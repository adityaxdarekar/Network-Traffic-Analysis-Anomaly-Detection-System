"""
Configuration for the Linux Failed Login Detection and Brute-Force Attack Monitoring System.

All detection thresholds, time windows, risk points and severity thresholds live here (DEFAULT_SETTINGS)
and can be changed on the dashboard's Detection Settings page (saved to user_settings.json).
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SAMPLES_DIR = BASE_DIR / "samples"
OUTPUT_DIR = BASE_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
DB_PATH = OUTPUT_DIR / "monitor_history.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"
STYLE_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "Linux Failed Login Detection and Brute-Force Attack Monitoring System"
APP_SHORT = "Failed Login Monitor"
APP_VERSION = "1.0.0"

# --------------------------------------------------------------------------- log sources
SYSTEM_LOGS = {
    "Ubuntu / Debian / Kali (/var/log/auth.log)": "/var/log/auth.log",
    "CentOS / RHEL / Fedora (/var/log/secure)": "/var/log/secure",
}
ALLOWED_UPLOAD_EXTENSIONS = {".log", ".txt"}
MAX_UPLOAD_BYTES = 50 * 1024 * 1024          # 50 MB per uploaded file
MAX_READ_BYTES = 50 * 1024 * 1024            # system logs: only the most recent 50 MB are read
MAX_LINES = 1_000_000
# journalctl is called with a fixed argument list (no shell), read-only
JOURNAL_COMMAND = ["journalctl", "--no-pager", "-o", "short-iso", "--since", "-7d",
                   "_COMM=sshd", "+", "_COMM=sshd-session", "+", "SYSLOG_FACILITY=4", "+", "SYSLOG_FACILITY=10"]
JOURNAL_TIMEOUT = 30

# --------------------------------------------------------------------------- risk
RISK_LABELS = {"LOW": "LOW RISK", "MEDIUM": "MEDIUM RISK", "HIGH": "HIGH RISK"}
RISK_COLORS = {"LOW": "#22c55e", "MEDIUM": "#f59e0b", "HIGH": "#ef4444"}

RULE_NAMES = {
    "R1": "Repeated Failed Logins",
    "R2": "High-Volume Failed Logins",
    "R3": "Multiple Username Attempts",
    "R4": "Root Login Attempts",
    "R5": "Distributed Login Attempts",
    "R6": "Successful Login After Repeated Failures",
}

DEFAULT_SETTINGS = {
    "rules": {
        # R1: >= threshold failed attempts from one IP within window_minutes
        "R1": {"enabled": True, "threshold": 5, "window_minutes": 5, "points": 20},
        # R2: high volume
        "R2": {"enabled": True, "threshold": 10, "window_minutes": 10, "points": 30},
        # R3: >= threshold DIFFERENT usernames from one IP within window_minutes
        "R3": {"enabled": True, "threshold": 5, "window_minutes": 10, "points": 20},
        # R4: >= threshold failed attempts for root from one IP within window_minutes
        "R4": {"enabled": True, "threshold": 3, "window_minutes": 10, "points": 15},
        # R5: one username failed from >= threshold different IPs within window_minutes,
        #     each IP with >= min_attempts_per_ip failures
        "R5": {"enabled": True, "threshold": 3, "window_minutes": 30, "min_attempts_per_ip": 2, "points": 30},
        # R6: success for user from IP after >= threshold failures for the same user+IP within window_minutes
        "R6": {"enabled": True, "threshold": 3, "window_minutes": 10, "points": 25},
    },
    "risk_thresholds": {"MEDIUM": 30, "HIGH": 60},     # 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH
    "incident_gap_minutes": 15,     # rule hits of one IP closer than this are merged into one alert
    "assume_year": None,            # year for syslog timestamps without a year (None = current year)
    "store_raw_events": False,      # privacy: raw log lines are not stored in history by default
}


def default_settings() -> dict:
    return copy.deepcopy(DEFAULT_SETTINGS)


def _merge(base: dict, new: dict) -> dict:
    for k, v in new.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _merge(base[k], v)
        elif k in base:
            base[k] = v
    return base


def load_settings(path: Path | None = None) -> dict:
    settings = default_settings()
    try:
        data = json.loads(Path(path or SETTINGS_FILE).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            _merge(settings, data)
    except (OSError, ValueError):
        pass
    return settings


def save_settings(settings: dict, path: Path | None = None) -> None:
    Path(path or SETTINGS_FILE).write_text(json.dumps(settings, indent=2), encoding="utf-8")


def validate_settings(settings: dict) -> list[str]:
    """Human-readable problems; empty list = valid."""
    problems = []
    for rid, r in settings["rules"].items():
        if int(r.get("threshold", 1)) < 1:
            problems.append(f"{rid}: threshold must be at least 1")
        if float(r.get("window_minutes", 1)) <= 0:
            problems.append(f"{rid}: time window must be greater than 0")
        if not 0 <= int(r.get("points", 0)) <= 100:
            problems.append(f"{rid}: points must be between 0 and 100")
    t = settings["risk_thresholds"]
    if not 0 < int(t["MEDIUM"]) < int(t["HIGH"]) <= 100:
        problems.append("Risk thresholds must satisfy 0 < MEDIUM < HIGH <= 100")
    return problems
