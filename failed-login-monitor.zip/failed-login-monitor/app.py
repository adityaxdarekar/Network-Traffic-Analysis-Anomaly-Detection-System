"""
Linux Failed Login Detection and Brute-Force Attack Monitoring System - Streamlit entry point.

    streamlit run app.py                  # uploads and samples (no root needed)
    sudo -E $(which streamlit) run app.py  # also read /var/log/auth.log or /var/log/secure directly
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from dashboard import (about_page, alerts_page, analyze_page, events_page, history_page, ips_page,  # noqa: E402
                       overview, reports_page, settings_page)
from dashboard.common import css, get_result, get_settings  # noqa: E402

PAGES = {
    "SOC Dashboard": ("📊", overview.render),
    "Analyze Logs": ("📂", analyze_page.render),
    "Failed Logins": ("🔑", events_page.render),
    "Suspicious IPs": ("🌐", ips_page.render),
    "Security Alerts": ("🚨", alerts_page.render),
    "Alert & Scan History": ("🕘", history_page.render),
    "Reports": ("📄", reports_page.render),
    "Detection Settings": ("⚙️", settings_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def main() -> None:
    st.set_page_config(page_title="Failed Login Monitor", page_icon="🛡️", layout="wide",
                       initial_sidebar_state="expanded")
    st.markdown(css(), unsafe_allow_html=True)
    get_settings()
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Analyze Logs"
    with st.sidebar:
        st.markdown("## 🛡️ Failed Login Monitor")
        st.caption(f"Linux brute-force detection · v{C.APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        r = get_result()
        if r is not None:
            st.markdown(f"**Loaded:** `{r.source}`")
            st.caption(f"{r.stats['failed_attempts']:,} failed · {len(r.alerts)} alerts")
        else:
            st.caption("No log loaded.")
        st.caption("🔒 Read-only · nothing is blocked · local only")
    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException") for c in type(exc).__mro__):
            raise
        st.error("Something went wrong on this page. Please check the input and try again.")
        if "--debug" in sys.argv:
            st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
