"""Safe log reading: uploads, files, size limits, .gz, permissions, journal, read-only guarantee."""

from __future__ import annotations

import gzip
import hashlib
import os
import re
import subprocess
import sys

import pytest

import config as C
from conftest import IS_ROOT, ROOT
from monitor import log_reader as LR
from monitor.log_reader import LogReadError, read_log_file, read_upload


def test_upload_ok():
    t = read_upload("auth.log", b"Nov  6 10:00:00 h sshd[1]: Failed password for root from 10.0.0.1 port 1 ssh2\n")
    assert t.source == "upload: auth.log" and "Failed password" in t.text


@pytest.mark.parametrize("name", ["auth.pdf", "auth.exe", "auth", "auth.gz"])
def test_upload_wrong_type(name):
    with pytest.raises(LogReadError, match="Unsupported file type"):
        read_upload(name, b"text")


def test_upload_empty_binary_and_too_large(monkeypatch):
    with pytest.raises(LogReadError, match="empty"):
        read_upload("a.log", b"")
    with pytest.raises(LogReadError, match="binary"):
        read_upload("a.txt", b"\x7fELF\x00\x00\x01")
    monkeypatch.setattr(C, "MAX_UPLOAD_BYTES", 10)
    with pytest.raises(LogReadError, match="larger than"):
        read_upload("a.log", b"x" * 11)


def test_invalid_utf8_is_replaced():
    assert "\ufffd" in read_upload("a.log", b"caf\xe9 line\n").text


def test_read_file_and_missing_and_directory(tmp_path):
    f = tmp_path / "auth.log"
    f.write_text("line1\nline2\n")
    assert read_log_file(f).text == "line1\nline2\n"
    with pytest.raises(LogReadError, match="does not exist"):
        read_log_file(tmp_path / "nope.log")
    with pytest.raises(LogReadError, match="directory"):
        read_log_file(tmp_path)


def test_large_file_reads_newest_part_from_a_full_line(tmp_path):
    f = tmp_path / "big.log"
    f.write_text("".join(f"line {i:05d}\n" for i in range(1000)))
    t = read_log_file(f, max_bytes=100)
    assert t.truncated and t.text.endswith("line 00999\n")
    assert all(re.fullmatch(r"line \d{5}", ln) for ln in t.text.splitlines())    # no partial first line


def test_gzip_rotated_log(tmp_path):
    f = tmp_path / "auth.log.2.gz"
    with gzip.open(f, "wt") as fh:
        fh.write("Nov  6 10:00:00 h sshd[1]: Failed password for root from 10.0.0.1 port 1 ssh2\n")
    assert "Failed password" in read_log_file(f).text


def test_reading_does_not_modify_the_log(tmp_path):
    f = tmp_path / "auth.log"
    f.write_bytes((ROOT / "samples" / "auth_attack.log").read_bytes())
    before = (hashlib.sha256(f.read_bytes()).hexdigest(), os.stat(f).st_mtime_ns, os.stat(f).st_size)
    read_log_file(f)
    after = (hashlib.sha256(f.read_bytes()).hexdigest(), os.stat(f).st_mtime_ns, os.stat(f).st_size)
    assert before == after


def test_permission_error_explained(tmp_path, monkeypatch):
    f = tmp_path / "secure"
    f.write_text("x\n")

    def deny(*a, **k):
        raise PermissionError(13, "Permission denied")
    monkeypatch.setattr("builtins.open", deny)
    with pytest.raises(LogReadError, match="adm"):
        read_log_file(f)


@pytest.mark.skipif(not IS_ROOT, reason="needs root to start a process as 'nobody'")
def test_permission_denied_real_unprivileged_process():
    import shutil
    import tempfile
    from pathlib import Path
    top = Path(tempfile.mkdtemp(prefix="flm-test-"))
    try:
        top.chmod(0o755)
        shutil.copytree(ROOT / "monitor", top / "code" / "monitor", ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy(ROOT / "config.py", top / "code" / "config.py")
        for p in [top / "code", *(top / "code").rglob("*")]:
            p.chmod(0o755 if p.is_dir() else 0o644)
        log = top / "auth.log"
        log.write_text("secret\n")
        log.chmod(0o640)                      # like /var/log/auth.log: root:adm 640
        code = ("import sys; sys.path.insert(0, sys.argv[1]); from monitor.log_reader import *\n"
                "try:\n    read_log_file(sys.argv[2])\nexcept LogReadError as e:\n    print('DENIED', 'adm' in str(e))")
        out = subprocess.run(["setpriv", "--reuid=65534", "--regid=65534", "--clear-groups", sys.executable, "-I",
                              "-c", code, str(top / "code"), str(log)], capture_output=True, text=True, timeout=60)
        assert out.stdout.strip() == "DENIED True", out.stderr
    except FileNotFoundError:
        pytest.skip("setpriv not installed")
    finally:
        shutil.rmtree(top)


def test_source_never_writes_logs():
    """Only read modes are used to open logs; no file deletion, truncation or config changes in the monitor code."""
    for py in (ROOT / "monitor").glob("*.py"):
        text = py.read_text()
        for m in re.finditer(r"open\(([^)]*)\)", text):
            assert not re.search(r"['\"](w|a|r\+|x)b?['\"]", m.group(1)), (py.name, m.group(0))
        for forbidden in ("os.remove", "os.unlink", "truncate(", "shutil.rmtree", "iptables", "ufw ", "chmod",
                          "shell=True"):
            assert forbidden not in text, (py.name, forbidden)


def test_journal_uses_fixed_command_without_shell(monkeypatch):
    seen = {}

    def fake_run(cmd, **kw):
        seen.update(cmd=cmd, **kw)
        return subprocess.CompletedProcess(cmd, 0, b"-- Logs begin --\n2026-11-06T10:00:00+0000 h sshd[1]: Failed "
                                                   b"password for root from 10.0.0.1 port 1 ssh2\n", b"")
    monkeypatch.setattr(LR.shutil, "which", lambda name: "/usr/bin/journalctl")
    monkeypatch.setattr(LR.subprocess, "run", fake_run)
    t = LR.read_journal()
    assert seen["cmd"] == C.JOURNAL_COMMAND and seen["shell"] is False
    assert t.source == "journalctl" and t.text.startswith("2026-11-06")       # "-- " lines removed


def test_journal_errors(monkeypatch):
    monkeypatch.setattr(LR.shutil, "which", lambda name: None)
    with pytest.raises(LogReadError, match="not installed"):
        LR.read_journal()
    monkeypatch.setattr(LR.shutil, "which", lambda name: "/usr/bin/journalctl")
    monkeypatch.setattr(LR.subprocess, "run", lambda cmd, **kw: subprocess.CompletedProcess(
        cmd, 1, b"", b"Hint: You are currently not seeing messages from other users and the system."))
    with pytest.raises(LogReadError, match="permission"):
        LR.read_journal()
    monkeypatch.setattr(LR.subprocess, "run", lambda cmd, **kw: subprocess.CompletedProcess(cmd, 0, b"-- No entries --\n",
                                                                                            b""))
    with pytest.raises(LogReadError, match="no SSH"):
        LR.read_journal()


def test_available_system_logs_reports_without_reading():
    status = LR.available_system_logs()
    assert set(status) == set(C.SYSTEM_LOGS) and all({"exists", "readable"} <= set(v) for v in status.values())
