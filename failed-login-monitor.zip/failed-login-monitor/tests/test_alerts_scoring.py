"""Risk scoring, classification, priority, alerts (fields, merging, no duplicates), IP table."""

from __future__ import annotations

from datetime import timedelta

import pytest

from conftest import T0, accepted, analyze, attempts
from monitor.risk_scorer import classify, priority, score_rules

TH = {"MEDIUM": 30, "HIGH": 60}


@pytest.mark.parametrize("score,level", [(0, "LOW"), (29, "LOW"), (30, "MEDIUM"), (59, "MEDIUM"), (60, "HIGH"),
                                         (100, "HIGH")])
def test_classification(score, level):
    assert classify(score, TH) == level


def test_score_sum_and_cap():
    assert score_rules({"R1": 20, "R2": 30}) == 50
    assert score_rules({"R1": 20, "R2": 30, "R3": 20, "R4": 15, "R6": 25}) == 100      # 110 -> capped


def test_configurable_thresholds():
    assert classify(45, {"MEDIUM": 50, "HIGH": 80}) == "LOW"


def test_priority():
    assert priority("LOW", {"R6"}) == "P1" and priority("HIGH", set()) == "P1"
    assert priority("MEDIUM", {"R1"}) == "P2" and priority("LOW", {"R4"}) == "P3"


def test_full_brute_force_alert():
    r = analyze(attempts("192.168.1.100", 12, users=("admin", "root", "test", "user", "guest")))
    assert len(r.alerts) == 1
    a = r.alerts[0]
    assert a.title == "POSSIBLE SSH BRUTE-FORCE ATTACK" and a.source_ip == "192.168.1.100"
    assert a.rule_ids == ["R1", "R2", "R3", "R4"] and a.risk_score == 85 and a.severity == "HIGH"
    assert a.failed_count == 12 and a.target_usernames == ["admin", "guest", "root", "test", "user"]
    d = a.to_dict()
    for field in ("alert_id", "first_seen", "source_ip", "target_usernames", "failed_count", "rules", "risk_score",
                  "severity", "explanation", "recommended_response"):
        assert d[field] not in (None, "", []), field
    assert "R1 Repeated Failed Logins" in a.explanation and "R4 Root Login Attempts" in a.explanation
    assert any("does not block" in x for x in a.recommended_response)


def test_alert_ids_sequential():
    lines = attempts("10.0.0.1", 6) + attempts("10.0.0.2", 6, start=T0 + timedelta(hours=1), pid0=900)
    assert [a.alert_id for a in analyze(lines).alerts] == ["ALT-0001", "ALT-0002"]


def test_hits_of_one_incident_merge_into_one_alert():
    lines = attempts("10.0.0.1", 6) + [accepted(T0 + timedelta(minutes=2), "root", "10.0.0.1")]
    r = analyze(lines)
    assert len(r.alerts) == 1 and set(r.alerts[0].rule_ids) == {"R1", "R4", "R6"}
    assert r.alerts[0].title.startswith("SUCCESSFUL LOGIN AFTER REPEATED FAILURES")


def test_incident_gap_splits_alerts(settings):
    lines = attempts("10.0.0.1", 6) + attempts("10.0.0.1", 6, start=T0 + timedelta(minutes=40), pid0=900)
    assert len(analyze(lines, settings).alerts) == 2
    settings["incident_gap_minutes"] = 60
    assert len(analyze(lines, settings).alerts) == 1


def test_fingerprint_stable_between_runs():
    lines = attempts("10.0.0.1", 6)
    assert analyze(lines).alerts[0].fingerprint == analyze(lines).alerts[0].fingerprint
    assert analyze(lines).alerts[0].fingerprint == analyze(lines + attempts("10.0.0.1", 3, start=T0 + timedelta(
        minutes=1), pid0=500)).alerts[0].fingerprint        # same incident growing -> same alert


def test_distributed_alert():
    lines = []
    for j, ip in enumerate(["10.0.1.1", "10.0.1.2", "10.0.1.3", "10.0.1.4"]):
        lines += attempts(ip, 2, start=T0 + timedelta(minutes=j * 3), users=("admin",), pid0=100 * j + 1)
    r = analyze(lines)
    a = next(a for a in r.alerts if a.alert_type == "DISTRIBUTED")
    assert a.source_ip == "multiple (4)" and a.target_usernames == ["admin"] and a.failed_count == 8
    assert a.risk_score == 30 and a.severity == "MEDIUM"


def test_ip_table_fields_and_wording():
    lines = attempts("192.168.1.100", 6, users=("root", "admin")) + attempts("10.9.9.9", 2, start=T0 + timedelta(
        hours=1), pid0=700) + [accepted(T0 + timedelta(hours=2), "alice", "10.9.9.10")]
    ips = analyze(lines).ips.set_index("ip")
    row = ips.loc["192.168.1.100"]
    assert row["failed_attempts"] == 6 and row["usernames_targeted"] == 2 and row["ip_class"] == "Private"
    assert row["status"] == "Flagged for review" and "R1" in row["reason"] and str(row["first_seen"]).startswith("2026")
    assert ips.loc["10.9.9.9", "status"] == "Not flagged" and ips.loc["10.9.9.9", "reason"].startswith("Below")
    assert ips.loc["10.9.9.10", "successful_logins"] == 1
    assert not any("malicious" in str(v).lower() for v in ips["status"])


def test_no_alerts_for_clean_log():
    lines = [accepted(T0 + timedelta(hours=i), "alice", "10.0.0.2", pid=i) for i in range(5)]
    r = analyze(lines)
    assert r.alerts == [] and r.severity_counts == {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
