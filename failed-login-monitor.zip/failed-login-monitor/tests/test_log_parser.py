"""Parser: event types, fields, formats, IPv6, malformed lines, attempt de-duplication, IP classification."""

from __future__ import annotations

import pytest

from monitor.log_parser import classify_ip, clean_ip, parse_log

BRIEF_EXAMPLE = """Nov 6 10:20:01 ubuntu sshd[1234]: Failed password for invalid user admin from 192.168.1.100 port 45321 ssh2
Nov 6 10:20:05 ubuntu sshd[1235]: Failed password for root from 192.168.1.100 port 45322 ssh2
Nov 6 10:20:09 ubuntu sshd[1236]: Failed password for test from 192.168.1.100 port 45323 ssh2
Nov 6 10:25:00 ubuntu sshd[1240]: Accepted password for student from 192.168.1.105 port 45324 ssh2"""


def one(line, year=2026):
    r = parse_log(line, year=year)
    assert len(r.events) == 1, r.events
    return r.events[0]


def test_brief_example_lines():
    r = parse_log(BRIEF_EXAMPLE, year=2026)
    assert [(e.event_type, e.username, e.ip, e.port) for e in r.events] == [
        ("FAILED_PASSWORD", "admin", "192.168.1.100", 45321), ("FAILED_PASSWORD", "root", "192.168.1.100", 45322),
        ("FAILED_PASSWORD", "test", "192.168.1.100", 45323), ("ACCEPTED_PASSWORD", "student", "192.168.1.105", 45324)]
    e = r.events[0]
    assert str(e.timestamp) == "2026-11-06 10:20:01" and e.hostname == "ubuntu" and e.service == "sshd"
    assert e.pid == "1234" and e.invalid_user and e.raw.startswith("Nov 6 10:20:01")
    assert [e.counts_as_attempt for e in r.events] == [True, True, True, False]


def test_successful_login_is_never_a_failure():
    e = one("Nov  6 10:25:00 h sshd[1]: Accepted password for student from 10.0.0.1 port 1 ssh2")
    assert e.success and not e.failed and not e.counts_as_attempt


@pytest.mark.parametrize("line,etype,user,ip,port", [
    ("Nov  6 10:00:00 h sshd[1]: Failed publickey for git from 10.0.0.2 port 22 ssh2: RSA SHA256:x",
     "FAILED_PUBLICKEY", "git", "10.0.0.2", 22),
    ("Nov  6 10:00:00 h sshd[1]: Accepted publickey for deploy from 10.0.0.3 port 23 ssh2: ED25519 SHA256:y",
     "ACCEPTED_PUBLICKEY", "deploy", "10.0.0.3", 23),
    ("Nov  6 10:00:00 h sshd[1]: Invalid user oracle from 10.0.0.4 port 24", "INVALID_USER", "oracle", "10.0.0.4", 24),
    ("Nov  6 10:00:00 h sshd[1]: Invalid user oracle from 10.0.0.4", "INVALID_USER", "oracle", "10.0.0.4", None),
    ("Nov  6 10:00:00 h sshd[1]: pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= "
     "rhost=10.0.0.5  user=root", "AUTH_FAILURE", "root", "10.0.0.5", None),
    ("Nov  6 10:00:00 h sshd[1]: Failed password for invalid user  from 10.0.0.6 port 25 ssh2",
     "FAILED_PASSWORD", "", "10.0.0.6", 25),
    ("Nov  6 10:00:00 h sshd[1]: Failed keyboard-interactive/pam for invalid user ops from 10.0.0.8 port 27 ssh2",
     "FAILED_PASSWORD", "ops", "10.0.0.8", 27),
    ("Nov  6 10:00:00 h sshd[1]: Accepted keyboard-interactive/pam for ops from 10.0.0.8 port 28 ssh2",
     "ACCEPTED_PASSWORD", "ops", "10.0.0.8", 28),
    ("Nov  6 10:00:00 h sshd[1]: Failed password for user.name-01 from 10.0.0.7 port 26 ssh2",
     "FAILED_PASSWORD", "user.name-01", "10.0.0.7", 26),
])
def test_event_types(line, etype, user, ip, port):
    e = one(line)
    assert (e.event_type, e.username, e.ip, e.port) == (etype, user, ip, port)


@pytest.mark.parametrize("ip_text,expected", [("2001:db8::5", "2001:db8::5"), ("2001:DB8:0:0::5", "2001:db8::5"),
                                              ("::FFFF:192.0.2.9", "::ffff:192.0.2.9"), ("fe80::1%eth0", "fe80::1")])
def test_ipv6(ip_text, expected):
    e = one(f"Nov  6 10:00:00 h sshd[1]: Failed password for root from {ip_text} port 22 ssh2")
    assert e.ip == expected and e.port == 22


def test_local_sudo_failure_has_no_ip():
    e = one("Nov  6 10:00:00 h sudo: pam_unix(sudo:auth): authentication failure; logname=bob uid=1000 euid=0 "
            "tty=/dev/pts/0 ruser=bob rhost=  user=bob")
    assert e.ip == "" and e.username == "bob" and e.service == "sudo" and e.counts_as_attempt


@pytest.mark.parametrize("stamp,expected", [("2026-11-06T10:20:01.123456+00:00", "2026-11-06 10:20:01.123456"),
                                            ("2026-11-06T10:20:01+0530", "2026-11-06 10:20:01"),
                                            ("2026-11-06T10:20:01Z", "2026-11-06 10:20:01"),
                                            ("2026-11-06T10:20:01", "2026-11-06 10:20:01")])
def test_iso8601_timestamps(stamp, expected):
    e = one(f"{stamp} web sshd-session[9]: Failed password for root from 10.1.1.1 port 2 ssh2")
    assert str(e.timestamp) == expected and e.service == "sshd-session" and e.hostname == "web"


def test_message_repeated_is_expanded():
    r = parse_log("Nov  6 10:00:00 h sshd[1]: message repeated 4 times: [ Failed password for root from 10.0.0.1 "
                  "port 22 ssh2]", year=2026)
    assert len(r.events) == 4 and all(e.counts_as_attempt for e in r.events)


@pytest.mark.parametrize("msg", [
    "Connection closed by authenticating user root 10.0.0.1 port 22 [preauth]",
    "Disconnected from invalid user admin 10.0.0.1 port 22 [preauth]",
    "Received disconnect from 10.0.0.1 port 22:11: Bye Bye [preauth]",
    "error: maximum authentication attempts exceeded for root from 10.0.0.1 port 22 ssh2 [preauth]",
    "PAM 2 more authentication failures; logname= uid=0 euid=0 tty=ssh ruser= rhost=10.0.0.1  user=root",
    "pam_unix(sshd:session): session opened for user alice(uid=1000) by alice(uid=0)",
    "Server listening on 0.0.0.0 port 22."])
def test_related_lines_are_not_counted_as_extra_attempts(msg):
    """Summary / disconnect lines describe attempts already logged - they must not add attempts."""
    r = parse_log(f"Nov  6 10:00:00 h sshd[1]: {msg}", year=2026)
    assert r.events == [] and r.other_lines == 1


def test_malformed_lines_do_not_crash():
    text = "\n".join(["garbage", "", "Nov  6", "\x00\x01 binary-ish", "Nov 31 10:00:00 h sshd[1]: Failed password "
                      "for x from 10.0.0.1 port 1 ssh2", "Nov  6 10:00:00 h sshd[1]: Failed password for root from "
                      "10.0.0.2 port 22 ssh2", "Nov  6 10:00:01 h CRON[5]: pam_unix(cron:session): session opened"])
    r = parse_log(text, year=2026)
    assert r.unrecognised_header == 3 and r.bad_timestamps == 1 and r.other_lines == 1
    assert len(r.events) == 2 and r.events[0].timestamp is None and r.malformed_samples


def test_year_rollover():
    r = parse_log("Dec 31 23:59:58 h sshd[1]: Failed password for a from 10.0.0.1 port 1 ssh2\n"
                  "Jan  1 00:00:03 h sshd[2]: Failed password for a from 10.0.0.1 port 2 ssh2", year=2025)
    assert [str(e.timestamp) for e in r.events] == ["2025-12-31 23:59:58", "2026-01-01 00:00:03"]


def test_one_guess_counted_once():
    """Invalid user + pam failure + Failed password from the same connection = 1 attempt."""
    text = """Nov  6 10:00:00 h sshd[77]: Invalid user oracle from 10.0.0.9 port 5000
Nov  6 10:00:00 h sshd[77]: pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost=10.0.0.9
Nov  6 10:00:02 h sshd[77]: Failed password for invalid user oracle from 10.0.0.9 port 5000 ssh2
Nov  6 10:00:05 h sshd[77]: Failed password for invalid user oracle from 10.0.0.9 port 5000 ssh2"""
    r = parse_log(text, year=2026)
    assert len(r.events) == 4 and sum(e.counts_as_attempt for e in r.events) == 2   # two guesses


def test_invalid_user_without_password_attempt_is_counted():
    r = parse_log("Nov  6 10:00:00 h sshd[88]: Invalid user mysql from 10.0.0.9 port 5001", year=2026)
    assert r.events[0].counts_as_attempt


def test_dataframe_columns():
    df = parse_log(BRIEF_EXAMPLE, year=2026).dataframe()
    assert {"timestamp", "hostname", "event_type", "username", "ip", "port", "service", "raw", "failed",
            "success", "counts_as_attempt"} <= set(df.columns)
    assert str(df["timestamp"].dtype).startswith("datetime64")


@pytest.mark.parametrize("ip,cls", [("192.168.1.100", "Private"), ("10.1.2.3", "Private"), ("172.20.0.1", "Private"),
                                    ("fd00::1", "Private"), ("8.8.8.8", "Public"), ("2606:4700::1", "Public"),
                                    ("127.0.0.1", "Loopback"), ("::1", "Loopback"), ("169.254.1.1", "Link-local"),
                                    ("203.0.113.9", "Reserved"), ("2001:db8::1", "Reserved"),
                                    ("100.64.0.1", "Reserved"), ("999.1.1.1", "Invalid"), ("hostname", "Invalid"),
                                    ("", "Local (no IP)"), ("::ffff:8.8.8.8", "Public")])
def test_classify_ip(ip, cls):
    assert classify_ip(ip) == cls


def test_clean_ip_keeps_invalid_text():
    assert clean_ip("not-an-ip") == "not-an-ip" and clean_ip("[::1]") == "::1"
