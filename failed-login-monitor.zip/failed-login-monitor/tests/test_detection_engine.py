"""Detection rules R1-R6: thresholds, time windows, configurability, burst merging."""

from __future__ import annotations

from datetime import timedelta

from conftest import T0, accepted, analyze, attempts, failed


def rules(r):
    return sorted({h.rule for h in r.hits})


def test_r1_threshold_boundary(settings):
    assert rules(analyze(attempts("10.0.0.1", 4, users=("admin",)))) == []
    assert rules(analyze(attempts("10.0.0.1", 5, users=("admin",)))) == ["R1"]


def test_r1_time_window(settings):
    # 5 attempts spread over 6 minutes (90 s apart): never 5 within 5 minutes
    assert "R1" not in rules(analyze(attempts("10.0.0.1", 5, step_s=90)))
    # exactly 5 minutes from first to last attempt still counts as "within 5 minutes"
    assert "R1" in rules(analyze(attempts("10.0.0.1", 5, step_s=75)))


def test_r2_high_volume():
    assert "R2" not in rules(analyze(attempts("10.0.0.1", 9)))
    assert "R2" in rules(analyze(attempts("10.0.0.1", 10, step_s=60)))       # 10 in 9 minutes


def test_r3_distinct_usernames():
    four = analyze(attempts("10.0.0.1", 8, users=("a", "b", "c", "d")))
    five = analyze(attempts("10.0.0.1", 5, users=("a", "b", "c", "d", "e")))
    assert "R3" not in rules(four) and "R3" in rules(five)


def test_r4_root_attempts():
    assert "R4" in rules(analyze(attempts("10.0.0.1", 3, users=("root",))))
    assert "R4" not in rules(analyze(attempts("10.0.0.1", 3, users=("admin",))))


def test_r5_distributed():
    lines = []
    for j, ip in enumerate(["10.0.1.1", "10.0.1.2", "10.0.1.3"]):
        lines += attempts(ip, 2, start=T0 + timedelta(minutes=j * 4), users=("admin",), pid0=100 * j + 1)
    r = analyze(lines)
    hit = next(h for h in r.hits if h.rule == "R5")
    assert hit.target_user == "admin" and hit.ips == ["10.0.1.1", "10.0.1.2", "10.0.1.3"]
    assert "R5" not in rules(analyze(lines[:4]))                         # only 2 IPs


def test_r5_requires_min_attempts_per_ip():
    lines = [failed(T0 + timedelta(minutes=i), "admin", f"10.0.2.{i}", pid=i) for i in range(1, 6)]   # 1 each
    assert "R5" not in rules(analyze(lines))


def test_r6_success_after_failures():
    lines = attempts("10.0.0.7", 3, users=("deploy",)) + [accepted(T0 + timedelta(minutes=1), "deploy", "10.0.0.7")]
    r = analyze(lines)
    assert rules(r) == ["R6"] and r.alerts[0].priority == "P1"


def test_r6_not_triggered_by_typo_other_user_other_ip_or_old_failures():
    two = attempts("10.0.0.7", 2, users=("deploy",)) + [accepted(T0 + timedelta(seconds=40), "deploy", "10.0.0.7")]
    other_user = attempts("10.0.0.7", 3, users=("alice",)) + [accepted(T0 + timedelta(minutes=1), "deploy", "10.0.0.7")]
    other_ip = attempts("10.0.0.8", 3, users=("deploy",)) + [accepted(T0 + timedelta(minutes=1), "deploy", "10.0.0.7")]
    late = attempts("10.0.0.7", 3, users=("deploy",)) + [accepted(T0 + timedelta(minutes=30), "deploy", "10.0.0.7")]
    for lines in (two, other_user, other_ip, late):
        assert "R6" not in rules(analyze(lines))


def test_thresholds_are_configurable(settings):
    settings["rules"]["R1"]["threshold"] = 3
    settings["rules"]["R1"]["window_minutes"] = 1
    assert "R1" in rules(analyze(attempts("10.0.0.1", 3), settings))
    settings["rules"]["R1"]["window_minutes"] = 0.25           # 15 s: 3 attempts 10 s apart do not fit
    assert "R1" not in rules(analyze(attempts("10.0.0.1", 3), settings))


def test_rules_can_be_disabled(settings):
    for rid in settings["rules"]:
        settings["rules"][rid]["enabled"] = False
    r = analyze(attempts("10.0.0.1", 50, users=("root", "a", "b", "c", "d")), settings)
    assert r.hits == [] and r.alerts == []


def test_long_attack_produces_one_hit_per_rule():
    """40 consecutive attempts = one R1 burst, not 36 overlapping windows."""
    r = analyze(attempts("10.0.0.1", 40))
    assert sum(h.rule == "R1" for h in r.hits) == 1
    h = next(h for h in r.hits if h.rule == "R1")
    assert h.failed_count == 40 and h.max_in_window == 31          # 31 attempts fit in 5 min at 10 s spacing


def test_separate_bursts_produce_separate_hits():
    lines = attempts("10.0.0.1", 6) + attempts("10.0.0.1", 6, start=T0 + timedelta(hours=2), pid0=5000)
    assert sum(h.rule == "R1" for h in analyze(lines).hits) == 2


def test_local_and_untimestamped_events_excluded_from_windows():
    sudo = [f"Nov  6 10:00:0{i} h sudo: pam_unix(sudo:auth): authentication failure; logname=bob uid=1000 euid=0 "
            f"tty=/dev/pts/0 ruser=bob rhost=  user=bob" for i in range(9)]
    r = analyze(sudo)
    assert r.stats["local_failures"] == 9 and r.hits == []


def test_successful_logins_never_trigger_failure_rules():
    lines = [accepted(T0 + timedelta(seconds=i), "alice", "10.0.0.2", pid=i) for i in range(30)]
    r = analyze(lines)
    assert r.stats["failed_attempts"] == 0 and r.hits == []
