"""End-to-end: every sample log produces exactly the documented detections."""

from __future__ import annotations

import config as C
from conftest import ROOT
from monitor.analyzer import analyze_text


def run(name):
    return analyze_text((ROOT / "samples" / name).read_text(), name, C.default_settings())


def summary(r):
    return {(a.source_ip, tuple(a.rule_ids), a.severity, a.priority) for a in r.alerts}


def test_normal_day_has_no_alerts():
    r = run("auth_normal.log")
    assert r.alerts == [] and r.stats["failed_attempts"] == 2 and r.stats["successful_logins"] == 10


def test_attack_log():
    r = run("auth_attack.log")
    assert summary(r) == {
        ("192.168.1.100", ("R1", "R2", "R3", "R4"), "HIGH", "P1"),
        ("198.51.100.77", ("R1", "R6"), "MEDIUM", "P1"),
        ("multiple (4)", ("R5",), "MEDIUM", "P2"),
        ("192.0.2.44", ("R1", "R3"), "MEDIUM", "P2"),
        ("2001:db8:4::23", ("R4",), "LOW", "P3"),
    }
    s = r.stats
    assert (s["total_lines"], s["failed_attempts"], s["successful_logins"], s["malformed_lines"],
            s["local_failures"]) == (401, 92, 11, 2, 2)
    brute = next(a for a in r.alerts if a.source_ip == "192.168.1.100")
    assert brute.failed_count == 40 and brute.risk_score == 85


def test_slow_scanner_is_not_flagged():
    ips = run("auth_attack.log").ips.set_index("ip")
    assert ips.loc["203.0.113.25", "failed_attempts"] == 20 and ips.loc["203.0.113.25", "status"] == "Not flagged"


def test_rhel_secure_log():
    r = run("secure_rhel.log")
    assert summary(r) == {("10.10.5.20", ("R1", "R2", "R4"), "HIGH", "P1")}
    assert r.stats["failed_attempts"] == 18          # "PAM 2 more authentication failures" lines not double counted


def test_iso8601_ubuntu24_log():
    r = run("auth_iso8601.log")
    assert summary(r) == {("172.16.9.9", ("R1", "R3", "R6"), "HIGH", "P1")}
    assert r.stats["formats"] == {"iso8601": r.stats["events"]}
