"""Shared fixtures and log-line builders. Tests use only sample files and temporary files."""

from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config as C  # noqa: E402
from database.db_manager import DatabaseManager  # noqa: E402
from monitor.analyzer import analyze_text  # noqa: E402

IS_ROOT = os.geteuid() == 0
T0 = datetime(2026, 11, 6, 10, 0, 0)


def ts(t: datetime) -> str:
    return f"{t:%b} {t.day:2d} {t:%H:%M:%S}"


def failed(t, user, ip, pid=1000, port=50000, invalid=False):
    return f"{ts(t)} srv sshd[{pid}]: Failed password for {'invalid user ' if invalid else ''}{user} from {ip} " \
           f"port {port} ssh2"


def accepted(t, user, ip, pid=2000, port=50001, method="password"):
    return f"{ts(t)} srv sshd[{pid}]: Accepted {method} for {user} from {ip} port {port} ssh2"


def attempts(ip, n, start=T0, step_s=10, users=("root",), pid0=1000):
    return [failed(start + timedelta(seconds=i * step_s), users[i % len(users)], ip, pid=pid0 + i, port=40000 + i)
            for i in range(n)]


def analyze(lines, settings=None):
    return analyze_text("\n".join(lines), "test", settings or C.default_settings())


@pytest.fixture
def settings():
    return C.default_settings()


@pytest.fixture
def db(tmp_path):
    return DatabaseManager(tmp_path / "history.db")


@pytest.fixture
def attack_result():
    return analyze_text((ROOT / "samples" / "auth_attack.log").read_text(), "auth_attack.log",
                        C.default_settings())
