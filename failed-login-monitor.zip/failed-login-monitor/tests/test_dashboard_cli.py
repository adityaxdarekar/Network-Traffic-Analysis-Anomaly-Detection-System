"""Headless dashboard tests (Streamlit stand-in) and command-line interface tests."""

from __future__ import annotations

import pytest

from tests import streamlit_stub as S

S.install()
import streamlit as st  # noqa: E402

import app  # noqa: E402
import cli  # noqa: E402
import config as C  # noqa: E402
from conftest import ROOT  # noqa: E402
from dashboard import common  # noqa: E402


class Upload:
    def __init__(self, name, data):
        self.name, self._data = name, data

    def getvalue(self):
        return self._data


@pytest.fixture
def env(tmp_path, monkeypatch, db):
    monkeypatch.setattr(common, "get_db", lambda: db)
    monkeypatch.setattr(C, "SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr(C, "REPORT_DIR", tmp_path / "reports")
    st.session_state.clear()
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(), {}
    return db


def page(name, press=(), **inputs):
    st.session_state["nav"] = name
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(press), inputs
    try:
        app.main()
    except S.StopException:
        pass
    except S.RerunException:
        return "rerun"
    return [c for c in S.StubState.calls if c[0] in ("error", "exception")]


def test_nine_pages():
    assert list(app.PAGES) == ["SOC Dashboard", "Analyze Logs", "Failed Logins", "Suspicious IPs", "Security Alerts",
                               "Alert & Scan History", "Reports", "Detection Settings", "About Project"]


@pytest.mark.parametrize("name", list(app.PAGES))
def test_pages_without_data(env, name):
    assert page(name) == []


def test_sample_workflow_and_all_pages(env):
    assert page("Analyze Logs", press={"▶ Analyze sample"}) == []
    r = st.session_state["result"]
    assert len(r.alerts) == 5 and env.stats()["alerts"] == 5
    for name in app.PAGES:
        assert page(name) == [], name


def test_upload_valid_and_invalid(env):
    data = (ROOT / "samples" / "secure_rhel.log").read_bytes()
    assert page("Analyze Logs", press={"▶ Analyze file"}, src="Upload a log file", upload=Upload("secure", data)) \
        != []      # no extension -> friendly error
    assert "result" not in st.session_state
    assert page("Analyze Logs", press={"▶ Analyze file"}, src="Upload a log file",
                upload=Upload("secure.log", data)) == []
    assert st.session_state["result"].source == "upload: secure.log"


def test_missing_system_log_message(env, tmp_path):
    errors = page("Analyze Logs", press={"▶ Read system log"}, src="System log file",
                  sys_custom=str(tmp_path / "auth.log"))
    assert len(errors) == 1 and "does not exist" in str(errors[0])


def test_settings_reanalyse(env):
    page("Analyze Logs", press={"▶ Analyze sample"})
    assert page("Detection Settings", press={"🔁 Save and re-analyse current log"}, set_R1_t=3) == []
    assert st.session_state["settings"]["rules"]["R1"]["threshold"] == 3
    assert len(st.session_state["result"].alerts) > 5


def test_invalid_settings_block_saving(env):
    errors = page("Detection Settings", set_med=70, set_high=60)
    assert errors and "MEDIUM < HIGH" in str(errors[0])


def test_history_status_and_reports(env):
    page("Analyze Logs", press={"▶ Analyze sample"})
    assert page("Alert & Scan History", press={"Update status"}, h_new_status="Investigating") == "rerun"
    assert "Investigating" in set(env.list_alerts()["status"])
    assert page("Reports", press={"💾 Save PDF to output/reports"}) == []
    assert list(C.REPORT_DIR.glob("*.pdf"))


def test_cli_analyze(capsys):
    assert cli.main(["analyze", str(ROOT / "samples" / "auth_attack.log"), "--no-color"]) == 0
    out = capsys.readouterr().out
    assert "Alerts: 5 (HIGH 1, MEDIUM 3, LOW 1)" in out and "POSSIBLE SSH BRUTE-FORCE ATTACK" in out


def test_cli_exports(tmp_path, capsys):
    pdf, csv_ = tmp_path / "r.pdf", tmp_path / "a.csv"
    assert cli.main(["analyze", str(ROOT / "samples" / "auth_iso8601.log"), "--pdf", str(pdf), "--csv", str(csv_)]) == 0
    assert pdf.read_bytes().startswith(b"%PDF") and "172.16.9.9" in csv_.read_text()


def test_cli_missing_file(capsys):
    assert cli.main(["analyze", "/no/such/file.log"]) == 1
    assert "does not exist" in capsys.readouterr().out


def test_cli_watch_prints_only_new_alerts(tmp_path, capsys, monkeypatch):
    log = tmp_path / "auth.log"
    lines = (ROOT / "samples" / "auth_attack.log").read_text().splitlines()
    log.write_text("\n".join(lines[:150]) + "\n")
    calls = {"n": 0}

    def grow(_):
        calls["n"] += 1
        if calls["n"] == 1:
            log.write_text("\n".join(lines) + "\n")       # the log grows between polls
    monkeypatch.setattr(cli.time, "sleep", grow)
    cli.watch(str(log), 0, False, max_cycles=3)
    out = capsys.readouterr().out
    assert out.count("ALERT ALT-") == 5                              # 5 different alerts, each printed once
    assert out.count("Source IP:        192.168.1.100") == 1         # already shown in cycle 1, not repeated
    assert "5 alert(s), 4 new" in out
