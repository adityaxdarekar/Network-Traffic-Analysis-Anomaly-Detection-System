"""SQLite history (no duplicate alerts, status tracking), CSV/JSON/ZIP exports and the PDF report."""

from __future__ import annotations

import csv
import io
import json
import zipfile

import pytest

import config as C
from conftest import ROOT, analyze, attempts
from monitor.analyzer import analyze_text
from reports.export_manager import alerts_csv, events_csv, ips_csv, stamp_name, to_json, zip_bundle
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report


def test_save_and_reanalyse_without_duplicates(db, attack_result):
    assert db.save_analysis(attack_result) == {"new_alerts": 5, "updated_alerts": 0}
    again = analyze_text((ROOT / "samples" / "auth_attack.log").read_text(), "again", C.default_settings())
    assert db.save_analysis(again) == {"new_alerts": 0, "updated_alerts": 5}
    alerts = db.list_alerts()
    assert len(alerts) == 5 and set(alerts["times_seen"]) == {2}
    assert len(db.get_analysis(attack_result.analysis_id)["alerts"]) == 5      # both analyses keep their alerts
    assert len(db.get_analysis(again.analysis_id)["alerts"]) == 5
    assert db.stats()["analyses"] == 2


def test_alert_status_and_filters(db, attack_result):
    db.save_analysis(attack_result)
    fp = db.list_alerts("HIGH").iloc[0]["fingerprint"]
    db.set_alert_status(fp, "Investigating")
    assert db.get_alert(fp)["status"] == "Investigating" and len(db.list_alerts(status="Investigating")) == 1
    with pytest.raises(ValueError):
        db.set_alert_status(fp, "Deleted")
    assert len(db.list_alerts(ip="203.0.113.1")) == 1                         # distributed alert, by member IP


def test_delete_and_clear(db, attack_result):
    db.save_analysis(attack_result)
    db.delete_analysis(attack_result.analysis_id)
    assert db.list_alerts().empty and db.list_analyses().empty
    db.save_analysis(attack_result)
    db.clear()
    assert db.stats()["alerts"] == 0


def test_raw_lines_not_stored_by_default(db, attack_result, tmp_path):
    db.save_analysis(attack_result)
    import sqlite3
    with sqlite3.connect(db.path) as con:
        assert con.execute("SELECT raw_events FROM analyses").fetchone()[0] is None
    db.save_analysis(attack_result, store_raw=True)
    with sqlite3.connect(db.path) as con:
        assert "Failed password" in con.execute("SELECT raw_events FROM analyses").fetchone()[0]


def test_sql_injection_safe(db, attack_result):
    db.save_analysis(attack_result)
    assert db.list_alerts(ip="' OR 1=1; DROP TABLE alerts; --").empty and len(db.list_alerts()) == 5


def test_csv_exports(attack_result):
    rows = list(csv.DictReader(io.StringIO(alerts_csv(attack_result))))
    assert len(rows) == 5 and {"alert_id", "source_ip", "risk_score", "severity", "recommended_response"} <= set(rows[0])
    assert len(list(csv.DictReader(io.StringIO(ips_csv(attack_result))))) == 12
    ev = events_csv(attack_result)
    assert "raw" not in ev.splitlines()[0] and "raw" in events_csv(attack_result, include_raw=True).splitlines()[0]


def test_json_and_zip(attack_result):
    d = json.loads(to_json(attack_result))
    assert len(d["alerts"]) == 5 and d["statistics"]["failed_attempts"] == 92 and "disclaimer" in d
    with zipfile.ZipFile(io.BytesIO(zip_bundle(attack_result))) as z:
        assert sorted(z.namelist()) == ["alerts.csv", "analysis.json", "events.csv", "ip_summary.csv"]


def test_stamp_name_is_safe():
    name = stamp_name("alerts", "upload: ../../etc/passwd", "csv")
    assert "/" not in name and ".." not in name and name.endswith(".csv")


def test_pdf_report(tmp_path, attack_result):
    pypdf = pytest.importorskip("pypdf")
    path = generate_pdf_report(attack_result, tmp_path / "r.pdf", analyst="Tester")
    text = "\n".join(p.extract_text() for p in pypdf.PdfReader(str(path)).pages)
    for needed in ("Executive summary", "Log source and parsing", "Detection rules and thresholds",
                   "Activity timeline", "Security alerts", "POSSIBLE SSH BRUTE-FORCE ATTACK", "192.168.1.100",
                   "SUCCESSFUL LOGIN AFTER REPEATED FAILURES", "Suspicious IP addresses", "Hardening",
                   "Notes and limitations", attack_result.analysis_id, "Tester"):
        assert needed in text, needed


def test_pdf_without_alerts():
    data = generate_pdf_bytes(analyze(attempts("10.0.0.1", 2)))
    assert data.startswith(b"%PDF") and len(data) > 3000
