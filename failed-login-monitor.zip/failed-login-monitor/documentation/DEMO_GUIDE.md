# Demo Guide, Expected Output and Viva Preparation

## A. Start
```bash
cd failed-login-monitor
./setup.sh            # once
./run.sh              # http://localhost:8501   (sudo ./run.sh to read /var/log/auth.log)
```
Before presenting: **Alert & Scan History → Delete all history**, so the numbers start clean.

## B. Dashboard demonstration (about 10 minutes)
| # | Do | Say |
|---|---|---|
| 1 | **About Project** | "It's read-only: it never changes logs, never blocks IPs and uses no external services. Scores are indicators, not proof." |
| 2 | **Analyze Logs → Sample log → auth_normal.log → Analyze** | "A normal day: 2 failed attempts (a typo) followed by a login. **0 alerts**: the tool doesn't panic about ordinary mistakes." |
| 3 | **Sample log → auth_attack.log → Analyze** | 401 lines, 92 failed attempts, 5 alerts. "There are about 200 failure lines, but one guess can write three lines, so the parser counts 92 real attempts." |
| 4 | **SOC Dashboard** | Timeline spike at 10:20, top usernames (root, admin…), top IPs, alerts by severity. |
| 5 | **Security Alerts** → ALT-0001 | "192.168.1.100: 40 attempts in 6 minutes on 9 usernames including root. R1+R2+R3+R4 = 85, HIGH." |
| 6 | ALT-0002 | "Only 6 failures, but then a **successful** login for `deploy`. The score is 45, but it is **P1**, because the account may be compromised. Recommended: confirm with the user, check `last -i`, authorized_keys." |
| 7 | ALT-0003 | "One account, `admin`, attacked from 4 IPs. Each IP alone stays below the thresholds; together it's a distributed attack (R5)." |
| 8 | **Suspicious IPs** → 203.0.113.25 | "20 failed attempts, but one every 3 minutes, so it's **not flagged**. Repeated failures alone don't make an IP malicious." Show the IP classes (Private / Reserved…). |
| 9 | **Failed Logins** → filter IP 192.0.2.44 | "This server logs only 'Invalid user' lines here; they still count, because there's no 'Failed password' line for that connection." |
| 10 | **Detection Settings** → R1 threshold 3 → **Save and re-analyse** | More alerts appear: "Thresholds are configurable." Reset afterwards. |
| 11 | **Alert & Scan History** → set ALT-0002 to *Investigating*; analyse the same log again | "Re-analysing doesn't create duplicates: `times_seen` goes to 2." |
| 12 | **Reports → Download PDF** | Show the executive summary, timeline, alert details, suspicious IPs and recommendations. |
| 13 | Terminal: `./venv/bin/python -m pytest -q` | "134 automated tests." |

## C. Live monitoring demonstration (terminal)
```bash
cp samples/auth_normal.log /tmp/demo_auth.log
./venv/bin/python cli.py watch /tmp/demo_auth.log --interval 2
# second terminal - simulate an attack arriving in the log:
grep "192.168.1.100" samples/auth_attack.log >> /tmp/demo_auth.log
```
Expected: the watcher prints `ALERT … POSSIBLE SSH BRUTE-FORCE ATTACK  Source IP: 192.168.1.100`, and then only new
alerts on later changes.

## D. Optional: real log entries on your own machine
Only on a computer you own. This creates genuine sshd entries from 127.0.0.1:
```bash
sudo apt install -y openssh-server && sudo systemctl start ssh
for u in admin test oracle guest backup; do ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no $u@localhost; done
#   (type a wrong password at each prompt, then press Ctrl+C)
sudo ./run.sh   →  Analyze Logs → System log file → /var/log/auth.log    (or "systemd journal" if auth.log is missing)
```
Expected: an alert for **127.0.0.1 (Loopback)** with R1 and R3, if at least 5 attempts and 5 usernames fall within the
windows. Real counts depend on how many passwords you typed.

## E. Expected output (auth_attack.log, CLI)
```
Lines 401 · auth events 230 · failed attempts 92 · successful logins 11 · source IPs 12 · malformed 2
Alerts: 5 (HIGH 1, MEDIUM 3, LOW 1)
ALT-0001 [P1] POSSIBLE SSH BRUTE-FORCE ATTACK                      192.168.1.100   85 HIGH    R1 R2 R3 R4
ALT-0002 [P1] SUCCESSFUL LOGIN AFTER REPEATED FAILURES - INVESTIGATE 198.51.100.77 45 MEDIUM  R1 R6
ALT-0003 [P2] POSSIBLE DISTRIBUTED LOGIN ATTEMPTS                   multiple (4)    30 MEDIUM  R5
ALT-0004 [P2] POSSIBLE SSH BRUTE-FORCE ATTACK                      192.0.2.44      40 MEDIUM  R1 R3
ALT-0005 [P3] REPEATED ROOT LOGIN ATTEMPTS                          2001:db8:4::23  15 LOW     R4
```
(The full text is in `sample_output/cli_output_auth_attack.txt`.)

## F. The project for a beginner
1. **log_reader**: opens the log *only for reading*. If you're not allowed to read it, it tells you how to get
   access instead of crashing.
2. **log_parser**: reads each line with regular expressions and pulls out time, host, program, event type,
   username, IP and port. It understands both date styles and IPv6, and it counts one guess as one attempt.
3. **detection_engine**: slides a "time window" (for example 5 minutes) along each IP's attempts and checks the six
   rules. Overlapping windows from the same attack are merged so you get one result, not thirty.
4. **alert_manager / risk_scorer**: groups an IP's rule results into one incident, adds up the points (max 100),
   sets the severity and priority, and writes the explanation and advice.
5. **ip_analyzer**: builds the per-IP table and labels each address as private, public, loopback and so on.
6. **database / reports / dashboard / cli**: save, show and export everything.

## G. Viva questions and answers
**Q1. Where are authentication logs on Linux?** `/var/log/auth.log` on Debian/Ubuntu/Kali, `/var/log/secure` on
RHEL/CentOS/Fedora, and in the systemd journal (`journalctl`) on systems without rsyslog.

**Q2. Why can't you just count "Failed password" lines?** You can for password guesses, but invalid-user guesses also
write "Invalid user" and PAM "authentication failure" lines, and some servers write *only* "Invalid user". The tool
counts each guess once by looking at the SSH connection (host + process ID + IP).

**Q3. What is a brute-force attack, and how is it different from password spraying?** Brute force tries many passwords
quickly, usually against a few accounts from one source. Spraying tries a few common passwords against many accounts,
often from many sources. R1/R2 target the first; R3 and R5 help with the second (MITRE ATT&CK T1110.001 / .003).

**Q4. Why is "success after failures" P1 even though its score can be low?** The score measures how intense the attack
was; the priority reflects impact. A successful login after guessing may mean the password was found, so it must be
checked first.

**Q5. How do you avoid duplicate alerts?** In three ways: windows are merged into bursts; one IP's hits are merged into
one incident; and stored alerts have a fingerprint, so re-analysis updates them.

**Q6. Why not block the IP automatically?** Automatic blocking can lock out legitimate users (shared NAT, an employee who
forgot a password), and attackers can rotate IPs. The brief required no blocking: the tool recommends, an administrator decides.

**Q7. Why is 203.0.113.9 shown as "Reserved"?** It belongs to a documentation range (RFC 5737) reserved for examples.
All sample data uses such ranges, so no real organisation is accused.

**Q8. How does the sliding window work?** Two pointers move over the time-sorted attempts. The right pointer adds an
attempt; the left pointer drops attempts older than the window. The count between them is compared with the threshold.
Each attempt enters and leaves once, so the cost is linear.

**Q9. Why are syslog timestamps a problem?** The classic format has no year, so the tool assumes the current (or a
configured) year and handles December → January inside a file. ISO 8601 logs include the year and time zone.

**Q10. How do you handle permission errors?** Uploads need no root. For system logs the tool explains sudo, the `adm`
group, or uploading a copy. It's tested with a real unprivileged process.

**Q11. What would you add next?** Reputation/geolocation lookups (opt-in), notifications, per-user baselines,
multi-host correlation, and other services' logs.

**Q12. Limitations?** Slow or widely distributed attacks can stay under the thresholds; detection depends on the log
contents; scores are not statistically calibrated.
