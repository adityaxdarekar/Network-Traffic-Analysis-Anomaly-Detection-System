"""Suspicious IPs page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import badge, donut, e, kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("Suspicious IPs", "Source IP addresses and why they were flagged")
    r = require_result()
    ips = r.ips
    if ips.empty:
        st.info("No source IP addresses in this log.")
        return
    flagged = ips[ips["status"] == "Flagged for review"]
    kpi_row([("Source IPs", len(ips)), ("Flagged for review", len(flagged), "", "alert" if len(flagged) else "accent"),
             ("High risk", int((ips["risk_level"] == "HIGH").sum())),
             ("Public IPs", int((ips["ip_class"] == "Public").sum()))])
    st.markdown("<div class='disclaimer'>An IP is <b>flagged for review</b> when a detection rule fired - that does "
                "not prove it is malicious (shared NAT, VPN, a user who forgot a password, a monitoring system). "
                "Nothing is blocked automatically and no external reputation service is queried.</div>",
                unsafe_allow_html=True)
    c1, c2 = st.columns([2, 1])
    with c1:
        only = st.radio("Show", ["Flagged only", "All IPs"], horizontal=True, key="ip_only")
        view = flagged if only == "Flagged only" else ips
        show_table(view, height=380, empty_msg="No IP was flagged.")
    with c2:
        vc = ips["ip_class"].value_counts()
        donut(vc.index, vc.values, "IP classification")
    st.caption("Private = 10/8, 172.16/12, 192.168/16, fc00::/7 · Reserved = documentation/test, CGNAT and other "
               "non-global ranges · Loopback = 127.0.0.0/8, ::1 (Python ipaddress module).")

    st.subheader("IP details")
    pick = st.selectbox("IP address", list(ips["ip"]), key="ip_pick")
    row = ips[ips["ip"] == pick].iloc[0]
    st.markdown(f"{badge(row['risk_level'], f'{row.risk_level} {row.risk_score}')} &nbsp; <b>{e(pick)}</b> · "
                f"{e(row['ip_class'])} · {e(row['status'])}<br><span class='muted'>{e(row['reason'])}</span>",
                unsafe_allow_html=True)
    ev = r.events[r.events["ip"] == pick]
    show_table(pd.DataFrame({
        "Failed attempts": [row["failed_attempts"]], "Usernames": [row["usernames"] or "-"],
        "Successful logins": [row["successful_logins"]], "Accepted users": [row["accepted_users"] or "-"],
        "First seen": [row["first_seen"]], "Last seen": [row["last_seen"]]}))
    show_table(ev[["timestamp", "event_type", "username", "port", "counts_as_attempt"]], height=300)
    related = [a for a in r.alerts if pick in a.source_ips]
    if related:
        st.markdown("**Alerts involving this IP:** " + ", ".join(f"{a.alert_id} ({a.severity})" for a in related))
