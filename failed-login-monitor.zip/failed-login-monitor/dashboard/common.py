"""Shared dashboard helpers. Log-derived text is HTML-escaped before it is shown with unsafe_allow_html."""

from __future__ import annotations

import html

import pandas as pd
import plotly.express as px
import streamlit as st

import config as C
from database.db_manager import DatabaseError, DatabaseManager

PANEL, BORDER, TEXT, MUTED = "#0f2038", "#1e3a5f", "#e2e8f0", "#8ba3c7"
CHART_COLORS = ["#3b82f6", "#22d3ee", "#818cf8", "#2dd4bf", "#38bdf8", "#a78bfa", "#facc15", "#94a3b8"]


def e(text) -> str:
    return html.escape("" if text is None else str(text))


def css() -> str:
    try:
        return "<style>" + C.STYLE_FILE.read_text(encoding="utf-8") + "</style>"
    except OSError:
        return ""


def plotly_layout(fig, title: str | None = None, height: int = 320):
    fig.update_layout(template="plotly_dark", paper_bgcolor=PANEL, plot_bgcolor=PANEL, height=height,
                      font=dict(color=TEXT, size=12), colorway=CHART_COLORS,
                      margin=dict(l=10, r=10, t=45 if title else 15, b=10),
                      title=dict(text=title, font=dict(size=14, color=TEXT), x=0.01) if title else None,
                      legend=dict(bgcolor="rgba(0,0,0,0)"))
    fig.update_xaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    fig.update_yaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    return fig


def get_settings() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = C.load_settings()
    return st.session_state["settings"]


def get_result():
    return st.session_state.get("result")


def require_result():
    r = get_result()
    if r is None:
        st.info("No log analysed yet. Open **Analyze Logs** and load a sample log, upload a file or read the "
                "system log.")
        st.stop()
    return r


@st.cache_resource
def get_db() -> DatabaseManager | None:
    try:
        return DatabaseManager()
    except DatabaseError:
        return None


def db_or_warn() -> DatabaseManager | None:
    db = get_db()
    if db is None:
        st.error("The history database could not be opened. Check that the 'output' folder is writable.")
    return db


def go_to(page: str) -> None:
    st.session_state["nav_target"] = page
    st.rerun()


def page_header(title: str, subtitle: str = "") -> None:
    r = get_result()
    pill = f"<span class='soc-pill'>{e(r.source)}</span>" if r is not None else \
        "<span class='soc-pill'>read-only · nothing is blocked</span>"
    st.markdown(f"<div class='soc-header'><div><div class='title'>{e(title)}</div>"
                f"<div class='subtitle'>{e(subtitle)}</div></div>{pill}</div>", unsafe_allow_html=True)


def kpi_row(items: list[tuple]) -> None:
    cols = st.columns(len(items))
    for col, item in zip(cols, items):
        label, value = item[0], item[1]
        sub = item[2] if len(item) > 2 else ""
        style = item[3] if len(item) > 3 else "accent"
        col.markdown(f"<div class='kpi {style}'><div class='label'>{e(label)}</div><div class='value'>{e(value)}</div>"
                     f"<div class='sub'>{e(sub)}</div></div>", unsafe_allow_html=True)


def badge(level: str, text: str | None = None) -> str:
    return f"<span class='sev sev-{e(level)}'>{e(text or level)}</span>"


def show_table(df: pd.DataFrame, height: int | None = None, empty_msg: str = "Nothing to show.") -> None:
    if df is None or df.empty:
        st.caption(empty_msg)
        return
    kw = {"hide_index": True, "width": "stretch"}
    if height:
        kw["height"] = height
    st.dataframe(df, **kw)


def bar(df: pd.DataFrame, x: str, y: str, title: str, color: str = "#3b82f6", horizontal: bool = False, height=320):
    if df is None or df.empty:
        st.markdown(f"<div class='panel'><b>{e(title)}</b><br><span class='muted'>No data.</span></div>",
                    unsafe_allow_html=True)
        return
    fig = px.bar(df, x=y if horizontal else x, y=x if horizontal else y, orientation="h" if horizontal else "v")
    fig.update_traces(marker_color=color)
    if horizontal:
        fig.update_yaxes(autorange="reversed")
    st.plotly_chart(plotly_layout(fig, title, height), width="stretch")


def donut(labels, values, title: str, colors: dict | None = None):
    if not sum(values):
        st.markdown(f"<div class='panel'><b>{e(title)}</b><br><span class='muted'>No data.</span></div>",
                    unsafe_allow_html=True)
        return
    fig = px.pie(names=list(labels), values=list(values), hole=0.55, color=list(labels),
                 color_discrete_map=colors or {})
    st.plotly_chart(plotly_layout(fig, title), width="stretch")


def timeline_chart(r, title: str = "Failed vs successful logins over time"):
    tl = r.timeline()
    if tl.empty:
        st.caption("No timestamped events.")
        return
    long = tl.melt(id_vars="time", value_vars=["failed", "successful"], var_name="type", value_name="events")
    fig = px.bar(long, x="time", y="events", color="type",
                 color_discrete_map={"failed": "#ef4444", "successful": "#22c55e"})
    st.plotly_chart(plotly_layout(fig, title), width="stretch")


def download(label: str, data, filename: str, mime: str, key: str, primary: bool = False) -> None:
    st.download_button(label, data=data, file_name=filename, mime=mime, key=key,
                       type="primary" if primary else "secondary", width="stretch")
