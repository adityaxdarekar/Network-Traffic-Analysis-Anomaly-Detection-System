"""Security Alerts page: alerts of the current analysis, with full explanation and response."""

from __future__ import annotations

import streamlit as st

import config as C
from dashboard.common import badge, e, kpi_row, page_header, require_result


def render() -> None:
    page_header("Security Alerts", "Generated from the detection rules - one alert per incident")
    r = require_result()
    sev = r.severity_counts
    kpi_row([("Alerts", len(r.alerts)), ("P1 - investigate first", sum(a.priority == "P1" for a in r.alerts), "",
                                         "alert" if any(a.priority == "P1" for a in r.alerts) else "accent"),
             ("High", sev["HIGH"]), ("Medium", sev["MEDIUM"]), ("Low", sev["LOW"])])
    st.markdown(f"<div class='disclaimer'>{e(r.disclaimer)}</div>", unsafe_allow_html=True)
    if not r.alerts:
        st.success("No alerts: no activity exceeded the configured thresholds (Detection Settings).")
        return
    c1, c2 = st.columns(2)
    sev_f = c1.multiselect("Severity", ["HIGH", "MEDIUM", "LOW"], key="al_sev")
    pri_f = c2.multiselect("Priority", ["P1", "P2", "P3"], key="al_pri")
    shown = [a for a in r.alerts if (not sev_f or a.severity in sev_f) and (not pri_f or a.priority in pri_f)]
    for a in sorted(shown, key=lambda a: (a.priority, -a.risk_score)):
        with st.expander(f"{a.priority} · {a.alert_id} · {a.severity} {a.risk_score}/100 · {a.title} · {a.source_ip}",
                         expanded=a.priority == "P1"):
            st.markdown(f"<div class='finding'><span class='pts'>{e(a.risk_score)}/100</span>"
                        f"<b>ALERT: {e(a.title)}</b> {badge(a.severity)}<br>"
                        f"<b>Source IP:</b> {e(a.source_ip)}"
                        + (f" ({e(', '.join(a.source_ips))})" if len(a.source_ips) > 1 else "")
                        + f" · {e(a.ip_class)}<br><b>Target usernames:</b> {e(', '.join(a.target_usernames))}<br>"
                        f"<b>Failed attempts:</b> {a.failed_count} · <b>Successful logins:</b> {a.success_count}<br>"
                        f"<b>Time window:</b> {e(a.first_seen)} → {e(a.last_seen)} ({a.window_minutes} min)<br>"
                        f"<b>Risk score:</b> {a.risk_score}/100 · <b>Severity:</b> {e(a.severity)} · "
                        f"<b>Priority:</b> {e(a.priority)}</div>", unsafe_allow_html=True)
            st.markdown("**Rules triggered**")
            for x in a.rules:
                st.markdown(f"- **{e(x['rule'])} {e(x['name'])}** (+{x['points']}): {e(x['detail'])}")
            st.markdown(f"**Explanation:** {e(a.explanation)}")
            st.markdown("**Recommended response**")
            for x in a.recommended_response:
                st.markdown(f"- {e(x)}")
    st.caption("Priority P1 = HIGH severity, or any successful login after repeated failures (R6), whatever its "
               f"score. Thresholds: MEDIUM ≥ {r.settings['risk_thresholds']['MEDIUM']}, HIGH ≥ "
               f"{r.settings['risk_thresholds']['HIGH']}. Rule names: " + ", ".join(f"{k} {v}" for k, v in
                                                                                   C.RULE_NAMES.items()))
