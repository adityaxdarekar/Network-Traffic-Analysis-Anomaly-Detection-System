"""Reports page: PDF, CSV, JSON and ZIP downloads for the current analysis."""

from __future__ import annotations

import streamlit as st

from dashboard.common import download, page_header, require_result
from reports.export_manager import alerts_csv, events_csv, ips_csv, stamp_name, to_json, zip_bundle
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report


def render() -> None:
    page_header("Reports", "Downloadable security reports")
    r = require_result()
    st.subheader("📄 PDF security report")
    analyst = st.text_input("Prepared by (optional)", key="rep_analyst")
    c1, c2 = st.columns(2)
    with c1:
        download("⬇ Download PDF report", generate_pdf_bytes(r, analyst), stamp_name("security_report", r.source, "pdf"),
                 "application/pdf", "rep_pdf", primary=True)
    with c2:
        if st.button("💾 Save PDF to output/reports", key="rep_save", width="stretch"):
            st.success(f"Saved to {generate_pdf_report(r, analyst=analyst)}")
    st.caption("Contents: executive summary, log source and parsing statistics, detection rules and thresholds, "
               "activity timeline, alerts with rules, explanation and recommended response, suspicious IPs, "
               "hardening recommendations and limitations.")
    st.subheader("⬇ Data exports")
    c1, c2, c3 = st.columns(3)
    with c1:
        download("Alerts (CSV)", alerts_csv(r).encode(), stamp_name("alerts", r.source, "csv"), "text/csv", "rep_a")
        download("IP summary (CSV)", ips_csv(r).encode(), stamp_name("ip_summary", r.source, "csv"), "text/csv",
                 "rep_i")
    with c2:
        download("Parsed events (CSV)", events_csv(r).encode(), stamp_name("events", r.source, "csv"), "text/csv",
                 "rep_e")
        download("Analysis (JSON)", to_json(r).encode(), stamp_name("analysis", r.source, "json"),
                 "application/json", "rep_j")
    with c3:
        download("Everything (ZIP)", zip_bundle(r), stamp_name("bundle", r.source, "zip"), "application/zip", "rep_z")
    st.caption("Exports contain parsed fields (time, host, user, IP, event type) - not the raw log lines.")
