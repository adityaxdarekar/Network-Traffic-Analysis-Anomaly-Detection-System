"""Detection Settings page: every threshold, time window and score is configurable."""

from __future__ import annotations

import streamlit as st

import config as C
from dashboard import common
from dashboard.common import get_settings, page_header
from monitor.analyzer import analyze_log

LABELS = {"R1": "failed attempts", "R2": "failed attempts", "R3": "different usernames", "R4": "root attempts",
          "R5": "different IPs", "R6": "failures before success"}


def render() -> None:
    page_header("Detection Settings", "Thresholds, time windows and risk points")
    s = get_settings()
    new = C.default_settings()
    for rid, name in C.RULE_NAMES.items():
        cfg = s["rules"][rid]
        st.markdown(f"**{rid} · {name}**")
        c1, c2, c3, c4 = st.columns([1, 1, 1, 1])
        new["rules"][rid]["enabled"] = c1.checkbox("Enabled", value=bool(cfg["enabled"]), key=f"set_{rid}_on")
        new["rules"][rid]["threshold"] = int(c2.number_input(f"Threshold ({LABELS[rid]})", 1, 1000,
                                                             int(cfg["threshold"]), key=f"set_{rid}_t"))
        new["rules"][rid]["window_minutes"] = float(c3.number_input("Time window (minutes)", 0.5, 1440.0,
                                                                    float(cfg["window_minutes"]), step=0.5,
                                                                    key=f"set_{rid}_w"))
        new["rules"][rid]["points"] = int(c4.number_input("Risk points", 0, 100, int(cfg["points"]),
                                                          key=f"set_{rid}_p"))
        if rid == "R5":
            new["rules"][rid]["min_attempts_per_ip"] = int(st.number_input(
                "R5: minimum failed attempts per IP", 1, 100, int(cfg.get("min_attempts_per_ip", 2)), key="set_R5_m"))
    st.markdown("**Risk classification**")
    c1, c2, c3 = st.columns(3)
    new["risk_thresholds"]["MEDIUM"] = int(c1.number_input("MEDIUM from score", 1, 99,
                                                           int(s["risk_thresholds"]["MEDIUM"]), key="set_med"))
    new["risk_thresholds"]["HIGH"] = int(c2.number_input("HIGH from score", 2, 100, int(s["risk_thresholds"]["HIGH"]),
                                                         key="set_high"))
    new["incident_gap_minutes"] = float(c3.number_input("Merge rule hits of one IP closer than (minutes)", 0.0, 1440.0,
                                                        float(s["incident_gap_minutes"]), key="set_gap"))
    c1, c2 = st.columns(2)
    year = c1.number_input("Year for syslog timestamps without a year (0 = current year)", 0, 2100,
                           int(s["assume_year"] or 0), key="set_year")
    new["assume_year"] = int(year) or None
    new["store_raw_events"] = c2.checkbox("Store raw log lines in history (off = privacy default)",
                                          value=bool(s["store_raw_events"]), key="set_raw")

    problems = C.validate_settings(new)
    for p in problems:
        st.error(p)
    b1, b2, b3 = st.columns(3)
    if b1.button("💾 Save settings", type="primary", key="set_save", disabled=bool(problems)):
        st.session_state["settings"] = new
        try:
            C.save_settings(new)
            st.success("Settings saved.")
        except OSError:
            st.warning("Settings apply to this session only (user_settings.json could not be written).")
    if b2.button("🔁 Save and re-analyse current log", key="set_rerun", disabled=bool(problems)
                 or "log_text" not in st.session_state):
        st.session_state["settings"] = new
        st.session_state["result"] = analyze_log(st.session_state["log_text"], new)
        db = common.get_db()
        if db is not None:
            db.save_analysis(st.session_state["result"], store_raw=bool(new["store_raw_events"]))
        st.success(f"Re-analysed: {len(st.session_state['result'].alerts)} alert(s) with the new settings.")
    if b3.button("↺ Reset to defaults", key="set_reset"):
        st.session_state["settings"] = C.default_settings()
        for k in [k for k in st.session_state if k.startswith("set_")]:
            del st.session_state[k]
        st.rerun()
