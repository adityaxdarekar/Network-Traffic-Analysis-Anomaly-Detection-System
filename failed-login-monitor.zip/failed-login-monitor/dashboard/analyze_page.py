"""Analyze Logs page: sample logs, uploads, system log files and the systemd journal."""

from __future__ import annotations

import logging

import pandas as pd
import streamlit as st

import config as C
from dashboard import common
from dashboard.common import get_settings, go_to, kpi_row, page_header, show_table
from monitor.analyzer import analyze_log
from monitor.log_reader import (LogReadError, LogText, available_system_logs, journal_available, read_journal,
                                read_log_file, read_upload)

log = logging.getLogger(__name__)
SOURCES = ["Sample log", "Upload a log file", "System log file", "systemd journal"]
SAMPLES = {
    "auth_attack.log - Ubuntu/Debian with 6 attack scenarios": "auth_attack.log",
    "auth_normal.log - normal day, no attack": "auth_normal.log",
    "secure_rhel.log - CentOS/RHEL /var/log/secure": "secure_rhel.log",
    "auth_iso8601.log - Ubuntu 24.04 ISO timestamps": "auth_iso8601.log",
}


def run(read_fn) -> None:
    """Read + analyse + save. Friendly messages only, never a stack trace."""
    try:
        text: LogText = read_fn()
    except LogReadError as exc:
        st.error(str(exc))
        return
    try:
        result = analyze_log(text, get_settings())
    except Exception:  # noqa: BLE001
        log.exception("analysis failed")
        st.error("The log could not be analysed. Check that it is a Linux authentication log.")
        return
    st.session_state["result"] = result
    st.session_state["log_text"] = text
    db = common.get_db()
    if db is not None:
        try:
            st.session_state["save_info"] = db.save_analysis(result, store_raw=bool(get_settings()["store_raw_events"]))
        except Exception:  # noqa: BLE001
            st.warning("The analysis could not be saved to history.")


def render() -> None:
    page_header("Analyze Logs", "Read authentication logs safely - the log is only read, never modified")
    source = st.radio("Log source", SOURCES, horizontal=True, key="src")
    if source == SOURCES[0]:
        pick = st.selectbox("Sample log", list(SAMPLES), key="sample_pick")
        st.caption("Fictional logs with private and documentation-only IP addresses (see samples/generate_samples.py).")
        if st.button("▶ Analyze sample", type="primary", key="go_sample"):
            run(lambda: read_log_file(C.SAMPLES_DIR / SAMPLES[pick]))
    elif source == SOURCES[1]:
        up = st.file_uploader("Upload an auth.log / secure file (.log or .txt, max 50 MB)", type=["log", "txt"],
                              key="upload")
        st.caption("Uploaded files are analysed in memory - no root privileges needed. Tip: copy your log first, "
                   "e.g. `sudo cp /var/log/auth.log ~/auth_copy.log && sudo chown $USER ~/auth_copy.log`.")
        if st.button("▶ Analyze file", type="primary", key="go_upload", disabled=up is None):
            run(lambda: read_upload(up.name, up.getvalue()))
    elif source == SOURCES[2]:
        status = available_system_logs()
        show_table(pd.DataFrame([{"Log": k, "Exists": "yes" if v["exists"] else "no",
                                  "Readable by this program": "yes" if v["readable"] else "no"}
                                 for k, v in status.items()]))
        options = list(C.SYSTEM_LOGS)
        pick = st.selectbox("System log", options, key="sys_pick")
        custom = st.text_input("…or another file path (e.g. a rotated /var/log/auth.log.1 or .gz)", key="sys_custom")
        st.caption("System logs need root or membership of the 'adm' group to read. The newest 50 MB are read.")
        if st.button("▶ Read system log", type="primary", key="go_sys"):
            run(lambda: read_log_file(custom.strip() or C.SYSTEM_LOGS[pick]))
    else:
        st.caption("For systems without /var/log/auth.log (rsyslog not installed). Runs a fixed, read-only "
                   "command: `" + " ".join(C.JOURNAL_COMMAND) + "`")
        if st.button("▶ Read journal", type="primary", key="go_journal", disabled=not journal_available()):
            run(read_journal)
        if not journal_available():
            st.caption("journalctl is not available on this system.")

    r = st.session_state.get("result")
    if r is None:
        return
    st.divider()
    s, sev = r.stats, r.severity_counts
    st.markdown(f"**Analysed:** `{common.e(r.source)}` at {r.analyzed_at}"
                + (" - only the newest part of a large file was read" if r.truncated else ""))
    kpi_row([("Lines", f"{s['total_lines']:,}"), ("Auth events", f"{s['events']:,}"),
             ("Failed attempts", f"{s['failed_attempts']:,}", "", "alert" if s["failed_attempts"] else "accent"),
             ("Successful logins", f"{s['successful_logins']:,}"),
             ("Alerts", len(r.alerts), f"{sev['HIGH']} high · {sev['MEDIUM']} medium · {sev['LOW']} low",
              "alert" if r.alerts else "accent")])
    info = st.session_state.get("save_info")
    if info:
        st.caption(f"Saved to history: {info['new_alerts']} new alert(s), {info['updated_alerts']} already known "
                   "alert(s) updated (no duplicates).")
    if s["malformed_lines"] or s["bad_timestamps"]:
        with st.expander(f"⚠ {s['malformed_lines']} malformed line(s) skipped, {s['bad_timestamps']} event(s) "
                         "without a valid timestamp"):
            show_table(pd.DataFrame(r.parse.malformed_samples))
    if s["events"] == 0:
        st.warning("No authentication events were found. Is this an auth.log / secure file?")
    c1, c2 = st.columns(2)
    if c1.button("🛡 View security alerts", key="to_alerts", width="stretch"):
        go_to("Security Alerts")
    if c2.button("📊 Open the SOC dashboard", key="to_dash", width="stretch"):
        go_to("SOC Dashboard")
