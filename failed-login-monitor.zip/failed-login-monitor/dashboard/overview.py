"""SOC Dashboard page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

import config as C
from dashboard.common import bar, donut, kpi_row, page_header, require_result, show_table, timeline_chart


def render() -> None:
    page_header("SOC Dashboard", "Failed login activity and brute-force indicators")
    r = require_result()
    s, sev = r.stats, r.severity_counts
    flagged = int((r.ips["status"] == "Flagged for review").sum()) if not r.ips.empty else 0
    p1 = sum(a.priority == "P1" for a in r.alerts)
    kpi_row([("Failed attempts", f"{s['failed_attempts']:,}", f"{s['invalid_user_attempts']} invalid users",
              "alert" if s["failed_attempts"] else "accent"),
             ("Successful logins", f"{s['successful_logins']:,}"),
             ("Source IPs", s["unique_ips"], f"{flagged} flagged for review", "alert" if flagged else "accent"),
             ("Usernames targeted", s["usernames_targeted"], f"root: {s['root_attempts']} attempts")])
    kpi_row([("Alerts", len(r.alerts)), ("High", sev["HIGH"], "", "alert" if sev["HIGH"] else "accent"),
             ("Medium", sev["MEDIUM"]), ("P1 - investigate first", p1, "", "alert" if p1 else "accent")])
    st.caption(f"Log period {s['first_event']} → {s['last_event']} · hosts: {', '.join(s['hosts']) or '-'} · "
               f"{s['malformed_lines']} malformed line(s) skipped")
    timeline_chart(r)
    c1, c2 = st.columns(2)
    with c1:
        bar(r.top_usernames(10), "username", "failed_attempts", "Most targeted usernames", "#f59e0b",
            horizontal=True)
    with c2:
        ips = r.ips[r.ips["failed_attempts"] > 0].head(10) if not r.ips.empty else r.ips
        bar(ips[["ip", "failed_attempts"]] if not ips.empty else ips, "ip", "failed_attempts",
            "Top source IPs by failed attempts", "#ef4444", horizontal=True)
    c3, c4 = st.columns(2)
    with c3:
        et = r.event_types()
        donut(et["event_type"], et["events"], "Authentication event types")
    with c4:
        donut([C.RISK_LABELS[k] for k in sev], list(sev.values()), "Alerts by severity",
              {C.RISK_LABELS[k]: C.RISK_COLORS[k] for k in sev})
    st.subheader("Latest alerts")
    show_table(r.alerts_frame().drop(columns=["window_minutes"]) if r.alerts else pd.DataFrame(),
               empty_msg="No alerts - no activity exceeded the detection thresholds.")
