"""Failed Logins page: every parsed authentication event, filterable."""

from __future__ import annotations

import streamlit as st

from dashboard.common import kpi_row, page_header, require_result, show_table
from monitor.log_parser import EVENT_LABELS

COLS = ["line_no", "timestamp", "hostname", "service", "event_type", "username", "ip", "port", "invalid_user",
        "counts_as_attempt"]


def render() -> None:
    page_header("Failed Logins", "Parsed authentication events - failed and successful")
    r = require_result()
    df = r.events
    kpi_row([("Failed events (lines)", int(df["failed"].sum())),
             ("Counted attempts", int(df["counts_as_attempt"].sum()), "one per password guess"),
             ("Successful logins", int(df["success"].sum())),
             ("Local failures (no IP)", r.stats["local_failures"], "e.g. sudo / su")])
    st.caption("A single guess can write 'Invalid user', a PAM 'authentication failure' and 'Failed password' lines. "
               "All are listed, but only one is counted as an attempt (column counts_as_attempt).")
    c1, c2, c3, c4 = st.columns(4)
    show = c1.radio("Show", ["Failed only", "Successful only", "All"], key="ev_show")
    types = c2.multiselect("Event type", sorted(df["event_type"].unique()), key="ev_types",
                           format_func=lambda t: EVENT_LABELS.get(t, t))
    user = c3.text_input("Username contains", key="ev_user")
    ip = c4.text_input("IP contains", key="ev_ip")
    view = df
    if show == "Failed only":
        view = view[view["failed"]]
    elif show == "Successful only":
        view = view[view["success"]]
    if types:
        view = view[view["event_type"].isin(types)]
    if user:
        view = view[view["username"].str.contains(user, case=False, regex=False)]
    if ip:
        view = view[view["ip"].str.contains(ip, case=False, regex=False)]
    st.markdown(f"**{len(view):,}** of {len(df):,} events")
    show_table(view[COLS].head(5000), height=480, empty_msg="No events match.")
    if st.checkbox("Show the raw log line for the selected events", key="ev_raw"):
        st.text("\n".join(view["raw"].head(200)))
