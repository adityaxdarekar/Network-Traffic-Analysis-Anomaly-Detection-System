"""About Project page."""

from __future__ import annotations

import streamlit as st

import config as C
from dashboard.common import page_header

ARCH = """
 auth.log / secure / journal / upload
            │  read-only (log_reader)
            ▼
 log_parser ── syslog + ISO-8601 · 6 event types · IPv4/IPv6 · one attempt per guess
            ▼
 detection_engine ── R1 repeated · R2 high-volume · R3 usernames · R4 root · R5 distributed · R6 success-after-fail
            ▼
 alert_manager + risk_scorer ── incidents per IP, points per rule, cap 100, LOW/MEDIUM/HIGH, P1-P3
            ▼
 ip_analyzer ── per-IP table (private/public/loopback/reserved/invalid), statistics, timeline
            ▼
 Streamlit dashboard · SQLite history (alerts upserted, status tracking) · PDF / CSV / JSON reports
"""


def render() -> None:
    page_header("About Project", f"{C.APP_TITLE} · v{C.APP_VERSION}")
    st.markdown("A Python tool that reads Linux authentication logs, finds failed login attempts, detects brute-force "
                "patterns with configurable rules, scores the risk, explains every alert and produces reports - the "
                "core of what a SOC analyst does when reviewing SSH activity.")
    st.code(ARCH, language=None)
    st.warning("Risk scores are heuristic indicators, not validated probabilities. A flagged IP is not proven "
               "malicious. The tool never blocks IPs, never changes system configuration and never modifies logs.")
    st.markdown("""
**Security and privacy**
- Logs are opened read-only; uploaded files are analysed in memory (no root needed)
- The journal is read with a fixed `journalctl` command (no shell, no user input)
- No external services or IP-reputation APIs; everything stays on this computer
- Raw log lines are not stored in history unless enabled in Detection Settings
- The dashboard listens on 127.0.0.1 only

**Technology:** Python · regular expressions · pandas · ipaddress · Streamlit · Plotly · SQLite · ReportLab ·
matplotlib · pytest
""")
