"""Alert & Scan History page: all stored alerts (with status tracking) and previous analyses."""

from __future__ import annotations

import streamlit as st

from dashboard.common import db_or_warn, download, kpi_row, page_header, show_table
from database.db_manager import ALERT_STATUSES


def render() -> None:
    page_header("Alert & Scan History", "Stored locally in SQLite - re-analysing a log never duplicates alerts")
    db = db_or_warn()
    if db is None:
        return
    st_ = db.stats()
    kpi_row([("Analyses", st_["analyses"]), ("Alerts stored", st_["alerts"]),
             ("Open / investigating", st_["open_alerts"], "", "alert" if st_["open_alerts"] else "accent"),
             ("High", st_["HIGH"])])
    t1, t2 = st.tabs(["Alerts", "Analyses"])
    with t1:
        c1, c2, c3 = st.columns(3)
        sev = c1.selectbox("Severity", ["All", "HIGH", "MEDIUM", "LOW"], key="h_sev")
        status = c2.selectbox("Status", ["All"] + ALERT_STATUSES, key="h_status")
        ip = c3.text_input("Source IP contains", key="h_ip")
        alerts = db.list_alerts(None if sev == "All" else sev, None if status == "All" else status, ip.strip())
        show_table(alerts.drop(columns=["fingerprint"]) if not alerts.empty else alerts, height=320,
                   empty_msg="No stored alerts.")
        if not alerts.empty:
            download("⬇ Export alerts (CSV)", db.export_alerts_csv().encode(), "alert_history.csv", "text/csv",
                     "h_csv")
            labels = {x.fingerprint: f"{x.alert_id} · {x.severity} · {x.title} · {x.source_ip} · {x.status}"
                      for x in alerts.itertuples()}
            fp = st.selectbox("Alert", list(labels), format_func=labels.get, key="h_pick")
            rec = db.get_alert(fp)
            st.markdown(f"**{rec['title']}** · first detected {rec['first_detected']} · seen in "
                        f"{rec['times_seen']} analysis(es)")
            st.caption(rec["explanation"])
            new = st.selectbox("Investigation status", ALERT_STATUSES, index=ALERT_STATUSES.index(rec["status"]),
                               key="h_new_status")
            if st.button("Update status", key="h_update"):
                db.set_alert_status(fp, new)
                st.success(f"Status set to {new}.")
                st.rerun()
    with t2:
        analyses = db.list_analyses()
        show_table(analyses, height=280, empty_msg="No analyses stored yet.")
        if not analyses.empty:
            labels = {x.analysis_id: f"{x.analyzed_at} · {x.source} · {x.alerts} alerts"
                      for x in analyses.itertuples()}
            aid = st.selectbox("Analysis", list(labels), format_func=labels.get, key="h_an")
            rec = db.get_analysis(aid)
            st.markdown("**Alerts**")
            show_table(rec["alerts"].drop(columns=["fingerprint"]) if not rec["alerts"].empty else rec["alerts"],
                       empty_msg="No alerts in this analysis.")
            st.markdown("**Source IPs**")
            show_table(rec["ips"].drop(columns=["analysis_id"]) if not rec["ips"].empty else rec["ips"])
            if st.button("🗑 Delete this analysis", key="h_del"):
                db.delete_analysis(aid)
                st.rerun()
        with st.expander("Delete all history"):
            sure = st.checkbox("Yes, delete all stored analyses and alerts", key="h_sure")
            if st.button("Delete everything", key="h_clear", disabled=not sure):
                db.clear()
                st.rerun()
