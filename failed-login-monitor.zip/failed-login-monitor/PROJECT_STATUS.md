# Project Status

**Code status: complete.** Everything in the project brief is implemented. A few checks must be done on your own
Linux machine.

## Note about the brief
The supplied brief ends in section 8 (the alert example stops at "Risk score:"). Sections 1–8 are implemented as
written. For the missing parts, the same deliverables as in the previous project briefs were assumed:
- a Streamlit dashboard (9 pages), SQLite history and PDF/CSV reports
- sample logs, automated tests, README and a college project report

Further decisions:

| Topic | Decision |
|---|---|
| Points for R5 (distributed) | not given in the brief; set to 30, configurable |
| Alert priority | P1 for HIGH, *or* any success after failures (R6), so a possible compromise is always investigated first |
| Merging into one alert | rule hits of one IP less than 15 minutes apart (configurable) form one alert |
| Live monitoring | added as `cli.py watch` |
| Systems without auth.log | added a read-only systemd journal option |

If the rest of the brief asks for something different, these are easy to change.

## Verified in the development environment (Ubuntu 24.04, Python 3.13)
- [x] `pytest`: **134 passed** as root; **133 passed, 1 skipped** as a normal user; compiles on Python 3.11/3.12/3.13
- [x] All 4 sample logs produce exactly the documented detections (see README §16)
- [x] CLI analyze / exports / missing file / watch (live re-reading of a growing log, only new alerts printed)
- [x] PDF report rendered and checked visually; real outputs in `sample_output/`
- [x] All 9 dashboard pages executed headlessly with a Streamlit stand-in, including the workflows
- [x] Real system: this sandbox had **no** `/var/log/auth.log`, `/var/log/secure` or journal entries. The
      "not present" and "empty journal" messages were verified on it; permission denied was verified with a real
      unprivileged process
- [x] Stress test: 200,000-line synthetic log in 16 s

## To do on your computer
- [ ] **Open the dashboard in a browser** (`./setup.sh`, then `./run.sh`). Streamlit/Plotly could not be installed
      here, so the page code ran but the visual layout was not seen.
- [ ] **Read a real log**: `sudo ./run.sh` → Analyze Logs → System log file. If auth.log is missing, use the systemd
      journal option. To create entries safely on your own machine, see `documentation/DEMO_GUIDE.md` §D.
- [ ] **Take dashboard screenshots**: see `screenshots/README.md`.
- [ ] Optional: `./venv/bin/python -m pytest -v` (expect 133 passed + 1 skipped without sudo).
