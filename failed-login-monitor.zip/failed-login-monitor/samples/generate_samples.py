"""
Generate the sample authentication logs (deterministic, fictional).

    python samples/generate_samples.py

IP addresses come from private ranges (192.168.x.x, 10.x.x.x) and the reserved documentation ranges
192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24 and 2001:db8::/32 - they belong to nobody, so no real
person or organisation is ever shown as an attacker.

Files and the scenarios they contain (expected results are checked by tests/test_samples.py):

auth_normal.log      Ubuntu/Debian syslog format - one normal day: key logins, cron, sudo, one mistyped
                     password followed by success (2 failures - below every threshold). Expected: 0 alerts.
auth_attack.log      Ubuntu/Debian syslog format - normal activity plus:
                     A 192.168.1.100   fast brute force, 40 attempts / ~6 min, 9 usernames incl. root -> R1 R2 R3 R4 HIGH
                     B 198.51.100.77   6 failures for 'deploy' then Accepted password                    -> R1 R6 MEDIUM, P1
                     C 203.0.113.10-13 'admin' tried from 4 IPs, 2-3 attempts each, 20 min              -> R5 MEDIUM
                     D 192.0.2.44      'Invalid user' only (password auth disabled), 8 usernames        -> R1 R3 MEDIUM
                     E 2001:db8:4::23  IPv6, root, rsyslog "message repeated 3 times"                   -> R4 LOW
                     F 203.0.113.25    slow scanner: 1 attempt every 3 minutes for an hour              -> no alert
                     G local sudo failures (no IP), malformed and truncated lines
secure_rhel.log      RHEL/CentOS /var/log/secure format with pam_unix lines and "PAM n more
                     authentication failures" (summary lines, not extra attempts): brute force from
                     10.10.5.20 on root/admin (2 usernames, so no R3) -> R1 R2 R4 HIGH
auth_iso8601.log     Ubuntu 24.04 style ISO-8601 timestamps and the OpenSSH 9.8+ 'sshd-session' process
                     name: 172.16.9.9 enumeration + success after failures -> R1 R3 R6 HIGH, P1
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent
YEAR = 2026


class Log:
    def __init__(self, host: str, iso: bool = False, proc: str = "sshd"):
        self.host, self.iso, self.proc = host, iso, proc
        self.lines: list[tuple[datetime, int, str]] = []
        self.pid = 2000
        self.seq = 0

    def stamp(self, t: datetime) -> str:
        return t.strftime("%Y-%m-%dT%H:%M:%S.%f") + "+00:00" if self.iso else f"{t:%b} {t.day:2d} {t:%H:%M:%S}"

    def add(self, t: datetime, proc: str, msg: str) -> None:
        self.seq += 1
        self.lines.append((t, self.seq, f"{self.stamp(t)} {self.host} {proc}: {msg}"))

    def raw(self, t: datetime, text: str) -> None:
        self.seq += 1
        self.lines.append((t, self.seq, text))

    def new_pid(self) -> int:
        self.pid += random.randint(1, 9)
        return self.pid

    # ---- sshd helpers
    def failed(self, t, user, ip, valid=True, port=None, pam=True):
        pid, port = self.new_pid(), port or random.randint(32768, 60999)
        p = f"{self.proc}[{pid}]"
        if not valid:
            self.add(t, p, f"Invalid user {user} from {ip} port {port}")
            self.add(t, p, "pam_unix(sshd:auth): check pass; user unknown")
        if pam:
            self.add(t + timedelta(seconds=0.5), p, "pam_unix(sshd:auth): authentication failure; logname= uid=0 "
                     f"euid=0 tty=ssh ruser= rhost={ip}" + (f"  user={user}" if valid else ""))
        self.add(t + timedelta(seconds=2), p, f"Failed password for {'' if valid else 'invalid user '}{user} "
                 f"from {ip} port {port} ssh2")
        self.add(t + timedelta(seconds=3), p, f"Connection closed by {'authenticating' if valid else 'invalid'} "
                 f"user {user} {ip} port {port} [preauth]")

    def accepted(self, t, user, ip, method="publickey"):
        pid, port = self.new_pid(), random.randint(32768, 60999)
        p = f"{self.proc}[{pid}]"
        extra = " ssh2: ED25519 SHA256:Zm9yLWRlbW8tb25seS1ub3QtYS1yZWFsLWtleQ" if method == "publickey" else " ssh2"
        self.add(t, p, f"Accepted {method} for {user} from {ip} port {port}{extra}")
        self.add(t, p, f"pam_unix(sshd:session): session opened for user {user}(uid=1000) by {user}(uid=0)")

    def write(self, name: str) -> None:
        self.lines.sort(key=lambda x: (x[0], x[1]))
        (OUT / name).write_text("\n".join(x[2] for x in self.lines) + "\n", encoding="utf-8")


def normal_day(log: Log, day: datetime, noisy_typo=True) -> None:
    for h in range(0, 24):
        t = day + timedelta(hours=h, minutes=17)
        log.add(t, f"CRON[{log.new_pid()}]", "pam_unix(cron:session): session opened for user root(uid=0) by (uid=0)")
    staff = [("student", "192.168.1.105"), ("alice", "192.168.1.20"), ("bob", "10.0.0.15")]
    for i, (u, ip) in enumerate(staff):
        for k in range(3):
            log.accepted(day + timedelta(hours=8 + i + k * 3, minutes=random.randint(0, 50)), u, ip)
    log.add(day + timedelta(hours=9, minutes=5), f"sudo[{log.new_pid()}]",
            "  student : TTY=pts/0 ; PWD=/home/student ; USER=root ; COMMAND=/usr/bin/apt update")
    if noisy_typo:      # user mistypes the password twice, then logs in: must NOT trigger anything
        t = day + timedelta(hours=14, minutes=2)
        log.failed(t, "alice", "192.168.1.20")
        log.failed(t + timedelta(seconds=9), "alice", "192.168.1.20")
        log.accepted(t + timedelta(seconds=20), "alice", "192.168.1.20", "password")


def make_normal() -> None:
    random.seed(1)
    log = Log("ubuntu-srv")
    normal_day(log, datetime(YEAR, 11, 5))
    log.write("auth_normal.log")


def make_attack() -> None:
    random.seed(42)
    log = Log("ubuntu-srv")
    day = datetime(YEAR, 11, 6)
    normal_day(log, day)
    # A - fast brute force (the brief's example IP)
    names = ["admin", "root", "test", "user", "oracle", "postgres", "ubuntu", "pi", "guest", "ftp", "support", "git"]
    t = day + timedelta(hours=10, minutes=20)
    for i in range(40):
        u = names[i % len(names)] if i % 4 else "root"
        log.failed(t, u, "192.168.1.100", valid=u in ("root",))
        t += timedelta(seconds=random.randint(6, 13))
    # B - success after repeated failures
    t = day + timedelta(hours=11, minutes=40)
    for i in range(6):
        log.failed(t, "deploy", "198.51.100.77")
        t += timedelta(seconds=random.randint(15, 30))
    log.accepted(t + timedelta(seconds=20), "deploy", "198.51.100.77", "password")
    # C - distributed attempts on 'admin'
    t = day + timedelta(hours=13, minutes=5)
    for j, ip in enumerate(["203.0.113.10", "203.0.113.11", "203.0.113.12", "203.0.113.13"]):
        for k in range(2 + j % 2):
            log.failed(t + timedelta(minutes=j * 5 + k * 2, seconds=random.randint(0, 40)), "admin", ip, valid=False)
    # D - invalid users only (no password attempt possible) -> counted from 'Invalid user' lines
    t = day + timedelta(hours=15, minutes=30)
    for i, u in enumerate(["webmaster", "mysql", "jenkins", "hadoop", "tomcat", "nagios", "minecraft", "steam"]):
        pid, port = log.new_pid(), 40000 + i
        log.add(t, f"sshd[{pid}]", f"Invalid user {u} from 192.0.2.44 port {port}")
        log.add(t + timedelta(seconds=1), f"sshd[{pid}]", f"Connection closed by invalid user {u} 192.0.2.44 port "
                f"{port} [preauth]")
        t += timedelta(seconds=25)
    # E - IPv6 root attempts with rsyslog duplicate suppression
    t = day + timedelta(hours=17, minutes=45)
    pid = log.new_pid()
    log.add(t, f"sshd[{pid}]", "Failed password for root from 2001:db8:4::23 port 51022 ssh2")
    log.add(t + timedelta(seconds=40), f"sshd[{pid}]",
            "message repeated 3 times: [ Failed password for root from 2001:db8:4::23 port 51022 ssh2]")
    # F - slow scanner, below thresholds
    t = day + timedelta(hours=19)
    for i in range(20):
        log.failed(t + timedelta(minutes=3 * i), ["admin", "root", "user"][i % 3], "203.0.113.25", valid=i % 3 == 1)
    # G - local sudo failures, malformed lines
    t = day + timedelta(hours=16, minutes=12)
    for k in range(2):
        log.add(t + timedelta(seconds=k * 4), f"sudo[{log.new_pid()}]", "pam_unix(sudo:auth): authentication failure; "
                "logname=student uid=1000 euid=0 tty=/dev/pts/1 ruser=student rhost=  user=student")
    log.raw(day + timedelta(hours=16, minutes=13), "### corrupted entry ### \x7f%%%")
    log.raw(day + timedelta(hours=16, minutes=14), "Nov  6 16:14")
    log.write("auth_attack.log")


def make_rhel() -> None:
    random.seed(7)
    log = Log("rhel9-web")
    day = datetime(YEAR, 11, 6)
    for k in range(4):
        log.accepted(day + timedelta(hours=7 + k * 2), "sysadmin", "10.10.1.5")
    t = day + timedelta(hours=2, minutes=14)
    for i in range(18):
        u = "root" if i % 2 else "admin"
        log.failed(t, u, "10.10.5.20", valid=(u == "root"))
        if i % 6 == 5:
            log.add(t + timedelta(seconds=4), f"sshd[{log.pid}]", "PAM 2 more authentication failures; logname= uid=0 "
                    "euid=0 tty=ssh ruser= rhost=10.10.5.20  user=root")
        t += timedelta(seconds=random.randint(8, 20))
    log.write("secure_rhel.log")


def make_iso() -> None:
    random.seed(9)
    log = Log("ubuntu24", iso=True, proc="sshd-session")
    day = datetime(YEAR, 11, 6)
    for k in range(3):
        log.accepted(day + timedelta(hours=8 + k), "student", "172.16.9.40")
    t = day + timedelta(hours=21, minutes=3)
    for i, u in enumerate(["admin", "test", "backup", "support", "dev", "backup", "backup", "backup"]):
        log.failed(t, u, "172.16.9.9", valid=u == "backup")
        t += timedelta(seconds=20)
    log.accepted(t + timedelta(seconds=10), "backup", "172.16.9.9", "password")
    log.write("auth_iso8601.log")


if __name__ == "__main__":
    make_normal()
    make_attack()
    make_rhel()
    make_iso()
    print("Sample logs written to", OUT)
