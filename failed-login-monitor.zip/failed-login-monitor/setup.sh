#!/usr/bin/env bash
# One-time setup on Ubuntu / Debian / Kali / RHEL: virtual environment + dependencies.
set -euo pipefail
cd "$(dirname "$0")"
if ! python3 -c "import venv, ensurepip" 2>/dev/null; then
  echo "python3-venv is missing:  sudo apt install -y python3-venv python3-pip   (RHEL: sudo dnf install python3-pip)"
  exit 1
fi
[ -d venv ] || python3 -m venv venv          # avoids 'externally-managed-environment' (PEP 668) on Kali/Ubuntu
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
echo
echo "Setup complete."
echo "  Dashboard (uploads + samples, no root needed):  ./run.sh"
echo "  Dashboard that can read /var/log/auth.log:       sudo ./run.sh"
echo "  Command line:                                     ./venv/bin/python cli.py analyze samples/auth_attack.log"
echo "  Tests:                                            ./venv/bin/python -m pytest -v"
