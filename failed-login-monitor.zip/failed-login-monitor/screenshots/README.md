# Screenshots

## Included (real output)
`report_page_1.png` … `report_page_3.png`: the first pages of `sample_output/security_report_auth_attack.pdf`,
the PDF generated from `samples/auth_attack.log`.

## Take these on your computer
Streamlit could not be installed in the development environment, so dashboard screenshots must be taken locally.
After `./run.sh`, analyse the sample `auth_attack.log`:

| File | Page |
|---|---|
| 01_soc_dashboard.png | SOC Dashboard (KPIs, timeline, top usernames/IPs) |
| 02_analyze_logs.png | Analyze Logs after the analysis |
| 03_security_alerts.png | Security Alerts with ALT-0001 and ALT-0002 expanded |
| 04_suspicious_ips.png | Suspicious IPs table and IP classification |
| 05_failed_logins.png | Failed Logins filtered to 192.168.1.100 |
| 06_history.png | Alert & Scan History with an alert set to "Investigating" |
| 07_settings.png | Detection Settings |
| 08_reports.png | Reports page |
| 09_cli_watch.png | terminal running `cli.py watch` (demo guide §C) |
| 10_real_authlog.png | optional: your own /var/log/auth.log analysed (demo guide §D) |

Crop out hostnames, usernames or public IPs of real systems before you publish screenshots.
