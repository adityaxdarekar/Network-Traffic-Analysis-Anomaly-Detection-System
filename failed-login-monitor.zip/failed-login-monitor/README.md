# Linux Failed Login Detection and Brute-Force Attack Monitoring System

A Python security-monitoring application that reads Linux authentication logs, finds failed login attempts,
detects brute-force patterns with six configurable rules, scores the risk, explains every alert and produces
reports. It covers the basic failed-login monitoring a Security Operations Center (SOC) analyst does for SSH.

> **Read-only and non-intrusive.** Logs are only read, never modified or deleted. Nothing is blocked
> automatically, no login configuration is changed, and no external IP-reputation service is contacted.
> Risk scores are heuristic indicators, not validated probabilities of an attack, and a flagged IP is not
> proven malicious.

---

## Contents
1. [Introduction](#1-introduction) · 2. [Problem statement](#2-problem-statement) · 3. [Objectives](#3-objectives) ·
4. [Technologies](#4-technologies) · 5. [Architecture](#5-architecture) · 6. [Folder structure](#6-folder-structure) ·
7. [Installation](#7-installation) · 8. [Running](#8-running-the-application) · 9. [Log sources and permissions](#9-log-sources-and-permissions) ·
10. [Log parsing](#10-how-log-parsing-works) · 11. [Detection rules](#11-detection-rules) · 12. [Risk scoring](#12-risk-scoring-and-alerts) ·
13. [Suspicious IPs](#13-suspicious-ip-identification) · 14. [Dashboard](#14-dashboard-pages) · 15. [Reports](#15-reports-and-history) ·
16. [Sample logs](#16-sample-logs-and-expected-results) · 17. [Testing](#17-test-results) · 18. [Security](#18-security-and-privacy) ·
19. [Troubleshooting](#19-troubleshooting) · 20. [Limitations](#20-limitations) · 21. [Future work](#21-future-enhancements) ·
22. [Conclusion](#22-conclusion)

## 1. Introduction
Every Internet-facing Linux server with SSH receives automated password-guessing attempts. Each attempt is
recorded in the authentication log (`/var/log/auth.log` on Debian/Ubuntu, `/var/log/secure` on RHEL/CentOS), but
logs grow to thousands of lines a day and the important signals are easy to miss. These include one IP trying
40 passwords in six minutes, many usernames being probed, an account attacked from several addresses at once,
and, most important of all, a successful login right after a series of failures. This project automates
finding and explaining those patterns.

## 2. Problem statement
Reading authentication logs by hand is slow, error-prone and inconsistent. Log formats differ between
distributions and versions, and a single password guess can produce several log lines. Simple counting therefore
exaggerates, while time windows, username variety and success-after-failure are hard to judge by eye. A tool is
needed that parses different log formats reliably, counts attempts correctly, applies clear, configurable
detection rules, avoids duplicate alerts, explains its reasoning and documents the results, without touching
the system it observes.

## 3. Objectives
1. Read authentication logs safely: uploaded `.log`/`.txt` files, `/var/log/auth.log`, `/var/log/secure`,
   rotated `.gz` logs and the systemd journal.
2. Parse failed password, invalid user, authentication failure, failed publickey, accepted password and accepted
   publickey events, extracting timestamp, host, event type, username, source IP (IPv4 and IPv6), port, service
   and the raw line.
3. Count repeated failed attempts per IP, per username and per time window.
4. Detect brute-force behaviour with six configurable rules and avoid duplicate alerts.
5. Identify and classify source IPs, score their risk and explain why each one was flagged.
6. Generate alerts with severity, priority, explanation and recommended response.
7. Present statistics on a dashboard, keep a history, and produce PDF/CSV/JSON reports.

## 4. Technologies
| Technology | Use |
|---|---|
| Python 3.11+ | application language |
| Regular expressions (`re`) | log line and message parsing |
| pandas | event tables, grouping, time-window statistics |
| `ipaddress` | IPv4/IPv6 validation and classification |
| Streamlit + Plotly | dark SOC dashboard (9 pages) |
| SQLite (`sqlite3`) | analyses, alerts (with status) and IP summaries |
| ReportLab + matplotlib | PDF security report with timeline chart |
| pytest (+ pypdf) | automated tests |

## 5. Architecture
```
 auth.log · secure · *.gz · journalctl · upload
                 │  log_reader.py   (read-only, size limits, permission help)
                 ▼
 log_parser.py   syslog + ISO-8601 timestamps · 6 event types · IPv4/IPv6 · "message repeated" ·
                 one attempt per password guess · malformed lines skipped safely
                 ▼  pandas DataFrame of events
 detection_engine.py   R1 repeated · R2 high volume · R3 many usernames · R4 root ·
                       R5 distributed · R6 success after failures   (sliding windows, bursts)
                 ▼  rule hits
 alert_manager.py + risk_scorer.py   incidents per IP → one alert · points · cap 100 · LOW/MEDIUM/HIGH · P1-P3
 ip_analyzer.py                      per-IP table · IP class · statistics · timeline
                 ▼  AnalysisResult
 ┌───────────────┬──────────────────────┬──────────────────────┐
 Streamlit dashboard   SQLite history (alerts upserted)   PDF / CSV / JSON / ZIP   ·   cli.py (incl. live "watch")
```

## 6. Folder structure
```
failed-login-monitor/
├── app.py                    Streamlit dashboard entry point (9 pages)
├── cli.py                    command line: analyze · system · journal · watch (live monitoring)
├── config.py                 rules, thresholds, windows, points, risk levels, limits, settings load/save
├── monitor/
│   ├── log_reader.py         safe read-only access: uploads, files, .gz, journal
│   ├── log_parser.py         parsing, IP normalisation/classification, attempt de-duplication
│   ├── detection_engine.py   rules R1-R6 (sliding windows, burst merging)
│   ├── risk_scorer.py        score, classification, priority
│   ├── alert_manager.py      incidents → alerts, explanations, recommended responses, fingerprints
│   ├── ip_analyzer.py        per-IP summary, statistics, timeline, top usernames
│   └── analyzer.py           orchestrator → AnalysisResult
├── database/db_manager.py    SQLite: analyses, alerts (upsert + status), IP summaries, alert links
├── reports/                  pdf_generator.py, export_manager.py (CSV / JSON / ZIP)
├── dashboard/                one module per page + common helpers
├── samples/                  4 sample logs + generate_samples.py (documents every scenario)
├── sample_output/            real PDF/CSV/JSON/CLI output produced from the samples
├── tests/                    134 pytest tests (+ Streamlit stand-in for headless page tests)
├── documentation/DEMO_GUIDE.md   demo script, expected output, viva questions
├── COLLEGE_PROJECT_REPORT.md     academic report
├── screenshots/              report page images; add dashboard screenshots here
├── assets/style.css  .streamlit/config.toml  requirements.txt  pytest.ini  setup.sh  run.sh
└── output/                   monitor_history.db, saved reports (created at runtime)
```

## 7. Installation
**Ubuntu / Debian / Kali**
```bash
sudo apt update && sudo apt install -y python3 python3-venv python3-pip
cd failed-login-monitor
chmod +x setup.sh run.sh
./setup.sh
```
**CentOS / RHEL / Fedora**
```bash
sudo dnf install -y python3 python3-pip
cd failed-login-monitor && ./setup.sh
```
**Manual (any OS; on Windows/macOS you can analyse uploaded or copied logs)**
```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 8. Running the application
```bash
./run.sh                 # dashboard: uploads and sample logs, no root needed → http://localhost:8501
sudo ./run.sh            # dashboard that can also read /var/log/auth.log or /var/log/secure
```
Quick demo: **Analyze Logs → Sample log → auth_attack.log → ▶ Analyze sample**, then open **SOC Dashboard**
and **Security Alerts**.

Command line:
```bash
./venv/bin/python cli.py analyze samples/auth_attack.log                 # summary + alerts
./venv/bin/python cli.py analyze samples/auth_attack.log --pdf report.pdf --csv alerts.csv --save
sudo ./venv/bin/python cli.py system                                     # auth.log or secure
sudo ./venv/bin/python cli.py journal                                    # systemd journal
sudo ./venv/bin/python cli.py watch /var/log/auth.log --interval 10      # live: prints NEW alerts only
```
Tests: `./venv/bin/python -m pytest -v`

## 9. Log sources and permissions
| Source | Where | Needs root? |
|---|---|---|
| Upload (`.log`, `.txt`, ≤ 50 MB) | any copy of a log | **No**, analysed in memory |
| Sample logs | `samples/` | No |
| `/var/log/auth.log` | Debian, Ubuntu, Kali (with rsyslog) | Yes, or membership of group `adm` |
| `/var/log/secure` | CentOS, RHEL, Fedora (with rsyslog) | Yes (root only) |
| Rotated logs (`auth.log.1`, `auth.log.2.gz`) | enter the path | as above |
| systemd journal | systems without rsyslog/auth.log | root, or group `systemd-journal`/`adm` |

If reading is denied, the app explains the options instead of crashing:
1. Run with `sudo`.
2. Add your user to the `adm` group: `sudo usermod -aG adm $USER`, then log out and back in.
3. Upload a copy: `sudo cp /var/log/auth.log ~/auth_copy.log && sudo chown $USER ~/auth_copy.log`.

Some installations do not install rsyslog, so `/var/log/auth.log` does not exist. Check with
`ls -l /var/log/auth.log /var/log/secure`. In that case, use the **systemd journal** option. It runs the fixed,
read-only command `journalctl --no-pager -o short-iso --since -7d _COMM=sshd + _COMM=sshd-session +
SYSLOG_FACILITY=4 + SYSLOG_FACILITY=10`, with no shell and no user input. Large files: only the newest 50 MB are
read, starting at a complete line.

## 10. How log parsing works
**Line formats** are detected per line, so mixed files work:
```
Nov  6 10:20:01 ubuntu sshd[1234]: Failed password for root from 192.168.1.100 port 45322 ssh2       (classic syslog)
2026-11-06T10:20:01.123456+00:00 ubuntu sshd-session[99]: Failed password for root from 2001:db8::5 port 22 ssh2  (ISO 8601)
```
Classic syslog has no year. The current year is assumed (configurable), and a December → January rollover
inside one file is handled.

**Events and extracted fields** (timestamp, hostname, service, pid, username, IP, port, raw line):

| Event type | Log message |
|---|---|
| FAILED_PASSWORD | `Failed password for [invalid user] USER from IP port N`; also `Failed keyboard-interactive/pam` |
| FAILED_PUBLICKEY | `Failed publickey for [invalid user] USER from IP port N` |
| INVALID_USER | `Invalid user USER from IP [port N]` |
| AUTH_FAILURE | `pam_unix(sshd:auth): authentication failure; … rhost=IP user=USER`; also local `sudo`/`su` failures (no IP) |
| ACCEPTED_PASSWORD | `Accepted password for USER from IP port N`; also `Accepted keyboard-interactive/pam` |
| ACCEPTED_PUBLICKEY | `Accepted publickey for USER from IP port N` |

rsyslog's `message repeated N times: [ … ]` is expanded to N events. IPv4 and IPv6 are supported; IPv6 is
normalised (e.g. `2001:DB8:0:0::5` → `2001:db8::5`, zone IDs removed). Malformed or truncated lines are counted and
skipped, and up to 20 examples are shown. They never stop the analysis.

**Counting attempts correctly.** One SSH password guess can write three lines (`Invalid user …`,
`pam_unix … authentication failure`, `Failed password …`). All lines are kept, but `counts_as_attempt` is set only
for:
- each `Failed password` / `Failed publickey` line (one per guess), and
- `Invalid user` / `authentication failure` lines from a connection (same host, process ID and IP) that has no
  `Failed …` line. This covers servers with password login disabled, and local `sudo` failures.

Summary and disconnect lines (`PAM 2 more authentication failures`, `Connection closed by …`,
`maximum authentication attempts exceeded`) describe attempts already logged, so they are not counted again.
Successful logins are never counted as failures.

## 11. Detection rules
All thresholds, windows and points are configurable (Detection Settings page or `config.py`).

| Rule | Condition (default) | Points |
|---|---|---|
| R1 Repeated Failed Logins | ≥ 5 failed attempts from one IP within 5 minutes | +20 |
| R2 High-Volume Failed Logins | ≥ 10 failed attempts from one IP within 10 minutes | +30 |
| R3 Multiple Username Attempts | ≥ 5 different usernames from one IP within 10 minutes (enumeration / dictionary attack) | +20 |
| R4 Root Login Attempts | ≥ 3 failed attempts for `root` from one IP within 10 minutes | +15 |
| R5 Distributed Login Attempts | one username failed from ≥ 3 different IPs (each ≥ 2 attempts) within 30 minutes | +30 |
| R6 Successful Login After Repeated Failures | a successful login for USER from IP after ≥ 3 failed attempts for the same USER and IP within 10 minutes | +25 |

Each rule uses a **sliding time window** over the attempts sorted by time. Every attempt that belongs to a
qualifying window is marked, and marked attempts are merged into **bursts**. So a 40-attempt attack produces one
R1 hit, not 36 overlapping ones; two attacks hours apart stay separate. Only events with a timestamp and a source
IP take part in time-window rules; local failures (sudo) appear in the statistics. The brief did not give points
for R5, so 30 was chosen, which makes a distributed attack at least MEDIUM, because each source alone stays
below the per-IP thresholds.

## 12. Risk scoring and alerts
**Score** = sum of the points of each *different* rule triggered, capped at 100. **Severity:** 0–29 LOW,
30–59 MEDIUM, 60–100 HIGH (configurable).
**Priority:** P1 for HIGH severity *or* any successful login after failures (R6), whatever its score, because a
possible account compromise must be investigated first. P2 for MEDIUM, P3 for LOW.

**One alert per incident.** All rule hits of one IP that overlap or are less than 15 minutes apart
(configurable) form one incident, and therefore one alert listing every rule it triggered. Distributed attempts
(R5) become their own alert with several source IPs. Each alert has a deterministic fingerprint, so analysing
the same log again, or a log that has grown, **updates** the stored alert instead of creating a duplicate.

Each alert contains: alert ID, title, first/last time and window length, source IP(s) and IP class, target
usernames, failed-attempt and success counts, the triggered rules with evidence and points, risk score, severity,
priority, explanation and recommended response. Example (real output for `samples/auth_attack.log`):
```
ALERT ALT-0001 [P1] POSSIBLE SSH BRUTE-FORCE ATTACK
  Source IP:        192.168.1.100  [Private]
  Target usernames: ftp, git, pi, postgres, root, support, test, ubuntu, user
  Failed attempts:  40   successful logins: 0
  Time window:      2026-11-06 10:20:02 -> 2026-11-06 10:26:06 (6.1 min)
  Risk score:       85/100  Severity: HIGH
  + R1 Repeated Failed Logins (+20): 33 failed attempts within 5 min (threshold 5)
  + R2 High-Volume Failed Logins (+30): 40 failed attempts within 10 min (threshold 10)
  + R3 Multiple Username Attempts (+20): 9 different usernames within 10 min (threshold 5)
  + R4 Root Login Attempts (+15): 14 failed attempts for 'root' within 10 min (threshold 3)
```

## 13. Suspicious IP identification
For every source IP the Suspicious IPs page and the reports show: IP, class, total failed attempts, number and
names of usernames targeted, first and last observed time, successful logins and accepted users, risk score,
risk level, status and reason.

IP classes use Python's `ipaddress` module:

| Class | Covers |
|---|---|
| Private | 10/8, 172.16/12, 192.168/16, fc00::/7 |
| Public | globally routable |
| Loopback | 127.0.0.0/8, ::1 |
| Link-local | 169.254/16, fe80::/10 |
| Reserved | documentation/test ranges, CGNAT 100.64/10, multicast |
| Invalid | not a valid address |
| Local (no IP) | sudo/su failures |

IPs are never called "malicious": they are *Flagged for review* or *Not flagged*. Nothing is blocked, and no
external reputation API is used.

## 14. Dashboard pages
| Page | Content |
|---|---|
| SOC Dashboard | KPIs, failed vs successful timeline, top usernames, top source IPs, event types, alerts by severity, latest alerts |
| Analyze Logs | sample / upload / system log / journal, availability and permissions of system logs, parse statistics, malformed lines |
| Failed Logins | every parsed event with filters (type, user, IP) and the counted-attempt flag; raw lines on request |
| Suspicious IPs | IP table, classification chart, per-IP detail with its events and alerts |
| Security Alerts | alert cards (P1 first) with rules, explanation and recommended response |
| Alert & Scan History | stored alerts with status (Open / Investigating / Resolved / False positive), previous analyses, CSV, delete |
| Reports | PDF report, alerts / IPs / events CSV, JSON, ZIP |
| Detection Settings | every threshold, window, point value and risk level, plus validation and re-analysis with the new settings |
| About Project | architecture, safety notes |

## 15. Reports and history
- **PDF report:** executive summary, log source and parsing statistics, detection rules and thresholds,
  timeline chart, most targeted usernames, alert table, alert details with rules and recommended response,
  suspicious IPs, hardening recommendations, notes and limitations. A real example is in `sample_output/`.
- **CSV:** alerts, IP summary, parsed events. **JSON:** full analysis. **ZIP:** all of these.
- **SQLite history** (`output/monitor_history.db`): analyses, alerts (upserted by fingerprint, `times_seen`,
  investigation status), per-IP summaries. Raw log lines are **not** stored unless enabled in Detection Settings.

## 16. Sample logs and expected results
All sample IPs are private or reserved documentation addresses (192.0.2.0/24, 198.51.100.0/24,
203.0.113.0/24, 2001:db8::/32), so no real organisation is ever shown as an attacker.
`samples/generate_samples.py` regenerates the logs and documents each scenario.

| File | Scenario | Result |
|---|---|---|
| auth_normal.log | normal day: key logins, cron, sudo; user mistypes the password twice then logs in | **0 alerts** |
| auth_attack.log | A 192.168.1.100: 40 attempts in ~6 min, 9 usernames incl. root | HIGH 85, P1 (R1 R2 R3 R4) |
| | B 198.51.100.77: 6 failures for `deploy`, then accepted password | MEDIUM 45, **P1** (R1 R6) |
| | C 203.0.113.10–13: `admin` from 4 IPs, 2–3 attempts each, 19 min | MEDIUM 30, P2 (R5) |
| | D 192.0.2.44: 8 usernames, `Invalid user` lines only | MEDIUM 40, P2 (R1 R3) |
| | E 2001:db8:4::23: IPv6, root, "message repeated 3 times" | LOW 15, P3 (R4) |
| | F 203.0.113.25: 20 attempts, one every 3 minutes | **not flagged** (below thresholds) |
| | G local sudo failures; 2 malformed lines | counted in statistics; skipped safely |
| secure_rhel.log | RHEL format with pam_unix and "PAM 2 more…" lines; 10.10.5.20 on root/admin | HIGH 65, P1 (R1 R2 R4) |
| auth_iso8601.log | ISO timestamps, `sshd-session`; 172.16.9.9 tries 5 users, then logs in as `backup` | HIGH 65, P1 (R1 R3 R6) |

Totals for `auth_attack.log`: 401 lines, 230 events, **92 counted failed attempts** (not the ~200 failure lines),
11 successful logins, 12 source IPs, 5 alerts.

## 17. Test results
`./venv/bin/python -m pytest -v`. Result in the development environment (Ubuntu 24.04, Python 3.13):
**134 passed** as root. As a normal user: **133 passed, 1 skipped**, because one test needs root to start a
process as user `nobody`. The code also compiles on Python 3.11 and 3.12.

| Test file | Tests | Covers |
|---|---|---|
| test_log_parser.py | 50 | the brief's example lines, all event types incl. keyboard-interactive, IPv6, ISO timestamps (+00:00, +0530, Z), sudo, "message repeated", lines that must not add attempts, malformed lines, year rollover, one-guess-one-attempt, IP classification (16 cases) |
| test_log_reader.py | 17 | upload type/size/empty/binary, invalid UTF-8, missing file, directory, newest-part reading of large files, .gz, **log unchanged after reading**, permission message (mocked and with a real unprivileged process), journal fixed command without shell, journal errors, source code has no write/delete/firewall/`shell=True` |
| test_detection_engine.py | 15 | R1–R6 at their thresholds and window edges, negative cases (typo, other user/IP, old failures), configurable thresholds, disabled rules, one hit per burst, separate bursts, local events, successes never trigger failure rules |
| test_alerts_scoring.py | 17 | classification, sum and cap at 100, priority, full alert fields, sequential IDs, incident merging and splitting, stable fingerprints, distributed alert, IP table wording ("Flagged for review", never "malicious") |
| test_samples.py | 5 | every sample log produces exactly the documented alerts and counts |
| test_database_reports.py | 10 | re-analysis without duplicates, status tracking, filters, delete/clear, raw lines not stored by default, SQL-injection-safe, CSV/JSON/ZIP, safe file names, PDF contents |
| test_dashboard_cli.py | 20 | 9 pages without and with data, sample workflow, valid/invalid upload, missing system log, settings re-analysis and validation, history status, report saving, CLI analyze/exports/missing file, **watch mode prints only new alerts** |

**Performance** (development environment): sample logs 0.1 s; a synthetic stress log of 200,000 lines
(17 MB) with 136,442 different IPs and 3,062 alerts took 16 s.

## 18. Security and privacy
- Logs are opened in binary read mode only, and a test checks that a log's content, size and modification time
  are unchanged after reading
- No root needed for uploads and samples; for system logs, permission errors are explained
- `journalctl` is run with a fixed argument list and `shell=False`
- No blocking, no firewall changes, no login configuration changes; responses are recommendations
- No external services or reputation APIs; the dashboard listens on 127.0.0.1; usage statistics are off
- Raw log lines are not stored in history by default; exports contain parsed fields only (raw lines optional in events CSV)
- Log-derived text is HTML-escaped in the dashboard and the PDF; users see friendly errors, not stack traces
- Monitor only systems you are authorised to monitor

## 19. Troubleshooting
| Problem | Solution |
|---|---|
| `externally-managed-environment` | use `./setup.sh` (virtual environment) |
| "Permission denied … adm group" | `sudo ./run.sh`, or `sudo usermod -aG adm $USER` and log in again, or upload a copy |
| `/var/log/auth.log does not exist` | use the systemd journal option, `/var/log/secure` on RHEL, or install rsyslog |
| "journal contains no SSH entries" | no SSH activity in 7 days, or no permission: run with sudo |
| Wrong year on old logs | Detection Settings → year for syslog timestamps |
| Too many / too few alerts | adjust thresholds and windows in Detection Settings → Save and re-analyse |
| Port 8501 in use | `./venv/bin/python -m streamlit run app.py --server.port 8502` |
| Very large log is slow | analyse a rotated part or `tail -n 200000 auth.log > part.log` |

## 20. Limitations
- Rule-based: slow attacks below the thresholds (like scenario F) and attacks spread over many IPs and usernames
  can avoid detection; legitimate users who mistype often can trigger alerts.
- Detection depends on the log: if sshd logging is reduced (LogLevel QUIET) or logs are rotated away, events are
  missing.
- Formats differ between distributions and OpenSSH versions; unrecognised messages are skipped, not guessed.
- Syslog lines without a year rely on an assumed year.
- Timestamps are used as written in the log (local wall-clock); time zones are not converted between hosts.
- Only SSH, sudo/su and PAM authentication messages are analysed (not web, FTP or mail logins).
- IP addresses may belong to shared networks (NAT, VPN, cloud), so attribution needs investigation.
- The score is not statistically calibrated, and accuracy was not measured on a large real-world dataset.

## 21. Future enhancements
- Opt-in IP reputation and geolocation (with consent and caching)
- Automatic scheduled monitoring with e-mail/chat notifications
- More services (Apache/Nginx auth, vsftpd, Postfix) and Windows Security event logs
- Optional, reviewed integration with fail2ban or firewall rules (always admin-approved)
- Baseline learning of normal login hours and locations per user
- Multi-host log collection and correlation

## 22. Conclusion
The project turns raw Linux authentication logs into explained, prioritised security alerts. Careful parsing
(several formats, IPv6, correct attempt counting), configurable time-window rules, incident merging, and a
transparent score make the results reliable and understandable. The system does all of this read-only, without
blocking anything or sending data elsewhere. The dashboard, command-line live monitoring, history with
investigation status, and PDF/CSV reports reproduce a small but realistic slice of SOC work, and 134 automated
tests confirm the behaviour.
