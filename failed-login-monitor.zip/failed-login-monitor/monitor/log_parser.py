"""
Authentication log parser.

Line formats (detected per line, so mixed files work):
  1. classic syslog (rsyslog default, RHEL /var/log/secure, `journalctl -o short`):
        Nov  6 10:20:01 ubuntu sshd[1234]: Failed password for root from 192.168.1.100 port 45322 ssh2
  2. ISO 8601 / RFC 3339 (Ubuntu 23.10+ rsyslog default, `journalctl -o short-iso`):
        2026-11-06T10:20:01.123456+00:00 ubuntu sshd[1234]: Failed password for root from 192.168.1.100 port ...

Event types:
  FAILED_PASSWORD   Failed password for [invalid user] USER from IP port N
  FAILED_PUBLICKEY  Failed publickey for [invalid user] USER from IP port N
  INVALID_USER      Invalid user USER from IP [port N]
  AUTH_FAILURE      pam_unix(...:auth): authentication failure; ... rhost=IP user=USER   (also su/sudo, local)
  ACCEPTED_PASSWORD Accepted password for USER from IP port N
  ACCEPTED_PUBLICKEY Accepted publickey for USER from IP port N
"message repeated N times: [ ... ]" lines (rsyslog duplicate suppression) are expanded to N events.

Counting failed ATTEMPTS without double counting
------------------------------------------------
One SSH password guess can produce up to three lines (Invalid user …, pam_unix authentication failure,
Failed password …). Each line is kept as an event, but `counts_as_attempt` is True only for:
  * every FAILED_PASSWORD / FAILED_PUBLICKEY line (one per guess), and
  * INVALID_USER / AUTH_FAILURE lines from a connection (same host + process id + IP) that has NO
    Failed password/publickey line - e.g. servers with password login disabled, or su/sudo failures.
Successful logins are never counted as failures.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime

import pandas as pd

FAILED_TYPES = {"FAILED_PASSWORD", "FAILED_PUBLICKEY", "INVALID_USER", "AUTH_FAILURE"}
SUCCESS_TYPES = {"ACCEPTED_PASSWORD", "ACCEPTED_PUBLICKEY"}
EVENT_LABELS = {
    "FAILED_PASSWORD": "Failed password", "FAILED_PUBLICKEY": "Failed publickey", "INVALID_USER": "Invalid user",
    "AUTH_FAILURE": "Authentication failure", "ACCEPTED_PASSWORD": "Accepted password",
    "ACCEPTED_PUBLICKEY": "Accepted publickey",
}
MONTHS = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                      "Dec"], 1)}

# --------------------------------------------------------------------------- line headers
SYSLOG_RE = re.compile(r"^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+"
                       r"(?P<host>\S+)\s+(?P<proc>[\w./@-]+?)(?:\[(?P<pid>\d+)\])?:\s?(?P<msg>.*)$")
ISO_RE = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+"
                    r"(?P<host>\S+)\s+(?P<proc>[\w./@-]+?)(?:\[(?P<pid>\d+)\])?:\s?(?P<msg>.*)$")

# --------------------------------------------------------------------------- messages
IP = r"(?P<ip>[0-9A-Fa-f:.]+(?:%\w+)?)"
USER = r"(?P<user>.*?)"
PORT = r"(?:\s+port\s+(?P<port>\d+))?"
MESSAGE_PATTERNS = [
    ("FAILED_PASSWORD", re.compile(rf"^Failed password for (?P<invalid>invalid user )?{USER} from {IP}{PORT}")),
    # PAM / 2FA logins ("keyboard-interactive/pam") are password-type authentications
    ("FAILED_PASSWORD", re.compile(rf"^Failed keyboard-interactive(?:/pam)? for (?P<invalid>invalid user )?{USER} "
                                   rf"from {IP}{PORT}")),
    ("FAILED_PUBLICKEY", re.compile(rf"^Failed publickey for (?P<invalid>invalid user )?{USER} from {IP}{PORT}")),
    ("ACCEPTED_PASSWORD", re.compile(rf"^Accepted password for {USER} from {IP}{PORT}")),
    ("ACCEPTED_PASSWORD", re.compile(rf"^Accepted keyboard-interactive(?:/pam)? for {USER} from {IP}{PORT}")),
    ("ACCEPTED_PUBLICKEY", re.compile(rf"^Accepted publickey for {USER} from {IP}{PORT}")),
    ("INVALID_USER", re.compile(rf"^Invalid user {USER} from {IP}{PORT}\s*$")),
    ("INVALID_USER", re.compile(rf"^Invalid user {USER} from {IP}{PORT}\b")),
    ("AUTH_FAILURE", re.compile(r"^pam_unix\((?P<svc>[\w-]+):auth\): authentication failure;(?P<kv>.*)$")),
]
REPEATED_RE = re.compile(r"^message repeated (?P<n>\d+) times: \[\s*(?P<msg>.*?)\s*\]\s*$")


@dataclass
class AuthEvent:
    line_no: int
    timestamp: datetime | None
    hostname: str
    service: str
    pid: str
    event_type: str
    username: str
    ip: str             # "" for local events (su, sudo, console login)
    port: int | None
    invalid_user: bool
    raw: str
    counts_as_attempt: bool = False

    @property
    def failed(self) -> bool:
        return self.event_type in FAILED_TYPES

    @property
    def success(self) -> bool:
        return self.event_type in SUCCESS_TYPES


@dataclass
class ParseResult:
    events: list = field(default_factory=list)
    total_lines: int = 0
    auth_lines: int = 0          # lines that produced at least one event
    unrecognised_header: int = 0  # lines that are not syslog / ISO formatted (malformed)
    other_lines: int = 0          # well-formed lines that are not authentication events
    bad_timestamps: int = 0
    malformed_samples: list = field(default_factory=list)
    formats: dict = field(default_factory=dict)   # {"syslog": n, "iso8601": n}

    def dataframe(self) -> pd.DataFrame:
        cols = list(AuthEvent.__dataclass_fields__) + ["failed", "success"]
        rows = [{**asdict(e), "failed": e.failed, "success": e.success} for e in self.events]
        df = pd.DataFrame(rows, columns=cols)
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        return df


# --------------------------------------------------------------------------- helpers
def clean_ip(value: str) -> str:
    """Return a normalised IP address string, or the original text if it is not a valid IP."""
    v = (value or "").strip().strip("[]")
    v = v.split("%")[0]
    try:
        return str(ipaddress.ip_address(v))
    except ValueError:
        return v


PRIVATE_NETS = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")]


def classify_ip(value: str) -> str:
    """
    Private / Public / Loopback / Link-local / Reserved / Invalid / Local (no IP), using the ipaddress module.
    'Private' = RFC 1918 (10/8, 172.16/12, 192.168/16) and IPv6 unique-local (fc00::/7).
    'Reserved' = other non-global ranges such as documentation/test networks (192.0.2.0/24, 2001:db8::/32),
    carrier-grade NAT (100.64.0.0/10), multicast and unspecified addresses.
    """
    if not value:
        return "Local (no IP)"
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return "Invalid"
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    if ip.is_loopback:
        return "Loopback"
    if ip.is_link_local:
        return "Link-local"
    if any(ip in net for net in PRIVATE_NETS if net.version == ip.version):
        return "Private"
    if not ip.is_global or ip.is_multicast or ip.is_unspecified:
        return "Reserved"
    return "Public"


def _kv(text: str) -> dict:
    return {k: v for k, v in re.findall(r"(\w+)=(\S*)", text)}


class TimestampResolver:
    """Adds a year to classic syslog timestamps and handles the December -> January rollover."""

    def __init__(self, year: int | None = None):
        self.year = year or datetime.now().year
        self.last: datetime | None = None

    def syslog(self, mon: str, day: str, time_s: str) -> datetime:
        m = MONTHS[mon]
        h, mi, s = (int(x) for x in time_s.split(":"))
        ts = datetime(self.year, m, int(day), h, mi, s)
        if self.last and (self.last - ts).days > 180:      # e.g. Dec 31 -> Jan 1
            self.year += 1
            ts = ts.replace(year=self.year)
        self.last = ts
        return ts

    @staticmethod
    def iso(value: str) -> datetime:
        v = value.replace("Z", "+00:00")
        v = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", v)
        ts = datetime.fromisoformat(v)
        return ts.replace(tzinfo=None) if ts.tzinfo else ts   # local wall-clock time of the log


def parse_message(msg: str) -> tuple[str, dict] | None:
    for etype, rx in MESSAGE_PATTERNS:
        m = rx.match(msg)
        if not m:
            continue
        g = m.groupdict()
        if etype == "AUTH_FAILURE":
            kv = _kv(g["kv"])
            return etype, {"user": kv.get("user", ""), "ip": kv.get("rhost", ""), "port": None,
                           "invalid": False, "svc": g["svc"]}
        return etype, {"user": g.get("user") or "", "ip": g.get("ip") or "", "port": g.get("port"),
                       "invalid": bool(g.get("invalid")) or etype == "INVALID_USER", "svc": None}
    return None


def parse_line(line: str, line_no: int, resolver: TimestampResolver, result: ParseResult) -> list[AuthEvent]:
    line = line.rstrip("\r\n")
    if not line.strip():
        return []
    m = ISO_RE.match(line)
    fmt = "iso8601"
    if not m:
        m = SYSLOG_RE.match(line)
        fmt = "syslog"
    if not m:
        result.unrecognised_header += 1
        if len(result.malformed_samples) < 20:
            result.malformed_samples.append({"line": line_no, "text": line[:200]})
        return []
    g = m.groupdict()
    msg = g["msg"]
    repeat = 1
    rm = REPEATED_RE.match(msg)
    if rm:
        repeat, msg = int(rm.group("n")), rm.group("msg")
    parsed = parse_message(msg)
    if not parsed:
        result.other_lines += 1
        return []
    try:
        ts = resolver.iso(g["ts"]) if fmt == "iso8601" else resolver.syslog(g["mon"], g["day"], g["time"])
    except (ValueError, KeyError):
        ts = None
        result.bad_timestamps += 1
    result.formats[fmt] = result.formats.get(fmt, 0) + 1
    etype, f = parsed
    port = int(f["port"]) if f.get("port") else None
    service = g["proc"] + (f"({f['svc']})" if f.get("svc") and f["svc"] != g["proc"] else "")
    ev = AuthEvent(line_no=line_no, timestamp=ts, hostname=g["host"], service=service, pid=g.get("pid") or "",
                   event_type=etype, username=f["user"].strip(), ip=clean_ip(f["ip"]) if f["ip"] else "",
                   port=port, invalid_user=f["invalid"], raw=line[:500])
    return [ev] + [AuthEvent(**{**asdict(ev)}) for _ in range(repeat - 1)]


def mark_attempts(events: list[AuthEvent]) -> None:
    """Set counts_as_attempt so that one password guess is counted once (see module docstring)."""
    with_failed_line = {(e.hostname, e.pid, e.ip) for e in events
                        if e.event_type in ("FAILED_PASSWORD", "FAILED_PUBLICKEY") and e.pid}
    for e in events:
        if e.event_type in ("FAILED_PASSWORD", "FAILED_PUBLICKEY"):
            e.counts_as_attempt = True
        elif e.event_type in ("INVALID_USER", "AUTH_FAILURE"):
            e.counts_as_attempt = not (e.pid and (e.hostname, e.pid, e.ip) in with_failed_line)


def parse_log(text: str, year: int | None = None, max_lines: int | None = None) -> ParseResult:
    result = ParseResult()
    resolver = TimestampResolver(year)
    for n, line in enumerate(text.splitlines(), 1):
        if max_lines and n > max_lines:
            break
        result.total_lines += 1
        try:
            evs = parse_line(line, n, resolver, result)
        except Exception:  # noqa: BLE001 - a single odd line must never stop the analysis
            result.unrecognised_header += 1
            continue
        if evs:
            result.auth_lines += 1
            result.events.extend(evs)
    mark_attempts(result.events)
    return result
