"""
Rule-based risk scoring.

score = sum of the points of every DIFFERENT rule triggered (each rule counts once), capped at 100.
0-29 LOW · 30-59 MEDIUM · 60-100 HIGH (thresholds configurable in settings["risk_thresholds"]).

The score is a heuristic risk indicator chosen by expert rules - not a validated probability of attack.
"""

from __future__ import annotations


def score_rules(rule_points: dict[str, int]) -> int:
    """rule_points: {rule_id: points} - one entry per distinct rule."""
    return max(0, min(100, sum(int(p) for p in rule_points.values())))


def classify(score: int, thresholds: dict) -> str:
    if score >= int(thresholds["HIGH"]):
        return "HIGH"
    if score >= int(thresholds["MEDIUM"]):
        return "MEDIUM"
    return "LOW"


def priority(level: str, rules: set[str]) -> str:
    """P1 = investigate first. A success after failures (R6) is always P1, whatever its score."""
    if "R6" in rules or level == "HIGH":
        return "P1"
    return "P2" if level == "MEDIUM" else "P3"
