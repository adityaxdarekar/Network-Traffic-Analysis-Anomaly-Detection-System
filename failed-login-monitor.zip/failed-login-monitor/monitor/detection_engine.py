"""
Detection rules R1-R6 (all thresholds and windows come from settings["rules"]).

Each rule produces RuleHit objects. A hit covers a whole BURST: every event that belongs to at least one
time window meeting the rule's condition, merged together - so a 40-attempt attack produces ONE R1 hit,
not 36 overlapping ones (duplicate-alert avoidance, step 1; step 2 is incident merging in alert_manager).

  R1 Repeated failed logins     >= T failed attempts from one IP within W minutes
  R2 High-volume failed logins  >= T failed attempts from one IP within W minutes (higher T/W)
  R3 Multiple usernames         >= T different usernames from one IP within W minutes
  R4 Root login attempts        >= T failed attempts for 'root' from one IP within W minutes
  R5 Distributed attempts       one username failed from >= T different IPs within W minutes,
                                each IP with >= min_attempts_per_ip failures
  R6 Success after failures     a successful login for USER from IP preceded by >= T failed attempts for
                                the same USER from the same IP within W minutes

Only events with a timestamp and a source IP take part in the time-window rules.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import timedelta

import pandas as pd

import config as C


@dataclass
class RuleHit:
    rule: str
    ip: str                          # source IP ("" for R5, which spans several IPs)
    start: pd.Timestamp
    end: pd.Timestamp
    failed_count: int                # failed attempts inside the burst
    usernames: list = field(default_factory=list)
    ips: list = field(default_factory=list)       # R5: participating IPs
    target_user: str = ""                          # R5 / R6
    max_in_window: int = 0           # strongest single window (e.g. 14 attempts in 5 minutes)
    detail: str = ""
    points: int = 0

    @property
    def name(self) -> str:
        return C.RULE_NAMES[self.rule]


def attempts_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Failed attempts usable for time-window rules (counted once, with timestamp and IP)."""
    a = df[df["counts_as_attempt"] & df["timestamp"].notna() & (df["ip"] != "")]
    return a.sort_values(["timestamp", "line_no"]).reset_index(drop=True)


def _merge_ranges(ranges: list[tuple[int, int]], times: list | None = None,
                  window: timedelta | None = None) -> list[tuple[int, int]]:
    """
    Merge qualifying index ranges into bursts. Ranges that overlap are merged; ranges that only touch
    (next range starts right after the previous one ends) are merged only when the time gap between them is
    within the rule's window - two attacks hours apart stay two bursts.
    """
    merged: list[list[int]] = []
    for s, e in sorted(ranges):
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        elif (merged and s == merged[-1][1] + 1 and times is not None and window is not None
              and times[s] - times[merged[-1][1]] <= window):
            merged[-1][1] = e
        else:
            merged.append([s, e])
    return [(s, e) for s, e in merged]


def sliding_bursts(times: list, threshold: int, window: timedelta, key_fn=None) -> list[tuple[int, int, int]]:
    """
    Indices of events in windows meeting the condition, merged into bursts.
    Without key_fn: condition = number of events in window >= threshold.
    With key_fn(i): condition = number of DIFFERENT keys in window >= threshold.
    Returns [(start_index, end_index, max_value_in_any_window)].
    """
    ranges, best, left = [], {}, 0
    counter: Counter = Counter()
    for right in range(len(times)):
        if key_fn:
            counter[key_fn(right)] += 1
        while times[right] - times[left] > window:
            if key_fn:
                k = key_fn(left)
                counter[k] -= 1
                if counter[k] == 0:
                    del counter[k]
            left += 1
        value = len(counter) if key_fn else right - left + 1
        if value >= threshold:
            ranges.append((left, right))
            best[(left, right)] = value
    out = []
    for s, e in _merge_ranges(ranges, times, window):
        mx = max(v for (l, r), v in best.items() if s <= l and r <= e)
        out.append((s, e, mx))
    return out


# --------------------------------------------------------------------------- per-IP rules
def _per_ip_rule(att: pd.DataFrame, rule: str, cfg: dict, distinct_users: bool = False,
                 only_user: str | None = None) -> list[RuleHit]:
    hits = []
    threshold = int(cfg["threshold"])
    window = timedelta(minutes=float(cfg["window_minutes"]))
    data = att if only_user is None else att[att["username"] == only_user]
    # performance: only IPs that could possibly reach the threshold are examined
    sizes = data.groupby("ip")["username"].nunique() if distinct_users else data["ip"].value_counts()
    candidates = set(sizes[sizes >= threshold].index)
    if not candidates:
        return hits
    data = data[data["ip"].isin(candidates)]
    for ip, g in data.groupby("ip", sort=False):
        times = list(g["timestamp"])
        users = list(g["username"])
        key_fn = (lambda i: users[i]) if distinct_users else None
        for s, e, mx in sliding_bursts(times, threshold, window, key_fn):
            unames = sorted(set(users[s:e + 1]))
            if distinct_users:
                detail = f"{mx} different usernames within {cfg['window_minutes']} min (threshold {threshold})"
            elif only_user:
                detail = f"{mx} failed attempts for '{only_user}' within {cfg['window_minutes']} min " \
                         f"(threshold {threshold})"
            else:
                detail = f"{mx} failed attempts within {cfg['window_minutes']} min (threshold {threshold})"
            hits.append(RuleHit(rule, ip, times[s], times[e], e - s + 1, unames, max_in_window=mx, detail=detail,
                                points=int(cfg["points"])))
    return hits


def rule_r5(att: pd.DataFrame, cfg: dict) -> list[RuleHit]:
    hits = []
    window = timedelta(minutes=float(cfg["window_minutes"]))
    need_ips, per_ip = int(cfg["threshold"]), int(cfg.get("min_attempts_per_ip", 1))
    # performance: only usernames with enough IPs that each made enough attempts can qualify
    per_user_ip = att.groupby(["username", "ip"]).size()
    eligible = per_user_ip[per_user_ip >= per_ip].groupby(level=0).size()
    users = set(eligible[eligible >= need_ips].index)
    for user, g in att[att["username"].isin(users)].groupby("username", sort=False):
        g = g.reset_index(drop=True)
        times, ips = list(g["timestamp"]), list(g["ip"])
        ranges, left, counter, qualified = [], 0, Counter(), 0
        for right in range(len(times)):
            counter[ips[right]] += 1
            if counter[ips[right]] == per_ip:            # this IP just reached the per-IP minimum
                qualified += 1
            while times[right] - times[left] > window:
                if counter[ips[left]] == per_ip:          # dropping below the minimum
                    qualified -= 1
                counter[ips[left]] -= 1
                left += 1
            if qualified >= need_ips:
                ranges.append((left, right))
        for s, e in _merge_ranges(ranges, times, window):
            part = g.iloc[s:e + 1]
            per = part["ip"].value_counts()
            ip_list = sorted(per[per >= per_ip].index)
            hits.append(RuleHit("R5", "", part["timestamp"].iloc[0], part["timestamp"].iloc[-1], len(part),
                                [user], ips=ip_list, target_user=user, max_in_window=len(ip_list),
                                detail=f"username '{user}' targeted by {len(ip_list)} different IPs "
                                       f"(each >= {per_ip} attempts) within {cfg['window_minutes']} min "
                                       f"(threshold {need_ips} IPs)", points=int(cfg["points"])))
    return hits


def rule_r6(att: pd.DataFrame, df: pd.DataFrame, cfg: dict) -> list[RuleHit]:
    hits = []
    threshold = int(cfg["threshold"])
    window = timedelta(minutes=float(cfg["window_minutes"]))
    succ = df[df["success"] & df["timestamp"].notna() & (df["ip"] != "")].sort_values("timestamp")
    if succ.empty or att.empty:
        return hits
    # failed-attempt times per (ip, user), sorted - looked up with binary search (fast on large logs)
    wanted = set(zip(succ["ip"], succ["username"]))
    failures: dict[tuple, list] = defaultdict(list)
    for ip, user, t in zip(att["ip"], att["username"], att["timestamp"]):   # att is sorted by time
        if (ip, user) in wanted:
            failures[(ip, user)].append(t)
    last_hit: dict[tuple, RuleHit] = {}
    for s in succ.itertuples():
        key = (s.ip, s.username)
        times = failures.get(key)
        if not times:
            continue
        hi = bisect_right(times, s.timestamp)
        lo = bisect_left(times, s.timestamp - window)
        n = hi - lo
        if n < threshold:
            continue
        prev = last_hit.get(key)
        if prev is not None and times[lo] <= prev.end:      # same episode -> extend
            prev.end = s.timestamp
            continue
        h = RuleHit("R6", s.ip, times[lo], s.timestamp, n, [s.username], target_user=s.username, max_in_window=n,
                    detail=f"successful {s.event_type.split('_')[1].lower()} login for '{s.username}' after "
                           f"{n} failed attempts within {cfg['window_minutes']} min (threshold {threshold})",
                    points=int(cfg["points"]))
        hits.append(h)
        last_hit[key] = h
    return hits


def run_rules(df: pd.DataFrame, settings: dict) -> list[RuleHit]:
    rules = settings["rules"]
    att = attempts_frame(df)
    hits: list[RuleHit] = []
    if att.empty and not df["success"].any():
        return hits
    if rules["R1"]["enabled"]:
        hits += _per_ip_rule(att, "R1", rules["R1"])
    if rules["R2"]["enabled"]:
        hits += _per_ip_rule(att, "R2", rules["R2"])
    if rules["R3"]["enabled"]:
        hits += _per_ip_rule(att, "R3", rules["R3"], distinct_users=True)
    if rules["R4"]["enabled"]:
        hits += _per_ip_rule(att, "R4", rules["R4"], only_user="root")
    if rules["R5"]["enabled"]:
        hits += rule_r5(att, rules["R5"])
    if rules["R6"]["enabled"]:
        hits += rule_r6(att, df, rules["R6"])
    return sorted(hits, key=lambda h: (h.start, h.rule))


def hits_by_ip(hits: list[RuleHit]) -> dict[str, list[RuleHit]]:
    """R5 hits are attributed to every participating IP."""
    out = defaultdict(list)
    for h in hits:
        for ip in (h.ips if h.rule == "R5" else [h.ip]):
            out[ip].append(h)
    return out
