"""
Safe, read-only access to authentication logs.

  * files are opened in binary READ mode only - nothing is ever written, truncated, rotated or deleted
  * uploaded files: only .log / .txt, at most 50 MB, binary content rejected - no root privileges needed
  * system logs (/var/log/auth.log, /var/log/secure): only the most recent MAX_READ_BYTES are read;
    rotated .gz files can be read too
  * systemd journal: `journalctl` is run with a fixed argument list (no shell, no user input)
  * permission problems are explained instead of crashing
"""

from __future__ import annotations

import gzip
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

import config as C


class LogReadError(Exception):
    """A log could not be read; the message is safe to show to the user."""


@dataclass
class LogText:
    text: str
    source: str             # "upload: name", "/var/log/auth.log", "journalctl"
    size_bytes: int
    truncated: bool = False  # only the newest part of a large file was read


PERMISSION_HELP = (
    "Permission denied while reading {path}. Authentication logs are readable only by root and the 'adm' group "
    "(Debian/Ubuntu/Kali) or by root only (RHEL/CentOS). Options: (1) run the dashboard with sudo, "
    "(2) add your user to the adm group: `sudo usermod -aG adm $USER` then log out and in, or "
    "(3) copy the log and upload the copy: `sudo cp {path} ~/auth_copy.log && sudo chown $USER ~/auth_copy.log`. "
    "The program only reads the log; it never changes it."
)


def decode(data: bytes) -> str:
    return data.decode("utf-8", errors="replace")


def looks_binary(data: bytes) -> bool:
    sample = data[:8192]
    return b"\x00" in sample


# --------------------------------------------------------------------------- uploads
def read_upload(filename: str, data: bytes) -> LogText:
    ext = Path(filename or "").suffix.lower()
    if ext not in C.ALLOWED_UPLOAD_EXTENSIONS:
        raise LogReadError(f"Unsupported file type '{ext or 'none'}'. Upload a .log or .txt file.")
    if not data:
        raise LogReadError("The uploaded file is empty.")
    if len(data) > C.MAX_UPLOAD_BYTES:
        raise LogReadError(f"The file is larger than {C.MAX_UPLOAD_BYTES // (1024 * 1024)} MB. "
                           "Upload a smaller extract, e.g. `tail -n 200000 auth.log > part.log`.")
    if looks_binary(data):
        raise LogReadError("The file contains binary data - it does not look like a text log.")
    return LogText(decode(data), f"upload: {Path(filename).name}", len(data))


# --------------------------------------------------------------------------- files on disk
def read_log_file(path: str | Path, max_bytes: int | None = None) -> LogText:
    """Read a log file read-only. Large files: only the last max_bytes (starting at a full line)."""
    max_bytes = max_bytes or C.MAX_READ_BYTES
    p = Path(path)
    if not p.exists():
        raise LogReadError(f"{p} does not exist on this system. Debian/Ubuntu use /var/log/auth.log, "
                           "RHEL/CentOS use /var/log/secure; some systems keep authentication events only in "
                           "the systemd journal - use the journal option or upload a file instead.")
    if p.is_dir():
        raise LogReadError(f"{p} is a directory, not a log file.")
    try:
        if p.suffix == ".gz":
            with gzip.open(p, "rb") as fh:                # read-only
                data = fh.read(max_bytes + 1)
            truncated = len(data) > max_bytes
            data = data[:max_bytes]
            size = len(data)
        else:
            size = p.stat().st_size
            with open(p, "rb") as fh:                     # read-only, binary
                truncated = size > max_bytes
                if truncated:
                    fh.seek(size - max_bytes)
                    data = fh.read()
                    data = data[data.find(b"\n") + 1:]    # drop the partial first line
                else:
                    data = fh.read()
    except PermissionError as exc:
        raise LogReadError(PERMISSION_HELP.format(path=p)) from exc
    except (OSError, EOFError, gzip.BadGzipFile) as exc:
        raise LogReadError(f"{p} could not be read: {exc.__class__.__name__}") from exc
    if looks_binary(data):
        raise LogReadError(f"{p} contains binary data - it does not look like a text log.")
    return LogText(decode(data), str(p), size, truncated)


def available_system_logs() -> dict[str, dict]:
    """Which standard logs exist and whether this process can read them (no content is read)."""
    out = {}
    for label, path in C.SYSTEM_LOGS.items():
        p = Path(path)
        out[label] = {"path": path, "exists": p.exists(), "readable": p.exists() and os.access(p, os.R_OK)}
    return out


# --------------------------------------------------------------------------- systemd journal
def journal_available() -> bool:
    return shutil.which("journalctl") is not None


def read_journal(command: list[str] | None = None, timeout: int | None = None) -> LogText:
    """Export recent SSH/auth entries from the systemd journal (read-only)."""
    if not journal_available():
        raise LogReadError("journalctl is not installed on this system.")
    cmd = list(command or C.JOURNAL_COMMAND)
    try:
        res = subprocess.run(cmd, capture_output=True, timeout=timeout or C.JOURNAL_TIMEOUT, check=False,
                             shell=False)
    except subprocess.TimeoutExpired as exc:
        raise LogReadError("journalctl took too long to respond.") from exc
    except OSError as exc:
        raise LogReadError(f"journalctl could not be started: {exc.__class__.__name__}") from exc
    text = decode(res.stdout[: C.MAX_READ_BYTES])
    err = decode(res.stderr)
    if res.returncode != 0 and not text.strip():
        if "permission" in err.lower() or "not seeing messages" in err.lower():
            raise LogReadError("journalctl has no permission to show system messages. Run with sudo or add your "
                               "user to the 'systemd-journal' or 'adm' group.")
        raise LogReadError("journalctl returned an error: " + (err.strip()[:200] or f"exit code {res.returncode}"))
    lines = [ln for ln in text.splitlines() if not ln.startswith("-- ")]
    if not lines:
        raise LogReadError("The journal contains no SSH or authentication entries for the last 7 days"
                           + (" (" + err.strip()[:120] + ")" if err.strip() else "") + ".")
    return LogText("\n".join(lines), "journalctl", len(res.stdout), len(res.stdout) > C.MAX_READ_BYTES)
