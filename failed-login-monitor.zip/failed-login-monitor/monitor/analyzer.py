"""
Orchestrator: log text -> parse -> rules -> alerts -> IP table -> statistics -> AnalysisResult.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd

import config as C
from monitor.alert_manager import Alert, build_alerts
from monitor.detection_engine import RuleHit, attempts_frame, run_rules
from monitor.ip_analyzer import event_type_counts, ip_table, statistics, timeline, top_usernames
from monitor.log_parser import ParseResult, parse_log
from monitor.log_reader import LogText

DISCLAIMER = ("Risk scores are rule-based heuristic indicators, not validated probabilities of an attack. A flagged "
              "IP is not proven malicious - verify before acting. This tool never blocks IPs or changes any "
              "system configuration.")


@dataclass
class AnalysisResult:
    analysis_id: str
    analyzed_at: str
    source: str
    settings: dict
    parse: ParseResult
    events: pd.DataFrame
    hits: list = field(default_factory=list)          # [RuleHit]
    alerts: list = field(default_factory=list)        # [Alert]
    ips: pd.DataFrame = field(default_factory=pd.DataFrame)
    stats: dict = field(default_factory=dict)
    truncated: bool = False
    disclaimer: str = DISCLAIMER

    @property
    def severity_counts(self) -> dict:
        out = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
        for a in self.alerts:
            out[a.severity] += 1
        return out

    def alerts_frame(self) -> pd.DataFrame:
        cols = ["alert_id", "priority", "severity", "risk_score", "title", "source_ip", "target_usernames",
                "failed_count", "success_count", "rule_ids", "first_seen", "last_seen", "window_minutes"]
        rows = []
        for a in self.alerts:
            d = a.to_dict()
            d["target_usernames"] = ", ".join(a.target_usernames)
            rows.append({c: d[c] for c in cols})
        return pd.DataFrame(rows, columns=cols)

    def timeline(self, freq: str | None = None) -> pd.DataFrame:
        return timeline(self.events, freq)

    def top_usernames(self, n: int = 10) -> pd.DataFrame:
        return top_usernames(self.events, n)

    def event_types(self) -> pd.DataFrame:
        return event_type_counts(self.events)


def analyze_text(text: str, source: str = "text", settings: dict | None = None, truncated: bool = False
                 ) -> AnalysisResult:
    settings = settings or C.load_settings()
    parsed = parse_log(text, year=settings.get("assume_year"), max_lines=C.MAX_LINES)
    df = parsed.dataframe()
    hits: list[RuleHit] = run_rules(df, settings) if len(df) else []
    alerts: list[Alert] = build_alerts(hits, attempts_frame(df), df, settings) if hits else []
    info = {"total_lines": parsed.total_lines, "auth_lines": parsed.auth_lines,
            "malformed_lines": parsed.unrecognised_header, "other_lines": parsed.other_lines,
            "bad_timestamps": parsed.bad_timestamps, "formats": parsed.formats}
    return AnalysisResult(
        analysis_id="AN-" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4].upper(),
        analyzed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), source=source, settings=settings, parse=parsed,
        events=df, hits=hits, alerts=alerts, ips=ip_table(df, hits, settings["risk_thresholds"]),
        stats=statistics(df, info), truncated=truncated)


def analyze_log(log: LogText, settings: dict | None = None) -> AnalysisResult:
    return analyze_text(log.text, log.source, settings, log.truncated)
