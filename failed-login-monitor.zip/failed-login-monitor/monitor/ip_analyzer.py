"""
Per-IP summary and overall statistics.

An IP is never labelled 'malicious': it is 'Flagged for review' when a rule fired, otherwise 'Not flagged'.
Nothing is blocked.
"""

from __future__ import annotations

import pandas as pd

from monitor.detection_engine import RuleHit, hits_by_ip
from monitor.log_parser import EVENT_LABELS, classify_ip
from monitor.risk_scorer import classify, score_rules

IP_COLUMNS = ["ip", "ip_class", "failed_attempts", "usernames_targeted", "usernames", "first_seen", "last_seen",
              "successful_logins", "accepted_users", "risk_score", "risk_level", "status", "reason"]


def _join_sorted(values) -> str:
    return ", ".join(sorted(set(values)))[:300]


def ip_table(df: pd.DataFrame, hits: list[RuleHit], thresholds: dict) -> pd.DataFrame:
    """One row per source IP, built with vectorised group-by aggregations (fast for thousands of IPs)."""
    with_ip = df[df["ip"] != ""]
    if with_ip.empty:
        return pd.DataFrame(columns=IP_COLUMNS)
    att = with_ip[with_ip["counts_as_attempt"]]
    ok = with_ip[with_ip["success"]]
    out = pd.DataFrame(index=pd.Index(sorted(set(with_ip["ip"])), name="ip"))
    out["failed_attempts"] = att.groupby("ip").size()
    out["usernames_targeted"] = att.groupby("ip")["username"].nunique()
    out["usernames"] = att.groupby("ip")["username"].agg(_join_sorted)
    times = with_ip.groupby("ip")["timestamp"].agg(["min", "max"])
    out["first_seen"], out["last_seen"] = times["min"], times["max"]
    out["successful_logins"] = ok.groupby("ip").size()
    out["accepted_users"] = ok.groupby("ip")["username"].agg(_join_sorted)
    out[["failed_attempts", "usernames_targeted", "successful_logins"]] = \
        out[["failed_attempts", "usernames_targeted", "successful_logins"]].fillna(0).astype(int)
    out[["usernames", "accepted_users"]] = out[["usernames", "accepted_users"]].fillna("")
    out = out.reset_index()
    out["ip_class"] = out["ip"].map(classify_ip)

    scores, reasons = {}, {}
    for ip, ip_hits in hits_by_ip(hits).items():
        best: dict[str, RuleHit] = {}
        for h in ip_hits:
            if h.rule not in best or h.max_in_window > best[h.rule].max_in_window:
                best[h.rule] = h
        scores[ip] = score_rules({r: h.points for r, h in best.items()})
        reasons[ip] = "; ".join(f"{r}: {h.detail}" for r, h in sorted(best.items()))
    out["risk_score"] = out["ip"].map(scores).fillna(0).astype(int)
    out["risk_level"] = out["risk_score"].map(lambda v: classify(int(v), thresholds))
    out["status"] = out["ip"].map(lambda ip: "Flagged for review" if ip in reasons else "Not flagged")
    out["reason"] = [reasons.get(ip) or ("Below all detection thresholds" if n else "Only successful logins")
                     for ip, n in zip(out["ip"], out["failed_attempts"])]
    out = out[IP_COLUMNS]
    return out.sort_values(["risk_score", "failed_attempts", "ip"], ascending=[False, False, True]).reset_index(drop=True)


def statistics(df: pd.DataFrame, parse_info: dict) -> dict:
    att = df[df["counts_as_attempt"]]
    ok = df[df["success"]]
    ts = df["timestamp"].dropna()
    return {
        **parse_info,
        "events": len(df), "failed_attempts": len(att), "failed_events": int(df["failed"].sum()),
        "successful_logins": len(ok), "unique_ips": df.loc[df["ip"] != "", "ip"].nunique(),
        "unique_failed_ips": att.loc[att["ip"] != "", "ip"].nunique(),
        "usernames_targeted": att["username"].nunique(), "local_failures": int((att["ip"] == "").sum()),
        "invalid_user_attempts": int(att["invalid_user"].sum()),
        "root_attempts": int((att["username"] == "root").sum()),
        "first_event": ts.min() if len(ts) else None, "last_event": ts.max() if len(ts) else None,
        "hosts": sorted(set(df["hostname"])),
    }


def top_usernames(df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    att = df[df["counts_as_attempt"]]
    vc = att["username"].replace("", "(empty)").value_counts().head(n)
    return pd.DataFrame({"username": vc.index, "failed_attempts": vc.values})


def event_type_counts(df: pd.DataFrame) -> pd.DataFrame:
    vc = df["event_type"].value_counts()
    return pd.DataFrame({"event_type": [EVENT_LABELS.get(e, e) for e in vc.index], "events": vc.values})


def timeline(df: pd.DataFrame, freq: str | None = None) -> pd.DataFrame:
    """Failed attempts and successful logins per time bucket (bucket chosen from the time span)."""
    d = df[df["timestamp"].notna()]
    if d.empty:
        return pd.DataFrame(columns=["time", "failed", "successful"])
    if freq is None:
        span = (d["timestamp"].max() - d["timestamp"].min()).total_seconds()
        freq = "1min" if span <= 3 * 3600 else "15min" if span <= 2 * 86400 else "1h" if span <= 14 * 86400 else "1D"
    t = d.set_index("timestamp")
    failed = t[t["counts_as_attempt"]].resample(freq).size()
    succ = t[t["success"]].resample(freq).size()
    out = pd.concat([failed.rename("failed"), succ.rename("successful")], axis=1, sort=True).fillna(0).astype(int)
    return out.reset_index().rename(columns={"timestamp": "time"})
