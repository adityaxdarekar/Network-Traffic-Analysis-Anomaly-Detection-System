"""
Alert generation.

Duplicate-alert avoidance, step 2: all rule hits of the same source IP that overlap in time or are closer than
`incident_gap_minutes` are merged into ONE incident -> one alert listing every rule it triggered.
Distributed attempts (R5) against one username become their own alert (source: several IPs).

Every alert gets a deterministic fingerprint (source + first event time + type), so analysing the same log
again (e.g. on refresh) updates the existing alert in history instead of creating a duplicate.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import timedelta

import pandas as pd

import config as C
from monitor.detection_engine import RuleHit
from monitor.log_parser import classify_ip
from monitor.risk_scorer import classify, priority, score_rules

RESPONSES = {
    "R1": ["Check whether the source IP belongs to a known user, scanner or monitoring system before acting.",
           "If it is not recognised, consider a temporary firewall block or fail2ban (manual, after review).",
           "Prefer SSH key authentication and disable password login (PasswordAuthentication no)."],
    "R2": ["Treat as an active brute-force attempt: review all activity from this IP.",
           "Rate-limit SSH (e.g. fail2ban, MaxStartups) and consider restricting SSH to known networks/VPN."],
    "R3": ["Many usernames from one source suggests username enumeration or a dictionary attack.",
           "Make sure default/unused accounts do not exist; restrict logins with AllowUsers/AllowGroups."],
    "R4": ["Disable direct root login over SSH (PermitRootLogin no) and use sudo instead."],
    "R5": ["The same account is targeted from several sources - possibly a distributed attack.",
           "Make sure this account uses a strong unique password or keys only; enable MFA where possible.",
           "Per-IP blocking alone is ineffective against distributed attempts; rely on account protection."],
    "R6": ["HIGH PRIORITY: confirm with the account owner whether this login was legitimate.",
           "Review the session: `last -i`, `who`, shell history, new files, running processes, ~/.ssh/authorized_keys.",
           "If not legitimate: lock the account, reset the password, revoke keys and follow incident response."],
}
GENERAL = "This tool does not block anything automatically - all responses are decisions for an administrator."


@dataclass
class Alert:
    alert_id: str
    fingerprint: str
    alert_type: str              # BRUTE_FORCE / ENUMERATION / ROOT_ATTEMPTS / SUCCESS_AFTER_FAILURES / DISTRIBUTED
    title: str
    first_seen: pd.Timestamp
    last_seen: pd.Timestamp
    source_ip: str               # one IP, or "multiple (n)" for distributed alerts
    source_ips: list
    ip_class: str
    target_usernames: list
    failed_count: int
    success_count: int
    rules: list                  # [{"rule", "name", "detail", "points"}]
    risk_score: int
    severity: str                # LOW / MEDIUM / HIGH
    priority: str                # P1 / P2 / P3
    explanation: str
    recommended_response: list = field(default_factory=list)

    @property
    def rule_ids(self) -> list[str]:
        return [r["rule"] for r in self.rules]

    @property
    def window_minutes(self) -> float:
        return round((self.last_seen - self.first_seen).total_seconds() / 60, 1)

    def to_dict(self) -> dict:
        return {"alert_id": self.alert_id, "fingerprint": self.fingerprint, "alert_type": self.alert_type,
                "title": self.title, "first_seen": str(self.first_seen), "last_seen": str(self.last_seen),
                "window_minutes": self.window_minutes, "source_ip": self.source_ip, "source_ips": self.source_ips,
                "ip_class": self.ip_class, "target_usernames": self.target_usernames,
                "failed_count": self.failed_count, "success_count": self.success_count,
                "rules": self.rules, "rule_ids": ",".join(self.rule_ids), "risk_score": self.risk_score,
                "severity": self.severity, "priority": self.priority, "explanation": self.explanation,
                "recommended_response": self.recommended_response}


def _type_and_title(rules: set[str]) -> tuple[str, str]:
    if "R6" in rules:
        return "SUCCESS_AFTER_FAILURES", "SUCCESSFUL LOGIN AFTER REPEATED FAILURES - INVESTIGATE"
    if rules & {"R1", "R2"}:
        return "BRUTE_FORCE", "POSSIBLE SSH BRUTE-FORCE ATTACK"
    if "R3" in rules:
        return "ENUMERATION", "POSSIBLE USERNAME ENUMERATION"
    if "R4" in rules:
        return "ROOT_ATTEMPTS", "REPEATED ROOT LOGIN ATTEMPTS"
    return "DISTRIBUTED", "POSSIBLE DISTRIBUTED LOGIN ATTEMPTS"


def _fingerprint(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def _rule_rows(hits: list[RuleHit]) -> list[dict]:
    best: dict[str, RuleHit] = {}
    for h in hits:
        if h.rule not in best or h.max_in_window > best[h.rule].max_in_window:
            best[h.rule] = h
    return [{"rule": r, "name": C.RULE_NAMES[r], "detail": best[r].detail, "points": best[r].points}
            for r in sorted(best)]


def _responses(rules: set[str]) -> list[str]:
    out = []
    for r in ("R6", "R2", "R1", "R3", "R4", "R5"):
        if r in rules:
            out += [x for x in RESPONSES[r] if x not in out]
    return out + [GENERAL]


def build_alerts(hits: list[RuleHit], att: pd.DataFrame, df: pd.DataFrame, settings: dict) -> list[Alert]:
    gap = timedelta(minutes=float(settings.get("incident_gap_minutes", 15)))
    thresholds = settings["risk_thresholds"]
    alerts: list[Alert] = []
    succ = df[df["success"] & df["timestamp"].notna()]
    # performance: group once instead of filtering the whole table for every alert
    hit_ips = {h.ip for h in hits if h.rule != "R5"}
    att_by_ip = {ip: g for ip, g in att[att["ip"].isin(hit_ips)].groupby("ip", sort=False)}
    succ_by_ip = {ip: g for ip, g in succ[succ["ip"].isin(hit_ips)].groupby("ip", sort=False)}
    empty_att, empty_succ = att.iloc[0:0], succ.iloc[0:0]

    # ---- per-IP incidents (R1, R2, R3, R4, R6)
    per_ip: dict[str, list[RuleHit]] = {}
    for h in hits:
        if h.rule != "R5":
            per_ip.setdefault(h.ip, []).append(h)
    for ip, ip_hits in per_ip.items():
        ip_hits.sort(key=lambda h: h.start)
        groups: list[list[RuleHit]] = []
        for h in ip_hits:
            if groups and h.start <= max(x.end for x in groups[-1]) + gap:
                groups[-1].append(h)
            else:
                groups.append([h])
        for grp in groups:
            first, last = min(h.start for h in grp), max(h.end for h in grp)
            rules = {h.rule for h in grp}
            rows = _rule_rows(grp)
            score = score_rules({r["rule"]: r["points"] for r in rows})
            level = classify(score, thresholds)
            a_ip, s_ip = att_by_ip.get(ip, empty_att), succ_by_ip.get(ip, empty_succ)
            span = a_ip[(a_ip["timestamp"] >= first) & (a_ip["timestamp"] <= last)]
            span_succ = s_ip[(s_ip["timestamp"] >= first) & (s_ip["timestamp"] <= last)]
            users = sorted(set(span["username"]) | set(span_succ["username"]))
            atype, title = _type_and_title(rules)
            expl = (f"{len(span)} failed login attempts from {ip} between {first:%Y-%m-%d %H:%M:%S} and "
                    f"{last:%H:%M:%S} against {len(set(span['username']))} username(s). Triggered: "
                    + "; ".join(f"{r['rule']} {r['name']} ({r['detail']})" for r in rows) + ".")
            if "R6" in rules:
                ok = sorted(set(span_succ["username"]))
                expl += f" A SUCCESSFUL login followed for: {', '.join(ok)}."
            alerts.append(Alert("", _fingerprint(atype, ip, first), atype, title, first, last, ip, [ip],
                                classify_ip(ip), users, len(span), len(span_succ), rows, score, level,
                                priority(level, rules), expl, _responses(rules)))

    # ---- distributed incidents (R5)
    for h in [h for h in hits if h.rule == "R5"]:
        rows = _rule_rows([h])
        span_succ = succ[(succ["username"] == h.target_user) & succ["ip"].isin(h.ips)
                         & (succ["timestamp"] >= h.start) & (succ["timestamp"] <= h.end + gap)]
        score = score_rules({r["rule"]: r["points"] for r in rows})
        level = classify(score, thresholds)
        expl = (f"{h.failed_count} failed attempts for username '{h.target_user}' from {len(h.ips)} different "
                f"IP addresses ({', '.join(h.ips)}) between {h.start:%Y-%m-%d %H:%M:%S} and {h.end:%H:%M:%S}. "
                f"Each source alone may stay below the per-IP thresholds.")
        if len(span_succ):
            expl += f" {len(span_succ)} successful login(s) for this account from one of these IPs followed."
        alerts.append(Alert("", _fingerprint("DISTRIBUTED", h.target_user, h.start), "DISTRIBUTED",
                            "POSSIBLE DISTRIBUTED LOGIN ATTEMPTS", h.start, h.end, f"multiple ({len(h.ips)})",
                            h.ips, ", ".join(sorted({classify_ip(i) for i in h.ips})), [h.target_user],
                            h.failed_count, len(span_succ), rows, score, level,
                            priority(level, {"R6"} if len(span_succ) else set()), expl, _responses({"R5"})))

    alerts.sort(key=lambda a: (a.first_seen, a.source_ip))
    for n, a in enumerate(alerts, 1):
        a.alert_id = f"ALT-{n:04d}"
    return alerts
