# Linux Failed Login Detection and Brute-Force Attack Monitoring System Using Python

*College project report*

---

## Abstract
Brute-force and password-guessing attacks against SSH are among the most frequent attacks on Linux servers.
Every attempt leaves a trace in the authentication log, but the volume and variety of log entries make manual
review impractical. This project implements a Python system that reads Linux authentication logs safely,
parses six types of authentication events from different log formats, and detects suspicious behaviour with six
configurable time-window rules. The rules cover repeated and high-volume failures, attempts on many usernames,
attempts on the root account, distributed attempts on one account from several addresses, and a successful
login following repeated failures. Rule hits are merged into incidents, scored with a transparent point system,
classified into three severity levels and three priorities, and presented as explained alerts with recommended
responses. A Streamlit dashboard, a command-line interface with a live monitoring mode, an SQLite history with
investigation status, and PDF/CSV/JSON reports complete the system. The tool is strictly read-only: it never
modifies logs, never blocks addresses and uses no external services. It was verified with 134 automated tests and
four purpose-built sample logs whose scenarios were all detected as designed.

## 1. Introduction
Secure Shell (SSH) is the standard way to administer Linux systems remotely, and every SSH server reachable from a
network receives login attempts from automated tools that try common usernames and passwords. The OpenSSH daemon
and the PAM framework record each attempt through the system logger: Debian-based systems write to
`/var/log/auth.log`, Red Hat-based systems to `/var/log/secure`, and systems without a classic syslog daemon keep
the messages in the systemd journal.

A Security Operations Center reviews this information to answer a few key questions. Who is trying to log in?
How often, and how fast? Against which accounts? Did any attempt succeed? This project automates those questions
for a single host, in a way that is explainable and safe to use for students and administrators.

## 2. Problem statement
Authentication logs are large, noisy and inconsistent:
- A single password guess can produce up to three log lines, so naive counting overstates the attack.
- Formats differ (classic syslog without a year vs ISO 8601 timestamps; `sshd` vs `sshd-session`; IPv4 vs IPv6;
  rsyslog's "message repeated" compression).
- The meaningful patterns depend on **time** (how many attempts within how many minutes), **variety** (how many
  usernames, how many sources) and **sequence** (success after failures). These are hard to see by reading.
- Tools that block automatically can lock out legitimate users, and reading logs requires privileges that must
  be handled carefully.

The problem is to build a tool that parses these logs reliably, counts attempts correctly, detects brute-force
patterns with configurable rules, explains its alerts, and stays read-only.

## 3. Existing system
- **Manual review** with `grep "Failed password" /var/log/auth.log | sort | uniq -c`: quick, but it counts lines rather
  than attempts, ignores time windows and gives no explanation or history.
- **`lastb`, `last`, `faillog`:** list failed or successful logins, but provide no correlation or detection logic.
- **fail2ban:** blocks IP addresses automatically after a number of failures. It is effective, but its purpose is
  prevention rather than analysis or reporting, and automatic blocking needs careful configuration.
- **SIEM platforms** (e.g. Wazuh, Splunk, Elastic): powerful, but heavyweight to deploy and learn for a single
  server or a student lab.

The gap is a lightweight, explainable analysis tool that sits between `grep` and a full SIEM.

## 4. Proposed system
A modular Python application that:
1. reads logs read-only from uploads, standard log files, rotated `.gz` files or the systemd journal;
2. parses each line into a structured event, marking which lines count as failed attempts;
3. applies six configurable sliding-window rules and merges hits into incidents;
4. scores and classifies each incident and explains it with evidence and recommended responses;
5. summarises every source IP, with IP classification;
6. stores analyses and alerts without duplicates and tracks their investigation status;
7. presents everything in a dashboard, a command-line interface (including live monitoring) and reports.

## 5. Objectives
1. Safe, permission-aware log reading that never modifies logs and needs no root for uploaded files.
2. Robust parsing of failed password, invalid user, authentication failure, failed publickey, accepted password and
   accepted publickey events, including timestamp, host, user, IPv4/IPv6 address, port, service and raw line.
3. Correct counting of attempts per IP, per user and per time window.
4. Detection of repeated, high-volume, multi-username, root, distributed and success-after-failure activity.
5. Rule-based risk scoring with configurable thresholds and a clear explanation of every alert.
6. Suspicious-IP identification and classification without labelling addresses as malicious.
7. Dashboard, history and downloadable reports.

## 6. Scope
**In scope:** OpenSSH, PAM and sudo authentication messages in Debian/Ubuntu/Kali and RHEL/CentOS/Fedora logs and
the systemd journal; analysis of one log at a time (with live re-reading in watch mode); single-user local
dashboard.

**Out of scope:** blocking or firewall changes; other services' logs (web, mail, FTP); Windows event logs; external
threat intelligence; multi-host correlation; machine-learning detection.

## 7. Hardware requirements
| Component | Minimum | Recommended |
|---|---|---|
| Processor | 64-bit dual core | quad core |
| RAM | 2 GB | 4 GB (large logs are held in memory) |
| Storage | 300 MB | 1 GB for history and reports |
| Display | 1280 × 720 | 1920 × 1080 |

## 8. Software requirements
| Software | Version |
|---|---|
| Operating system | Ubuntu 22.04+/Debian/Kali, CentOS/RHEL/Fedora (uploaded logs can be analysed on any OS) |
| Python | 3.11 or newer |
| Streamlit / Plotly | ≥ 1.50 / ≥ 5.18 |
| pandas | ≥ 2.0 |
| ReportLab / matplotlib | ≥ 4.0 / ≥ 3.7 |
| SQLite | bundled with Python |
| pytest, pypdf | for testing |
| OpenSSH server | optional, to produce real log entries in a lab |

## 9. System architecture
```
           ┌────────────────────────────────────────────────────────────┐
 sources   │ upload (.log/.txt) · /var/log/auth.log · /var/log/secure · │
           │ rotated .gz · journalctl (fixed command, no shell)          │
           └──────────────────────────┬─────────────────────────────────┘
                                      │ Log Reader (read-only, size limits, permission help)
                                      ▼
                         Log Parser  →  events (pandas DataFrame)
                                      │
                         Detection Engine (R1–R6, sliding windows, bursts)
                                      │ rule hits
             ┌────────────────────────┼────────────────────────┐
             ▼                        ▼                        ▼
   Alert Manager + Risk Scorer   IP Analyzer             Statistics / timeline
   (incidents, score, severity,  (per-IP table,
    priority, explanation)        classification)
             └────────────────────────┼────────────────────────┘
                                      ▼ AnalysisResult
        Streamlit dashboard · CLI (analyze / watch) · SQLite history · PDF / CSV / JSON reports
```

## 10. Module descriptions
| Module | Description |
|---|---|
| `config.py` | Rule thresholds, windows and points, risk levels, incident gap, assumed year, limits, settings persistence and validation. |
| `monitor/log_reader.py` | Reads uploads (type, size, emptiness and binary checks), log files (binary read-only mode, newest 50 MB, `.gz`) and the journal (`subprocess.run` with a fixed list, `shell=False`). Converts permission and missing-file errors into explanations. |
| `monitor/log_parser.py` | Regular expressions for classic syslog and ISO 8601 headers and for each sshd/PAM message; IP normalisation and classification with `ipaddress`; year inference and rollover; expansion of "message repeated"; attempt de-duplication; malformed-line accounting. |
| `monitor/detection_engine.py` | Implements R1–R6 with two-pointer sliding windows (count-based, distinct-username, per-IP-qualified for R5) and binary search for R6; merges qualifying windows into bursts; only examines candidates that can reach a threshold. |
| `monitor/risk_scorer.py` | Score = sum of distinct rule points, capped at 100; severity and priority. |
| `monitor/alert_manager.py` | Groups each IP's hits into incidents, builds alerts with explanation, evidence, recommended response and a deterministic fingerprint; separate distributed-attack alerts. |
| `monitor/ip_analyzer.py` | Vectorised per-IP summary, statistics, timeline, top usernames, event-type counts. |
| `monitor/analyzer.py` | Orchestrates the pipeline and returns an `AnalysisResult`. |
| `database/db_manager.py` | SQLite schema, upsert of alerts, links between analyses and alerts, alert status, filters, statistics, CSV. |
| `reports/*` | PDF report (ReportLab + matplotlib) and CSV/JSON/ZIP exports. |
| `dashboard/*`, `app.py` | Nine Streamlit pages. |
| `cli.py` | `analyze`, `system`, `journal` and `watch` commands. |

## 11. Algorithms
**Algorithm 1 – Attempt de-duplication**
```
for each event e:
    if e is FAILED_PASSWORD or FAILED_PUBLICKEY: e.counts ← true
    if e is INVALID_USER or AUTH_FAILURE:
        e.counts ← not exists FAILED_* event with same (host, pid, ip)        # same SSH connection
ACCEPTED_* events never count as failures
```

**Algorithm 2 – Sliding-window burst detection (R1, R2, R3, R4)**
```
for each source IP with at least T candidate attempts (or T distinct usernames):
    sort attempts by time; left ← 0
    for right in 0..n-1:
        add attempt[right] (for R3 also update the username counter)
        while time[right] − time[left] > W: remove attempt[left]; left ← left+1
        value ← right−left+1   (R3: number of distinct usernames)
        if value ≥ T: mark range [left, right]
    merge overlapping marked ranges (and touching ranges no more than W apart) into bursts
    each burst → one rule hit (first, last, attempts, usernames, strongest window)
```
The time complexity is O(n) per IP after sorting.

**Algorithm 3 – Distributed attempts (R5)**
```
for each username with ≥ T IPs that each have ≥ m attempts in total:
    slide a window W over that username's attempts; keep per-IP counts and the number q of IPs with count ≥ m
    (q is updated incrementally when a count crosses m)
    if q ≥ T: mark the window → merge into bursts → hit listing the qualifying IPs
```

**Algorithm 4 – Success after failures (R6)**
```
index failed-attempt times by (ip, user) for pairs that also have a successful login
for each successful login s at time t:
    n ← number of failures for (s.ip, s.user) in [t − W, t]          # two binary searches
    if n ≥ T: hit (merged with a previous hit of the same pair if their failures overlap)
```

**Algorithm 5 – Incidents, scoring and classification**
```
for each IP: sort its hits by start; join hits whose start ≤ (latest end of the group + gap)
for each incident: rules ← distinct rules; score ← min(100, Σ points(rule))
severity ← HIGH if score ≥ 60, MEDIUM if score ≥ 30, else LOW
priority ← P1 if severity = HIGH or R6 ∈ rules; P2 if MEDIUM; else P3
fingerprint ← hash(type, ip or username, first event time)       # stable across re-analysis
```

## 12. Implementation
The system was written in Python (about 2,600 lines of application code and 860 lines of tests). Notable points:

- **Read-only by design.** Files are opened only in binary read mode; the journal is read through a fixed
  `journalctl` argument list without a shell. A test compares the SHA-256, size and modification time of a log
  before and after reading, and another scans the monitor package for write modes, deletions, firewall commands
  and `shell=True`.
- **Permissions.** Uploads need no privileges. For system logs, the program checks existence and readability and
  explains the three ways to get access (sudo, the `adm` group, or uploading a copy). This was tested with a real
  process running as the unprivileged user `nobody`.
- **Format robustness.** The header is matched with two patterns (syslog and ISO 8601), so mixed files work. During
  development, support was added for `keyboard-interactive/pam` messages (used with PAM and 2FA) and for the
  `sshd-session` process name used by recent OpenSSH versions.
- **Correctness issue found by testing.** The first burst-merging implementation merged ranges that were adjacent in
  the list of attempts even when they were hours apart in time, which joined two separate attacks. A test exposed
  this, and merging now also requires the gap between the ranges to be within the rule's window.
- **Performance.** A first stress test with a synthetic 200,000-line log did not finish within two minutes, because
  per-IP filtering of pandas tables was repeated for every one of over 100,000 IP addresses. The rules were
  changed to examine only candidate IPs that can reach a threshold, R6 was changed to binary search, R5 to
  incremental counting, and the IP table to vectorised group-by operations. The same log (136,442 IPs, 3,062
  alerts) then took 16 seconds, with identical results.
- **Duplicate-alert avoidance** works at two levels: bursts within a rule, and incidents across rules. Stored alerts
  are keyed by a fingerprint, so re-analysing a growing log updates alerts instead of duplicating them. This is
  also what makes the CLI `watch` mode print only new alerts.
- **Privacy and presentation.** Raw log lines are not stored in history by default. All log text is escaped in the
  dashboard and PDF, and users see friendly messages instead of stack traces.

## 13. Testing
134 automated pytest tests were run in the development environment (Ubuntu 24.04, Python 3.13): **134 passed** as
root. As a normal user the result is 133 passed and 1 skipped, because one test needs root to start a process as
another user. The code compiles on Python 3.11, 3.12 and 3.13.

| Area | Tests | Highlights |
|---|---|---|
| Parser | 50 | the brief's four example lines; all six event types; IPv6 normalisation; ISO 8601 variants; sudo; message repeated; seven kinds of line that must not add attempts; malformed lines; year rollover; IP classification (16 cases) |
| Log reader | 17 | upload validation; large files; .gz; log unchanged after reading; permission denied (mocked and real); journal command without shell; journal errors; no modifying code |
| Detection | 15 | each rule at and just below its threshold; window edges; negative R6 cases; configurability; disabled rules; burst merging |
| Alerts and scoring | 17 | thresholds; cap; priority; alert fields; incident merging and splitting; stable fingerprints; distributed alerts; IP table wording |
| Samples (end-to-end) | 5 | each sample log produces exactly the documented alerts and counts |
| Database and reports | 10 | no duplicate alerts on re-analysis; status; privacy default; SQL injection; exports; PDF |
| Dashboard and CLI | 20 | all pages; workflows; invalid input; settings re-analysis; history; CLI; live watch mode |

Dashboard tests use a stand-in for Streamlit, because Streamlit could not be installed in the development
environment. The page code therefore ran, but its visual appearance must be checked in a browser. The sandbox had
no `/var/log/auth.log` and an empty journal, so reading real system logs was verified only for the
"not present" and permission-denied paths. Reading a real auth.log should be checked on the target machine (see
the demo guide).

## 14. Results
Results with the default settings:

| Log | Lines | Counted failed attempts | Successful logins | Alerts |
|---|---|---|---|---|
| auth_normal.log | 51 | 2 | 10 | 0 |
| auth_attack.log | 401 | 92 | 11 | 5 (1 HIGH, 3 MEDIUM, 1 LOW; 2 × P1) |
| secure_rhel.log | 83 | 18 | 4 | 1 HIGH |
| auth_iso8601.log | 40 | 8 | 4 | 1 HIGH (P1) |

Scenario-level results for `auth_attack.log`:

| Scenario | Expected | Detected |
|---|---|---|
| Fast brute force, 40 attempts, 9 usernames incl. root | R1 R2 R3 R4 | R1 R2 R3 R4, score 85, HIGH, P1 |
| 6 failures, then accepted password for `deploy` | R1 R6 | R1 R6, score 45, MEDIUM, **P1** |
| `admin` from 4 IPs | R5 | R5, score 30, MEDIUM |
| 8 usernames with `Invalid user` only | R1 R3 | R1 R3, score 40, MEDIUM |
| IPv6 root attempts via "message repeated" | R4 | R4, score 15, LOW |
| Slow scanner, 1 attempt every 3 minutes | no alert | not flagged |
| Typing mistake followed by login | no alert | no alert |

In the attack log, the parser counted 92 attempts from about 200 failure-related lines, which shows that the
de-duplication works. Every planted scenario was detected as designed, and the two "benign" scenarios were not
flagged. These are results on synthetic logs written for this project; they demonstrate correct behaviour, not
real-world detection rates.

## 15. Advantages
- **Explainable:** each alert lists the rules, the evidence (e.g. "33 failed attempts within 5 minutes") and the points.
- **Safe:** read-only, no automatic blocking, no external services, no root needed for uploaded logs.
- **Accurate counting:** one password guess is one attempt, whatever number of lines it writes.
- **Configurable:** every threshold, window, point value and severity limit can be adjusted and re-applied instantly.
- **Practical:** handles real formats (syslog, ISO 8601, RHEL, journal, IPv6, rotated `.gz`), tracks alert status and
  can monitor a log live from the command line.
- **Efficient:** linear-time sliding windows; tested on a 200,000-line log.

## 16. Limitations
- Threshold rules can be evaded by very slow or highly distributed attacks, and can flag legitimate users who mistype often.
- Detection depends entirely on what sshd/PAM log; reduced logging or rotated-away logs hide activity.
- Unrecognised message formats are skipped, not interpreted.
- Syslog timestamps without a year rely on an assumed year; time zones are not converted.
- IP addresses may belong to shared infrastructure, so they are indicators, not identities.
- Scores are expert-chosen weights, not statistically calibrated; no large real-world evaluation was performed.

## 17. Future scope
- Opt-in reputation and geolocation lookups; scheduled monitoring with notifications.
- Additional services (web, mail, FTP) and Windows Security event logs.
- Per-user behavioural baselines (usual hours, usual source networks).
- Multi-host collection and correlation; export to SIEM formats.
- Optional administrator-approved integration with fail2ban or firewall rules.

## 18. Conclusion
The project delivers a working, explainable brute-force detection system for Linux authentication logs. It parses
real-world log formats robustly, counts attempts correctly, detects six attack patterns with configurable sliding
windows, and turns them into prioritised alerts with clear explanations and recommended responses. A dashboard,
a command-line interface with live monitoring, a history with investigation tracking and professional reports
make it a practical model of a SOC workflow. Strict read-only operation keeps it safe to run on the systems it
observes, and the automated tests and documented sample scenarios show that it behaves as designed.

## 19. References
1. OpenBSD Project. *sshd(8)* and *sshd_config(5)* manual pages (LogLevel, MaxAuthTries, PermitRootLogin, PasswordAuthentication). https://man.openbsd.org/
2. Linux-PAM. *pam_unix(8)* manual page. https://man7.org/linux/man-pages/man8/pam_unix.8.html
3. Gerhards, R. *RFC 5424: The Syslog Protocol*. IETF, 2009; Lonvick, C. *RFC 3164: The BSD syslog Protocol*. IETF, 2001.
4. systemd. *journalctl(1)* manual page. https://www.freedesktop.org/software/systemd/man/journalctl.html
5. MITRE ATT&CK. *T1110 Brute Force* (T1110.001 Password Guessing, T1110.003 Password Spraying, T1110.004 Credential Stuffing). https://attack.mitre.org/techniques/T1110/
6. NIST. *SP 800-92: Guide to Computer Security Log Management*. 2006.
7. Center for Internet Security. *CIS Benchmarks for Ubuntu Linux / Red Hat Enterprise Linux* (SSH server configuration). https://www.cisecurity.org/cis-benchmarks
8. Python Software Foundation. `re`, `ipaddress`, `sqlite3`, `subprocess`, `gzip` documentation. https://docs.python.org/3/
9. pandas, Streamlit and ReportLab documentation. https://pandas.pydata.org/docs/ · https://docs.streamlit.io/ · https://docs.reportlab.com/
