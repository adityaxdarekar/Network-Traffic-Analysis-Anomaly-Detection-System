"""CSV / JSON exports of one analysis (no raw log lines unless explicitly requested)."""

from __future__ import annotations

import io
import json
import re
import zipfile
from datetime import datetime


def stamp_name(kind: str, source: str, ext: str) -> str:
    base = re.sub(r"[^A-Za-z0-9]+", "_", source.replace("upload:", "")).strip("_")[:40] or "log"
    return f"{kind}_{base}_{datetime.now():%Y%m%d_%H%M%S}.{ext}"


def alerts_csv(r) -> str:
    rows = []
    for a in r.alerts:
        d = a.to_dict()
        rows.append({k: d[k] for k in ("alert_id", "priority", "severity", "risk_score", "title", "source_ip",
                                       "ip_class", "failed_count", "success_count", "rule_ids", "first_seen",
                                       "last_seen", "window_minutes", "explanation")}
                    | {"target_usernames": ", ".join(a.target_usernames),
                       "recommended_response": " | ".join(a.recommended_response)})
    import pandas as pd
    return pd.DataFrame(rows).to_csv(index=False)


def ips_csv(r) -> str:
    return r.ips.to_csv(index=False)


def events_csv(r, include_raw: bool = False) -> str:
    cols = ["line_no", "timestamp", "hostname", "service", "event_type", "username", "ip", "port", "invalid_user",
            "counts_as_attempt"] + (["raw"] if include_raw else [])
    return r.events[cols].to_csv(index=False)


def to_json(r) -> str:
    stats = {k: (str(v) if k in ("first_event", "last_event") else v) for k, v in r.stats.items()}
    return json.dumps({"analysis_id": r.analysis_id, "analyzed_at": r.analyzed_at, "source": r.source,
                       "statistics": stats, "severity_counts": r.severity_counts,
                       "alerts": [a.to_dict() for a in r.alerts],
                       "suspicious_ips": json.loads(r.ips[r.ips["status"] == "Flagged for review"]
                                                    .to_json(orient="records", date_format="iso")),
                       "settings": r.settings, "disclaimer": r.disclaimer}, indent=2, default=str)


def zip_bundle(r) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("alerts.csv", alerts_csv(r))
        z.writestr("ip_summary.csv", ips_csv(r))
        z.writestr("events.csv", events_csv(r))
        z.writestr("analysis.json", to_json(r))
    return buf.getvalue()
