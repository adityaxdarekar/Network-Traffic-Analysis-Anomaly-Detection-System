"""
PDF security report (ReportLab + matplotlib charts), built from a real AnalysisResult.

Sections: 1 Executive summary · 2 Log source and parsing · 3 Detection rules and thresholds ·
4 Activity timeline · 5 Security alerts · 6 Alert details and recommended response ·
7 Suspicious IP addresses · 8 Hardening recommendations · 9 Notes and limitations
"""

from __future__ import annotations

import io
from pathlib import Path
from xml.sax.saxutils import escape

import matplotlib

matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import (CondPageBreak, Image, KeepTogether, Paragraph, SimpleDocTemplate,  # noqa: E402
                                Spacer, Table, TableStyle)

import config as C  # noqa: E402
from reports.export_manager import stamp_name  # noqa: E402

NAVY = colors.HexColor("#0b1f3a")
BLUE = colors.HexColor("#2563eb")
LIGHT = colors.HexColor("#f1f5f9")
BORDER = colors.HexColor("#cbd5e1")
TEXT = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#64748b")
SEV_BG = {"HIGH": colors.HexColor("#fee2e2"), "MEDIUM": colors.HexColor("#fef3c7"), "LOW": colors.HexColor("#dcfce7")}
SEV_FG = {k: colors.HexColor(v) for k, v in C.RISK_COLORS.items()}
PAGE_W, PAGE_H = A4
MARGIN = 1.7 * cm
WIDTH = PAGE_W - 2 * MARGIN
HARDENING = [
    "Use SSH key authentication and disable password login (PasswordAuthentication no) where possible.",
    "Disable direct root login (PermitRootLogin no); administrators use sudo.",
    "Restrict who may log in (AllowUsers / AllowGroups) and which networks may reach SSH (firewall, VPN).",
    "Rate-limit authentication (MaxAuthTries, MaxStartups) and consider fail2ban after reviewing its policy.",
    "Enable multi-factor authentication for remote access.",
    "Review alerts regularly and verify any successful login that followed failures.",
    "Keep logs: make sure rsyslog/journald retention covers your investigation needs.",
]

ST = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=18, leading=22, textColor=NAVY),
    "sub": ParagraphStyle("sub", fontName="Helvetica", fontSize=9.5, leading=13, textColor=MUTED, spaceAfter=8),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=13, leading=17, textColor=NAVY, spaceBefore=12,
                         spaceAfter=6),
    "h3": ParagraphStyle("h3", fontName="Helvetica-Bold", fontSize=10.5, leading=14, textColor=BLUE, spaceBefore=8,
                         spaceAfter=3),
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.2, leading=13, textColor=TEXT, spaceAfter=4),
    "small": ParagraphStyle("small", fontName="Helvetica", fontSize=7.8, leading=10.2, textColor=MUTED),
    "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=7.8, leading=9.8, textColor=TEXT),
    "wrap": ParagraphStyle("wrap", fontName="Helvetica", fontSize=7.8, leading=9.8, textColor=TEXT, wordWrap="CJK"),
    "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=7.8, leading=9.8, textColor=colors.white),
    "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=9, leading=12.5, textColor=TEXT, leftIndent=12,
                             bulletIndent=2, spaceAfter=2),
}


def esc(v, limit=500) -> str:
    s = "-" if v is None or str(v) in ("", "NaT", "None", "nan") else str(v)
    return escape(s if len(s) <= limit else s[:limit] + "…")


def P(v, style="cell") -> Paragraph:
    return Paragraph(esc(v), ST[style])


def table(header, rows, widths, sev_col=None, wrap_cols=()):
    data = [[Paragraph(escape(h), ST["cellb"]) for h in header]] + \
           [[P(c, "wrap" if j in wrap_cols else "cell") for j, c in enumerate(r)] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if sev_col is not None:
        for i, r in enumerate(rows, 1):
            if r[sev_col] in SEV_BG:
                style.append(("BACKGROUND", (sev_col, i), (sev_col, i), SEV_BG[r[sev_col]]))
    t.setStyle(TableStyle(style))
    return t


def kv(rows, key_w=4.3 * cm):
    t = Table([[Paragraph(f"<b>{escape(k)}</b>", ST["cell"]), P(v, "wrap")] for k, v in rows],
              colWidths=[key_w, WIDTH - key_w])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t


def kpis(items):
    cells = [[Paragraph(f"<font size=15><b>{escape(str(v))}</b></font><br/><font color='#64748b' size=7.5>"
                        f"{escape(k)}</font>", ST["cell"]) for k, v in items]]
    t = Table(cells, colWidths=[WIDTH / len(items)] * len(items))
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.6, BORDER),
                           ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 7),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return t


def timeline_chart(r) -> Image | None:
    tl = r.timeline()
    if tl.empty:
        return None
    fig, ax = plt.subplots(figsize=(7.2, 2.4), dpi=150)
    width = (tl["time"].iloc[1] - tl["time"].iloc[0]) * 0.8 if len(tl) > 1 else None
    ax.bar(tl["time"], tl["failed"], width=width, color="#ef4444", label="Failed attempts")
    ax.bar(tl["time"], tl["successful"], width=width, bottom=tl["failed"], color="#22c55e", label="Successful logins")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b\n%H:%M"))
    ax.tick_params(labelsize=7)
    ax.set_ylabel("events", fontsize=7)
    ax.legend(fontsize=7, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return Image(buf, width=WIDTH, height=WIDTH * 2.4 / 7.2)


def _page(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, PAGE_H - 1.15 * cm, PAGE_W, 1.15 * cm, stroke=0, fill=1)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 8.5)
    canvas.drawString(MARGIN, PAGE_H - 0.75 * cm, "Failed Login & Brute-Force Monitoring Report")
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 0.75 * cm, doc.analysis_id)
    canvas.setFillColor(MUTED)
    canvas.drawString(MARGIN, 0.95 * cm, "Heuristic indicators - verify before acting. Nothing was blocked or changed.")
    canvas.drawRightString(PAGE_W - MARGIN, 0.95 * cm, f"Page {doc.page}")
    canvas.restoreState()


def build_story(r, analyst: str = "") -> list:
    s, sev = r.stats, r.severity_counts
    story = [Paragraph("Failed Login Detection and Brute-Force Monitoring Report", ST["title"]),
             Paragraph(f"{escape(C.APP_TITLE)} · v{C.APP_VERSION}", ST["sub"]),
             kv([("Analysis ID", r.analysis_id), ("Generated", r.analyzed_at), ("Log source", r.source),
                 ("Log period", f"{s['first_event']} → {s['last_event']}"), ("Hosts", ", ".join(s["hosts"])),
                 ("Prepared by", analyst or "-")]), Spacer(1, 8)]

    story.append(Paragraph("1. Executive summary", ST["h1"]))
    story.append(kpis([("Failed attempts", s["failed_attempts"]), ("Successful logins", s["successful_logins"]),
                       ("Source IPs", s["unique_ips"]), ("Alerts", len(r.alerts)), ("High", sev["HIGH"]),
                       ("Medium", sev["MEDIUM"]), ("Low", sev["LOW"])]))
    flagged = r.ips[r.ips["status"] == "Flagged for review"] if not r.ips.empty else r.ips
    p1 = [a for a in r.alerts if a.priority == "P1"]
    text = (f"The log contained {s['total_lines']:,} lines with {s['events']:,} authentication events: "
            f"{s['failed_attempts']:,} failed login attempts and {s['successful_logins']:,} successful logins from "
            f"{s['unique_ips']} source IP address(es). {len(r.alerts)} alert(s) were generated and {len(flagged)} IP "
            f"address(es) were flagged for review. ")
    if p1:
        text += f"{len(p1)} alert(s) have priority P1 and should be investigated first"
        if any("R6" in a.rule_ids for a in p1):
            text += ", including a successful login that followed repeated failures"
        text += "."
    elif not r.alerts:
        text += "No activity exceeded the configured detection thresholds."
    story += [Spacer(1, 6), Paragraph(escape(text), ST["body"]), Paragraph(escape(r.disclaimer), ST["small"])]

    story.append(CondPageBreak(6 * cm))
    story.append(Paragraph("2. Log source and parsing", ST["h1"]))
    fmts = ", ".join(f"{k}: {v:,}" for k, v in s["formats"].items()) or "-"
    story.append(kv([("Source", r.source + (" (newest part only - file truncated)" if r.truncated else "")),
                     ("Lines read", f"{s['total_lines']:,}"), ("Authentication events", f"{s['events']:,}"),
                     ("Timestamp formats", fmts), ("Other (non-auth) lines", f"{s['other_lines']:,}"),
                     ("Malformed lines skipped", f"{s['malformed_lines']:,}"),
                     ("Events without valid timestamp", f"{s['bad_timestamps']:,}"),
                     ("Invalid-user attempts", f"{s['invalid_user_attempts']:,}"),
                     ("Attempts on root", f"{s['root_attempts']:,}"),
                     ("Local failures (no IP, e.g. sudo)", f"{s['local_failures']:,}")]))
    story.append(Paragraph("Failed attempts are counted once per guess: a guess that writes 'Invalid user', a PAM "
                           "'authentication failure' and a 'Failed password' line is one attempt. The log was only "
                           "read, never modified.", ST["small"]))

    story.append(CondPageBreak(6 * cm))
    story.append(Paragraph("3. Detection rules and thresholds", ST["h1"]))
    rows = []
    for rid, cfg in r.settings["rules"].items():
        cond = {"R1": f">= {cfg['threshold']} failed attempts from one IP in {cfg['window_minutes']} min",
                "R2": f">= {cfg['threshold']} failed attempts from one IP in {cfg['window_minutes']} min",
                "R3": f">= {cfg['threshold']} different usernames from one IP in {cfg['window_minutes']} min",
                "R4": f">= {cfg['threshold']} failed root attempts from one IP in {cfg['window_minutes']} min",
                "R5": f"one username from >= {cfg['threshold']} IPs (each >= {cfg.get('min_attempts_per_ip', 1)}) "
                      f"in {cfg['window_minutes']} min",
                "R6": f"success after >= {cfg['threshold']} failures (same user + IP) in {cfg['window_minutes']} min"}
        rows.append([rid, C.RULE_NAMES[rid], cond[rid], f"+{cfg['points']}", "on" if cfg["enabled"] else "off"])
    story.append(table(["Rule", "Name", "Condition", "Points", "Status"], rows,
                       [1.1 * cm, 4.6 * cm, WIDTH - 9.0 * cm, 1.5 * cm, 1.8 * cm]))
    t = r.settings["risk_thresholds"]
    story.append(Paragraph(f"Risk score = sum of the points of each different rule triggered (max 100). "
                           f"0-{int(t['MEDIUM']) - 1} LOW, {t['MEDIUM']}-{int(t['HIGH']) - 1} MEDIUM, {t['HIGH']}-100 "
                           "HIGH. Priority P1 = HIGH severity or any successful login after failures (R6).",
                           ST["small"]))

    story.append(CondPageBreak(7 * cm))
    story.append(Paragraph("4. Activity timeline", ST["h1"]))
    chart = timeline_chart(r)
    story.append(chart if chart else Paragraph("No timestamped events.", ST["body"]))
    tu = r.top_usernames(10)
    if not tu.empty:
        story.append(Paragraph("Most targeted usernames", ST["h3"]))
        story.append(table(["Username", "Failed attempts"], tu.values.tolist(), [6 * cm, 3 * cm]))

    story.append(CondPageBreak(5 * cm))
    story.append(Paragraph("5. Security alerts", ST["h1"]))
    if r.alerts:
        story.append(table(["ID", "Pri.", "Severity", "Score", "Alert", "Source IP", "Fails", "Rules", "First seen"],
                           [[a.alert_id, a.priority, a.severity, a.risk_score, a.title, a.source_ip, a.failed_count,
                             ",".join(a.rule_ids), str(a.first_seen)[:19]] for a in r.alerts],
                           [1.9 * cm, 0.9 * cm, 1.8 * cm, 1.2 * cm, 4.3 * cm, 2.6 * cm, 1.1 * cm, 1.7 * cm,
                            WIDTH - 15.5 * cm], sev_col=2, wrap_cols=(5,)))
    else:
        story.append(Paragraph("No alerts: no activity exceeded the configured thresholds.", ST["body"]))

    if r.alerts:
        story.append(CondPageBreak(9 * cm))
        story.append(Paragraph("6. Alert details and recommended response", ST["h1"]))
    for a in r.alerts:
        block = [Paragraph(f"{escape(a.alert_id)} · {escape(a.title)}", ST["h3"]),
                 kv([("Severity / score / priority", f"{a.severity} · {a.risk_score}/100 · {a.priority}"),
                     ("Source IP", f"{a.source_ip}" + (f" ({', '.join(a.source_ips)})" if len(a.source_ips) > 1
                                                      else "") + f" - {a.ip_class}"),
                     ("Target usernames", ", ".join(a.target_usernames)),
                     ("Failed attempts / successes", f"{a.failed_count} / {a.success_count}"),
                     ("Time window", f"{a.first_seen} → {a.last_seen} ({a.window_minutes} min)"),
                     ("Explanation", a.explanation)])]
        block.append(table(["Rule", "Name", "Evidence", "Points"],
                           [[x["rule"], x["name"], x["detail"], f"+{x['points']}"] for x in a.rules],
                           [1.1 * cm, 4.6 * cm, WIDTH - 7.1 * cm, 1.4 * cm]))
        block += [Paragraph(esc(x), ST["bullet"], bulletText="•") for x in a.recommended_response]
        story.append(KeepTogether(block))

    story.append(CondPageBreak(6 * cm))
    story.append(Paragraph("7. Suspicious IP addresses", ST["h1"]))
    if len(flagged):
        story.append(table(["IP", "Class", "Fails", "Users", "First / last seen", "OK", "Score", "Risk", "Reason"],
                           [[x.ip, x.ip_class, x.failed_attempts, x.usernames_targeted,
                             f"{str(x.first_seen)[:19]} - {str(x.last_seen)[11:19]}", x.successful_logins,
                             x.risk_score, x.risk_level, x.reason] for x in flagged.itertuples()],
                           [2.6 * cm, 1.7 * cm, 1.2 * cm, 1.3 * cm, 2.6 * cm, 0.8 * cm, 1.2 * cm, 1.8 * cm,
                            WIDTH - 13.2 * cm], sev_col=7, wrap_cols=(0,)))
    else:
        story.append(Paragraph("No IP address was flagged.", ST["body"]))
    others = r.ips[r.ips["status"] != "Flagged for review"] if not r.ips.empty else r.ips
    if len(others):
        story.append(Paragraph(f"{len(others)} other source IP(s) stayed below all thresholds (e.g. "
                               + escape(", ".join(others["ip"].head(6))) + "). Repeated failures alone do not make "
                               "an IP malicious.", ST["small"]))

    story.append(CondPageBreak(6 * cm))
    story.append(Paragraph("8. Hardening recommendations", ST["h1"]))
    story += [Paragraph(escape(x), ST["bullet"], bulletText="•") for x in HARDENING]
    story.append(Paragraph("9. Notes and limitations", ST["h1"]))
    for x in [r.disclaimer,
              "Detection is based only on the supplied log; log formats differ between distributions and sshd versions.",
              "A source IP may belong to a shared network (NAT, VPN, proxy, cloud provider) - attributing activity "
              "to a person or organisation needs further investigation.",
              "No external IP reputation services were queried; all analysis ran locally."]:
        story.append(Paragraph(escape(x), ST["bullet"], bulletText="•"))
    return story


def generate_pdf_bytes(r, analyst: str = "") -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=1.8 * cm,
                            bottomMargin=1.6 * cm, title="Failed Login Monitoring Report", author=C.APP_TITLE)
    doc.analysis_id = r.analysis_id
    doc.build(build_story(r, analyst), onFirstPage=_page, onLaterPages=_page)
    return buf.getvalue()


def generate_pdf_report(r, output_path: Path | str | None = None, analyst: str = "") -> Path:
    path = Path(output_path) if output_path else C.REPORT_DIR / stamp_name("security_report", r.source, "pdf")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(generate_pdf_bytes(r, analyst))
    return path
