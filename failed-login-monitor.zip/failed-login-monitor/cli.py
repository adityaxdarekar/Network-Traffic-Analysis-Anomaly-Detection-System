"""
Command-line interface.

    python cli.py analyze samples/auth_attack.log            # analyse a file, print alerts
    python cli.py analyze samples/auth_attack.log --pdf report.pdf --csv alerts.csv
    sudo python cli.py system                                  # /var/log/auth.log or /var/log/secure
    sudo python cli.py journal                                 # systemd journal (no auth.log)
    sudo python cli.py watch /var/log/auth.log --interval 10   # live monitoring: prints NEW alerts only

All modes are read-only: logs are never modified and nothing is blocked.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from monitor.analyzer import AnalysisResult, analyze_log  # noqa: E402
from monitor.log_reader import LogReadError, read_journal, read_log_file  # noqa: E402

COLORS = {"HIGH": "\033[91m", "MEDIUM": "\033[93m", "LOW": "\033[92m"}
RESET = "\033[0m"


def color(text: str, level: str, enabled: bool) -> str:
    return f"{COLORS.get(level, '')}{text}{RESET}" if enabled else text


def print_alert(a, use_color: bool) -> None:
    print(color(f"\nALERT {a.alert_id} [{a.priority}] {a.title}", a.severity, use_color))
    print(f"  Source IP:        {a.source_ip}" + (f" ({', '.join(a.source_ips)})" if len(a.source_ips) > 1 else "")
          + f"  [{a.ip_class}]")
    print(f"  Target usernames: {', '.join(a.target_usernames)}")
    print(f"  Failed attempts:  {a.failed_count}   successful logins: {a.success_count}")
    print(f"  Time window:      {a.first_seen} -> {a.last_seen} ({a.window_minutes} min)")
    print(f"  Risk score:       {a.risk_score}/100  Severity: {a.severity}")
    for r in a.rules:
        print(f"  + {r['rule']} {r['name']} (+{r['points']}): {r['detail']}")
    print(f"  Response:         {a.recommended_response[0]}")


def print_summary(r: AnalysisResult, use_color: bool) -> None:
    s, sev = r.stats, r.severity_counts
    print(f"Source: {r.source}{' (newest part only)' if r.truncated else ''}")
    print(f"Lines {s['total_lines']:,} · auth events {s['events']:,} · failed attempts {s['failed_attempts']:,} · "
          f"successful logins {s['successful_logins']:,} · source IPs {s['unique_ips']} · malformed "
          f"{s['malformed_lines']}")
    print(f"Alerts: {len(r.alerts)} (HIGH {sev['HIGH']}, MEDIUM {sev['MEDIUM']}, LOW {sev['LOW']})")
    for a in r.alerts:
        print_alert(a, use_color)
    flagged = r.ips[r.ips["status"] == "Flagged for review"] if not r.ips.empty else r.ips
    if len(flagged):
        print("\nIPs flagged for review:")
        print(flagged[["ip", "ip_class", "failed_attempts", "usernames_targeted", "successful_logins", "risk_score",
                       "risk_level"]].to_string(index=False))
    print("\n" + r.disclaimer)


def export(r: AnalysisResult, args) -> None:
    if args.pdf:
        from reports.pdf_generator import generate_pdf_report
        print("PDF report:", generate_pdf_report(r, args.pdf))
    if args.csv:
        from reports.export_manager import alerts_csv
        Path(args.csv).write_text(alerts_csv(r), encoding="utf-8")
        print("Alerts CSV:", args.csv)
    if args.save:
        from database.db_manager import DatabaseManager
        print("Saved to history:", DatabaseManager().save_analysis(r))


def watch(path: str, interval: float, use_color: bool, max_cycles: int | None = None) -> int:
    """Re-read the log whenever it changes and print alerts that were not shown before."""
    settings = C.load_settings()
    seen: set[str] = set()
    last_sig = None
    cycles = 0
    print(f"Watching {path} every {interval}s (read-only). Press Ctrl+C to stop.")
    try:
        while max_cycles is None or cycles < max_cycles:
            cycles += 1
            try:
                st = Path(path).stat()
                sig = (st.st_size, st.st_mtime_ns)
                if sig != last_sig:
                    last_sig = sig
                    r = analyze_log(read_log_file(path), settings)
                    new = [a for a in r.alerts if a.fingerprint not in seen]
                    for a in new:
                        print_alert(a, use_color)
                        seen.add(a.fingerprint)
                    print(f"[{time.strftime('%H:%M:%S')}] {r.stats['failed_attempts']:,} failed attempts, "
                          f"{len(r.alerts)} alert(s), {len(new)} new", flush=True)
            except (LogReadError, OSError) as exc:
                print(f"[{time.strftime('%H:%M:%S')}] {exc}", flush=True)
            if max_cycles is None or cycles < max_cycles:
                time.sleep(interval)
    except KeyboardInterrupt:
        print("\nStopped.")
    return 0


def main(argv=None) -> int:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--no-color", action="store_true", help="plain output without colours")
    p = argparse.ArgumentParser(description=C.APP_TITLE)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze", help="analyse a log file", parents=[common])
    a.add_argument("file")
    s = sub.add_parser("system", help="analyse /var/log/auth.log or /var/log/secure", parents=[common])
    s.add_argument("--log", help="explicit log path")
    sub.add_parser("journal", help="analyse SSH entries from the systemd journal", parents=[common])
    for x in (a, s, sub.choices["journal"]):
        x.add_argument("--pdf", help="write a PDF report")
        x.add_argument("--csv", help="write alerts as CSV")
        x.add_argument("--save", action="store_true", help="store the analysis in the history database")
    w = sub.add_parser("watch", help="monitor a log file and print new alerts", parents=[common])
    w.add_argument("file", nargs="?")
    w.add_argument("--interval", type=float, default=10.0)
    args = p.parse_args(argv)
    use_color = sys.stdout.isatty() and not args.no_color

    try:
        if args.cmd == "watch":
            path = args.file or next((v for v in C.SYSTEM_LOGS.values() if Path(v).exists()), None)
            if not path:
                print("No system log found - pass a file path.")
                return 2
            return watch(path, args.interval, use_color)
        if args.cmd == "analyze":
            log = read_log_file(args.file)
        elif args.cmd == "system":
            path = args.log or next((v for v in C.SYSTEM_LOGS.values() if Path(v).exists()), None)
            if not path:
                print("Neither /var/log/auth.log nor /var/log/secure exists. Try: python cli.py journal")
                return 2
            log = read_log_file(path)
        else:
            log = read_journal()
    except LogReadError as exc:
        print(f"Error: {exc}")
        return 1
    r = analyze_log(log, C.load_settings())
    print_summary(r, use_color)
    export(r, args)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:          # output piped into e.g. `head` - exit quietly
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        sys.exit(0)
