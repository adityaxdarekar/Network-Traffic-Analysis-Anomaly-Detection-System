"""
SQLite storage (output/monitor_history.db): analyses (scan history), alerts and per-IP summaries.

  * alerts are UPSERTED by fingerprint: analysing the same log again (or a log that has grown) updates the
    existing alert (last_seen, counts, score) instead of creating a duplicate
  * raw log lines are NOT stored unless settings["store_raw_events"] is enabled
  * parameterised SQL only
"""

from __future__ import annotations

import io
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

import config as C

SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    analysis_id TEXT PRIMARY KEY, analyzed_at TEXT NOT NULL, source TEXT, total_lines INTEGER,
    events INTEGER, failed_attempts INTEGER, successful_logins INTEGER, unique_ips INTEGER,
    alerts INTEGER, high INTEGER, medium INTEGER, low INTEGER, first_event TEXT, last_event TEXT,
    malformed_lines INTEGER, settings_json TEXT, stats_json TEXT, raw_events TEXT
);
CREATE TABLE IF NOT EXISTS alerts (
    fingerprint TEXT PRIMARY KEY, alert_id TEXT, analysis_id TEXT, first_detected TEXT, updated_at TEXT,
    alert_type TEXT, title TEXT, first_seen TEXT, last_seen TEXT, source_ip TEXT, source_ips TEXT,
    ip_class TEXT, target_usernames TEXT, failed_count INTEGER, success_count INTEGER, rule_ids TEXT,
    risk_score INTEGER, severity TEXT, priority TEXT, explanation TEXT, details_json TEXT,
    status TEXT DEFAULT 'Open', times_seen INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS ip_summary (
    analysis_id TEXT, ip TEXT, ip_class TEXT, failed_attempts INTEGER, usernames_targeted INTEGER,
    first_seen TEXT, last_seen TEXT, successful_logins INTEGER, risk_score INTEGER, risk_level TEXT,
    status TEXT, reason TEXT, PRIMARY KEY (analysis_id, ip)
);
CREATE TABLE IF NOT EXISTS alert_links (
    analysis_id TEXT, fingerprint TEXT, PRIMARY KEY (analysis_id, fingerprint)
);
CREATE INDEX IF NOT EXISTS idx_alerts_analysis ON alerts(analysis_id);
"""
ALERT_STATUSES = ["Open", "Investigating", "Resolved", "False positive"]


class DatabaseError(RuntimeError):
    pass


def _s(v) -> str | None:
    return None if v is None or (isinstance(v, float) and pd.isna(v)) or v is pd.NaT else str(v)


class DatabaseManager:
    def __init__(self, path: Path | str | None = None):
        self.path = Path(path or C.DB_PATH)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._conn() as con:
                con.executescript(SCHEMA)
        except (OSError, sqlite3.Error) as exc:
            raise DatabaseError(f"Cannot open the database at {self.path}: {exc}") from exc

    @contextmanager
    def _conn(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        finally:
            con.close()

    # ------------------------------------------------------------------ write
    def save_analysis(self, r, store_raw: bool = False) -> dict:
        """Returns {"new_alerts": n, "updated_alerts": n}."""
        s, sev = r.stats, r.severity_counts
        stats = {k: (str(v) if k in ("first_event", "last_event") else v) for k, v in s.items()}
        raw = r.events[["line_no", "raw"]].to_json(orient="records") if store_raw else None
        new = upd = 0
        with self._conn() as con:
            con.execute("INSERT OR REPLACE INTO analyses VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (r.analysis_id, r.analyzed_at, r.source, s["total_lines"], s["events"], s["failed_attempts"],
                         s["successful_logins"], s["unique_ips"], len(r.alerts), sev["HIGH"], sev["MEDIUM"],
                         sev["LOW"], _s(s["first_event"]), _s(s["last_event"]), s["malformed_lines"],
                         json.dumps(r.settings), json.dumps(stats, default=str), raw))
            for a in r.alerts:
                d = a.to_dict()
                row = con.execute("SELECT times_seen FROM alerts WHERE fingerprint = ?", (a.fingerprint,)).fetchone()
                values = (a.alert_id, r.analysis_id, r.analyzed_at, a.alert_type, a.title, str(a.first_seen),
                          str(a.last_seen), a.source_ip, ", ".join(a.source_ips), a.ip_class,
                          ", ".join(a.target_usernames), a.failed_count, a.success_count, d["rule_ids"],
                          a.risk_score, a.severity, a.priority, a.explanation, json.dumps(d, default=str))
                if row:
                    upd += 1
                    con.execute("UPDATE alerts SET alert_id=?, analysis_id=?, updated_at=?, alert_type=?, title=?, "
                                "first_seen=?, last_seen=?, source_ip=?, source_ips=?, ip_class=?, target_usernames=?, "
                                "failed_count=?, success_count=?, rule_ids=?, risk_score=?, severity=?, priority=?, "
                                "explanation=?, details_json=?, times_seen=times_seen+1 WHERE fingerprint=?",
                                values + (a.fingerprint,))
                else:
                    new += 1
                    con.execute("INSERT INTO alerts (alert_id, analysis_id, updated_at, alert_type, title, first_seen, "
                                "last_seen, source_ip, source_ips, ip_class, target_usernames, failed_count, "
                                "success_count, rule_ids, risk_score, severity, priority, explanation, details_json, "
                                "first_detected, fingerprint) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                values + (r.analyzed_at, a.fingerprint))
                con.execute("INSERT OR IGNORE INTO alert_links VALUES (?, ?)", (r.analysis_id, a.fingerprint))
            for row in r.ips.itertuples():
                con.execute("INSERT OR REPLACE INTO ip_summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                            (r.analysis_id, row.ip, row.ip_class, row.failed_attempts, row.usernames_targeted,
                             _s(row.first_seen), _s(row.last_seen), row.successful_logins, row.risk_score,
                             row.risk_level, row.status, row.reason))
        return {"new_alerts": new, "updated_alerts": upd}

    def set_alert_status(self, fingerprint: str, status: str) -> None:
        if status not in ALERT_STATUSES:
            raise ValueError(f"status must be one of {ALERT_STATUSES}")
        with self._conn() as con:
            con.execute("UPDATE alerts SET status = ? WHERE fingerprint = ?", (status, fingerprint))

    def delete_analysis(self, analysis_id: str) -> None:
        with self._conn() as con:
            con.execute("DELETE FROM analyses WHERE analysis_id = ?", (analysis_id,))
            con.execute("DELETE FROM ip_summary WHERE analysis_id = ?", (analysis_id,))
            con.execute("DELETE FROM alert_links WHERE analysis_id = ?", (analysis_id,))
            # alerts that no remaining analysis refers to are removed as well
            con.execute("DELETE FROM alerts WHERE fingerprint NOT IN (SELECT fingerprint FROM alert_links)")

    def clear(self) -> None:
        with self._conn() as con:
            con.executescript("DELETE FROM analyses; DELETE FROM alerts; DELETE FROM ip_summary; "
                              "DELETE FROM alert_links;")

    # ------------------------------------------------------------------ read
    def list_analyses(self) -> pd.DataFrame:
        with self._conn() as con:
            rows = [dict(r) for r in con.execute(
                "SELECT analysis_id, analyzed_at, source, total_lines, events, failed_attempts, successful_logins, "
                "unique_ips, alerts, high, medium, low, first_event, last_event, malformed_lines FROM analyses "
                "ORDER BY analyzed_at DESC, rowid DESC")]
        return pd.DataFrame(rows)

    def list_alerts(self, severity: str | None = None, status: str | None = None, ip: str = "") -> pd.DataFrame:
        sql = ("SELECT alert_id, fingerprint, analysis_id, first_detected, updated_at, priority, severity, risk_score, "
               "title, source_ip, target_usernames, failed_count, success_count, rule_ids, first_seen, last_seen, "
               "status, times_seen FROM alerts")
        cond, args = [], []
        if severity:
            cond.append("severity = ?")
            args.append(severity)
        if status:
            cond.append("status = ?")
            args.append(status)
        if ip:
            cond.append("(source_ip LIKE ? OR source_ips LIKE ?)")
            args += [f"%{ip}%", f"%{ip}%"]
        if cond:
            sql += " WHERE " + " AND ".join(cond)
        sql += " ORDER BY updated_at DESC, first_seen"
        with self._conn() as con:
            return pd.DataFrame([dict(r) for r in con.execute(sql, args)])

    def get_alert(self, fingerprint: str) -> dict | None:
        with self._conn() as con:
            row = con.execute("SELECT * FROM alerts WHERE fingerprint = ?", (fingerprint,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["details"] = json.loads(d.pop("details_json") or "{}")
        return d

    def get_analysis(self, analysis_id: str) -> dict | None:
        with self._conn() as con:
            row = con.execute("SELECT * FROM analyses WHERE analysis_id = ?", (analysis_id,)).fetchone()
            if not row:
                return None
            d = dict(row)
            d["ips"] = pd.DataFrame([dict(r) for r in con.execute(
                "SELECT * FROM ip_summary WHERE analysis_id = ? ORDER BY risk_score DESC, failed_attempts DESC",
                (analysis_id,))])
            d["alerts"] = pd.DataFrame([dict(r) for r in con.execute(
                "SELECT a.alert_id, a.fingerprint, a.priority, a.severity, a.risk_score, a.title, a.source_ip, "
                "a.target_usernames, a.failed_count, a.success_count, a.rule_ids, a.first_seen, a.last_seen, a.status "
                "FROM alerts a JOIN alert_links l ON l.fingerprint = a.fingerprint WHERE l.analysis_id = ? "
                "ORDER BY a.first_seen", (analysis_id,))])
        d["stats"] = json.loads(d.pop("stats_json") or "{}")
        d["settings"] = json.loads(d.pop("settings_json") or "{}")
        return d

    def stats(self) -> dict:
        with self._conn() as con:
            a = con.execute("SELECT COUNT(*), COALESCE(SUM(failed_attempts),0) FROM analyses").fetchone()
            sev = dict(con.execute("SELECT severity, COUNT(*) FROM alerts GROUP BY severity").fetchall())
            open_ = con.execute("SELECT COUNT(*) FROM alerts WHERE status IN ('Open','Investigating')").fetchone()[0]
        return {"analyses": a[0], "failed_attempts": a[1], "alerts": sum(sev.values()), "open_alerts": open_,
                "HIGH": sev.get("HIGH", 0), "MEDIUM": sev.get("MEDIUM", 0), "LOW": sev.get("LOW", 0)}

    def export_alerts_csv(self) -> str:
        buf = io.StringIO()
        df = self.list_alerts()
        (df.drop(columns=["fingerprint"]) if not df.empty else df).to_csv(buf, index=False)
        return buf.getvalue()
