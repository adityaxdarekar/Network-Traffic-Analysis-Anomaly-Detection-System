"""
process_tree.py - build the parent/child tree from a snapshot, evaluate the
parent-child rules and render the tree as text (terminal) or rows (dashboard).

A matching relationship is a lead to investigate, not proof of compromise:
admin scripts, installers and IDEs legitimately start shells.
"""
from __future__ import annotations

from collections import defaultdict

from .process_analyzer import Finding


class ProcessTree:
    def __init__(self, processes: list):
        self.by_pid = {p.pid: p for p in processes}
        self.children = defaultdict(list)
        self.roots = []
        for p in processes:
            if p.ppid in self.by_pid and p.ppid != p.pid:
                self.children[p.ppid].append(p.pid)
            else:
                self.roots.append(p.pid)
        for v in self.children.values():
            v.sort()
        self.roots.sort()

    def ancestors(self, pid: int, limit: int = 32) -> list:
        """Parent chain, nearest first (cycle-safe)."""
        chain, seen = [], {pid}
        cur = self.by_pid.get(pid)
        while cur and cur.ppid in self.by_pid and cur.ppid not in seen and len(chain) < limit:
            seen.add(cur.ppid)
            cur = self.by_pid[cur.ppid]
            chain.append(cur)
        return chain

    def descendants(self, pid: int) -> list:
        out, stack = [], list(self.children.get(pid, []))
        while stack:
            c = stack.pop()
            out.append(self.by_pid[c])
            stack.extend(self.children.get(c, []))
        return out

    def chain_text(self, pid: int) -> str:
        names = [f"{p.name}({p.pid})" for p in reversed(self.ancestors(pid))]
        me = self.by_pid.get(pid)
        if me:
            names.append(f"{me.name}({me.pid})")
        return " -> ".join(names)

    def render(self, highlight: dict | None = None, root: int | None = None, max_depth: int = 12,
               only_suspicious_branches: bool = False) -> str:
        """ASCII tree. highlight = {pid: severity}. Ancestors of flagged pids are marked too."""
        highlight = highlight or {}
        on_path = set()
        for pid in highlight:
            on_path.add(pid)
            on_path.update(a.pid for a in self.ancestors(pid))
        lines = []

        def walk(pid, prefix, last, depth):
            p = self.by_pid[pid]
            mark = f"  <== [{highlight[pid]}]" if pid in highlight else ("  (parent of flagged)" if pid in on_path else "")
            connector = "" if depth == 0 else ("└── " if last else "├── ")
            lines.append(f"{prefix}{connector}{p.name} [{p.pid}]{mark}")
            if depth >= max_depth:
                return
            kids = self.children.get(pid, [])
            if only_suspicious_branches:
                kids = [k for k in kids if k in on_path]
            for i, k in enumerate(kids):
                ext = "" if depth == 0 else ("    " if last else "│   ")
                walk(k, prefix + ext, i == len(kids) - 1, depth + 1)

        starts = [root] if root in self.by_pid else self.roots
        if only_suspicious_branches:
            starts = [r for r in starts if r in on_path]
        for r in starts:
            walk(r, "", True, 0)
        return "\n".join(lines)

    def rows(self) -> list[dict]:
        """Flat rows with depth for tables / treemaps."""
        out = []

        def walk(pid, depth):
            p = self.by_pid[pid]
            out.append({"pid": p.pid, "ppid": p.ppid, "name": p.name, "parent_name": p.parent_name,
                        "depth": depth, "children": len(self.children.get(pid, []))})
            for k in self.children.get(pid, []):
                walk(k, depth + 1)

        for r in self.roots:
            walk(r, 0)
        return out


class RelationshipAnalyzer:
    def __init__(self, rules: dict, analyzer=None):
        self.analyzer = analyzer       # optional ProcessAnalyzer, to match interpreter script names too
        self.rules = []
        for r in rules["parent_child_rules"]:
            self.rules.append({**r, "parents": {x.lower() for x in r["parents"]},
                               "children": {x.lower() for x in r["children"]}})

    def check(self, proc, tree: ProcessTree) -> list[Finding]:
        parent = tree.by_pid.get(proc.ppid)
        if not parent:
            return []
        pnames = {parent.name.lower()}
        sn = ""
        if self.analyzer:
            sn = self.analyzer.script_name(parent)
            if sn:
                pnames.add(sn)        # e.g. "python3 office_report.py" also matches as "office_report"
        cname = proc.name.lower()
        pdesc = f"{parent.name} running {sn}" if self.analyzer and sn else parent.name
        out = []
        for r in self.rules:
            if pnames & r["parents"] and cname in r["children"]:
                out.append(Finding("suspicious_parent_child", f"Suspicious parent-child: {r['name']}",
                                   r["description"] + " A relationship alone is not proof of malware.",
                                   f"parent {pdesc} (PID {parent.pid}) -> child {proc.name} (PID {proc.pid}); "
                                   f"chain: {tree.chain_text(proc.pid)}"))
        return out
