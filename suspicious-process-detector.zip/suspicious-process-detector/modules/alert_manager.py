"""
alert_manager.py - turn risk results into structured alerts.

  * Only processes with score >= alert_min_score raise alerts.
  * Deduplication: signature = (process name, executable path, set of scored
    rules). The same signature is not re-alerted within alert_cooldown
    seconds. A NEW rule firing (higher score) produces a new alert at once.
  * Alerts are stored in SQLite; analysts acknowledge them manually
    (ACKNOWLEDGED / FALSE_POSITIVE / RESOLVED). Nothing is done to the process.
"""
from __future__ import annotations

import threading
import time
import uuid
from datetime import datetime, timezone

from .settings import redact_cmdline


class AlertManager:
    def __init__(self, cfg: dict, db=None, logger=None):
        self.cfg, self.db, self.log = cfg, db, logger
        self._last: dict = {}           # signature -> (timestamp, score)
        self._lock = threading.Lock()
        self.listeners = []             # callables(alert) for real-time display
        self.suppressed = 0
        self.recent: list = []          # in-memory, newest last (bounded)

    def _signature(self, proc, result):
        rules = frozenset(r for r, p, _ in result.scored if p > 0)
        return (proc.name, proc.exe, rules)

    def evaluate(self, proc, result, session_id=None, now: float | None = None) -> dict | None:
        now = time.time() if now is None else now
        if result.score < self.cfg["alert_min_score"] or result.score <= 0:
            return None
        sig = self._signature(proc, result)
        with self._lock:
            last = self._last.get(sig)
            if last and now - last[0] < self.cfg["alert_cooldown"]:
                self.suppressed += 1
                return None
            self._last[sig] = (now, result.score)
        primary = next((c for _, p, c in result.scored if p > 0), "Suspicious process")
        ts = datetime.fromtimestamp(now, timezone.utc)
        alert = {
            "alert_id": f"SPD-{ts:%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:6].upper()}",
            "timestamp": ts.isoformat(timespec="seconds"),
            "session_id": session_id,
            "pid": proc.pid,
            "process_name": proc.name,
            "exe": proc.exe,
            "category": primary,
            "risk_score": result.score,
            "severity": result.severity,
            "description": f"{len(result.categories)} indicator(s): " + "; ".join(result.categories)
                           + ". Heuristic score - investigate before concluding.",
            "evidence": [f"{f.category}: {f.evidence}" for f in result.findings if f.evidence] +
                        [f"score: {result.explanation()}", f"cmdline (redacted): {redact_cmdline(proc.cmdline)[:300]}",
                         f"parent: {proc.parent_name or '?'} (PPID {proc.ppid}); user: {proc.username or '?'}"],
            "recommendations": result.recommendations,
            "status": "NEW",
        }
        if self.db:
            self.db.insert_alert(alert)
        if self.log:
            self.log.warning("ALERT %s [%s] score=%s pid=%s name=%s category=%s", alert["alert_id"], alert["severity"],
                             alert["risk_score"], proc.pid, proc.name, primary)
        with self._lock:
            self.recent.append(alert)
            del self.recent[:-500]
        for fn in list(self.listeners):
            try:
                fn(alert)
            except Exception:
                pass
        return alert

    def acknowledge(self, alert_id, status="ACKNOWLEDGED", analyst="", note="") -> bool:
        ok = self.db.set_alert_status(alert_id, status, analyst, note) if self.db else False
        if ok and self.log:
            self.log.info("alert %s marked %s by %s", alert_id, status, analyst or "analyst")
        return ok

    def prune(self, now: float | None = None):
        now = time.time() if now is None else now
        with self._lock:
            for k, (t, _) in list(self._last.items()):
                if now - t > max(self.cfg["alert_cooldown"] * 10, 600):
                    del self._last[k]
