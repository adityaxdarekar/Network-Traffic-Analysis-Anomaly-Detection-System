"""
risk_scorer.py - weighted, explainable risk score per process.

Rules:
  * Each rule (weight key) counts once per process, using the strongest
    weight_factor among its findings.
  * Findings marked requires_context (LOLBin names, CPU spikes) only score
    when at least one other scoring finding exists for the same process.
  * Final score is capped at 100.
  * Severity: 0-19 LOW, 20-39 MEDIUM, 40-69 HIGH, 70-100 CRITICAL
    (boundaries from config.risk_thresholds). A score of 0 is reported as
    NONE (nothing observed).

The score is a heuristic indicator of "how much should an analyst look at
this", NOT a probability that the process is malware.
"""
from __future__ import annotations

from dataclasses import dataclass, field

SEVERITIES = ["NONE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]

RECOMMENDATIONS = {
    "suspicious_name": "Verify the executable file location and its digital signature / package owner.",
    "lolbin_with_context": "Review the full command line and the parent process that launched this system tool.",
    "suspicious_cmdline": "Review the (redacted) command line; decode any encoded payload in an isolated environment.",
    "temp_directory_execution": "Verify why a program runs from a temp folder; check how the file got there.",
    "user_writable_execution": "Confirm the software is expected for this user and check its signature/vendor.",
    "hidden_directory_execution": "Inspect the hidden directory contents and how the program is started (autostart, cron).",
    "missing_executable": "Investigate why the executable is missing; capture memory/details before the process exits.",
    "masquerading": "Compare the path and hash with the genuine system binary; check the digital signature.",
    "elevated_unusual_location": "Investigate how a privileged process came to run from a user-writable path.",
    "suspicious_parent_child": "Investigate the parent process and the document/page/script that triggered the child.",
    "unknown_hash_untrusted_location": "Calculate and investigate the file hash with your threat-intelligence sources.",
    "known_bad_hash": "Treat as a likely compromise: isolate the endpoint if your incident process warrants it.",
    "hash_changed": "Check whether a software update explains the hash change (package manager logs).",
    "unusual_network": "Review associated network connections and the remote endpoints' reputation.",
    "high_resource": "Check what workload the process is doing at the time of the spike.",
    "sustained_high_cpu": "Confirm the workload is expected (build, encode, game); consider cryptomining if not.",
    "high_memory": "Confirm the memory use is expected for this application.",
    "high_thread_count": "Compare the thread count with normal behaviour for this application.",
    "rapid_process_creation": "Investigate the parent process and what it is launching repeatedly.",
}
GENERAL_ACTIONS = ["Perform an antivirus / EDR scan of the executable.",
                   "Isolate the endpoint only if the investigation confirms compromise.",
                   "Do not terminate the process until evidence (memory, files, connections) is collected."]


@dataclass
class RiskResult:
    score: int
    severity: str
    findings: list = field(default_factory=list)      # all Finding objects
    scored: list = field(default_factory=list)        # (rule, points, category)
    recommendations: list = field(default_factory=list)

    @property
    def categories(self) -> list:
        return [c for _, p, c in self.scored if p > 0]

    def explanation(self) -> str:
        if not self.scored:
            return "No scoring findings."
        return " + ".join(f"{c} ({p})" for _, p, c in self.scored) + f" = {self.score}" + \
            (" (capped at 100)" if sum(p for _, p, _ in self.scored) > 100 else "")

    def to_dict(self) -> dict:
        return {"score": self.score, "severity": self.severity, "explanation": self.explanation(),
                "findings": [f.to_dict() for f in self.findings],
                "scored": [{"rule": r, "points": p, "category": c} for r, p, c in self.scored],
                "recommendations": self.recommendations}


class RiskScorer:
    def __init__(self, cfg: dict):
        self.weights = cfg["risk_weights"]
        self.t = cfg["risk_thresholds"]

    def severity(self, score: int) -> str:
        if score <= 0:
            return "NONE"
        if score <= self.t["low"]:
            return "LOW"
        if score <= self.t["medium"]:
            return "MEDIUM"
        if score <= self.t["high"]:
            return "HIGH"
        return "CRITICAL"

    def score(self, findings: list) -> RiskResult:
        best: dict = {}     # rule -> (points, category, requires_context)
        for f in findings:
            pts = round(self.weights.get(f.rule, 0) * f.weight_factor)
            cur = best.get(f.rule)
            if cur is None or pts > cur[0]:
                best[f.rule] = (pts, f.category, f.requires_context and (cur is None or cur[2]))
        has_context = any(p > 0 and not rc for p, _, rc in best.values())
        scored = []
        for rule, (pts, cat, rc) in best.items():
            if rc and not has_context:
                pts = 0
            scored.append((rule, pts, cat + (" [needs context - not scored]" if rc and not has_context else "")))
        scored.sort(key=lambda x: -x[1])
        total = min(100, sum(p for _, p, _ in scored))
        recs = [RECOMMENDATIONS[r] for r, p, _ in scored if p > 0 and r in RECOMMENDATIONS]
        if total > 0:
            recs += GENERAL_ACTIONS
        return RiskResult(total, self.severity(total), findings, scored, list(dict.fromkeys(recs)))
