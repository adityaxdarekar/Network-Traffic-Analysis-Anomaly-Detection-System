"""
process_analyzer.py - static checks on a single process: name rules, command
line patterns, executable location, masquerading and missing executables.

Every check returns Finding objects. A Finding is EVIDENCE for an analyst,
not a verdict: names can collide, admins use dual-use tools, and software is
sometimes installed in odd places.
"""
from __future__ import annotations

import fnmatch
import ntpath
import posixpath
import re
from dataclasses import asdict, dataclass

from .settings import redact_cmdline


@dataclass
class Finding:
    rule: str            # weight key in config.risk_weights
    category: str        # human-readable detection category
    description: str     # what was observed and why it matters
    evidence: str = ""   # concrete values (already redacted)
    requires_context: bool = False   # LOLBin-style: only scores with other evidence
    weight_factor: float = 1.0       # e.g. 0.5 for loopback-only listeners

    def to_dict(self) -> dict:
        return asdict(self)


def _norm(path: str) -> str:
    return (path or "").replace("/", "\\").lower() if "\\" in (path or "") or re.match(r"^[a-zA-Z]:", path or "") \
        else (path or "").lower()


def _basename(path: str) -> str:
    return ntpath.basename(path) if "\\" in path else posixpath.basename(path)


def osa_distance(a: str, b: str) -> int:
    """Optimal-string-alignment edit distance (insert/delete/substitute/adjacent swap)."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[-1][-1]


class ProcessAnalyzer:
    def __init__(self, rules: dict):
        self.rules = rules
        self.name_index = {}
        for r in rules["name_rules"]:
            for n in r["names"]:
                self.name_index[n.lower()] = r
        self.cmd_patterns = [(re.compile(p["pattern"]), p["description"]) for p in rules["suspicious_cmdline_patterns"]]
        m = rules["masquerading"]
        self.system_bins = {k.lower(): [_norm(x) for x in v] for k, v in m["system_binaries"].items()}
        self.lookalike_max = int(m.get("lookalike_max_distance", 1))
        self.temp_locs = [_norm(x) for x in rules["suspicious_locations"]["temp"]]
        self.user_locs = [_norm(x) for x in rules["suspicious_locations"]["user_writable"]]
        self.trusted = [_norm(x) for x in rules["trusted_locations"]]
        self.interpreters = {x.lower() for x in rules.get("script_interpreters", [])}

    # ---------------------------------------------------------- locations
    @staticmethod
    def _match(path: str, patterns: list) -> str | None:
        for p in patterns:
            if ("*" in p and fnmatch.fnmatch(path, "*" + p + "*")) or ("*" not in p and p in path):
                return p
        return None

    def is_trusted_location(self, exe: str) -> bool:
        p = _norm(exe)
        return bool(p) and any(p.startswith(t) for t in self.trusted) and not self._match(p, self.temp_locs)

    def location_class(self, exe: str) -> str:
        """'trusted' | 'temp' | 'user_writable' | 'hidden' | 'other' | 'unknown'."""
        if not exe:
            return "unknown"
        p = _norm(exe)
        if self._match(p, self.temp_locs):
            return "temp"
        if self.is_trusted_location(exe):
            return "trusted"
        if self._match(p, self.user_locs):
            return "user_writable"
        sep = "\\" if "\\" in p else "/"
        parts = [x for x in p.split(sep)[:-1] if x]
        if any(x.startswith(".") and x not in (".", "..") for x in parts):
            return "hidden"
        return "other"

    # ---------------------------------------------------------- scripts
    def script_path(self, proc) -> str:
        """For interpreter processes (python, bash, wscript, powershell -File ...) return the script file
        being run, resolved against the process cwd. '' if none (e.g. python -c / -m, interactive shells)."""
        base = re.sub(r"(\.exe)$", "", proc.name.lower())
        base = re.sub(r"^(python)[\d.]*$", r"\1", base)
        if base not in self.interpreters or len(proc.cmdline) < 2:
            return ""
        args = proc.cmdline[1:]
        i = 0
        while i < len(args):
            a = args[i]
            low = a.lower()
            if low in ("-c", "-m", "-command", "-encodedcommand", "-e", "-enc", "/c", "-i"):
                return ""
            if low in ("-file", "-f") and i + 1 < len(args):
                return self._resolve(args[i + 1], proc.cwd)
            if a.startswith("-") or (a.startswith("/") and len(a) <= 3 and "\\" not in a and base in ("wscript", "cscript")):
                i += 1
                continue
            return self._resolve(a, proc.cwd)
        return ""

    @staticmethod
    def _resolve(path: str, cwd: str) -> str:
        if not path or path.startswith(("/", "\\")) or re.match(r"^[a-zA-Z]:", path):
            return path
        if not cwd:
            return path
        return (ntpath if "\\" in cwd else posixpath).normpath((ntpath if "\\" in cwd else posixpath).join(cwd, path))

    def script_name(self, proc) -> str:
        sp = self.script_path(proc)
        if not sp:
            return ""
        return re.sub(r"\.(py|pyw|js|vbs|ps1|sh|pl|rb)$", "", _basename(sp).lower())

    # ---------------------------------------------------------- checks
    def check_name(self, proc) -> list[Finding]:
        names = {proc.name.lower()}
        if proc.exe:
            names.add(_basename(proc.exe).lower())
        sn = self.script_name(proc)
        if sn:
            names.add(sn)
        for n in sorted(names):
            r = self.name_index.get(n)
            if r:
                return [Finding("lolbin_with_context" if r.get("context_required") else "suspicious_name",
                                r["category"], r["description"], f"process name: {proc.name}",
                                requires_context=bool(r.get("context_required")))]
        return []

    def check_cmdline(self, proc) -> list[Finding]:
        if not proc.cmdline:
            return []
        raw = " ".join(proc.cmdline)
        hits = [desc for rx, desc in self.cmd_patterns if rx.search(raw)]
        if not hits:
            return []
        excerpt = redact_cmdline(proc.cmdline)
        if len(excerpt) > 200:
            excerpt = excerpt[:200] + "..."
        return [Finding("suspicious_cmdline", "Suspicious command-line behaviour", "; ".join(hits),
                        f"cmdline (redacted): {excerpt}")]

    def check_path(self, proc) -> list[Finding]:
        out = []
        loc = self.location_class(proc.exe)
        if loc == "temp":
            out.append(Finding("temp_directory_execution", "Execution from temporary directory",
                               "Executable runs from a temporary folder; legitimate installers do this briefly, "
                               "malware droppers often do it persistently.", f"path: {proc.exe}"))
        elif loc == "user_writable":
            out.append(Finding("user_writable_execution", "Execution from user-writable location",
                               "Executable runs from Downloads/AppData-style folders that any user process can write.",
                               f"path: {proc.exe}"))
        elif loc == "hidden":
            out.append(Finding("hidden_directory_execution", "Execution from hidden directory",
                               "A folder in the executable path starts with '.', which hides it from normal listings. "
                               "Some developer tools install here legitimately.", f"path: {proc.exe}"))
        if proc.exe.startswith("/memfd:"):
            out.append(Finding("missing_executable", "Fileless execution (memfd)",
                               "The executable lives only in memory (memfd_create), with no file on disk. Used by some "
                               "sandboxes and runtimes, and by fileless malware to avoid disk scanning.",
                               f"path: {proc.exe}"))
        elif proc.exe_deleted:
            out.append(Finding("missing_executable", "Executable missing on disk",
                               "The process is running but its executable file has been deleted or replaced - "
                               "seen after software updates and also when malware removes its dropper.",
                               f"path: {proc.exe} (deleted)"))
        elif proc.exe and loc != "unknown" and _native(proc.exe) and not _exists(proc.exe):
            out.append(Finding("missing_executable", "Executable path not accessible",
                               "The reported executable path does not exist or cannot be read.", f"path: {proc.exe}"))
        script = self.script_path(proc)
        sloc = self.location_class(script) if script else "unknown"
        if script and sloc in ("temp", "user_writable", "hidden") and sloc != loc:
            label = {"temp": ("temp_directory_execution", "Script executed from temporary directory"),
                     "user_writable": ("user_writable_execution", "Script executed from user-writable location"),
                     "hidden": ("hidden_directory_execution", "Script executed from hidden directory")}[sloc]
            out.append(Finding(label[0], label[1],
                               f"The interpreter {proc.name} is running a script from a {sloc.replace('_', '-')} folder. "
                               f"The interpreter itself is legitimate; the script location is what is unusual.",
                               f"script: {script}; interpreter: {proc.exe}"))
            if loc not in ("temp", "user_writable", "hidden"):
                loc = sloc        # for the elevated check below
                where = f"script: {script}"
        where = locals().get("where") or f"path: {proc.exe}"
        elevated = (proc.username or "").lower() in ("root", "nt authority\\system", "system")
        if elevated and loc in ("temp", "user_writable", "hidden"):
            out.append(Finding("elevated_unusual_location", "Privileged process from unusual location",
                               "A root/SYSTEM process is running an executable from a location ordinary users can write.",
                               f"user: {proc.username}; {where}"))
        return out

    def check_masquerade(self, proc) -> list[Finding]:
        name = proc.name.lower()
        if not proc.exe:            # cannot judge without a readable path
            return []
        exe = _norm(proc.exe)
        if name in self.system_bins:
            expected = self.system_bins[name]
            if not any(exe.startswith(e) for e in expected):
                return [Finding("masquerading", "Possible process masquerading",
                                f"'{proc.name}' is a system process name but is not running from its usual location.",
                                f"path: {proc.exe}; expected under: {', '.join(expected)}")]
            return []
        for sysname in self.system_bins:
            if sysname.endswith(".exe") and len(sysname) >= 7 and name.endswith(".exe") \
                    and 0 < osa_distance(name, sysname) <= self.lookalike_max:
                return [Finding("masquerading", "Look-alike system process name",
                                f"'{proc.name}' differs from the system process '{sysname}' by one character.",
                                f"name: {proc.name}; path: {proc.exe}")]
        return []

    def analyze(self, proc) -> list[Finding]:
        out = []
        for check in (self.check_name, self.check_cmdline, self.check_path, self.check_masquerade):
            try:
                out.extend(check(proc))
            except Exception as exc:     # one broken check must not stop the scan
                out.append(Finding("info", "Analyzer error", f"{check.__name__} failed: {exc}", weight_factor=0))
        return out


def _native(path: str) -> bool:
    """True if the path style matches this OS (skip existence checks for foreign paths in tests)."""
    import os
    windows_style = "\\" in path or bool(re.match(r"^[a-zA-Z]:", path))
    return windows_style == (os.name == "nt")


def _exists(path: str) -> bool:
    import os
    try:
        return os.path.exists(path)
    except (OSError, ValueError):
        return False
