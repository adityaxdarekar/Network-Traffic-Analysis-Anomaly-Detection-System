"""
report_generator.py - investigation reports in HTML, JSON, CSV and PDF.

Report contents (in order):
  1 project title  2 monitoring start/end  3 operating system  4 hostname
  5 total processes monitored  6 suspicious processes  7 process details
  8 executable paths  9 SHA-256 hashes  10 parent-child relationships
  11 network connections  12 risk scores  13 security alerts
  14 recommended actions  15 final security assessment

All text placed in HTML is escaped; command lines are redacted before they
reach any report.
"""
from __future__ import annotations

import csv
import html
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from .database import utcnow
from .settings import redact_cmdline

TITLE = "Suspicious Process Detector - Endpoint Investigation Report"
DISCLAIMER = ("Risk scores are heuristic indicators of what deserves an analyst's attention. They are not malware "
              "probabilities, and no process, IP address or hash in this report has been confirmed malicious unless "
              "a reliable known-bad source is cited. No process was terminated or modified by this tool.")
SEV_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "NONE": 0}


def build_report_data(engine, max_processes: int = 400) -> dict:
    s = engine.snapshot()
    procs, results, tree = s["processes"], s["results"], s["tree"]
    sus = engine.session_suspicious()
    alerts = engine.db.alerts(session_id=engine.session_id)
    sev = Counter(a["severity"] for a in alerts)

    def pd(p):
        r = results.get(p.pid, {})
        res = r.get("result")
        return {"pid": p.pid, "ppid": p.ppid, "name": p.name, "parent_name": p.parent_name, "exe": p.exe,
                "username": p.username, "status": p.status,
                "created": datetime.fromtimestamp(p.create_time, timezone.utc).isoformat(timespec="seconds")
                if p.create_time else "",
                "cpu_percent": p.cpu_percent, "memory_percent": p.memory_percent, "threads": p.num_threads,
                "cmdline": redact_cmdline(p.cmdline)[:400], "sha256": r.get("sha256"), "location": r.get("location"),
                "risk_score": res.score if res else 0, "severity": res.severity if res else "NONE",
                "access_denied": p.access_denied}

    suspicious = []
    for p, r, chain, running in sus:
        res = r["result"]
        d = pd(p)
        d.update(sha256=r.get("sha256"), location=r.get("location"), risk_score=res.score, severity=res.severity,
                 explanation=res.explanation(), findings=[f.to_dict() for f in res.findings],
                 recommendations=res.recommendations, chain=chain, still_running=running)
        suspicious.append(d)

    rels = []
    for d in suspicious:
        for f in d["findings"]:
            if f["rule"] == "suspicious_parent_child":
                rels.append({"pid": d["pid"], "child": d["name"], "parent": d["parent_name"], "ppid": d["ppid"],
                             "rule": f["category"], "chain": d["chain"]})
    seen, hashes = set(), []
    for p in procs:
        sha = results.get(p.pid, {}).get("sha256")
        if sha and p.exe not in seen:
            seen.add(p.exe)
            hashes.append({"path": p.exe, "sha256": sha, "reputation": engine.hasher.reputation(sha),
                           "process": p.name})
    for d in suspicious:
        if d["sha256"] and d["exe"] not in seen:
            seen.add(d["exe"])
            hashes.insert(0, {"path": d["exe"], "sha256": d["sha256"], "process": d["name"],
                              "reputation": engine.hasher.reputation(d["sha256"])})
    all_p = sorted((pd(p) for p in procs), key=lambda d: (-d["risk_score"], d["pid"]))
    top = max((SEV_ORDER[d["severity"]] for d in suspicious), default=0)
    if any(a["severity"] in ("CRITICAL", "HIGH") for a in alerts):
        top = max(top, max(SEV_ORDER[a["severity"]] for a in alerts))
    assessment = {
        0: ("NO SUSPICIOUS ACTIVITY OBSERVED", "No process reached the alert threshold during monitoring. This does "
            "not prove the system is clean - only that these heuristics found nothing."),
        1: ("LOW RISK", "Only weak indicators were observed (e.g. one unusual location or listener). Review "
            "when convenient; these are frequently legitimate."),
        2: ("MEDIUM RISK - REVIEW RECOMMENDED", "One or more processes showed indicators worth an analyst's review. "
            "Verify the listed executables and their parents."),
        3: ("HIGH RISK - INVESTIGATE", "Several indicators combine on at least one process. Investigate promptly and "
            "collect evidence before taking any containment action."),
        4: ("CRITICAL - PRIORITY INVESTIGATION", "Strong combined indicators were observed. Follow your incident "
            "response process; isolate the endpoint only if the investigation confirms compromise."),
    }[top]
    recs = []
    for d in suspicious:
        recs.extend(d["recommendations"])
    recs = list(dict.fromkeys(recs)) or ["No action required beyond routine monitoring."]
    return {
        "title": TITLE,
        "generated": utcnow(),
        "monitoring_start": engine.started,
        "monitoring_end": engine.ended or utcnow(),
        "session_id": engine.session_id,
        "scans": s["scans"],
        "operating_system": engine.os,
        "hostname": engine.hostname,
        "total_processes": len(procs),
        "max_processes_seen": engine.max_total,
        "suspicious_count": len(suspicious),
        "suspicious_processes": suspicious,
        "process_details": all_p[:max_processes],
        "process_details_truncated": max(0, len(all_p) - max_processes),
        "executable_paths": sorted({(d["exe"], d["location"]) for d in all_p + suspicious if d["exe"]}),
        "hashes": hashes,
        "relationships": rels,
        "connections": [c.to_dict() for c in s["connections"]],
        "connection_status": s["conn_status"],
        "risk_distribution": dict(Counter(d["severity"] for d in all_p)),
        "alerts": alerts,
        "alert_counts": {k: sev.get(k, 0) for k in ("CRITICAL", "HIGH", "MEDIUM", "LOW")},
        "recommended_actions": recs,
        "assessment": {"level": assessment[0], "summary": assessment[1]},
        "disclaimer": DISCLAIMER,
        "thresholds": {k: engine.cfg[k] for k in ("monitoring_interval", "cpu_threshold", "cpu_duration_seconds",
                                                    "memory_threshold", "process_creation_threshold",
                                                    "process_creation_window", "alert_cooldown", "alert_min_score")},
    }


# ===================================================================== writers
def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def write_json(data: dict, out_dir: Path, name=None) -> Path:
    p = Path(out_dir) / "json" / (name or f"spd_report_{_stamp()}.json")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    return p


def write_csv(data: dict, out_dir: Path, name=None) -> list[Path]:
    base = Path(out_dir) / "csv"
    base.mkdir(parents=True, exist_ok=True)
    stem = name or f"spd_report_{_stamp()}"
    out = []
    specs = [("processes", data["process_details"],
              ["pid", "ppid", "name", "parent_name", "exe", "username", "cpu_percent", "memory_percent", "threads",
               "sha256", "location", "risk_score", "severity", "cmdline"]),
             ("alerts", data["alerts"],
              ["alert_id", "timestamp", "pid", "process_name", "exe", "category", "risk_score", "severity",
               "description", "status", "analyst", "analyst_note"]),
             ("connections", data["connections"],
              ["pid", "process_name", "protocol", "local_ip", "local_port", "remote_ip", "remote_port", "status",
               "remote_scope"])]
    for label, rows, cols in specs:
        p = base / f"{stem}_{label}.csv"
        with p.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                w.writerow({k: _csv_safe(r.get(k)) for k in cols})
        out.append(p)
    return out


def _csv_safe(v):
    """Neutralise spreadsheet formula injection from process names / paths."""
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


SEV_COLOR = {"CRITICAL": "#ef4444", "HIGH": "#f97316", "MEDIUM": "#eab308", "LOW": "#22c55e", "NONE": "#64748b"}


def write_html(data: dict, out_dir: Path, name=None) -> Path:
    e = lambda v: html.escape("" if v is None else str(v))   # noqa: E731
    sev = lambda s: f'<span class="sev" style="background:{SEV_COLOR.get(s, "#64748b")}">{e(s)}</span>'  # noqa: E731

    def table(cols, rows):
        head = "".join(f"<th>{e(c)}</th>" for c in cols)
        body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
        return f'<div class="tw"><table><thead><tr>{head}</tr></thead><tbody>{body or "<tr><td colspan=99>None</td></tr>"}</tbody></table></div>'

    ac = data["alert_counts"]
    sus_blocks = []
    for d in data["suspicious_processes"]:
        f_rows = [[e(f["category"]), e(f["evidence"]), e(f["description"])] for f in d["findings"]]
        sus_blocks.append(f"""
        <div class="card"><div class="ch">{sev(d['severity'])} <b>{e(d['name'])}</b> &middot; PID {e(d['pid'])}
        &middot; score <b>{e(d['risk_score'])}</b>/100 &middot; {'still running' if d['still_running'] else 'exited during monitoring'}</div>
        <p class="mono">{e(d['exe'] or '(path unavailable)')}</p>
        <p><b>Chain:</b> <span class="mono">{e(d['chain'])}</span></p>
        <p><b>User:</b> {e(d['username'])} &middot; <b>CPU</b> {e(d['cpu_percent'])}% &middot; <b>MEM</b> {e(d['memory_percent'])}%
        &middot; <b>Threads</b> {e(d['threads'])}</p>
        <p><b>Command line (redacted):</b> <span class="mono">{e(d['cmdline'])}</span></p>
        <p><b>SHA-256:</b> <span class="mono">{e(d['sha256'] or 'not available')}</span></p>
        <p><b>Score:</b> {e(d['explanation'])}</p>
        {table(['Finding', 'Evidence', 'Why it matters'], f_rows)}
        <p><b>Recommended:</b></p><ul>{''.join(f'<li>{e(r)}</li>' for r in d['recommendations'])}</ul></div>""")
    sections = [
        ("1-4. Monitoring summary", table(["Field", "Value"], [
            ["Project", e(data["title"])], ["Monitoring start (UTC)", e(data["monitoring_start"])],
            ["Monitoring end (UTC)", e(data["monitoring_end"])], ["Operating system", e(data["operating_system"])],
            ["Hostname", e(data["hostname"])], ["Scans", e(data["scans"])],
            ["Network visibility", e(data["connection_status"])]])),
        ("5-6. Totals", f"""<div class="stats">
            <div class="st"><b>{data['total_processes']}</b><span>processes (latest scan)</span></div>
            <div class="st"><b>{data['suspicious_count']}</b><span>suspicious this session (score &ge; {data['thresholds']['alert_min_score']})</span></div>
            <div class="st"><b style="color:#ef4444">{ac['CRITICAL']}</b><span>critical alerts</span></div>
            <div class="st"><b style="color:#f97316">{ac['HIGH']}</b><span>high alerts</span></div>
            <div class="st"><b style="color:#eab308">{ac['MEDIUM']}</b><span>medium alerts</span></div>
            <div class="st"><b style="color:#22c55e">{ac['LOW']}</b><span>low alerts</span></div></div>"""),
        ("6-7. Suspicious processes", "".join(sus_blocks) or "<p>No process reached the alert threshold.</p>"),
        ("7. Process details (all processes, latest scan)", table(
            ["PID", "PPID", "Name", "User", "CPU %", "MEM %", "Thr", "Score", "Severity"],
            [[e(d["pid"]), e(d["ppid"]), e(d["name"]), e(d["username"]), e(d["cpu_percent"]), e(d["memory_percent"]),
              e(d["threads"]), e(d["risk_score"]), sev(d["severity"])] for d in data["process_details"]])
            + (f"<p>{data['process_details_truncated']} more processes omitted (see JSON/CSV).</p>"
               if data["process_details_truncated"] else "")),
        ("8. Executable paths", table(["Path", "Location class"],
                                      [[f'<span class="mono">{e(p)}</span>', e(c)] for p, c in data["executable_paths"]])),
        ("9. SHA-256 hashes", "<p>Computed locally. Nothing was uploaded. 'unknown' = not in your known_hashes.json "
                              "lists, which is not evidence of malware.</p>" + table(
            ["Process", "Path", "SHA-256", "Reputation"],
            [[e(h["process"]), f'<span class="mono">{e(h["path"])}</span>', f'<span class="mono">{e(h["sha256"])}</span>',
              e(h["reputation"])] for h in data["hashes"]])),
        ("10. Parent-child relationships", table(["Parent (PPID)", "Child (PID)", "Rule", "Chain"],
            [[e(f"{r['parent']} ({r['ppid']})"), e(f"{r['child']} ({r['pid']})"), e(r["rule"]),
              f'<span class="mono">{e(r["chain"])}</span>'] for r in data["relationships"]])),
        ("11. Network connections", "<p>Remote scopes are address classes only; no IP is labelled malicious.</p>" +
            table(["PID", "Process", "Proto", "Local", "Remote", "Scope", "Status"],
                  [[e(c["pid"]), e(c["process_name"]), e(c["protocol"]), e(f"{c['local_ip']}:{c['local_port']}"),
                    e(f"{c['remote_ip']}:{c['remote_port']}" if c["remote_ip"] else ""), e(c["remote_scope"]),
                    e(c["status"])] for c in data["connections"][:500]])),
        ("12. Risk scores", table(["Severity", "Processes"], [[sev(k), e(v)] for k, v in sorted(
            data["risk_distribution"].items(), key=lambda kv: -SEV_ORDER.get(kv[0], 0))])
            + table(["PID", "Name", "Score", "Explanation"], [[e(d["pid"]), e(d["name"]), e(d["risk_score"]),
                                                             e(d["explanation"])] for d in data["suspicious_processes"]])),
        ("13. Security alerts", table(["Alert ID", "Time (UTC)", "Severity", "PID", "Process", "Category", "Score",
                                        "Status"],
            [[f'<span class="mono">{e(a["alert_id"])}</span>', e(a["timestamp"]), sev(a["severity"]), e(a["pid"]),
              e(a["process_name"]), e(a["category"]), e(a["risk_score"]), e(a["status"])] for a in data["alerts"]])),
        ("14. Recommended actions", "<ul>" + "".join(f"<li>{e(r)}</li>" for r in data["recommended_actions"])
         + "</ul><p>The detector never terminates processes, deletes files or changes configuration - every action "
           "above is for an analyst to take manually.</p>"),
        ("15. Final security assessment", f'<div class="assess"><h3>{e(data["assessment"]["level"])}</h3>'
                                          f'<p>{e(data["assessment"]["summary"])}</p><p class="disc">{e(data["disclaimer"])}</p></div>'),
    ]
    body = "".join(f"<section><h2>{e(t)}</h2>{c}</section>" for t, c in sections)
    doc = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SPD Investigation Report</title><style>
body{{margin:0;background:#0b1120;color:#e2e8f0;font:14px/1.5 system-ui,Segoe UI,Roboto,sans-serif}}
header{{padding:28px 32px;background:linear-gradient(135deg,#0f172a,#111c33);border-bottom:2px solid #f97316}}
header h1{{margin:0;font-size:22px}} header p{{margin:4px 0 0;color:#94a3b8}}
main{{max-width:1200px;margin:0 auto;padding:16px 24px 48px}}
section{{margin:22px 0}} h2{{font-size:16px;color:#fb923c;border-bottom:1px solid #1e293b;padding-bottom:6px}}
.tw{{overflow-x:auto}} table{{border-collapse:collapse;width:100%;font-size:12.5px}}
th{{background:#111827;color:#94a3b8;text-align:left;padding:6px 8px;position:sticky;top:0}}
td{{border-top:1px solid #1e293b;padding:5px 8px;vertical-align:top;word-break:break-word}}
.mono{{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:#cbd5e1}}
.sev{{display:inline-block;padding:1px 8px;border-radius:4px;color:#0b1120;font-weight:700;font-size:11px}}
.card{{background:#0f172a;border:1px solid #1e293b;border-left:4px solid #f97316;border-radius:8px;padding:12px 16px;margin:12px 0}}
.ch{{font-size:15px}} .stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}}
.st{{background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:12px}} .st b{{font-size:26px;display:block}}
.st span{{color:#94a3b8;font-size:12px}} .assess{{background:#0f172a;border:1px solid #f97316;border-radius:8px;padding:14px 18px}}
.disc{{color:#94a3b8;font-size:12px}}
</style></head><body><header><h1>{e(data['title'])}</h1>
<p>Host {e(data['hostname'])} &middot; {e(data['operating_system'])} &middot; generated {e(data['generated'])} UTC
&middot; session {e(data['session_id'])}</p></header><main>{body}</main></body></html>"""
    p = Path(out_dir) / "html" / (name or f"spd_report_{_stamp()}.html")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(doc, encoding="utf-8")
    return p


def write_pdf(data: dict, out_dir: Path, name=None) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    p = Path(out_dir) / "pdf" / (name or f"spd_report_{_stamp()}.pdf")
    p.parent.mkdir(parents=True, exist_ok=True)
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=17, textColor=colors.HexColor("#0f172a"))
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12.5, textColor=colors.HexColor("#c2410c"), spaceBefore=10)
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=8.6, leading=11)
    mono = ParagraphStyle("m", parent=body, fontName="Courier", fontSize=7.4, leading=9)
    e = lambda v: html.escape("" if v is None else str(v))   # noqa: E731

    def tbl(head, rows, widths, monocols=()):
        data_rows = [[Paragraph(f"<b>{e(h)}</b>", body) for h in head]]
        for r in rows or [["None"] + [""] * (len(head) - 1)]:
            data_rows.append([Paragraph(e(c), mono if i in monocols else body) for i, c in enumerate(r)])
        t = Table(data_rows, colWidths=[w * mm for w in widths], repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                               ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#cbd5e1")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t

    ac = data["alert_counts"]
    st = [Paragraph(e(data["title"]), h1),
          Paragraph(f"Generated {e(data['generated'])} UTC &middot; session {e(data['session_id'])}", body),
          Paragraph("1-4. Monitoring summary", h2),
          tbl(["Field", "Value"], [["Monitoring start (UTC)", data["monitoring_start"]],
                                   ["Monitoring end (UTC)", data["monitoring_end"]],
                                   ["Operating system", data["operating_system"]], ["Hostname", data["hostname"]],
                                   ["Scans", data["scans"]], ["Network visibility", data["connection_status"]]], [70, 200]),
          Paragraph("5-6. Totals", h2),
          tbl(["Processes", "Suspicious", "Critical", "High", "Medium", "Low"],
              [[data["total_processes"], data["suspicious_count"], ac["CRITICAL"], ac["HIGH"], ac["MEDIUM"], ac["LOW"]]],
              [45] * 6),
          Paragraph("6-7. Suspicious processes", h2)]
    for d in data["suspicious_processes"]:
        st.append(Paragraph(f"<b>[{e(d['severity'])}] {e(d['name'])}</b> PID {e(d['pid'])} &middot; score "
                            f"{e(d['risk_score'])}/100 &middot; {e(d['explanation'])}", body))
        st.append(tbl(["Finding", "Evidence"], [[f["category"], f["evidence"]] for f in d["findings"]], [80, 190], (1,)))
        st.append(Spacer(1, 4))
    if not data["suspicious_processes"]:
        st.append(Paragraph("No process reached the alert threshold.", body))
    st += [Paragraph("7-8. Process details and executable paths (top by score)", h2),
           tbl(["PID", "PPID", "Name", "User", "CPU%", "MEM%", "Score", "Sev", "Path"],
               [[d["pid"], d["ppid"], d["name"], d["username"], d["cpu_percent"], d["memory_percent"], d["risk_score"],
                 d["severity"], d["exe"]] for d in data["process_details"][:120]],
               [13, 13, 36, 20, 13, 13, 13, 18, 131], (8,)),
           PageBreak(),
           Paragraph("9. SHA-256 hashes (computed locally, nothing uploaded)", h2),
           tbl(["Process", "Path", "SHA-256", "Reputation"],
               [[h["process"], h["path"], h["sha256"], h["reputation"]] for h in data["hashes"]], [30, 85, 120, 35], (1, 2)),
           Paragraph("10. Parent-child relationships", h2),
           tbl(["Parent", "Child", "Rule", "Chain"],
               [[f"{r['parent']} ({r['ppid']})", f"{r['child']} ({r['pid']})", r["rule"], r["chain"]]
                for r in data["relationships"]], [40, 40, 80, 110], (3,)),
           Paragraph("11. Network connections", h2),
           tbl(["PID", "Process", "Proto", "Local", "Remote", "Scope", "Status"],
               [[c["pid"], c["process_name"], c["protocol"], f"{c['local_ip']}:{c['local_port']}",
                 f"{c['remote_ip']}:{c['remote_port']}" if c["remote_ip"] else "", c["remote_scope"], c["status"]]
                for c in data["connections"][:150]], [15, 40, 15, 55, 55, 25, 30], (3, 4)),
           Paragraph("12. Risk score distribution", h2),
           tbl(["Severity", "Processes"], [[k, v] for k, v in data["risk_distribution"].items()], [60, 60]),
           Paragraph("13. Security alerts", h2),
           tbl(["Alert ID", "Time (UTC)", "Sev", "PID", "Process", "Category", "Score", "Status"],
               [[a["alert_id"], a["timestamp"], a["severity"], a["pid"], a["process_name"], a["category"], a["risk_score"],
                 a["status"]] for a in data["alerts"]], [45, 38, 18, 13, 32, 82, 13, 25], (0,)),
           Paragraph("14. Recommended actions", h2)]
    st += [Paragraph("&bull; " + e(r), body) for r in data["recommended_actions"]]
    st += [Paragraph("15. Final security assessment", h2), Paragraph(f"<b>{e(data['assessment']['level'])}</b>", body),
           Paragraph(e(data["assessment"]["summary"]), body), Spacer(1, 4), Paragraph(e(data["disclaimer"]), body)]

    def footer(c, d):
        c.saveState()
        c.setFont("Helvetica", 7)
        c.drawString(12 * mm, 7 * mm, f"SPD report - {data['hostname']} - page {d.page}")
        c.restoreState()

    SimpleDocTemplate(str(p), pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm, topMargin=12 * mm,
                      bottomMargin=12 * mm, title="SPD Investigation Report").build(st, onFirstPage=footer,
                                                                                    onLaterPages=footer)
    return p


def generate_all(engine, formats=("html", "json", "csv", "pdf"), out_dir=None, stem=None) -> dict:
    data = build_report_data(engine)
    out_dir = Path(out_dir or engine.cfg.path("reports"))
    out = {}
    if "html" in formats:
        out["html"] = write_html(data, out_dir, f"{stem}.html" if stem else None)
    if "json" in formats:
        out["json"] = write_json(data, out_dir, f"{stem}.json" if stem else None)
    if "csv" in formats:
        out["csv"] = write_csv(data, out_dir, stem)
    if "pdf" in formats:
        out["pdf"] = write_pdf(data, out_dir, f"{stem}.pdf" if stem else None)
    return out
