"""
network_monitor.py - process-associated connections via psutil.net_connections.

Addresses are classified only as loopback / private / link-local / public /
multicast. The tool never calls an IP "malicious": that needs reliable
threat intelligence, which this offline tool does not have.

Platform notes: on Linux, seeing other users' sockets needs root; on macOS
net_connections needs root; on Windows most connections are visible but
some PIDs are protected.
"""
from __future__ import annotations

import ipaddress
import socket
from collections import defaultdict
from dataclasses import asdict, dataclass

import psutil

from .process_analyzer import Finding

PROTO = {(socket.AF_INET, socket.SOCK_STREAM): "TCP", (socket.AF_INET6, socket.SOCK_STREAM): "TCP6",
         (socket.AF_INET, socket.SOCK_DGRAM): "UDP", (socket.AF_INET6, socket.SOCK_DGRAM): "UDP6"}


@dataclass
class Connection:
    pid: int | None
    protocol: str
    local_ip: str
    local_port: int
    remote_ip: str
    remote_port: int | None
    status: str
    remote_scope: str
    process_name: str = ""

    def to_dict(self):
        return asdict(self)

    @property
    def local(self):
        return f"{self.local_ip}:{self.local_port}"

    @property
    def remote(self):
        return f"{self.remote_ip}:{self.remote_port}" if self.remote_ip else ""


def ip_scope(ip: str) -> str:
    if not ip:
        return "none"
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return "unknown"
    if a.is_loopback:
        return "loopback"
    if a.is_unspecified:
        return "any"
    if a.is_link_local:
        return "link-local"
    if a.is_multicast:
        return "multicast"
    if a.is_private:
        return "private"
    return "public"


def collect_connections(names: dict | None = None) -> tuple[list[Connection], str]:
    """Returns (connections, status). status 'ok' or a reason they could not be read."""
    names = names or {}
    try:
        raw = psutil.net_connections(kind="inet")
    except psutil.AccessDenied:
        return [], "access denied (run as root/Administrator to see all sockets)"
    except (OSError, NotImplementedError) as exc:
        return [], f"unavailable: {exc}"
    out = []
    for c in raw:
        lip, lport = (c.laddr.ip, c.laddr.port) if c.laddr else ("", 0)
        rip, rport = (c.raddr.ip, c.raddr.port) if c.raddr else ("", None)
        status = c.status if c.status != psutil.CONN_NONE else ("UDP" if c.type == socket.SOCK_DGRAM else "NONE")
        out.append(Connection(c.pid, PROTO.get((c.family, c.type), "?"), lip, lport, rip, rport, status,
                              ip_scope(rip), names.get(c.pid, "")))
    return out, "ok"


class NetworkAnalyzer:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.allowed_ports = set(cfg["allowed_listening_ports"])
        self.allowed_procs = {x.lower() for x in cfg["allowed_listening_processes"]}

    @staticmethod
    def group(conns: list[Connection]) -> dict:
        g = defaultdict(list)
        for c in conns:
            if c.pid:
                g[c.pid].append(c)
        return g

    def check(self, proc, conns: list[Connection], trusted_location: bool) -> list[Finding]:
        out = []
        listeners = [c for c in conns if c.status == psutil.CONN_LISTEN]
        if proc.name.lower() not in self.allowed_procs:
            odd = [c for c in listeners if c.local_port not in self.allowed_ports]
            if odd:
                loop_only = all(ip_scope(c.local_ip) == "loopback" for c in odd)
                ports = ", ".join(sorted({f"{c.protocol}/{c.local_port} on {c.local_ip}" for c in odd}))
                out.append(Finding("unusual_network", "Unexpected listening service",
                                   "Process accepts connections on a port not in allowed_listening_ports"
                                   + (" (loopback only - reachable from this machine only)." if loop_only else
                                      ". Reachable from the network."),
                                   f"listening: {ports}", weight_factor=0.5 if loop_only else 1.0))
        established = [c for c in conns if c.status == psutil.CONN_ESTABLISHED]
        if len(established) >= self.cfg["connection_threshold"]:
            out.append(Finding("unusual_network", "Many simultaneous connections",
                               f"{len(established)} established connections (rule: {self.cfg['connection_threshold']}). "
                               "Normal for browsers and servers; unusual for small utilities.",
                               f"established: {len(established)}"))
        public = [c for c in established if c.remote_scope == "public"]
        if public and not trusted_location and proc.exe:
            sample = ", ".join(sorted({c.remote for c in public})[:5])
            out.append(Finding("unusual_network", "Untrusted-location executable with external connections",
                               "An executable outside trusted system folders is talking to public IP addresses. "
                               "The remote addresses are NOT known to be malicious - check them with threat intel.",
                               f"remote: {sample}"))
        return out
