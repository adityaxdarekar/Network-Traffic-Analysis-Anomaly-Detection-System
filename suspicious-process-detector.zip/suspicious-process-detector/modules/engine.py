"""
engine.py - orchestrates one detection scan and keeps the latest state for
the terminal menu and dashboard.

scan():  collect processes -> build tree -> read connections -> per process:
         name/cmdline/path/masquerade + parent-child + resources + network +
         hash -> score -> alerts -> SQLite.

The engine is read-only towards the system: it never kills, suspends,
re-prioritises or modifies processes, and never deletes or uploads files.
"""
from __future__ import annotations

import logging
import os
import platform
import socket
import threading
import time
from logging.handlers import RotatingFileHandler

import psutil

from .alert_manager import AlertManager
from .behavior_detector import BehaviorDetector
from .database import Database, utcnow
from .hash_analyzer import HashAnalyzer
from .network_monitor import NetworkAnalyzer, collect_connections
from .process_analyzer import ProcessAnalyzer
from .process_monitor import BackgroundMonitor, ProcessMonitor
from .process_tree import ProcessTree, RelationshipAnalyzer
from .risk_scorer import RiskScorer
from .settings import load_config, load_known_hashes, load_rules, redact_cmdline


def setup_logging(path) -> logging.Logger:
    log = logging.getLogger("spd")
    if not log.handlers:
        path.parent.mkdir(parents=True, exist_ok=True)
        h = RotatingFileHandler(path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log


def os_name() -> str:
    try:
        if platform.system() == "Linux":
            info = platform.freedesktop_os_release()
            return info.get("PRETTY_NAME") or info.get("NAME") or "Linux"
    except (OSError, AttributeError):
        pass
    return f"{platform.system()} {platform.release()}".strip()


class DetectionEngine:
    def __init__(self, cfg=None, db: Database | None = None):
        self.cfg = cfg or load_config()
        self.log = setup_logging(self.cfg.path("logs"))
        self.rules = load_rules(self.cfg.path("rules"))
        self.db = db or Database(self.cfg.path("database"))
        self.monitor = ProcessMonitor(self.cfg["history_snapshots"])
        self.analyzer = ProcessAnalyzer(self.rules)
        self.relations = RelationshipAnalyzer(self.rules, self.analyzer)
        self.behavior = BehaviorDetector(self.cfg)
        self.network = NetworkAnalyzer(self.cfg)
        self.hasher = HashAnalyzer(load_known_hashes(self.cfg.path("known_hashes")), self.cfg["max_hash_file_mb"],
                                   self.cfg.path("known_hashes"))
        self.scorer = RiskScorer(self.cfg)
        self.alerts = AlertManager(self.cfg, self.db, self.log)
        self.hostname = socket.gethostname()
        self.os = os_name()
        self.session_id = self.db.start_session(self.hostname, self.os, self.cfg["monitoring_interval"])
        self.started = utcnow()
        self.started_ts = time.time()
        self.ended = None
        self._baseline = self._load_hash_baseline()
        self._hashes_recorded: set = set()
        self._lock = threading.Lock()
        self.state = {"processes": [], "results": {}, "connections": [], "tree": None, "conn_status": "not scanned",
                      "scans": 0, "last_scan": None, "new_alerts": []}
        self.flagged: dict = {}    # process key -> {"proc", "info", "chain", "last_seen"} for the whole session
        self.background: BackgroundMonitor | None = None
        self.max_total = 0
        self.log.info("session %s started on %s (%s)", self.session_id, self.hostname, self.os)

    def _load_hash_baseline(self) -> dict:
        rows = self.db.q("""SELECT path, sha256 FROM hashes WHERE session_id IS NOT ? ORDER BY last_seen""",
                         (self.session_id,))
        return {r["path"]: r["sha256"] for r in rows}   # latest per path wins

    # --------------------------------------------------------------- scan
    def scan(self) -> dict:
        now = time.time()
        procs = self.monitor.collect()
        by_pid = {p.pid: p for p in procs}
        tree = ProcessTree(procs)
        conns, conn_status = collect_connections({p.pid: p.name for p in procs})
        conn_by_pid = NetworkAnalyzer.group(conns)
        spawn = self.behavior.check_process_creation(self.monitor.creation_times, by_pid, now)
        self.behavior.forget({p.key for p in procs})

        results, hashes, rows = {}, {}, []
        for p in procs:
            trusted = self.analyzer.is_trusted_location(p.exe)
            findings = self.analyzer.analyze(p)
            findings += self.relations.check(p, tree)
            findings += self.behavior.check_resources(p, now)
            findings += self.network.check(p, conn_by_pid.get(p.pid, []), trusted)
            findings += spawn.get(p.pid, [])
            sha = None
            if p.exe and not p.exe.startswith("/memfd:") and not p.exe_deleted:
                sha, status = self.hasher.sha256(p.exe)
                if sha:
                    hashes[p.exe] = sha
                    findings += self.hasher.findings(p, sha, trusted, self._baseline.get(p.exe))
            result = self.scorer.score(findings)
            results[p.pid] = {"result": result, "sha256": sha, "trusted": trusted,
                              "location": self.analyzer.location_class(p.exe)}
            rows.append({"pid": p.pid, "create_time": p.create_time, "name": p.name, "exe": p.exe,
                         "cmdline": redact_cmdline(p.cmdline)[:1000], "username": p.username, "ppid": p.ppid,
                         "parent_name": p.parent_name, "sha256": sha, "score": result.score,
                         "severity": result.severity})

        for p in procs:
            r = results[p.pid]
            if r["result"].score >= max(self.cfg["alert_min_score"], 1):
                prev = self.flagged.get(p.key)
                if not prev or r["result"].score >= prev["info"]["result"].score:
                    self.flagged[p.key] = {"proc": p, "info": r, "chain": tree.chain_text(p.pid), "last_seen": utcnow()}
                else:
                    prev["last_seen"] = utcnow()
        if len(self.flagged) > 2000:
            for k in sorted(self.flagged, key=lambda k: self.flagged[k]["last_seen"])[:-2000]:
                del self.flagged[k]

        new_alerts = []
        for p in procs:
            a = self.alerts.evaluate(p, results[p.pid]["result"], self.session_id, now)
            if a:
                new_alerts.append(a)
        self.alerts.prune(now)

        # persistence
        for path, sha in hashes.items():
            if (path, sha) not in self._hashes_recorded:
                try:
                    size = os.path.getsize(path)
                except OSError:
                    size = None
                self.db.record_hash(path, sha, size, self.session_id)
                self._hashes_recorded.add((path, sha))
        self.db.upsert_processes(self.session_id, rows)
        self.db.record_connections(self.session_id, conns)
        suspicious = sum(1 for r in results.values() if r["result"].score >= self.cfg["alert_min_score"])
        vm = psutil.virtual_memory()
        cpu = psutil.cpu_percent(None)
        self.db.record_scan(self.session_id, len(procs), suspicious, len(conns), cpu, vm.percent, len(new_alerts))
        self.max_total = max(self.max_total, len(procs))
        with self._lock:
            self.state.update(processes=procs, results=results, connections=conns, tree=tree, conn_status=conn_status,
                              scans=self.state["scans"] + 1, last_scan=utcnow(), new_alerts=new_alerts,
                              cpu_percent=cpu, memory_percent=vm.percent)
        return self.snapshot()

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self.state)

    # --------------------------------------------------------------- views
    def suspicious(self, min_score=None) -> list:
        """[(ProcessInfo, result_dict)] sorted by score, highest first."""
        s = self.snapshot()
        lim = self.cfg["alert_min_score"] if min_score is None else min_score
        out = [(p, s["results"][p.pid]) for p in s["processes"]
               if p.pid in s["results"] and s["results"][p.pid]["result"].score >= max(lim, 1)]
        return sorted(out, key=lambda x: -x[1]["result"].score)

    def session_suspicious(self) -> list:
        """Every process that reached the alert score at any point this session (highest score kept),
        including processes that have since exited. [(ProcessInfo, result_dict, chain, still_running)]"""
        live = {p.key for p in self.snapshot()["processes"]}
        out = [(v["proc"], v["info"], v["chain"], k in live) for k, v in self.flagged.items()]
        return sorted(out, key=lambda x: -x[1]["result"].score)

    def process_details(self, pid: int) -> dict:
        """On-demand extra details (open files, connections) where permissions allow."""
        out = {"pid": pid, "open_files": [], "connections": [], "errors": []}
        try:
            p = psutil.Process(pid)
            try:
                out["open_files"] = [f.path for f in p.open_files()][:200]
            except psutil.AccessDenied:
                out["errors"].append("open_files: access denied")
            try:
                out["connections"] = [str(c) for c in p.net_connections(kind="inet")][:200]
            except psutil.AccessDenied:
                out["errors"].append("connections: access denied")
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            out["errors"].append("process no longer exists")
        return out

    def uptime(self) -> float:
        return time.time() - self.started_ts

    # --------------------------------------------------------------- monitoring
    def start_background(self, interval=None):
        if not self.background or not self.background.running:
            self.background = BackgroundMonitor(self, interval or self.cfg["monitoring_interval"])
            self.background.start()
        return self.background

    def stop_background(self):
        if self.background:
            self.background.stop()

    def close(self):
        self.stop_background()
        self.db.end_session(self.session_id)
        self.ended = utcnow()
        self.log.info("session %s ended after %d scans", self.session_id, self.state["scans"])
