"""
database.py - SQLite storage (parameterised queries only, one lock, WAL).

Tables
  sessions          monitoring sessions (start/end, host, OS)
  processes         one row per process instance (pid + create_time): name,
                    exe, username, ppid, sha256, first/last observed, max score
  hashes            sha256 history per executable path (cross-session compare)
  alerts            security alerts + analyst acknowledgement
  network_records   process-associated connections (deduplicated per session)
  scans             per-scan summary (counts, CPU, memory) for charts
Command lines are stored REDACTED.
"""
from __future__ import annotations

import csv
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, started TEXT NOT NULL, ended TEXT,
  hostname TEXT, os TEXT, interval REAL, scans INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS processes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, pid INTEGER NOT NULL, create_time REAL NOT NULL,
  name TEXT, exe TEXT, cmdline TEXT, username TEXT, ppid INTEGER, parent_name TEXT, sha256 TEXT,
  first_seen TEXT, last_seen TEXT, max_score INTEGER DEFAULT 0, severity TEXT DEFAULT 'NONE',
  UNIQUE(pid, create_time));
CREATE INDEX IF NOT EXISTS ix_proc_name ON processes(name);
CREATE TABLE IF NOT EXISTS hashes (
  path TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER, first_seen TEXT, last_seen TEXT, session_id INTEGER,
  PRIMARY KEY(path, sha256));
CREATE TABLE IF NOT EXISTS alerts (
  alert_id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, session_id INTEGER, pid INTEGER, process_name TEXT,
  exe TEXT, category TEXT, risk_score INTEGER, severity TEXT, description TEXT, evidence TEXT,
  recommendations TEXT, status TEXT DEFAULT 'NEW', analyst TEXT, analyst_note TEXT, acknowledged_at TEXT);
CREATE INDEX IF NOT EXISTS ix_alert_sev ON alerts(severity);
CREATE TABLE IF NOT EXISTS network_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, pid INTEGER, process_name TEXT, protocol TEXT,
  local TEXT, remote TEXT, remote_scope TEXT, status TEXT, first_seen TEXT, timestamp TEXT,
  UNIQUE(session_id, pid, protocol, local, remote, status));
CREATE TABLE IF NOT EXISTS scans (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, timestamp TEXT, total INTEGER, suspicious INTEGER,
  connections INTEGER, cpu_percent REAL, memory_percent REAL, new_alerts INTEGER);
"""

ALERT_STATUSES = ("NEW", "ACKNOWLEDGED", "FALSE_POSITIVE", "RESOLVED")


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            if self.path != ":memory:":
                self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    @contextmanager
    def tx(self):
        with self._lock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def q(self, sql, args=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def close(self):
        with self._lock:
            self.conn.close()

    # ------------------------------------------------------------ sessions
    def start_session(self, hostname, os_name, interval) -> int:
        with self.tx() as c:
            return c.execute("INSERT INTO sessions(started, hostname, os, interval) VALUES (?,?,?,?)",
                             (utcnow(), hostname, os_name, interval)).lastrowid

    def end_session(self, sid):
        with self.tx() as c:
            c.execute("UPDATE sessions SET ended=? WHERE id=?", (utcnow(), sid))

    def sessions(self, limit=50):
        return self.q("SELECT * FROM sessions ORDER BY id DESC LIMIT ?", (limit,))

    # ------------------------------------------------------------ processes
    def upsert_processes(self, sid, rows: list[dict]):
        now = utcnow()
        with self.tx() as c:
            c.executemany("""
              INSERT INTO processes(session_id,pid,create_time,name,exe,cmdline,username,ppid,parent_name,sha256,
                                    first_seen,last_seen,max_score,severity)
              VALUES (:sid,:pid,:create_time,:name,:exe,:cmdline,:username,:ppid,:parent_name,:sha256,:now,:now,
                      :score,:severity)
              ON CONFLICT(pid, create_time) DO UPDATE SET last_seen=:now,
                 sha256=COALESCE(:sha256, sha256), session_id=:sid,
                 severity=CASE WHEN :score > max_score THEN :severity ELSE severity END,
                 max_score=MAX(max_score, :score)""",
                          [{**r, "sid": sid, "now": now} for r in rows])

    def search_processes(self, term="", min_score=0, limit=500):
        like = f"%{term}%"
        args = [min_score, like, like, like]
        sql = "SELECT * FROM processes WHERE max_score >= ? AND (name LIKE ? OR exe LIKE ? OR CAST(pid AS TEXT) LIKE ?)"
        return self.q(sql + " ORDER BY max_score DESC, last_seen DESC LIMIT ?", (*args, limit))

    # ------------------------------------------------------------ hashes
    def previous_hash(self, path) -> str | None:
        r = self.q("SELECT sha256 FROM hashes WHERE path=? ORDER BY last_seen DESC LIMIT 1", (path,))
        return r[0]["sha256"] if r else None

    def record_hash(self, path, sha, size, sid):
        now = utcnow()
        with self.tx() as c:
            c.execute("""INSERT INTO hashes(path, sha256, size, first_seen, last_seen, session_id) VALUES (?,?,?,?,?,?)
                         ON CONFLICT(path, sha256) DO UPDATE SET last_seen=excluded.last_seen,
                         session_id=excluded.session_id""", (path, sha, size, now, now, sid))

    def hash_rows(self, limit=5000):
        return self.q("""SELECT h.path, h.sha256, h.size, h.first_seen, h.last_seen,
                         (SELECT COUNT(*) FROM hashes h2 WHERE h2.path=h.path) AS versions
                         FROM hashes h ORDER BY h.last_seen DESC LIMIT ?""", (limit,))

    # ------------------------------------------------------------ alerts
    def insert_alert(self, a: dict):
        with self.tx() as c:
            c.execute("""INSERT INTO alerts(alert_id,timestamp,session_id,pid,process_name,exe,category,risk_score,
                         severity,description,evidence,recommendations,status) VALUES
                         (:alert_id,:timestamp,:session_id,:pid,:process_name,:exe,:category,:risk_score,:severity,
                          :description,:evidence,:recommendations,'NEW')""",
                      {**a, "evidence": json.dumps(a["evidence"]), "recommendations": json.dumps(a["recommendations"])})

    def set_alert_status(self, alert_id, status, analyst="", note="") -> bool:
        if status not in ALERT_STATUSES:
            raise ValueError(f"status must be one of {ALERT_STATUSES}")
        with self.tx() as c:
            n = c.execute("UPDATE alerts SET status=?, analyst=?, analyst_note=?, acknowledged_at=? WHERE alert_id=?",
                          (status, analyst[:80], note[:500], utcnow(), alert_id)).rowcount
        return n == 1

    def alerts(self, severity=None, term="", status=None, session_id=None, limit=1000):
        sql, args = "SELECT * FROM alerts WHERE 1=1", []
        if severity:
            sevs = [severity] if isinstance(severity, str) else list(severity)
            sql += f" AND severity IN ({','.join('?' * len(sevs))})"
            args += sevs
        if status:
            sql += " AND status=?"
            args.append(status)
        if session_id:
            sql += " AND session_id=?"
            args.append(session_id)
        if term:
            sql += " AND (process_name LIKE ? OR CAST(pid AS TEXT)=? OR category LIKE ?)"
            args += [f"%{term}%", term, f"%{term}%"]
        rows = self.q(sql + " ORDER BY timestamp DESC, risk_score DESC LIMIT ?", (*args, limit))
        for r in rows:
            r["evidence"] = json.loads(r["evidence"] or "[]")
            r["recommendations"] = json.loads(r["recommendations"] or "[]")
        return rows

    def severity_counts(self, session_id=None) -> dict:
        sql, args = "SELECT severity, COUNT(*) n FROM alerts", ()
        if session_id:
            sql, args = sql + " WHERE session_id=?", (session_id,)
        out = {s: 0 for s in ("CRITICAL", "HIGH", "MEDIUM", "LOW")}
        for r in self.q(sql + " GROUP BY severity", args):
            out[r["severity"]] = r["n"]
        return out

    # ------------------------------------------------------------ network
    def record_connections(self, sid, conns):
        now = utcnow()
        with self.tx() as c:
            c.executemany("""INSERT INTO network_records(session_id,pid,process_name,protocol,local,remote,remote_scope,
                             status,first_seen,timestamp) VALUES (?,?,?,?,?,?,?,?,?,?)
                             ON CONFLICT(session_id,pid,protocol,local,remote,status)
                             DO UPDATE SET timestamp=excluded.timestamp""",
                          [(sid, x.pid, x.process_name, x.protocol, x.local, x.remote, x.remote_scope, x.status, now, now)
                           for x in conns])

    def network_rows(self, term="", limit=2000):
        like = f"%{term}%"
        return self.q("""SELECT * FROM network_records WHERE process_name LIKE ? OR local LIKE ? OR remote LIKE ?
                         OR CAST(pid AS TEXT)=? ORDER BY timestamp DESC LIMIT ?""", (like, like, like, term, limit))

    # ------------------------------------------------------------ scans
    def record_scan(self, sid, total, suspicious, connections, cpu, mem, new_alerts):
        with self.tx() as c:
            c.execute("""INSERT INTO scans(session_id,timestamp,total,suspicious,connections,cpu_percent,memory_percent,
                         new_alerts) VALUES (?,?,?,?,?,?,?,?)""",
                      (sid, utcnow(), total, suspicious, connections, cpu, mem, new_alerts))
            c.execute("UPDATE sessions SET scans = scans + 1 WHERE id=?", (sid,))

    def scan_rows(self, session_id=None, limit=2000):
        if session_id:
            return self.q("SELECT * FROM scans WHERE session_id=? ORDER BY id DESC LIMIT ?", (session_id, limit))[::-1]
        return self.q("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,))[::-1]

    # ------------------------------------------------------------ export
    def export_csv(self, table: str, path: Path) -> int:
        if table not in ("processes", "alerts", "network_records", "hashes", "scans", "sessions"):
            raise ValueError("unknown table")
        rows = self.q(f"SELECT * FROM {table}")   # table name validated against a fixed list above
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as fh:
            if rows:
                w = csv.DictWriter(fh, fieldnames=list(rows[0]))
                w.writeheader()
                w.writerows(rows)
        return len(rows)
