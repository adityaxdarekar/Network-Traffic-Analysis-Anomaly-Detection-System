"""
hash_analyzer.py - SHA-256 of executable files, cached by (path, size, mtime).

  * Reads files in 1 MiB chunks; files above max_hash_file_mb are skipped.
  * Compares against data/known_hashes.json (analyst-maintained lists).
  * Detects a changed hash for the same path across monitoring sessions
    (previous value comes from the SQLite hash table).

Files are NEVER uploaded anywhere. An unknown hash means "not in your lists",
nothing more - most legitimate software is "unknown" to a local list.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

from .process_analyzer import Finding

CHUNK = 1024 * 1024


class HashAnalyzer:
    def __init__(self, known: dict, max_mb: float = 256, known_path: Path | None = None):
        self.known_good = known.get("known_good", {})
        self.known_bad = known.get("known_bad", {})
        self.max_bytes = int(max_mb * 1024 * 1024)
        self.known_path = known_path
        self._cache: dict = {}       # path -> (size, mtime_ns, sha256)
        self._lock = threading.Lock()
        self.stats = {"hashed": 0, "cached": 0, "skipped": 0, "errors": 0}

    def sha256(self, path: str) -> tuple[str | None, str]:
        """Returns (hash or None, status). status: ok | cached | too_large | denied | missing | error."""
        if not path:
            return None, "missing"
        try:
            st = os.stat(path)
        except FileNotFoundError:
            return None, "missing"
        except PermissionError:
            return None, "denied"
        except OSError:
            return None, "error"
        with self._lock:
            c = self._cache.get(path)
            if c and c[0] == st.st_size and c[1] == st.st_mtime_ns:
                self.stats["cached"] += 1
                return c[2], "cached"
        if st.st_size > self.max_bytes:
            self.stats["skipped"] += 1
            return None, "too_large"
        h = hashlib.sha256()
        try:
            with open(path, "rb") as fh:
                for block in iter(lambda: fh.read(CHUNK), b""):
                    h.update(block)
        except PermissionError:
            self.stats["errors"] += 1
            return None, "denied"
        except OSError:
            self.stats["errors"] += 1
            return None, "error"
        digest = h.hexdigest()
        with self._lock:
            self._cache[path] = (st.st_size, st.st_mtime_ns, digest)
            self.stats["hashed"] += 1
        return digest, "ok"

    def reputation(self, sha: str | None) -> str:
        if not sha:
            return "unavailable"
        if sha in self.known_bad:
            return "known_bad"
        if sha in self.known_good:
            return "known_good"
        return "unknown"

    def findings(self, proc, sha: str | None, trusted_location: bool, previous_sha: str | None) -> list[Finding]:
        out = []
        rep = self.reputation(sha)
        if rep == "known_bad":
            src = self.known_bad[sha]
            src = src.get("source", "analyst list") if isinstance(src, dict) else str(src)
            out.append(Finding("known_bad_hash", "Hash matches known-bad list",
                               f"SHA-256 is listed in known_hashes.json known_bad (source: {src}). Confirm the "
                               f"source is reliable before acting.", f"sha256: {sha}"))
        elif rep == "unknown" and not trusted_location:
            out.append(Finding("unknown_hash_untrusted_location", "Unknown executable hash",
                               "Hash is not in your known-good list and the file is outside trusted system folders. "
                               "Unknown does NOT mean malicious.", f"sha256: {sha}"))
        if sha and previous_sha and sha != previous_sha:
            out.append(Finding("hash_changed", "Executable hash changed",
                               "This path had a different SHA-256 in an earlier monitoring session. Normal after a "
                               "software update; unexpected changes to system binaries deserve investigation.",
                               f"path: {proc.exe}; previous: {previous_sha[:16]}...; now: {sha[:16]}..."))
        return out

    def add_known_good(self, entries: dict) -> int:
        """Add {sha: note} to known_good and save the JSON file. Returns number added."""
        added = 0
        for sha, note in entries.items():
            if sha not in self.known_good and sha not in self.known_bad:
                self.known_good[sha] = note
                added += 1
        if self.known_path and added:
            data = {"_comment": "Analyst-maintained hash lists. Ships empty; never contains invented verdicts.",
                    "known_good": self.known_good, "known_bad": self.known_bad}
            tmp = Path(str(self.known_path) + ".tmp")
            tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
            os.replace(tmp, self.known_path)
        return added


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
