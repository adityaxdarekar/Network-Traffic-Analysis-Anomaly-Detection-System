"""
behavior_detector.py - resource and activity anomalies across snapshots.

  * sustained CPU      : cpu_percent >= cpu_threshold for cpu_duration_seconds
                         (psutil reports % of ONE core, so >100 is possible)
  * high memory        : memory_percent >= memory_threshold (% of total RAM)
  * thread count       : num_threads >= thread_threshold
  * rapid creation     : one parent starting >= process_creation_threshold
                         children within process_creation_window seconds

Processes in resource_intensive_allowlist (browsers, compilers, IDEs) still
get their resource findings recorded, but with zero weight, so normal heavy
applications do not raise repeated alerts.
"""
from __future__ import annotations

import time
from collections import Counter

from .process_analyzer import Finding


class BehaviorDetector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.allow = {x.lower() for x in cfg.get("resource_intensive_allowlist", [])}
        self._cpu_since: dict = {}     # process key -> first timestamp above threshold

    def _factor(self, proc) -> float:
        return 0.0 if proc.name.lower() in self.allow else 1.0

    def check_resources(self, proc, now: float | None = None) -> list[Finding]:
        now = time.time() if now is None else now
        c, out = self.cfg, []
        f = self._factor(proc)
        note = " (allow-listed resource-intensive application: informational only)" if f == 0 else ""
        # --- CPU
        if proc.cpu_percent >= c["cpu_threshold"]:
            since = self._cpu_since.setdefault(proc.key, now)
            held = now - since
            if held >= c["cpu_duration_seconds"]:
                out.append(Finding("sustained_high_cpu", "Sustained high CPU usage",
                                   f"CPU at or above {c['cpu_threshold']}% for {held:.0f}s "
                                   f"(rule: {c['cpu_duration_seconds']}s). Common for builds, games and encoders; "
                                   f"also for cryptominers." + note,
                                   f"cpu: {proc.cpu_percent:.1f}% for {held:.0f}s", weight_factor=f))
            else:
                out.append(Finding("high_resource", "High CPU spike",
                                   f"CPU above {c['cpu_threshold']}% for {held:.0f}s so far; scores only together "
                                   f"with other evidence." + note,
                                   f"cpu: {proc.cpu_percent:.1f}%", requires_context=True, weight_factor=f))
        else:
            self._cpu_since.pop(proc.key, None)
        # --- memory
        if proc.memory_percent >= c["memory_threshold"]:
            out.append(Finding("high_memory", "High memory usage",
                               f"Process uses {proc.memory_percent:.1f}% of total RAM (rule: {c['memory_threshold']}%)." + note,
                               f"memory: {proc.memory_percent:.1f}% ({proc.memory_rss / 1048576:.0f} MiB RSS)",
                               weight_factor=f))
        # --- threads
        if proc.num_threads >= c["thread_threshold"]:
            out.append(Finding("high_thread_count", "Unusual thread count",
                               f"{proc.num_threads} threads (rule: {c['thread_threshold']})." + note,
                               f"threads: {proc.num_threads}", weight_factor=f))
        return out

    def check_process_creation(self, creation_events, by_pid: dict, now: float | None = None) -> dict:
        """Returns {parent_pid: [Finding]} for parents that spawned too many children too fast.
        creation_events: iterable of (create_time, pid, name, ppid)."""
        now = time.time() if now is None else now
        window, limit = self.cfg["process_creation_window"], self.cfg["process_creation_threshold"]
        recent = [e for e in creation_events if now - window <= e[0] <= now + 1]
        counts = Counter(e[3] for e in recent)
        out = {}
        for ppid, n in counts.items():
            if n >= limit and ppid in by_pid:
                names = Counter(e[2] for e in recent if e[3] == ppid).most_common(3)
                out[ppid] = [Finding("rapid_process_creation", "Rapid process creation",
                                     f"Started {n} child processes within {window}s (rule: {limit}). Seen with "
                                     f"fork bombs, brute-force tools and worm-like spreading; also with build systems "
                                     f"and shell loops.",
                                     f"{n} children in {window}s; most common: "
                                     + ", ".join(f"{nm} x{c}" for nm, c in names))]
        return out

    def forget(self, live_keys: set):
        for k in list(self._cpu_since):
            if k not in live_keys:
                del self._cpu_since[k]
