"""
settings.py - load and validate config.json, suspicious_processes.json and
known_hashes.json, plus the command-line redaction helper used by logs and
reports.
"""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "monitoring_interval": 5, "cpu_threshold": 90, "cpu_duration_seconds": 30, "memory_threshold": 80,
    "thread_threshold": 500, "process_creation_threshold": 20, "process_creation_window": 10,
    "connection_threshold": 50, "alert_cooldown": 60, "alert_min_score": 20, "history_snapshots": 120,
    "max_hash_file_mb": 256, "allowed_listening_ports": [22, 53, 80, 123, 443], "allowed_listening_processes": [],
    "resource_intensive_allowlist": [],
    "risk_weights": {"suspicious_name": 20, "lolbin_with_context": 20, "suspicious_cmdline": 15,
                     "temp_directory_execution": 20, "user_writable_execution": 10, "hidden_directory_execution": 10,
                     "missing_executable": 15, "masquerading": 30, "elevated_unusual_location": 10,
                     "suspicious_parent_child": 25, "unknown_hash_untrusted_location": 10, "hash_changed": 15,
                     "unusual_network": 15, "known_bad_hash": 50, "high_resource": 10, "sustained_high_cpu": 20,
                     "high_memory": 20, "high_thread_count": 10, "rapid_process_creation": 40},
    "risk_thresholds": {"low": 19, "medium": 39, "high": 69, "critical": 100},
    "paths": {"database": "database/process_monitor.db", "reports": "reports", "logs": "logs/detector.log",
              "rules": "data/suspicious_processes.json", "known_hashes": "data/known_hashes.json"},
}


class ConfigError(ValueError):
    pass


class Config(dict):
    base_dir: Path = BASE_DIR

    def path(self, key: str) -> Path:
        p = Path(self["paths"][key])
        return p if p.is_absolute() else self.base_dir / p


def _merge(base, over):
    out = copy.deepcopy(base)
    for k, v in over.items():
        if k.startswith("_"):
            continue
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def validate(cfg: dict) -> list[str]:
    e = []

    def num(key, lo, hi, integer=False):
        v = cfg.get(key)
        ok = isinstance(v, int) if integer else isinstance(v, (int, float))
        if isinstance(v, bool) or not ok or not lo <= v <= hi:
            e.append(f"{key} must be {'an integer' if integer else 'a number'} between {lo} and {hi} (got {v!r})")

    num("monitoring_interval", 0.5, 3600)
    num("cpu_threshold", 1, 100 * 1024)
    num("cpu_duration_seconds", 0, 86400)
    num("memory_threshold", 0.1, 100)
    num("thread_threshold", 1, 1_000_000, True)
    num("process_creation_threshold", 2, 100_000, True)
    num("process_creation_window", 1, 3600)
    num("connection_threshold", 1, 1_000_000, True)
    num("alert_cooldown", 0, 86400)
    num("alert_min_score", 0, 100)
    num("history_snapshots", 2, 100_000, True)
    num("max_hash_file_mb", 1, 100_000)
    ports = cfg.get("allowed_listening_ports")
    if not isinstance(ports, list) or not all(isinstance(p, int) and 0 < p < 65536 for p in ports):
        e.append("allowed_listening_ports must be a list of port numbers 1-65535")
    for key in ("allowed_listening_processes", "resource_intensive_allowlist"):
        if not isinstance(cfg.get(key), list) or not all(isinstance(x, str) for x in cfg[key]):
            e.append(f"{key} must be a list of process names")
    for k, v in cfg["risk_weights"].items():
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 <= v <= 100:
            e.append(f"risk_weights.{k} must be between 0 and 100")
    t = cfg["risk_thresholds"]
    vals = [t.get(k) for k in ("low", "medium", "high", "critical")]
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in vals) or not vals[0] < vals[1] < vals[2] <= vals[3] \
            or vals[3] != 100:
        e.append("risk_thresholds must be integers with low < medium < high < critical = 100")
    return e


def load_config(path=None, base_dir: Path = BASE_DIR, overrides: dict | None = None) -> Config:
    path = Path(path) if path else base_dir / "config.json"
    user = {}
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"{path.name} is not valid JSON (line {exc.lineno}): {exc.msg}")
    cfg = _merge(DEFAULTS, user)
    if overrides:
        cfg = _merge(cfg, overrides)
    problems = validate(cfg)
    if problems:
        raise ConfigError("invalid configuration:\n  - " + "\n  - ".join(problems))
    out = Config(cfg)
    out.base_dir = base_dir
    return out


def load_rules(path: Path) -> dict:
    try:
        rules = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"cannot load detection rules {Path(path).name}: {exc}") from exc
    for key in ("name_rules", "suspicious_cmdline_patterns", "parent_child_rules", "masquerading",
                "suspicious_locations", "trusted_locations"):
        if key not in rules:
            raise ConfigError(f"{Path(path).name} is missing '{key}'")
    for p in rules["suspicious_cmdline_patterns"]:
        try:
            re.compile(p["pattern"])
        except re.error as exc:
            raise ConfigError(f"invalid regex in suspicious_cmdline_patterns: {p['pattern']!r}: {exc}") from exc
    return rules


def load_known_hashes(path: Path) -> dict:
    p = Path(path)
    if not p.exists():
        return {"known_good": {}, "known_bad": {}}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigError(f"{p.name} is not valid JSON: {exc.msg}") from exc
    return {"known_good": {k.lower(): v for k, v in data.get("known_good", {}).items()},
            "known_bad": {k.lower(): v for k, v in data.get("known_bad", {}).items()}}


# ------------------------------------------------------------- redaction
_SECRET_FLAG = re.compile(
    r"(?i)((?:--?|/)(?:password|passwd|pass|pwd|token|secret|api[-_]?key|apikey|key|auth|credential|"
    r"access[-_]?key|client[-_]?secret)(?:[=:]|\s+))(\"[^\"]*\"|'[^']*'|\S+)")
_SECRET_KV = re.compile(r"(?i)\b((?:password|passwd|pwd|token|secret|api_?key|apikey|access_?key)=)([^\s&]+)")
_BEARER = re.compile(r"(?i)(authorization:\s*(?:bearer|basic)\s+)\S+")
_URL_CRED = re.compile(r"(?i)(\b[a-z][a-z0-9+.-]*://[^/\s:@]+:)[^@\s/]+(@)")


def redact_cmdline(cmdline) -> str:
    """Join a command line and mask likely secrets (passwords, tokens, keys, URL credentials)."""
    text = " ".join(cmdline) if isinstance(cmdline, (list, tuple)) else str(cmdline or "")
    text = _SECRET_FLAG.sub(r"\1[REDACTED]", text)
    text = _SECRET_KV.sub(r"\1[REDACTED]", text)
    text = _BEARER.sub(r"\1[REDACTED]", text)
    return _URL_CRED.sub(r"\1[REDACTED]\2", text)
