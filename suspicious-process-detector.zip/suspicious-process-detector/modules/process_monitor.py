"""
process_monitor.py - read-only process collection with psutil.

This module ONLY reads process information. It never calls terminate(),
kill(), suspend(), resume(), nice() or any other method that changes a
process. (tests/test_process_monitor.py checks the source for this.)
"""
from __future__ import annotations

import os
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass, field

import psutil

ATTRS = ["pid", "ppid", "name", "exe", "cmdline", "username", "status", "create_time",
         "num_threads", "memory_info", "memory_percent", "cwd"]


@dataclass
class ProcessInfo:
    pid: int
    ppid: int | None
    name: str
    exe: str = ""
    cmdline: list = field(default_factory=list)
    username: str = ""
    status: str = ""
    create_time: float = 0.0
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_rss: int = 0
    num_threads: int = 0
    parent_name: str = ""
    exe_deleted: bool = False
    cwd: str = ""
    access_denied: list = field(default_factory=list)   # fields we could not read

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def key(self) -> tuple:
        """(pid, create_time) identifies a process instance even if the pid is reused."""
        return (self.pid, round(self.create_time, 2))


def _safe(proc, attr, denied):
    try:
        return getattr(proc, attr)()
    except psutil.AccessDenied:
        denied.append(attr)
    except (psutil.NoSuchProcess, psutil.ZombieProcess, OSError):
        pass
    return None


def snapshot_process(proc: psutil.Process, cpu: float = 0.0) -> ProcessInfo | None:
    """Build a ProcessInfo from one psutil.Process. Returns None if the process vanished."""
    denied: list = []
    try:
        with proc.oneshot():
            info = proc.as_dict(attrs=ATTRS, ad_value="__DENIED__")
    except (psutil.NoSuchProcess, psutil.ZombieProcess):
        return None
    for k, v in list(info.items()):
        if v == "__DENIED__":
            denied.append(k)
            info[k] = None
    exe = info.get("exe") or ""
    deleted = False
    if exe.endswith(" (deleted)"):           # Linux: binary removed after start
        exe, deleted = exe[:-10], True
    mem = info.get("memory_info")
    return ProcessInfo(
        pid=info["pid"], ppid=info.get("ppid"), name=info.get("name") or "",
        exe=exe, cmdline=info.get("cmdline") or [], username=info.get("username") or "",
        status=info.get("status") or "", create_time=info.get("create_time") or 0.0,
        cpu_percent=round(cpu, 1), memory_percent=round(info.get("memory_percent") or 0.0, 2),
        memory_rss=getattr(mem, "rss", 0) if mem else 0, num_threads=info.get("num_threads") or 0,
        exe_deleted=deleted, cwd=info.get("cwd") or "", access_denied=denied)


class ProcessMonitor:
    """Collects process snapshots. cpu_percent needs two samples, so the first
    collect() primes the counters and reports 0 % for every process."""

    def __init__(self, history_size: int = 120):
        self._cpu_primed: dict = {}            # key -> psutil.Process (keeps cpu baseline)
        self.history: deque = deque(maxlen=history_size)   # (timestamp, {key: ProcessInfo})
        self.creation_times: deque = deque(maxlen=10_000)  # (create_time, pid, name, ppid)
        self._seen: set = set()
        self.errors = {"access_denied": 0, "vanished": 0}

    def collect(self) -> list[ProcessInfo]:
        now = time.time()
        result: dict = {}
        live_keys = set()
        for proc in psutil.process_iter():
            try:
                key = (proc.pid, round(proc.create_time(), 2))
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                self.errors["vanished"] += 1
                continue
            except psutil.AccessDenied:
                key = (proc.pid, 0.0)
            live_keys.add(key)
            primed = self._cpu_primed.get(key)
            cpu = 0.0
            try:
                if primed is None:
                    proc.cpu_percent(None)                # first call primes; returns 0.0
                    self._cpu_primed[key] = proc
                else:
                    cpu = primed.cpu_percent(None)
                    proc = primed
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                self.errors["vanished"] += 1
                continue
            except psutil.AccessDenied:
                self.errors["access_denied"] += 1
            info = snapshot_process(proc, cpu)
            if info is None:
                self.errors["vanished"] += 1
                continue
            if info.access_denied:
                self.errors["access_denied"] += 1
            result[key] = info
            if key not in self._seen:
                self._seen.add(key)
                self.creation_times.append((info.create_time, info.pid, info.name, info.ppid))
        # parent names
        by_pid = {i.pid: i for i in result.values()}
        for i in result.values():
            parent = by_pid.get(i.ppid)
            i.parent_name = parent.name if parent else ""
        # forget processes that ended
        for k in list(self._cpu_primed):
            if k not in live_keys:
                del self._cpu_primed[k]
        self._seen &= live_keys
        self.history.append((now, result))
        return list(result.values())

    def new_processes_since(self, since: float) -> list:
        return [c for c in self.creation_times if c[0] >= since]


class BackgroundMonitor:
    """Runs a callback on each snapshot in a daemon thread until stop()."""

    def __init__(self, engine, interval: float):
        self.engine, self.interval = engine, interval
        self._stop = threading.Event()
        self.thread: threading.Thread | None = None
        self.cycles = 0
        self.last_error = ""

    def _run(self):
        while not self._stop.is_set():
            try:
                self.engine.scan()
                self.cycles += 1
            except Exception as exc:          # keep monitoring; record the problem
                self.last_error = f"{type(exc).__name__}: {exc}"
            self._stop.wait(self.interval)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self._stop.clear()
        self.thread = threading.Thread(target=self._run, name="spd-monitor", daemon=True)
        self.thread.start()

    def stop(self, timeout: float = 10):
        self._stop.set()
        if self.thread:
            self.thread.join(timeout)

    @property
    def running(self) -> bool:
        return bool(self.thread and self.thread.is_alive())


def system_summary() -> dict:
    vm = psutil.virtual_memory()
    return {"cpu_count": psutil.cpu_count() or 1, "cpu_percent": psutil.cpu_percent(None),
            "memory_total": vm.total, "memory_percent": vm.percent, "boot_time": psutil.boot_time(),
            "platform": os.name, "is_admin": is_elevated_session()}


def is_elevated_session() -> bool:
    try:
        return os.geteuid() == 0
    except AttributeError:   # Windows
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
