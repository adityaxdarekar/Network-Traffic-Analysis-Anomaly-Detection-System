"""Suspicious Process Detector - application modules."""
