"""Live psutil collection, exception handling and the read-only guarantee."""
import os
import re
import subprocess
import sys
import time
from pathlib import Path

import psutil
import pytest

from modules import process_monitor as pm
from modules.process_monitor import BackgroundMonitor, ProcessMonitor, snapshot_process

ROOT = Path(__file__).resolve().parent.parent


def test_collect_finds_this_process():
    m = ProcessMonitor()
    procs = m.collect()
    me = [p for p in procs if p.pid == os.getpid()]
    assert me, "own process must be visible"
    p = me[0]
    assert p.name
    assert p.ppid == os.getppid()
    assert p.create_time > 0
    assert p.num_threads >= 1
    assert isinstance(p.cmdline, list)


def test_first_collect_primes_cpu_second_measures():
    m = ProcessMonitor()
    first = {p.key: p for p in m.collect()}
    assert all(p.cpu_percent == 0.0 for p in first.values())
    end = time.time() + 0.3
    while time.time() < end:       # burn a little CPU in this process
        pass
    second = {p.pid: p for p in m.collect()}
    assert second[os.getpid()].cpu_percent > 0


def test_parent_names_filled():
    procs = ProcessMonitor().collect()
    me = next(p for p in procs if p.pid == os.getpid())
    assert me.parent_name == psutil.Process(os.getppid()).name()


def test_vanished_process_is_skipped():
    child = subprocess.Popen([sys.executable, "-c", "pass"])
    proc = psutil.Process(child.pid)
    child.wait()
    time.sleep(0.1)
    assert snapshot_process(proc) is None


class _DeniedProc:
    """psutil.Process stand-in whose fields raise AccessDenied."""
    pid = 4242

    def oneshot(self):
        import contextlib
        return contextlib.nullcontext()

    def as_dict(self, attrs, ad_value):
        d = {a: ad_value for a in attrs}
        d.update(pid=4242, name="protected", ppid=1)
        return d


def test_access_denied_fields_recorded():
    info = snapshot_process(_DeniedProc())
    assert info.name == "protected"
    assert "exe" in info.access_denied
    assert "cmdline" in info.access_denied
    assert info.exe == ""


class _ZombieProc(_DeniedProc):
    def as_dict(self, attrs, ad_value):
        raise psutil.ZombieProcess(4242)


def test_zombie_returns_none():
    assert snapshot_process(_ZombieProc()) is None


def test_creation_events_recorded():
    m = ProcessMonitor()
    m.collect()
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(2)"])
    try:
        m.collect()
        evs = [e for e in m.creation_times if e[1] == child.pid]
        assert evs and evs[0][3] == os.getpid()       # (create_time, pid, name, ppid)
    finally:
        child.wait()


def test_background_monitor_runs_and_stops():
    class E:
        n = 0

        def scan(self):
            E.n += 1
    b = BackgroundMonitor(E(), 0.05)
    b.start()
    time.sleep(0.3)
    b.stop()
    assert not b.running
    assert E.n >= 2


def test_background_monitor_survives_errors():
    class E:
        def scan(self):
            raise RuntimeError("boom")
    b = BackgroundMonitor(E(), 0.05)
    b.start()
    time.sleep(0.15)
    b.stop()
    assert "boom" in b.last_error


FORBIDDEN = re.compile(r"\.(terminate|kill|suspend|resume|nice|ionice|cpu_affinity|rlimit|send_signal)\(|"
                       r"os\.kill\(|os\.remove\(|os\.unlink\(|shutil\.rmtree\(|\.unlink\(|requests\.|urllib\.request")


@pytest.mark.parametrize("path", sorted((ROOT / "modules").glob("*.py")) + [ROOT / "main.py", ROOT / "app.py"])
def test_application_code_never_modifies_processes_or_files(path):
    """The detector itself must be read-only (demo scripts that clean up their OWN temp files are excluded)."""
    if not path.exists():
        pytest.skip("not present")
    src = path.read_text(encoding="utf-8")
    bad = FORBIDDEN.findall(src)
    assert not bad, f"{path.name} contains {bad}"
