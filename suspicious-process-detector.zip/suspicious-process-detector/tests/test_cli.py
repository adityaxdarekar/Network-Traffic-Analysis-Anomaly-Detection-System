"""Terminal interface: every menu option and sub-command runs against the live system."""
import builtins

import pytest

import main as cli


@pytest.fixture
def use_cfg(monkeypatch, cfg):
    monkeypatch.setattr(cli, "load_config", lambda path=None: cfg)
    return cfg


@pytest.mark.parametrize("argv", [["scan"], ["processes"], ["tree"], ["tree", "--all"], ["network"],
                                  ["hashes"], ["alerts"], ["alerts", "--severity", "high"],
                                  ["monitor", "--duration", "2", "--interval", "1"],
                                  ["report", "--formats", "html", "json"]])
def test_subcommands(use_cfg, argv, capsys):
    assert cli.main(argv) == 0
    out = capsys.readouterr().out
    assert "Traceback" not in out


def test_report_writes_files(use_cfg, capsys):
    cli.main(["report", "--formats", "html", "json", "csv", "pdf"])
    assert list((use_cfg.base_dir / "reports" / "pdf").glob("*.pdf"))
    assert list((use_cfg.base_dir / "reports" / "html").glob("*.html"))


def test_ack_unknown_alert(use_cfg, capsys):
    assert cli.main(["ack", "SPD-NOPE"]) == 1


def test_interactive_menu_all_options(use_cfg, monkeypatch, capsys):
    answers = iter(["1", "2", "2", "3", "4", "y", "5", "6", "7", "", "", "", "8", "spd", "9",
                    "10", "cpu_threshold", "95", "10", "memory_threshold", "999", "99", "11"])
    monkeypatch.setattr(builtins, "input", lambda prompt="": next(answers))
    assert cli.main([]) == 0
    out = capsys.readouterr().out
    assert "SUSPICIOUS PROCESS DETECTOR" in out
    assert "cpu_threshold = 95.0" in out or "cpu_threshold = 95" in out
    assert "rejected" in out           # memory_threshold 999 fails validation
    assert "choose 1-11" in out
    assert "error:" not in out


def test_bad_config_exit_code(monkeypatch, tmp_path, capsys):
    p = tmp_path / "c.json"
    p.write_text('{"monitoring_interval": 0}')
    assert cli.main(["--config", str(p), "scan"]) == 2
    assert "configuration error" in capsys.readouterr().out
