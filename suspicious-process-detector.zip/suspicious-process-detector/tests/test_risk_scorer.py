"""Risk scoring, severity bands, alerts, database, reports, configuration and redaction."""
import json
import time

import pytest

from modules.alert_manager import AlertManager
from modules.database import Database
from modules.engine import DetectionEngine
from modules.process_analyzer import Finding
from modules.report_generator import build_report_data, generate_all
from modules.risk_scorer import RiskScorer
from modules.settings import ConfigError, load_config, redact_cmdline


def F(rule, **kw):
    return Finding(rule, rule.replace("_", " "), "desc", "ev", **kw)


@pytest.mark.parametrize("score,sev", [(0, "NONE"), (1, "LOW"), (19, "LOW"), (20, "MEDIUM"), (39, "MEDIUM"),
                                       (40, "HIGH"), (69, "HIGH"), (70, "CRITICAL"), (100, "CRITICAL")])
def test_severity_bands(cfg, score, sev):
    assert RiskScorer(cfg).severity(score) == sev


def test_brief_example_weights(cfg):
    s = RiskScorer(cfg)
    assert s.score([F("suspicious_name")]).score == 20
    assert s.score([F("temp_directory_execution")]).score == 20
    assert s.score([F("suspicious_parent_child")]).score == 25
    assert s.score([F("unknown_hash_untrusted_location")]).score == 10
    assert s.score([F("unusual_network")]).score == 15


def test_sum_and_cap(cfg):
    s = RiskScorer(cfg)
    r = s.score([F("suspicious_name"), F("temp_directory_execution"), F("suspicious_parent_child")])
    assert r.score == 65 and r.severity == "HIGH"
    many = [F(k) for k in cfg["risk_weights"]]
    r2 = s.score(many)
    assert r2.score == 100
    assert "capped" in r2.explanation()


def test_rule_counted_once(cfg):
    r = RiskScorer(cfg).score([F("unusual_network"), F("unusual_network"), F("unusual_network", weight_factor=0.5)])
    assert r.score == 15


def test_context_rule(cfg):
    s = RiskScorer(cfg)
    assert s.score([F("lolbin_with_context", requires_context=True)]).score == 0
    assert s.score([F("lolbin_with_context", requires_context=True), F("suspicious_cmdline")]).score == 35


def test_zero_weight_finding_is_not_context(cfg):
    s = RiskScorer(cfg)
    r = s.score([F("lolbin_with_context", requires_context=True), F("high_memory", weight_factor=0)])
    assert r.score == 0


def test_recommendations_present(cfg):
    r = RiskScorer(cfg).score([F("masquerading")])
    assert any("signature" in x for x in r.recommendations)
    assert any("Isolate" in x for x in r.recommendations)
    assert not RiskScorer(cfg).score([]).recommendations


# ----------------------------------------------------------------- alerts
def _res(cfg, *rules):
    return RiskScorer(cfg).score([F(r) for r in rules])


def test_alert_fields_and_cooldown(cfg, make_proc):
    db = Database(":memory:")
    am = AlertManager(cfg, db)
    p = make_proc("x", "/tmp/x", ["x", "--password", "hunter2"])
    a = am.evaluate(p, _res(cfg, "temp_directory_execution"), 1, now=1000)
    for k in ("alert_id", "timestamp", "pid", "process_name", "exe", "category", "risk_score", "severity",
              "evidence", "recommendations"):
        assert k in a
    assert "hunter2" not in json.dumps(a)
    assert am.evaluate(p, _res(cfg, "temp_directory_execution"), 1, now=1010) is None      # cooldown
    assert am.suppressed == 1
    assert am.evaluate(p, _res(cfg, "temp_directory_execution", "suspicious_name"), 1, now=1011)   # new rule
    assert am.evaluate(p, _res(cfg, "temp_directory_execution"), 1, now=1000 + cfg["alert_cooldown"] + 1)
    assert len(db.alerts()) == 3


def test_below_min_score_no_alert(cfg, make_proc):
    am = AlertManager(cfg, Database(":memory:"))
    assert am.evaluate(make_proc(), _res(cfg, "unknown_hash_untrusted_location")) is None   # 10 < 20


def test_acknowledge_and_search(cfg, make_proc):
    db = Database(":memory:")
    am = AlertManager(cfg, db)
    p = make_proc("evil_name", "/tmp/e", pid=4321)
    a = am.evaluate(p, _res(cfg, "temp_directory_execution", "suspicious_name"), 1)
    assert am.acknowledge(a["alert_id"], "FALSE_POSITIVE", "ana", "dev build")
    row = db.alerts(term="4321")[0]
    assert row["status"] == "FALSE_POSITIVE" and row["analyst_note"] == "dev build"
    assert db.alerts(term="evil")
    assert db.alerts(severity="HIGH")
    assert not db.alerts(severity="LOW")
    with pytest.raises(ValueError):
        db.set_alert_status(a["alert_id"], "DELETE_PROCESS")
    assert not am.acknowledge("nope")


def test_listener_called(cfg, make_proc):
    got = []
    am = AlertManager(cfg)
    am.listeners.append(got.append)
    am.evaluate(make_proc(), _res(cfg, "masquerading"))
    assert got and got[0]["severity"] == "MEDIUM"


# ----------------------------------------------------------------- database
def test_db_sql_injection_safe(cfg):
    db = Database(":memory:")
    assert db.search_processes("'; DROP TABLE alerts; --") == []
    assert db.alerts(term="' OR 1=1 --") == []
    db.q("SELECT COUNT(*) FROM alerts")      # table still exists
    with pytest.raises(ValueError):
        db.export_csv("sqlite_master", "/tmp/x.csv")


def test_process_upsert_tracks_first_last_max(cfg):
    db = Database(":memory:")
    sid = db.start_session("h", "os", 5)
    row = {"pid": 1, "create_time": 1.0, "name": "a", "exe": "/a", "cmdline": "", "username": "u", "ppid": 0,
           "parent_name": "", "sha256": None, "score": 30, "severity": "MEDIUM"}
    db.upsert_processes(sid, [row])
    db.upsert_processes(sid, [{**row, "score": 10, "severity": "LOW", "sha256": "f" * 64}])
    r = db.search_processes("a")[0]
    assert r["max_score"] == 30 and r["severity"] == "MEDIUM" and r["sha256"] == "f" * 64


def test_hash_history(cfg):
    db = Database(":memory:")
    db.record_hash("/a", "1" * 64, 10, 1)
    time.sleep(1.1)
    db.record_hash("/a", "2" * 64, 11, 2)
    assert db.previous_hash("/a") == "2" * 64
    assert {r["versions"] for r in db.hash_rows()} == {2}


# ----------------------------------------------------------------- config
def test_config_validation(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"cpu_threshold": -5, "risk_thresholds": {"low": 50, "medium": 40, "high": 69,
                                                                     "critical": 100}}))
    with pytest.raises(ConfigError) as e:
        load_config(p, base_dir=tmp_path)
    assert "cpu_threshold" in str(e.value) and "risk_thresholds" in str(e.value)


def test_config_bad_json(tmp_path):
    p = tmp_path / "c.json"
    p.write_text("{nope")
    with pytest.raises(ConfigError):
        load_config(p, base_dir=tmp_path)


def test_config_bool_rejected(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"thread_threshold": True}))
    with pytest.raises(ConfigError):
        load_config(p, base_dir=tmp_path)


# ----------------------------------------------------------------- redaction
@pytest.mark.parametrize("cmd,secret", [
    (["mysql", "--password=hunter2"], "hunter2"),
    (["tool", "--token", "abc123"], "abc123"),
    (["tool", "/password:Sup3r"], "Sup3r"),
    (["curl", "-H", "Authorization: Bearer eyJabc.def"], "eyJabc.def"),
    (["git", "clone", "https://user:pa55@github.com/x"], "pa55"),
    (["app", "api_key=XYZ987"], "XYZ987"),
    (["app", "--api-key", "'quoted secret'"], "quoted secret"),
])
def test_redaction(cmd, secret):
    out = redact_cmdline(cmd)
    assert secret not in out and "[REDACTED]" in out


def test_redaction_keeps_normal_args():
    assert redact_cmdline(["python3", "app.py", "--port", "80"]) == "python3 app.py --port 80"


# ----------------------------------------------------------------- engine + reports (live)
def test_engine_live_scan_and_reports(cfg, tmp_path):
    e = DetectionEngine(cfg)
    e.scan()
    s = e.scan()
    assert len(s["processes"]) > 0
    assert all(p.pid in s["results"] for p in s["processes"])
    out = generate_all(e, out_dir=tmp_path / "rep", stem="t")
    e.close()
    html_text = out["html"].read_text()
    for n in range(1, 16):
        assert f"{n}." in html_text or f"{n}-" in html_text
    data = json.loads(out["json"].read_text())
    for k in ("title", "monitoring_start", "monitoring_end", "operating_system", "hostname", "total_processes",
              "suspicious_processes", "process_details", "executable_paths", "hashes", "relationships",
              "connections", "risk_distribution", "alerts", "recommended_actions", "assessment"):
        assert k in data
    assert out["pdf"].read_bytes()[:4] == b"%PDF"
    assert len(out["csv"]) == 3


def test_report_escapes_html(cfg, tmp_path, make_proc):
    e = DetectionEngine(cfg)
    e.scan()
    evil = make_proc("<script>alert(1)</script>", "/tmp/<b>x</b>")
    res = RiskScorer(cfg).score([F("temp_directory_execution"), F("suspicious_name")])
    e.flagged[evil.key] = {"proc": evil, "info": {"result": res, "sha256": None, "location": "temp"},
                           "chain": "<img src=x>", "last_seen": "now"}
    out = generate_all(e, ("html",), out_dir=tmp_path)
    e.close()
    t = out["html"].read_text()
    assert "<script>alert(1)</script>" not in t and "&lt;script&gt;" in t
    assert "<img src=x>" not in t


def test_csv_formula_injection_neutralised(cfg, tmp_path, make_proc):
    e = DetectionEngine(cfg)
    e.scan()
    data = build_report_data(e)
    data["process_details"].insert(0, {**data["process_details"][0], "name": "=HYPERLINK(\"x\")"})
    from modules.report_generator import write_csv
    paths = write_csv(data, tmp_path, "c")
    e.close()
    assert "'=HYPERLINK" in paths[0].read_text()


def test_report_assessment_levels(cfg, tmp_path):
    e = DetectionEngine(cfg)
    e.scan()
    d = build_report_data(e)
    e.close()
    assert d["assessment"]["level"]
    assert "not malware probabilities" in d["disclaimer"]
