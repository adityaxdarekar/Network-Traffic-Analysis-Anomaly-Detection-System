"""
Smoke test for app.py with STAND-INS for Streamlit and Plotly (neither is
installed in the build environment). Every section runs against a LIVE
engine so wiring mistakes are caught; this does NOT prove the real UI
renders correctly (see PROJECT_STATUS.md).
"""
import importlib
import sys
import types

import pytest


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeSt(types.ModuleType):
    current = None

    def __init__(self):
        super().__init__("streamlit")
        self.session_state, self.calls, self.clicks, self.inputs = {}, [], set(), {}
        self.sidebar = _Ctx()
        FakeSt.current = self

    def cache_resource(self, fn=None, **kw):
        return fn if fn else (lambda f: f)

    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def expander(self, *a, **kw):
        return _Ctx()

    def radio(self, label, options, **kw):
        return self.session_state.get("_page", options[0])

    def selectbox(self, label, options, index=0, **kw):
        options = list(options)
        return self.inputs.get(label, options[index] if options else None)

    def multiselect(self, label, options, default=None, **kw):
        return self.inputs.get(label, default or [])

    def slider(self, label, lo, hi, value=None, **kw):
        return self.inputs.get(label, value)

    def number_input(self, label, lo=None, hi=None, value=None, **kw):
        return self.inputs.get(label, value)

    def button(self, label, **kw):
        return label in self.clicks

    def checkbox(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    def text_input(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def download_button(self, label, data, *a, **kw):
        assert data, label
        self.calls.append(("download", label))
        return False

    def __getattr__(self, name):
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


def fake_plotly():
    class Fig:
        def update_layout(self, **kw):
            pass
    calls = []

    def mk(name):
        def f(*a, **kw):
            calls.append(name)
            return Fig()
        return f
    px = types.ModuleType("plotly.express")
    for n in ("line", "bar", "histogram", "pie", "treemap"):
        setattr(px, n, mk(n))
    pl = types.ModuleType("plotly")
    pl.express = px
    return pl, px, calls


@pytest.fixture(params=["plotly", "no-plotly"])
def app(request, monkeypatch, cfg):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    calls = []
    if request.param == "plotly":
        pl, px, calls = fake_plotly()
        monkeypatch.setitem(sys.modules, "plotly", pl)
        monkeypatch.setitem(sys.modules, "plotly.express", px)
    else:
        monkeypatch.setitem(sys.modules, "plotly", None)
        monkeypatch.setitem(sys.modules, "plotly.express", None)
    sys.modules.pop("app", None)
    mod = importlib.import_module("app")
    monkeypatch.setattr(mod, "load_config", lambda: cfg)
    engine = mod.DetectionEngine(cfg)
    engine.scan()
    engine.scan()
    yield mod, fake, engine, request.param, calls
    engine.close()


def errors(fake):
    return [c for c in fake.calls if c[0] in ("error", "exception")]


def test_every_section_renders(app, make_proc):
    mod, fake, engine, mode, calls = app
    from modules.process_analyzer import Finding
    res = engine.scorer.score([Finding("masquerading", "masq", "d", "e")])
    engine.alerts.evaluate(make_proc("svchost.exe", "C:\\Users\\Public\\svchost.exe"), res, engine.session_id)
    assert mod.HAVE_PLOTLY == (mode == "plotly")
    for name, fn in mod.PAGES.items():
        fn(engine)
    assert not errors(fake), errors(fake)
    assert len(mod.SECTIONS) == 10
    if mode == "plotly":
        assert {"pie", "line", "bar", "treemap"} <= set(calls)


def test_reports_and_alert_ack(app, make_proc):
    mod, fake, engine, mode, _ = app
    from modules.process_analyzer import Finding
    p = make_proc("spd_test_tool", "/tmp/spd_test_tool")
    res = engine.scorer.score([Finding("suspicious_name", "name", "d", "e"),
                               Finding("temp_directory_execution", "temp", "d", "e")])
    a = engine.alerts.evaluate(p, res, engine.session_id)
    fake.clicks = {"Generate report"}
    mod.page_reports(engine)
    assert {"HTML report", "PDF report", "JSON", "CSV"} <= {c[1] for c in fake.calls if c[0] == "download"}
    fake.clicks = {"Save acknowledgement"}
    fake.inputs.update({"Alert": a["alert_id"], "Set status": "FALSE_POSITIVE", "Note": "demo"})
    mod.page_alerts(engine)
    assert engine.db.alerts(term="spd_test_tool")[0]["status"] == "FALSE_POSITIVE"
    assert not errors(fake), errors(fake)


def test_threshold_validation_in_settings(app):
    mod, fake, engine, *_ = app
    fake.clicks = {"Apply thresholds"}
    fake.inputs["Memory threshold (% RAM)"] = 500.0
    mod.page_reports(engine)
    assert any(c[0] == "error" for c in fake.calls)
    assert engine.cfg["memory_threshold"] != 500.0


def test_main_runs(app, monkeypatch):
    mod, fake, engine, *_ = app
    monkeypatch.setattr(mod, "get_engine", lambda: engine)
    for s in mod.SECTIONS:
        fake.session_state["_page"] = s
        mod.main()
    assert not errors(fake), errors(fake)
