import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from modules.process_monitor import ProcessInfo  # noqa: E402
from modules.settings import load_config, load_rules  # noqa: E402


@pytest.fixture
def rules():
    return load_rules(ROOT / "data" / "suspicious_processes.json")


@pytest.fixture
def cfg(tmp_path):
    """Config with every writable path inside tmp_path."""
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "suspicious_processes.json").write_text(
        (ROOT / "data" / "suspicious_processes.json").read_text())
    (tmp_path / "data" / "known_hashes.json").write_text(json.dumps({"known_good": {}, "known_bad": {}}))
    (tmp_path / "config.json").write_text((ROOT / "config.json").read_text())
    return load_config(tmp_path / "config.json", base_dir=tmp_path)


@pytest.fixture
def make_proc():
    counter = {"pid": 1000}

    def _make(name="app", exe="/usr/bin/app", cmdline=None, pid=None, ppid=1, username="alice", cpu=0.0, mem=0.5,
              threads=4, cwd="/home/alice", create_time=1_700_000_000.0, parent_name="", deleted=False):
        if pid is None:
            counter["pid"] += 1
            pid = counter["pid"]
        return ProcessInfo(pid=pid, ppid=ppid, name=name, exe=exe, cmdline=cmdline if cmdline is not None else [exe],
                           username=username, status="running", create_time=create_time + pid, cpu_percent=cpu,
                           memory_percent=mem, memory_rss=int(mem * 1e7), num_threads=threads,
                           parent_name=parent_name, exe_deleted=deleted, cwd=cwd)
    return _make
