"""
app.py - Streamlit SOC/EDR-style dashboard for the Suspicious Process Detector.

    streamlit run app.py

Sections: Overview, Live Process Monitor, Suspicious Processes, Process Tree,
Network Connections, Resource Usage, Security Alerts, Process Hash Analysis,
Investigation History, Reports and Settings.

Read-only: the dashboard has no button that kills, suspends or changes a
process. Analysts can only acknowledge alerts and export evidence.
"""
from __future__ import annotations

import time
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAVE_PLOTLY = True
except ImportError:          # dashboard still works with Streamlit's built-in charts
    px = None
    HAVE_PLOTLY = False

from modules.database import ALERT_STATUSES
from modules.engine import DetectionEngine
from modules.report_generator import build_report_data, write_html, write_json, write_pdf
from modules.settings import load_config, redact_cmdline, validate

SECTIONS = ["Overview", "Live Process Monitor", "Suspicious Processes", "Process Tree", "Network Connections",
            "Resource Usage", "Security Alerts", "Process Hash Analysis", "Investigation History",
            "Reports and Settings"]
SEV_COLORS = {"CRITICAL": "#ef4444", "HIGH": "#f97316", "MEDIUM": "#eab308", "LOW": "#22c55e", "NONE": "#64748b"}
CSS = """<style>
.stApp{background:#0b1120;color:#e2e8f0}
section[data-testid="stSidebar"]{background:#0f172a}
.kpi{background:#0f172a;border:1px solid #1e293b;border-radius:10px;padding:12px 14px}
.kpi b{font-size:26px;display:block} .kpi span{color:#94a3b8;font-size:12px}
.sev{padding:1px 8px;border-radius:4px;color:#0b1120;font-weight:700;font-size:12px}
.mono{font-family:ui-monospace,Consolas,monospace;font-size:12.5px}
</style>"""


@st.cache_resource
def get_engine():
    e = DetectionEngine(load_config())
    e.scan()
    time.sleep(1)
    e.scan()
    return e


def kpi(col, value, label, color="#e2e8f0"):
    col.markdown(f'<div class="kpi"><b style="color:{color}">{value}</b><span>{label}</span></div>',
                 unsafe_allow_html=True)


def sev_badge(s):
    return f'<span class="sev" style="background:{SEV_COLORS.get(s, "#64748b")}">{s}</span>'


def chart(kind, df, x, y, title, color=None):
    if df is None or df.empty:
        st.info(f"{title}: no data yet")
        return
    if HAVE_PLOTLY:
        fn = {"line": px.line, "bar": px.bar, "hist": px.histogram, "pie": px.pie}[kind]
        if kind == "pie":
            fig = fn(df, names=x, values=y, title=title, color=x, color_discrete_map=SEV_COLORS, hole=0.45)
        elif kind == "hist":
            fig = fn(df, x=x, nbins=20, title=title)
        else:
            fig = fn(df, x=x, y=y, title=title, color=color,
                     color_discrete_map=SEV_COLORS if color == "severity" else None)
        fig.update_layout(template="plotly_dark", paper_bgcolor="#0b1120", plot_bgcolor="#0f172a",
                          margin=dict(l=10, r=10, t=40, b=10), height=300)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.caption(title + " (install plotly for interactive charts)")
        if kind == "line":
            st.line_chart(df.set_index(x)[y])
        else:
            st.bar_chart(df.set_index(x)[y] if y else df[x].value_counts())


def process_frame(engine) -> pd.DataFrame:
    s = engine.snapshot()
    rows = []
    for p in s["processes"]:
        r = s["results"].get(p.pid, {})
        res = r.get("result")
        rows.append({"PID": p.pid, "PPID": p.ppid, "Name": p.name, "Parent": p.parent_name, "User": p.username,
                     "CPU %": p.cpu_percent, "Memory %": p.memory_percent, "Threads": p.num_threads,
                     "Status": p.status, "Executable": p.exe, "Location": r.get("location"),
                     "Risk": res.score if res else 0, "Severity": res.severity if res else "NONE",
                     "Command line (redacted)": redact_cmdline(p.cmdline)[:300]})
    return pd.DataFrame(rows)


# ===================================================================== sections
def page_overview(engine):
    s = engine.snapshot()
    sus = engine.suspicious()
    counts = engine.db.severity_counts(engine.session_id)
    st.subheader("Overview")
    c = st.columns(5)
    kpi(c[0], len(s["processes"]), "running processes")
    kpi(c[1], len(sus), "suspicious now", "#f97316" if sus else "#22c55e")
    kpi(c[2], len(s["connections"]), "network connections")
    kpi(c[3], f"{s.get('cpu_percent', 0):.0f}%", "system CPU")
    kpi(c[4], f"{s.get('memory_percent', 0):.0f}%", "system memory")
    c = st.columns(5)
    kpi(c[0], counts["CRITICAL"], "critical alerts", SEV_COLORS["CRITICAL"])
    kpi(c[1], counts["HIGH"], "high alerts", SEV_COLORS["HIGH"])
    kpi(c[2], counts["MEDIUM"], "medium alerts", SEV_COLORS["MEDIUM"])
    kpi(c[3], counts["LOW"], "low alerts", SEV_COLORS["LOW"])
    kpi(c[4], f"{engine.uptime() / 60:.1f} min", "monitoring uptime")
    st.caption(f"Host {engine.hostname} · {engine.os} · session {engine.session_id} · last scan {s['last_scan']} UTC · "
               f"network visibility: {s['conn_status']}")
    left, right = st.columns(2)
    with left:
        sev_df = pd.DataFrame([{"severity": k, "alerts": v} for k, v in counts.items() if v])
        chart("pie", sev_df, "severity", "alerts", "Alert severity distribution")
    with right:
        df = process_frame(engine)
        chart("hist", df[df["Risk"] > 0] if not df.empty else df, "Risk", None, "Risk score distribution (score > 0)")
    scans = pd.DataFrame(engine.db.scan_rows(engine.session_id))
    if not scans.empty:
        chart("line", scans, "timestamp", ["total", "suspicious"], "Process activity over time")
    st.info("Scores are heuristic indicators, not malware probabilities. Nothing on this dashboard terminates or "
            "modifies a process.")


def page_live(engine):
    st.subheader("Live Process Monitor")
    df = process_frame(engine)
    q = st.text_input("Filter by name, PID, user or path", "")
    if q and not df.empty:
        m = df.apply(lambda r: q.lower() in " ".join(map(str, r.values)).lower(), axis=1)
        df = df[m]
    sort = st.selectbox("Sort by", ["CPU %", "Memory %", "Risk", "PID", "Threads"])
    if not df.empty:
        df = df.sort_values(sort, ascending=sort == "PID")
    st.dataframe(df, use_container_width=True, hide_index=True, height=520)
    pid = st.text_input("PID for details (open files, connections - where permissions allow)", "")
    if pid.strip().isdigit():
        st.json(engine.process_details(int(pid)))
    st.caption(f"access-denied reads so far: {engine.monitor.errors['access_denied']} · processes that vanished "
               f"mid-read: {engine.monitor.errors['vanished']}")


def page_suspicious(engine):
    st.subheader("Suspicious Processes")
    min_score = st.slider("Minimum risk score", 1, 100, int(engine.cfg["alert_min_score"]))
    sus = engine.suspicious(min_score)
    include_exited = st.checkbox("Include processes that exited earlier this session", value=False)
    items = [(p, r, engine.snapshot()["tree"].chain_text(p.pid), True) for p, r in sus]
    if include_exited:
        live = {p.key for p, _ in sus}
        items += [x for x in engine.session_suspicious() if x[0].key not in live and x[1]["result"].score >= min_score]
    if not items:
        st.success("No process at or above this score. (The heuristics found nothing - that is not proof the "
                   "system is clean.)")
        return
    for p, r, chain, running in items:
        res = r["result"]
        with st.expander(f"[{res.severity}] {p.name} · PID {p.pid} · score {res.score}"
                         f"{'' if running else ' · exited'}", expanded=res.score >= 40):
            st.markdown(f"{sev_badge(res.severity)} &nbsp; <span class='mono'>{p.exe or '(path unavailable)'}</span>",
                        unsafe_allow_html=True)
            st.markdown(f"**Chain:** `{chain}`")
            st.markdown(f"**Score:** {res.explanation()}")
            st.dataframe(pd.DataFrame([{"Finding": f.category, "Evidence": f.evidence, "Why it matters": f.description}
                                       for f in res.findings]), hide_index=True, use_container_width=True)
            st.markdown("**Recommended defensive actions (manual):**")
            for rec in res.recommendations:
                st.markdown(f"- {rec}")


def page_tree(engine):
    st.subheader("Process Tree")
    s = engine.snapshot()
    hl = {p.pid: r["result"].severity for p, r in engine.suspicious()}
    only = st.checkbox("Show only branches leading to flagged processes", value=bool(hl))
    root = st.text_input("Start from PID (optional)", "")
    text = s["tree"].render(hl, root=int(root) if root.strip().isdigit() else None,
                            only_suspicious_branches=only and bool(hl))
    st.code(text or "(no processes)", language="text")
    st.caption("'<== [SEVERITY]' marks a flagged process; '(parent of flagged)' marks its ancestors. A relationship "
               "is a lead to investigate, not proof of malware.")
    rows = pd.DataFrame(s["tree"].rows())
    if HAVE_PLOTLY and not rows.empty:
        rows["label"] = rows["name"] + " [" + rows["pid"].astype(str) + "]"
        ids = set(rows["pid"])
        rows["parent"] = rows["ppid"].where(rows["ppid"].isin(ids), None)
        rows["parent_label"] = rows["parent"].map(dict(zip(rows["pid"], rows["label"]))).fillna("")
        rows["flag"] = rows["pid"].map(hl).fillna("NONE")
        fig = px.treemap(rows, names="label", parents="parent_label", color="flag", color_discrete_map=SEV_COLORS)
        fig.update_layout(template="plotly_dark", paper_bgcolor="#0b1120", height=520, margin=dict(t=20, l=0, r=0, b=0))
        st.plotly_chart(fig, use_container_width=True)


def page_network(engine):
    st.subheader("Network Connections")
    s = engine.snapshot()
    st.caption(f"visibility: {s['conn_status']} · remote scope is an address class only; no IP address is labelled "
               f"malicious without threat-intelligence evidence.")
    df = pd.DataFrame([c.to_dict() for c in s["connections"]])
    if df.empty:
        st.info("No connections visible.")
        return
    status = st.multiselect("Status", sorted(df["status"].unique()), default=sorted(df["status"].unique()))
    df = df[df["status"].isin(status)]
    st.dataframe(df, use_container_width=True, hide_index=True)
    by = df.groupby("process_name").size().reset_index(name="connections").sort_values("connections", ascending=False)
    chart("bar", by.head(15), "process_name", "connections", "Connections per process")


def page_resources(engine):
    st.subheader("Resource Usage")
    df = process_frame(engine)
    scans = pd.DataFrame(engine.db.scan_rows(engine.session_id))
    if not scans.empty:
        chart("line", scans, "timestamp", ["cpu_percent", "memory_percent"], "System CPU and memory usage (%)")
    if not df.empty:
        left, right = st.columns(2)
        with left:
            chart("bar", df.nlargest(10, "CPU %"), "Name", "CPU %", "Top CPU (% of one core)")
        with right:
            chart("bar", df.nlargest(10, "Memory %"), "Name", "Memory %", "Top memory (% of RAM)")
    st.caption(f"Rules: CPU >= {engine.cfg['cpu_threshold']}% for {engine.cfg['cpu_duration_seconds']}s · memory >= "
               f"{engine.cfg['memory_threshold']}% of RAM · threads >= {engine.cfg['thread_threshold']} · "
               f"{engine.cfg['process_creation_threshold']} children in {engine.cfg['process_creation_window']}s. "
               f"Allow-listed heavy apps are informational only.")


def page_alerts(engine):
    st.subheader("Security Alerts")
    c = st.columns(3)
    sev = c[0].multiselect("Severity", ["CRITICAL", "HIGH", "MEDIUM", "LOW"], default=["CRITICAL", "HIGH", "MEDIUM", "LOW"])
    status = c[1].selectbox("Status", ["ALL"] + list(ALERT_STATUSES))
    term = c[2].text_input("Search PID or process name", "")
    rows = engine.db.alerts(severity=sev or None, term=term.strip(), status=None if status == "ALL" else status)
    if not rows:
        st.info("No alerts match.")
        return
    df = pd.DataFrame(rows)
    st.dataframe(df[["alert_id", "timestamp", "severity", "pid", "process_name", "category", "risk_score", "status"]],
                 use_container_width=True, hide_index=True)
    ids = [r["alert_id"] for r in rows]
    aid = st.selectbox("Alert", ids)
    a = next(r for r in rows if r["alert_id"] == aid)
    st.markdown(f"{sev_badge(a['severity'])} **{a['category']}** · PID {a['pid']} · {a['process_name']} · "
                f"score {a['risk_score']}", unsafe_allow_html=True)
    st.markdown(f"<span class='mono'>{a['exe'] or ''}</span>", unsafe_allow_html=True)
    st.markdown("**Evidence**")
    for ev in a["evidence"]:
        st.markdown(f"- {ev}")
    st.markdown("**Recommended defensive actions**")
    for r in a["recommendations"]:
        st.markdown(f"- {r}")
    st.markdown("**Analyst acknowledgement**")
    c = st.columns(3)
    new_status = c[0].selectbox("Set status", ["ACKNOWLEDGED", "FALSE_POSITIVE", "RESOLVED"])
    analyst = c[1].text_input("Analyst", "analyst")
    note = c[2].text_input("Note", "")
    if st.button("Save acknowledgement"):
        ok = engine.alerts.acknowledge(aid, new_status, analyst, note)
        (st.success if ok else st.error)("saved" if ok else "alert not found")
    st.download_button("Export alerts CSV", df.to_csv(index=False).encode(), "alerts.csv", "text/csv")


def page_hashes(engine):
    st.subheader("Process Hash Analysis")
    st.caption("SHA-256 computed locally. Executables are never uploaded. 'unknown' means not in "
               "data/known_hashes.json - most legitimate software is unknown to a local list.")
    s = engine.snapshot()
    seen, rows = set(), []
    for p in s["processes"]:
        sha = s["results"][p.pid].get("sha256")
        if sha and p.exe not in seen:
            seen.add(p.exe)
            prev = engine._baseline.get(p.exe)
            rows.append({"Process": p.name, "Path": p.exe, "SHA-256": sha, "Reputation": engine.hasher.reputation(sha),
                         "vs previous session": "-" if not prev else ("same" if prev == sha else "CHANGED")})
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.json(engine.hasher.stats)
    hist = pd.DataFrame(engine.db.hash_rows())
    if not hist.empty:
        st.markdown("**Hash history (all sessions)**")
        st.dataframe(hist, use_container_width=True, hide_index=True)
        st.download_button("Export hash records CSV", hist.to_csv(index=False).encode(), "hashes.csv", "text/csv")


def page_history(engine):
    st.subheader("Investigation History")
    st.dataframe(pd.DataFrame(engine.db.sessions()), use_container_width=True, hide_index=True)
    term = st.text_input("Search process history (name, path or PID)", "")
    min_score = st.slider("Minimum max-score", 0, 100, 0)
    procs = pd.DataFrame(engine.db.search_processes(term.strip(), min_score))
    st.dataframe(procs, use_container_width=True, hide_index=True)
    net = pd.DataFrame(engine.db.network_rows(term.strip()))
    st.markdown("**Network records**")
    st.dataframe(net, use_container_width=True, hide_index=True)
    if not procs.empty:
        st.download_button("Export process records CSV", procs.to_csv(index=False).encode(), "processes.csv", "text/csv")
    if not net.empty:
        st.download_button("Export network records CSV", net.to_csv(index=False).encode(), "network.csv", "text/csv")


def page_reports(engine):
    st.subheader("Reports and Settings")
    if st.button("Generate report"):
        data = build_report_data(engine)
        out = engine.cfg.path("reports")
        stem = f"spd_report_{datetime.now():%Y%m%d_%H%M%S}"
        html_p = write_html(data, out, stem + ".html")
        json_p = write_json(data, out, stem + ".json")
        pdf_p = write_pdf(data, out, stem + ".pdf")
        st.session_state["report"] = {"html": html_p.read_bytes(), "json": json_p.read_bytes(),
                                      "pdf": pdf_p.read_bytes(), "stem": stem,
                                      "csv": pd.DataFrame(data["process_details"]).to_csv(index=False).encode()}
        st.success(f"Saved to {out} · assessment: {data['assessment']['level']}")
    rep = st.session_state.get("report")
    if rep:
        c = st.columns(4)
        c[0].download_button("HTML report", rep["html"], rep["stem"] + ".html", "text/html")
        c[1].download_button("PDF report", rep["pdf"], rep["stem"] + ".pdf", "application/pdf")
        c[2].download_button("JSON", rep["json"], rep["stem"] + ".json", "application/json")
        c[3].download_button("CSV", rep["csv"], rep["stem"] + ".csv", "text/csv")
    st.markdown("---")
    st.markdown("**Detection thresholds (this dashboard session; edit config.json to make permanent)**")
    cfg = engine.cfg
    c = st.columns(3)
    new = {
        "monitoring_interval": c[0].number_input("Monitoring interval (s)", 0.5, 3600.0, float(cfg["monitoring_interval"])),
        "cpu_threshold": c[1].number_input("CPU threshold (% of one core)", 1.0, 10000.0, float(cfg["cpu_threshold"])),
        "cpu_duration_seconds": c[2].number_input("CPU duration (s)", 0.0, 86400.0, float(cfg["cpu_duration_seconds"])),
        "memory_threshold": c[0].number_input("Memory threshold (% RAM)", 0.1, 100.0, float(cfg["memory_threshold"])),
        "process_creation_threshold": int(c[1].number_input("Process creation threshold", 2, 100000,
                                                            int(cfg["process_creation_threshold"]))),
        "alert_cooldown": c[2].number_input("Alert cooldown (s)", 0.0, 86400.0, float(cfg["alert_cooldown"])),
    }
    if st.button("Apply thresholds"):
        errs = validate({**cfg, **new})
        if errs:
            st.error("; ".join(errs))
        else:
            cfg.update(new)
            st.success("applied")
    st.markdown("**Risk weights**")
    st.json(cfg["risk_weights"])
    st.json(cfg["risk_thresholds"])


PAGES = dict(zip(SECTIONS, [page_overview, page_live, page_suspicious, page_tree, page_network, page_resources,
                            page_alerts, page_hashes, page_history, page_reports]))


def main():
    st.set_page_config(page_title="Suspicious Process Detector", page_icon="🛡️", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    engine = get_engine()
    with st.sidebar:
        st.markdown("## 🛡️ Suspicious Process Detector")
        st.caption("Defensive, read-only endpoint monitor")
        page = st.radio("Section", SECTIONS)
        if st.button("Scan now"):
            engine.scan()
        auto = st.checkbox("Auto-refresh (live monitoring)", value=False)
        bg = st.checkbox("Background monitoring thread", value=bool(engine.background and engine.background.running))
        if bg:
            engine.start_background()
        else:
            engine.stop_background()
        st.caption(f"scans: {engine.snapshot()['scans']} · interval {engine.cfg['monitoring_interval']}s")
        if not HAVE_PLOTLY:
            st.warning("plotly not installed - using basic charts")
    PAGES[page](engine)
    if auto:
        if not bg:
            engine.scan()
        time.sleep(float(engine.cfg["monitoring_interval"]))
        st.rerun()


if __name__ == "__main__":
    main()
