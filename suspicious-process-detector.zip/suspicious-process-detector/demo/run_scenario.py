#!/usr/bin/env python3
"""
run_scenario.py - HARMLESS test processes for demonstrating the detector.

Nothing here is malware or imitates malware behaviour beyond what the
detector needs to see: processes that sleep, burn one CPU core for a limited
time, hold a limited amount of memory, start one child that sleeps, or open
a TCP connection to 127.0.0.1. Every scenario has a hard runtime limit and
cleans up its temporary files.

    python3 demo/run_scenario.py name      [--seconds 60]
    python3 demo/run_scenario.py path      [--seconds 60]
    python3 demo/run_scenario.py cpu       [--seconds 45]          (hard max 120)
    python3 demo/run_scenario.py memory    [--mb 200 --seconds 40] (hard max 1024 MB)
    python3 demo/run_scenario.py parent    [--seconds 40]
    python3 demo/run_scenario.py network   [--seconds 40 --port 8765]
    python3 demo/run_scenario.py masquerade [--seconds 60]         (Linux/macOS)
    python3 demo/run_scenario.py spawn     [--count 25]            (rapid creation, children sleep 3 s)
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEST_AREA = HERE / "test_area"
MAX_SECONDS = 120
IS_WIN = os.name == "nt"


def _limit(seconds: float) -> float:
    return max(1.0, min(float(seconds), MAX_SECONDS))


def _cpu_rlimit(seconds):
    """Linux/macOS: kernel-enforced CPU-time cap for this process as a second safety net."""
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (int(seconds) + 5, int(seconds) + 10))
    except (ImportError, ValueError, OSError):
        pass


def _sleeper_binary() -> tuple[str, list]:
    """A harmless system binary to copy under a test name, and the args that make it wait."""
    if IS_WIN:
        return os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "PING.EXE"), \
            ["-n", "{s}", "127.0.0.1"]
    return shutil.which("sleep") or "/bin/sleep", ["{s}"]


def _run_copy(dest: Path, seconds: float) -> int:
    src, args = _sleeper_binary()
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    print(f"[scenario] copied harmless {src} -> {dest}")
    p = subprocess.Popen([str(dest)] + [a.format(s=int(seconds)) for a in args],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"[scenario] started PID {p.pid} for {int(seconds)} s")
    try:
        p.wait(timeout=seconds + 5)
    except subprocess.TimeoutExpired:
        p.kill()     # our own test child only
    finally:
        try:
            dest.unlink()
        except OSError:
            pass
    return p.pid


def scenario_name(seconds):
    """Test 2: a process whose name matches the TEST RULE 'spd_test_tool' (not a real tool)."""
    name = "spd_test_tool.exe" if IS_WIN else "spd_test_tool"
    _run_copy(TEST_AREA / name, seconds)


def scenario_path(seconds):
    """Test 3: a harmless Python script run from a dedicated temporary directory."""
    d = Path(tempfile.mkdtemp(prefix="spd_test_"))
    script = d / "temp_test_app.py"
    script.write_text(f"import time\nprint('harmless temp-dir test app; sleeping')\ntime.sleep({int(seconds)})\n")
    print(f"[scenario] running {script}")
    try:
        p = subprocess.Popen([sys.executable, str(script)], stdout=subprocess.DEVNULL)
        print(f"[scenario] started PID {p.pid}")
        p.wait(timeout=seconds + 5)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def scenario_cpu(seconds):
    """Test 4a: one core busy for a limited time (hard limit 120 s, plus RLIMIT_CPU)."""
    seconds = _limit(seconds)
    _cpu_rlimit(seconds)
    print(f"[scenario] PID {os.getpid()} busy-looping on one core for {seconds:.0f} s")
    end, x = time.time() + seconds, 0
    while time.time() < end:
        x = (x * 31 + 7) % 1_000_003
    print("[scenario] cpu test finished")


def scenario_memory(mb, seconds):
    """Test 4b: hold a bounded block of memory (max 1024 MB, never more than 25 % of RAM)."""
    try:
        import psutil
        cap = int(psutil.virtual_memory().total / 1048576 * 0.25)
    except Exception:
        cap = 1024
    mb = max(1, min(int(mb), 1024, cap))
    seconds = _limit(seconds)
    block = bytearray(mb * 1048576)
    for i in range(0, len(block), 4096):      # touch pages so RSS really grows
        block[i] = 1
    print(f"[scenario] PID {os.getpid()} holding {mb} MB for {seconds:.0f} s")
    time.sleep(seconds)
    del block


def scenario_parent(seconds):
    """Test 5: a parent named like an office app ('spd_office_sim') starts a shell child that only sleeps."""
    seconds = _limit(seconds)
    d = TEST_AREA / "parent_child"          # inside the project, not a temp folder: isolates the relationship
    d.mkdir(parents=True, exist_ok=True)
    parent = d / "spd_office_sim.py"
    child_cmd = (["cmd.exe", "/c", f"ping -n {int(seconds)} 127.0.0.1 >NUL"] if IS_WIN
                 else ["sh", "-c", f"sleep {int(seconds)}"])
    parent.write_text(
        "import subprocess, sys\n"
        f"p = subprocess.Popen({child_cmd!r})\n"
        "print(f'[spd_office_sim] parent PID {__import__(\"os\").getpid()} started child PID {p.pid}', flush=True)\n"
        f"p.wait(timeout={int(seconds) + 10})\n")
    try:
        subprocess.run([sys.executable, str(parent)], timeout=seconds + 15)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def scenario_network(seconds, port):
    """Test 7: local TCP server on 127.0.0.1 and a client that connects to it. Loopback only."""
    seconds = _limit(seconds)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(5)
    print(f"[scenario] PID {os.getpid()} listening on 127.0.0.1:{port}")
    client_code = ("import socket,time\n"
                   f"s=socket.create_connection(('127.0.0.1',{port}))\n"
                   "s.sendall(b'hello from harmless client')\n"
                   f"time.sleep({int(seconds) - 2})\ns.close()\n")
    cl = subprocess.Popen([sys.executable, "-c", client_code])
    print(f"[scenario] client PID {cl.pid} connected")
    srv.settimeout(5)
    conn, _ = srv.accept()
    print(f"[scenario] server received: {conn.recv(64)!r}")
    time.sleep(max(0, seconds - 3))
    conn.close()
    srv.close()
    cl.wait(timeout=10)


def scenario_masquerade(seconds):
    """Extra: a copy of 'sleep' named like a system daemon ('sshd') in a temp folder."""
    if IS_WIN:
        print("masquerade demo is for Linux/macOS (use 'name' on Windows)")
        return
    d = Path(tempfile.mkdtemp(prefix="spd_masq_"))
    try:
        _run_copy(d / "sshd", seconds)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def scenario_spawn(count):
    """Extra: start `count` children (max 40) that each sleep 3 s - rapid process creation."""
    count = max(1, min(int(count), 40))
    cmd = (["cmd.exe", "/c", "ping -n 4 127.0.0.1 >NUL"] if IS_WIN else ["sleep", "3"])
    kids = [subprocess.Popen(cmd, stdout=subprocess.DEVNULL) for _ in range(count)]
    print(f"[scenario] PID {os.getpid()} started {count} short-lived children")
    for k in kids:
        k.wait(timeout=15)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("scenario", choices=["name", "path", "cpu", "memory", "parent", "network", "masquerade", "spawn"])
    ap.add_argument("--seconds", type=float, default=45)
    ap.add_argument("--mb", type=int, default=200)
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--count", type=int, default=25)
    a = ap.parse_args(argv)
    s = _limit(a.seconds)
    {"name": lambda: scenario_name(s), "path": lambda: scenario_path(s), "cpu": lambda: scenario_cpu(s),
     "memory": lambda: scenario_memory(a.mb, s), "parent": lambda: scenario_parent(s),
     "network": lambda: scenario_network(s, a.port), "masquerade": lambda: scenario_masquerade(s),
     "spawn": lambda: scenario_spawn(a.count)}[a.scenario]()


if __name__ == "__main__":
    main()
