#!/usr/bin/env python3
"""
run_all_demos.py - runs DEMO_GUIDE Tests 1-8 end to end against the LIVE
system: starts each harmless scenario from run_scenario.py, scans with the
real detection engine, prints what was detected, and finally writes HTML,
JSON, CSV and PDF reports.

    python3 demo/run_all_demos.py                 # all tests (~3 minutes)
    python3 demo/run_all_demos.py --tests 2 3 7   # selected tests
    python3 demo/run_all_demos.py --quick         # CPU rule shortened to 10 s

Demo-only setting changes (printed when used): memory_threshold is lowered so
a 400 MB test allocation crosses it (on an 8 GB machine 400 MB = ~5 %), and the scan interval is 2 s.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from modules.engine import DetectionEngine          # noqa: E402
from modules.hash_analyzer import HashAnalyzer       # noqa: E402
from modules.report_generator import generate_all    # noqa: E402
from modules.settings import load_config             # noqa: E402

SCEN = [sys.executable, str(ROOT / "demo" / "run_scenario.py")]


def banner(t):
    print("\n" + "=" * 78 + f"\n {t}\n" + "=" * 78, flush=True)


def start(*args):
    return subprocess.Popen(SCEN + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)


def scan_for(engine, seconds, interval=2.0):
    end = time.time() + seconds
    while time.time() < end:
        engine.scan()
        time.sleep(interval)
    engine.scan()


def show(engine, match, label):
    hits = [(p, r) for p, r in engine.suspicious(1) if match(p)]
    if not hits:
        print(f"  [!] no process matched for {label}")
    for p, r in hits:
        res = r["result"]
        print(f"  [{res.severity}] PID {p.pid} {p.name}  score {res.score}/100")
        print(f"      path : {p.exe}")
        print(f"      chain: {engine.snapshot()['tree'].chain_text(p.pid)}")
        print(f"      score: {res.explanation()}")
        for f in res.findings:
            print(f"       * {f.category}: {f.evidence[:120]}")
    return hits


def finish(proc):
    try:
        out, _ = proc.communicate(timeout=60)
    except subprocess.TimeoutExpired:
        proc.kill()      # only ever our own scenario process
        out, _ = proc.communicate()
    for line in (out or "").strip().splitlines():
        print("   scenario> " + line)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--tests", nargs="*", type=int, default=list(range(1, 9)))
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--report-stem", default="demo_report")
    a = ap.parse_args(argv)
    over = {"monitoring_interval": 2, "memory_threshold": 4.0}
    if a.quick:
        over["cpu_duration_seconds"] = 10
    cfg = load_config(overrides=over)
    print(f"DEMO SETTINGS (changed for the demo only): {over}. Everything else from config.json.")
    engine = DetectionEngine(cfg)
    engine.scan()
    time.sleep(1)
    results = {}

    if 1 in a.tests:
        banner("TEST 1 - Normal process monitoring")
        engine.scan()
        s = engine.snapshot()
        print(f"  processes: {len(s['processes'])}  connections: {len(s['connections'])}  "
              f"network visibility: {s['conn_status']}")
        for p in sorted(s["processes"], key=lambda p: -p.memory_percent)[:8]:
            print(f"  PID {p.pid:>6}  {p.name[:22]:22}  CPU {p.cpu_percent:5.1f}%  MEM {p.memory_percent:5.2f}%  "
                  f"{(p.exe or '-')[:40]}")
        base = engine.suspicious()
        print(f"  baseline processes at/above alert score {cfg['alert_min_score']}: {len(base)}")
        results[1] = True

    if 2 in a.tests:
        banner("TEST 2 - Suspicious process name (harmless copy of 'sleep' named spd_test_tool)")
        pr = start("name", "--seconds", "12")
        scan_for(engine, 6)
        results[2] = bool(show(engine, lambda p: p.name.startswith("spd_test_tool"), "name"))
        finish(pr)

    if 3 in a.tests:
        banner("TEST 3 - Execution from a temporary directory (harmless Python script)")
        pr = start("path", "--seconds", "12")
        scan_for(engine, 6)
        results[3] = bool(show(engine, lambda p: any("temp_test_app.py" in x for x in p.cmdline), "path"))
        finish(pr)
        pr = start("masquerade", "--seconds", "10")
        print("  -- extra: copy of 'sleep' named 'sshd' running from a temp folder")
        scan_for(engine, 5)
        show(engine, lambda p: p.name == "sshd" and "spd_masq_" in (p.exe or ""), "masquerade")
        finish(pr)

    if 4 in a.tests:
        dur = cfg["cpu_duration_seconds"]
        banner(f"TEST 4 - Resource consumption (CPU loop {dur + 10:.0f}s, memory 400 MB)")
        pr = start("cpu", "--seconds", str(dur + 10))
        pm = start("memory", "--mb", "400", "--seconds", str(min(dur + 10, 60)))
        scan_for(engine, dur + 5)
        ok_cpu = show(engine, lambda p: "cpu" in p.cmdline and "run_scenario.py" in " ".join(p.cmdline), "cpu")
        ok_mem = show(engine, lambda p: "memory" in p.cmdline and "run_scenario.py" in " ".join(p.cmdline), "memory")
        results[4] = bool(ok_cpu and ok_mem)
        finish(pr)
        finish(pm)
        print("  -- extra: rapid process creation (25 children that sleep 3 s)")
        ps = start("spawn", "--count", "25")
        time.sleep(1.0)
        engine.scan()
        show(engine, lambda p: "spawn" in p.cmdline, "spawn")
        finish(ps)

    if 5 in a.tests:
        banner("TEST 5 - Parent-child analysis (spd_office_sim.py starts 'sh -c sleep')")
        pr = start("parent", "--seconds", "12")
        scan_for(engine, 6)
        hits = show(engine, lambda p: p.parent_name and "spd_office_sim" in " ".join(
            engine.snapshot()["tree"].by_pid.get(p.ppid).cmdline if engine.snapshot()["tree"].by_pid.get(p.ppid) else []),
            "parent-child")
        if hits:
            p = hits[0][0]
            hl = {p.pid: hits[0][1]["result"].severity}
            print("\n  process tree (flagged branch only):")
            for line in engine.snapshot()["tree"].render(hl, only_suspicious_branches=True).splitlines():
                print("    " + line)
        results[5] = bool(hits)
        finish(pr)

    if 6 in a.tests:
        banner("TEST 6 - Hash analysis (harmless test script)")
        f = ROOT / "demo" / "test_area" / "hash_demo_tool.py"
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text("print('harmless hash demo v1')\n")
        h = HashAnalyzer({}, 16)
        sha1, st1 = h.sha256(str(f))
        engine.db.record_hash(str(f), sha1, f.stat().st_size, engine.session_id)
        print(f"  v1 sha256 = {sha1} ({st1}); stored in SQLite table 'hashes'")
        time.sleep(0.05)
        f.write_text("print('harmless hash demo v2 - one line changed')\n")
        sha2, st2 = h.sha256(str(f))
        prev = engine.db.q("SELECT sha256 FROM hashes WHERE path=? AND sha256<>? ORDER BY last_seen DESC LIMIT 1",
                           (str(f), sha2))
        changed = bool(prev) and prev[0]["sha256"] != sha2
        engine.db.record_hash(str(f), sha2, f.stat().st_size, engine.session_id)
        print(f"  v2 sha256 = {sha2} ({st2})")
        print(f"  comparison with stored hash: {'CHANGED' if changed else 'same'}")
        print(f"  reputation (known_hashes.json): {h.reputation(sha2)}  <- 'unknown' is not evidence of malware")
        f.unlink()
        results[6] = changed

    if 7 in a.tests:
        banner("TEST 7 - Network monitoring (local server + client on 127.0.0.1:8765)")
        pr = start("network", "--seconds", "12", "--port", "8765")
        time.sleep(2)
        scan_for(engine, 4)
        s = engine.snapshot()
        mine = [c for c in s["connections"] if 8765 in (c.local_port, c.remote_port)]
        for c in mine:
            print(f"  PID {c.pid:>6} {c.process_name[:16]:16} {c.protocol:4} {c.local:>21} -> {c.remote or '-':21} "
                  f"{c.status:12} scope={c.remote_scope}")
        show(engine, lambda p: any(c.pid == p.pid and c.status == "LISTEN" for c in mine), "listener")
        results[7] = len(mine) >= 2
        finish(pr)

    if 8 in a.tests:
        banner("TEST 8 - Report generation")
        engine.scan()
        engine.ended = None
        out = generate_all(engine, out_dir=ROOT / "sample_output", stem=a.report_stem)
        for k, v in out.items():
            for p in (v if isinstance(v, list) else [v]):
                print(f"  {k.upper():5} {p.relative_to(ROOT)}")
        counts = engine.db.severity_counts(engine.session_id)
        print(f"  alerts this session: {counts}")
        results[8] = all(Path(p).exists() for v in out.values() for p in (v if isinstance(v, list) else [v]))

    engine.close()
    banner("SUMMARY")
    for t in sorted(results):
        print(f"  Test {t}: {'PASS' if results[t] else 'NOT DETECTED'}")
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
