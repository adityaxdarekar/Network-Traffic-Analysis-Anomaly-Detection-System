# Demonstration Guide — Tests 1 to 8

Every scenario is **harmless**. No real malware or credential-theft tool is executed. The "suspicious" processes are copies of `sleep` with test names, sleeping Python scripts, a bounded CPU loop, a bounded memory block, and a TCP server and client on `127.0.0.1`. Each scenario has a hard runtime limit and deletes its own temporary files. The detector never touches the test processes. They exit on their own.

All expected output below is **real output** captured in the build environment (Ubuntu 24.04, 2 CPUs, 8 GB RAM, running as root), taken from `sample_output/demo_run_all_tests.txt`. On your machine the PIDs, paths, hashes and counts will differ.

**Run everything:**

```bash
python3 demo/run_all_demos.py          # Tests 1-8, about 3 minutes
python3 demo/run_all_demos.py --quick  # CPU rule shortened to 10 s
python3 demo/run_all_demos.py --tests 2 5 7
```

**Demo-only settings.** The runner prints these. The scan interval is 2 s. `memory_threshold` is set to 4 % so that a 400 MB test block (about 5 % of 8 GB) crosses it. The default rule of 80 % of RAM is deliberately not reproduced with a real allocation. On a machine with a different amount of RAM, adjust `--mb` and the threshold.

**Manual alternative (two terminals).** Run the monitor in one terminal:

```bash
python3 main.py monitor --duration 120
```

Then start each scenario in the other:

```bash
python3 demo/run_scenario.py <name|path|cpu|memory|parent|network|masquerade|spawn>
```

---

## Test 1 — Normal process monitoring

**Command:** `python3 main.py` → option **2**, or `python3 main.py processes`

**Expected (real, excerpt):**

```
  processes: 68  connections: 11  network visibility: ok
  PID     94  claude                  CPU   0.0%  MEM  3.36%  /opt/claude-code/bin/claude
  PID     87  environment-manager     CPU   0.0%  MEM  0.49%  /opt/env-runner/environment-manager
  PID    391  python3                 CPU   9.8%  MEM  0.37%  /usr/local/bin/python3.13
  baseline processes at/above alert score 20: 0
```

**Explanation.** The first sample primes CPU counters, so the tool always takes two samples before showing CPU %. The baseline machine produced **no alert-level processes**. A few LOW scores did appear: a `memfd` telemetry process, a shell script that base64-decodes a value, and loopback listeners. Those are honest heuristic hits on legitimate software, and they are why LOW does not alert.

**Screenshot suggestion:** the process table sorted by CPU, plus the header line showing totals.

## Test 2 — Suspicious process name detection

**Command:** `python3 demo/run_scenario.py name --seconds 60`, then menu option **3**

**What it does.** It copies the system `sleep` binary to `demo/test_area/spd_test_tool` and runs it. On Windows it copies `PING.EXE`. `spd_test_tool` is a **TEST RULE** in `data/suspicious_processes.json`.

**Expected (real):**

```
  [MEDIUM] PID 393 spd_test_tool  score 30/100
      path : /home/claude/suspicious-process-detector/demo/test_area/spd_test_tool
      score: TEST RULE - harmless demonstration name (20) + Unknown executable hash (10) = 30
```

**Explanation.** The name match gives 20 points. The executable is outside trusted folders and its hash is not in `known_hashes.json`, which adds 10. That gives 30, which is MEDIUM, and an alert is raised. Legitimate tools such as `powershell.exe` and `cmd.exe` are context-required and score 0 on their own (see `tests/test_detection.py::test_powershell_alone_scores_zero`).

**Screenshot:** `screenshots/02_demo_tests_2_3.png`

## Test 3 — Suspicious execution path

**Command:** `python3 demo/run_scenario.py path --seconds 60`

**What it does.** It writes `temp_test_app.py`, which only sleeps, to a fresh `/tmp/spd_test_*` folder (`%TEMP%` on Windows) and runs it with Python.

**Expected (real):**

```
  [MEDIUM] PID 395 python3  score 30/100
      score: Script executed from temporary directory (20) + Privileged process from unusual location (10) = 30
       * Script executed from temporary directory: script: /tmp/spd_test_ccyri547/temp_test_app.py; interpreter: /usr/local/bin/python3.13
```

**Explanation.** The interpreter itself (`/usr/local/bin/python3.13`) is in a trusted location. The detector resolves the **script** path from the command line and the process working directory. "Privileged…" appears because the demo ran as root. As a normal user that line disappears and the score is 20.

**Extra (masquerading):**

```bash
python3 demo/run_scenario.py masquerade
```

This runs a copy of `sleep` named `sshd` from a temp folder:

```
  [CRITICAL] PID 397 sshd  score 70/100
      score: Possible process masquerading (30) + Execution from temporary directory (20) + Privileged process from unusual location (10) + Unknown executable hash (10) = 70
```

**Screenshot:** `screenshots/02_demo_tests_2_3.png`

## Test 4 — Resource consumption detection

**Commands:**

```bash
python3 demo/run_scenario.py cpu --seconds 40
python3 demo/run_scenario.py memory --mb 400 --seconds 40
```

**Limits.** The CPU scenario uses a single core and is capped at 120 s, with a second cap through RLIMIT_CPU on Linux. The memory scenario is capped at 1024 MB and at 25 % of RAM, and releases the memory at the end.

**Expected (real):**

```
  [MEDIUM] PID 400 python3  score 20/100
      score: Sustained high CPU usage (20) = 20
       * Sustained high CPU usage: cpu: 100.2% for 35s
  [MEDIUM] PID 401 python3  score 20/100
       * High memory usage: memory: 5.2% (417 MiB RSS)        (demo threshold 4 %)
  -- extra: rapid process creation (25 children that sleep 3 s)
  [HIGH] PID 406 python3  score 40/100
       * Rapid process creation: 25 children in 10s; most common: sleep x25
```

**Explanation.** CPU must stay at or above 90 % (of one core) for 30 s. A short spike only counts when another indicator exists, so builds don't alert. The brief's severities are reproduced: CPU is MEDIUM, memory is MEDIUM, and rapid creation is HIGH. Browsers, compilers and IDEs in `resource_intensive_allowlist` are recorded with 0 points, which avoids repeated alerts for normal heavy apps.

**Screenshot:** `screenshots/03_demo_tests_4_5_tree.png`

## Test 5 — Parent-child process analysis

**Command:** `python3 demo/run_scenario.py parent`, then menu option **4**

**What it does.** `demo/test_area/parent_child/spd_office_sim.py` simulates an "office application" and starts `sh -c "sleep 40"` (`cmd.exe /c ping …` on Windows).

**Expected (real):**

```
  [MEDIUM] PID 434 sh  score 25/100
       * Suspicious parent-child: Office application spawning a command interpreter: parent python3 running spd_office_sim (PID 433) -> child sh (PID 434)

  process tree (flagged branch only):
    ...
            └── python3 [433]  (parent of flagged)
                └── sh [434]  <== [MEDIUM]
```

**Explanation.** For interpreter processes, the parent is matched by its process name **and** its script name, so `python3 spd_office_sim.py` counts as `spd_office_sim`. That name is listed alongside `winword.exe`, `excel.exe` and others in the rule. The evidence states that a relationship alone is not proof of malware.

**Screenshot:** `screenshots/05_menu_process_tree.png`

## Test 6 — Hash analysis

**Command:** part of `run_all_demos.py --tests 6`. You can also use menu option **6**, or `python3 main.py hashes --export hashes.csv`.

**Expected (real):**

```
  v1 sha256 = bf22203fb81ee74ead5ac219a1b42fa935efb00b8385c9bc47807247d8368532 (ok); stored in SQLite table 'hashes'
  v2 sha256 = 71201f36985b051fd05e431ee8260dffd3354eac16714478a867279c4a205b5a (ok)
  comparison with stored hash: CHANGED
  reputation (known_hashes.json): unknown  <- 'unknown' is not evidence of malware
```

**Explanation.** Files are hashed locally in 1 MiB chunks. Results are cached by size and mtime, so only changed files are re-hashed. Every running executable's hash is stored per path. In the next session, a different hash for the same path produces an "Executable hash changed" finding worth 15 points, which is normal after updates. Nothing is ever uploaded.

## Test 7 — Network connection monitoring

**Command:** `python3 demo/run_scenario.py network --port 8765`, then menu option **5**

**Expected (real):**

```
  PID    439 python3  TCP  127.0.0.1:41800 -> 127.0.0.1:8765   ESTABLISHED  scope=loopback
  PID    438 python3  TCP   127.0.0.1:8765 -> -                LISTEN       scope=none
  PID    438 python3  TCP   127.0.0.1:8765 -> 127.0.0.1:41800  ESTABLISHED  scope=loopback
  [LOW] PID 438 python3  score 8/100
       * Unexpected listening service: listening: TCP/8765 on 127.0.0.1
```

**Explanation.** Port 8765 is not in `allowed_listening_ports`. Because the listener is loopback-only, it gets half weight (8 points, LOW, no alert). On `0.0.0.0` it would score 15. Remote addresses are classified only as loopback, private, public and so on. **No IP is called malicious.**

## Test 8 — Report generation

**Command:** menu option **9**, `python3 main.py report`, or the dashboard's "Reports and Settings" section.

**Expected (real):**

```
  HTML  sample_output/html/demo_report.html
  JSON  sample_output/json/demo_report.json
  CSV   sample_output/csv/demo_report_{processes,alerts,connections}.csv
  PDF   sample_output/pdf/demo_report.pdf        (8 pages)
  alerts this session: {'CRITICAL': 1, 'HIGH': 1, 'MEDIUM': 5, 'LOW': 0}
```

**Explanation.** The report covers the whole session, including processes that had already exited. It contains all 15 required items and ends with a final assessment and the heuristic disclaimer. Command lines are redacted.

**Screenshots:** `screenshots/07_html_report_top.png`, `08_html_report_full.png`, `09_pdf_report_page-1.png`

---

### Suggested screenshot list for the college report

1. Banner and menu (`main.py`).
2. Live monitoring with a CRITICAL alert (`01_live_monitor_alerts.png`).
3. Suspicious process details.
4. Process tree with the flagged branch.
5. Network table.
6. Hash table.
7. Alerts table.
8. HTML report.
9. PDF report.
10. Each dashboard section. **Take these yourself after `pip install streamlit plotly`**, because the dashboard could not be screenshotted in the build environment.
