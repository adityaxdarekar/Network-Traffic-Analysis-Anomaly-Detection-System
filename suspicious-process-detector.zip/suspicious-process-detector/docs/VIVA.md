# Viva Preparation — 40 Questions and Answers

**1. What is a process?**
A process is a program in execution. It has its own memory space, one or more threads, open handles (files and sockets), a security context (user or token) and an entry in the OS process table. Running the same program twice creates two processes.

**2. What is a PID?**
The Process ID is a number the OS assigns to identify a running process. PIDs are reused after a process exits. That is why this project identifies a process by the pair (PID, create_time).

**3. What is a PPID?**
The Parent Process ID is the PID of the process that created this one. It lets us build the process tree. On Windows the parent may have exited, and its PID may even have been reused, so a PPID must be interpreted carefully.

**4. What is psutil?**
psutil is a cross-platform Python library (Linux, Windows, macOS, BSD) for retrieving information about processes and system utilisation: CPU, memory, disks, network, sensors. It wraps OS-specific sources such as `/proc` on Linux and the Win32 and NT APIs on Windows.

**5. What is process monitoring?**
Process monitoring is the continuous observation of which processes start, run and exit, and how they behave: resources, files, network and children. It is done to detect performance problems or security threats.

**6. What is malware?**
Malware is software designed to harm or gain unauthorised access, for example viruses, worms, trojans, ransomware, spyware, cryptominers and backdoors.

**7. What is a suspicious process?**
A suspicious process is one whose properties or behaviour deviate from what is expected and resemble attacker tradecraft: an odd location, a masqueraded name, an unusual parent, encoded commands, unexpected network activity. Suspicious does **not** mean malicious. It means "investigate".

**8. What is process injection?**
Process injection is a technique (MITRE T1055) where malicious code is written into, and executed inside, another legitimate process. Examples are DLL injection, process hollowing and APC injection. It is used to evade detection and inherit privileges. This project does **not** detect it, because that needs memory scanning or API hooking.

**9. What is process masquerading?**
Process masquerading (T1036) means disguising a malicious program as a legitimate one, using a system name such as `svchost.exe` from the wrong folder or a look-alike such as `scvhost.exe`. The project checks system names against their expected folders and flags look-alikes one edit away.

**10. What is a parent-child relationship?**
It is the link between a process and the process that created it. Some links are normal (`explorer.exe` → `chrome.exe`). Others are classic attack patterns (`winword.exe` → `powershell.exe`).

**11. What is CPU utilisation?**
CPU utilisation is the share of processor time a process used over an interval. psutil reports it per process as a percentage of one core, so it can exceed 100 % on multi-core systems. It needs two samples.

**12. What is memory utilisation?**
Memory utilisation is how much RAM a process uses. The resident set size (RSS) is its physical memory. The project uses RSS as a percentage of total RAM (`memory_percent`).

**13. What is SHA-256?**
SHA-256 is a cryptographic hash function from the SHA-2 family. It produces a 256-bit digest. It is one-way, and collisions are practically impossible to find, so the digest acts as a unique fingerprint of the file's content.

**14. What is a file hash?**
A file hash is a fixed-size digest computed from a file's bytes. If one byte changes, the hash changes completely. Hashes are used to identify known files, check integrity and share IOCs.

**15. What is Endpoint Detection and Response?**
EDR is security software on endpoints that continuously records activity (processes, files, network, registry), detects threats with rules and behaviour analytics, and supports investigation and response, such as isolating a host.

**16. What is EDR?**
EDR stands for Endpoint Detection and Response (see Q15). Examples are Microsoft Defender for Endpoint, CrowdStrike Falcon and SentinelOne. This project implements a small, read-only subset: detection and investigation, without automated response.

**17. What is an IOC?**
An Indicator of Compromise is an observable artefact that suggests an intrusion, such as a malicious file hash, IP, domain, file path or registry key.

**18. What is behavioural detection?**
Behavioural detection identifies threats by what a program *does* (spawning shells, beaconing, mass file changes) rather than by what it *is* (its signature). It catches new or renamed malware but needs tuning to avoid false positives.

**19. What is anomaly detection?**
Anomaly detection flags deviations from normal patterns, for example CPU held above 90 % for 30 s or 25 children in 10 s. This project uses fixed thresholds. A future version could learn per-host baselines.

**20. What is a false positive?**
A false positive is an alert on benign activity. For example, an admin script starting `curl` from bash, or the build-environment shell script running `base64 -d` that scored LOW in our baseline. A false negative is malicious activity that goes undetected.

**21. What is privilege escalation?**
Privilege escalation means gaining higher permissions than granted, for example from a normal user to root or SYSTEM, by exploiting vulnerabilities or misconfigurations. The project flags root or SYSTEM processes running from user-writable folders.

**22. What is a network connection?**
A network connection is a communication endpoint pair: local IP and port, and remote IP and port. Each has a protocol (TCP or UDP) and a state (LISTEN, ESTABLISHED, TIME_WAIT…). psutil maps sockets to the PIDs that own them.

**23. What is process enumeration?**
Process enumeration means listing the running processes and their properties. Defenders do it to monitor, and attackers do it to find security tools or targets (T1057). Here it is `psutil.process_iter()`.

**24. How does this project detect suspicious processes?**
Each scan collects every process and runs independent checks: name, command line, location, masquerading, parent-child, resources, network and hash. Each check produces findings with evidence. A weighted scorer combines them. Each rule counts once, context-only rules need another indicator, and the total is capped at 100 and mapped to a severity. Alerts are raised at 20 and above, with a cooldown.

**25. What are the limitations of psutil?**
- It polls, so it misses short-lived processes.
- Visibility depends on privileges, and protected processes deny access.
- It has no kernel event stream.
- It cannot see memory contents, injected code, handles in detail, or Windows-specific data such as signatures and tokens.
- Some fields differ across operating systems.
- Connection-to-PID mapping can need root.

**26. Why doesn't the tool kill malicious processes automatically?**
Automatic response on heuristic evidence can cause outages: killing a legitimate admin tool or a system service. Killing a process also destroys volatile evidence. The brief requires defensive monitoring only. The analyst decides.

**27. Why is `powershell.exe` not flagged by its name?**
PowerShell is a legitimate built-in tool used constantly by administrators. It is marked `context_required`, so it scores only when another indicator is present, such as an Office parent, an encoded command or an unusual location.

**28. What does "the risk score is not a probability" mean?**
The points come from expert-chosen weights, not from statistics on labelled malware. A score of 70 means "several strong indicators coincide, look now". It does not mean a 70 % chance of malware.

**29. How is CPU % measured correctly?**
The first `cpu_percent(None)` call for a process stores a baseline and returns 0. The next call returns usage since then. The monitor keeps the same `Process` object between scans for this reason.

**30. How do you avoid alert floods?**
- Alerts are only raised at a minimum score.
- There is a cooldown per signature (name, path and the set of rules).
- Heavy applications such as browsers and compilers are allow-listed for resource rules.
- CPU must be sustained, not a spike.
- Loopback listeners get half weight.

**31. Why hash executables if most hashes are "unknown"?**
Hashes allow comparison across sessions (detecting replaced binaries), matching against an analyst's known-bad list, export to threat-intel tools, and evidence in reports.

**32. Why don't you upload hashes or files to VirusTotal?**
The brief forbids automatic uploads. Uploading files can leak confidential data, and even hash lookups reveal what software you run. The project stays offline. Lookups would be a manual, opt-in step.

**33. How are passwords in command lines protected?**
`redact_cmdline()` masks the values after `--password`, `--token`, `/pwd:`, `api_key=`, `Authorization: Bearer` and URL credentials before anything is logged, stored or reported.

**34. How does the tool handle AccessDenied?**
It uses `as_dict(..., ad_value=…)`, so the fields it cannot read are recorded in `access_denied` while the rest are kept. A process is never dropped just because one field is protected. Checks that need a missing path, such as masquerading, simply don't fire.

**35. What happens if a process exits during a scan?**
psutil raises `NoSuchProcess` or `ZombieProcess`. The monitor catches these, counts them as "vanished" and continues.

**36. How is the system thread-safe?**
Scans run in one background thread. The engine updates its state dictionary under a lock, and the UIs read copies. SQLite access goes through a re-entrant lock with `check_same_thread=False`, in WAL mode.

**37. How did you test it without real malware?**
- Harmless stand-ins: a renamed `sleep`, sleeping scripts in temp folders, a time-limited CPU loop, a bounded memory block, a parent script spawning `sh`, and a loopback TCP server.
- 141 unit, integration and smoke tests, including a test that fails if kill or delete calls appear in the application code.

**38. What is a LOLBin?**
A Living-off-the-Land Binary is a legitimate, signed OS tool that attackers abuse to avoid dropping their own malware, for example `certutil`, `mshta`, `rundll32` and `bitsadmin`.

**39. What is fileless malware, and how does the project notice it?**
Fileless malware runs from memory without a file on disk. On Linux the project flags processes whose executable is `/memfd:…` or `(deleted)`. It cannot see in-memory payloads inside legitimate processes.

**40. What would you improve first?**
- Event-driven collection (ETW, Sysmon or eBPF) to catch short-lived processes.
- Signature verification.
- Per-host baselines to cut false positives.
- MITRE ATT&CK tags on alerts.
