# Suspicious Process Detector Using Python and psutil
### College Project Report

---

## 1. Abstract

Malware has to run as a process to do anything, so the list of running processes is one of the richest sources of evidence on an endpoint. This project implements a defensive, read-only **Suspicious Process Detector** in Python using the cross-platform `psutil` library.

At a configurable interval it collects each process's identity, executable path, command line, parent, user, resource use, threads and network connections. It then applies seven groups of heuristics: suspicious names, command-line patterns, execution location, masquerading, parent-child relationships, resource anomalies and network behaviour. It also calculates SHA-256 hashes of executables and compares them across sessions.

Findings are combined by a weighted, explainable risk scorer (0–100, LOW to CRITICAL), turned into de-duplicated alerts with recommended defensive actions, stored in SQLite, and presented through a terminal interface, a Streamlit dashboard and HTML, PDF, JSON and CSV reports.

Eight harmless test scenarios were executed against a live Linux system. All eight were detected with the expected severity, and 141 automated tests pass. The tool never terminates or modifies processes, and its scores are presented as heuristic indicators rather than malware probabilities.

## 2. Introduction

Endpoint Detection and Response (EDR) products such as Microsoft Defender for Endpoint, CrowdStrike Falcon and open-source tools like Sysmon with Wazuh continuously observe process activity, because attacker behaviour shows up there. Examples include:

- a Word document launching PowerShell;
- a binary called `svchost.exe` running from a Downloads folder;
- a cryptominer pinning the CPU;
- an unknown program opening connections to the internet.

Commercial EDRs are expensive and opaque. Students and small organisations benefit from a transparent tool that shows *how* such detections work. This project builds that tool with standard Python libraries, using `psutil` as the single cross-platform source of process information on Linux and Windows.

## 3. Problem Statement

Manually inspecting hundreds of processes with Task Manager or `ps` is slow, and it misses relationships (who started what), history (what changed since yesterday) and context (why a legitimate tool is running somewhere unusual). Simple name blacklists produce false positives on legitimate utilities such as PowerShell, and they miss renamed malware.

The problem is to design a system that:

- monitors processes continuously;
- evaluates name, path, command line, parent and behaviour **together**;
- explains why a process was flagged;
- avoids alert floods;
- stores evidence for later investigation;
- never interferes with the system it is protecting.

## 4. Project Objectives

1. Collect live process information with psutil and handle AccessDenied, NoSuchProcess and ZombieProcess gracefully.
2. Detect suspicious names using configurable rules that distinguish always-suspicious tools from context-dependent system utilities.
3. Analyse executable and script locations: temp, Downloads/AppData, hidden folders, deleted or memory-only binaries, and masquerading.
4. Detect CPU, memory, thread and process-creation anomalies with configurable thresholds.
5. Build process trees and evaluate configurable parent-child rules.
6. Hash executables with SHA-256, store the hashes, and detect changes between sessions without uploading anything.
7. Monitor process network connections and flag unexpected listeners and unusual outbound activity without labelling IPs malicious.
8. Compute an explainable, capped risk score and severity.
9. Generate de-duplicated alerts with recommended actions and manual acknowledgement.
10. Provide a terminal UI, a web dashboard and professional reports.

## 5. Existing System

| Approach | Limitations |
|---|---|
| Task Manager / `ps` / `top` | Manual, no history, no relationships, no scoring |
| Antivirus signature scanning | Misses unknown/renamed malware and living-off-the-land techniques; file-centric, not behaviour-centric |
| Sysmon + SIEM | Powerful but complex to deploy and tune; Windows-centric |
| Commercial EDR | Costly, closed-source, not suitable for teaching |
| Process Explorer | Excellent manual tool but no automated rules, alerts or reports |

## 6. Proposed System

The proposed system is a lightweight Python application. It:

- polls processes every N seconds using psutil's efficient `oneshot()` reads;
- converts every observation into a **finding** with evidence and an explanation;
- scores findings with configurable weights, using a *context rule* so that legitimate system tools are not flagged on name alone;
- raises alerts only above a threshold and with a cooldown;
- stores everything in SQLite for history and comparison;
- offers three interfaces: terminal, dashboard and reports.

It is strictly read-only. The analyst decides what to do.

## 7. System Architecture

```
 ┌───────────── Presentation ─────────────┐
 │ main.py (menu/CLI)   app.py (Streamlit) │──► reports (HTML/PDF/JSON/CSV)
 └───────────────────┬────────────────────┘
                     ▼
 ┌──────────────── DetectionEngine ───────────────────────────────────────┐
 │ ProcessMonitor → ProcessTree → [ProcessAnalyzer, RelationshipAnalyzer,  │
 │ BehaviorDetector, NetworkAnalyzer, HashAnalyzer] → RiskScorer →         │
 │ AlertManager                                                            │
 └───────────────────┬─────────────────────────────────────────────────────┘
                     ▼
 ┌──── Data ─────────────────────────────────────────────────────────────┐
 │ config.json · suspicious_processes.json · known_hashes.json · SQLite   │
 │ (sessions, processes, hashes, alerts, network_records, scans) · logs   │
 └────────────────────────────────────────────────────────────────────────┘
```

A background thread (`BackgroundMonitor`) runs scans. The engine keeps the latest state behind a lock, and the UIs read snapshots of that state.

## 8. Hardware Requirements

| Component | Minimum | Recommended |
|---|---|---|
| CPU | Dual-core x86-64 | Quad-core |
| RAM | 2 GB | 4 GB+ (for the dashboard) |
| Disk | 200 MB | 1 GB for long histories |
| Network | Not required (fully offline) | — |

Measured cost in the test environment: the first scan of 68 processes took about 120–220 ms (it hashes executables), and later scans took about 30 ms.

## 9. Software Requirements

| Software | Version |
|---|---|
| OS | Kali Linux 2024+, Ubuntu 22.04/24.04, Windows 10/11 |
| Python | 3.10+ (tested on 3.13) |
| psutil | 5.9+ (tested 7.2.2) |
| pandas, colorama, tabulate, reportlab | current |
| streamlit, plotly | for the dashboard |
| SQLite | bundled with Python |
| pytest | for tests |

## 10. Module Descriptions

- **settings.py** loads JSON configuration, validates every value (types, ranges, threshold order) and redacts secrets in command lines.
- **process_monitor.py** defines the `ProcessInfo` dataclass and collects processes. It reads with `oneshot()`, primes CPU counters, keys each process by (PID, create_time) to survive PID reuse, records creation events, and runs the background thread.
- **process_analyzer.py** holds the name rules, the context-required LOLBin rule, command-line regexes, location classification, interpreter script resolution, masquerading by expected path, look-alike names (optimal string alignment distance 1), and missing or memfd executables.
- **process_tree.py** builds the tree, ancestor chains and ASCII rendering, and evaluates parent-child rules (matching interpreter script names as well).
- **behavior_detector.py** detects sustained CPU, memory, threads and rapid process creation, with an allow-list for heavy applications.
- **hash_analyzer.py** computes cached SHA-256, checks the known-good and known-bad lists and detects hash changes.
- **network_monitor.py** collects connections, classifies IP scope, and detects unexpected listeners, many connections, and untrusted executables with public connections.
- **risk_scorer.py** produces the weighted score, applies the context rule and the cap, and supplies severity, explanation and recommendations.
- **alert_manager.py** creates alerts with de-duplication, cooldown, listeners and acknowledgement.
- **database.py** provides the SQLite schema, upserts, search, filters and CSV export.
- **engine.py** orchestrates scans and keeps state, session history and logging.
- **report_generator.py** writes HTML, PDF, JSON and CSV reports.
- **main.py** and **app.py** are the user interfaces.

## 11. Process Monitoring Methodology

1. `psutil.process_iter()` enumerates PIDs.
2. For each process, `as_dict(attrs=[...], ad_value=…)` inside `oneshot()` reads all fields with as few system calls as possible. Fields the OS refuses are recorded in `access_denied` instead of aborting the scan.
3. CPU % is the change in CPU time between two calls. The first call per process primes the counter, so the tool keeps the same `psutil.Process` object across scans.
4. Processes that vanish mid-read (`NoSuchProcess`, `ZombieProcess`) are counted and skipped.
5. Parent names come from the same snapshot, which avoids extra lookups.
6. Each new (PID, create_time) is recorded as a creation event with its PPID.
7. Open files and per-process connections are read **on demand** for a selected PID, because they are expensive.

## 12. Suspicious Behaviour Detection Methodology

| Detection | Logic |
|---|---|
| Suspicious name | Exact case-insensitive match on the process name, exe basename or interpreter script name. |
| LOLBin (powershell, cmd, mshta, rundll32…) | Flagged with `requires_context`. It scores **only if** another indicator exists. |
| Command line | Regexes for encoded PowerShell, hidden windows, download cradles, IEX, `mshta http…`, `certutil -urlcache`, `curl … \| sh`, `nc -e`, `/dev/tcp`, `base64 -d`. |
| Location | Temp, user-writable or hidden folders for the executable, or for the script an interpreter runs. Trusted system folders are recognised. |
| Masquerading | A system name (`svchost.exe`, `lsass.exe`, `sshd`…) outside its expected folder, or a Windows name one edit away (`svch0st.exe`, `scvhost.exe`). |
| Missing executable | The binary was deleted after start, or it is memfd (fileless). |
| Privileged + unusual location | root or SYSTEM running from a writable location. |
| Parent-child | Office app → shell, browser → script engine, script → network tool, remote admin service → shell. |
| Resources | CPU ≥ threshold continuously for N s; memory ≥ % of RAM; thread count; ≥ N children of one parent in a window. |
| Network | Listener on a non-allowed port (half weight on loopback), ≥ N established connections, untrusted-location exe talking to public IPs. |
| Hash | Known-bad list match (with its source), unknown hash outside trusted folders, hash changed since a previous session. |

## 13. Risk Scoring Methodology

```
score = min(100, Σ_rules weight(rule) × factor(rule))
   – each rule counts once (strongest factor)
   – context-required rules count only if another rule scored > 0
   – factor: 1.0 normally, 0.5 for loopback-only listeners, 0 for allow-listed heavy apps
severity: 0 NONE · 1-19 LOW · 20-39 MEDIUM · 40-69 HIGH · 70-100 CRITICAL
```

Weights are taken from the brief where it gives values: name 20, temp 20, parent-child 25, unknown hash 10, network 15, resource 10. The rest were chosen so that the brief's example severities hold:

- sustained CPU 20 → MEDIUM;
- memory 20 → MEDIUM;
- rapid creation 40 → HIGH;
- threads 10 → LOW;
- masquerading 30;
- a known-bad hash 50.

Every score is shown with its explanation, for example "Possible process masquerading (30) + Execution from temporary directory (20) + … = 70". **The score indicates how much attention a process deserves. It is not a probability of maliciousness.**

## 14. Database Design

| Table | Key columns |
|---|---|
| sessions | id, started, ended, hostname, os, interval, scans |
| processes | pid, create_time (unique together), name, exe, cmdline (redacted), username, ppid, parent_name, sha256, first_seen, last_seen, max_score, severity |
| hashes | path + sha256 (PK), size, first_seen, last_seen, session_id |
| alerts | alert_id (PK), timestamp, pid, process_name, exe, category, risk_score, severity, description, evidence (JSON), recommendations (JSON), status, analyst, analyst_note, acknowledged_at |
| network_records | session, pid, process, protocol, local, remote, remote_scope, status (unique), first_seen, timestamp |
| scans | session, timestamp, total, suspicious, connections, cpu %, memory %, new_alerts |

All queries are parameterised. The only dynamic table name (CSV export) is checked against a fixed list. WAL mode and a re-entrant lock make the database safe for the monitoring thread and the UI together.

## 15. Implementation

The system is implemented in about 3,300 lines of Python across 12 modules, two UIs and two demo scripts. Notable implementation points:

- PID reuse is handled by keying on (PID, create_time).
- Interpreter script paths are resolved against the process's working directory.
- The engine keeps a session-wide record of flagged processes, so reports include processes that already exited.
- Reports escape all HTML and prefix CSV cells that start with `= + - @`, which prevents formula injection.
- Command lines are redacted (`--password=…`, `--token …`, `Authorization: Bearer …`, `user:pass@` in URLs, `api_key=`) before reaching logs, the database, alerts or reports.
- The dashboard works without Plotly, falling back to built-in charts.

## 16. Testing and Results

**Automated tests: 141 passed.**

- `test_process_monitor.py`: live collection, CPU priming, vanished, zombie and access-denied handling, the background thread, and a source scan proving no kill, terminate or delete calls.
- `test_detection.py`: every rule, including negative cases (PowerShell alone = 0, trusted paths clean, `ssh` not a look-alike of `sshd`).
- `test_risk_scorer.py`: severity bands, cap, context, alerts, cooldown, acknowledgement, SQL injection safety, redaction, and live report generation with HTML escaping.
- `test_cli.py`: all menu options and sub-commands.
- `test_app_smoke.py`: all 10 dashboard sections with stand-ins for Streamlit and Plotly.

**Live demonstration (harmless scenarios, Ubuntu 24.04, root):**

| Test | Scenario | Result | Score / severity |
|---|---|---|---|
| 1 | Baseline monitoring | 68 processes, 0 at alert level | — |
| 2 | `sleep` copy named `spd_test_tool` | Detected | 30 MEDIUM |
| 3 | Python script from `/tmp/spd_test_*` | Detected | 30 MEDIUM |
| 3+ | `sleep` copy named `sshd` in `/tmp` | Detected | 70 CRITICAL |
| 4 | CPU loop (40 s) | Sustained CPU after 30 s | 20 MEDIUM |
| 4 | 400 MB block (demo threshold 4 %) | High memory | 20 MEDIUM |
| 4+ | 25 children in 1 s | Rapid creation | 40 HIGH |
| 5 | `spd_office_sim.py` → `sh` | Parent-child | 25 MEDIUM |
| 6 | Hash, modify, re-hash | Change detected | — |
| 7 | TCP 127.0.0.1:8765 server and client | 3 sockets mapped to PIDs, loopback listener | 8 LOW |
| 8 | Reports | HTML, JSON, 3 CSV, PDF (8 pages) | 7 alerts |

On the baseline system, legitimate processes received LOW scores (for example a memfd sandbox component and a shell script running `base64 -d`). This is a real illustration of false positives, and of why LOW does not alert.

## 17. Advantages

- Transparent, explainable scores with evidence and reasons.
- Context-aware: legitimate system tools are not flagged by name alone.
- Cross-platform through psutil, and fully offline.
- Configurable rules and thresholds without code changes.
- Strictly read-only, with redaction of secrets.
- History and hash comparison across sessions.
- Three interfaces, and reports suitable for documentation.

## 18. Limitations

- **Polling.** Processes shorter than the interval can be missed. Real EDRs use kernel callbacks or ETW.
- **No process-injection detection.** Memory regions are not scanned. Injected code inside a legitimate process is invisible.
- **No signature verification.** Authenticode and package-owner checks are recommended manually, not performed.
- **Visibility depends on privileges.** Protected Windows processes and other users' processes on Linux need elevation.
- **Heuristics produce false positives and false negatives.** Thresholds need tuning per environment, and attackers can choose benign names and paths.
- **No threat intelligence.** `known_hashes.json` ships empty, so "unknown" is uninformative until an analyst builds a baseline.
- **Cross-run de-duplication.** The cooldown lives in memory, so restarting the tool can repeat an alert for a process that is still running.
- **Not run on Windows.** The Windows code paths (paths, PING-based demo, admin detection) were written but only executed on Linux.
- **The Streamlit dashboard was smoke-tested with stand-ins, not rendered in a browser.**

## 19. Future Enhancements

- Event-driven collection: Sysmon/ETW on Windows, eBPF or the audit netlink on Linux.
- Authenticode and package signature checks, and YARA scanning of executables.
- Optional, opt-in hash-only threat-intelligence lookups (VirusTotal or MISP), never file uploads.
- Per-host behavioural baselining (normal parents, ports and CPU profiles) for anomaly detection.
- Persistent alert de-duplication across runs, and a SIEM export (syslog, JSON lines).
- MITRE ATT&CK technique tags on each rule (T1036 masquerading, T1059 command interpreters…).
- Central server mode for many endpoints.

## 20. Conclusion

The project shows that a small, transparent Python tool can reproduce the core ideas of endpoint detection:

- collect process telemetry safely;
- judge each process in context (path, parent, command line, behaviour and network) rather than by name;
- explain every score.

All eight harmless demonstration scenarios were detected with the expected severity on a live system, and 141 automated tests verify the rules, the safety guarantees and the interfaces. The limitations above make clear that it is a learning and triage tool, not a replacement for a commercial EDR. Its findings are leads for an analyst, not verdicts.
