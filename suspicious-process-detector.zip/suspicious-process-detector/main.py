#!/usr/bin/env python3
"""
main.py - terminal interface for the Suspicious Process Detector.

    python3 main.py                         interactive menu (11 options)
    python3 main.py monitor --duration 60   live monitoring for 60 s
    python3 main.py scan                    one scan, print suspicious processes
    python3 main.py report --formats html json
    python3 main.py alerts [--severity HIGH] [--search name|pid]
    python3 main.py ack ALERT_ID --status FALSE_POSITIVE --note "admin script"
    python3 main.py hashes [--export FILE] [--baseline]

Defensive and read-only: this program never terminates, suspends or modifies
processes, and never deletes or uploads files.
"""
from __future__ import annotations

import argparse
import sys
import time
from datetime import datetime, timezone

from colorama import Fore, Style, init as colorama_init
from tabulate import tabulate

from modules.engine import DetectionEngine
from modules.report_generator import generate_all
from modules.settings import ConfigError, load_config

colorama_init()
SEV_COL = {"CRITICAL": Fore.RED + Style.BRIGHT, "HIGH": Fore.LIGHTRED_EX, "MEDIUM": Fore.YELLOW,
           "LOW": Fore.GREEN, "NONE": Fore.WHITE}
BANNER = r"""
  ____  ____  ____     ____                  _      _                    ____
 / ___||  _ \|  _ \   / ___| _   _ ___ _ __ (_) ___(_) ___  _   _ ___   |  _ \ _ __ ___   ___
 \___ \| |_) | | | |  \___ \| | | / __| '_ \| |/ __| |/ _ \| | | / __|  | |_) | '__/ _ \ / __|
  ___) |  __/| |_| |   ___) | |_| \__ \ |_) | | (__| | (_) | |_| \__ \  |  __/| | | (_) | (__
 |____/|_|   |____/   |____/ \__,_|___/ .__/|_|\___|_|\___/ \__,_|___/  |_|   |_|  \___/ \___|
                                      |_|
=================================================================================================
                SUSPICIOUS PROCESS DETECTOR  -  defensive, read-only endpoint monitor
=================================================================================================
"""
MENU = ["Start Live Process Monitoring", "View All Running Processes", "View Suspicious Processes",
        "View Process Tree", "View Network Connections", "Analyze Executable Hashes", "View Security Alerts",
        "View Investigation History", "Generate Security Report", "Configuration Settings", "Exit"]


def c(sev, text=None):
    return f"{SEV_COL.get(sev, '')}{text if text is not None else sev}{Style.RESET_ALL}"


def short(s, n):
    s = "" if s is None else str(s)
    return s if len(s) <= n else s[: n - 3] + "..."


def print_alert(a):
    print(f"\n{c(a['severity'], '[' + a['severity'] + ']')} {Style.BRIGHT}{a['category']}{Style.RESET_ALL}  "
          f"({a['alert_id']})")
    print(f"  PID: {a['pid']}   Name: {a['process_name']}   Risk Score: {a['risk_score']}")
    print(f"  Path: {a['exe'] or '(unavailable)'}")
    for ev in a["evidence"][:6]:
        print(f"  - {short(ev, 150)}")
    if a["recommendations"]:
        print(f"  Recommended: {a['recommendations'][0]}")


def header(engine, status="ACTIVE"):
    s = engine.snapshot()
    sus = engine.suspicious()
    print(f"{Style.BRIGHT}Monitoring Status:{Style.RESET_ALL} {Fore.GREEN}{status}{Style.RESET_ALL}   "
          f"OS: {engine.os}   Host: {engine.hostname}   Interval: {engine.cfg['monitoring_interval']}s")
    counts = engine.db.severity_counts(engine.session_id)
    print(f"Total Processes: {len(s['processes'])}   Suspicious: {len(sus)}   Network Connections: "
          f"{len(s['connections'])}   Scans: {s['scans']}   Uptime: {engine.uptime():.0f}s")
    print("Alerts this session: " + "  ".join(c(k, f"{k} {v}") for k, v in counts.items()))


# ------------------------------------------------------------------ views
def live_monitor(engine, duration=None, interval=None, quiet=False):
    interval = interval or engine.cfg["monitoring_interval"]
    engine.cfg["monitoring_interval"] = interval
    spinner = "|/-\\"
    end = time.time() + duration if duration else None
    print(f"{Fore.CYAN}Live monitoring every {interval}s - press Ctrl+C to stop "
          f"(read-only: no process will be touched).{Style.RESET_ALL}")
    i = 0
    try:
        while end is None or time.time() < end:
            t0 = time.time()
            engine.scan()
            s = engine.snapshot()
            sys.stdout.write(f"\r{spinner[i % 4]} scan {s['scans']:>4}  processes {len(s['processes']):>4}  "
                             f"connections {len(s['connections']):>4}  suspicious {len(engine.suspicious()):>3}  "
                             f"({(time.time() - t0) * 1000:.0f} ms)   ")
            sys.stdout.flush()
            for a in s["new_alerts"]:
                print()
                print_alert(a)
            i += 1
            remaining = interval - (time.time() - t0)
            if end is not None:
                remaining = min(remaining, end - time.time())
            if remaining > 0:
                time.sleep(remaining)
    except KeyboardInterrupt:
        print("\nstopped by user")
    print()
    if not quiet:
        header(engine, "STOPPED")


def ensure_scanned(engine):
    if engine.snapshot()["scans"] < 2:
        print("collecting two samples (CPU % needs a baseline)...")
        engine.scan()
        time.sleep(1)
        engine.scan()


def view_all(engine, limit=60, sort="cpu"):
    ensure_scanned(engine)
    s = engine.snapshot()
    key = {"cpu": lambda p: -p.cpu_percent, "mem": lambda p: -p.memory_percent, "pid": lambda p: p.pid}[sort]
    rows = []
    for p in sorted(s["processes"], key=key)[:limit]:
        r = s["results"][p.pid]["result"]
        rows.append([p.pid, p.ppid, short(p.name, 22), short(p.username, 12), f"{p.cpu_percent:.1f}",
                     f"{p.memory_percent:.2f}", p.num_threads, p.status, short(p.exe or "-", 45),
                     c(r.severity, r.score)])
    print(tabulate(rows, ["PID", "PPID", "Name", "User", "CPU%", "MEM%", "Thr", "Status", "Executable", "Risk"],
                   tablefmt="simple"))
    print(f"\nshowing {len(rows)} of {len(s['processes'])} processes (sorted by {sort}); "
          f"access-denied reads: {engine.monitor.errors['access_denied']}")


def view_suspicious(engine, min_score=None):
    ensure_scanned(engine)
    sus = engine.suspicious(min_score)
    if not sus:
        print(f"{Fore.GREEN}No process at or above score {engine.cfg['alert_min_score'] if min_score is None else min_score}."
              f"{Style.RESET_ALL} (This means the heuristics found nothing - not that the system is proven clean.)")
        return
    tree = engine.snapshot()["tree"]
    for p, r in sus:
        res = r["result"]
        print(f"\n{c(res.severity, '[' + res.severity + ']')} {Style.BRIGHT}{p.name}{Style.RESET_ALL}  PID {p.pid}  "
              f"score {res.score}/100")
        print(f"  Path: {p.exe or '(unavailable)'}   [{r['location']}]")
        print(f"  Chain: {tree.chain_text(p.pid)}")
        print(f"  Score: {res.explanation()}")
        for f in res.findings:
            print(f"   * {f.category}: {short(f.evidence, 140)}")
        for rec in res.recommendations[:3]:
            print(f"   > {rec}")


def view_tree(engine, only_flagged=True):
    ensure_scanned(engine)
    hl = {p.pid: r["result"].severity for p, r in engine.suspicious()}
    tree = engine.snapshot()["tree"]
    text = tree.render(hl, only_suspicious_branches=only_flagged and bool(hl))
    print(text if text else "(empty)")
    if only_flagged and hl:
        print(f"\n(showing only branches that lead to {len(hl)} flagged process(es))")


def view_network(engine, limit=80):
    ensure_scanned(engine)
    s = engine.snapshot()
    print(f"visibility: {s['conn_status']}")
    rows = [[x.pid, short(x.process_name, 18), x.protocol, x.local, x.remote or "-", x.remote_scope, x.status]
            for x in sorted(s["connections"], key=lambda x: (x.status != "LISTEN", x.pid or 0))[:limit]]
    print(tabulate(rows, ["PID", "Process", "Proto", "Local", "Remote", "Scope", "Status"], tablefmt="simple"))
    print("\nScope is an address class only - no IP address is labelled malicious by this tool.")


def view_hashes(engine, export=None, baseline=False):
    ensure_scanned(engine)
    s = engine.snapshot()
    seen, rows = set(), []
    for p in s["processes"]:
        sha = s["results"][p.pid]["sha256"]
        if sha and p.exe not in seen:
            seen.add(p.exe)
            prev = engine._baseline.get(p.exe)
            change = "-" if not prev else ("same" if prev == sha else c("HIGH", "CHANGED"))
            rows.append([short(p.name, 18), short(p.exe, 46), sha[:20] + "...", engine.hasher.reputation(sha), change])
    print(tabulate(rows, ["Process", "Path", "SHA-256", "Reputation", "vs previous session"], tablefmt="simple"))
    print(f"\nhash stats: {engine.hasher.stats}. Nothing is uploaded. 'unknown' = not in data/known_hashes.json.")
    if export:
        n = engine.db.export_csv("hashes", export)
        print(f"exported {n} hash records to {export}")
    if baseline:
        added = engine.hasher.add_known_good({s["results"][p.pid]["sha256"]: f"baseline {p.exe}"
                                              for p in s["processes"] if s["results"][p.pid]["sha256"]})
        print(f"added {added} hashes to known_good. Only do this on a machine you have verified as clean.")


def view_alerts(engine, severity=None, term=""):
    rows = engine.db.alerts(severity=severity, term=term, limit=200)
    if not rows:
        print("no alerts match.")
        return
    print(tabulate([[a["alert_id"], a["timestamp"][11:19], c(a["severity"]), a["pid"], short(a["process_name"], 18),
                     short(a["category"], 40), a["risk_score"], a["status"]] for a in rows],
                   ["Alert ID", "Time", "Severity", "PID", "Process", "Category", "Score", "Status"], tablefmt="simple"))


def view_history(engine):
    rows = engine.db.sessions(20)
    print(tabulate([[r["id"], r["started"], r["ended"] or "running", r["hostname"], r["scans"]] for r in rows],
                   ["Session", "Started (UTC)", "Ended", "Host", "Scans"], tablefmt="simple"))
    term = input("\nsearch process history (name / path / pid, blank to skip): ").strip()
    if term:
        hits = engine.db.search_processes(term, limit=50)
        print(tabulate([[h["pid"], short(h["name"], 18), short(h["exe"], 40), h["username"], h["first_seen"][11:19],
                         h["last_seen"][11:19], c(h["severity"], h["max_score"])] for h in hits],
                       ["PID", "Name", "Executable", "User", "First", "Last", "Max score"], tablefmt="simple"))


def do_report(engine, formats=("html", "json", "csv", "pdf")):
    ensure_scanned(engine)
    out = generate_all(engine, formats)
    for k, v in out.items():
        for path in (v if isinstance(v, list) else [v]):
            print(f"  {k.upper():5} {path}")


def show_config(engine):
    cfg = engine.cfg
    keys = ["monitoring_interval", "cpu_threshold", "cpu_duration_seconds", "memory_threshold", "thread_threshold",
            "process_creation_threshold", "process_creation_window", "connection_threshold", "alert_cooldown",
            "alert_min_score"]
    print(tabulate([[k, cfg[k]] for k in keys], ["Setting", "Value"], tablefmt="simple"))
    print("\nrisk weights: " + ", ".join(f"{k}={v}" for k, v in cfg["risk_weights"].items()))
    print(f"thresholds: {cfg['risk_thresholds']}")
    k = input("\nchange a setting for this run (name, blank to skip): ").strip()
    if k in keys:
        v = input(f"new value for {k}: ").strip()
        try:
            new = type(cfg[k])(float(v)) if isinstance(cfg[k], (int, float)) else v
            from modules.settings import validate
            trial = {**cfg, k: new}
            errs = validate(trial)
            if errs:
                print(c("HIGH", "rejected: " + errs[0]))
            else:
                cfg[k] = new
                print(f"{k} = {new} (edit config.json to make it permanent)")
        except ValueError:
            print(c("HIGH", "not a number"))
    elif k:
        print("unknown setting")


def acknowledge_prompt(engine):
    aid = input("alert ID to acknowledge (blank to skip): ").strip()
    if not aid:
        return
    st = input("status [ACKNOWLEDGED/FALSE_POSITIVE/RESOLVED]: ").strip().upper() or "ACKNOWLEDGED"
    note = input("note: ").strip()
    try:
        ok = engine.alerts.acknowledge(aid, st, analyst="analyst", note=note)
        print("updated" if ok else "alert not found")
    except ValueError as exc:
        print(exc)


def interactive(engine):
    print(Fore.CYAN + BANNER + Style.RESET_ALL)
    header(engine, "READY")
    while True:
        print()
        for i, m in enumerate(MENU, 1):
            print(f"  {i:>2}. {m}")
        choice = input("\nselect option: ").strip()
        try:
            if choice == "1":
                d = input("duration in seconds (blank = until Ctrl+C): ").strip()
                live_monitor(engine, float(d) if d else None)
            elif choice == "2":
                view_all(engine)
            elif choice == "3":
                view_suspicious(engine)
            elif choice == "4":
                view_tree(engine, input("only flagged branches? [Y/n]: ").strip().lower() != "n")
            elif choice == "5":
                view_network(engine)
            elif choice == "6":
                view_hashes(engine)
            elif choice == "7":
                sev = input("filter severity (blank = all): ").strip().upper() or None
                term = input("search PID / name (blank = all): ").strip()
                view_alerts(engine, sev, term)
                acknowledge_prompt(engine)
            elif choice == "8":
                view_history(engine)
            elif choice == "9":
                do_report(engine)
            elif choice == "10":
                show_config(engine)
            elif choice in ("11", "q", "exit"):
                break
            else:
                print("choose 1-11")
        except KeyboardInterrupt:
            print("\n(cancelled)")
        except Exception as exc:
            print(c("HIGH", f"error: {type(exc).__name__}: {exc}"))


def main(argv=None):
    ap = argparse.ArgumentParser(description="Suspicious Process Detector (defensive, read-only)")
    ap.add_argument("--config", help="path to config.json")
    sub = ap.add_subparsers(dest="cmd")
    m = sub.add_parser("monitor"); m.add_argument("--duration", type=float); m.add_argument("--interval", type=float)
    s = sub.add_parser("scan"); s.add_argument("--min-score", type=int)
    sub.add_parser("processes")
    t = sub.add_parser("tree"); t.add_argument("--all", action="store_true")
    sub.add_parser("network")
    h = sub.add_parser("hashes"); h.add_argument("--export"); h.add_argument("--baseline", action="store_true")
    a = sub.add_parser("alerts"); a.add_argument("--severity"); a.add_argument("--search", default="")
    k = sub.add_parser("ack"); k.add_argument("alert_id"); k.add_argument("--status", default="ACKNOWLEDGED")
    k.add_argument("--note", default=""); k.add_argument("--analyst", default="analyst")
    r = sub.add_parser("report"); r.add_argument("--formats", nargs="+", default=["html", "json", "csv", "pdf"])
    args = ap.parse_args(argv)
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(c("CRITICAL", f"configuration error: {exc}"))
        return 2
    engine = DetectionEngine(cfg)
    try:
        if args.cmd is None:
            interactive(engine)
        elif args.cmd == "monitor":
            print(Fore.CYAN + BANNER + Style.RESET_ALL)
            live_monitor(engine, args.duration, args.interval)
        elif args.cmd == "scan":
            view_suspicious(engine, args.min_score)
        elif args.cmd == "processes":
            view_all(engine)
        elif args.cmd == "tree":
            view_tree(engine, not args.all)
        elif args.cmd == "network":
            view_network(engine)
        elif args.cmd == "hashes":
            view_hashes(engine, args.export, args.baseline)
        elif args.cmd == "alerts":
            view_alerts(engine, args.severity.upper() if args.severity else None, args.search)
        elif args.cmd == "ack":
            ok = engine.alerts.acknowledge(args.alert_id, args.status.upper(), args.analyst, args.note)
            print("updated" if ok else "alert not found")
            return 0 if ok else 1
        elif args.cmd == "report":
            do_report(engine, args.formats)
    finally:
        engine.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
