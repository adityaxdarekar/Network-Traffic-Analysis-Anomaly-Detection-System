# Project Status — what was verified, and what was not

Build environment: Ubuntu 24.04.5 (container), Python 3.13, psutil 7.2.2, 2 CPUs, 8 GB RAM, running as root, no internet.

## Verified by actually running it

| Item | Evidence |
|---|---|
| 141 automated tests pass | `python3 -m pytest -q` → `141 passed` |
| Live psutil collection, CPU priming, AccessDenied/NoSuchProcess/Zombie handling | `tests/test_process_monitor.py` (live and stand-in processes) |
| Application code contains no kill/terminate/suspend/delete/upload calls | Source-scan test in `test_process_monitor.py` |
| Demo Tests 1–8 detected on the live system | `sample_output/demo_run_all_tests.txt` (all PASS) |
| Live monitoring prints real-time alerts | `sample_output/terminal_live_monitor.txt`, `screenshots/01_*` |
| Terminal menu options 1–11 | `tests/test_cli.py` + `sample_output/terminal_menu_session.txt` |
| HTML / PDF / JSON / CSV reports with 15 sections | `sample_output/{html,pdf,json,csv}/demo_report*`, screenshots 07–09 |
| HTML escaping, CSV formula-injection guard, cmdline redaction, SQL-injection safety | `tests/test_risk_scorer.py` |
| SQLite storage | `database/process_monitor.db` holds the real demo session (3 sessions, 11 alerts, 17 hashes) |

## Not verified (honest gaps)

| Item | Status |
|---|---|
| **Streamlit dashboard in a real browser** | streamlit and plotly could not be installed here (no network). All 10 sections were executed with stand-in modules (`tests/test_app_smoke.py`), both with and without Plotly. That catches wiring errors but **not** layout or visual problems. No dashboard screenshots exist — take them after `pip install streamlit plotly`. |
| **Windows 10/11** | Windows paths, rules and demo branches (PING.EXE copy, `cmd.exe` child, admin detection via `IsUserAnAdmin`) were written, and Windows-style paths are unit-tested, but **nothing was executed on Windows**. |
| **Kali Linux** | Not run on Kali specifically. It is Debian-based like the Ubuntu test system, and the same commands apply. |
| **Running as a non-root user** | All live runs were as root. As a normal user expect `access_denied` entries and fewer visible sockets. The "Privileged process from unusual location" finding will not appear in Test 3. |
| **Default memory rule (80 % of RAM)** | Demonstrated with a lowered demo threshold (4 %) instead of allocating 6+ GB. The logic is identical and is unit-tested with 85 %. |
| **Real malware / real attack tools** | Deliberately never executed. Detection of real samples is not claimed. |

## Known behaviour worth mentioning in the viva

- In the build environment, three legitimate processes got LOW scores with no alert: a memfd sandbox component (fileless execution), a shell script containing `base64 -d`, and loopback-only listeners. These are real false-positive examples, which is why LOW does not alert.
- The alert cooldown is kept in memory. Restarting the program can re-alert a process that is still running. This is visible in `terminal_menu_session.txt`, where the same `sshd` test process was alerted by two separate runs.
- `data/known_hashes.json` ships **empty**. No reputation verdicts were invented.
- The timestamps in the sample output are from the build run (2026-11-08, UTC).
