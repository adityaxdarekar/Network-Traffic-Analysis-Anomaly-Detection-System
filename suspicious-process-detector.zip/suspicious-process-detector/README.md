# Suspicious Process Detector

A **defensive, read-only** endpoint monitor written in Python with `psutil`. It watches running processes, flags suspicious execution patterns, analyses parent-child relationships, hashes executables with SHA-256, inspects process network connections, assigns an explainable risk score, raises de-duplicated alerts and writes SOC/EDR-style reports (HTML, PDF, JSON, CSV).

> **Safety guarantees.** The detector never terminates, suspends, re-prioritises or modifies a process. It never deletes files and never uploads anything. A test (`tests/test_process_monitor.py`) scans the application source and fails if any of those calls appear. Risk scores are **heuristic indicators** of what deserves an analyst's attention. They are **not** malware probabilities. No IP address, hash or process is called malicious without a reliable known-bad source.

---

## PHASE 1 — Architecture and working methodology

```
            ┌──────────────────────── DetectionEngine.scan() (every N seconds) ───────────────────────┐
 psutil ──► │ ProcessMonitor ─► ProcessTree ─► per process:                                            │
            │  (snapshot,        (PID/PPID)     ProcessAnalyzer   name · LOLBin · cmdline · path ·     │
            │   CPU priming,                                      script path · masquerade · memfd     │
            │   AccessDenied/                   RelationshipAnalyzer  parent-child rules              │
            │   NoSuchProcess/                  BehaviorDetector  sustained CPU · RAM · threads ·      │
            │   Zombie)                                           rapid process creation               │
            │                                   NetworkAnalyzer   listeners · many conns · external    │
            │                                   HashAnalyzer      SHA-256 · known lists · changes      │
            │                                          │                                               │
            │                                     RiskScorer (weighted, capped at 100, explainable)    │
            │                                          │                                               │
            │                         AlertManager (threshold, dedup, cooldown) ─► SQLite ◄─ reports   │
            └──────────────────────────────────────────────────────────────────────────────────────────┘
                     ▲ terminal menu (main.py)                     ▲ Streamlit dashboard (app.py)
```

How it works:

1. **Collect.** `psutil.process_iter()` reads every process. The first CPU sample primes the counters and the next one measures.
2. **Context.** A process tree is built from PID and PPID. Connections are grouped by PID.
3. **Detect.** Independent checks each produce *findings*. Each finding carries a category, evidence and an explanation of why it matters.
4. **Score.** Each rule counts once with its configured weight. "Context-required" findings (for example `powershell.exe` or a short CPU spike) score only when another indicator is present. The total is capped at 100 and mapped to LOW, MEDIUM, HIGH or CRITICAL.
5. **Alert.** Processes at or above `alert_min_score` raise an alert. The same process/path/rule-set is not re-alerted within `alert_cooldown`.
6. **Store and report.** Processes, hashes, alerts, connections and scan statistics go to SQLite. Reports are rendered from that state.

### Module responsibilities

| Module | Responsibility |
|---|---|
| `modules/settings.py` | Loads and validates `config.json`, the rules and the known hashes. Also holds the **command-line redaction** for passwords, tokens, keys, bearer headers and URL credentials. |
| `modules/process_monitor.py` | `ProcessInfo` dataclass and read-only psutil collection. Handles AccessDenied, NoSuchProcess and ZombieProcess. Primes CPU %, records process-creation events and runs the background monitoring thread. |
| `modules/process_analyzer.py` | Name rules, context-required LOLBins, suspicious command-line regexes, executable location class (temp, user-writable, hidden, trusted), script path of interpreters, masquerading and look-alike names, deleted or memfd executables. |
| `modules/process_tree.py` | Process tree, ancestor chains, ASCII rendering with highlights, and parent-child rule evaluation. |
| `modules/behavior_detector.py` | Sustained CPU, memory % of RAM, thread count, and rapid process creation per parent. Includes an allow-list for normally heavy applications. |
| `modules/hash_analyzer.py` | Chunked SHA-256 with a (size, mtime) cache and a size limit. Checks the known-good and known-bad lists and detects hash changes across sessions. Nothing is uploaded. |
| `modules/network_monitor.py` | `net_connections` per PID, IP scope classification (loopback, private, public and so on), unexpected listeners, many connections, and untrusted executables talking to public IPs. |
| `modules/risk_scorer.py` | Weighted scoring, context rule, cap, severity bands, explanations and recommended defensive actions. |
| `modules/alert_manager.py` | Structured alerts, de-duplication, cooldown, real-time listeners and manual acknowledgement. |
| `modules/database.py` | SQLite schema (sessions, processes, hashes, alerts, network_records, scans). Parameterised queries, WAL mode, a single lock, search and CSV export. |
| `modules/engine.py` | Orchestrates a scan and keeps the latest thread-safe state. Also handles session-wide flagged history and logging. |
| `modules/report_generator.py` | HTML, PDF (reportlab), JSON and CSV reports with all 15 required sections. HTML is escaped and CSV is protected against formula injection. |
| `main.py` | Terminal UI: ASCII banner, the 11-option menu, coloured tables, live monitoring with a progress indicator, and sub-commands. |
| `app.py` | Streamlit dashboard with 10 sections and Plotly charts. It falls back to built-in charts if Plotly is missing. |
| `demo/run_scenario.py` | **Harmless** test processes with hard time and memory limits. |
| `demo/run_all_demos.py` | Runs DEMO_GUIDE Tests 1–8 against the live system. |

## PHASE 2 — Folder structure and dependencies

```
suspicious-process-detector/
├── main.py                 terminal interface (11-option menu + sub-commands)
├── app.py                  Streamlit dashboard (10 sections)
├── config.json             thresholds, weights, allow-lists (validated at start)
├── requirements.txt  pytest.ini  .gitignore  .streamlit/config.toml
├── modules/                settings, process_monitor, process_analyzer, process_tree, behavior_detector,
│                           hash_analyzer, network_monitor, risk_scorer, alert_manager, database, engine,
│                           report_generator
├── data/
│   ├── suspicious_processes.json   name rules, cmdline patterns, parent-child rules,
│   │                               masquerade locations, suspicious/trusted locations
│   └── known_hashes.json           analyst lists (ships EMPTY - no invented verdicts)
├── database/process_monitor.db     SQLite (sample from the demo run included)
├── reports/{html,pdf,json,csv}/    generated reports
├── logs/detector.log               rotating log (command lines redacted)
├── demo/                           run_scenario.py, run_all_demos.py
├── tests/                          141 pytest tests
├── docs/                           DEMO_GUIDE.md, PROJECT_REPORT.md, VIVA.md
├── sample_output/                  real output captured from the demo run
└── screenshots/                    terminal + report screenshots
```

Dependencies: `psutil`, `pandas`, `colorama`, `tabulate`, `reportlab` (PDF), `streamlit` and `plotly` (dashboard), and `pytest`. Everything else is in the standard library: `os`, `pathlib`, `hashlib`, `json`, `sqlite3`, `logging`, `threading`, `datetime`, `ipaddress`, `socket`.

## PHASE 3 — Installation and environment setup

### Kali Linux / Ubuntu Linux

```bash
# 1. Python
sudo apt update && sudo apt install -y python3 python3-venv python3-pip
# 2. virtual environment
cd suspicious-process-detector
python3 -m venv .venv && source .venv/bin/activate
# 3-4. psutil and the other dependencies
pip install -r requirements.txt
# 5. permissions: run normally for your own processes; use sudo for full visibility
#    (other users' exe paths, open files and sockets need root)
sudo .venv/bin/python main.py scan
# 6. database: created automatically on first run (database/process_monitor.db)
python3 -c "from modules.engine import DetectionEngine; DetectionEngine().close()"
# 7. dashboard
streamlit run app.py            # opens http://localhost:8501
# 8. run
python3 main.py                 # interactive menu
python3 -m pytest -q            # tests
```

### Windows 10/11 (PowerShell)

```powershell
# 1. Python 3.10+ from python.org (tick "Add python.exe to PATH") or: winget install Python.Python.3.12
# 2. virtual environment
cd suspicious-process-detector
py -m venv .venv
.\.venv\Scripts\Activate.ps1      # if blocked: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
# 3-4. dependencies
pip install -r requirements.txt
# 5. permissions: start PowerShell "Run as administrator" to see SYSTEM/service process paths
# 6. database is created on first run
# 7. dashboard
streamlit run app.py
# 8. run
python main.py
```

### Platform-specific limitations

| Area | Linux (Kali/Ubuntu) | Windows 10/11 |
|---|---|---|
| Other users' `exe`, `cmdline`, `open_files` | Need root. Otherwise they are recorded as `access_denied`. | Protected processes (`System`, `csrss.exe`, PPL services) deny access even to Administrators. |
| `net_connections` | Root is needed to map other users' sockets to PIDs. Some sockets show PID `None` (other namespaces, TIME_WAIT). | Mostly visible. Some PIDs are protected. |
| CPU % | Per process, as a percentage of **one core**, so it can exceed 100 % on multi-core machines. | Same. |
| Short-lived processes | Processes that start and exit between two scans are not seen. Rapid-creation detection only counts children seen alive. | Same. |
| Deleted or memfd executables | Detected via `(deleted)` and `/memfd:`. | Not applicable. |
| Digital signatures | Not checked (recommended as a manual step). | Not checked. `sigcheck` or `Get-AuthenticodeSignature` can be added. |

## PHASE 4 — Source code

Every module listed above is complete and runnable. Start with `modules/engine.py` to follow one scan end to end. The detection rules are data, not code: edit `data/suspicious_processes.json` and `config.json`.

Key `config.json` settings, all of them validated:

| Setting | Default | Meaning |
|---|---|---|
| `monitoring_interval` | 5 | seconds between scans |
| `cpu_threshold` / `cpu_duration_seconds` | 90 / 30 | % of one core held for N seconds |
| `memory_threshold` | 80 | % of total RAM |
| `thread_threshold` | 500 | threads per process |
| `process_creation_threshold` / `_window` | 20 / 10 | children of one parent within N seconds |
| `connection_threshold` | 50 | established connections per process |
| `alert_cooldown` | 60 | seconds before the same alert repeats |
| `alert_min_score` | 20 | lowest score that raises an alert (MEDIUM) |
| `risk_weights` | see file | points per rule (the brief's examples: name 20, temp 20, parent-child 25, unknown hash 10, network 15, resource 10) |
| `risk_thresholds` | 19/39/69/100 | 0–19 LOW, 20–39 MEDIUM, 40–69 HIGH, 70–100 CRITICAL |

## PHASE 5 — Terminal interface and dashboard

```
python3 main.py                         # 11-option menu
python3 main.py monitor --duration 60   # live monitoring with real-time alerts
python3 main.py scan | processes | tree [--all] | network
python3 main.py hashes [--export hashes.csv] [--baseline]
python3 main.py alerts [--severity HIGH] [--search 4321]
python3 main.py ack SPD-... --status FALSE_POSITIVE --note "admin script"
python3 main.py report --formats html json csv pdf
streamlit run app.py
```

Menu: 1 Live Monitoring · 2 All Processes · 3 Suspicious Processes · 4 Process Tree · 5 Network Connections · 6 Executable Hashes · 7 Security Alerts (with acknowledgement) · 8 Investigation History · 9 Security Report · 10 Configuration · 11 Exit.

Dashboard sections: Overview · Live Process Monitor · Suspicious Processes · Process Tree (ASCII + Plotly treemap) · Network Connections · Resource Usage · Security Alerts (acknowledge, export) · Process Hash Analysis · Investigation History · Reports and Settings.

## PHASE 6 — Practical demonstrations

`python3 demo/run_all_demos.py` runs Tests 1–8 against the live system. It takes about 3 minutes and finishes in under 2 minutes with `--quick`. All scenarios are harmless:

- a copy of `sleep` renamed `spd_test_tool`;
- a sleeping Python script in a temp folder;
- a CPU loop with a 120 s hard cap and RLIMIT_CPU;
- a bounded memory block (at most 25 % of RAM and 1 GB);
- a parent script that starts `sh -c sleep`;
- a hash of a test file;
- a TCP server and client on 127.0.0.1.

See **docs/DEMO_GUIDE.md**. Real output is in `sample_output/demo_run_all_tests.txt`.

## PHASE 7 — Database, alerts and reports

SQLite tables:

- `sessions`
- `processes` (PID, name, exe, username, PPID, SHA-256, first and last seen, max score)
- `hashes` (path → SHA-256 history)
- `alerts` (ID, time, PID, name, category, score, severity, description, evidence, recommendations, status, analyst note)
- `network_records`
- `scans`

Alerts can be searched by PID or name, filtered by severity or status, acknowledged as ACKNOWLEDGED, FALSE_POSITIVE or RESOLVED, and exported as CSV.

Reports contain:

1. Title
2. Start and end time
3. OS
4. Hostname
5. Total processes
6. Suspicious processes (session-wide, including processes that already exited)
7. Process details
8. Executable paths
9. SHA-256
10. Parent-child relationships
11. Network connections
12. Risk scores
13. Alerts
14. Recommended actions
15. Final assessment, with the disclaimer

## PHASE 8 — Documentation

- `docs/PROJECT_REPORT.md`: the 20-section college report.
- `docs/VIVA.md`: 40 questions with answers.
- `PROJECT_STATUS.md`: what was verified, and what was not.
