#!/usr/bin/env bash
# Run the automated tests. They only use temporary directories - real system files are never modified.
# Run with sudo to also execute the root-only tests (orphaned owner, unprivileged-process permission test).
set -euo pipefail
cd "$(dirname "$0")"
PY=./venv/bin/python
[ -x "$PY" ] || PY=python3
exec "$PY" -m pytest -v "$@"
