# Project Status

**Code status: complete** - all phases of the brief are implemented. Two items need to be done on your own
Ubuntu/Kali machine because they could not be done in the development environment.

## Verified in the development environment (Ubuntu 24.04.5, Python 3.13, root)
- [x] Scanner, analysers, 10 detection rules, risk engine
- [x] Real audits of `/etc`, `/usr`, `/var`, `/home`, `/tmp` and `/` (results in `documentation/PROJECT_DOCUMENTATION.md` §15)
- [x] Demo lab produces exactly the 9 documented findings; sticky directory and public key correctly not reported
- [x] SQLite history, comparison, report records
- [x] PDF report (14 pages for the lab, visually checked), CSV, JSON, ZIP - real samples in `sample_output/`
- [x] 103 automated tests: 103 passed, 0 skipped (run as root)
- [x] Syntax check on Python 3.11, 3.12 and 3.13
- [x] All 13 dashboard pages executed headlessly (with and without an audit), including starting an audit,
      generating a PDF, comparing audits and saving settings - using `tests/streamlit_stub.py`

## Still to do on your machine
- [ ] **Visual check of the dashboard in a browser.** Streamlit and Plotly could not be installed in the development
      environment (no internet), so page code was executed but the rendered layout was not seen.
      Run `./setup.sh && sudo ./run.sh` and click through all 13 pages.
- [ ] **Dashboard screenshots** for the submission/portfolio - list in `screenshots/README.md`.
- [ ] Optional: `./run_tests.sh` on your machine (expect 101 passed + 2 skipped without sudo, 103 passed with sudo).

If a page shows an error on your machine, the message appears in red on that page - note the page name and message.
