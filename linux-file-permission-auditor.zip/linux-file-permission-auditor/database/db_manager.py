"""
SQLite storage for audit history.

Stored: audit metadata and totals, findings, notable entries (world-writable,
SUID/SGID, orphaned) and the sensitive-file audit. NOT stored: the full list of
every scanned file (it can be hundreds of thousands of rows) and never any
file contents.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS audits (
    audit_id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT, scanned_path TEXT, status TEXT,
    options_json TEXT, host_json TEXT, profile TEXT, total_files INTEGER, total_directories INTEGER,
    total_symlinks INTEGER, world_writable_files INTEGER, world_writable_dirs INTEGER, ww_dirs_no_sticky INTEGER,
    suid_files INTEGER, sgid_files INTEGER, orphaned INTEGER, scan_errors INTEGER, findings INTEGER,
    severity_json TEXT, duration_sec REAL, privileged INTEGER
);
CREATE TABLE IF NOT EXISTS findings (
    audit_id TEXT REFERENCES audits(audit_id) ON DELETE CASCADE, finding_id TEXT, severity TEXT, rule TEXT,
    rule_name TEXT, category TEXT, path TEXT, file_type TEXT, permissions TEXT, expected TEXT, owner TEXT,
    grp TEXT, evidence TEXT, explanation TEXT, impact TEXT, remediation TEXT
);
CREATE TABLE IF NOT EXISTS notable_entries (
    audit_id TEXT REFERENCES audits(audit_id) ON DELETE CASCADE, kind TEXT, path TEXT, type TEXT, octal TEXT,
    symbolic TEXT, owner TEXT, grp TEXT
);
CREATE TABLE IF NOT EXISTS sensitive_audit (
    audit_id TEXT REFERENCES audits(audit_id) ON DELETE CASCADE, file TEXT, result TEXT, observed_mode TEXT,
    expected_mode TEXT, observed_owner TEXT, observed_group TEXT, expected_owner TEXT, expected_group TEXT, issues TEXT
);
CREATE TABLE IF NOT EXISTS reports (
    audit_id TEXT REFERENCES audits(audit_id) ON DELETE CASCADE, report_type TEXT, path TEXT,
    created_at TEXT DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_findings_audit ON findings(audit_id);
"""


class DatabaseError(Exception):
    pass


class DatabaseManager:
    def __init__(self, path: str | Path = DB_PATH):
        self.path = Path(path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._connect() as con:
                con.executescript(SCHEMA)
        except (sqlite3.Error, OSError) as exc:
            raise DatabaseError(f"Cannot open the audit database {self.path}: {exc}") from exc

    @contextmanager
    def _connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.execute("PRAGMA foreign_keys = ON")
        try:
            yield con
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        finally:
            con.close()

    def _run(self, fn):
        try:
            with self._connect() as con:
                return fn(con)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Database error: {exc}") from exc

    # ------------------------------------------------------------------
    def save_audit(self, r) -> str:
        s = r.summary

        def notable_rows():
            df = r.entries
            if df.empty:
                return []
            rows = []
            for kind, mask in (("world_writable_file", (df["type"] == "file") & df["world_writable"]),
                               ("world_writable_dir", (df["type"] == "directory") & df["world_writable"]),
                               ("suid", (df["type"] == "file") & df["suid"]),
                               ("sgid", (df["type"] == "file") & df["sgid"]),
                               ("orphaned", df["owner"].isna() | df["group"].isna())):
                for e in df[mask].head(5000).itertuples():
                    rows.append((r.audit_id, kind, e.path, e.type, e.octal, e.symbolic, e.owner_display,
                                 e.group_display))
            return rows

        def work(con):
            con.execute("DELETE FROM audits WHERE audit_id = ?", (r.audit_id,))
            con.execute("INSERT INTO audits VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                r.audit_id, r.started_at, r.finished_at, r.root, r.status, json.dumps(r.options, default=str),
                json.dumps(r.host), r.sensitive_profile, s["files"], s["directories"], s["symlinks"],
                s["world_writable_files"], s["world_writable_dirs"], s["ww_dirs_no_sticky"], s["suid"], s["sgid"],
                s["orphaned"], s["errors"], s["findings"], json.dumps(r.severity_counts), s["duration_sec"],
                int(r.host.get("privileged", False))))
            con.executemany("INSERT INTO findings VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            [(r.audit_id, *[f[c] for c in ("finding_id", "severity", "rule", "rule_name", "category",
                                                           "path", "file_type", "permissions", "expected", "owner",
                                                           "group", "evidence", "explanation", "impact",
                                                           "remediation")]) for _, f in r.findings.iterrows()])
            con.executemany("INSERT INTO notable_entries VALUES (?,?,?,?,?,?,?,?)", notable_rows())
            if not r.sensitive.empty:
                con.executemany("INSERT INTO sensitive_audit VALUES (?,?,?,?,?,?,?,?,?,?)",
                                [(r.audit_id, x.file, x.result, x.observed_mode, x.expected_mode, x.observed_owner,
                                  x.observed_group, x.expected_owner, x.expected_group, x.issues)
                                 for x in r.sensitive.itertuples()])
            return r.audit_id
        return self._run(work)

    def add_report(self, audit_id: str, report_type: str, path: str) -> None:
        self._run(lambda con: con.execute("INSERT INTO reports (audit_id, report_type, path) VALUES (?,?,?)",
                                          (audit_id, report_type, str(path))))

    def list_audits(self) -> pd.DataFrame:
        return self._run(lambda con: pd.read_sql_query(
            "SELECT audit_id, started_at, scanned_path, status, total_files, total_directories, world_writable_files, "
            "world_writable_dirs, suid_files, sgid_files, findings, severity_json, privileged FROM audits "
            "ORDER BY started_at DESC", con))

    def get_audit(self, audit_id: str) -> dict | None:
        def work(con):
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM audits WHERE audit_id = ?", (audit_id,)).fetchone()
            if row is None:
                return None
            d = dict(row)
            d["severity_counts"] = json.loads(d.pop("severity_json") or "{}")
            d["host"] = json.loads(d.pop("host_json") or "{}")
            d["options"] = json.loads(d.pop("options_json") or "{}")
            for t in ("findings", "notable_entries", "sensitive_audit", "reports"):
                d[t] = pd.read_sql_query(f"SELECT * FROM {t} WHERE audit_id = ?", con, params=(audit_id,)) \
                    .drop(columns=["audit_id"])
            return d
        return self._run(work)

    def list_reports(self) -> pd.DataFrame:
        return self._run(lambda con: pd.read_sql_query(
            "SELECT r.created_at, r.report_type, r.path, a.scanned_path, r.audit_id FROM reports r "
            "JOIN audits a USING(audit_id) ORDER BY r.created_at DESC", con))

    def delete_audit(self, audit_id: str) -> None:
        self._run(lambda con: con.execute("DELETE FROM audits WHERE audit_id = ?", (audit_id,)))

    def compare(self, old_id: str, new_id: str) -> dict:
        """Findings that are new, resolved or changed severity between two audits, plus SUID/SGID changes."""
        old, new = self.get_audit(old_id), self.get_audit(new_id)
        if old is None or new is None:
            raise DatabaseError("One of the selected audits no longer exists.")

        def keyed(df):
            return {(x.rule, x.path): x for x in df.itertuples()}
        a, b = keyed(old["findings"]), keyed(new["findings"])
        rows = []
        for k in sorted(set(a) | set(b)):
            fa, fb = a.get(k), b.get(k)
            if fa is None:
                rows.append({"change": "New finding", "rule": k[0], "path": k[1], "before": "-",
                             "after": f"{fb.severity} · {fb.permissions}"})
            elif fb is None:
                rows.append({"change": "Resolved", "rule": k[0], "path": k[1],
                             "before": f"{fa.severity} · {fa.permissions}", "after": "-"})
            elif fa.severity != fb.severity or fa.permissions != fb.permissions:
                rows.append({"change": "Changed", "rule": k[0], "path": k[1],
                             "before": f"{fa.severity} · {fa.permissions}", "after": f"{fb.severity} · {fb.permissions}"})

        def special(d):
            n = d["notable_entries"]
            return set(n[n["kind"].isin(["suid", "sgid"])]["path"]) if not n.empty else set()
        return {"findings": pd.DataFrame(rows, columns=["change", "rule", "path", "before", "after"]),
                "special_added": sorted(special(new) - special(old)),
                "special_removed": sorted(special(old) - special(new)),
                "same_path": old["scanned_path"] == new["scanned_path"]}
