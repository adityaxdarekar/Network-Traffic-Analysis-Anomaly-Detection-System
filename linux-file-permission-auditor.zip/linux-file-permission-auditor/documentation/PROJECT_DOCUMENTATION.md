# Linux File Permission Auditor and Security Assessment System Using Python

*Project documentation for college submission*

---

## 1. Abstract
Incorrect file permissions are a frequent and easily overlooked cause of security weaknesses on Linux systems.
A configuration file writable by every user, a root-run script that anyone may overwrite, a private key readable
by all accounts or a shared directory without the sticky bit can each let an unprivileged user tamper with the
system or escalate privileges. This project implements a read-only auditing tool in Python that walks a selected
directory tree, collects each entry's permission metadata with `lstat`, analyses world-writable files and
directories, SUID/SGID programs, ownership and sensitive system configuration files, and applies ten transparent
detection rules that classify findings into five severity levels. Results are presented in a Streamlit dashboard,
stored in an SQLite history that allows audits to be compared, and exported as PDF, CSV and JSON reports. The tool
never changes permissions, never reads file contents and never follows symbolic links. It was verified with an
automated test suite of 103 tests and with audits of a real Ubuntu 24.04 system and a deliberately misconfigured
demonstration directory.

## 2. Introduction
Linux controls access to every file and directory with a small set of permission bits - read, write and execute
for the owner, the group and all other users - plus three special bits (SUID, SGID and sticky) and the numeric
owner and group of the file. These bits are simple, but a single wrong digit can expose an entire system: `chmod 777`
applied while troubleshooting, an archive extracted with its original permissions, or a software installer that
leaves files writable by everyone. Administrators commonly check permissions with commands such as
`find / -perm -4000` or `find / -perm -0002`, but the output is unstructured, hard to interpret for beginners and
not kept for later comparison. This project packages these checks into a structured, explainable and repeatable
audit.

## 3. Problem statement
Manually reviewing permissions on a Linux system is slow and error-prone. The raw output of `ls -l`, `stat` and
`find` does not explain *why* a permission is risky, does not distinguish expected cases (for example `/tmp` with
the sticky bit, or the standard SUID program `passwd`) from genuinely suspicious ones, does not compare sensitive
files with the defaults of the installed distribution, and leaves no record that can be compared after changes.
A tool is needed that performs these checks safely (without modifying anything), explains each result and its
potential impact, suggests remediation, and stores the results.

## 4. Objectives
1. Recursively scan a user-selected directory with read-only system calls, without following symbolic links and
   without entering virtual or other mounted filesystems.
2. Extract numeric and symbolic permissions, owner, group, size, modification time and file type for every entry.
3. Identify world-writable files and directories and interpret the sticky bit correctly.
4. Detect and classify SUID and SGID files, separating standard system programs from programs needing review.
5. Audit sensitive configuration files against configurable, distribution-aware baseline policies.
6. Analyse ownership, including orphaned UIDs/GIDs and user-owned files in system directories.
7. Apply ten rule-based detections with severity levels, explanations, impact and remediation advice.
8. Provide a dashboard, persistent history with comparison, and PDF/CSV/JSON reports.
9. Handle permission errors, very large trees and invalid input safely.

## 5. Literature / background overview
The background of this project is the standard Linux permission model and widely used hardening guidance:

- **Linux manual pages** `stat(2)`, `inode(7)`, `chmod(1)` and `find(1)` define the permission bits, the special
  bits SUID (04000), SGID (02000) and sticky (01000), and the `-perm` search semantics that this tool reproduces.
- The **Filesystem Hierarchy Standard** (FHS 3.0) describes the purpose of `/etc`, `/usr/bin`, `/sbin`, `/tmp`,
  `/var` etc., which this tool uses to decide which locations count as system locations.
- **NIST SP 800-123**, *Guide to General Server Security*, recommends restricting access to files and directories
  to what is necessary and reviewing configuration of the operating system as part of server hardening.
- The **CIS Benchmarks** for Ubuntu Linux contain recommendations about the permissions of `/etc/passwd`,
  `/etc/shadow`, `/etc/group`, `/etc/gshadow`, SSH configuration and cron files, about world-writable files and
  about reviewing SUID/SGID executables. The baseline policies in this project follow the same file list; the exact
  values were taken from the defaults observed on Debian/Ubuntu-family systems and should be adjusted to an
  organisation's own policy.
- **MITRE ATT&CK** documents abuse of these mechanisms: technique T1548.001 *Setuid and Setgid* (privilege
  escalation through SUID/SGID binaries) and T1222.002 *Linux and Mac File and Directory Permissions
  Modification* (adversaries changing permissions to gain access).

No experimental results from other publications are claimed in this document.

## 6. Existing system
Permission auditing is usually done with manual commands (`ls -l`, `stat`, `find -perm`), shell scripts written by
the administrator, or broad security auditing tools that check permissions as one item among many. The limitations
of the manual approach are:
- output is a plain list with no explanation of risk or remediation;
- expected cases (sticky `/tmp`, standard SUID programs) are mixed with real problems, causing alert fatigue;
- there is no comparison with distribution defaults;
- results are not stored, so changes over time cannot be tracked;
- careless commands (for example `find / ...` without `-xdev`) descend into `/proc` or network mounts.

## 7. Proposed system
The proposed system is a Python application with a graphical dashboard that:
- performs the scan with `os.scandir` and `lstat`, staying on one filesystem and excluding `/proc`, `/sys`, `/dev`
  and `/run` by default;
- normalises every entry into a structured record and analyses it with pandas;
- distinguishes acceptable from risky situations (sticky bit, standard SUID list, trusted administrative groups,
  test-data folders) to reduce false positives;
- compares sensitive files with a JSON baseline profile chosen from `/etc/os-release`;
- explains every finding (evidence, explanation, potential impact, remediation) and assigns a severity;
- stores audits in SQLite and compares two audits;
- produces PDF, CSV and JSON reports;
- is strictly read-only.

## 8. System architecture
```
           ┌──────────────────────┐
           │  Linux filesystem     │
           └──────────┬───────────┘
                      │ os.scandir + lstat (read-only)
           ┌──────────▼───────────┐
           │ FilesystemScanner     │  path validation, exclusions, one filesystem,
           │ + metadata_extractor  │  symlinks recorded not followed, error capture
           └──────────┬───────────┘
                      │ entries (list of dicts → pandas DataFrame)
   ┌──────────────────┼────────────────────┬─────────────────────┐
   ▼                  ▼                    ▼                     ▼
Permission       Special permission    Ownership           Sensitive file
analyzer         analyzer (SUID/SGID)  analyzer            auditor (baselines)
   └──────────────────┴─────────┬──────────┴─────────────────────┘
                                ▼
                  Detection rules R1–R10 → Risk engine
                                ▼
                         AuditResult object
          ┌─────────────────────┼─────────────────────┐
          ▼                     ▼                     ▼
   SQLite database      Streamlit dashboard     PDF / CSV / JSON
   (history, compare)   (13 pages)              reports
```

## 9. Hardware requirements
| Component | Minimum | Recommended |
|---|---|---|
| Processor | any 64-bit x86 or ARM CPU | dual core or better |
| RAM | 2 GB | 4 GB or more (an audit of ~150,000 entries is held in memory) |
| Disk | 200 MB for the virtual environment | 1 GB (history database and reports) |
| Display | browser at 1280×720 | 1920×1080 |
The application was developed and tested in an x86-64 virtual machine.

## 10. Software requirements
| Software | Version |
|---|---|
| Operating system | Ubuntu 22.04/24.04 or Kali Linux (other Linux distributions work with baseline adjustments) |
| Python | 3.10 or newer (development: 3.13; syntax checked on 3.11, 3.12, 3.13) |
| Streamlit | ≥ 1.50 (dashboard) |
| Plotly | ≥ 5.18 (interactive charts) |
| pandas | ≥ 2.0 (analysis) |
| ReportLab | ≥ 4.0 (PDF) |
| Matplotlib | ≥ 3.7 (charts in the PDF) |
| SQLite | bundled with Python (`sqlite3`) |
| pytest, pypdf | testing |
| Web browser | any modern browser |

## 11. Methodology
1. **Input validation** - the directory must be absolute, existing, a real directory (not a symlink) and outside the
   excluded virtual filesystems.
2. **Traversal** - an iterative depth-first walk using `os.scandir`. For each entry `entry.stat(follow_symlinks=False)`
   (equivalent to `lstat`) is called. Directories on a different device number (`st_dev`) than the start directory
   are recorded but not entered (equivalent to `find -xdev`). Symbolic links are recorded with their target and a
   broken-link flag and are never followed. `PermissionError` and other `OSError`s are recorded per path and the
   scan continues. A configurable entry limit and depth limit protect memory; a stop event allows cancellation.
3. **Metadata extraction** - `stat.S_IMODE`, `stat.filemode` and bit masks give numeric and symbolic permissions and
   flags (world-writable, group-writable, executable, SUID, SGID, sticky). UIDs and GIDs are resolved with the
   `pwd` and `grp` modules; unresolved IDs are kept as numbers (orphaned).
4. **Analysis** - pandas aggregations compute permission distribution, an owner/group/others access matrix, type
   distribution, world-writable lists, SUID/SGID lists with investigation indicators, and ownership summaries.
5. **Baseline comparison** - `/etc/os-release` (`ID`, `ID_LIKE`) selects a profile from
   `data/permission_baselines.json`. For each policy file the observed mode is compared with `max_mode`: any bit
   present in the observed mode but not in the maximum is a deviation; fewer bits pass ("stricter than policy").
   Owner and group are compared with lists of allowed names.
6. **Detection** - ten independent rule functions receive the analysed data and return findings. The risk engine
   skips disabled rules, applies severity overrides from the settings, isolates exceptions of individual rules,
   sorts by severity and numbers the findings (F-0001 …).
7. **Severity logic** - severity depends on what the permission allows and where the file is: writable by every user
   in a system or start-up location → Critical; writable or readable sensitive data → High; unusual but limited
   exposure → Medium/Low; standard expected configuration → Informational.
8. **Persistence and reporting** - the result is saved to SQLite (audit metadata, findings, notable entries,
   sensitive audit) and can be exported.

## 12. Module descriptions
| Module | Responsibility |
|---|---|
| `config.py` | paths, defaults (exclusions, system directories, startup paths, sensitive name patterns, rules), settings load/save |
| `scanner/filesystem_scanner.py` | `validate_scan_path`, `ScanOptions`, `FilesystemScanner.scan()` |
| `scanner/metadata_extractor.py` | numeric/symbolic conversion, permission explanation, owner/group resolution, entry record |
| `scanner/scan_manager.py` | `run_audit` (full pipeline), `AuditResult`, `AuditJob` background thread with progress, masked host information |
| `analyzer/permission_analyzer.py` | DataFrame creation, distribution, access matrix, world-writable files/dirs with sticky interpretation, summary |
| `analyzer/special_permission_analyzer.py` | SUID/SGID listing, known-program comparison, indicators, SGID directories |
| `analyzer/ownership_analyzer.py` | owners/groups summary, orphaned entries, regular-user files in system locations, `UID_MIN` from `/etc/login.defs` |
| `analyzer/sensitive_file_auditor.py` | os-release parsing, profile selection with inheritance, per-file baseline comparison |
| `detection/detection_rules.py` | `Finding`, `RuleContext`, rules R1–R10 |
| `detection/risk_engine.py` | running rules, overrides, sorting, severity counts |
| `database/db_manager.py` | SQLite schema, save/list/get/delete audits, report records, audit comparison |
| `reports/pdf_generator.py` | ReportLab PDF with cover, table of contents, charts, 13 sections, page numbers |
| `reports/export_manager.py` | timestamped CSV/JSON/ZIP exports |
| `dashboard/*.py`, `app.py` | Streamlit pages and navigation |
| `sample_files/create_samples.py` | safe demonstration tree with deliberately insecure permissions |

## 13. Implementation
The project is written in Python (about 4,450 lines of application code and tests). Important implementation
decisions:
- **Read-only by construction.** No module outside the sample generator and the tests imports or calls `chmod`,
  `chown`, `remove`, `unlink`, `rename` or `subprocess`; a unit test scans the source code to enforce this.
  Remediation is generated as text with `shlex.quote`d paths.
- **No content access.** Only `lstat` metadata is used; file contents are never opened (the only files read are
  `/etc/os-release`, `/etc/login.defs` for `UID_MIN`, and the project's own JSON data).
- **False-positive control.** During development, audits of the real `/usr` tree initially reported public
  certificates (`*.pem`) as private keys and a key readable by the `ssl-cert` group. The rules were refined: `.pem`
  is no longer treated as a private key, administrative groups are configurable, and files inside test-data folders
  are downgraded to Low with an explanation instead of being hidden.
- **Dashboard.** Streamlit pages share helpers in `dashboard/common.py`; the audit runs in a background thread
  (`AuditJob`) so the page can show live progress and offer a stop button. The current result is kept in session
  state and every completed audit is saved to SQLite automatically.
- **Privacy.** The hostname is replaced by `host-<8 hex characters of a SHA-256 hash>` in reports by default; the
  Streamlit server is bound to 127.0.0.1 and usage statistics are disabled.

## 14. Testing
The automated suite (pytest) contains **103 tests** in 7 files. All tests create their own files in temporary
directories; real system files are only read, never changed.

| Area | Examples of what is tested |
|---|---|
| Scanner | recursion, non-recursive mode, metadata, numeric/symbolic conversion, exclusions, entry limit, stop, path validation (empty, relative, missing, file, symlink, `/proc`, `/sys/kernel`) |
| Symlinks | links to files and directories are recorded but not followed; broken links detected |
| Permission errors | mocked `PermissionError`; real run as user `nobody` (via `setpriv`) against a `700` directory |
| World-writable | files, group-writable vs world-writable, sticky vs non-sticky directories, R1/R2/R3, real `/tmp` not reported |
| SUID/SGID | `4755`, `2755`, `6755`, writable SUID → Critical, standard program → Informational, SGID directories |
| Ownership | owner/group summaries, orphaned file (file chowned to an unused UID, root only) |
| Baselines | profile selection for Kali/Ubuntu/Fedora/unknown, OK / stricter / deviation, missing and symlinked files, fake `/etc` tree → R7 severities |
| Rules | required fields on every finding, sorting, overrides and disabling, a crashing rule is isolated, demo lab produces the documented findings |
| Storage/reports | save/list/get/delete, comparison (new, resolved, new SUID), CSV/JSON/ZIP (no file contents), PDF headings, PDF with zero findings |
| Dashboard | all 13 pages rendered with and without an audit using a Streamlit stand-in; starting a real audit from the page; PDF generation; history comparison; settings save |
| Safety | scanning does not change mode/mtime/owner; source code contains no modifying calls |

Result in the development environment (Ubuntu 24.04.5, Python 3.13, run as root): **103 passed, 0 failed, 0 skipped**
(4.2 s). When run without root, 2 tests are skipped (orphaned owner, unprivileged-process test).

Limitation of the test environment: Streamlit and Plotly were not installable there, so the dashboard was tested with a
stand-in module that executes every page's code and checks the referenced data columns; visual rendering must be
checked in a browser on the target machine.

## 15. Results
All numbers below are **development-environment results** (Ubuntu 24.04.5 LTS virtual machine, audit run as root,
default settings). They will differ on other machines.

**Real system directories**
| Directory | Files | Dirs | WW files | WW dirs | SUID | SGID | Scan time | Findings |
|---|---|---|---|---|---|---|---|---|
| /etc | 420 | 180 | 0 | 0 | 0 | 0 | 0.03 s | 0 |
| /usr | 140,378 | 15,410 | 0 | 0 | 12 | 5 | 2.8 s | 17 Informational (standard SUID/SGID programs), 1 Low |
| /var | 5,824 | 176 | 0 | 2 (both with sticky bit) | 0 | 0 | 0.09 s | 0 |
| /home | 1,046 | 189 | 0 | 0 | 0 | 0 | 0.02 s | 0 |

The single Low finding in `/usr` is a `.pfx` key file inside a software template folder (downgraded as test/template
data). The sensitive file audit selected the `debian` profile; 13 policy files were OK and 4 were not present on this
minimal system (`sshd_config`, SSH host keys, `crontab`, `rc.local`). An audit of the whole filesystem stopped at
the default limit of 300,000 entries in about 8 seconds, did not enter the excluded virtual filesystems or the
other mounted filesystems, and recorded no read errors.

**Demonstration lab** (`sample_files/create_samples.py`, 14 files, 11 directories, 1 broken symlink):
| Severity | Rule | Path (in the lab) | Cause |
|---|---|---|---|
| High | R1 | etc/app.conf | 666 configuration file |
| High | R1 | home/student/.bashrc | 646 shell start-up file |
| High | R2 | home/student/backup.sh | 777 script |
| High | R3 | shared | 777 directory without sticky bit |
| High | R4 | opt/tools/helper | SUID program outside system directories |
| High | R6 | data/secret.key | key file writable by group (660) |
| High | R6 | home/student/.ssh/id_rsa | private key readable by everyone (644) |
| Medium | R5 | opt/tools/reporter | SGID program outside system directories |
| Medium | R6 | home/student/notes.txt | 666 data file |

`public_tmp` (1777) and `id_rsa.pub` (644) were correctly **not** reported. The generated 14-page PDF report, CSV and
JSON are included in `sample_output/`.

## 16. Limitations
- Only classic permission bits and ownership are analysed; POSIX ACLs, extended attributes (immutable flag), file
  capabilities and SELinux/AppArmor contexts are not.
- Baselines and the standard SUID/SGID list cover common Debian-family and RHEL-family defaults; other or hardened
  distributions need adjustments.
- Rules are heuristics. Findings are indicators for review, not confirmed vulnerabilities; intentional
  configurations may be reported and unusual risks may be missed.
- File integrity (whether a binary was modified) is not checked.
- The audit is a snapshot and holds results in memory; very large trees are limited by the entry limit.
- The dashboard was validated headlessly in the development environment; its visual appearance was not verified there.

## 17. Future scope
- ACL (`getfacl`), file-capability (`getcap`) and immutable-attribute checks
- Integration with package verification (`dpkg --verify`, `rpm -Va`)
- Scheduled audits with alerts when new SUID files or world-writable files appear
- Command-line mode for automation, and audit profiles mapped to CIS Benchmark items
- Multi-host collection over SSH with central reporting

## 18. Conclusion
The project delivers a working, read-only Linux permission auditor that turns low-level `stat` information into
explained, prioritised findings. Distinguishing expected cases (sticky `/tmp`, standard SUID programs, stricter-than-
policy files) from real risks kept the results on a real Ubuntu system small and meaningful, while the demonstration
lab showed that each of the implemented rules detects its target misconfiguration. The history, comparison and
reports make the audit repeatable, and the automated tests confirm both the detection logic and the read-only
guarantee.

## 19. References
1. Linux man-pages project. `stat(2)`, `inode(7)`, `chmod(1)`, `chown(1)`, `find(1)`. https://man7.org/linux/man-pages/
2. Linux Foundation. *Filesystem Hierarchy Standard*, version 3.0, 2015. https://refspecs.linuxfoundation.org/fhs.shtml
3. Scarfone, K., Jansen, W., Tracy, M. *NIST Special Publication 800-123: Guide to General Server Security*. NIST, 2008.
4. Center for Internet Security. *CIS Ubuntu Linux Benchmark*. https://www.cisecurity.org/benchmark/ubuntu_linux
5. MITRE ATT&CK. *T1548.001 Abuse Elevation Control Mechanism: Setuid and Setgid*. https://attack.mitre.org/techniques/T1548/001/
6. MITRE ATT&CK. *T1222.002 File and Directory Permissions Modification: Linux and Mac*. https://attack.mitre.org/techniques/T1222/002/
7. Python Software Foundation. `os`, `stat`, `pwd`, `grp`, `sqlite3` module documentation. https://docs.python.org/3/library/
8. Streamlit documentation. https://docs.streamlit.io/ · ReportLab User Guide. https://docs.reportlab.com/
