# Linux File Permission Auditor and Security Assessment System

A **read-only** Python tool that audits Linux file and directory permissions and reports insecure
configurations: world-writable files and directories, missing sticky bits, SUID/SGID programs,
sensitive configuration files that deviate from a baseline policy, and unusual ownership. Results are
shown in a dark Streamlit dashboard, stored in SQLite, and exported as PDF, CSV and JSON.

> **The auditor never changes your system.** It never runs `chmod` or `chown`, never modifies, moves or
> deletes files, never reads file contents, does not follow symbolic links, and keeps all results on
> your computer. Remediation commands in the reports are suggestions for you to review and run yourself.
> Only audit systems you own or are authorised to assess.

---

## Table of contents
1. [Project overview](#1-project-overview)
2. [Features](#2-features)
3. [Architecture](#3-architecture)
4. [Requirements](#4-requirements)
5. [Installation on Ubuntu](#5-installation-on-ubuntu)
6. [Installation on Kali Linux](#6-installation-on-kali-linux)
7. [Running the application](#7-running-the-application)
8. [Running a permission audit](#8-running-a-permission-audit)
9. [Understanding Linux permissions](#9-understanding-linux-permissions)
10. [Understanding world-writable files](#10-understanding-world-writable-files)
11. [Understanding SUID and SGID](#11-understanding-suid-and-sgid)
12. [Detection rules](#12-detection-rules)
13. [Reports](#13-reports)
14. [Testing](#14-testing)
15. [Project structure](#15-project-structure)
16. [Screenshots](#16-screenshots)
17. [Security and privacy](#17-security-and-privacy)
18. [Troubleshooting](#18-troubleshooting)
19. [Limitations](#19-limitations)
20. [Future improvements](#20-future-improvements)

---

## 1. Project overview
Wrong file permissions are one of the most common Linux misconfigurations: a configuration file that
every user can edit, a script run by root that anyone can overwrite, a private SSH key readable by
everybody, or a shared folder without the sticky bit. This project walks a directory tree, reads every
entry's metadata (the same information the `stat` command shows), analyses it, applies 10 transparent
detection rules and presents the results with explanations, potential impact and remediation advice.

## 2. Features
- Recursive, read-only scan with `os.scandir` + `lstat`; stays on one filesystem; excludes `/proc`,
  `/sys`, `/dev`, `/run`; optional exclusion patterns; entry limit; live progress; stop button
- Numeric (`644`, `4755`) and symbolic (`-rw-r--r--`) permissions, owner/group (UID/GID → names),
  size, modification time, file type, symbolic-link target and broken-link detection
- World-writable files and directories with **sticky-bit interpretation** (`/tmp` is not treated as a risk)
- SUID / SGID analysis against a list of standard programs, with investigation indicators
- Sensitive configuration audit (`/etc/passwd`, `shadow`, `group`, `gshadow`, `sudoers`, `ssh/sshd_config`,
  SSH host keys, `crontab`, `hosts` …) against a **distribution-aware baseline** (`data/permission_baselines.json`)
- Ownership analysis: files per user/group, orphaned UIDs/GIDs, regular-user files in system directories
- 10 detection rules, 5 severity levels (Informational, Low, Medium, High, Critical)
- Streamlit dashboard with 13 pages, interactive Plotly charts, searchable tables
- SQLite audit history with comparison of two audits (new / resolved / changed findings, new SUID files)
- Professional PDF report (cover, table of contents, 13 sections, charts, page numbers), CSV, JSON, ZIP
- Settings page: default scan options, exclusions, enabling rules, severity overrides, trusted groups,
  regular-user UID threshold, hostname masking, table size
- 103 automated tests that use only temporary directories

## 3. Architecture
```
Linux filesystem
   │  os.scandir + lstat  (read-only, links not followed, one filesystem, virtual fs excluded)
   ▼
scanner/filesystem_scanner.py ──► scanner/metadata_extractor.py   (permissions, owner, type, size, mtime)
   ▼
analyzer/permission_analyzer.py      world-writable files/dirs, sticky bit, distribution, access matrix
analyzer/special_permission_analyzer SUID / SGID
analyzer/ownership_analyzer.py       UID/GID → names, orphaned files, unusual owners
analyzer/sensitive_file_auditor.py   /etc files vs. distribution-aware baseline
   ▼
detection/detection_rules.py (R1-R10) ──► detection/risk_engine.py (severity, overrides, IDs)
   ▼
scanner/scan_manager.py  (AuditResult, background job)
   ├──► database/db_manager.py   SQLite history + comparison
   ├──► reports/pdf_generator.py, reports/export_manager.py   PDF / CSV / JSON / ZIP
   └──► app.py + dashboard/*      Streamlit dashboard (13 pages)
```

## 4. Requirements
- Ubuntu 22.04+/24.04 or Kali Linux (any modern Linux works; baselines exist for Debian-family and RHEL-family)
- Python **3.10 or newer** (`python3 --version`)
- `python3-venv` and `python3-pip`
- Python packages in `requirements.txt`: streamlit, plotly, pandas, reportlab, matplotlib (+ pytest, pypdf for tests)

## 5. Installation on Ubuntu
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
cd linux-file-permission-auditor
chmod +x setup.sh run.sh run_tests.sh
./setup.sh
```

## 6. Installation on Kali Linux
Kali (like recent Ubuntu) blocks system-wide `pip install` (PEP 668, "externally-managed-environment").
`setup.sh` therefore uses a virtual environment:
```bash
sudo apt update
sudo apt install -y python3-venv python3-pip
cd linux-file-permission-auditor
chmod +x setup.sh run.sh run_tests.sh
./setup.sh
```
Manual alternative:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 7. Running the application
```bash
./run.sh            # safe mode: runs as your user, directories you cannot read are reported, not scanned
sudo ./run.sh       # full audit with root privileges (still strictly read-only)
```
Open **http://localhost:8501**. The server listens on `127.0.0.1` only.
Manual start: `source venv/bin/activate && streamlit run app.py`.

**Safe mode vs. root:** without root, folders such as `/root`, `/etc/sudoers.d` or `/var/lib/...`
cannot be listed; they appear under "location(s) could not be read" with a hint. Running with `sudo`
gives complete results. Root is needed only to *read* metadata - the program contains no code that writes
to scanned files (a test enforces this).

## 8. Running a permission audit
1. Go to **Start New Audit**.
2. Enter an absolute directory such as `/etc`, `/home/kali`, `/usr/bin`, `/tmp` - or click a quick button.
   For a safe demonstration click **Demo lab** (creates `sample_files/lab` with deliberately insecure test files).
3. Optionally change recursion, "stay on one filesystem", exclusions, patterns and the entry limit.
4. Click **▶ Start audit**. Progress (files, directories, current folder) updates every second; **■ Stop** ends it early (results are marked partial).
5. The audit is saved to history automatically. Explore the pages: Overview, File Permissions,
   World-Writable Files/Directories, SUID/SGID, Sensitive Files, Ownership, Security Findings.
6. Open **Reports** to generate the PDF or download CSV/JSON/ZIP.
7. Run the same audit again later and compare both in **Audit History**.

Path validation rejects relative paths, non-existent paths, files, symbolic links (scan the real target
instead) and paths inside `/proc`, `/sys`, `/dev`, `/run`.

Command-line demo lab (alternative): `python3 sample_files/create_samples.py /tmp/permlab`, audit `/tmp/permlab`,
and remove it afterwards with `rm -rf /tmp/permlab`.

## 9. Understanding Linux permissions
```
-rwxr-xr--   1 alice developers  script.sh
│└┬┘└┬┘└┬┘
│ │  │  └── others  (everyone else): r-- = read only
│ │  └───── group   (developers):    r-x = read + execute
│ └──────── owner   (alice):         rwx = read + write + execute
└────────── type: - file, d directory, l symbolic link
```
| Permission | On a file | On a directory | Value |
|---|---|---|---|
| r read | read content | list names | 4 |
| w write | change content | create / delete / rename entries | 2 |
| x execute | run as a program | enter (`cd`) and access entries | 1 |

Add the values per class: `rwx`=7, `r-x`=5, `r--`=4 → `754`.
Common values: `644` (normal file), `600` (private file), `755` (program/directory), `700` (private directory),
`640` (readable by group), `440` (`/etc/sudoers`).
A fourth, leading digit holds the special bits: SUID = 4, SGID = 2, sticky = 1 (e.g. `4755`, `2755`, `1777`).
Check any file with `stat FILE` or `ls -l FILE`.

## 10. Understanding world-writable files
"World-writable" means **others** have write permission (`o+w`, the last `w`, e.g. `666` / `-rw-rw-rw-`):
every local account - including compromised service accounts - can change the file. That is acceptable for
some scratch files but dangerous for configuration files, credentials and anything executed by other users
or root (an attacker appends a command and waits for the script to run).

For **directories**, world-writable means anybody can create, delete and rename entries. The **sticky bit**
(`t`, `drwxrwxrwt`, `1777`) restricts deletion and renaming to each file's owner. That is why `/tmp` is
world-writable yet safe. A world-writable directory **without** the sticky bit lets any user delete or replace
other users' files. Equivalent commands:
```bash
find /path -xdev -type f -perm -0002        # world-writable files
find /path -xdev -type d -perm -0002 ! -perm -1000   # world-writable dirs WITHOUT sticky bit
```

## 11. Understanding SUID and SGID
- **SUID** (`s` in the owner execute position, `-rwsr-xr-x`, `4755`): the program runs with the privileges of
  its **owner** (usually root) no matter who starts it. `passwd` needs this to update `/etc/shadow`.
- **SGID** on a file (`-rwxr-sr-x`, `2755`): runs with the privileges of the file's **group**.
  On a directory, SGID makes new files inherit the directory's group (normal for shared team folders).

SUID/SGID files are **not automatically malicious** - every Linux system has a dozen or more. They are reviewed
because a vulnerable or unexpected SUID-root program is a classic privilege-escalation path (MITRE ATT&CK
T1548.001). The auditor marks standard programs (`data/known_special_files.json`) as Informational and escalates
unknown programs, programs outside system directories, non-root owners and programs others can modify.
Equivalent command: `find / -xdev -perm -4000 -type f`.

## 12. Detection rules
| Rule | Name | Logic (summary) | Typical severity |
|---|---|---|---|
| R1 | World-Writable Sensitive File | world-writable file under /etc, private keys, credentials, shell start-up files, `*.conf` | High - Critical |
| R2 | World-Writable Executable | executable writable by others, outside system program dirs | High |
| R3 | World-Writable Directory Without Sticky Bit | o+w directory without `t` | High (Critical in system/startup locations) |
| R4 | SUID File Review | standard → Informational; unknown/unusual/writable → Low … Critical | Informational - Critical |
| R5 | SGID File Review | same idea for SGID files | Informational - High |
| R6 | Excessively Permissive File | world-writable data files; private keys readable/writable by group or others | Low - High |
| R7 | Sensitive Configuration Permissions | more bits than the baseline's maximum | Medium - Critical |
| R8 | Unexpected Ownership | sensitive-file owner/group mismatch, orphaned UID/GID, user-owned files in system dirs | Low - High |
| R9 | Writable System Executable | `/usr/bin`, `/sbin` … programs writable by others or non-admin groups | Low - Critical |
| R10 | Writable Startup / Scheduled Task File | cron, systemd units, init scripts, profile writable or user-owned | High - Critical |

Every finding contains: ID, path, file type, current permissions, expected permissions, owner, group,
rule, severity, evidence, explanation, potential impact and remediation. Files inside folders named like test
data (e.g. `tests`, `testdata`, `fixtures`) are downgraded to Low and say so in the explanation.
Rules can be disabled and their severity overridden on the Settings page.

**Baselines.** `data/permission_baselines.json` holds a `debian` profile (Ubuntu, Kali, Debian, Mint …) and a `rhel`
profile (Fedora, RHEL, CentOS, Rocky, Alma …). The profile is chosen from `/etc/os-release`. Each policy is a
**maximum** (`max_mode`) plus allowed owners and groups - a stricter file passes. Observed and expected values are
shown side by side; a deviation is a review item, not proof of a vulnerability.

## 13. Reports
| Format | Content | Where |
|---|---|---|
| PDF | cover, table of contents, executive summary, system information (hostname masked), methodology, statistics and charts, world-writable files and directories, SUID/SGID, sensitive files, ownership, risk assessment, finding details with remediation, recommendations, conclusion | `output/reports/` and download |
| CSV | findings / all scanned entries / sensitive-file audit | download |
| JSON | audit metadata, summary, findings, sensitive audit | download |
| ZIP | all of the above | download |

File names contain the scanned directory and a timestamp, e.g. `findings_etc_20261106_101500.csv`.
A real sample generated from the demo lab is in `sample_output/`.

## 14. Testing
```bash
./run_tests.sh          # or: source venv/bin/activate && pytest -v
sudo ./run_tests.sh     # additionally runs the 2 root-only tests
```
Covered: directory scanning and recursion, permission extraction, numeric/symbolic conversion, world-writable
files, world-writable directories and sticky bit, SUID and SGID (created with `chmod` on temp files), ownership
and orphaned files, sensitive-file baselines (fake `/etc` in a temp directory), all detection rules and severity
logic, symbolic links and broken links (not followed), path validation, exclusions, entry limit, stop, permission
errors (mocked, and a real process running as user `nobody`), SQLite history and comparison, CSV/JSON/ZIP/PDF
exports, a headless smoke test of all 13 dashboard pages, and a check that application code contains no
`chmod`/`chown`/delete/rename calls. Tests never modify real system files.

## 15. Project structure
```
linux-file-permission-auditor/
├── app.py                     Streamlit entry point (13 pages)
├── config.py                  paths, defaults, settings load/save
├── scanner/                   filesystem_scanner, metadata_extractor, scan_manager
├── analyzer/                  permission, special permission, ownership, sensitive files
├── detection/                 detection_rules (R1-R10), risk_engine
├── database/db_manager.py     SQLite history and comparison
├── reports/                   pdf_generator, export_manager
├── dashboard/                 one module per page + common helpers + theme
├── data/                      permission_baselines.json, known_special_files.json
├── sample_files/create_samples.py   safe demo lab generator
├── sample_output/             real report/CSV/JSON generated from the demo lab
├── tests/                     pytest suite (+ headless Streamlit stand-in)
├── documentation/             PROJECT_DOCUMENTATION.md, DEMO_GUIDE.md
├── screenshots/               report pages + your dashboard screenshots
├── output/                    audit_history.db, reports/, exports/  (created at runtime)
├── setup.sh  run.sh  run_tests.sh  requirements.txt  pytest.ini
└── PROJECT_STATUS.md
```

## 16. Screenshots
`screenshots/` contains pages of the real PDF report produced from the demo lab. Dashboard screenshots must be
taken on your machine - see `screenshots/README.md` for the list and naming.

## 17. Security and privacy
- Read-only: no `chmod`, `chown`, write, rename or delete on scanned paths (enforced by `test_source_code_contains_no_modifying_calls`)
- Metadata only (`lstat`); file contents are never read
- Symbolic links are recorded but never followed; mount points of other filesystems are not entered
- Virtual filesystems `/proc`, `/sys`, `/dev`, `/run` excluded by default
- Permission errors are recorded and the scan continues
- Results stay local (SQLite + files in `output/`); the dashboard listens on `127.0.0.1`; Streamlit usage statistics are disabled
- Hostname is masked in reports by default (`host-<hash>`); file contents, environment variables and user passwords are never collected
- Authorised use only

## 18. Troubleshooting
| Problem | Fix |
|---|---|
| `error: externally-managed-environment` | use `./setup.sh` (virtual environment) |
| `No module named venv` / `ensurepip` | `sudo apt install python3-venv` |
| `streamlit: command not found` | `source venv/bin/activate` or use `./run.sh` |
| Many "could not be read" locations | expected in safe mode; run `sudo ./run.sh` |
| `sudo ./run.sh` → "Run ./setup.sh first" | run `./setup.sh` as your normal user first, inside the project folder |
| Audit of `/` stops at the entry limit | audit a narrower folder or raise the limit in the audit form / Settings |
| "is a symbolic link" when entering a path | enter the real directory shown in the message |
| Port 8501 in use | `PORT=8502 ./run.sh` |
| Database error in Audit History | check that `output/` is writable; delete `output/audit_history.db` to start fresh |
| PDF button fails | `pip install reportlab matplotlib` inside the venv |

## 19. Limitations
- Checks classic permission bits and ownership only - not ACLs (`getfacl`), extended attributes (`lsattr` immutable flag), file capabilities (`getcap`), SELinux/AppArmor labels
- The list of standard SUID/SGID programs and the baselines cover common Debian/Ubuntu/Kali and RHEL-family defaults; other distributions or hardened systems may need edits
- Rule logic is heuristic; findings are leads for review, not confirmed vulnerabilities, and some intentional configurations will be reported
- Package integrity is not verified (use `debsums` / `rpm -Va` for that)
- A scan is a snapshot; files changing during the scan are reported as errors
- Very large trees (millions of entries) are limited by the configurable entry limit and available memory
- Network filesystems are not entered by default (one-filesystem option)

## 20. Future improvements
ACL, capability (`getcap`) and immutable-flag checks · package-manager comparison (`dpkg --verify`) ·
scheduled audits with change alerts · CLI mode for cron · CIS-Benchmark-mapped profiles · multi-host collection over SSH ·
HTML report.

---
**References**: `stat(2)`, `chmod(1)`, `find(1)`, `inode(7)` Linux manual pages · Filesystem Hierarchy Standard 3.0 ·
NIST SP 800-123 *Guide to General Server Security* · CIS Benchmarks for Ubuntu Linux · MITRE ATT&CK T1548.001
*Setuid and Setgid* and T1222.002 *Linux and Mac File and Directory Permissions Modification*.
