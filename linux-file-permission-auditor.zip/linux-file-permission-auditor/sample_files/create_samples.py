#!/usr/bin/env python3
"""
Create a SAFE demonstration directory tree with deliberately insecure
permissions, so every detection rule can be shown without touching real
system files.

    python3 sample_files/create_samples.py               # creates ./sample_files/lab
    python3 sample_files/create_samples.py /tmp/permlab  # or another location

Then audit that directory in the dashboard. Everything is created inside the
chosen folder only; delete it afterwards with:  rm -rf <folder>

The tree mimics system paths (lab/etc, lab/usr/bin ...) but they are ordinary
folders - nothing outside the lab folder is modified.
"""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

SPEC = [
    # (relative path, kind, mode, description)
    ("etc", "dir", 0o755, "fake /etc"),
    ("etc/app.conf", "file", 0o666, "world-writable configuration file  -> R1"),
    ("etc/normal.conf", "file", 0o644, "normal configuration file"),
    ("etc/cron.d", "dir", 0o755, "fake cron directory"),
    ("home/student", "dir", 0o755, "fake home directory"),
    ("home/student/.bashrc", "file", 0o646, "world-writable shell start-up file  -> R1"),
    ("home/student/.ssh", "dir", 0o700, ""),
    ("home/student/.ssh/id_rsa", "file", 0o644, "private key readable by everyone  -> R6"),
    ("home/student/.ssh/id_rsa.pub", "file", 0o644, "public key (644 is fine)"),
    ("home/student/backup.sh", "file", 0o777, "world-writable executable script  -> R2"),
    ("home/student/notes.txt", "file", 0o666, "world-writable data file  -> R6"),
    ("home/student/report.txt", "file", 0o600, "private file (fine)"),
    ("shared", "dir", 0o777, "world-writable directory WITHOUT sticky bit  -> R3"),
    ("shared/readme.txt", "file", 0o644, ""),
    ("public_tmp", "dir", 0o1777, "world-writable directory WITH sticky bit (like /tmp, acceptable)"),
    ("opt/tools", "dir", 0o755, ""),
    ("opt/tools/helper", "file", 0o4755, "SUID program outside system directories  -> R4"),
    ("opt/tools/reporter", "file", 0o2755, "SGID program outside system directories  -> R5"),
    ("opt/tools/run.sh", "file", 0o755, "normal executable"),
    ("data", "dir", 0o750, ""),
    ("data/secret.key", "file", 0o660, "key file writable by group  -> R6"),
    ("data/public.txt", "file", 0o644, ""),
]


def create(base: Path) -> list[tuple[str, str, str]]:
    base.mkdir(parents=True, exist_ok=True)
    made = []
    for rel, kind, mode, desc in SPEC:
        p = base / rel
        if kind == "dir":
            p.mkdir(parents=True, exist_ok=True)
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                text = "#!/bin/sh\necho demo\n" if mode & 0o111 else "demonstration file - no real data\n"
                p.write_text(text, encoding="utf-8")
        os.chmod(p, mode)                         # only inside the lab folder
        made.append((rel, stat.filemode(os.lstat(p).st_mode), desc))
    link = base / "home/student/broken_link"
    if not os.path.lexists(link):
        os.symlink("does-not-exist", link)        # broken symbolic link (handled safely, never followed)
    made.append(("home/student/broken_link", "lrwxrwxrwx", "broken symbolic link (recorded, not followed)"))
    return made


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "lab"
    target = target.resolve()
    for rel, mode, desc in create(target):
        print(f"{mode}  {rel:<32} {desc}")
    print(f"\nDemonstration tree created in {target}\nAudit it in the dashboard (Start New Audit → {target}).")
