#!/usr/bin/env bash
# Start the dashboard on http://localhost:8501 (bound to localhost only).
# The auditor is read-only: even with sudo it never changes, moves or deletes files.
set -euo pipefail
cd "$(dirname "$0")"
PY=./venv/bin/python
[ -x "$PY" ] || { echo "Run ./setup.sh first."; exit 1; }
exec "$PY" -m streamlit run app.py --server.address 127.0.0.1 --server.port "${PORT:-8501}"
