"""
Professional PDF audit report (ReportLab), built only from real audit data.

Sections: cover · contents · 1 Executive summary · 2 System and audit information · 3 Methodology ·
4 Scan statistics and permission distribution · 5 World-writable files · 6 World-writable directories ·
7 SUID/SGID · 8 Sensitive configuration audit · 9 Ownership analysis · 10 Security risk assessment ·
11 Finding details and remediation · 12 Recommendations · 13 Conclusion
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Frame, Image, KeepTogether,  # noqa: E402
                                NextPageTemplate, PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle)
from reportlab.platypus.tableofcontents import TableOfContents  # noqa: E402

from config import (APP_SUBTITLE, APP_TITLE, APP_VERSION, REPORT_DIR, RULE_NAMES, SEVERITY_COLORS,  # noqa: E402
                    SEVERITY_ORDER)
from detection.detection_rules import describe_rules  # noqa: E402
from reports.export_manager import stamp_name  # noqa: E402

NAVY = colors.HexColor("#0b1f3a")
BLUE = colors.HexColor("#2563eb")
CYAN = colors.HexColor("#06b6d4")
LIGHT = colors.HexColor("#f1f5f9")
BORDER = colors.HexColor("#cbd5e1")
TEXT = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#64748b")
PAGE_W, PAGE_H = A4
MARGIN = 2 * cm
CONTENT_W = PAGE_W - 2 * MARGIN
GENERAL_RECOMMENDATIONS = [
    "Treat every finding as an indicator to verify; this audit does not confirm vulnerabilities.",
    "Apply the principle of least privilege: give write access only to the accounts that need it.",
    "Never leave files or directories world-writable unless they are shared temporary areas with the sticky bit.",
    "Review SUID/SGID programs regularly; remove the special bit from programs that do not need it.",
    "Verify system files against their packages (debsums / dpkg --verify on Debian-based systems).",
    "Re-run the audit after changes and compare audits on the Audit History page to confirm the fix.",
    "This tool is read-only: remediation commands in this report must be reviewed and run manually.",
]


def fmt(value) -> str:
    try:
        if value is None or pd.isna(value):
            return "-"
    except (TypeError, ValueError):
        pass
    return str(value) if str(value) != "" else "-"


def _styles():
    return {
        "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.5, leading=13.5, textColor=TEXT, spaceAfter=6),
        "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8, leading=10.5, textColor=MUTED),
        "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=7.8, leading=9.8, textColor=TEXT),
        "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=7.8, leading=9.8, textColor=colors.white),
        "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=NAVY, spaceBefore=6,
                             spaceAfter=10),
        "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=11.5, leading=15, textColor=BLUE,
                             spaceBefore=10, spaceAfter=5),
        "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=9.5, leading=13, textColor=TEXT,
                                 leftIndent=12, bulletIndent=2, spaceAfter=3),
        "cover_title": ParagraphStyle("ct", fontName="Helvetica-Bold", fontSize=25, leading=31, textColor=colors.white),
        "cover_sub": ParagraphStyle("cs", fontName="Helvetica", fontSize=13, leading=18, textColor=CYAN),
        "cover_meta": ParagraphStyle("cm", fontName="Helvetica", fontSize=10, leading=15,
                                     textColor=colors.HexColor("#cbd5e1")),
        "toc_title": ParagraphStyle("tt", fontName="Helvetica-Bold", fontSize=16, textColor=NAVY, spaceAfter=14),
    }


def p(text, style) -> Paragraph:
    return Paragraph(escape(fmt(text)), style)


class ReportDoc(BaseDocTemplate):
    def __init__(self, filename, label: str):
        super().__init__(filename, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=2.2 * cm,
                         bottomMargin=2 * cm, title="Linux File Permission Audit Report", author=APP_TITLE)
        self.label = label
        self.addPageTemplates([
            PageTemplate(id="cover", frames=[Frame(MARGIN, MARGIN, CONTENT_W, PAGE_H - 2 * MARGIN)], onPage=_cover_bg),
            PageTemplate(id="content", frames=[Frame(MARGIN, 2 * cm, CONTENT_W, PAGE_H - 4.2 * cm)], onPage=_header),
        ])

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("h1", "h2"):
            key = f"h{id(flowable)}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (0 if flowable.style.name == "h1" else 1, flowable.getPlainText(), self.page, key))


def _cover_bg(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, 0, PAGE_W, PAGE_H, stroke=0, fill=1)
    canvas.setFillColor(CYAN)
    canvas.rect(0, PAGE_H - 1.1 * cm, PAGE_W, 0.25 * cm, stroke=0, fill=1)
    canvas.setFillColor(BLUE)
    canvas.rect(0, 0, PAGE_W, 0.6 * cm, stroke=0, fill=1)
    canvas.restoreState()


def _header(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(CYAN)
    canvas.setLineWidth(1.2)
    canvas.line(MARGIN, PAGE_H - 1.5 * cm, PAGE_W - MARGIN, PAGE_H - 1.5 * cm)
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(NAVY)
    canvas.drawString(MARGIN, PAGE_H - 1.3 * cm, "Linux File Permission Audit Report")
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 1.3 * cm, doc.label)
    canvas.restoreState()


def _numbered_canvas(*args, **kwargs):
    from reportlab.pdfgen.canvas import Canvas

    class NumberedCanvas(Canvas):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self._saved = []

        def showPage(self):
            self._saved.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._saved)
            for state in self._saved:
                self.__dict__.update(state)
                if self._pageNumber > 1:
                    self.setFont("Helvetica", 8)
                    self.setFillColor(MUTED)
                    self.drawRightString(PAGE_W - MARGIN, 1.2 * cm, f"Page {self._pageNumber} of {total}")
                    self.drawString(MARGIN, 1.2 * cm, "Read-only audit · findings require verification")
                super().showPage()
            super().save()

    return NumberedCanvas(*args, **kwargs)


def table(rows, header, widths, s, max_rows=None, sev_col=None):
    total = len(rows)
    rows = rows[:max_rows] if max_rows else rows
    data = [[Paragraph(escape(h), s["cellb"]) for h in header]]
    data += [[Paragraph(escape(fmt(v)), s["cell"]) for v in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if sev_col is not None:
        for i, r in enumerate(rows, 1):
            c = SEVERITY_COLORS.get(str(r[sev_col]))
            if c:
                style.append(("BACKGROUND", (sev_col, i), (sev_col, i), colors.HexColor(c)))
    t.setStyle(TableStyle(style))
    out = [t]
    if max_rows and total > max_rows:
        out.append(p(f"Showing {max_rows} of {total} rows - the full list is in the CSV export.", s["small"]))
    return out


def kv(pairs, s, key_w=5.2 * cm):
    t = Table([[Paragraph(f"<b>{escape(k)}</b>", s["cell"]), Paragraph(escape(fmt(v)), s["cell"])] for k, v in pairs],
              colWidths=[key_w, CONTENT_W - key_w])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t


def kpis(items, s):
    t = Table([[Paragraph(f"<font size=15 color='#2563eb'><b>{escape(str(v))}</b></font><br/>"
                          f"<font size=7.5 color='#64748b'>{escape(k)}</font>", s["cell"]) for k, v in items]],
              colWidths=[CONTENT_W / len(items)] * len(items))
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.6, BORDER),
                           ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 7),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return t


def bullets(lines, s):
    return [Paragraph(escape(x), s["bullet"], bulletText="•") for x in lines]


# ---------------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------------
def _png(fig) -> Image:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    img = Image(io.BytesIO(buf.getvalue()))
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth, img.drawHeight = CONTENT_W * 0.92, CONTENT_W * 0.92 * ratio
    return img


def _axes(title, size=(7, 2.5)):
    fig, ax = plt.subplots(figsize=size)
    ax.set_title(title, fontsize=11, color="#0b1f3a", loc="left", fontweight="bold")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.tick_params(labelsize=8)
    return fig, ax


def bar_chart(labels, values, title, colors_list, log=False) -> Image:
    fig, ax = _axes(title)
    if sum(values) == 0:
        ax.axis("off")
        ax.text(0.5, 0.4, "No data", ha="center", color="#64748b")
        return _png(fig)
    bars = ax.bar(labels, values, color=colors_list, width=0.55)
    ax.bar_label(bars, labels=[f"{v:,}" for v in values], fontsize=8, padding=2)
    if log:
        ax.set_yscale("symlog")
    ax.grid(axis="y", color="#e2e8f0")
    ax.set_axisbelow(True)
    return _png(fig)


def hbar_chart(labels, values, title) -> Image:
    fig, ax = _axes(title, (7, 0.32 * max(len(labels), 1) + 1.1))
    if not labels:
        ax.axis("off")
        ax.text(0.5, 0.4, "No open services", ha="center", color="#64748b")
        return _png(fig)
    bars = ax.barh(list(labels)[::-1], list(values)[::-1], color="#06b6d4", height=0.6)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.bar_label(bars, fontsize=8, padding=3)
    ax.grid(axis="x", color="#e2e8f0")
    ax.set_axisbelow(True)
    return _png(fig)



# ---------------------------------------------------------------------------
def _short(path: str, n: int = 70) -> str:
    return path if len(path) <= n else "…" + path[-(n - 1):]


def _recommendations(r) -> list[str]:
    recs, seen = [], set()
    for f in r.findings.itertuples():
        if f.severity in ("Critical", "High", "Medium") and f.rule not in seen:
            seen.add(f.rule)
            recs.append(f"{RULE_NAMES[f.rule]}: {f.remediation}")
    return recs + GENERAL_RECOMMENDATIONS


def _conclusion(r) -> str:
    s, sev = r.summary, r.severity_counts
    serious = sev["Critical"] + sev["High"]
    text = (f"The read-only audit of {r.root} examined {s['files']:,} files and {s['directories']:,} directories. ")
    if serious:
        text += f"{serious} high or critical finding(s) should be reviewed first (see section 11). "
    elif s["findings"]:
        text += "No high or critical findings were raised; review the remaining findings against the system's purpose. "
    else:
        text += "No findings were raised with the current rules and baselines. "
    if not r.host.get("privileged"):
        text += "The audit ran without root privileges, so some locations may not have been readable. "
    return text + ("Findings are indicators produced by transparent rules on permission metadata; they must be "
                   "verified before any change is made. No file was modified during this audit.")


def generate_pdf_report(r, output_path: str | Path | None = None, analyst: str = "") -> Path:
    s = _styles()
    sm = r.summary
    now = datetime.now()
    output_path = Path(output_path or REPORT_DIR / stamp_name("permission_audit_report", r.root, "pdf", now))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = ReportDoc(str(output_path), f"{_short(r.root, 50)} · audit {r.audit_id}")
    story = []

    # Cover
    story += [Spacer(1, 4 * cm), Paragraph("READ-ONLY SECURITY AUDIT", s["cover_sub"]), Spacer(1, 0.4 * cm),
              Paragraph("Linux File Permission Audit Report", s["cover_title"]), Spacer(1, 0.6 * cm),
              Paragraph(escape(APP_SUBTITLE), s["cover_meta"]), Spacer(1, 3 * cm)]
    meta = [("Scanned directory", r.root), ("Audit date", r.started_at), ("Report generated", now.strftime("%Y-%m-%d %H:%M:%S")),
            ("Distribution", r.host.get("distribution", "-")), ("Host", r.host.get("hostname", "-")),
            ("Audit ID", r.audit_id), ("Software version", APP_VERSION)]
    if analyst:
        meta.insert(0, ("Prepared by", analyst))
    for k, v in meta:
        story.append(Paragraph(f"<font color='#06b6d4'>{escape(k)}:</font>&nbsp;&nbsp;{escape(fmt(v))}", s["cover_meta"]))
    story += [Spacer(1, 2 * cm), Paragraph("All results come from the file metadata read during this audit. Findings "
                                           "are indicators for review, not confirmed vulnerabilities. No files were "
                                           "modified.", s["cover_meta"]), NextPageTemplate("content"), PageBreak()]
    toc = TableOfContents()
    toc.levelStyles = [ParagraphStyle("t1", fontName="Helvetica-Bold", fontSize=10.5, leading=17, textColor=NAVY),
                       ParagraphStyle("t2", fontName="Helvetica", fontSize=9, leading=13, leftIndent=14)]
    story += [Paragraph("Table of Contents", s["toc_title"]), toc, PageBreak()]

    # 1 Executive summary
    sev = r.severity_counts
    story += [Paragraph("1. Executive Summary", s["h1"]),
              kpis([("Files", f"{sm['files']:,}"), ("Directories", f"{sm['directories']:,}"),
                    ("World-writable", sm["world_writable_files"] + sm["world_writable_dirs"]),
                    ("SUID / SGID", f"{sm['suid']} / {sm['sgid']}"), ("Findings", sm["findings"]),
                    ("High / Critical", sev["High"] + sev["Critical"])], s), Spacer(1, 8)]
    lines = [f"Audit of {r.root} ({r.status}) on {r.host.get('distribution', 'Linux')}, run "
             f"{'with root privileges' if r.host.get('privileged') else 'without root privileges (safe mode)'}."]
    if sm["findings"]:
        lines.append("Findings by severity: " + ", ".join(f"{sev[k]} {k}" for k in reversed(SEVERITY_ORDER) if sev[k]) + ".")
        for f in r.findings.head(4).itertuples():
            lines.append(f"{f.severity}: {RULE_NAMES[f.rule]} - {_short(f.path, 60)}")
    else:
        lines.append("No findings were raised with the current rules and baselines.")
    if sm["errors"]:
        lines.append(f"{sm['errors']} location(s) could not be read (see section 2).")
    story += bullets(lines, s)

    # 2 System info
    story += [Paragraph("2. System and Audit Information", s["h1"]),
              kv([("Distribution", r.host.get("distribution")), ("Kernel", r.host.get("kernel")),
                  ("Architecture", r.host.get("architecture")), ("Host (privacy-masked by default)", r.host.get("hostname")),
                  ("Audit user", r.host.get("user")), ("Root privileges", "yes" if r.host.get("privileged") else "no"),
                  ("Scanned directory", r.root), ("Recursive", r.options.get("recursive")),
                  ("Stay on one filesystem", r.options.get("one_filesystem")), ("Follow symbolic links", "no (never)"),
                  ("Exclusions", ", ".join(r.options.get("exclusions", [])) or "-"),
                  ("Started / finished", f"{r.started_at} / {r.finished_at}"), ("Scan time", f"{sm['duration_sec']} s"),
                  ("Status", r.status), ("Baseline profile", r.sensitive_profile),
                  ("Unreadable locations", sm["errors"]), ("Other filesystems not entered", sm["skipped_mounts"])], s)]
    if r.scan.errors:
        story.append(Spacer(1, 6))
        story += table([[_short(e["path"], 60), e["error"]] for e in r.scan.errors],
                       ["Path", "Problem"], [CONTENT_W * 0.65, CONTENT_W * 0.35], s, max_rows=15)

    # 3 Methodology
    story += [Paragraph("3. Audit Methodology", s["h1"]),
              p("The directory tree was walked with os.scandir and every entry's metadata was read with lstat (the "
                "same information as the Linux 'stat' command). Symbolic links were recorded but never followed, "
                "other mounted filesystems were not entered, and the virtual filesystems /proc, /sys, /dev and /run "
                "were excluded. No file contents were read and nothing was modified.", s["body"]),
              p("Each entry's permission bits (owner/group/others read-write-execute plus SUID, SGID and sticky) and "
                "ownership were analysed. Sensitive configuration files were compared with a configurable, "
                "distribution-aware baseline policy. Ten transparent rules then produced findings:", s["body"])]
    story += table([[x["rule"], x["name"], x["logic"]] for x in describe_rules()], ["Rule", "Name", "Logic"],
                   [1.2 * cm, 4.6 * cm, CONTENT_W - 5.8 * cm], s)

    # 4 Statistics
    pd_ = r.permission_distribution
    story += [PageBreak(), Paragraph("4. Scan Statistics and Permission Distribution", s["h1"]),
              kv([("Files", f"{sm['files']:,}"), ("Directories", f"{sm['directories']:,}"),
                  ("Symbolic links (not followed)", f"{sm['symlinks']:,} ({sm['broken_links']} broken)"),
                  ("Executable files", f"{sm['executables']:,}"), ("Total entries", f"{sm['total_entries']:,}")], s)]
    if not pd_.empty:
        story.append(hbar_chart([f"{o} ({sy})" for o, sy in zip(pd_["octal"], pd_["symbolic"])][:12],
                                list(pd_["total"])[:12], "Most common permissions (files + directories)"))
        story += table(pd_.values.tolist(), ["Numeric", "Symbolic", "Files", "Directories", "Total"],
                       [2.5 * cm, 3.5 * cm, 3 * cm, 3 * cm, CONTENT_W - 12 * cm], s)
    am = r.access_matrix
    story += [Paragraph("Who can read, write and execute regular files", s["h2"])]
    story += table(am.values.tolist(), ["Class", "Read", "Write", "Execute"], [CONTENT_W / 4] * 4, s)

    # 5 & 6 world-writable
    ww = r.world_writable_files
    story += [PageBreak(), Paragraph("5. World-Writable Files", s["h1"]),
              p("Equivalent of: find DIR -type f -perm -0002. A world-writable file can be changed by every local "
                "user; it is not automatically a vulnerability, but sensitive files and executables are serious.",
                s["body"])]
    story += table([[_short(x.path, 60), x.octal, x.owner_display, x.group_display, "yes" if x.executable else "no"]
                    for x in ww.itertuples()], ["Path", "Mode", "Owner", "Group", "Exec"],
                   [CONTENT_W - 9.3 * cm, 1.5 * cm, 2.6 * cm, 2.6 * cm, 1.2 * cm], s, max_rows=40) \
        if not ww.empty else [p("No world-writable files were found.", s["body"])]
    wd = r.world_writable_dirs
    story += [Paragraph("6. World-Writable Directories", s["h1"]),
              p("Equivalent of: find DIR -type d -perm -0002. With the sticky bit (e.g. /tmp, mode 1777) users can "
                "create files but cannot delete or rename other users' files - a normal configuration for shared "
                "temporary directories. WITHOUT the sticky bit, any user can delete or replace anyone's files.", s["body"])]
    story += table([[_short(x.path, 55), x.octal, x.sticky_status, x.owner_display, x.assessment]
                    for x in wd.itertuples()], ["Directory", "Mode", "Sticky bit", "Owner", "Assessment"],
                   [5.2 * cm, 1.3 * cm, 2.4 * cm, 1.8 * cm, CONTENT_W - 10.7 * cm], s, max_rows=40) \
        if not wd.empty else [p("No world-writable directories were found.", s["body"])]

    # 7 SUID/SGID
    sp = r.special
    story += [PageBreak(), Paragraph("7. SUID and SGID Files", s["h1"]),
              p("Equivalent of: find DIR -type f -perm -4000 (SUID) and -perm -2000 (SGID). These programs run with "
                "the privileges of their owner or group for whoever starts them, so they need careful review. Many are "
                "standard (passwd, sudo); unusual location, owner or writability are indicators, not proof.", s["body"])]
    if not sp.empty:
        vc = sp["special"].value_counts()
        story.append(bar_chart(list(vc.index), list(vc.values), "SUID / SGID files", ["#2563eb", "#06b6d4", "#6366f1"][:len(vc)]))
        story += table([[_short(x.path, 55), x.special, x.octal, x.owner_display, "yes" if x.known else "no", x.note]
                        for x in sp.itertuples()], ["Path", "Bit", "Mode", "Owner", "Std.", "Investigation note"],
                       [5 * cm, 1.4 * cm, 1.3 * cm, 1.6 * cm, 1 * cm, CONTENT_W - 10.3 * cm], s, max_rows=60)
    else:
        story.append(p("No SUID or SGID files were found in the scanned directory.", s["body"]))

    # 8 Sensitive files
    sens = r.sensitive
    story += [PageBreak(), Paragraph("8. Sensitive Configuration Audit", s["h1"]),
              p(f"System files compared with the '{r.sensitive_profile}' baseline profile "
                "(data/permission_baselines.json). The policy is a maximum: stricter permissions pass. Observed values "
                "and the expected policy are shown separately; a deviation is a review item.", s["body"])]
    if not sens.empty:
        story += table([[x.file, x.observed_mode, x.expected_mode, f"{x.observed_owner}:{x.observed_group}",
                         f"{x.expected_owner}:{x.expected_group}", x.result] for x in sens.itertuples()],
                       ["File", "Observed", "Policy", "Owner:group", "Expected", "Result"],
                       [4.2 * cm, 1.7 * cm, 3.2 * cm, 2.6 * cm, 2.6 * cm, CONTENT_W - 14.3 * cm], s)

    # 9 Ownership
    own = r.ownership
    story += [Paragraph("9. Ownership Analysis", s["h1"]),
              kv([("Entries owned by root", f"{own['root_owned']:,}"), ("Entries owned by other accounts",
                  f"{own['non_root_owned']:,}"), ("Unresolved UID/GID (orphaned)", len(own["orphaned"])),
                  ("Regular-user files in system program directories", len(own["user_owned_system"])),
                  ("Regular user UIDs start at", own["uid_min"])], s), Spacer(1, 6)]
    story += table([[x.uid, x.username, x.account_type, f"{x.files:,}", f"{x.directories:,}"]
                    for x in own["owners"].head(15).itertuples()], ["UID", "User", "Account type", "Files", "Directories"],
                   [1.6 * cm, 3.5 * cm, 5 * cm, 3 * cm, CONTENT_W - 13.1 * cm], s)

    # 10 Risk assessment
    fd = r.findings
    story += [PageBreak(), Paragraph("10. Security Risk Assessment", s["h1"]),
              bar_chart(SEVERITY_ORDER, [sev[k] for k in SEVERITY_ORDER], "Findings by severity",
                        [SEVERITY_COLORS[k] for k in SEVERITY_ORDER])]
    if not fd.empty:
        story += table([[f.finding_id, f.severity, f.rule, _short(f.path, 55), f.permissions] for f in fd.itertuples()],
                       ["ID", "Severity", "Rule", "Path", "Permissions"],
                       [1.6 * cm, 2 * cm, 1.2 * cm, CONTENT_W - 8.2 * cm, 3.4 * cm], s, max_rows=80, sev_col=1)
        byr = fd["rule"].value_counts()
        story += [Spacer(1, 6)]
        story += table([[k, RULE_NAMES[k], int(v)] for k, v in byr.items()], ["Rule", "Name", "Findings"],
                       [1.5 * cm, CONTENT_W - 4.5 * cm, 3 * cm], s)
    else:
        story.append(p("No findings were generated.", s["body"]))

    # 11 Details
    story += [PageBreak(), Paragraph("11. Finding Details and Recommended Remediation", s["h1"]),
              p("Commands are suggestions to review and run manually - the auditor never changes permissions.", s["small"])]
    for f in fd[fd["severity"] != "Informational"].head(60).itertuples():
        color = SEVERITY_COLORS.get(f.severity, "#64748b")
        block = [Paragraph(f"<font color='{color}'><b>■ {escape(f.severity.upper())}</b></font>&nbsp;&nbsp;"
                           f"<b>{escape(f.finding_id)} · {escape(RULE_NAMES[f.rule])}</b>", s["body"]),
                 kv([("Path", f.path), ("Type", f.file_type), ("Current permissions", f.permissions),
                     ("Expected", f.expected), ("Owner / group", f"{f.owner} / {f.group}"), ("Evidence", f.evidence),
                     ("Explanation", f.explanation), ("Potential impact", f.impact), ("Remediation", f.remediation)], s),
                 Spacer(1, 10)]
        story += [CondPageBreak(5 * cm), KeepTogether(block)]
    info = int((fd["severity"] == "Informational").sum()) if not fd.empty else 0
    if info:
        story.append(p(f"{info} informational finding(s) (e.g. standard SUID programs) are listed in section 10 and in "
                       "the CSV export.", s["small"]))
    if (fd["severity"] != "Informational").sum() > 60 if not fd.empty else False:
        story.append(p("Only the first 60 detailed findings are shown; see the CSV export for all.", s["small"]))

    story += [PageBreak(), Paragraph("12. Recommendations", s["h1"])]
    story += bullets(_recommendations(r), s)
    story += [Paragraph("13. Conclusion", s["h1"]), p(_conclusion(r), s["body"])]
    doc.multiBuild(story, canvasmaker=_numbered_canvas)
    return output_path
