"""CSV and JSON exports (file names include a timestamp). Exports contain metadata only - no file contents."""

from __future__ import annotations

import io
import json
import re
import zipfile
from datetime import datetime
from pathlib import Path

from config import APP_VERSION, EXPORT_DIR


def stamp_name(kind: str, root: str, ext: str, when: datetime | None = None) -> str:
    when = when or datetime.now()
    safe = re.sub(r"[^A-Za-z0-9.-]+", "_", root.strip("/") or "root")
    safe = re.sub(r"\.{2,}", "_", safe).strip("_.")[:50] or "root"
    return f"{kind}_{safe}_{when:%Y%m%d_%H%M%S}.{ext}"


def findings_csv(r) -> str:
    return r.findings.to_csv(index=False)


def entries_csv(r) -> str:
    cols = ["path", "type", "octal", "symbolic", "owner_display", "group_display", "uid", "gid", "size", "mtime",
            "world_writable", "suid", "sgid", "sticky", "symlink_target", "broken_link"]
    return r.entries[cols].rename(columns={"owner_display": "owner", "group_display": "group"}).to_csv(index=False)


def sensitive_csv(r) -> str:
    return r.sensitive.drop(columns=[c for c in ("mode", "uid", "gid", "extra_bits") if c in r.sensitive.columns]) \
        .to_csv(index=False)


def to_json(r, include_entries: bool = False) -> str:
    def records(df):
        return json.loads(df.to_json(orient="records")) if df is not None and not df.empty else []
    data = {
        "tool": f"Linux File Permission Auditor {APP_VERSION}",
        "audit_id": r.audit_id, "started_at": r.started_at, "finished_at": r.finished_at, "status": r.status,
        "scanned_path": r.root, "options": r.options, "host": r.host, "baseline_profile": r.sensitive_profile,
        "summary": r.summary, "severity_counts": r.severity_counts,
        "permission_distribution": records(r.permission_distribution),
        "world_writable_files": records(r.world_writable_files),
        "world_writable_directories": records(r.world_writable_dirs),
        "suid_sgid": records(r.special.drop(columns=["uid"], errors="ignore")),
        "sensitive_files": records(r.sensitive.drop(columns=["mode", "uid", "gid", "extra_bits"], errors="ignore")),
        "findings": records(r.findings),
        "scan_errors": r.scan.errors[:1000],
    }
    if include_entries:
        data["entries"] = records(r.entries.drop(columns=["mode"], errors="ignore"))
    return json.dumps(data, indent=2, default=str)


def save_exports(r, out_dir: Path = EXPORT_DIR) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    when = datetime.now()
    files = {
        "findings_csv": (out_dir / stamp_name("findings", r.root, "csv", when), findings_csv(r)),
        "entries_csv": (out_dir / stamp_name("permissions", r.root, "csv", when), entries_csv(r)),
        "sensitive_csv": (out_dir / stamp_name("sensitive_files", r.root, "csv", when), sensitive_csv(r)),
        "audit_json": (out_dir / stamp_name("audit", r.root, "json", when), to_json(r)),
    }
    for path, text in files.values():
        path.write_text(text, encoding="utf-8")
    return {k: v[0] for k, v in files.items()}


def zip_bundle(r) -> bytes:
    buf = io.BytesIO()
    when = datetime.now()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(stamp_name("findings", r.root, "csv", when), findings_csv(r))
        zf.writestr(stamp_name("permissions", r.root, "csv", when), entries_csv(r))
        zf.writestr(stamp_name("sensitive_files", r.root, "csv", when), sensitive_csv(r))
        zf.writestr(stamp_name("audit", r.root, "json", when), to_json(r))
    return buf.getvalue()
