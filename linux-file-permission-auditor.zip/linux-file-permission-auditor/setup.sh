#!/usr/bin/env bash
# One-time setup on Ubuntu / Kali Linux: creates a virtual environment and installs the dependencies.
set -euo pipefail
cd "$(dirname "$0")"
if ! python3 -c "import venv, ensurepip" 2>/dev/null; then
  echo "python3-venv is missing. Install it with:  sudo apt update && sudo apt install -y python3-venv python3-pip"
  exit 1
fi
[ -d venv ] || python3 -m venv venv          # a venv avoids Kali/Ubuntu 'externally-managed-environment' (PEP 668)
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
echo
echo "Setup complete."
echo "  Run the dashboard (safe mode):      ./run.sh"
echo "  Run with root privileges (full):    sudo ./run.sh"
echo "  Run the tests:                      ./run_tests.sh"
