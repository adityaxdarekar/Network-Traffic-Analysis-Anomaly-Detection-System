"""
The ten transparent, rule-based checks.

Principles:
    * A finding is an INDICATOR for review, never "confirmed vulnerable".
    * Remediation is advice only - the commands are shown as text and NEVER run.
    * The same path is not reported by two rules for the same problem
      (e.g. a baseline file is handled by R7/R8, not again by R1/R10).
"""

from __future__ import annotations

import fnmatch
import shlex
from dataclasses import dataclass, field

import pandas as pd

import config as C
from analyzer.special_permission_analyzer import in_system_location, known_special


@dataclass
class Finding:
    rule: str
    severity: str
    path: str
    file_type: str
    permissions: str
    expected: str
    owner: str
    group: str
    evidence: str
    explanation: str
    impact: str
    remediation: str
    category: str = ""
    finding_id: str = ""

    @property
    def rule_name(self) -> str:
        return C.RULE_NAMES[self.rule]


@dataclass
class RuleContext:
    df: pd.DataFrame                    # scanned entries
    special: pd.DataFrame               # SUID/SGID table
    sensitive_rows: list[dict]          # baseline audit
    settings: dict
    uid_min: int = 1000
    handled_paths: set = field(default_factory=set)   # paths covered by the baseline audit


# Folder names that indicate bundled example/test data (used only to LOWER severity, never to hide findings)
TEST_DATA_DIRS = {"test", "tests", "testdata", "test_data", "testing", "fixtures", "dummyserver", "examples",
                  "templates", "samples"}


def q(path: str) -> str:
    return shlex.quote(path)


def perms(row) -> str:
    return f"{row['octal']} ({row['symbolic']})"


def _matches(name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def under_any(path: str, prefixes: list[str]) -> bool:
    return any(path == p or path.startswith(p.rstrip("/") + "/") for p in prefixes)


def _rows(df: pd.DataFrame, mask) -> list:
    return [r for _, r in df[mask].iterrows()] if not df.empty else []


# ---------------------------------------------------------------------------
def rule_r1(ctx: RuleContext) -> list[Finding]:
    """World-writable SENSITIVE files: anything under /etc, or private keys, credentials and shell start-up files."""
    df = ctx.df
    if df.empty:
        return []
    out = []
    for r in _rows(df, (df["type"] == "file") & df["world_writable"]):
        if r["path"] in ctx.handled_paths:
            continue
        sensitive = r["path"].startswith("/etc/") or _matches(r["name"], C.SENSITIVE_NAME_PATTERNS)
        if not sensitive:
            continue
        sev = "Critical" if r["path"].startswith("/etc/") or _matches(r["name"], C.PRIVATE_KEY_PATTERNS) else "High"
        out.append(Finding(
            "R1", sev, r["path"], r["type"], perms(r), "no write permission for others", r["owner_display"],
            r["group_display"], f"others have write permission (o+w) on a sensitive file: mode {r['octal']}",
            "This file holds configuration, credentials or start-up commands, and every local user can change it.",
            "Any local user (or a compromised service account) could alter system configuration, plant commands "
            "that run when someone logs in, or replace keys/credentials.",
            f"Confirm nobody needs to edit it, then remove write access for others:  sudo chmod o-w {q(r['path'])}",
            "Sensitive files"))
    return out


def rule_r2(ctx: RuleContext) -> list[Finding]:
    """World-writable EXECUTABLE files outside system program directories (those are rule R9)."""
    df = ctx.df
    if df.empty:
        return []
    out = []
    for r in _rows(df, (df["type"] == "file") & df["world_writable"] & df["executable"]):
        if r["path"] in ctx.handled_paths or in_system_location(r["path"]) or r["path"].startswith("/etc/") \
                or _matches(r["name"], C.SENSITIVE_NAME_PATTERNS) or under_any(r["path"], C.STARTUP_PATHS):
            continue
        out.append(Finding(
            "R2", "High", r["path"], r["type"], perms(r), "executable, not writable by others", r["owner_display"],
            r["group_display"], f"executable and writable by every user (mode {r['octal']})",
            "Any local user can change what this program or script does.",
            "If another user (especially root, or a cron job/service) runs it, an attacker can insert commands that "
            "run with that user's privileges.",
            f"Remove write access for others:  sudo chmod o-w {q(r['path'])}  (and check who runs this file).",
            "World-writable files"))
    return out


def rule_r3(ctx: RuleContext) -> list[Finding]:
    """World-writable directories WITHOUT the sticky bit (with the sticky bit, e.g. /tmp, they are normal)."""
    df = ctx.df
    if df.empty:
        return []
    out = []
    for r in _rows(df, (df["type"] == "directory") & df["world_writable"] & ~df["sticky"]):
        critical = under_any(r["path"], C.STARTUP_PATHS) or under_any(r["path"], C.SYSTEM_BIN_DIRS) \
            or r["path"].startswith("/etc")
        out.append(Finding(
            "R3", "Critical" if critical else "High", r["path"], "directory", perms(r),
            "no o+w, or o+w together with the sticky bit (like /tmp: 1777)", r["owner_display"], r["group_display"],
            f"others have write permission and the sticky bit is NOT set (mode {r['octal']})",
            "Every user can create, rename and DELETE any file in this directory - including other users' files."
            + (" It is a system or start-up location." if critical else ""),
            "Attackers can replace files that other users or programs rely on, delete data, or plant files "
            "(e.g. scripts, configuration) that get executed or loaded.",
            f"If it must be shared, add the sticky bit:  sudo chmod +t {q(r['path'])}  - otherwise remove "
            f"write access for others:  sudo chmod o-w {q(r['path'])}",
            "World-writable directories"))
    return out


def _special_finding(rule: str, kind: str, r, ctx: RuleContext) -> Finding | None:
    path = r["path"]
    known = path in known_special()[kind]
    system = in_system_location(path)
    writable_o, writable_g = bool(r["world_writable"]), bool(r["group_writable"])
    reasons = []
    if writable_o:
        sev = "Critical"
        reasons.append("it can be modified by every user")
    elif writable_g and r["group"] not in ctx.settings.get("trusted_system_groups", ["root"]):
        sev = "Critical" if kind == "suid" else "High"
        reasons.append(f"it can be modified by members of group {r['group_display']}")
    elif kind == "suid" and r["uid"] != 0 and not system:
        sev = "High"
        reasons.append(f"it is owned by {r['owner_display']} and outside system directories")
    elif not system:
        sev = "High" if kind == "suid" else "Medium"
        reasons.append("it is outside the standard system program directories")
    elif not known:
        sev = "Medium" if kind == "suid" else "Low"
        reasons.append("it is not on the list of standard programs that normally have this bit")
    else:
        sev = "Informational"
    if kind == "suid" and r["uid"] != 0 and "owned by" not in " ".join(reasons):
        reasons.append(f"it runs with the privileges of {r['owner_display']}, not root")
    label = "SUID" if kind == "suid" else "SGID"
    whose = f"owner ({r['owner_display']})" if kind == "suid" else f"group ({r['group_display']})"
    if sev == "Informational":
        explanation = f"Standard program that normally has the {label} bit (it runs with its {whose}'s privileges)."
        remediation = "No action needed. Keep the package updated (sudo apt update && sudo apt upgrade)."
    else:
        explanation = f"{label} program to review: " + "; ".join(reasons) + "."
        remediation = (f"Identify the owning package (dpkg -S {q(path)}) and whether the {label} bit is needed. "
                       f"If not:  sudo chmod {'u-s' if kind == 'suid' else 'g-s'} {q(path)}"
                       + (f"; remove write access:  sudo chmod go-w {q(path)}" if writable_o or writable_g else ""))
    return Finding(rule, sev, path, "file", perms(r), "special bit only on known, root-owned, non-writable programs",
                   r["owner_display"], r["group_display"],
                   f"{label} bit set; owner {r['owner_display']}; known program: {'yes' if known else 'no'}; "
                   f"system location: {'yes' if system else 'no'}",
                   explanation,
                   f"A {label} program runs with its {whose}'s privileges for every user who starts it. A bug in it, "
                   "or the ability to replace it, can give an ordinary user those privileges.",
                   remediation, "SUID/SGID")


def rule_r4(ctx: RuleContext) -> list[Finding]:
    """SUID review: known root-owned system programs = Informational; unknown/unusual/writable ones escalate."""
    df = ctx.df
    return [_special_finding("R4", "suid", r, ctx) for r in _rows(df, (df["type"] == "file") & df["suid"])] \
        if not df.empty else []


def rule_r5(ctx: RuleContext) -> list[Finding]:
    """SGID review (files only; SGID on directories is a normal group-sharing feature)."""
    df = ctx.df
    return [_special_finding("R5", "sgid", r, ctx) for r in _rows(df, (df["type"] == "file") & df["sgid"])] \
        if not df.empty else []


def rule_r6(ctx: RuleContext) -> list[Finding]:
    """Excessively permissive files: world-writable data files not covered elsewhere, and private keys
    readable or writable by group/others."""
    df = ctx.df
    if df.empty:
        return []
    out = []
    for r in _rows(df, (df["type"] == "file") & df["world_writable"] & ~df["executable"]):
        if r["path"] in ctx.handled_paths or r["path"].startswith("/etc/") or \
                _matches(r["name"], C.SENSITIVE_NAME_PATTERNS) or under_any(r["path"], C.STARTUP_PATHS):
            continue
        out.append(Finding(
            "R6", "Medium" if r["mode"] & 0o777 == 0o777 or r["mode"] & 0o066 == 0o066 else "Low", r["path"], "file",
            perms(r), "no write permission for others (e.g. 644 or 664)", r["owner_display"], r["group_display"],
            f"world-writable data file (mode {r['octal']})",
            "Every local user can change or empty this file. That may be intended for a shared file, but is rarely "
            "necessary.",
            "Data integrity: other users can alter or destroy the content; if a program reads it as configuration "
            "or input, they can influence that program.",
            f"Unless the file is meant to be shared:  sudo chmod o-w {q(r['path'])}", "Excessive permissions"))
    trusted = set(ctx.settings.get("trusted_system_groups", ["root"]))
    for r in _rows(df, (df["type"] == "file") & ((df["mode"].astype(int) % 0o100) != 0)):
        if r["path"] in ctx.handled_paths or not _matches(r["name"], C.PRIVATE_KEY_PATTERNS) or r["world_writable"]:
            continue                                     # world-writable keys are already Critical under R1
        mode = int(r["mode"])
        if mode & 0o007:
            sev, who = "High", "all users (others)"
        elif mode & 0o020:
            sev, who = "High", f"group {r['group_display']} (write)"
        elif r["group"] in trusted:
            continue                                     # e.g. Debian's ssl-cert group may read TLS keys by design
        else:
            sev, who = "Low", f"group {r['group_display']}"
        test_data = bool(TEST_DATA_DIRS & set(r["path"].lower().split("/")))
        if test_data:
            sev = "Low"
        out.append(Finding(
            "R6", sev, r["path"], "file", perms(r), "600 (rw-------) or 400 for private keys", r["owner_display"],
            r["group_display"], f"private-key file accessible by {who} (mode {r['octal']})",
            "Private keys should be readable only by their owner (or a dedicated service group)."
            + (" This file is inside a test/sample-data folder of installed software, so it is most likely a "
               "published example key - severity lowered to Low." if test_data else ""),
            "Anyone who can read a private key can impersonate its owner (SSH logins, TLS servers). SSH itself "
            "refuses keys with such permissions.",
            f"sudo chmod 600 {q(r['path'])}", "Excessive permissions"))
    return out


def rule_r7(ctx: RuleContext) -> list[Finding]:
    """Sensitive configuration files compared with the distribution-aware baseline policy."""
    out = []
    for row in ctx.sensitive_rows:
        if not row["exists"] or row["mode"] is None or not row["extra_bits"]:
            continue
        name = row["file"]
        if row["others_write"]:
            sev = "Critical"
        elif row["others_read"] and any(x in name for x in ("shadow", "sudoers", "ssh_host")):
            sev = "High"
        elif row["group_write"]:
            sev = "High"
        else:
            sev = "Medium"
        out.append(Finding(
            "R7", sev, name, row["type"], f"{row['observed_mode']} ({row['observed_symbolic']})",
            f"{row['expected_mode']}, typical {row['typical_mode']}", row["observed_owner"], row["observed_group"],
            "; ".join(row["issues"]),
            "This file is more permissive than the configured baseline policy for this distribution.",
            {"Critical": "Every user can modify a security-critical file (e.g. add an account or a sudo rule).",
             "High": "Sensitive data (password hashes, sudo rules, host keys) is exposed or modifiable beyond "
                     "the intended administrators.",
             "Medium": "More access than necessary; review whether it is intentional."}[sev],
            f"Compare with your distribution's default, then e.g.:  sudo chmod {row['typical_mode']} {q(name)}",
            "Sensitive configuration"))
    return out


def rule_r8(ctx: RuleContext) -> list[Finding]:
    """Unexpected ownership of sensitive files, orphaned UIDs/GIDs, user-owned files in system locations."""
    out = []
    for row in ctx.sensitive_rows:
        if not row["exists"] or row["uid"] is None or (row["owner_ok"] and row["group_ok"]):
            continue
        user_owner = not row["owner_ok"] and row["uid"] >= ctx.uid_min
        sev = "High" if user_owner else "Medium" if not row["owner_ok"] else \
            ("Medium" if row["group_write"] else "Low")
        out.append(Finding(
            "R8", sev, row["file"], row["type"], f"{row['observed_mode']} ({row['observed_symbolic']})",
            f"owner {row['expected_owner']}, group {row['expected_group']}", row["observed_owner"],
            row["observed_group"], "; ".join(i for i in row["issues"] if "Owner" in i or "Group" in i),
            "The owner or group of this sensitive file does not match the configured policy.",
            "The owner of a file can change its permissions and content; an unexpected owner or group may be able "
            "to alter security configuration.",
            f"Verify the reason, then if appropriate:  sudo chown {row['expected_owner'].split('/')[0]}:"
            f"{row['expected_group'].split('/')[0]} {q(row['file'])}", "Ownership"))
    df = ctx.df
    if df.empty:
        return out
    orphan = _rows(df, df["owner"].isna() | df["group"].isna())
    for r in orphan[:200]:
        out.append(Finding(
            "R8", "Low", r["path"], r["type"], perms(r), "UID/GID that belongs to an existing account",
            r["owner_display"], r["group_display"], "owner and/or group number does not exist in /etc/passwd or /etc/group",
            "Orphaned file: its owning account or group was removed (or it came from another system).",
            "If a new account is later created with the same UID/GID it silently becomes the owner.",
            f"Assign a valid owner:  sudo chown <user>:<group> {q(r['path'])}", "Ownership"))
    sysuser = _rows(df, (df["uid"] >= ctx.uid_min) & (df["uid"] != 65534) & df["path"].map(in_system_location)
                    & (df["type"] == "file"))
    for r in sysuser[:200]:
        out.append(Finding(
            "R8", "Medium", r["path"], r["type"], perms(r), "owned by root (or a system account)", r["owner_display"],
            r["group_display"], f"regular user {r['owner_display']} owns a file in a system program directory",
            "System programs and libraries are normally owned by root.",
            "That user can modify the file; if it is executed or loaded by other users or root, this allows "
            "privilege escalation.",
            f"If it belongs to a package, restore ownership:  sudo chown root:root {q(r['path'])}", "Ownership"))
    return out


def rule_r9(ctx: RuleContext) -> list[Finding]:
    """Executables in system program directories that other users or non-administrative groups can modify."""
    df = ctx.df
    if df.empty:
        return []
    trusted = set(ctx.settings.get("trusted_system_groups", ["root"]))
    out = []
    mask = (df["type"] == "file") & df["executable"] & (df["world_writable"] | df["group_writable"]) \
        & df["path"].map(in_system_location)
    for r in _rows(df, mask):
        if r["suid"] or r["sgid"]:
            continue                                     # covered by R4/R5 with Critical severity
        if r["world_writable"]:
            sev, who = "Critical", "every user"
        elif r["group"] not in trusted:
            sev, who = "High", f"members of group {r['group_display']}"
        else:
            sev, who = "Low", f"members of administrative group {r['group_display']}"
        out.append(Finding(
            "R9", sev, r["path"], "file", perms(r), "755 (rwxr-xr-x), owned by root", r["owner_display"],
            r["group_display"], f"system executable writable by {who} (mode {r['octal']})",
            "Programs in system directories are run by many users and by root.",
            "Whoever can modify it can make root (or any user who runs it) execute their code - a classic local "
            "privilege-escalation path.",
            f"sudo chmod go-w {q(r['path'])}  then verify the file against its package (debsums / dpkg --verify).",
            "System executables"))
    return out


def rule_r10(ctx: RuleContext) -> list[Finding]:
    """Start-up and scheduled-task files/dirs (cron, systemd units, init scripts, profile) writable by others,
    by non-administrative groups, or owned by a regular user."""
    df = ctx.df
    if df.empty:
        return []
    trusted = set(ctx.settings.get("trusted_system_groups", ["root"]))
    out = []
    sub = df[df["path"].map(lambda p: under_any(p, C.STARTUP_PATHS)) & df["type"].isin(["file", "directory"])]
    for _, r in sub.iterrows():
        if r["path"] in ctx.handled_paths:
            continue
        reasons, sev = [], None
        if r["world_writable"] and not (r["type"] == "directory" and r["sticky"] and r["path"].startswith("/var/spool/cron")):
            reasons.append("writable by every user")
            sev = "Critical"
        elif r["group_writable"] and r["group"] not in trusted:
            reasons.append(f"writable by group {r['group_display']}")
            sev = "High"
        if r["uid"] >= ctx.uid_min and r["uid"] != 65534 and not r["path"].startswith("/var/spool/cron"):
            reasons.append(f"owned by regular user {r['owner_display']}")
            sev = sev or "High"
        if not sev:
            continue
        out.append(Finding(
            "R10", sev, r["path"], r["type"], perms(r), "owned by root, not writable by group/others",
            r["owner_display"], r["group_display"], "start-up / scheduled-task location " + "; ".join(reasons),
            "Files here define commands that the system runs automatically (cron jobs, services, login scripts), "
            "often as root.",
            "A user who can change them can schedule or inject commands that run with root privileges.",
            f"sudo chown root:root {q(r['path'])} && sudo chmod go-w {q(r['path'])}  (after confirming the change "
            "is not intended)", "Startup & scheduled tasks"))
    return out


ALL_RULES = {"R1": rule_r1, "R2": rule_r2, "R3": rule_r3, "R4": rule_r4, "R5": rule_r5, "R6": rule_r6,
             "R7": rule_r7, "R8": rule_r8, "R9": rule_r9, "R10": rule_r10}


def describe_rules() -> list[dict]:
    return [{"rule": k, "name": C.RULE_NAMES[k], "logic": " ".join((f.__doc__ or "").split())}
            for k, f in ALL_RULES.items()]


__all__ = ["Finding", "RuleContext", "ALL_RULES", "describe_rules"]
