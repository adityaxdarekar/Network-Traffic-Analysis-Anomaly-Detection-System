"""Risk engine: runs the enabled rules, applies severity overrides, numbers and sorts findings."""

from __future__ import annotations

import pandas as pd

import config as C
from detection.detection_rules import ALL_RULES, RuleContext

FINDING_COLUMNS = ["finding_id", "severity", "rule", "rule_name", "category", "path", "file_type", "permissions",
                   "expected", "owner", "group", "evidence", "explanation", "impact", "remediation"]


def run_rules(ctx: RuleContext) -> tuple[pd.DataFrame, list[str]]:
    enabled = ctx.settings.get("rules_enabled", {})
    overrides = ctx.settings.get("severity_overrides", {}) or {}
    findings, errors = [], []
    for rule_id, fn in ALL_RULES.items():
        if not enabled.get(rule_id, True):
            continue
        try:
            found = fn(ctx)
        except Exception as exc:  # noqa: BLE001 - one faulty rule must not stop the audit
            errors.append(f"{rule_id} ({C.RULE_NAMES[rule_id]}) failed: {exc.__class__.__name__}: {exc}")
            continue
        if overrides.get(rule_id) in C.SEVERITY_ORDER:
            for f in found:
                f.severity = overrides[rule_id]
        findings.extend(found)
    findings.sort(key=lambda f: (-C.SEVERITY_ORDER.index(f.severity), f.rule, f.path))
    for i, f in enumerate(findings, 1):
        f.finding_id = f"F-{i:04d}"
    if not findings:
        return pd.DataFrame(columns=FINDING_COLUMNS), errors
    df = pd.DataFrame([{**{k: getattr(f, k) for k in FINDING_COLUMNS if k != "rule_name"}, "rule_name": f.rule_name}
                       for f in findings])
    return df[FINDING_COLUMNS], errors


def severity_counts(findings: pd.DataFrame) -> dict[str, int]:
    counts = {s: 0 for s in C.SEVERITY_ORDER}
    if findings is not None and not findings.empty:
        for k, v in findings["severity"].value_counts().items():
            counts[k] = int(v)
    return counts
