"""Audit History page: previous audits and comparison."""

from __future__ import annotations

import streamlit as st

from dashboard.common import db_or_warn, page_header, show_table
from database.db_manager import DatabaseError


def render() -> None:
    page_header("Audit History", "Previous audits stored in SQLite")
    db = db_or_warn()
    if db is None:
        return
    try:
        audits = db.list_audits()
    except DatabaseError as exc:
        st.error(str(exc))
        return
    if audits.empty:
        st.info("No audits stored yet.")
        return
    show_table(audits.drop(columns=["severity_json"]), height=280)
    label = {a.audit_id: f"{a.started_at} · {a.scanned_path} · {a.findings} findings" for a in audits.itertuples()}
    ids = list(label)
    pick = st.selectbox("View an audit", ids, format_func=label.get, key="ah_pick")
    rec = db.get_audit(pick)
    if rec:
        st.caption(f"{rec['host'].get('distribution', '')} · {rec['status']} · severities {rec['severity_counts']}")
        t1, t2, t3 = st.tabs(["Findings", "Notable entries", "Sensitive files"])
        with t1:
            show_table(rec["findings"])
        with t2:
            show_table(rec["notable_entries"])
        with t3:
            show_table(rec["sensitive_audit"])
        if st.button("🗑 Delete this audit", key="ah_del"):
            db.delete_audit(pick)
            st.rerun()

    st.subheader("Compare two audits")
    if len(ids) < 2:
        st.caption("Run at least two audits (ideally of the same directory) to compare them.")
        return
    c1, c2 = st.columns(2)
    old = c1.selectbox("Earlier audit", ids, index=1, format_func=label.get, key="ah_old")
    new = c2.selectbox("Later audit", ids, index=0, format_func=label.get, key="ah_new")
    if old == new:
        st.caption("Choose two different audits.")
        return
    cmp = db.compare(old, new)
    if not cmp["same_path"]:
        st.warning("The two audits scanned different directories - differences may simply reflect that.")
    diff = cmp["findings"]
    if diff.empty and not cmp["special_added"] and not cmp["special_removed"]:
        st.success("No changes in findings or SUID/SGID files.")
    else:
        st.markdown(f"**{(diff['change'] == 'New finding').sum()} new**, **{(diff['change'] == 'Resolved').sum()} "
                    f"resolved**, **{(diff['change'] == 'Changed').sum()} changed** findings.")
        show_table(diff)
        if cmp["special_added"]:
            st.warning("New SUID/SGID files: " + ", ".join(cmp["special_added"]))
        if cmp["special_removed"]:
            st.info("SUID/SGID files no longer present: " + ", ".join(cmp["special_removed"]))
