"""About Project page."""

from __future__ import annotations

import streamlit as st

import config as C
from dashboard.common import page_header

ARCH = """
LINUX FILESYSTEM
      │  os.scandir + lstat (read-only, links not followed, one filesystem, /proc /sys /dev /run excluded)
      ▼
PYTHON FILE SCANNER ──► PERMISSION EXTRACTION (numeric + symbolic, owner/group, size, mtime)
      │
      ├──► PERMISSION ANALYSIS ──► world-writable files/dirs, sticky bit, SUID/SGID, distribution
      └──► OWNERSHIP ANALYSIS  ──► UID/GID → user/group, orphaned files, unusual owners
      │
SENSITIVE FILE AUDIT (distribution-aware baselines)
      ▼
SECURITY AUDITOR (10 rules) ──► RISK CLASSIFICATION (Informational → Critical)
      ▼
SQLITE DATABASE ──► STREAMLIT DASHBOARD ──► PDF / CSV / JSON REPORTS
"""


def render() -> None:
    page_header("About Project", C.APP_SUBTITLE)
    st.markdown(f"**{C.APP_TITLE}** v{C.APP_VERSION} audits Linux file and directory permissions to find insecure "
                "configurations: world-writable files and directories, SUID/SGID programs, sensitive configuration "
                "files that deviate from policy, and unusual ownership.")
    st.code(ARCH, language=None)
    c1, c2 = st.columns(2)
    c1.markdown("""
**Technology**
- Python 3.10+: os, pathlib, stat, pwd, grp
- Streamlit + Plotly + pandas dashboard
- SQLite history, ReportLab PDF reports
- pytest test suite on synthetic test files
""")
    c2.markdown("""
**Safety guarantees**
- Read-only: never runs chmod/chown, never modifies or deletes
- Never reads file contents
- Symbolic links are not followed; virtual filesystems excluded
- Results stay on this machine; hostname masked in reports by default
- Findings are indicators to review, not confirmed vulnerabilities
""")
    st.info("Only audit systems you own or are authorised to assess.")
