"""Sensitive File Audit page."""

from __future__ import annotations

import streamlit as st

from dashboard.common import kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("Sensitive File Audit", "System configuration files compared with the baseline policy")
    r = require_result()
    sens = r.sensitive
    if sens.empty:
        st.info("No baseline policies are configured (data/permission_baselines.json).")
        return
    res = sens["result"]
    kpi_row([("Files checked", len(sens)), ("OK", int(res.str.startswith("OK").sum())),
             ("Deviations", int((res == "Deviation - review").sum()), "", "alert" if (res == "Deviation - review").any()
              else "accent"),
             ("Not present / not accessible", int(res.isin(["Not present", "Not accessible"]).sum()))])
    st.markdown(f"<div class='panel'>Baseline profile: <b>{r.sensitive_profile}</b> (chosen from /etc/os-release). "
                "The policy is a <b>maximum</b>: stricter permissions pass. Observed values and the expected policy are "
                "shown separately; a deviation is something to <b>review</b> - distributions and organisations "
                "differ. Edit <code>data/permission_baselines.json</code> to change the policy. This check always "
                "audits the real system files listed, whatever directory was scanned.</div>", unsafe_allow_html=True)
    cols = ["file", "result", "type", "observed_mode", "observed_symbolic", "expected_mode", "typical_mode",
            "observed_owner", "observed_group", "expected_owner", "expected_group", "issues"]
    only = st.radio("Show", ["All", "Deviations only"], horizontal=True, key="sf_only")
    view = sens if only == "All" else sens[sens["result"] == "Deviation - review"]
    show_table(view[cols], height=520, empty_msg="No deviations from the baseline policy.")
