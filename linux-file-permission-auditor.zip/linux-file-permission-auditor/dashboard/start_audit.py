"""Start New Audit page."""

from __future__ import annotations

import os
import time

import pandas as pd

import streamlit as st

import config as C
from dashboard.common import db_or_warn, get_result, get_settings, go_to, kpi_row, page_header, show_table
from scanner.filesystem_scanner import ScanPathError, validate_scan_path
from scanner.scan_manager import AuditJob, options_from_settings

QUICK = ["/etc", "/home", "/usr/bin", "/usr/local", "/opt", "/var", "/tmp", "/"]
LAB_DIR = C.BASE_DIR / "sample_files" / "lab"


def _store(result) -> None:
    st.session_state["result"] = result
    st.session_state.pop("last_report", None)
    db = db_or_warn()
    if db is not None:
        try:
            db.save_audit(result)
        except Exception as exc:  # noqa: BLE001
            st.warning(f"Audit finished but could not be saved to history: {exc}")


def render() -> None:
    page_header("Start New Audit", "Read-only scan of a directory's permissions and ownership")
    settings = get_settings()
    sc = settings["scan"]
    privileged = os.geteuid() == 0
    if privileged:
        st.info("Running as **root**: the audit can read every directory. It is still strictly read-only.")
    else:
        st.warning("Running in **safe mode (no root privileges)**. Permissions of most files can still be read, "
                   "but directories you cannot list (e.g. /root, some of /var) will be reported as 'Permission "
                   "denied'. For a complete audit, start the app with `sudo` on a system you are authorised to audit.")

    job: AuditJob | None = st.session_state.get("audit_job")
    running = bool(job and job.is_running())

    st.caption("Quick picks:")
    qcols = st.columns(len(QUICK) + 1)
    for col, q in zip(qcols, QUICK):
        if col.button(q, key=f"quick_{q}", disabled=running):
            st.session_state["audit_path"] = q
    if qcols[-1].button("Demo lab", key="quick_lab", disabled=running):
        from sample_files.create_samples import create
        create(LAB_DIR)
        st.session_state["audit_path"] = str(LAB_DIR)
        st.success(f"Demonstration tree created in {LAB_DIR} (deliberately insecure test files, nothing else "
                   "is touched).")

    if "audit_path" not in st.session_state:
        st.session_state["audit_path"] = sc["path"]
    path = st.text_input("Directory to audit", key="audit_path", disabled=running,
                         help="Absolute path, e.g. /etc or /home/kali")
    c1, c2, c3 = st.columns(3)
    recursive = c1.checkbox("Recursive (include sub-directories)", value=bool(sc["recursive"]), disabled=running)
    one_fs = c2.checkbox("Stay on one filesystem", value=bool(sc["one_filesystem"]), disabled=running,
                         help="Like find -xdev: do not enter other mounted filesystems.")
    max_entries = c3.number_input("Maximum entries", 1000, 5_000_000, int(sc["max_entries"]), step=50_000,
                                  disabled=running)
    excl_text = st.text_area("Excluded paths (one per line)", "\n".join(sc["exclusions"]), height=100, disabled=running)
    pat_text = st.text_input("Excluded file-name patterns (comma separated, e.g. *.log, node_modules)",
                             ", ".join(sc.get("exclude_patterns", [])), disabled=running)
    st.caption("Symbolic links are never followed. /proc, /sys, /dev and /run are virtual filesystems and are "
               "excluded by default. Nothing is ever modified.")
    exclusions = [x.strip() for x in excl_text.splitlines() if x.strip()]
    patterns = [x.strip() for x in pat_text.split(",") if x.strip()]

    valid, message = True, ""
    try:
        norm = validate_scan_path(path, exclusions)
        message = f"Ready to audit {norm}"
    except ScanPathError as exc:
        valid, message = False, str(exc)
    (st.success if valid else st.error)(message)

    b1, b2, _ = st.columns([1, 1, 3])
    if b1.button("▶ Start audit", type="primary", disabled=running or not valid):
        opts = options_from_settings(norm, settings, recursive=recursive, one_filesystem=one_fs,
                                     exclusions=exclusions, exclude_patterns=patterns, max_entries=int(max_entries))
        st.session_state["audit_job"] = AuditJob(opts, settings).start()
        st.session_state["audit_saved"] = None
        st.rerun()
    if b2.button("■ Stop audit", disabled=not running):
        job.stop()
        st.rerun()

    if job is None:
        return
    status = job.status()
    st.markdown(f"**Status:** {status['state'].upper()} · {status['elapsed']:.1f}s")
    kpi_row([("Files scanned", f"{status['files']:,}"), ("Directories scanned", f"{status['directories']:,}")])
    if status["state"] == "running":
        st.caption(f"Scanning: `{status['current']}`")
        time.sleep(1)
        st.rerun()
    if status["error"]:
        st.error(status["error"])
    if job.result is not None and st.session_state.get("audit_saved") != job.result.audit_id:
        _store(job.result)
        st.session_state["audit_saved"] = job.result.audit_id
    r = get_result()
    if r is not None and job.result is not None and r.audit_id == job.result.audit_id:
        s = r.summary
        st.success(f"Audit {r.status}: {s['files']:,} files, {s['directories']:,} directories, {s['findings']} findings "
                   f"in {s['duration_sec']} s.")
        if r.scan.stopped:
            st.warning("The audit was stopped - results are partial.")
        if r.scan.limit_reached:
            st.warning("The maximum number of entries was reached - results are partial. Audit a narrower directory "
                       "or raise the limit.")
        if r.scan.errors:
            with st.expander(f"{len(r.scan.errors)} location(s) could not be read"):
                show_table(pd.DataFrame(r.scan.errors))
        if st.button("📊 Open the dashboard overview", key="go_overview"):
            go_to("Dashboard Overview")

