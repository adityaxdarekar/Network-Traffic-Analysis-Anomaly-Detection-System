"""World-Writable Files and World-Writable Directories pages."""

from __future__ import annotations

import streamlit as st

from dashboard.common import findings_for, kpi_row, page_header, require_result, show_table


def _with_risk(table, findings):
    if table.empty:
        return table
    sev = findings.drop_duplicates("path").set_index("path")["severity"] if not findings.empty else {}
    expl = findings.drop_duplicates("path").set_index("path")["explanation"] if not findings.empty else {}
    out = table.copy()
    out["risk_severity"] = out["path"].map(lambda p: sev.get(p, "Not flagged") if len(sev) else "Not flagged")
    out["explanation"] = out["path"].map(lambda p: expl.get(p, "") if len(expl) else "")
    return out


def render_files() -> None:
    page_header("World-Writable Files", "Files every local user can modify  (find DIR -type f -perm -0002)")
    r = require_result()
    ww = r.world_writable_files
    f = findings_for(r, ["R1", "R2", "R6", "R7", "R9", "R10"])
    kpi_row([("World-writable files", len(ww)), ("Executable", int(ww["executable"].sum()) if not ww.empty else 0),
             ("Flagged", int(ww["path"].isin(f["path"]).sum()) if not ww.empty else 0)])
    st.markdown("<div class='panel'>A world-writable file (others have <b>w</b>, e.g. <code>666</code> / "
                "<code>-rw-rw-rw-</code>) is not automatically a vulnerability - shared scratch files can be "
                "intentional. It becomes serious for <b>configuration files</b>, <b>credentials</b> and "
                "<b>executables or scripts</b> that other users or root run.</div>", unsafe_allow_html=True)
    if ww.empty:
        st.success("No world-writable files were found in this audit.")
        return
    q = st.text_input("Filter by path", key="wwf_q")
    view = _with_risk(ww, f)
    if q:
        view = view[view["path"].str.contains(q, case=False, regex=False)]
    show_table(view.rename(columns={"owner_display": "owner", "group_display": "group"}), height=440)


def render_dirs() -> None:
    page_header("World-Writable Directories", "Directories where every user can create entries "
                                              "(find DIR -type d -perm -0002)")
    r = require_result()
    wd = r.world_writable_dirs
    kpi_row([("World-writable directories", len(wd)),
             ("With sticky bit", int(wd["sticky"].sum()) if not wd.empty else 0),
             ("WITHOUT sticky bit", int((~wd["sticky"]).sum()) if not wd.empty else 0, "",
              "alert" if not wd.empty and (~wd["sticky"]).any() else "accent")])
    st.markdown("<div class='panel'><b>The sticky bit</b> (<code>t</code> in <code>drwxrwxrwt</code>, numeric "
                "<code>1777</code>): in a directory everybody may write to, the sticky bit means users can only delete "
                "or rename <b>their own</b> files. That is why <code>/tmp</code> is world-writable and still safe. "
                "<b>Without</b> the sticky bit any user can delete or replace other users' files - e.g. swap a "
                "script another user is about to run.</div>", unsafe_allow_html=True)
    if wd.empty:
        st.success("No world-writable directories were found in this audit.")
        return
    f = findings_for(r, ["R3", "R10"])
    view = _with_risk(wd, f)
    show_table(view.rename(columns={"owner_display": "owner", "group_display": "group"}), height=420)
