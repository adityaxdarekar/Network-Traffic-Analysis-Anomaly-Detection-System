"""Settings page."""

from __future__ import annotations

import json

import pandas as pd
import streamlit as st

import config as C
from analyzer.sensitive_file_auditor import load_baselines, read_os_release, select_profile
from dashboard.common import get_settings, page_header, show_table


def render() -> None:
    page_header("Settings", "Scan defaults, rules, severity, ownership expectations and baselines")
    s = get_settings()

    st.subheader("Scan defaults")
    c1, c2 = st.columns(2)
    path = c1.text_input("Default directory", s["scan"]["path"], key="st_path")
    max_entries = c2.number_input("Maximum entries per audit", 1000, 5_000_000, int(s["scan"]["max_entries"]),
                                  step=50_000, key="st_max")
    excl = st.text_area("Default exclusions (one per line)", "\n".join(s["scan"]["exclusions"]), key="st_excl")

    st.subheader("Detection rules and severity")
    st.caption("Disable a rule, or force every finding of a rule to one severity (e.g. make R4 SUID review 'Low' on "
               "systems where you review SUID programs separately). 'Rule default' keeps the built-in logic.")
    enabled, overrides = {}, {}
    for rid, name in C.RULE_NAMES.items():
        a, b = st.columns([2, 1])
        enabled[rid] = a.checkbox(f"{rid} · {name}", value=s["rules_enabled"].get(rid, True), key=f"st_en_{rid}")
        opts = ["Rule default"] + C.SEVERITY_ORDER
        cur = s["severity_overrides"].get(rid, "Rule default")
        choice = b.selectbox("Severity", opts, index=opts.index(cur) if cur in opts else 0, key=f"st_sev_{rid}",
                             label_visibility="collapsed")
        if choice != "Rule default":
            overrides[rid] = choice

    st.subheader("Ownership expectations")
    uid_min = st.number_input("First UID of regular user accounts", 100, 100000, int(s["regular_user_uid_min"]),
                              key="st_uid")
    groups = st.text_input("Trusted administrative groups (comma separated)",
                           ", ".join(s["trusted_system_groups"]), key="st_groups")

    st.subheader("Dashboard preferences")
    c3, c4 = st.columns(2)
    mask = c3.checkbox("Mask the hostname in reports (privacy)", value=bool(s["dashboard"]["mask_hostname"]),
                       key="st_mask")
    rows = c4.number_input("Rows shown in tables", 100, 50000, int(s["dashboard"]["table_rows"]), key="st_rows")

    b1, b2 = st.columns(2)
    if b1.button("💾 Save settings", type="primary"):
        s["scan"].update(path=path, max_entries=int(max_entries),
                         exclusions=[x.strip() for x in excl.splitlines() if x.strip()])
        s.update(rules_enabled=enabled, severity_overrides=overrides, regular_user_uid_min=int(uid_min),
                 trusted_system_groups=[g.strip() for g in groups.split(",") if g.strip()])
        s["dashboard"].update(mask_hostname=bool(mask), table_rows=int(rows))
        C.save_settings(s)
        st.success("Saved. New settings apply to the next audit.")
    if b2.button("↺ Reset to defaults"):
        st.session_state["settings"] = C.default_settings()
        C.save_settings(st.session_state["settings"])
        for k in [k for k in st.session_state if k.startswith("st_")]:
            del st.session_state[k]
        st.rerun()

    st.subheader("Expected permission policies (baselines)")
    profile, files = select_profile(read_os_release())
    st.caption(f"Detected profile for this system: **{profile}** ({read_os_release().get('PRETTY_NAME', 'unknown')}). "
               f"Edit `{C.BASELINE_FILE.relative_to(C.BASE_DIR)}` to change policies, then restart the app.")
    show_table(pd.DataFrame([{"file": k, **{x: (", ".join(v) if isinstance(v, list) else v) for x, v in p.items()}}
                             for k, p in files.items()]))
    with st.expander("All baseline profiles (raw JSON)"):
        st.code(json.dumps(load_baselines(), indent=2), language="json")
