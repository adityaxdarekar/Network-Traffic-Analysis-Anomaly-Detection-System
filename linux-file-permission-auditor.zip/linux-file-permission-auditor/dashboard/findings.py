"""Security Findings page."""

from __future__ import annotations

import html

import pandas as pd
import streamlit as st

import config as C
from dashboard.common import kpi_row, page_header, require_result, severity_badge, severity_chart, show_table
from detection.detection_rules import describe_rules


def render() -> None:
    page_header("Security Findings", "Rule-based indicators for review - nothing has been changed")
    r = require_result()
    fd, sev = r.findings, r.severity_counts
    kpi_row([(s, sev[s], "", "alert" if s in ("High", "Critical") and sev[s] else "accent")
             for s in reversed(C.SEVERITY_ORDER)])
    for e in r.rule_errors:
        st.error(e)
    with st.expander("Detection rules"):
        show_table(pd.DataFrame(describe_rules()))
    if fd.empty:
        st.success("No findings with the current rules and baselines.")
        return
    c1, c2 = st.columns(2)
    with c1:
        severity_chart(sev)
    with c2:
        vc = fd["category"].value_counts()
        show_table(pd.DataFrame({"category": vc.index, "findings": vc.values}))
    f1, f2, f3 = st.columns(3)
    sev_f = f1.multiselect("Severity", list(reversed(C.SEVERITY_ORDER)), key="fd_sev")
    cat_f = f2.multiselect("Category", sorted(fd["category"].unique()), key="fd_cat")
    q = f3.text_input("Path contains", key="fd_q")
    view = fd
    if sev_f:
        view = view[view["severity"].isin(sev_f)]
    if cat_f:
        view = view[view["category"].isin(cat_f)]
    if q:
        view = view[view["path"].str.contains(q, case=False, regex=False)]
    show_table(view[["finding_id", "severity", "rule", "rule_name", "path", "permissions", "owner", "group",
                     "evidence"]], height=320)
    st.caption("Remediation commands are suggestions to review and run yourself - the auditor never runs them.")
    for f in view.head(80).itertuples():
        with st.expander(f"{f.finding_id} · {f.severity} · {f.rule_name} · {f.path}"):
            st.markdown(f"{severity_badge(f.severity)} &nbsp; <b>{html.escape(f.rule_name)}</b> "
                        f"<span class='muted'>({f.rule}, {html.escape(f.category)})</span>", unsafe_allow_html=True)
            c1, c2, c3 = st.columns(3)
            c1.markdown(f"**Type**  \n{f.file_type}")
            c2.markdown(f"**Current**  \n`{f.permissions}`")
            c3.markdown(f"**Owner / group**  \n{f.owner} / {f.group}")
            st.markdown(f"**Expected:** {f.expected}")
            st.markdown(f"**Evidence:** {f.evidence}")
            st.markdown(f"**Explanation:** {f.explanation}")
            st.markdown(f"**Potential impact:** {f.impact}")
            st.code(f.remediation, language="bash")
    if len(view) > 80:
        st.caption("Showing details for the first 80 findings; all are in the table and the exports.")
