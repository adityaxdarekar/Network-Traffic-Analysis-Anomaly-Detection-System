"""Dark SOC-style visual theme: CSS for Streamlit and a matching Plotly template."""

from __future__ import annotations

BG = "#0a1628"          # dark navy page background
PANEL = "#0f2038"       # cards / panels
PANEL_2 = "#132a4a"
BORDER = "#1e3a5f"
TEXT = "#e2e8f0"
MUTED = "#8ba3c7"
CYAN = "#22d3ee"
BLUE = "#3b82f6"
CHART_COLORS = ["#3b82f6", "#22d3ee", "#818cf8", "#2dd4bf", "#38bdf8", "#a78bfa", "#facc15", "#94a3b8"]

CSS = f"""
<style>
.stApp {{ background: {BG}; }}
section[data-testid="stSidebar"] {{ background: #081223; border-right: 1px solid {BORDER}; }}
h1, h2, h3, h4 {{ color: {TEXT}; letter-spacing: .2px; }}
.block-container {{ padding-top: 1.6rem; max-width: 1400px; }}

.soc-header {{ display:flex; align-items:center; justify-content:space-between;
   border-bottom: 1px solid {BORDER}; padding-bottom: .6rem; margin-bottom: 1.1rem; }}
.soc-header .title {{ font-size: 1.55rem; font-weight: 700; color: {TEXT}; }}
.soc-header .subtitle {{ color: {MUTED}; font-size: .85rem; }}
.soc-pill {{ display:inline-block; padding: 2px 10px; border-radius: 999px; font-size: .75rem;
   border: 1px solid {BORDER}; color: {CYAN}; background: {PANEL}; margin-left: 6px; }}

.kpi {{ background: linear-gradient(180deg, {PANEL_2} 0%, {PANEL} 100%); border: 1px solid {BORDER};
   border-radius: 10px; padding: 14px 16px; height: 100%; }}
.kpi .label {{ color: {MUTED}; font-size: .72rem; text-transform: uppercase; letter-spacing: .08em; }}
.kpi .value {{ color: {TEXT}; font-size: 1.65rem; font-weight: 700; margin-top: 2px; }}
.kpi .sub {{ color: {MUTED}; font-size: .75rem; }}
.kpi.accent {{ border-left: 3px solid {CYAN}; }}
.kpi.alert {{ border-left: 3px solid #ef4444; }}

.panel {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 10px; padding: 14px 16px;
   margin-bottom: 12px; }}
.sev {{ display:inline-block; padding: 2px 9px; border-radius: 6px; font-size: .72rem; font-weight: 700;
   color: #0a1628; }}
.sev-Informational {{ background:#94a3b8; }} .sev-Low {{ background:#38bdf8; }} .sev-Medium {{ background:#facc15; }}
.sev-High {{ background:#fb923c; }} .sev-Critical {{ background:#ef4444; color:white; }}
.muted {{ color: {MUTED}; font-size: .85rem; }}
div[data-testid="stExpander"] {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 10px; }}
</style>
"""


def plotly_layout(fig, title: str | None = None, height: int = 340):
    """Apply the dark theme to a Plotly figure."""
    fig.update_layout(
        template="plotly_dark", paper_bgcolor=PANEL, plot_bgcolor=PANEL, height=height,
        font=dict(color=TEXT, size=12), colorway=CHART_COLORS,
        margin=dict(l=10, r=10, t=45 if title else 15, b=10),
        title=dict(text=title, font=dict(size=14, color=TEXT), x=0.01) if title else None,
        legend=dict(bgcolor="rgba(0,0,0,0)"),
    )
    fig.update_xaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    fig.update_yaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    return fig
