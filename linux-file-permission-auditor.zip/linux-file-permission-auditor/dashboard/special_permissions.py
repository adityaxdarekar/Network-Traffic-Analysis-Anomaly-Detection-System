"""SUID/SGID Analysis page."""

from __future__ import annotations

import streamlit as st

from dashboard.common import kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("SUID / SGID Analysis", "Programs that run with their owner's or group's privileges")
    r = require_result()
    sp = r.special
    kpi_row([("SUID files", r.summary["suid"]), ("SGID files", r.summary["sgid"]),
             ("On standard list", int(sp["known"].sum()) if not sp.empty else 0),
             ("Need review", int((~sp["known"] | (sp["indicators"] != "")).sum()) if not sp.empty else 0, "",
              "alert" if not sp.empty and ((~sp["known"]) | (sp["indicators"] != "")).any() else "accent")])
    st.markdown("<div class='panel'><b>SUID</b> (<code>s</code> in the owner's execute position, e.g. "
                "<code>-rwsr-xr-x</code> / <code>4755</code>): the program runs with its <b>owner's</b> privileges "
                "(usually root) whoever starts it - <code>passwd</code> needs this to update /etc/shadow. "
                "<b>SGID</b> (<code>2755</code>) does the same with the group. Such programs are a classic privilege-"
                "escalation target, so they deserve review - but being SUID does not make a file malicious. "
                "Indicators: not a standard program, unusual location, non-root owner, writable by others.</div>",
                unsafe_allow_html=True)
    if sp.empty:
        st.success("No SUID or SGID files in the scanned directory.")
    else:
        only = st.radio("Show", ["All", "Needs review only"], horizontal=True, key="sp_only")
        view = sp if only == "All" else sp[(~sp["known"]) | (sp["indicators"] != "")]
        show_table(view.drop(columns=["uid"]).rename(columns={"owner_display": "owner", "group_display": "group",
                                                              "note": "investigation notes"}), height=420)
    if not r.sgid_dirs.empty:
        st.markdown("**Directories with SGID** (normal for shared group folders - new files inherit the group)")
        show_table(r.sgid_dirs)
