"""Ownership Analysis page."""

from __future__ import annotations

import streamlit as st

from dashboard.common import bar, kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("Ownership Analysis", "Which users and groups own the scanned files")
    r = require_result()
    o = r.ownership
    kpi_row([("Owned by root", f"{o['root_owned']:,}"), ("Owned by other accounts", f"{o['non_root_owned']:,}"),
             ("Unresolved UID/GID", len(o["orphaned"]), "orphaned", "alert" if len(o["orphaned"]) else "accent"),
             ("User files in system dirs", len(o["user_owned_system"]), "", "alert" if len(o["user_owned_system"])
              else "accent")])
    st.caption(f"Regular user accounts start at UID {o['uid_min']} (UID_MIN in /etc/login.defs). Root ownership is "
               "not required for every file; unusual ownership is a lead for manual investigation.")
    c1, c2 = st.columns(2)
    with c1:
        bar(o["owners"].head(10).assign(user=lambda d: d["username"] + " (" + d["uid"].astype(str) + ")"),
            "user", "files", "Files per owner", horizontal=True)
    with c2:
        bar(o["groups"].head(10).assign(grp=lambda d: d["group"] + " (" + d["gid"].astype(str) + ")"), "grp", "files",
            "Files per group", horizontal=True, color="#22d3ee")
    st.markdown("**Owners (UID → username)**")
    show_table(o["owners"])
    st.markdown("**Groups (GID → group)**")
    show_table(o["groups"])
    st.markdown("**Files with unresolved owner or group**")
    show_table(o["orphaned"], empty_msg="None - every UID and GID resolves to an account and group.")
    st.markdown("**Regular-user files inside system program directories**")
    show_table(o["user_owned_system"], empty_msg="None found.")
    uid = st.selectbox("List the files of owner", o["owners"]["uid"].tolist(), key="ow_uid",
                       format_func=lambda u: f"{u} - {o['owners'].set_index('uid').loc[u, 'username']}")
    show_table(r.entries[r.entries["uid"] == uid][["path", "type", "octal", "group_display"]], height=300)
