"""Reports page: PDF, CSV, JSON and previous reports."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from dashboard.common import db_or_warn, download, page_header, require_result, show_table
from reports.export_manager import entries_csv, findings_csv, sensitive_csv, stamp_name, to_json, zip_bundle
from reports.pdf_generator import generate_pdf_report


def render() -> None:
    page_header("Reports", "PDF audit report and CSV / JSON exports")
    r = require_result()
    db = db_or_warn()
    st.subheader("📄 PDF audit report")
    analyst = st.text_input("Prepared by (optional)", key="rp_analyst")
    if st.button("Generate PDF report", type="primary"):
        with st.spinner("Building the report..."):
            try:
                path = generate_pdf_report(r, analyst=analyst)
                st.session_state["last_report"] = str(path)
                if db:
                    db.add_report(r.audit_id, "pdf", str(path))
            except Exception as exc:  # noqa: BLE001
                st.error(f"Report generation failed: {exc}")
    last = st.session_state.get("last_report")
    if last and Path(last).exists():
        st.success(f"Saved to `{last}`")
        download("⬇ Download PDF", Path(last).read_bytes(), Path(last).name, "application/pdf", "dl_pdf", True)

    st.subheader("⬇ Exports")
    c1, c2, c3 = st.columns(3)
    download("Findings (CSV)", findings_csv(r).encode(), stamp_name("findings", r.root, "csv"), "text/csv", "dl_f")
    with c1:
        download("All scanned entries (CSV)", entries_csv(r).encode(), stamp_name("permissions", r.root, "csv"),
                 "text/csv", "dl_e")
    with c2:
        download("Sensitive file audit (CSV)", sensitive_csv(r).encode(), stamp_name("sensitive_files", r.root, "csv"),
                 "text/csv", "dl_s")
        download("Audit summary + findings (JSON)", to_json(r).encode(), stamp_name("audit", r.root, "json"),
                 "application/json", "dl_j")
    with c3:
        download("Everything (ZIP)", zip_bundle(r), stamp_name("audit_bundle", r.root, "zip"), "application/zip",
                 "dl_z")
    st.caption("Exports contain permission metadata only - never file contents.")

    st.subheader("Previous reports")
    if db:
        reps = db.list_reports()
        show_table(reps, empty_msg="No reports generated yet.")
        existing = [p for p in reps["path"].tolist() if Path(p).exists()] if not reps.empty else []
        if existing:
            pick = st.selectbox("Download a previous report", existing, format_func=lambda p: Path(p).name,
                                key="rp_prev")
            download("⬇ Download selected report", Path(pick).read_bytes(), Path(pick).name, "application/pdf",
                     "dl_prev")
