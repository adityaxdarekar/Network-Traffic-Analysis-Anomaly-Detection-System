"""File Permissions page: every scanned entry, searchable, plus a permission explainer."""

from __future__ import annotations

import stat

import pandas as pd
import streamlit as st

from dashboard.common import kpi_row, page_header, require_result, show_table
from scanner.metadata_extractor import explain_permissions

COLUMNS = ["name", "path", "owner_display", "group_display", "octal", "symbolic", "size", "type", "mtime"]


def render() -> None:
    page_header("File Permissions", "Numeric and symbolic permissions of every scanned entry")
    r = require_result()
    df = r.entries
    with st.expander("How to read Linux permissions", expanded=False):
        st.markdown("`-rwxr-xr--` = **type** + **owner** `rwx` + **group** `r-x` + **others** `r--`.  "
                    "Numbers: read = 4, write = 2, execute = 1, added per class → `754`.  "
                    "Special bits (first of four digits): SUID 4, SGID 2, sticky 1 → `4755`, `1777`.")
        show_table(pd.DataFrame([{"numeric": n, "symbolic": stat.filemode(int(n, 8) | stat.S_IFREG)[1:],
                                  "meaning": explain_permissions(int(n, 8))}
                                 for n in ("644", "755", "666", "777", "600", "700", "640", "440", "1777", "4755")]))
        octal = st.text_input("Try any numeric permission", "750", key="perm_try")
        try:
            v = int(octal, 8)
            if not 0 <= v <= 0o7777:
                raise ValueError
            st.success(f"{octal} = {stat.filemode(v | stat.S_IFREG)[1:]} → {explain_permissions(v)}")
        except ValueError:
            st.error("Enter 3 or 4 octal digits (0-7), e.g. 644 or 4755.")
    am = r.access_matrix
    kpi_row([("Entries", f"{len(df):,}")] + [(f"{row['class'].capitalize()} can write", f"{row['write']:,}", "files")
                                            for _, row in am.iterrows()])

    f1, f2, f3, f4 = st.columns([1.6, 1, 1, 1])
    q = f1.text_input("Search path or name", key="pm_q")
    types = f2.multiselect("Type", sorted(df["type"].unique()), key="pm_type")
    octs = f3.multiselect("Numeric permission", sorted(df["octal"].unique()), key="pm_oct")
    owners = f4.multiselect("Owner", sorted(df["owner_display"].astype(str).unique()), key="pm_owner")
    flags = st.multiselect("Only entries that are…", ["world-writable", "group-writable", "executable", "SUID", "SGID",
                                                      "sticky", "broken symlink"], key="pm_flags")
    sort = st.selectbox("Sort by", ["path", "octal", "owner_display", "size", "mtime", "type"], key="pm_sort")
    view = df
    if q:
        view = view[view["path"].str.contains(q, case=False, regex=False)]
    if types:
        view = view[view["type"].isin(types)]
    if octs:
        view = view[view["octal"].isin(octs)]
    if owners:
        view = view[view["owner_display"].astype(str).isin(owners)]
    flag_cols = {"world-writable": "world_writable", "group-writable": "group_writable", "executable": "executable",
                 "SUID": "suid", "SGID": "sgid", "sticky": "sticky", "broken symlink": "broken_link"}
    for f in flags:
        view = view[view[flag_cols[f]]]
    view = view.sort_values(sort, ascending=sort not in ("size", "mtime"))
    st.markdown(f"**{len(view):,}** of {len(df):,} entries")
    show_table(view[COLUMNS].rename(columns={"owner_display": "owner", "group_display": "group"}), height=460)
    if not view.empty:
        pick = st.selectbox("Explain the permissions of", view["path"].head(500).tolist(), key="pm_pick")
        row = df[df["path"] == pick].iloc[0]
        st.markdown(f"`{row['symbolic']}`  **{row['octal']}** - {explain_permissions(int(row['mode']))}  ·  owner "
                    f"**{row['owner_display']}** (UID {row['uid']}), group **{row['group_display']}** (GID {row['gid']})"
                    + (f"  ·  link → `{row['symlink_target']}`{' (broken)' if row['broken_link'] else ''}"
                       if row['type'] == 'symlink' else ""))
