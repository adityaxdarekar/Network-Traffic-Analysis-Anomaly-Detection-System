"""Dashboard Overview page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import bar, donut, kpi_row, page_header, require_result, severity_chart


def render() -> None:
    page_header("Dashboard Overview", "Key figures of the loaded permission audit")
    r = require_result()
    s, sev = r.summary, r.severity_counts
    kpi_row([("Files scanned", f"{s['files']:,}"), ("Directories scanned", f"{s['directories']:,}"),
             ("World-writable files", s["world_writable_files"], "", "alert" if s["world_writable_files"] else "accent"),
             ("World-writable dirs", s["world_writable_dirs"], f"{s['ww_dirs_no_sticky']} without sticky bit",
              "alert" if s["ww_dirs_no_sticky"] else "accent")])
    kpi_row([("SUID files", s["suid"]), ("SGID files", s["sgid"]),
             ("High findings", sev["High"], "", "alert" if sev["High"] else "accent"),
             ("Critical findings", sev["Critical"], "", "alert" if sev["Critical"] else "accent")])
    st.caption(f"{r.root} · {r.status} · {r.host.get('distribution', '')} · "
               f"{'root' if r.host.get('privileged') else 'safe mode (no root)'} · {s['duration_sec']} s · "
               f"{s['errors']} unreadable location(s) · symbolic links not followed: {s['symlinks']:,}")

    c1, c2 = st.columns(2)
    with c1:
        pdist = r.permission_distribution.head(12)
        bar(pdist.assign(label=pdist["octal"] + "  " + pdist["symbolic"].fillna("")), "label", "total",
            "Permission distribution (files + directories)", horizontal=True)
    with c2:
        td = r.type_distribution
        donut(list(td), list(td.values()), "File type distribution")
    c3, c4 = st.columns(2)
    with c3:
        severity_chart(sev, "Risk severity distribution")
    with c4:
        ww = r.world_writable_files
        if ww.empty:
            st.markdown("<div class='panel'><b>World-writable file distribution</b><br><span class='muted'>No "
                        "world-writable files found.</span></div>", unsafe_allow_html=True)
        else:
            vc = ww["path"].map(lambda p: p.rsplit("/", 1)[0] or "/").value_counts().head(10)
            bar(pd.DataFrame({"directory": vc.index, "files": vc.values}), "directory", "files",
                "World-writable files by directory", horizontal=True, color="#fb923c")
    c5, c6 = st.columns(2)
    with c5:
        sp = r.special
        known = int(sp["known"].sum()) if not sp.empty else 0
        donut(["SUID (standard)", "SGID / other standard", "Not on standard list"],
              [int(((sp["special"].str.contains("SUID")) & sp["known"]).sum()) if not sp.empty else 0,
               int(((~sp["special"].str.contains("SUID")) & sp["known"]).sum()) if not sp.empty else 0,
               len(sp) - known], "SUID / SGID distribution", ["#3b82f6", "#22d3ee", "#fb923c"])
    with c6:
        bar(r.findings_by_directory(), "directory", "findings", "Findings by directory", horizontal=True,
            color="#a78bfa")
