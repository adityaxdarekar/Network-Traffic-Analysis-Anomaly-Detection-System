"""
Central configuration for the Linux File Permission Auditor.

The auditor is READ-ONLY: nothing in this project ever calls chmod, chown,
unlink or writes to scanned locations. Remediation advice is text only.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
EXPORT_DIR = OUTPUT_DIR / "exports"
DB_PATH = OUTPUT_DIR / "audit_history.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"
BASELINE_FILE = DATA_DIR / "permission_baselines.json"
KNOWN_SPECIAL_FILE = DATA_DIR / "known_special_files.json"

for _d in (OUTPUT_DIR, REPORT_DIR, EXPORT_DIR):
    _d.mkdir(parents=True, exist_ok=True)

APP_TITLE = "Linux File Permission Auditor"
APP_SUBTITLE = "Linux File Permission Auditor and Security Assessment System Using Python"
APP_VERSION = "1.0.0"

SEVERITY_ORDER = ["Informational", "Low", "Medium", "High", "Critical"]
SEVERITY_COLORS = {"Informational": "#94a3b8", "Low": "#38bdf8", "Medium": "#facc15", "High": "#fb923c",
                   "Critical": "#ef4444"}

# Virtual / special filesystems that are never scanned (they are not real files on disk)
DEFAULT_EXCLUSIONS = ["/proc", "/sys", "/dev", "/run"]

# Locations whose executables belong to the operating system (used by rules 4, 5 and 9)
SYSTEM_BIN_DIRS = ["/bin", "/sbin", "/usr/bin", "/usr/sbin", "/usr/local/bin", "/usr/local/sbin", "/usr/lib",
                   "/usr/libexec", "/lib", "/lib64", "/usr/lib64", "/usr/local/lib"]

# Startup and scheduled-task locations (rule 10)
STARTUP_PATHS = ["/etc/crontab", "/etc/cron.d", "/etc/cron.hourly", "/etc/cron.daily", "/etc/cron.weekly",
                 "/etc/cron.monthly", "/var/spool/cron", "/etc/anacrontab", "/etc/systemd/system",
                 "/lib/systemd/system", "/usr/lib/systemd/system", "/etc/init.d", "/etc/rc.local", "/etc/profile",
                 "/etc/profile.d", "/etc/bash.bashrc", "/etc/environment", "/etc/xdg/autostart"]

# World-writable directories that are normal when the sticky bit is set
EXPECTED_STICKY_DIRS = ["/tmp", "/var/tmp", "/dev/shm", "/run/lock", "/var/lock", "/var/crash",
                        "/var/lib/php/sessions", "/var/metrics"]

# Sensitive file name patterns (rule 1 and rule 6): private keys, credentials, shell start-up files
SENSITIVE_NAME_PATTERNS = ["id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "*.pem", "*.key", "*.p12", "*.pfx",
                           "*.conf", "*.cfg", "*.ini", "*.env",
                           "authorized_keys", ".bashrc", ".bash_profile", ".profile", ".netrc", ".pgpass",
                           "*.kdbx", "credentials", ".git-credentials", "shadow*", "gshadow*", "passwd*",
                           "sudoers*"]
# Private keys only (".pem" is NOT included: most .pem files are public certificates)
PRIVATE_KEY_PATTERNS = ["id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "*.key", "*.p12", "*.pfx", "ssh_host_*_key"]

RULE_NAMES = {
    "R1": "World-Writable Sensitive File",
    "R2": "World-Writable Executable",
    "R3": "World-Writable Directory Without Sticky Bit",
    "R4": "SUID File Review",
    "R5": "SGID File Review",
    "R6": "Excessively Permissive File",
    "R7": "Sensitive Configuration Permissions",
    "R8": "Unexpected Ownership",
    "R9": "Writable System Executable",
    "R10": "Writable Startup / Scheduled Task File",
}

DEFAULT_SETTINGS = {
    "scan": {
        "path": "/etc",
        "recursive": True,
        "one_filesystem": True,       # do not cross into other mounted filesystems
        "follow_symlinks": False,     # never followed by default (see README)
        "exclusions": list(DEFAULT_EXCLUSIONS),
        "exclude_patterns": [],       # file-name patterns, e.g. "*.log"
        "max_entries": 300_000,       # protects memory on very large trees
        "max_depth": 64,
    },
    "rules_enabled": {r: True for r in RULE_NAMES},
    # Optional severity overrides per rule (e.g. {"R4": "Low"}); empty = rule defaults
    "severity_overrides": {},
    # Ownership expectations
    "regular_user_uid_min": 1000,     # UIDs >= this are normal user accounts (from /etc/login.defs UID_MIN)
    "trusted_system_owners": ["root"],
    "trusted_system_groups": ["root", "shadow", "adm", "staff", "utmp", "tty", "mail", "crontab", "messagebus",
                              "ssh", "_ssh", "plocate", "mlocate", "systemd-journal", "polkitd", "lp", "ssl-cert"],
    "dashboard": {"mask_hostname": True, "table_rows": 2000},
}


def default_settings() -> dict:
    return copy.deepcopy(DEFAULT_SETTINGS)


def load_settings(path: Path | None = None) -> dict:
    s = default_settings()
    path = path or SETTINGS_FILE
    try:
        if path.exists():
            stored = json.loads(path.read_text(encoding="utf-8"))
            for k, v in stored.items():
                if isinstance(v, dict) and isinstance(s.get(k), dict):
                    s[k].update(v)
                elif k in s:
                    s[k] = v
    except (OSError, ValueError):
        pass
    return s


def save_settings(settings: dict, path: Path | None = None) -> None:
    (path or SETTINGS_FILE).write_text(json.dumps(settings, indent=2), encoding="utf-8")
