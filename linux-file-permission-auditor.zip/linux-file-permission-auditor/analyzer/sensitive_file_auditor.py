"""
Audit of sensitive system configuration files against configurable,
distribution-aware baseline POLICIES (data/permission_baselines.json).

How a file is judged:
    max_mode  - the most permissive acceptable mode. A stricter mode passes
                ("stricter than baseline"); every extra bit is a deviation.
    owner / group - acceptable owners and groups.

A deviation is reported for REVIEW. Distributions and organisations differ,
so nothing here is automatically called a vulnerability, and the observed
value and the expected policy are always shown side by side.

``root_prefix`` lets the tests audit a fake '/etc' inside a temporary
folder - the real system files are never touched (only lstat is used).
"""

from __future__ import annotations

import glob
import json
import os
import stat
from functools import lru_cache
from pathlib import Path

import config as C
from scanner.metadata_extractor import file_type, group_name, octal_to_symbolic, owner_name, short_octal


def read_os_release(path: str = "/etc/os-release") -> dict:
    info = {}
    try:
        for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" in line and not line.startswith("#"):
                k, _, v = line.partition("=")
                info[k.strip()] = v.strip().strip('"')
    except OSError:
        pass
    return info


@lru_cache(maxsize=4)
def load_baselines(path: str = str(C.BASELINE_FILE)) -> dict:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"profiles": {}, "default_profile": None}


def select_profile(os_info: dict | None = None, baselines: dict | None = None) -> tuple[str, dict]:
    """Pick the baseline profile for this distribution (ID / ID_LIKE from /etc/os-release)."""
    baselines = baselines or load_baselines()
    os_info = os_info if os_info is not None else read_os_release()
    ids = [os_info.get("ID", "").lower()] + os_info.get("ID_LIKE", "").lower().split()
    profiles = baselines.get("profiles", {})
    chosen = None
    for name, prof in profiles.items():
        if any(i and i in prof.get("match", []) for i in ids):
            chosen = name
            break
    chosen = chosen or baselines.get("default_profile") or next(iter(profiles), None)
    if chosen is None:
        return "none", {}
    files: dict = {}
    parent = profiles[chosen].get("inherit")
    if parent and parent in profiles:
        files.update(profiles[parent].get("files", {}))
    files.update(profiles[chosen].get("files", {}))
    return chosen, files


def _extra_bits(observed: int, max_mode: int) -> int:
    return observed & ~max_mode & 0o7777


def _bits_text(bits: int) -> str:
    names = []
    for bit, label in ((0o4000, "SUID"), (0o2000, "SGID"), (0o1000, "sticky"), (0o400, "owner read"),
                       (0o200, "owner write"), (0o100, "owner execute"), (0o40, "group read"), (0o20, "group write"),
                       (0o10, "group execute"), (0o4, "others read"), (0o2, "others write"), (0o1, "others execute")):
        if bits & bit:
            names.append(label)
    return ", ".join(names)


def audit_file(policy_path: str, real_path: str, policy: dict) -> dict:
    exp_mode = policy.get("max_mode", "644")
    row = {"file": policy_path if policy_path == real_path else real_path, "policy_path": policy_path,
           "exists": False, "type": "-", "observed_mode": "-", "observed_symbolic": "-",
           "expected_mode": f"≤ {exp_mode} ({octal_to_symbolic(exp_mode)})", "typical_mode": policy.get("typical", "-"),
           "observed_owner": "-", "observed_group": "-",
           "expected_owner": "/".join(policy.get("owner", ["root"])), "expected_group": "/".join(policy.get("group", ["root"])),
           "result": "", "issues": [], "extra_bits": 0, "mode": None, "uid": None, "gid": None,
           "others_write": False, "others_read": False, "group_write": False, "owner_ok": True, "group_ok": True}
    try:
        st = os.lstat(real_path)
    except FileNotFoundError:
        row["result"] = "Not present"
        row["issues"] = ["File does not exist on this system (normal for optional files such as /etc/rc.local)."]
        return row
    except PermissionError:
        row["result"] = "Not accessible"
        row["issues"] = ["Permission denied - run the audit with sudo to check this file."]
        return row
    mode = stat.S_IMODE(st.st_mode)
    ftype = file_type(st.st_mode)
    owner, group = owner_name(st.st_uid), group_name(st.st_gid)
    row.update(exists=True, type=ftype, observed_mode=short_octal(st.st_mode), observed_symbolic=stat.filemode(st.st_mode),
               observed_owner=owner or f"UID {st.st_uid}", observed_group=group or f"GID {st.st_gid}", mode=mode,
               uid=st.st_uid, gid=st.st_gid, others_write=bool(mode & 0o002), others_read=bool(mode & 0o004),
               group_write=bool(mode & 0o020))
    issues = []
    if ftype == "symlink":
        row["result"] = "Symbolic link (not followed)"
        issues.append(f"Points to {os.readlink(real_path)} - audit that file directly if needed.")
        row["issues"] = issues
        return row
    want_type = {"file": "file", "dir": "directory"}.get(policy.get("type", "file"), "file")
    if ftype != want_type:
        issues.append(f"Expected a {want_type}, found a {ftype}.")
    extra = _extra_bits(mode, int(exp_mode, 8))
    row["extra_bits"] = extra
    if extra:
        issues.append(f"Permissions are more permissive than the policy: extra {_bits_text(extra)}.")
    if owner not in policy.get("owner", ["root"]):
        row["owner_ok"] = False
        issues.append(f"Owner is {row['observed_owner']}, policy expects {row['expected_owner']}.")
    if group not in policy.get("group", ["root"]):
        row["group_ok"] = False
        issues.append(f"Group is {row['observed_group']}, policy expects {row['expected_group']}.")
    if issues:
        row["result"] = "Deviation - review"
    elif mode != int(exp_mode, 8):
        row["result"] = "OK (stricter than policy)"
    else:
        row["result"] = "OK"
    row["issues"] = issues
    return row


def audit_sensitive_files(root_prefix: str = "/", os_info: dict | None = None, policies: dict | None = None) -> dict:
    """Audit every policy entry. ``root_prefix`` is '/' for the real system or a test directory."""
    profile, files = (select_profile(os_info) if policies is None else ("custom", policies))
    rows = []
    for policy_path, policy in files.items():
        if policy_path.startswith("_"):
            continue
        real = os.path.join(root_prefix, policy_path.lstrip("/"))
        if any(ch in policy_path for ch in "*?["):
            matches = sorted(glob.glob(real))
            if not matches:
                row = audit_file(policy_path, real, policy)
                row["file"] = policy_path
                rows.append(row)
            for m in matches:
                row = audit_file(policy_path, m, policy)
                row["file"] = "/" + os.path.relpath(m, root_prefix) if root_prefix != "/" else m
                rows.append(row)
        else:
            row = audit_file(policy_path, real, policy)
            row["file"] = policy_path
            rows.append(row)
    return {"profile": profile, "rows": rows}
