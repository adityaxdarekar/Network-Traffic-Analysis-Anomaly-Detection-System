"""
SUID / SGID analysis.

Why they need review: a SUID program runs with the privileges of its OWNER
(usually root) no matter who starts it; SGID runs with its group's
privileges. A bug in such a program - or the ability to replace it - can let
an ordinary user gain those privileges. Many SUID programs are normal
(passwd must update /etc/shadow, sudo must become root), so nothing here is
labelled malicious: unusual location, unexpected owner, writability and
"not on the known list" are investigation indicators.
"""

from __future__ import annotations

import json
from functools import lru_cache

import pandas as pd

from config import KNOWN_SPECIAL_FILE, SYSTEM_BIN_DIRS


@lru_cache(maxsize=1)
def known_special() -> dict[str, frozenset[str]]:
    try:
        data = json.loads(KNOWN_SPECIAL_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    return {"suid": frozenset(data.get("suid", [])), "sgid": frozenset(data.get("sgid", []))}


def in_system_location(path: str) -> bool:
    return any(path == d or path.startswith(d.rstrip("/") + "/") for d in SYSTEM_BIN_DIRS)


def investigate(row, kind: str) -> tuple[list[str], str]:
    """Return (indicators, plain-English note) for one SUID or SGID file."""
    known = row["path"] in known_special()[kind]
    indicators = []
    if not known:
        indicators.append("not on the list of standard programs")
    if not in_system_location(row["path"]):
        indicators.append("outside the standard system program directories")
    if kind == "suid" and row["uid"] != 0:
        indicators.append(f"owned by {row['owner_display']} (not root) - runs with that user's privileges")
    if row["world_writable"] or row["group_writable"]:
        indicators.append("can be modified by other users")
    if not row["executable"]:
        indicators.append("special bit on a non-executable file (no effect, but unusual)")
    if known and not indicators:
        note = "Standard program that normally has this bit. Keep it updated; no action needed."
    elif known:
        note = "Standard program, but: " + "; ".join(indicators) + "."
    else:
        note = "Review: " + "; ".join(indicators) + ". Find which package owns it (dpkg -S <path>) and whether " \
               "the special bit is needed."
    return indicators, note


def special_files(df: pd.DataFrame) -> pd.DataFrame:
    """Equivalent of find -type f -perm -4000 / -perm -2000, with investigation notes."""
    cols = ["path", "name", "special", "octal", "symbolic", "owner_display", "group_display", "uid", "known",
            "system_location", "indicators", "note"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    sub = df[(df["type"] == "file") & (df["suid"] | df["sgid"])]
    rows = []
    for _, r in sub.iterrows():
        kinds = [k for k in ("suid", "sgid") if r[k]]
        all_ind, notes = [], []
        for k in kinds:
            ind, note = investigate(r, k)
            all_ind += [i for i in ind if i not in all_ind]
            notes.append(f"{k.upper()}: {note}")
        rows.append({
            "path": r["path"], "name": r["name"], "special": "+".join(k.upper() for k in kinds),
            "octal": r["octal"], "symbolic": r["symbolic"], "owner_display": r["owner_display"],
            "group_display": r["group_display"], "uid": r["uid"],
            "known": all(r["path"] in known_special()[k] for k in kinds),
            "system_location": in_system_location(r["path"]), "indicators": "; ".join(all_ind), "note": " ".join(notes),
        })
    return pd.DataFrame(rows, columns=cols).sort_values(["known", "path"]).reset_index(drop=True)


def sgid_directories(df: pd.DataFrame) -> pd.DataFrame:
    """SGID on directories is a normal way to share group ownership - listed for information only."""
    if df.empty:
        return df
    return df[(df["type"] == "directory") & df["sgid"]][["path", "octal", "owner_display", "group_display"]]
