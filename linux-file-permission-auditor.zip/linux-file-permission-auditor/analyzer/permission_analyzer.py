"""
Permission analysis: tables and statistics built from the scanned metadata.

World-writable means the "others" write bit (o+w, octal 0002) is set: ANY local
user can modify the file (or, for a directory, create/delete/rename entries
in it - unless the sticky bit restricts deletion to each file's owner).
"""

from __future__ import annotations

import pandas as pd

from config import EXPECTED_STICKY_DIRS

ENTRY_COLUMNS = ["path", "name", "parent", "type", "octal", "symbolic", "mode", "uid", "owner", "gid", "group",
                 "size", "mtime", "nlink", "depth", "world_writable", "group_writable", "world_readable",
                 "executable", "suid", "sgid", "sticky", "symlink_target", "broken_link"]


def entries_dataframe(entries: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame.from_records(entries, columns=ENTRY_COLUMNS) if entries else pd.DataFrame(columns=ENTRY_COLUMNS)
    if not df.empty:
        df["owner_display"] = df["owner"].fillna(df["uid"].astype(str).radd("UID "))
        df["group_display"] = df["group"].fillna(df["gid"].astype(str).radd("GID "))
    else:
        df["owner_display"] = pd.Series(dtype=str)
        df["group_display"] = pd.Series(dtype=str)
    return df


def permission_distribution(df: pd.DataFrame, top: int = 15) -> pd.DataFrame:
    """How many files and directories have each numeric permission (e.g. 644: 300 files)."""
    cols = ["octal", "symbolic", "files", "directories", "total"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    sub = df[df["type"].isin(["file", "directory"])]
    table = sub.pivot_table(index="octal", columns="type", values="path", aggfunc="count", fill_value=0)
    table = table.reindex(columns=["file", "directory"], fill_value=0).rename(columns={"file": "files",
                                                                                       "directory": "directories"})
    table["total"] = table["files"] + table["directories"]
    table = table.sort_values("total", ascending=False).head(top).reset_index()
    sym = sub.drop_duplicates("octal").set_index("octal")["symbolic"].str[1:]
    table["symbolic"] = table["octal"].map(sym)
    return table[cols]


def access_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """For regular files: how many grant read / write / execute to owner, group and others."""
    files = df[df["type"] == "file"]
    rows = []
    for who, shift in (("owner", 6), ("group", 3), ("others", 0)):
        bits = (files["mode"].astype(int) // (1 << shift)) % 8 if not files.empty else pd.Series(dtype=int)
        rows.append({"class": who, "read": int(((bits & 4) > 0).sum()), "write": int(((bits & 2) > 0).sum()),
                     "execute": int(((bits & 1) > 0).sum())})
    return pd.DataFrame(rows)


def type_distribution(df: pd.DataFrame) -> dict:
    return df["type"].value_counts().to_dict() if not df.empty else {}


def world_writable_files(df: pd.DataFrame) -> pd.DataFrame:
    """Equivalent of:  find DIR -type f -perm -0002"""
    cols = ["path", "name", "type", "octal", "symbolic", "owner_display", "group_display", "executable", "size",
            "mtime"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    return df[(df["type"] == "file") & df["world_writable"]][cols].sort_values("path").reset_index(drop=True)


def world_writable_other(df: pd.DataFrame) -> pd.DataFrame:
    """World-writable devices, FIFOs and sockets (often normal, e.g. /dev/null) - listed for completeness."""
    if df.empty:
        return df
    return df[~df["type"].isin(["file", "directory", "symlink"]) & df["world_writable"]].reset_index(drop=True)


def world_writable_dirs(df: pd.DataFrame) -> pd.DataFrame:
    """Equivalent of:  find DIR -type d -perm -0002 , with sticky-bit interpretation."""
    cols = ["path", "octal", "symbolic", "sticky", "sticky_status", "owner_display", "group_display", "assessment"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    d = df[(df["type"] == "directory") & df["world_writable"]].copy()
    if d.empty:
        return pd.DataFrame(columns=cols)

    def assess(row) -> str:
        if not row["sticky"]:
            return ("No sticky bit: any user can delete or rename other users' files here - "
                    "review and normally remove o+w or add the sticky bit.")
        if row["path"] in EXPECTED_STICKY_DIRS:
            return "Expected: shared temporary directory protected by the sticky bit (like /tmp)."
        return "Sticky bit set (users cannot delete each other's files); confirm the directory is meant to be shared."
    d["sticky_status"] = d["sticky"].map({True: "sticky bit set", False: "NO sticky bit"})
    d["assessment"] = d.apply(assess, axis=1)
    return d[cols].sort_values(["sticky", "path"]).reset_index(drop=True)


def summary(df: pd.DataFrame) -> dict:
    if df.empty:
        return {k: 0 for k in ("files", "directories", "symlinks", "world_writable_files", "world_writable_dirs",
                               "ww_dirs_no_sticky", "suid", "sgid", "broken_links", "executables")}
    files, dirs = df["type"] == "file", df["type"] == "directory"
    return {
        "files": int(files.sum()),
        "directories": int(dirs.sum()),
        "symlinks": int((df["type"] == "symlink").sum()),
        "world_writable_files": int((files & df["world_writable"]).sum()),
        "world_writable_dirs": int((dirs & df["world_writable"]).sum()),
        "ww_dirs_no_sticky": int((dirs & df["world_writable"] & ~df["sticky"]).sum()),
        "suid": int((files & df["suid"]).sum()),
        "sgid": int((files & df["sgid"]).sum()),
        "broken_links": int(df["broken_link"].sum()),
        "executables": int(df["executable"].sum()),
    }
