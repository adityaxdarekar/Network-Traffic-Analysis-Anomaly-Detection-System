"""
Ownership analysis: who owns what.

Notes for beginners:
    * UID 0 is root. System accounts normally have UIDs below UID_MIN (1000 on
      Debian/Ubuntu/Kali); regular human users have UIDs >= 1000.
    * An "unresolved" UID/GID has no matching entry in /etc/passwd or
      /etc/group - typical after a user was deleted or files were copied from
      another machine. Such "orphaned" files deserve a look because a new
      account that later receives that number would own them.
    * Root ownership is NOT required for every file; unusual ownership is an
      investigation lead, not proof of compromise.
"""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from analyzer.special_permission_analyzer import in_system_location


def uid_min(default: int = 1000) -> int:
    """Read UID_MIN from /etc/login.defs (falls back to 1000)."""
    try:
        for line in Path("/etc/login.defs").read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r"\s*UID_MIN\s+(\d+)", line)
            if m:
                return int(m.group(1))
    except OSError:
        pass
    return default


def owner_summary(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["uid", "username", "account_type", "files", "directories", "other_entries", "total_size"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    umin = uid_min()
    g = df.groupby("uid", dropna=False)
    out = pd.DataFrame({
        "username": g["owner"].first(),
        "files": g["type"].apply(lambda s: int((s == "file").sum())),
        "directories": g["type"].apply(lambda s: int((s == "directory").sum())),
        "other_entries": g["type"].apply(lambda s: int((~s.isin(["file", "directory"])).sum())),
        "total_size": g["size"].sum(),
    }).reset_index()

    def kind(row):
        if row["username"] is None or pd.isna(row["username"]):
            return "UNRESOLVED (no such account)"
        if row["uid"] == 0:
            return "root"
        return "regular user" if row["uid"] >= umin and row["uid"] != 65534 else "system account"
    out["account_type"] = out.apply(kind, axis=1)
    out["username"] = out["username"].fillna("(unresolved)")
    return out[cols].sort_values("files", ascending=False).reset_index(drop=True)


def group_summary(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["gid", "group", "files", "directories", "total_size"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    g = df.groupby("gid", dropna=False)
    out = pd.DataFrame({"group": g["group"].first(),
                        "files": g["type"].apply(lambda s: int((s == "file").sum())),
                        "directories": g["type"].apply(lambda s: int((s == "directory").sum())),
                        "total_size": g["size"].sum()}).reset_index()
    out["group"] = out["group"].fillna("(unresolved)")
    return out[cols].sort_values("files", ascending=False).reset_index(drop=True)


def orphaned(df: pd.DataFrame) -> pd.DataFrame:
    """Entries whose UID or GID does not resolve to an account/group."""
    if df.empty:
        return df
    o = df[df["owner"].isna() | df["group"].isna()]
    return o[["path", "type", "octal", "uid", "owner_display", "gid", "group_display"]].reset_index(drop=True)


def user_owned_in_system_locations(df: pd.DataFrame, regular_uid_min: int | None = None) -> pd.DataFrame:
    """Regular-user-owned entries inside system program directories (unusual - review)."""
    if df.empty:
        return df
    umin = regular_uid_min or uid_min()
    mask = (df["uid"] >= umin) & (df["uid"] != 65534) & df["path"].map(in_system_location)
    return df[mask][["path", "type", "octal", "owner_display", "group_display"]].reset_index(drop=True)


def analyze_ownership(df: pd.DataFrame, regular_uid_min: int | None = None) -> dict:
    return {
        "owners": owner_summary(df),
        "groups": group_summary(df),
        "orphaned": orphaned(df),
        "user_owned_system": user_owned_in_system_locations(df, regular_uid_min),
        "root_owned": int((df["uid"] == 0).sum()) if not df.empty else 0,
        "non_root_owned": int((df["uid"] != 0).sum()) if not df.empty else 0,
        "uid_min": regular_uid_min or uid_min(),
    }
