"""
Linux File Permission Auditor - Streamlit entry point.

    streamlit run app.py             # safe mode (your own user)
    sudo -E $(which streamlit) run app.py   # full audit with root privileges (still read-only)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import APP_TITLE, APP_VERSION  # noqa: E402
from dashboard import (about_page, findings, history, overview, ownership, permissions, reports_page,  # noqa: E402
                       sensitive_files, settings_page, special_permissions, start_audit, world_writable)
from dashboard.common import get_result, get_settings  # noqa: E402
from dashboard.theme import CSS  # noqa: E402

PAGES = {
    "Dashboard Overview": ("📊", overview.render),
    "Start New Audit": ("🔍", start_audit.render),
    "File Permissions": ("🗂️", permissions.render),
    "World-Writable Files": ("✏️", world_writable.render_files),
    "World-Writable Directories": ("📁", world_writable.render_dirs),
    "SUID/SGID Analysis": ("⚡", special_permissions.render),
    "Sensitive File Audit": ("🔐", sensitive_files.render),
    "Ownership Analysis": ("👤", ownership.render),
    "Security Findings": ("🛡️", findings.render),
    "Audit History": ("🕘", history.render),
    "Reports": ("📄", reports_page.render),
    "Settings": ("⚙️", settings_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def main() -> None:
    st.set_page_config(page_title="Permission Auditor", page_icon="🛡️", layout="wide",
                       initial_sidebar_state="expanded")
    st.markdown(CSS, unsafe_allow_html=True)
    get_settings()
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Start New Audit"
    with st.sidebar:
        st.markdown("## 🛡️ Permission Auditor")
        st.caption(f"{APP_TITLE} · v{APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        r = get_result()
        if r is not None:
            st.markdown(f"**Loaded audit:** `{r.root}`")
            st.caption(f"{r.summary['files']:,} files · {r.summary['findings']} findings")
        else:
            st.caption("No audit loaded.")
        st.caption(("🔓 running as root" if os.geteuid() == 0 else "🔒 safe mode (no root)") +
                   " · read-only - nothing is ever modified")
    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException") for c in type(exc).__mro__):
            raise
        st.error(f"Something went wrong on this page: {exc.__class__.__name__}: {exc}")
        st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
