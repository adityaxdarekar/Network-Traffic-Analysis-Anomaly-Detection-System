"""
Audit orchestration:

    validate path → scan (read-only) → permission / special-bit / ownership
    analysis → sensitive-file baseline audit → risk rules → AuditResult

``AuditJob`` runs an audit in a background thread so the dashboard can show
progress and offer a Stop button (stopping simply ends the read-only walk;
nothing needs to be undone).
"""

from __future__ import annotations

import getpass
import hashlib
import os
import platform
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd

import config as C
from analyzer import permission_analyzer as pa
from analyzer.ownership_analyzer import analyze_ownership
from analyzer.sensitive_file_auditor import audit_sensitive_files, read_os_release
from analyzer.special_permission_analyzer import sgid_directories, special_files
from detection.detection_rules import RuleContext
from detection.risk_engine import run_rules, severity_counts
from scanner.filesystem_scanner import FilesystemScanner, ScanOptions, ScanResult


@dataclass
class AuditResult:
    audit_id: str
    started_at: str
    finished_at: str
    options: dict
    host: dict
    scan: ScanResult
    entries: pd.DataFrame
    summary: dict
    permission_distribution: pd.DataFrame
    access_matrix: pd.DataFrame
    type_distribution: dict
    world_writable_files: pd.DataFrame
    world_writable_dirs: pd.DataFrame
    special: pd.DataFrame
    sgid_dirs: pd.DataFrame
    ownership: dict
    sensitive_profile: str
    sensitive: pd.DataFrame
    findings: pd.DataFrame
    severity_counts: dict
    rule_errors: list[str] = field(default_factory=list)

    @property
    def root(self) -> str:
        return self.scan.root

    @property
    def status(self) -> str:
        if self.scan.stopped:
            return "stopped (partial)"
        if self.scan.limit_reached:
            return "entry limit reached (partial)"
        return "completed"

    def findings_by_directory(self, depth: int = 2) -> pd.DataFrame:
        if self.findings.empty:
            return pd.DataFrame(columns=["directory", "findings"])
        dirs = self.findings["path"].map(lambda p: "/" + "/".join(p.strip("/").split("/")[:depth]))
        vc = dirs.value_counts()
        return pd.DataFrame({"directory": vc.index, "findings": vc.values})


def host_info(mask_hostname: bool = True) -> dict:
    """Privacy-conscious host description (hostname hashed by default; no IP addresses collected)."""
    osr = read_os_release()
    name = socket.gethostname()
    return {
        "distribution": osr.get("PRETTY_NAME") or platform.platform(),
        "distribution_id": osr.get("ID", ""),
        "kernel": platform.release(),
        "architecture": platform.machine(),
        "hostname": ("host-" + hashlib.sha256(name.encode()).hexdigest()[:8]) if mask_hostname else name,
        "user": getpass.getuser(),
        "privileged": os.geteuid() == 0,
    }


def run_audit(options: ScanOptions, settings: dict | None = None, progress=None, stop_event=None,
              root_prefix: str = "/") -> AuditResult:
    """Run a complete read-only audit and return the result."""
    settings = settings or C.load_settings()
    started = datetime.now()
    scan = FilesystemScanner(options, progress, stop_event).scan()
    df = pa.entries_dataframe(scan.entries)
    special = special_files(df)
    ownership = analyze_ownership(df, settings.get("regular_user_uid_min"))
    sens = audit_sensitive_files(root_prefix)
    sens_rows = sens["rows"]
    handled = {r["file"] for r in sens_rows if r["exists"]}
    ctx = RuleContext(df=df, special=special, sensitive_rows=sens_rows, settings=settings,
                      uid_min=ownership["uid_min"], handled_paths=handled)
    findings, errors = run_rules(ctx)
    sens_df = pd.DataFrame(sens_rows)
    if not sens_df.empty:
        sens_df["issues"] = sens_df["issues"].map(lambda x: " ".join(x))
    summary = pa.summary(df)
    summary.update(errors=len(scan.errors), skipped_mounts=len(scan.skipped_mounts), duration_sec=scan.duration_sec,
                   total_entries=len(df), findings=len(findings), orphaned=len(ownership["orphaned"]))
    return AuditResult(
        audit_id=started.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6],
        started_at=started.strftime("%Y-%m-%d %H:%M:%S"), finished_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        options=vars(options).copy(), host=host_info(settings.get("dashboard", {}).get("mask_hostname", True)),
        scan=scan, entries=df, summary=summary, permission_distribution=pa.permission_distribution(df),
        access_matrix=pa.access_matrix(df), type_distribution=pa.type_distribution(df),
        world_writable_files=pa.world_writable_files(df), world_writable_dirs=pa.world_writable_dirs(df),
        special=special, sgid_dirs=sgid_directories(df), ownership=ownership, sensitive_profile=sens["profile"],
        sensitive=sens_df, findings=findings, severity_counts=severity_counts(findings), rule_errors=errors)


def options_from_settings(path: str, settings: dict, **overrides) -> ScanOptions:
    s = dict(settings.get("scan", {}))
    s.update(overrides)
    return ScanOptions(path=path, recursive=s.get("recursive", True), one_filesystem=s.get("one_filesystem", True),
                       follow_symlinks=False, exclusions=list(s.get("exclusions", C.DEFAULT_EXCLUSIONS)),
                       exclude_patterns=list(s.get("exclude_patterns", [])),
                       max_entries=int(s.get("max_entries", 300_000)), max_depth=int(s.get("max_depth", 64)))


class AuditJob:
    """Background audit with live progress for the dashboard."""

    def __init__(self, options: ScanOptions, settings: dict | None = None):
        self.options = options
        self.settings = settings
        self.stop_event = threading.Event()
        self.state = "pending"
        self.files = self.directories = 0
        self.current = ""
        self.result: AuditResult | None = None
        self.error: str | None = None
        self.started = self.finished = None
        self._thread: threading.Thread | None = None

    def _progress(self, files: int, dirs: int, current: str) -> None:
        self.files, self.directories, self.current = files, dirs, current

    def _run(self) -> None:
        try:
            self.result = run_audit(self.options, self.settings, self._progress, self.stop_event)
            self.state = "stopped" if self.result.scan.stopped else "completed"
        except Exception as exc:  # noqa: BLE001 - reported in the UI
            self.error = f"{exc.__class__.__name__}: {exc}" if not isinstance(exc, ValueError) else str(exc)
            self.state = "failed"
        self.finished = time.time()

    def start(self) -> "AuditJob":
        self.started = time.time()
        self.state = "running"
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def stop(self) -> None:
        self.stop_event.set()

    def wait(self, timeout: float | None = None) -> "AuditJob":
        if self._thread:
            self._thread.join(timeout)
        return self

    def is_running(self) -> bool:
        return self.state == "running"

    def status(self) -> dict:
        end = self.finished or time.time()
        return {"state": self.state, "files": self.files, "directories": self.directories, "current": self.current,
                "elapsed": round(end - self.started, 1) if self.started else 0.0, "error": self.error}
