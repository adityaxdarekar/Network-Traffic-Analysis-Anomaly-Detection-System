"""
Read-only, iterative filesystem scanner.

Safety and robustness:
    * Uses os.scandir + lstat: symbolic links are recorded but NEVER followed
      (following them could escape the chosen directory or loop forever).
    * Does not cross into other mounted filesystems by default (like find -xdev).
    * Skips virtual filesystems (/proc, /sys, /dev, /run) and user exclusions.
    * Permission-denied directories, files that vanish during the scan and
      broken symlinks are recorded as scan notes - the scan never crashes.
    * Never opens, modifies or deletes anything.
"""

from __future__ import annotations

import fnmatch
import os
import stat
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from scanner.metadata_extractor import extract

ProgressCallback = Callable[[int, int, str], None]   # files, directories, current directory


class ScanPathError(ValueError):
    """Raised for an invalid or disallowed scan path."""


@dataclass
class ScanOptions:
    path: str
    recursive: bool = True
    one_filesystem: bool = True
    follow_symlinks: bool = False
    exclusions: list[str] = field(default_factory=lambda: ["/proc", "/sys", "/dev", "/run"])
    exclude_patterns: list[str] = field(default_factory=list)
    max_entries: int = 300_000
    max_depth: int = 64


@dataclass
class ScanResult:
    root: str
    entries: list[dict]
    errors: list[dict]
    files: int = 0
    directories: int = 0
    symlinks: int = 0
    others: int = 0
    skipped_mounts: list[str] = field(default_factory=list)
    skipped_excluded: list[str] = field(default_factory=list)
    stopped: bool = False
    limit_reached: bool = False
    duration_sec: float = 0.0
    privileged: bool = False


def _is_under(path: str, prefix: str) -> bool:
    prefix = prefix.rstrip("/") or "/"
    return path == prefix or path.startswith(prefix + "/") or prefix == "/"


def validate_scan_path(raw: str, exclusions: list[str] | None = None) -> str:
    """Return a normalised absolute directory path or raise ScanPathError."""
    if raw is None or not str(raw).strip():
        raise ScanPathError("Please enter a directory to scan, e.g. /etc")
    text = str(raw).strip()
    if "\x00" in text:
        raise ScanPathError("Invalid characters in path.")
    p = Path(os.path.expanduser(text))
    if not p.is_absolute():
        raise ScanPathError("Please use an absolute path starting with '/', e.g. /etc or /home/kali")
    norm = os.path.normpath(str(p))
    if not os.path.lexists(norm):
        raise ScanPathError(f"Path does not exist: {norm}")
    if os.path.islink(norm):
        raise ScanPathError(f"{norm} is a symbolic link. Scan its real location instead "
                            f"({os.path.realpath(norm)}) - links are not followed.")
    if not os.path.isdir(norm):
        raise ScanPathError(f"{norm} is not a directory.")
    for ex in exclusions or []:
        if ex and ex != "/" and _is_under(norm, ex):
            raise ScanPathError(f"{norm} is inside the excluded location {ex} (virtual filesystem or exclusion).")
    return norm


class FilesystemScanner:
    def __init__(self, options: ScanOptions, progress: ProgressCallback | None = None,
                 stop_event: threading.Event | None = None):
        self.options = options
        self.progress = progress
        self.stop_event = stop_event or threading.Event()

    def _excluded(self, path: str, name: str) -> bool:
        if any(ex and ex != "/" and _is_under(path, ex) for ex in self.options.exclusions):
            return True
        return any(fnmatch.fnmatch(name, pat) for pat in self.options.exclude_patterns)

    def scan(self) -> ScanResult:
        opts = self.options
        root = validate_scan_path(opts.path, opts.exclusions)
        start = time.perf_counter()
        result = ScanResult(root=root, entries=[], errors=[], privileged=os.geteuid() == 0)
        try:
            root_st = os.lstat(root)
        except OSError as exc:
            raise ScanPathError(f"Cannot read {root}: {exc.strerror}") from exc
        root_dev = root_st.st_dev
        rec = extract(root, root_st, 0)
        result.entries.append(rec)
        result.directories += 1

        stack: list[tuple[str, int]] = [(root, 0)]
        last_report = 0.0
        while stack:
            if self.stop_event.is_set():
                result.stopped = True
                break
            directory, depth = stack.pop()
            try:
                it = os.scandir(directory)
            except PermissionError:
                result.errors.append({"path": directory, "error": "Permission denied",
                                      "hint": "Run the audit with sudo to include this directory."})
                continue
            except FileNotFoundError:
                result.errors.append({"path": directory, "error": "Directory disappeared during the scan"})
                continue
            except OSError as exc:
                result.errors.append({"path": directory, "error": exc.strerror or str(exc)})
                continue
            with it:
                subdirs = []
                while True:
                    try:
                        entry = next(it)
                    except StopIteration:
                        break
                    except OSError as exc:       # e.g. I/O error while listing
                        result.errors.append({"path": directory, "error": exc.strerror or str(exc)})
                        break
                    path = entry.path
                    if self._excluded(path, entry.name):
                        result.skipped_excluded.append(path)
                        continue
                    try:
                        st = entry.stat(follow_symlinks=False)          # lstat: never follow links
                    except FileNotFoundError:
                        result.errors.append({"path": path, "error": "File disappeared during the scan"})
                        continue
                    except PermissionError:
                        result.errors.append({"path": path, "error": "Permission denied (metadata)"})
                        continue
                    except OSError as exc:
                        result.errors.append({"path": path, "error": exc.strerror or str(exc)})
                        continue
                    rec = extract(path, st, depth + 1)
                    if stat.S_ISLNK(st.st_mode):
                        result.symlinks += 1
                        try:
                            rec["symlink_target"] = os.readlink(path)
                        except OSError:
                            rec["symlink_target"] = None
                        rec["broken_link"] = not os.path.exists(path)     # exists() follows the link
                    elif stat.S_ISDIR(st.st_mode):
                        result.directories += 1
                        if opts.recursive and depth + 1 <= opts.max_depth:
                            if opts.one_filesystem and st.st_dev != root_dev:
                                result.skipped_mounts.append(path)     # another filesystem is mounted here
                            else:
                                subdirs.append(path)
                    elif stat.S_ISREG(st.st_mode):
                        result.files += 1
                    else:
                        result.others += 1
                    result.entries.append(rec)
                    if len(result.entries) >= opts.max_entries:
                        result.limit_reached = True
                        stack.clear()
                        subdirs = []
                        break
                # push in reverse so directories are visited in alphabetical order
                for sd in sorted(subdirs, reverse=True):
                    stack.append((sd, depth + 1))
            now = time.perf_counter()
            if self.progress and now - last_report > 0.2:
                self.progress(result.files, result.directories, directory)
                last_report = now
        result.duration_sec = round(time.perf_counter() - start, 3)
        if self.progress:
            self.progress(result.files, result.directories, "done")
        return result
