"""
Turn an ``os.stat_result`` into readable permission metadata.

Linux permission refresher (used throughout the project):

    -rwxr-xr--   =  type + owner (rwx) + group (r-x) + others (r--)
    numeric 754  =  owner 7 (4 read + 2 write + 1 execute), group 5 (4+1), others 4

    Special bits (the leading digit of a 4-digit mode):
        4000 SUID   - a program runs with the permissions of its OWNER
        2000 SGID   - a program runs with its GROUP's permissions; on a directory,
                      new files inherit the directory's group
        1000 sticky - on a directory, only a file's owner may delete/rename it (e.g. /tmp)

Only metadata is read (``lstat``) - file contents are never opened.
"""

from __future__ import annotations

import grp
import os
import pwd
import stat
from datetime import datetime
from functools import lru_cache

FILE_TYPES = [
    (stat.S_ISREG, "file"), (stat.S_ISDIR, "directory"), (stat.S_ISLNK, "symlink"), (stat.S_ISCHR, "char device"),
    (stat.S_ISBLK, "block device"), (stat.S_ISFIFO, "fifo"), (stat.S_ISSOCK, "socket"),
]


def file_type(mode: int) -> str:
    for test, name in FILE_TYPES:
        if test(mode):
            return name
    return "unknown"


def octal_mode(mode: int) -> str:
    """Permission bits incl. special bits, e.g. '0644', '4755', '1777'."""
    return f"{stat.S_IMODE(mode):04o}"


def short_octal(mode: int) -> str:
    """'644' for ordinary modes, '4755' when special bits are present."""
    m = stat.S_IMODE(mode)
    return f"{m:04o}" if m & 0o7000 else f"{m:03o}"


def symbolic_mode(mode: int) -> str:
    """'-rw-r--r--', 'drwxrwxrwt', '-rwsr-xr-x' (same as ls -l)."""
    return stat.filemode(mode)


def octal_to_symbolic(octal: str) -> str:
    """'755' -> 'rwxr-xr-x' (without the type character); special bits shown like ls."""
    return stat.filemode(int(octal, 8) | stat.S_IFREG)[1:]


def explain_permissions(mode: int) -> str:
    """Plain-English description used in the dashboard and report."""
    m = stat.S_IMODE(mode)

    def who(shift: int) -> str:
        bits = (m >> shift) & 7
        words = [w for w, b in (("read", 4), ("write", 2), ("execute", 1)) if bits & b]
        return ", ".join(words) if words else "no access"
    parts = [f"owner: {who(6)}", f"group: {who(3)}", f"others: {who(0)}"]
    if m & stat.S_ISUID:
        parts.append("SUID set")
    if m & stat.S_ISGID:
        parts.append("SGID set")
    if m & stat.S_ISVTX:
        parts.append("sticky bit set")
    return "; ".join(parts)


@lru_cache(maxsize=4096)
def owner_name(uid: int) -> str | None:
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return None          # unresolved UID: no account with this number exists


@lru_cache(maxsize=4096)
def group_name(gid: int) -> str | None:
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return None


def extract(path: str, st: os.stat_result, depth: int = 0) -> dict:
    """Metadata record for one filesystem entry (no file contents)."""
    mode = st.st_mode
    perm = stat.S_IMODE(mode)
    ftype = file_type(mode)
    rec = {
        "path": path,
        "name": os.path.basename(path) or path,
        "parent": os.path.dirname(path),
        "type": ftype,
        "mode": perm,
        "octal": short_octal(mode),
        "symbolic": symbolic_mode(mode),
        "uid": st.st_uid,
        "owner": owner_name(st.st_uid),
        "gid": st.st_gid,
        "group": group_name(st.st_gid),
        "size": st.st_size,
        "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        "nlink": st.st_nlink,
        "depth": depth,
        "world_writable": bool(perm & stat.S_IWOTH),
        "group_writable": bool(perm & stat.S_IWGRP),
        "world_readable": bool(perm & stat.S_IROTH),
        "executable": ftype == "file" and bool(perm & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)),
        "suid": bool(perm & stat.S_ISUID),
        "sgid": bool(perm & stat.S_ISGID),
        "sticky": bool(perm & stat.S_ISVTX),
        "symlink_target": None,
        "broken_link": False,
    }
    return rec
