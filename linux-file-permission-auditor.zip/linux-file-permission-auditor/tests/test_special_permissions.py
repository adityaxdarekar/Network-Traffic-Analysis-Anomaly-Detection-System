"""SUID / SGID detection (rules R4, R5) on temporary files."""

from __future__ import annotations

import os

from analyzer.special_permission_analyzer import in_system_location, known_special, sgid_directories, special_files
from conftest import make
from detection.risk_engine import run_rules
from test_permission_analyzer import ctx_for, df_of


def test_suid_and_sgid_detected(tmp_path):
    make(tmp_path / "s", 0o4755)
    make(tmp_path / "g", 0o2755)
    make(tmp_path / "both", 0o6755)
    make(tmp_path / "plain", 0o755)
    sp = special_files(df_of(tmp_path)).set_index("name")
    assert sp.loc["s", "special"] == "SUID" and sp.loc["g", "special"] == "SGID"
    assert sp.loc["both", "special"] == "SUID+SGID" and "plain" not in sp.index
    assert sp.loc["s", "octal"] == "4755" and sp.loc["s", "symbolic"] == "-rwsr-xr-x"


def test_r4_r5_outside_system_dirs_need_review(tmp_path):
    make(tmp_path / "helper", 0o4755)
    make(tmp_path / "reporter", 0o2755)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    r4 = fd[fd["rule"] == "R4"]
    r5 = fd[fd["rule"] == "R5"]
    assert len(r4) == 1 and r4.iloc[0]["severity"] in ("High", "Medium")
    assert len(r5) == 1 and r5.iloc[0]["severity"] in ("Medium", "High", "Low")


def test_writable_suid_is_critical(tmp_path):
    make(tmp_path / "danger", 0o4777)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    assert "Critical" in set(fd[fd["rule"] == "R4"]["severity"])


def test_known_suid_programs_are_informational():
    """Standard programs such as /usr/bin/passwd are listed for review, not reported as risks."""
    known = known_special()
    assert "/usr/bin/passwd" in known["suid"] and "/usr/bin/sudo" in known["suid"]
    if os.path.exists("/usr/bin/passwd") and os.lstat("/usr/bin/passwd").st_mode & 0o4000:
        from analyzer.permission_analyzer import entries_dataframe
        from scanner.filesystem_scanner import FilesystemScanner, ScanOptions
        df = entries_dataframe(FilesystemScanner(ScanOptions(path="/usr/bin", recursive=False)).scan().entries)
        fd, _ = run_rules(ctx_for(df))
        row = fd[(fd["rule"] == "R4") & (fd["path"] == "/usr/bin/passwd")]
        assert row.empty or row.iloc[0]["severity"] == "Informational"


def test_system_location():
    assert in_system_location("/usr/bin/x") and in_system_location("/sbin/y")
    assert not in_system_location("/home/user/x") and not in_system_location("/tmp/x")


def test_sgid_directory(tmp_path):
    d = tmp_path / "team"
    d.mkdir()
    os.chmod(d, 0o2775)
    assert list(sgid_directories(df_of(tmp_path))["path"]) == [str(d)]
