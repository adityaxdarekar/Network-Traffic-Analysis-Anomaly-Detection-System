"""World-writable files and directories, sticky bit, rules R1-R3."""

from __future__ import annotations

import os

from analyzer import permission_analyzer as pa
from conftest import make, scan
from test_permission_analyzer import ctx_for, df_of
from detection.risk_engine import run_rules


def test_world_writable_file_detected(tmp_path):
    make(tmp_path / "open.txt", 0o666)
    make(tmp_path / "closed.txt", 0o644)
    ww = pa.world_writable_files(df_of(tmp_path))
    assert list(ww["name"]) == ["open.txt"]


def test_group_writable_is_not_world_writable(tmp_path):
    make(tmp_path / "g.txt", 0o664)
    assert pa.world_writable_files(df_of(tmp_path)).empty


def test_world_writable_dirs_and_sticky_bit(tmp_path):
    a = tmp_path / "shared"
    b = tmp_path / "tmp_like"
    a.mkdir(); b.mkdir()
    os.chmod(a, 0o777)
    os.chmod(b, 0o1777)
    wd = pa.world_writable_dirs(df_of(tmp_path)).set_index("path")
    assert not wd.loc[str(a), "sticky"] and wd.loc[str(b), "sticky"]
    assert wd.loc[str(a), "sticky_status"] == "NO sticky bit"
    assert pa.summary(df_of(tmp_path))["ww_dirs_no_sticky"] == 1


def test_r3_only_flags_directory_without_sticky(tmp_path):
    for name, mode in (("shared", 0o777), ("tmp_like", 0o1777)):
        (tmp_path / name).mkdir()
        os.chmod(tmp_path / name, mode)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    r3 = fd[fd["rule"] == "R3"]
    assert list(r3["path"]) == [str(tmp_path / "shared")]
    assert r3.iloc[0]["severity"] in ("High", "Critical", "Medium")


def test_real_tmp_is_not_critical():
    """/tmp is world-writable WITH the sticky bit on standard systems - it must not be reported as a risk."""
    df = pa.entries_dataframe(scan("/tmp", recursive=False).entries)
    root = df[df["path"] == "/tmp"].iloc[0]
    if root["sticky"]:
        fd, _ = run_rules(ctx_for(df))
        assert "/tmp" not in set(fd[fd["severity"] == "Critical"]["path"])
        assert "/tmp" not in set(fd[fd["rule"] == "R3"]["path"])


def test_r1_world_writable_config(tmp_path):
    make(tmp_path / "etc" / "app.conf", 0o666)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    r1 = fd[fd["rule"] == "R1"]
    assert len(r1) == 1 and r1.iloc[0]["severity"] in ("High", "Critical")


def test_r2_world_writable_executable(tmp_path):
    make(tmp_path / "backup.sh", 0o777)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    assert list(fd[fd["rule"] == "R2"]["severity"]) == ["High"]


def test_lab_expected_findings(lab_audit, lab):
    """The demo lab produces exactly the indicators documented in sample_files/create_samples.py."""
    fd = lab_audit.findings
    got = {(r.rule, os.path.relpath(r.path, lab)) for r in fd.itertuples()}
    expected = {("R1", "etc/app.conf"), ("R1", "home/student/.bashrc"), ("R2", "home/student/backup.sh"),
                ("R3", "shared"), ("R4", "opt/tools/helper"), ("R5", "opt/tools/reporter"),
                ("R6", "home/student/.ssh/id_rsa"), ("R6", "home/student/notes.txt"), ("R6", "data/secret.key")}
    assert expected <= got, expected - got
    assert ("R3", "public_tmp") not in got           # sticky bit -> acceptable
    assert not any(p.endswith("id_rsa.pub") for _, p in got)
