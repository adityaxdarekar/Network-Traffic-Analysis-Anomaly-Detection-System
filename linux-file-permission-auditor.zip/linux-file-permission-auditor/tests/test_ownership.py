"""Ownership analysis, orphaned files, sensitive baselines (fake /etc in a temp dir)."""

from __future__ import annotations

import os

import pytest

from analyzer.ownership_analyzer import analyze_ownership, orphaned
from analyzer.sensitive_file_auditor import audit_file, audit_sensitive_files, select_profile
from conftest import IS_ROOT, make
from detection.risk_engine import run_rules
from test_permission_analyzer import ctx_for, df_of


def unused_id(start=54321):
    import grp
    import pwd
    i = start
    while True:
        try:
            pwd.getpwuid(i)
        except KeyError:
            try:
                grp.getgrgid(i)
            except KeyError:
                return i
        i += 1


def test_owner_and_group_summary(tmp_path):
    make(tmp_path / "a", 0o644)
    o = analyze_ownership(df_of(tmp_path), 1000)
    assert o["owners"].iloc[0]["uid"] == os.getuid() and o["owners"]["files"].sum() >= 1
    assert "username" in o["owners"] and "group" in o["groups"]


@pytest.mark.skipif(not IS_ROOT, reason="changing a file's owner to an unused UID requires root")
def test_orphaned_file_detected(tmp_path):
    f = make(tmp_path / "orphan.txt", 0o644)
    uid = unused_id()
    os.chown(f, uid, uid)                       # temp file only
    df = df_of(tmp_path)
    orph = orphaned(df)
    assert list(orph["path"]) == [str(f)]
    assert df[df["path"] == str(f)].iloc[0]["owner_display"] == f"UID {uid}"
    fd, _ = run_rules(ctx_for(df))
    assert str(f) in set(fd[fd["rule"] == "R8"]["path"])


def test_profile_selection():
    assert select_profile({"ID": "kali", "ID_LIKE": "debian"})[0] == "debian"
    assert select_profile({"ID": "ubuntu", "ID_LIKE": "debian"})[0] == "debian"
    name, files = select_profile({"ID": "fedora", "ID_LIKE": "rhel centos fedora"})
    assert name == "rhel" and "/etc/passwd" in files          # inherited from debian
    assert select_profile({"ID": "unknownos"})[0] == "debian"  # default profile


def test_baseline_ok_stricter_and_deviation(tmp_path):
    policy = {"max_mode": "644", "typical": "644", "owner": ["root"], "group": ["root"], "type": "file"}
    ok = make(tmp_path / "ok", 0o644)
    strict = make(tmp_path / "strict", 0o600)
    bad = make(tmp_path / "bad", 0o666)
    owner_ok = os.getuid() == 0
    r_ok = audit_file("/etc/passwd", str(ok), policy)
    r_strict = audit_file("/etc/passwd", str(strict), policy)
    r_bad = audit_file("/etc/passwd", str(bad), policy)
    if owner_ok:
        assert r_ok["result"] == "OK" and r_strict["result"] == "OK (stricter than policy)"
    assert r_bad["result"] == "Deviation - review" and r_bad["others_write"] and r_bad["extra_bits"]
    assert r_bad["observed_mode"] == "666" and r_bad["expected_mode"].startswith("≤ 644")


def test_missing_and_symlinked_sensitive_files(tmp_path):
    policy = {"max_mode": "600", "typical": "600", "owner": ["root"], "group": ["root"], "type": "file"}
    assert audit_file("/etc/x", str(tmp_path / "nope"), policy)["result"] == "Not present"
    os.symlink("/etc/hostname", tmp_path / "link")
    assert audit_file("/etc/x", str(tmp_path / "link"), policy)["result"] == "Symbolic link (not followed)"


def test_fake_etc_tree(tmp_path):
    """audit_sensitive_files with root_prefix audits a fake /etc - the real one is never touched."""
    etc = tmp_path / "etc"
    make(etc / "passwd", 0o644)
    make(etc / "shadow", 0o644)             # deviation: others can read
    make(etc / "sudoers", 0o666)            # deviation: others can write
    res = audit_sensitive_files(str(tmp_path), os_info={"ID": "ubuntu", "ID_LIKE": "debian"})
    rows = {r["file"]: r for r in res["rows"]}
    assert res["profile"] == "debian"
    assert rows["/etc/shadow"]["result"] == "Deviation - review"
    assert rows["/etc/sudoers"]["others_write"]
    assert rows["/etc/gshadow"]["result"] == "Not present"
    fd, _ = run_rules(ctx_for(df_of(tmp_path), sensitive_rows=res["rows"]))
    r7 = fd[fd["rule"] == "R7"].set_index("path")
    assert r7.loc["/etc/sudoers", "severity"] == "Critical" and r7.loc["/etc/shadow", "severity"] == "High"
    assert "/etc/passwd" not in r7.index


def test_real_system_sensitive_audit_is_read_only():
    import stat as st_mod
    before = {p: os.lstat(p).st_mode for p in ("/etc/passwd", "/etc/group") if os.path.exists(p)}
    audit_sensitive_files("/")
    assert before == {p: os.lstat(p).st_mode for p in before}
    assert all(st_mod.S_ISREG(m) for m in before.values())
