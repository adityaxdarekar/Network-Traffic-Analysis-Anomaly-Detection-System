"""Headless smoke test of all 13 dashboard pages using the Streamlit stand-in (tests/streamlit_stub.py)."""

from __future__ import annotations

import time

import pytest

from tests import streamlit_stub as S

S.install()
import streamlit as st  # noqa: E402

import app  # noqa: E402
import config as C  # noqa: E402
from dashboard import common  # noqa: E402


@pytest.fixture
def env(tmp_path, monkeypatch, db, settings):
    monkeypatch.setattr(common, "get_db", lambda: db)
    monkeypatch.setattr(C, "SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr("reports.pdf_generator.REPORT_DIR", tmp_path)
    st.session_state.clear()
    S.StubState.calls.clear()
    S.StubState.press = set()
    S.StubState.inputs = {}
    st.session_state["settings"] = settings
    return db


def run_page(page):
    st.session_state["nav"] = page
    S.StubState.calls.clear()
    try:
        app.main()
    except S.StopException:
        pass
    except S.RerunException:
        return "rerun"
    errors = [c for c in S.StubState.calls if c[0] in ("error", "exception")]
    assert errors == [], errors
    return "ok"


def test_thirteen_pages():
    assert list(app.PAGES) == ["Dashboard Overview", "Start New Audit", "File Permissions", "World-Writable Files",
                               "World-Writable Directories", "SUID/SGID Analysis", "Sensitive File Audit",
                               "Ownership Analysis", "Security Findings", "Audit History", "Reports", "Settings",
                               "About Project"]


@pytest.mark.parametrize("page", list(app.PAGES))
def test_pages_without_audit(env, page):
    run_page(page)


@pytest.mark.parametrize("page", list(app.PAGES))
def test_pages_with_lab_audit(env, lab_audit, page):
    env.save_audit(lab_audit)
    st.session_state["result"] = lab_audit
    run_page(page)


def test_start_audit_page_runs_real_audit(env, lab):
    S.StubState.inputs = {"audit_path": str(lab)}
    S.StubState.press = {"▶ Start audit"}
    assert run_page("Start New Audit") == "rerun"
    S.StubState.press = set()
    job = st.session_state["audit_job"]
    job.wait(30)
    for _ in range(5):
        if run_page("Start New Audit") == "ok":
            break
        time.sleep(0.2)
    r = st.session_state["result"]
    assert r.root == str(lab) and r.summary["findings"] >= 9
    assert env.list_audits().iloc[0]["audit_id"] == r.audit_id          # stored in history


def test_invalid_path_shows_error_and_disables_start(env):
    S.StubState.inputs = {"audit_path": "relative/path"}
    st.session_state["nav"] = "Start New Audit"
    try:
        app.main()
    except S.StopException:
        pass
    assert any(c[0] == "error" and "absolute path" in str(c[1]) for c in S.StubState.calls)
    assert "audit_job" not in st.session_state


def test_reports_page_generates_pdf(env, lab_audit):
    env.save_audit(lab_audit)
    st.session_state["result"] = lab_audit
    S.StubState.press = {"Generate PDF report"}
    run_page("Reports")
    assert st.session_state["last_report"].endswith(".pdf")
    assert len(env.list_reports()) == 1


def test_history_compare(env, lab, settings):
    from scanner.scan_manager import options_from_settings, run_audit
    a = run_audit(options_from_settings(str(lab), settings), settings)
    env.save_audit(a)
    (lab / "shared").chmod(0o1777)
    b = run_audit(options_from_settings(str(lab), settings), settings)
    env.save_audit(b)
    run_page("Audit History")
    assert any(c[0] == "markdown" and "resolved" in str(c[1]) for c in S.StubState.calls)


def test_settings_save(env, tmp_path):
    S.StubState.press = {"💾 Save settings"}
    S.StubState.inputs = {"st_en_R8": False, "st_rows": 500}
    run_page("Settings")
    saved = C.load_settings(tmp_path / "settings.json")
    assert saved["rules_enabled"]["R8"] is False and saved["dashboard"]["table_rows"] == 500
