"""Database history/compare, CSV/JSON/ZIP exports, PDF report."""

from __future__ import annotations

import csv
import io
import json
import os
import zipfile

import pytest

from conftest import make
from reports.export_manager import (entries_csv, findings_csv, save_exports, sensitive_csv, stamp_name, to_json,
                                    zip_bundle)
from reports.pdf_generator import generate_pdf_report
from scanner.scan_manager import options_from_settings, run_audit


def test_save_list_get(db, lab_audit):
    db.save_audit(lab_audit)
    audits = db.list_audits()
    assert len(audits) == 1 and audits.iloc[0]["audit_id"] == lab_audit.audit_id
    rec = db.get_audit(lab_audit.audit_id)
    assert len(rec["findings"]) == len(lab_audit.findings)
    assert rec["severity_counts"] == lab_audit.severity_counts
    assert set(rec["notable_entries"]["kind"]) >= {"world_writable_file", "world_writable_dir", "suid", "sgid"}


def test_compare_detects_new_and_resolved(db, lab, settings):
    first = run_audit(options_from_settings(str(lab), settings), settings)
    db.save_audit(first)
    os.chmod(lab / "home/student/notes.txt", 0o644)         # temp lab file only
    make(lab / "opt/tools/newsuid", 0o4755)
    second = run_audit(options_from_settings(str(lab), settings), settings)
    db.save_audit(second)
    cmp = db.compare(first.audit_id, second.audit_id)
    ch = cmp["findings"].set_index("path")["change"]
    assert ch[str(lab / "home/student/notes.txt")] == "Resolved"
    assert ch[str(lab / "opt/tools/newsuid")] == "New finding"
    assert cmp["special_added"] == [str(lab / "opt/tools/newsuid")] and cmp["same_path"]


def test_delete_audit(db, lab_audit):
    db.save_audit(lab_audit)
    db.delete_audit(lab_audit.audit_id)
    assert db.list_audits().empty and db.get_audit(lab_audit.audit_id) is None


def test_reports_table(db, lab_audit, tmp_path):
    db.save_audit(lab_audit)
    db.add_report(lab_audit.audit_id, "pdf", str(tmp_path / "r.pdf"))
    assert db.list_reports().iloc[0]["path"] == str(tmp_path / "r.pdf")


def test_csv_exports(lab_audit):
    rows = list(csv.DictReader(io.StringIO(findings_csv(lab_audit))))
    assert len(rows) == len(lab_audit.findings) and {"path", "severity", "rule", "remediation"} <= set(rows[0])
    ent = list(csv.DictReader(io.StringIO(entries_csv(lab_audit))))
    assert len(ent) == len(lab_audit.entries) and "symbolic" in ent[0]
    assert "file" in sensitive_csv(lab_audit).splitlines()[0]


def test_json_export(lab_audit):
    data = json.loads(to_json(lab_audit))
    assert data["summary"]["files"] == lab_audit.summary["files"]
    assert len(data["findings"]) == len(lab_audit.findings)
    assert "entries" not in data or not data["entries"]
    assert not data["host"]["hostname"] or data["host"]["hostname"].startswith("host-")   # masked by default


def test_exports_contain_no_file_contents(lab_audit, lab):
    marker = "TOPSECRET-CONTENT-12345"
    (lab / "data" / "public.txt").write_text(marker)
    blob = zip_bundle(lab_audit)
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        assert len(z.namelist()) >= 4
        assert all(marker not in z.read(n).decode(errors="ignore") for n in z.namelist())


def test_save_exports_timestamped(lab_audit, tmp_path):
    out = save_exports(lab_audit, tmp_path)
    assert all(p.exists() and p.stat().st_size > 0 for p in out.values())
    name = stamp_name("findings", "/home/../etc", "csv")
    assert ".." not in name and name.endswith(".csv") and "/" not in name


def test_pdf_report(lab_audit, tmp_path):
    pypdf = pytest.importorskip("pypdf")
    path = generate_pdf_report(lab_audit, tmp_path / "report.pdf", analyst="Tester")
    reader = pypdf.PdfReader(str(path))
    text = "\n".join(p.extract_text() for p in reader.pages)
    assert len(reader.pages) >= 8
    for heading in ("Executive Summary", "Audit Methodology", "World-Writable Files", "World-Writable Directories",
                    "SUID and SGID", "Sensitive Configuration", "Ownership Analysis", "Security Risk Assessment",
                    "Recommendations", "Conclusion"):
        assert heading in text, heading
    assert "app.conf" in text


def test_pdf_report_with_no_findings(tmp_path, settings):
    make(tmp_path / "clean" / "a.txt", 0o644)
    r = run_audit(options_from_settings(str(tmp_path / "clean"), settings), settings)
    assert generate_pdf_report(r, tmp_path / "clean.pdf").stat().st_size > 2000
