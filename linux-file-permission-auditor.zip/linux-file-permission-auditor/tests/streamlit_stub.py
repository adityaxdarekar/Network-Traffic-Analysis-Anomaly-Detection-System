"""
Minimal stand-ins for ``streamlit`` and ``plotly`` used by the dashboard smoke test.

They let every dashboard page run headlessly so that pandas/column/logic
errors are caught by pytest, without starting a browser. Widgets return their
default values; buttons return True only when their label is listed in
``StubState.press``. Charts check that the columns they reference exist.
"""

from __future__ import annotations

import sys
import types

import pandas as pd


class StopException(Exception):
    pass


class RerunException(Exception):
    pass


class SessionState(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as exc:
            raise AttributeError(k) from exc

    def __setattr__(self, k, v):
        self[k] = v


class StubState:
    press: set[str] = set()
    inputs: dict[str, object] = {}
    calls: list[tuple] = []


class _Ctx:
    """Object usable as a container, column, tab, expander or sidebar."""

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(_module, name)


def _record(name, *a, **k):
    StubState.calls.append((name, a, k))


def _widget_value(label, key, default):
    for ident in (key, label):
        if ident in StubState.inputs:
            return StubState.inputs[ident]
    if key and key in _module.session_state:          # like Streamlit: session_state holds keyed widget values
        return _module.session_state[key]
    return default


def _make_streamlit():
    st = types.ModuleType("streamlit")
    st.session_state = SessionState()

    def passthrough(name):
        def f(*a, **k):
            _record(name, *a, **k)
            return _Ctx()
        return f

    for name in ("markdown", "caption", "info", "warning", "error", "success", "write", "code", "divider",
                 "subheader", "title", "header", "exception", "json", "set_page_config", "line_chart", "image",
                 "toast"):
        setattr(st, name, passthrough(name))

    def dataframe(df, **k):
        assert isinstance(df, pd.DataFrame), "st.dataframe expects a DataFrame"
        assert k.get("width") in (None, "stretch", "content") or isinstance(k.get("width"), int)
        _record("dataframe", df, **k)
    st.dataframe = dataframe

    def plotly_chart(fig, **k):
        assert isinstance(fig, FakeFigure), "plotly_chart expects a figure"
        _record("plotly_chart", fig, **k)
    st.plotly_chart = plotly_chart

    def metric(label, value, *a, **k):
        _record("metric", label, value)
    st.metric = metric

    st.columns = lambda spec, **k: [_Ctx() for _ in range(spec if isinstance(spec, int) else len(spec))]
    st.tabs = lambda labels: [_Ctx() for _ in labels]
    st.expander = lambda *a, **k: _Ctx()
    st.spinner = lambda *a, **k: _Ctx()
    st.container = lambda *a, **k: _Ctx()
    st.sidebar = _Ctx()

    class _Progress:
        def progress(self, *a, **k):
            pass

        def empty(self):
            pass
    st.progress = lambda *a, **k: _Progress()

    def text_input(label, value="", key=None, **k):
        return _widget_value(label, key, value)

    def text_area(label, value="", height=None, key=None, **k):
        return _widget_value(label, key, value)

    def number_input(label, min_value=None, max_value=None, value=None, step=None, key=None, **k):
        return _widget_value(label, key, value if value is not None else min_value)

    def selectbox(label, options, index=0, key=None, format_func=str, **k):
        options = list(options)
        for o in options:
            format_func(o)
        default = options[index] if options else None
        return _widget_value(label, key, default)

    def multiselect(label, options, default=None, key=None, format_func=str, **k):
        list(options)
        return _widget_value(label, key, default or [])

    def slider(label, min_value=None, max_value=None, value=None, key=None, **k):
        return _widget_value(label, key, value)

    def checkbox(label, value=False, key=None, help=None, disabled=False, **k):
        return _widget_value(label, key, value)

    def toggle(label, value=False, key=None, **k):
        return _widget_value(label, key, value)

    def radio(label, options, key=None, format_func=str, **k):
        options = list(options)
        for o in options:
            format_func(o)
        if key and key in st.session_state:
            return st.session_state[key]
        return options[0]

    def button(label, key=None, disabled=False, **k):
        if disabled:
            return False          # like Streamlit: a disabled button can never be clicked
        return label in StubState.press or (key in StubState.press if key else False)

    def download_button(label, data, file_name=None, mime=None, key=None, **k):
        assert data is not None and len(data) > 0, f"empty download for {label}"
        _record("download_button", label, file_name, len(data))
        return False

    def file_uploader(label, type=None, help=None, **k):
        return _widget_value(label, k.get("key"), None)

    def stop():
        raise StopException()

    def rerun():
        raise RerunException()

    for f in (text_input, text_area, number_input, selectbox, multiselect, slider, checkbox, toggle, radio, button,
              download_button, file_uploader, stop, rerun):
        setattr(st, f.__name__, f)

    def cache(func=None, **kw):
        def deco(fn):
            memo = {}

            def wrapper(*a):
                if a not in memo:
                    memo[a] = fn(*a)
                return memo[a]
            wrapper.clear = memo.clear
            return wrapper
        return deco(func) if callable(func) else deco
    st.cache_resource = cache
    st.cache_data = cache
    return st


# ---------------------------------------------------------------------------
# Plotly stand-in
# ---------------------------------------------------------------------------
class FakeFigure:
    def __init__(self, *a, **k):
        self.traces = []

    def add_trace(self, t):
        self.traces.append(t)
        return self

    def __getattr__(self, name):
        if name.startswith("update_"):
            return lambda *a, **k: self
        raise AttributeError(name)


def _check_columns(df, **cols):
    if df is None:
        return
    assert isinstance(df, pd.DataFrame)
    for arg, col in cols.items():
        if isinstance(col, str):
            assert col in df.columns, f"plotly {arg}='{col}' not in columns {list(df.columns)}"


def _make_plotly():
    plotly = types.ModuleType("plotly")
    px = types.ModuleType("plotly.express")
    go = types.ModuleType("plotly.graph_objects")

    def bar(df=None, x=None, y=None, **k):
        _check_columns(df, x=x, y=y)
        return FakeFigure()

    def pie(df=None, names=None, values=None, **k):
        if df is not None:
            _check_columns(df, names=names, values=values)
        else:
            assert len(list(names)) == len(list(values))
        return FakeFigure()

    px.bar, px.pie = bar, pie
    px.line = lambda df=None, x=None, y=None, **k: (_check_columns(df, x=x, y=y), FakeFigure())[1]
    go.Figure = FakeFigure
    go.Scatter = lambda **k: k
    go.Bar = lambda **k: k
    plotly.express, plotly.graph_objects = px, go
    return plotly, px, go


_module = _make_streamlit()


def install() -> None:
    """Put the stubs into sys.modules (and drop any already-imported dashboard modules)."""
    plotly, px, go = _make_plotly()
    sys.modules["streamlit"] = _module
    sys.modules["plotly"] = plotly
    sys.modules["plotly.express"] = px
    sys.modules["plotly.graph_objects"] = go
    for name in list(sys.modules):
        if name == "app" or name.startswith("dashboard"):
            del sys.modules[name]
