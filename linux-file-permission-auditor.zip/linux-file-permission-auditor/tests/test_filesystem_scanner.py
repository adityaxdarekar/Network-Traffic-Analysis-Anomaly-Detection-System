"""Scanner: recursion, metadata, path validation, symlinks, permission errors, limits."""

from __future__ import annotations

import os
import stat
import subprocess
import sys
import threading

import pytest

from conftest import IS_ROOT, ROOT, make, scan
from scanner.filesystem_scanner import FilesystemScanner, ScanOptions, ScanPathError, validate_scan_path
from scanner.metadata_extractor import (explain_permissions, extract, octal_to_symbolic, short_octal,
                                        symbolic_mode)


def test_recursive_scan_counts_files_and_dirs(tmp_path):
    make(tmp_path / "a.txt", 0o644)
    make(tmp_path / "sub" / "b.txt", 0o600)
    make(tmp_path / "sub" / "deep" / "c.sh", 0o755)
    r = scan(tmp_path)
    paths = {e["path"] for e in r.entries}
    assert r.files == 3 and r.directories == 3      # root + sub + deep
    assert str(tmp_path / "sub" / "deep" / "c.sh") in paths
    assert r.errors == []


def test_non_recursive_scan_stays_at_top_level(tmp_path):
    make(tmp_path / "a.txt", 0o644)
    make(tmp_path / "sub" / "b.txt", 0o644)
    r = scan(tmp_path, recursive=False)
    assert str(tmp_path / "sub" / "b.txt") not in {e["path"] for e in r.entries}


def test_metadata_extraction(tmp_path):
    f = make(tmp_path / "f", 0o640)
    rec = extract(str(f), os.lstat(f))
    assert rec["octal"] == "640" and rec["symbolic"] == "-rw-r-----"
    assert rec["type"] == "file" and rec["size"] == 2
    assert rec["uid"] == os.getuid() and rec["owner"]
    assert not rec["world_writable"] and not rec["suid"]


@pytest.mark.parametrize("mode,octal,sym", [(0o644, "644", "rw-r--r--"), (0o755, "755", "rwxr-xr-x"),
                                            (0o4755, "4755", "rwsr-xr-x"), (0o2755, "2755", "rwxr-sr-x"),
                                            (0o1777, "1777", "rwxrwxrwt"), (0o600, "600", "rw-------")])
def test_numeric_and_symbolic_conversion(mode, octal, sym):
    assert short_octal(mode | stat.S_IFREG) == octal
    assert symbolic_mode(mode | stat.S_IFREG)[1:] == sym
    assert octal_to_symbolic(octal).endswith(sym)


def test_explain_permissions_mentions_classes():
    text = explain_permissions(0o754)
    assert "owner" in text.lower() and "others" in text.lower()


def test_symlinks_are_not_followed(tmp_path):
    outside = tmp_path / "outside"
    make(outside / "secret.txt", 0o666)
    target = tmp_path / "scanme"
    target.mkdir()
    os.symlink(outside, target / "link_to_dir")
    os.symlink(outside / "secret.txt", target / "link_to_file")
    r = scan(target)
    paths = {e["path"] for e in r.entries}
    assert str(target / "link_to_dir" / "secret.txt") not in paths      # did not descend through the link
    links = [e for e in r.entries if e["type"] == "symlink"]
    assert len(links) == 2 and r.symlinks == 2
    # the link's own metadata is recorded, not the 666 target
    assert all(not e["world_writable"] or e["type"] == "symlink" for e in r.entries)


def test_broken_symlink_detected(tmp_path):
    os.symlink(tmp_path / "missing", tmp_path / "dangling")
    r = scan(tmp_path)
    link = next(e for e in r.entries if e["name"] == "dangling")
    assert link["broken_link"] is True and link["symlink_target"].endswith("missing")


@pytest.mark.parametrize("raw,msg", [("", "enter a directory"), ("etc", "absolute path"),
                                     ("/definitely/not/here", "does not exist"), ("/proc", "excluded"),
                                     ("/sys/kernel", "excluded")])
def test_path_validation_rejects(raw, msg):
    with pytest.raises(ScanPathError, match=msg):
        validate_scan_path(raw, ["/proc", "/sys", "/dev", "/run"])


def test_path_validation_rejects_file_and_symlink(tmp_path):
    f = make(tmp_path / "file.txt", 0o644)
    with pytest.raises(ScanPathError, match="not a directory"):
        validate_scan_path(str(f))
    os.symlink(tmp_path, tmp_path.parent / f"{tmp_path.name}_link")
    with pytest.raises(ScanPathError, match="symbolic link"):
        validate_scan_path(str(tmp_path.parent / f"{tmp_path.name}_link"))


def test_path_validation_normalises(tmp_path):
    assert validate_scan_path(f"{tmp_path}/./") == str(tmp_path)


def test_exclusion_patterns_and_paths(tmp_path):
    make(tmp_path / "keep.txt", 0o644)
    make(tmp_path / "skip.log", 0o644)
    make(tmp_path / "cache" / "x", 0o644)
    r = scan(tmp_path, exclude_patterns=["*.log"], exclusions=[str(tmp_path / "cache")])
    names = {e["name"] for e in r.entries}
    assert "keep.txt" in names and "skip.log" not in names and "x" not in names


def test_entry_limit_marks_result_partial(tmp_path):
    for i in range(30):
        make(tmp_path / f"f{i}", 0o644)
    r = scan(tmp_path, max_entries=10)
    assert r.limit_reached and len(r.entries) == 10


def test_stop_event(tmp_path):
    make(tmp_path / "a", 0o644)
    ev = threading.Event()
    ev.set()
    r = FilesystemScanner(ScanOptions(path=str(tmp_path)), stop_event=ev).scan()
    assert r.stopped


def test_permission_error_is_recorded_not_raised(tmp_path, monkeypatch):
    blocked = tmp_path / "blocked"
    make(blocked / "x", 0o644)
    real = os.scandir

    def fake(path):
        if str(path) == str(blocked):
            raise PermissionError(13, "Permission denied")
        return real(path)

    monkeypatch.setattr("scanner.filesystem_scanner.os.scandir", fake)
    r = scan(tmp_path)
    assert r.errors and r.errors[0]["path"] == str(blocked) and "Permission denied" in r.errors[0]["error"]
    assert "sudo" in r.errors[0]["hint"]


@pytest.mark.skipif(not IS_ROOT, reason="needs root to start a process as the 'nobody' user")
def test_permission_denied_real_unprivileged_process():
    """Run the scanner as uid 65534 (nobody) against a 700 directory: it must finish and report the error."""
    import shutil
    import tempfile
    from pathlib import Path
    top = Path(tempfile.mkdtemp(prefix="permaudit-test-"))      # pytest's tmp dirs are 700, not reachable by nobody
    try:
        _run_as_nobody(top)
    finally:
        shutil.rmtree(top)                                       # removes only the test's own temp directory


def _run_as_nobody(top):
    top.chmod(0o755)
    base = top / "base"
    make(base / "readable.txt", 0o644)
    make(base / "private" / "hidden.txt", 0o600)
    base.chmod(0o755)
    (base / "private").chmod(0o700)
    # The project folder may be inside a home directory that 'nobody' cannot enter (Ubuntu homes are 750),
    # so a copy of the self-contained scanner package is placed in the test's own temp directory.
    import shutil
    shutil.copytree(ROOT / "scanner", top / "code" / "scanner", ignore=shutil.ignore_patterns("__pycache__"))
    for p in [top / "code", *(top / "code").rglob("*")]:
        p.chmod(0o755 if p.is_dir() else 0o644)
    code = ("import sys; sys.path.insert(0, sys.argv[1]); from scanner.filesystem_scanner import *; "
            "r = FilesystemScanner(ScanOptions(path=sys.argv[2])).scan(); "
            "print(len(r.errors), r.errors[0]['path'] if r.errors else '', r.files, r.privileged)")
    try:
        out = subprocess.run(["setpriv", "--reuid=65534", "--regid=65534", "--clear-groups", sys.executable, "-I",
                              "-c", code, str(top / "code"), str(base)], capture_output=True, text=True, timeout=60,
                             cwd=str(top))
    except FileNotFoundError:
        pytest.skip("setpriv not installed")
    if out.returncode != 0 and "Permission denied" in out.stderr and "scanner" not in out.stderr:
        pytest.skip("the Python interpreter is not usable by 'nobody'")
    assert out.returncode == 0, out.stderr
    n, path, files, priv = out.stdout.split()
    assert n == "1" and path == str(base / "private") and files == "1" and priv == "False"


def test_scanner_does_not_change_anything(tmp_path):
    f = make(tmp_path / "ww.txt", 0o666)
    d = tmp_path / "shared"
    d.mkdir()
    d.chmod(0o777)
    before = {p: (os.lstat(p).st_mode, os.lstat(p).st_mtime_ns, os.lstat(p).st_uid) for p in (f, d)}
    content = f.read_bytes()
    scan(tmp_path)
    after = {p: (os.lstat(p).st_mode, os.lstat(p).st_mtime_ns, os.lstat(p).st_uid) for p in (f, d)}
    assert before == after and f.read_bytes() == content


def test_source_code_contains_no_modifying_calls():
    """Read-only guarantee: application code never calls chmod/chown/remove/unlink/rename on scanned files."""
    forbidden = ["os.chmod", "os.chown", "os.lchown", "os.remove", "os.unlink", "os.rename", "os.rmdir",
                 "shutil.rmtree", "shutil.move", ".chmod(", ".unlink(", "subprocess", "os.system"]
    folders = ["scanner", "analyzer", "detection", "dashboard", "reports", "database"]
    offenders = []
    for folder in folders:
        for py in (ROOT / folder).glob("*.py"):
            text = py.read_text()
            offenders += [f"{py.name}: {w}" for w in forbidden if w in text]
    offenders += [f"app.py: {w}" for w in forbidden if w in (ROOT / "app.py").read_text()]
    assert offenders == []
