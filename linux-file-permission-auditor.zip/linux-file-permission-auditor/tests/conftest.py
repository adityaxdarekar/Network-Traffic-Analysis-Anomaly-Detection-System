"""Shared fixtures. Every test works on temporary directories - real system files are never modified."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config as C  # noqa: E402
from sample_files.create_samples import create  # noqa: E402
from scanner.filesystem_scanner import FilesystemScanner, ScanOptions  # noqa: E402
from scanner.scan_manager import options_from_settings, run_audit  # noqa: E402

IS_ROOT = os.geteuid() == 0


@pytest.fixture
def settings():
    return C.default_settings()


@pytest.fixture
def lab(tmp_path) -> Path:
    base = tmp_path / "lab"
    create(base)
    return base


@pytest.fixture
def lab_audit(lab, settings):
    return run_audit(options_from_settings(str(lab), settings), settings)


@pytest.fixture
def db(tmp_path):
    from database.db_manager import DatabaseManager
    return DatabaseManager(tmp_path / "history.db")


def scan(path, **kw):
    return FilesystemScanner(ScanOptions(path=str(path), **kw)).scan()


def make(path: Path, mode: int, content: str = "x\n") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    os.chmod(path, mode)
    return path
