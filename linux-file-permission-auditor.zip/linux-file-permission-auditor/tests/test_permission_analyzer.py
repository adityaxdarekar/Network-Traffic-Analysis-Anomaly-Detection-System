"""Permission analysis, distribution, access matrix, rules R6/R7/R9/R10, risk engine."""

from __future__ import annotations

from analyzer import permission_analyzer as pa
from conftest import make, scan
from detection.detection_rules import RuleContext, describe_rules
from detection.risk_engine import run_rules, severity_counts
from analyzer.special_permission_analyzer import special_files
import config as C
import pandas as pd


def df_of(path, **kw):
    return pa.entries_dataframe(scan(path, **kw).entries)


def ctx_for(df, settings=None, sensitive_rows=None):
    settings = settings or C.default_settings()
    return RuleContext(df=df, special=special_files(df), sensitive_rows=sensitive_rows or [], settings=settings,
                       uid_min=1000, handled_paths=set())


def test_distribution_and_summary(tmp_path):
    make(tmp_path / "a", 0o644)
    make(tmp_path / "b", 0o644)
    make(tmp_path / "c", 0o600)
    df = df_of(tmp_path)
    dist = pa.permission_distribution(df).set_index("octal")
    assert dist.loc["644", "files"] == 2 and dist.loc["600", "files"] == 1
    s = pa.summary(df)
    assert s["files"] == 3 and s["world_writable_files"] == 0


def test_access_matrix(tmp_path):
    make(tmp_path / "a", 0o666)
    make(tmp_path / "b", 0o644)
    am = pa.access_matrix(df_of(tmp_path)).set_index("class")
    assert am.loc["others", "write"] == 1 and am.loc["owner", "write"] == 2 and am.loc["others", "read"] == 2


def test_type_distribution(lab):
    td = pa.type_distribution(df_of(lab))
    assert td["file"] == 14 and td["directory"] == 11 and td["symlink"] == 1


def test_r6_private_key_readable_by_everyone(tmp_path):
    make(tmp_path / ".ssh" / "id_rsa", 0o644)
    make(tmp_path / ".ssh" / "id_rsa.pub", 0o644)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    keys = fd[fd["rule"] == "R6"]
    assert list(keys["path"].str.rsplit("/", n=1).str[-1]) == ["id_rsa"]
    assert keys.iloc[0]["severity"] == "High"


def test_r6_world_writable_data_file(tmp_path):
    make(tmp_path / "notes.txt", 0o666)
    fd, _ = run_rules(ctx_for(df_of(tmp_path)))
    assert (fd["rule"] == "R6").sum() == 1 and fd.iloc[0]["severity"] in ("Medium", "Low")


def test_no_findings_for_safe_files(tmp_path):
    make(tmp_path / "a.txt", 0o644)
    make(tmp_path / "run.sh", 0o755)
    make(tmp_path / "private.txt", 0o600)
    fd, errs = run_rules(ctx_for(df_of(tmp_path)))
    assert fd.empty and errs == []


def test_r7_uses_sensitive_rows():
    row = {"file": "/etc/shadow", "exists": True, "type": "file", "observed_mode": "644",
           "observed_symbolic": "-rw-r--r--", "expected_mode": "≤ 640 (rw-r-----)", "typical_mode": "640",
           "observed_owner": "root", "observed_group": "root", "expected_owner": "root", "expected_group": "shadow",
           "result": "Deviation - review", "issues": ["others can read"], "extra_bits": "004", "mode": 0o644,
           "uid": 0, "gid": 0, "others_write": False, "others_read": True, "group_write": False, "owner_ok": True,
           "group_ok": True}
    fd, _ = run_rules(ctx_for(pa.entries_dataframe([]), sensitive_rows=[row]))
    r7 = fd[fd["rule"] == "R7"]
    assert len(r7) == 1 and r7.iloc[0]["path"] == "/etc/shadow" and r7.iloc[0]["severity"] in ("High", "Critical")


def test_rules_can_be_disabled_and_overridden(lab_audit, settings):
    s = settings
    s["rules_enabled"]["R6"] = False
    s["severity_overrides"]["R2"] = "Low"
    fd, _ = run_rules(ctx_for(lab_audit.entries, s))
    assert "R6" not in set(fd["rule"])
    assert set(fd[fd["rule"] == "R2"]["severity"]) == {"Low"}


def test_findings_have_all_required_fields(lab_audit):
    fd = lab_audit.findings
    for col in ["finding_id", "path", "file_type", "permissions", "expected", "owner", "group", "rule", "rule_name",
                "severity", "explanation", "impact", "remediation"]:
        assert col in fd.columns and fd[col].notna().all(), col
    assert fd["finding_id"].is_unique and fd["finding_id"].str.match(r"F-\d{4}").all()
    assert set(fd["severity"]) <= set(C.SEVERITY_ORDER)


def test_findings_sorted_by_severity(lab_audit):
    order = [C.SEVERITY_ORDER.index(s) for s in lab_audit.findings["severity"]]
    assert order == sorted(order, reverse=True)


def test_severity_counts_cover_every_level(lab_audit):
    counts = severity_counts(lab_audit.findings)
    assert set(counts) == set(C.SEVERITY_ORDER) and sum(counts.values()) == len(lab_audit.findings)


def test_remediation_is_text_only(lab_audit):
    """Remediation is a suggestion; paths are shell-quoted so a copied command is safe."""
    rem = lab_audit.findings["remediation"]
    assert rem.str.contains("chmod|chown|Review|review|Verify|verify", regex=True).all()


def test_ten_rules_described():
    rules = describe_rules()
    assert [r["rule"] for r in rules] == [f"R{i}" for i in range(1, 11)]


def test_rule_error_isolated(lab_audit, monkeypatch):
    """A crashing rule is reported but the other nine still run."""
    import detection.risk_engine as re_mod

    def boom(ctx):
        raise RuntimeError("broken rule")

    monkeypatch.setitem(re_mod.ALL_RULES, "R1", boom)
    fd, errs = run_rules(ctx_for(lab_audit.entries))
    assert len(errs) == 1 and "R1" in errs[0] and "broken rule" in errs[0]
    assert "R2" in set(fd["rule"])
