#!/usr/bin/env python3
"""
analyze.py - terminal companion to the dashboard (same detection engine).

    python analyze.py sample_logs/auth.log                    # analyse and print incidents
    python analyze.py sample_logs/auth.log --save             # also store incidents in SQLite
    python analyze.py my.log --max-failed 5 --window 5 --high 10 --critical 20
    python analyze.py sample_logs/auth.log --pdf reports/report.pdf --csv reports/
    python analyze.py --incidents                             # list stored incidents
    python analyze.py --set-status INC-XXXX Investigating --note "checking with the admin team"

Read-only towards other systems: it parses files, nothing else.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from tabulate import tabulate

from config import DB_PATH, DetectionConfig
from database.db_manager import DBManager
from detector.brute_force_detector import analyze_events
from detector.incident_manager import IncidentManager
from detector.log_parser import parse_file
from detector.risk_scoring import DISCLAIMER
from utils.helpers import fmt_duration, fmt_ts
from utils.report_generator import incidents_csv, pdf_report, suspicious_ips_csv


def print_result(path, parsed, res, merged):
    s = parsed.summary()
    m = res.metrics
    print(f"\n=== {path}  [{s['format']}]" + ("  ** SYNTHETIC DATA **" if s["synthetic"] else ""))
    print(f"lines {s['total_lines']} | auth events {m['total_events']} | failed attempts {m['failed_attempts']} | "
          f"successful logins {m['successful_logins']} | malformed {s['malformed_lines']} | unrelated "
          f"{s['unrelated_lines']} | merged supporting lines {s['supporting_lines']}")
    for ln, why, txt in parsed.errors[:5]:
        print(f"  skipped line {ln}: {why}: {txt[:70]}")
    print(f"incidents {m['incidents']} (critical {m['critical']}, high {m['high']}, medium {m['medium']}, low {m['low']}) "
          f"| suspicious IPs {m['suspicious_ips']}\n")
    if merged:
        print(tabulate([[i["incident_id"], i["risk_level"], i["risk_score"], i["incident_type"], i["source_ip"],
                         i["failed_attempts"], i["successful_logins"], ", ".join(i["usernames"])[:28],
                         fmt_ts(i["first_seen"])[11:], fmt_duration(i["duration_s"]), i["status"]] for i in merged],
                       ["Incident", "Level", "Score", "Type", "Source", "Fail", "OK", "Usernames", "First", "Span",
                        "Status"], tablefmt="simple"))
        for i in merged:
            print(f"\n[{i['risk_level'].upper()} {i['risk_score']}] {i['incident_id']} {i['incident_type']} - {i['source_ip']}")
            print("  score: " + " + ".join(f"{b['factor']} ({b['points']})" for b in i["score_breakdown"]))
            for r in i["reasons"]:
                print(f"  - {r}")
            for d in i["success_details"]:
                print(f"  ! successful login: {d}")
    else:
        print("No brute-force patterns crossed the thresholds.")
    if not res.suspicious_ips.empty:
        print("\nSuspicious IPs:")
        print(tabulate([[r.ip_address, r.total_failed_attempts, r.successful_logins, r.usernames_targeted,
                         fmt_ts(r.first_detected), fmt_ts(r.last_detected), r.risk_score, r.risk_level]
                        for r in res.suspicious_ips.itertuples()],
                       ["IP", "Failed", "Success", "Users", "First", "Last", "Score", "Level"], tablefmt="simple"))
    print(f"\nNote: {DISCLAIMER}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Brute-force detection on SSH auth logs / CSV logs")
    ap.add_argument("logfile", nargs="?")
    ap.add_argument("--format", choices=["auto", "syslog", "csv"], default="auto")
    ap.add_argument("--year", type=int, help="year for syslog lines (they carry no year)")
    ap.add_argument("--max-failed", type=int, default=5)
    ap.add_argument("--window", type=float, default=5.0, help="minutes")
    ap.add_argument("--high", type=int, default=10)
    ap.add_argument("--critical", type=int, default=20)
    ap.add_argument("--save", action="store_true", help="store incidents in SQLite")
    ap.add_argument("--db", default=str(DB_PATH))
    ap.add_argument("--pdf")
    ap.add_argument("--csv", help="directory for incidents.csv and suspicious_ips.csv")
    ap.add_argument("--incidents", action="store_true", help="list stored incidents")
    ap.add_argument("--set-status", nargs=2, metavar=("INCIDENT_ID", "STATUS"))
    ap.add_argument("--note", default="")
    a = ap.parse_args(argv)
    db = DBManager(a.db)
    im = IncidentManager(db)
    try:
        if a.set_status:
            ok = im.set_status(a.set_status[0], a.set_status[1], a.note)
            print("updated" if ok else "incident not found")
            return 0 if ok else 1
        if a.incidents:
            rows = im.list()
            print(tabulate([[r["incident_id"], r["risk_level"], r["risk_score"], r["incident_type"], r["source_ip"],
                             r["status"], (r["analyst_notes"] or "")[:40], r["updated_at"]] for r in rows],
                           ["Incident", "Level", "Score", "Type", "Source", "Status", "Notes", "Updated"],
                           tablefmt="simple") if rows else "no stored incidents")
            return 0
        if not a.logfile:
            ap.error("give a log file, --incidents or --set-status")
        cfg = DetectionConfig(max_failed_attempts=a.max_failed, time_window_minutes=a.window,
                              high_risk_threshold=a.high, critical_risk_threshold=a.critical)
        errs = cfg.validate()
        if errs:
            print("invalid settings: " + "; ".join(errs))
            return 2
        try:
            parsed = parse_file(a.logfile, a.format, a.year)
        except OSError as exc:
            print(f"cannot read {a.logfile}: {exc}")
            return 2
        res = analyze_events(parsed.events, cfg)
        name = Path(a.logfile).name
        if a.save:
            im.sync(res, name, parsed.synthetic)
        merged = im.merged(res)
        print_result(a.logfile, parsed, res, merged)
        if a.csv:
            d = Path(a.csv)
            d.mkdir(parents=True, exist_ok=True)
            (d / "incidents.csv").write_bytes(incidents_csv(merged))
            (d / "suspicious_ips.csv").write_bytes(suspicious_ips_csv(res))
            print(f"\nCSV written to {d}/incidents.csv and {d}/suspicious_ips.csv")
        if a.pdf:
            Path(a.pdf).parent.mkdir(parents=True, exist_ok=True)
            Path(a.pdf).write_bytes(pdf_report(res, merged, name, parsed.synthetic))
            print(f"PDF written to {a.pdf}")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
