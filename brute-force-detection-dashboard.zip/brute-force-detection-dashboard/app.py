"""
app.py - Brute Force Attack Detection and Monitoring Dashboard (Streamlit).

    streamlit run app.py

Pages: Security Overview · Authentication Log Analyzer · Brute Force Detection ·
Suspicious IP Analysis · Incident Management · Reports and Downloads ·
Detection Configuration.

Every metric, chart and table is computed from the log that is currently
loaded (bundled synthetic sample, an uploaded file, or a monitored local
file). Nothing blocks IPs or contacts other systems.
"""
from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAVE_PLOTLY = True
except ImportError:          # the dashboard still works with Streamlit's built-in charts
    px = None
    HAVE_PLOTLY = False

from config import (APP_TITLE, CSS_FILE, DB_PATH, INCIDENT_STATUSES, MAX_UPLOAD_MB, RISK_COLORS, RISK_LEVELS,
                    SAMPLE_DIR, DetectionConfig)
from database.db_manager import DBManager
from detector.brute_force_detector import analyze_events
from detector.incident_manager import IncidentManager
from detector.log_monitor import MonitorSession
from detector.log_parser import decode_bytes, parse_file, parse_text
from detector.risk_scoring import BASE, DISCLAIMER
from utils.helpers import UploadError, esc, fmt_duration, fmt_ts, get_logger, risk_badge, validate_upload
from utils.report_generator import incidents_csv, pdf_report, suspicious_ips_csv

PAGES = ["Security Overview", "Authentication Log Analyzer", "Brute Force Detection", "Suspicious IP Analysis",
         "Incident Management", "Reports and Downloads", "Detection Configuration"]
SOURCES = ["Bundled sample log (synthetic)", "Upload a log file", "Monitor a local log file"]
LOG = get_logger()


# ============================================================ state
@st.cache_resource
def get_db(path: str = str(DB_PATH)) -> DBManager:
    return DBManager(path)


def ss():
    return st.session_state


def sidebar_config() -> DetectionConfig:
    st.sidebar.markdown("### Detection thresholds")
    d = DetectionConfig()
    cur = ss().get("cfg", d.to_dict())
    cfg = DetectionConfig(
        max_failed_attempts=int(st.sidebar.number_input("Maximum failed attempts", 2, 10000,
                                                        int(cur["max_failed_attempts"]), key="cfg_max")),
        time_window_minutes=float(st.sidebar.number_input("Detection time window (minutes)", 0.1, 1440.0,
                                                          float(cur["time_window_minutes"]), key="cfg_win")),
        high_risk_threshold=int(st.sidebar.number_input("High-risk threshold (failures)", 2, 100000,
                                                        int(cur["high_risk_threshold"]), key="cfg_high")),
        critical_risk_threshold=int(st.sidebar.number_input("Critical-risk threshold (failures)", 3, 1000000,
                                                            int(cur["critical_risk_threshold"]), key="cfg_crit")),
    )
    with st.sidebar.expander("Advanced rules"):
        cfg.multi_user_threshold = int(st.number_input("Usernames per IP (multi-username rule)", 2, 1000,
                                                       int(cur["multi_user_threshold"]), key="cfg_mu"))
        cfg.distributed_ip_threshold = int(st.number_input("IPs per username (distributed rule)", 2, 10000,
                                                           int(cur["distributed_ip_threshold"]), key="cfg_di"))
        cfg.success_after_failures_min = int(st.number_input("Failures before a success to flag", 1, 10000,
                                                             int(cur["success_after_failures_min"]), key="cfg_saf"))
        cfg.success_lookahead_minutes = float(st.number_input("Success look-ahead (minutes)", 0.0, 1440.0,
                                                              float(cur["success_lookahead_minutes"]), key="cfg_la"))
        cfg.fast_attempt_seconds = float(st.number_input("'Concentrated' if mean gap <= (seconds)", 0.1, 3600.0,
                                                         float(cur["fast_attempt_seconds"]), key="cfg_fast"))
    errs = cfg.validate()
    if errs:
        for e in errs:
            st.sidebar.error(e)
        return DetectionConfig.from_dict(ss().get("cfg", d.to_dict()))
    ss()["cfg"] = cfg.to_dict()
    return cfg


def sidebar_source():
    st.sidebar.markdown("### Log source")
    source = st.sidebar.radio("Source", SOURCES, key="source")
    if source == SOURCES[0]:
        files = sorted(p.name for p in SAMPLE_DIR.glob("*") if p.suffix in (".log", ".csv"))
        if not files:
            st.sidebar.warning("No sample logs - run: python -m utils.sample_log_generator")
            return None
        default = files.index("auth.log") if "auth.log" in files else 0
        name = st.sidebar.selectbox("Sample file", files, index=default)
        path = SAMPLE_DIR / name
        key = f"sample:{name}:{path.stat().st_mtime_ns}"
        if ss().get("parsed_key") != key:
            ss().update(parsed=parse_file(path), parsed_key=key, source_name=name)
        return ss()["parsed"]
    if source == SOURCES[1]:
        up = st.sidebar.file_uploader(f"auth.log / secure / CSV (max {MAX_UPLOAD_MB} MB)",
                                      type=None, accept_multiple_files=False)
        fmt = st.sidebar.selectbox("Format", ["auto", "syslog", "csv"])
        if up is None:
            return ss().get("parsed") if ss().get("parsed_key", "").startswith("upload:") else None
        data = up.getvalue()
        key = f"upload:{up.name}:{hashlib.sha256(data).hexdigest()[:16]}:{fmt}"
        if ss().get("parsed_key") != key:
            try:
                validate_upload(up.name, data)
            except UploadError as exc:
                st.sidebar.error(f"Upload rejected: {exc}")
                return None
            parsed = parse_text(decode_bytes(data), fmt)
            LOG.info("uploaded %s (%d bytes): %s", up.name, len(data), parsed.summary())
            ss().update(parsed=parsed, parsed_key=key, source_name=up.name)
        return ss()["parsed"]
    # ---- monitoring
    st.sidebar.caption("Reads only new lines on each refresh. Only monitor logs you are authorised to read.")
    default = str(SAMPLE_DIR / "live_auth.log")
    path = st.sidebar.text_input("Local log file path", ss().get("mon_path", default))
    from_start = st.sidebar.checkbox("Read existing content first", value=True)
    mon = ss().get("monitor")
    if mon is None or ss().get("mon_path") != path:
        mon = MonitorSession(path, from_start=from_start)
        ss().update(monitor=mon, mon_path=path)
        mon.refresh()
    c1, c2 = st.sidebar.columns(2)
    if c1.button("Refresh now"):
        mon.refresh()
    if c2.button("Reset"):
        mon = MonitorSession(path, from_start=from_start)
        ss()["monitor"] = mon
        mon.refresh()
    auto = st.sidebar.checkbox("Auto-refresh", value=False, key="auto_refresh")
    every = st.sidebar.number_input("Every (seconds)", 2, 600, 10, key="auto_every")
    st.sidebar.caption(f"Status: {mon.status} · events {len(mon.events)} · refreshes {mon.stats['refreshes']}")
    from detector.log_parser import ParseResult
    pr = ParseResult(events=list(mon.events), log_format="syslog (monitored)", total_lines=mon.stats["lines"],
                     auth_lines=mon.stats["auth_events"], unrelated_lines=mon.stats["unrelated"],
                     malformed_lines=mon.stats["malformed"], synthetic=mon.synthetic)
    ss().update(source_name=Path(path).name, parsed_key=f"monitor:{path}:{len(mon.events)}", parsed=pr,
                _auto=(auto, every))
    return pr


def run_detection(parsed, cfg, im: IncidentManager):
    res = analyze_events(parsed.events, cfg)
    key = hashlib.sha256((ss().get("parsed_key", "") + json.dumps(cfg.to_dict(), sort_keys=True)).encode()).hexdigest()
    if ss().get("synced_key") != key and parsed.events:
        im.sync(res, ss().get("source_name", "?"), parsed.synthetic)
        ss()["synced_key"] = key
        LOG.info("analysis of %s: %s", ss().get("source_name"), {k: v for k, v in res.metrics.items()
                                                                  if not k.endswith("_event")})
    return res


# ============================================================ UI helpers
def header(title, parsed):
    src = ss().get("source_name", "-")
    st.markdown(f'<div class="soc-header"><div><div class="title">{esc(title)}</div>'
                f'<div class="sub">{esc(APP_TITLE)} · source: {esc(src)}</div></div>'
                f'<div class="sub">{datetime.now():%Y-%m-%d %H:%M}</div></div>', unsafe_allow_html=True)
    if parsed is not None and parsed.synthetic:
        st.markdown('<div class="synthetic-banner">SYNTHETIC DATA - this log was generated for demonstration. '
                    'Attacker addresses are RFC 5737 documentation IPs; the activity is not real.</div>',
                    unsafe_allow_html=True)


def metric(col, value, label, kind=""):
    col.markdown(f'<div class="metric-card {kind}"><div class="value">{esc(value)}</div>'
                 f'<div class="label">{esc(label)}</div></div>', unsafe_allow_html=True)


def chart(kind, df, x, y=None, title="", color=None, **kw):
    if df is None or len(df) == 0:
        st.info(f"{title}: no data")
        return
    if HAVE_PLOTLY:
        cmap = kw.pop("color_discrete_map", RISK_COLORS)
        if kind == "bar":
            fig = px.bar(df, x=x, y=y, title=title, color=color, color_discrete_map=cmap, text_auto=True, **kw)
        elif kind == "line":
            fig = px.line(df, x=x, y=y, title=title, color=color, markers=True, **kw)
        elif kind == "pie":
            fig = px.pie(df, names=x, values=y, title=title, hole=0.5, color=x,
                         color_discrete_map={**RISK_COLORS, "Failed": "#ef4444", "Successful": "#22c55e"})
        elif kind == "scatter":
            fig = px.scatter(df, x=x, y=y, title=title, color=color, color_discrete_map=cmap, **kw)
        else:
            raise ValueError(kind)
        fig.update_layout(template="plotly_dark", paper_bgcolor="#070b14", plot_bgcolor="#0f172a", height=340,
                          margin=dict(l=10, r=10, t=46, b=10), legend_title_text="")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.caption(title + " (install plotly for interactive charts)")
        if kind == "line":
            st.line_chart(df.set_index(x)[y])
        elif kind == "pie":
            st.bar_chart(df.set_index(x)[y])
        elif kind == "scatter":
            st.scatter_chart(df, x=x, y=y)
        else:
            st.bar_chart(df.set_index(x)[y])


def no_data():
    st.info("No log loaded. Choose a bundled sample, upload a file, or monitor a local log in the sidebar.")


def incident_frame(incidents) -> pd.DataFrame:
    return pd.DataFrame([{"Incident": i["incident_id"], "Risk": i["risk_level"], "Score": i["risk_score"],
                          "Type": i["incident_type"], "Source IP": i["source_ip"],
                          "Failed": i["failed_attempts"], "Success": i["successful_logins"],
                          "Usernames": ", ".join(i["usernames"])[:80], "First seen": fmt_ts(i["first_seen"]),
                          "Last seen": fmt_ts(i["last_seen"]), "Duration": fmt_duration(i["duration_s"]),
                          "Status": i.get("status", "Open")} for i in incidents])


# ============================================================ pages
def page_overview(parsed, res, im):
    header("Security Overview", parsed)
    if parsed is None:
        return no_data()
    m = res.metrics
    c = st.columns(6)
    metric(c[0], m["total_events"], "authentication events")
    metric(c[1], m["failed_attempts"], "failed login attempts", "warn" if m["failed_attempts"] else "")
    metric(c[2], m["successful_logins"], "successful logins", "ok")
    metric(c[3], m["suspicious_ips"], "suspicious IP addresses", "warn" if m["suspicious_ips"] else "")
    metric(c[4], m["brute_force_incidents"], "brute-force incidents", "warn" if m["brute_force_incidents"] else "")
    metric(c[5], m["critical"], "critical-risk incidents", "critical" if m["critical"] else "")
    st.write("")
    ev = res.events
    fails = ev[(ev["status"] == "failure") & ev["counts_as_attempt"]] if not ev.empty else ev
    left, right = st.columns([3, 2])
    with left:
        if not fails.empty:
            span = (fails["timestamp"].max() - fails["timestamp"].min()).total_seconds()
            freq = "1min" if span <= 6 * 3600 else ("10min" if span <= 3 * 86400 else "1h")
            ts = fails.set_index("timestamp").resample(freq).size().reset_index(name="failed attempts")
            chart("bar", ts, "timestamp", "failed attempts", f"Failed login attempts over time (per {freq})")
        else:
            st.info("No failed attempts in this log.")
    with right:
        dist = pd.DataFrame({"result": ["Failed", "Successful"], "events": [m["failed_attempts"], m["successful_logins"]]})
        chart("pie", dist, "result", "events", "Successful vs failed logins")
    left, right = st.columns(2)
    with left:
        top = res.suspicious_ips.head(10)
        chart("bar", top.sort_values("total_failed_attempts"), "total_failed_attempts", "ip_address",
              "Top 10 suspicious IP addresses (failed attempts)", color="risk_level", orientation="h")
    with right:
        tu = res.targeted_usernames.head(10)
        chart("bar", tu.sort_values("failed_attempts"), "failed_attempts", "username", "Most targeted usernames",
              orientation="h")
    left, right = st.columns(2)
    with left:
        rd = pd.DataFrame({"risk_level": RISK_LEVELS, "incidents": [m["low"], m["medium"], m["high"], m["critical"]]})
        chart("bar", rd, "risk_level", "incidents", "Risk-level distribution of incidents", color="risk_level")
    with right:
        if not ev.empty:
            g = ev[ev["status"].isin(["failure", "success"]) & ev["counts_as_attempt"]]
            g = g.groupby(["source_ip", "status"]).size().reset_index(name="attempts")
            top_ips = g.groupby("source_ip")["attempts"].sum().nlargest(15).index
            chart("bar", g[g["source_ip"].isin(top_ips)], "source_ip", "attempts",
                  "Login attempts grouped by IP (top 15)", color="status",
                  color_discrete_map={"failure": "#ef4444", "success": "#22c55e"})
    st.markdown(f'<div class="heuristic-note">{esc(DISCLAIMER)}</div>', unsafe_allow_html=True)


def page_analyzer(parsed, res, im):
    header("Authentication Log Analyzer", parsed)
    if parsed is None:
        return no_data()
    s = parsed.summary()
    c = st.columns(6)
    metric(c[0], s["total_lines"], "lines read")
    metric(c[1], s["auth_events"], "auth events parsed")
    metric(c[2], s["failed_attempts"], "failed attempts (deduplicated)")
    metric(c[3], s["successful_logins"], "successful logins", "ok")
    metric(c[4], s["unrelated_lines"], "unrelated lines skipped")
    metric(c[5], s["malformed_lines"], "malformed lines", "warn" if s["malformed_lines"] else "")
    st.caption(f"Format: {s['format']} · 'message repeated N times' expanded: {s['repeated_expanded']} · supporting "
               f"pam/invalid-user lines merged into their 'Failed password' attempt: {s['supporting_lines']}")
    if parsed.errors:
        with st.expander(f"Malformed / skipped lines ({s['malformed_lines']}) - the analysis continued"):
            st.dataframe(pd.DataFrame(parsed.errors, columns=["line", "reason", "excerpt"]), hide_index=True,
                         use_container_width=True)
    ev = res.events
    if ev.empty:
        st.warning("No authentication events were recognised in this file.")
        return
    c = st.columns(4)
    status = c[0].multiselect("Status", ["failure", "success", "info"], default=["failure", "success"])
    ip = c[1].text_input("Source IP contains", "")
    user = c[2].text_input("Username contains", "")
    only_counted = c[3].checkbox("Only counted attempts", value=False)
    f = ev[ev["status"].isin(status)] if status else ev
    if ip:
        f = f[f["source_ip"].str.contains(ip, regex=False)]
    if user:
        f = f[f["username"].str.contains(user, regex=False, case=False)]
    if only_counted:
        f = f[f["counts_as_attempt"]]
    st.dataframe(f[["timestamp", "source_ip", "username", "status", "event_type", "counts_as_attempt", "message"]],
                 hide_index=True, use_container_width=True, height=420)
    st.caption(f"{len(f)} of {len(ev)} events shown")
    et = ev.groupby(["event_type", "status"]).size().reset_index(name="events")
    chart("bar", et, "event_type", "events", "Events by type", color="status",
          color_discrete_map={"failure": "#ef4444", "success": "#22c55e", "info": "#64748b"})
    with st.expander("Supported log formats"):
        st.markdown("""
**Linux SSH (`/var/log/auth.log`, `/var/log/secure`)**
```
Nov  8 10:15:04 web01 sshd[2143]: Failed password for root from 203.0.113.5 port 52144 ssh2
Nov  8 10:16:01 web01 sshd[2150]: Failed password for invalid user admin from 198.51.100.7 port 4000 ssh2
Nov  8 10:16:00 web01 sshd[2150]: Invalid user admin from 198.51.100.7 port 4000
Nov  8 10:17:00 web01 sshd[2160]: Accepted publickey for alice from 10.0.0.5 port 50000 ssh2
Nov  8 10:15:02 web01 sshd[2143]: pam_unix(sshd:auth): authentication failure; ... rhost=203.0.113.5 user=root
2026-11-08T10:19:00+00:00 web01 sshd[2180]: Failed password for root from 2001:db8::5 port 22 ssh2
```
**CSV** with a header: `timestamp,source_ip,username,status[,event_type,message]` - status `success`/`failure`
(aliases such as `ip`, `user`, `result`, `accepted`, `failed` are accepted).
""")


def page_detection(parsed, res, im):
    header("Brute Force Detection", parsed)
    if parsed is None:
        return no_data()
    cfg = res.config
    st.caption(f"Rule: an IP is flagged when >= {cfg['max_failed_attempts']} failures fall inside any sliding "
               f"{cfg['time_window_minutes']}-minute window (also: >= {cfg['multi_user_threshold']} usernames from one IP, "
               f">= {cfg['distributed_ip_threshold']} IPs against one username, success after "
               f">= {cfg['success_after_failures_min']} failures).")
    incs = im.merged(res)
    if not incs:
        st.success("No brute-force pattern crossed the thresholds in this log. (Normal activity, or attempts too "
                   "slow / too few for the configured window.)")
        return
    st.dataframe(incident_frame(incs), hide_index=True, use_container_width=True)
    ev = res.events
    for i in incs:
        with st.expander(f"[{i['risk_level']} {i['risk_score']}] {i['incident_type']} - {i['source_ip']} - "
                         f"{i['failed_attempts']} failures", expanded=i["risk_level"] in ("Critical", "High")):
            st.markdown(f"{risk_badge(i['risk_level'])} &nbsp; <b>{esc(i['incident_id'])}</b> · status "
                        f"<b>{esc(i['status'])}</b>", unsafe_allow_html=True)
            c = st.columns(4)
            c[0].metric("Failed attempts", i["failed_attempts"])
            c[1].metric("Peak in one window", i["peak_window_attempts"])
            c[2].metric("Usernames", len(i["usernames"]))
            c[3].metric("Successful logins", i["successful_logins"])
            st.markdown(f"**First / last activity:** {fmt_ts(i['first_seen'])} → {fmt_ts(i['last_seen'])} "
                        f"({fmt_duration(i['duration_s'])})")
            st.markdown("**Targeted usernames:** " + esc(", ".join(i["usernames"])))
            st.markdown("**Reasons for detection:**")
            for r in i["reasons"]:
                st.markdown(f"- {r}")
            if i["success_details"]:
                st.error("Successful login(s) after the failures: " + "; ".join(i["success_details"]) +
                         " - this deserves investigation because the attacker may have guessed the password.")
            st.dataframe(pd.DataFrame(i["score_breakdown"]), hide_index=True, use_container_width=True)
            ips = i["source_ips"]
            tl = ev[ev["source_ip"].isin(ips) & ev["status"].isin(["failure", "success"]) & ev["counts_as_attempt"] &
                    (ev["timestamp"] >= i["first_seen"]) &
                    (ev["timestamp"] <= max(i["last_seen"], i["first_seen"]) + pd.Timedelta(minutes=30))]
            if i["incident_type"].startswith("Distributed"):
                tl = tl[tl["username"] == i["username_key"]]
            chart("scatter", tl, "timestamp", "username", "Attempt timeline", color="status",
                  color_discrete_map={"failure": "#ef4444", "success": "#22c55e"}, hover_data=["source_ip"])
    st.markdown("#### Usernames targeted by suspicious IPs")
    st.dataframe(res.targeted_usernames, hide_index=True, use_container_width=True)
    st.markdown(f'<div class="heuristic-note">{esc(DISCLAIMER)}</div>', unsafe_allow_html=True)


def page_ips(parsed, res, im):
    header("Suspicious IP Analysis", parsed)
    if parsed is None:
        return no_data()
    df = res.suspicious_ips
    if df.empty:
        st.success("No suspicious IP addresses with the current settings.")
        return
    show = df.copy()
    show["first_detected"] = show["first_detected"].map(fmt_ts)
    show["last_detected"] = show["last_detected"].map(fmt_ts)
    st.dataframe(show, hide_index=True, use_container_width=True)
    st.caption("This tool never blocks addresses or contacts them. Addresses shown in the synthetic samples are "
               "documentation IPs. Verify ownership (your scanner, VPN, shared NAT) before any manual block.")
    ip = st.selectbox("Inspect IP", list(df["ip_address"]))
    row = df[df["ip_address"] == ip].iloc[0]
    c = st.columns(5)
    c[0].metric("Failed attempts", int(row["total_failed_attempts"]))
    c[1].metric("Successful logins", int(row["successful_logins"]))
    c[2].metric("Usernames targeted", int(row["usernames_targeted"]))
    c[3].metric("Risk score", int(row["risk_score"]))
    c[4].metric("Risk category", row["risk_level"])
    ev = res.events
    sub = ev[(ev["source_ip"] == ip) & ev["status"].isin(["failure", "success"]) & ev["counts_as_attempt"]]
    chart("scatter", sub, "timestamp", "username", f"Activity of {ip}", color="status",
          color_discrete_map={"failure": "#ef4444", "success": "#22c55e"})
    u = sub.groupby(["username", "status"]).size().reset_index(name="attempts")
    chart("bar", u, "username", "attempts", "Usernames tried by this IP", color="status",
          color_discrete_map={"failure": "#ef4444", "success": "#22c55e"})
    rel = [i for i in im.merged(res) if ip in i["source_ips"]]
    st.markdown("**Related incidents**")
    st.dataframe(incident_frame(rel), hide_index=True, use_container_width=True)


def page_incidents(parsed, res, im):
    header("Incident Management", parsed)
    scope = st.radio("Scope", ["Current analysis", "All stored incidents"], horizontal=True)
    c = st.columns(3)
    levels = c[0].multiselect("Risk level", RISK_LEVELS, default=RISK_LEVELS)
    statuses = c[1].multiselect("Status", INCIDENT_STATUSES, default=INCIDENT_STATUSES)
    ip = c[2].text_input("Search IP address", "")
    ids = [i["incident_id"] for i in res.incidents] if (scope == "Current analysis" and res is not None) else None
    if scope == "Current analysis" and res is None:
        ids = []
    rows = im.list(levels=levels, ip_search=ip, statuses=statuses, current_ids=ids)
    counts = im.db.status_counts()
    st.caption(f"Stored incidents - Open {counts['Open']} · Investigating {counts['Investigating']} · Resolved "
               f"{counts['Resolved']}. Status and notes are saved in SQLite ({DB_PATH.name}) and survive restarts.")
    if not rows:
        st.info("No incidents match the filters.")
        return
    table = pd.DataFrame([{"Incident": r["incident_id"], "Risk": r["risk_level"], "Score": r["risk_score"],
                           "Type": r["incident_type"], "Source IP": r["source_ip"], "Failed": r["failed_attempts"],
                           "Status": r["status"], "Notes": (r["analyst_notes"] or "")[:60], "Source log": r["source_name"],
                           "Updated": r["updated_at"]} for r in rows])
    st.dataframe(table, hide_index=True, use_container_width=True)
    sel = st.selectbox("Open incident", [r["incident_id"] for r in rows],
                       format_func=lambda x: next(f"{x} · {r['risk_level']} · {r['source_ip']} · {r['status']}"
                                                  for r in rows if r["incident_id"] == x))
    inc = im.get(sel)
    d = inc["details"]
    st.markdown(f'<div class="incident-card">{risk_badge(inc["risk_level"])} &nbsp;<b>{esc(inc["incident_type"])}</b>'
                f' · score {inc["risk_score"]}/100 · <span class="mono">{esc(sel)}</span><br>'
                f'Source: <b>{esc(inc["source_ip"])}</b> · usernames: {esc(", ".join(inc["usernames"]))}<br>'
                f'Failed attempts: {inc["failed_attempts"]} · successful logins: {inc["successful_logins"]} · '
                f'{esc(inc["first_seen"])} → {esc(inc["last_seen"])}</div>', unsafe_allow_html=True)
    st.markdown("**Reasons:** " + "; ".join(inc["reasons"]))
    if d.get("success_details"):
        st.error("Successful login(s): " + "; ".join(d["success_details"]))
    st.markdown("**Recommended defensive actions (manual):**")
    for r in d.get("recommendations", []):
        st.markdown(f"- {r}")
    st.markdown("**Example log lines:**")
    st.code("\n".join(d.get("sample_messages", [])), language="text")
    st.markdown("---")
    c = st.columns([1, 1, 2])
    new_status = c[0].selectbox("Set status", INCIDENT_STATUSES, index=INCIDENT_STATUSES.index(inc["status"]))
    analyst = c[1].text_input("Analyst", ss().get("analyst", "analyst"))
    note = c[2].text_area("Analyst note", "", max_chars=2000)
    if st.button("Save status and note"):
        ok = im.set_status(sel, new_status, note, analyst)
        ss()["analyst"] = analyst
        if ok:
            LOG.info("incident %s -> %s by %s", sel, new_status, analyst)
            st.success(f"Saved: {sel} is now {new_status}.")
            inc = im.get(sel)
        else:
            st.error("Incident not found.")
    if inc["notes"]:
        st.markdown("**History**")
        st.dataframe(pd.DataFrame(inc["notes"]), hide_index=True, use_container_width=True)


def page_reports(parsed, res, im):
    header("Reports and Downloads", parsed)
    if parsed is None:
        return no_data()
    incs = im.merged(res)
    name = ss().get("source_name", "log")
    stem = f"bruteforce_{Path(name).stem}_{datetime.now():%Y%m%d_%H%M}"
    st.markdown(f"Reports are built from the current analysis of **{esc(name)}**: {res.metrics['total_events']} events, "
                f"{len(incs)} incidents, {res.metrics['suspicious_ips']} suspicious IPs." +
                (" The source is **synthetic** and the PDF says so." if parsed.synthetic else ""))
    c = st.columns(3)
    c[0].download_button("Incidents CSV", incidents_csv(incs), f"{stem}_incidents.csv", "text/csv")
    c[1].download_button("Suspicious IPs CSV", suspicious_ips_csv(res), f"{stem}_suspicious_ips.csv", "text/csv")
    if c[2].button("Build PDF report"):
        ss()["pdf"] = (pdf_report(res, incs, name, parsed.synthetic), f"{stem}_report.pdf")
    if ss().get("pdf"):
        data, fname = ss()["pdf"]
        st.download_button("Download PDF security report", data, fname, "application/pdf")
    st.markdown("**Preview: incidents**")
    st.dataframe(incident_frame(incs), hide_index=True, use_container_width=True)


def page_config(parsed, res, im):
    header("Detection Configuration", parsed)
    st.markdown("Thresholds are set in the **sidebar** and apply immediately to every page.")
    cfg = res.config if res is not None else DetectionConfig().to_dict()
    st.dataframe(pd.DataFrame([{"setting": k, "value": v} for k, v in cfg.items()]), hide_index=True,
                 use_container_width=True)
    if st.button("Reset to defaults (5 / 5 min / 10 / 20)"):
        ss()["cfg"] = DetectionConfig().to_dict()
        for k in ("cfg_max", "cfg_win", "cfg_high", "cfg_crit", "cfg_mu", "cfg_di", "cfg_saf", "cfg_la", "cfg_fast"):
            ss().pop(k, None)
        st.rerun()
    st.markdown("#### How the risk score is calculated")
    st.markdown(f"""
| Failed attempts in the incident | Base category | Base points |
|---|---|---|
| 1 – {cfg['max_failed_attempts'] - 1} | Low | {BASE['Low']} |
| {cfg['max_failed_attempts']} – {cfg['high_risk_threshold'] - 1} | Medium | {BASE['Medium']} |
| {cfg['high_risk_threshold']} – {cfg['critical_risk_threshold'] - 1} | High | {BASE['High']} |
| {cfg['critical_risk_threshold']}+ | Critical | {BASE['Critical']} |

Indicators add points: multiple usernames **+10** (+5 more for twice as many), attempts concentrated
(mean gap ≤ {cfg['fast_attempt_seconds']} s) **+10**, successful login after failures **+25**, repeated
episodes from the same IP **+10**, mostly non-existent usernames **+5**, many source IPs **+10**.
Score is capped at 100. Category from the score: 0–24 Low · 25–49 Medium · 50–74 High · 75–100 Critical.
""")
    st.markdown(f'<div class="heuristic-note">{esc(DISCLAIMER)}</div>', unsafe_allow_html=True)
    with st.expander("Danger zone: clear the incident database"):
        st.warning("Deletes all stored incidents, statuses and notes.")
        if st.checkbox("I understand") and st.button("Clear incident database"):
            im.db.delete_all()
            ss().pop("synced_key", None)
            st.success("Incident database cleared.")


PAGE_FUNCS = dict(zip(PAGES, [page_overview, page_analyzer, page_detection, page_ips, page_incidents, page_reports,
                              page_config]))


def main():
    st.set_page_config(page_title="Brute Force Detection", page_icon="🛡️", layout="wide")
    if CSS_FILE.exists():
        st.markdown(f"<style>{CSS_FILE.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)
    st.sidebar.markdown("## 🛡️ Brute Force Detection")
    page = st.sidebar.radio("Navigation", PAGES, key="page")
    db = get_db()
    im = IncidentManager(db)
    parsed = sidebar_source()
    cfg = sidebar_config()
    res = run_detection(parsed, cfg, im) if parsed is not None else None
    if not HAVE_PLOTLY:
        st.sidebar.warning("plotly not installed - basic charts are used")
    PAGE_FUNCS[page](parsed, res, im)
    auto = ss().get("_auto")
    if ss().get("source") == SOURCES[2] and auto and auto[0]:
        time.sleep(float(auto[1]))
        ss()["monitor"].refresh()
        st.rerun()


if __name__ == "__main__":
    main()
