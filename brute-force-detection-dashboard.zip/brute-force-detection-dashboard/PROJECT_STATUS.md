# Project Status: what was verified, and what was not

Build environment: Ubuntu 24.04 container, Python 3.13, pandas 3.0.5, reportlab 4, no internet.

## Verified by running it

| Item | Evidence |
|---|---|
| 119 automated tests pass | `python -m pytest -q` → `119 passed` (`sample_output/test_results.txt`) |
| Parser: syslog, ISO prefix, IPv6, CSV, malformed lines, duplicate-line merging | `tests/test_log_parser.py` |
| Sliding-window detection, thresholds, all 7 rules | `tests/test_detector.py` |
| Each synthetic scenario yields exactly its expected incident | `test_sample_scenarios` |
| Demos 1–6 | `python run_demos.py` → all PASS (`sample_output/demo_results.txt`) |
| Incident status and notes persist after a restart | Demo 5, plus `test_incidents_persist_across_restart` |
| Live monitoring reads only new lines and handles rotation and truncation | `sample_output/monitoring_demo.txt`, monitoring tests |
| CSV and PDF reports from real analysis | `sample_output/*.csv`, `security_incident_report.pdf` (4 pages), `screenshots/07_*` |
| Terminal tool | `sample_output/cli_analyze_auth_log.txt` |

## Not verified (honest gaps)

| Item | Status |
|---|---|
| **The Streamlit dashboard in a real browser** | Streamlit and Plotly could not be installed here (no network). All 7 pages were run with stand-in modules (`tests/test_app_smoke.py`), both with and without Plotly. That covers upload, thresholds, status saving across a restart, downloads, monitoring and clearing the database. These tests caught and fixed two real bugs: a duplicate chart argument and two widgets sharing the label "Status". They cannot catch layout or visual problems. **There are no dashboard screenshots. Take them after `pip install -r requirements.txt`.** |
| Real production `auth.log` files | Only synthetic logs plus hand-written test lines were analysed. Real logs may contain sshd message variants that are not recognised. They are counted as "unrelated" rather than crashing. |
| Windows 10/11 | Not run. The code is pure Python with no OS-specific calls apart from file paths. |
| Python 3.11 / 3.12 | Run on 3.13 only. No 3.13-only features are used. |

## Notes

- All sample data is **synthetic**. Every file starts with a `# SYNTHETIC` header, the dashboard shows a banner, and the PDF prints a warning.
- `database/incidents.db` in the ZIP contains the incidents from the demo run. One of them is set to *Investigating* with a note (Demo 5). Delete the file to start empty.
- The sample timestamps are fixed to 8 Nov 2026 so that the outputs are reproducible.
