"""helpers.py - upload validation, formatting and logging helpers."""
from __future__ import annotations

import html
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import LOG_FILE, MAX_UPLOAD_MB, RISK_COLORS

ALLOWED_EXT = {".log", ".txt", ".csv", ""}      # auth.log, secure, auth.log.1 have no/odd suffixes


class UploadError(ValueError):
    pass


def validate_upload(name: str, data: bytes, max_mb: float = MAX_UPLOAD_MB) -> None:
    """Reject files that are too big, empty, compressed or binary. Raises UploadError with a readable reason."""
    if not data:
        raise UploadError("the file is empty")
    if len(data) > max_mb * 1024 * 1024:
        raise UploadError(f"the file is larger than {max_mb} MB")
    suffix = Path(name).suffix.lower()
    if suffix in (".gz", ".zip", ".bz2", ".xz", ".7z"):
        raise UploadError("compressed files are not supported - decompress first (e.g. zcat auth.log.2.gz > auth2.log)")
    if suffix not in ALLOWED_EXT and not suffix[1:].isdigit():     # allow auth.log.1
        raise UploadError(f"unsupported file type '{suffix}' - upload a .log, .txt or .csv file")
    sample = data[:8192]
    if b"\x00" in sample:
        raise UploadError("the file looks binary (contains NUL bytes) - is it a journald .journal file? "
                          "Export it with: journalctl -u ssh --no-pager > ssh.log")
    if sample.count(b"\n") == 0 and len(data) > 4096:
        raise UploadError("no line breaks found - not a text log")


def fmt_ts(ts) -> str:
    if ts is None:
        return "-"
    try:
        return ts.strftime("%Y-%m-%d %H:%M:%S")
    except AttributeError:
        return str(ts)


def fmt_duration(seconds) -> str:
    if seconds is None:
        return "-"
    s = int(round(float(seconds)))
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60:02d}s"
    return f"{s // 3600}h {(s % 3600) // 60:02d}m"


def risk_badge(level: str) -> str:
    color = RISK_COLORS.get(level, "#64748b")
    return f'<span class="risk-badge" style="background:{color}">{html.escape(level)}</span>'


def esc(v) -> str:
    return html.escape("" if v is None else str(v))


def get_logger() -> logging.Logger:
    log = logging.getLogger("bfd")
    if not log.handlers:
        Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        h = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log
