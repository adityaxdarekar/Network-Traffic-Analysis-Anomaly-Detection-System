"""
report_generator.py - CSV and PDF reports built ONLY from analysed data.

  incidents_csv(result_or_rows)  -> bytes
  suspicious_ips_csv(result)     -> bytes
  pdf_report(result, ...)        -> bytes (reportlab)

The PDF contains: project title, generation timestamp, analysed source,
total events, failed / successful counts, suspicious IPs, severity
breakdown, detailed incident descriptions and recommended defensive
actions, plus the heuristic disclaimer. If the analysed log was synthetic,
the report says so on the first page.
"""
from __future__ import annotations

import csv
import html
import io
from datetime import datetime

from config import APP_TITLE, RISK_LEVELS
from detector.risk_scoring import DISCLAIMER
from utils.helpers import fmt_duration, fmt_ts

INCIDENT_COLS = ["incident_id", "incident_type", "risk_level", "risk_score", "status", "source_ip", "usernames",
                 "failed_attempts", "successful_logins", "first_seen", "last_seen", "duration", "peak_window_attempts",
                 "reasons", "analyst_notes"]


def _safe(v) -> str:
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s     # CSV formula-injection guard


def incidents_csv(incidents: list[dict]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(INCIDENT_COLS)
    for i in incidents:
        w.writerow([_safe(x) for x in [
            i["incident_id"], i["incident_type"], i["risk_level"], i["risk_score"], i.get("status", "Open"),
            i["source_ip"], "; ".join(i["usernames"]), i["failed_attempts"], i["successful_logins"],
            fmt_ts(i["first_seen"]), fmt_ts(i["last_seen"]), fmt_duration(i.get("duration_s")),
            i.get("peak_window_attempts"), " | ".join(i["reasons"]), i.get("analyst_notes", "")]])
    return buf.getvalue().encode("utf-8")


def suspicious_ips_csv(result) -> bytes:
    df = result.suspicious_ips.copy()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(list(df.columns))
    for row in df.itertuples(index=False):
        w.writerow([_safe(fmt_ts(v) if hasattr(v, "strftime") else v) for v in row])
    return buf.getvalue().encode("utf-8")


def pdf_report(result, incidents: list[dict] | None = None, source_name: str = "", synthetic: bool = False) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import CondPageBreak, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    incidents = incidents if incidents is not None else result.incidents
    m = result.metrics
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=16, leading=20, textColor=colors.HexColor("#0f172a"))
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12.5, textColor=colors.HexColor("#b91c1c"), spaceBefore=10)
    h3 = ParagraphStyle("h3", parent=ss["Heading3"], fontSize=10.5, spaceBefore=6, spaceAfter=2)
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10, textColor=colors.HexColor("#475569"))
    mono = ParagraphStyle("m", parent=body, fontName="Courier", fontSize=7, leading=9)
    warn = ParagraphStyle("w", parent=body, textColor=colors.HexColor("#92400e"), backColor=colors.HexColor("#fef3c7"),
                          borderPadding=4)
    e = lambda v: html.escape("" if v is None else str(v))   # noqa: E731
    level_color = {"Low": "#16a34a", "Medium": "#ca8a04", "High": "#ea580c", "Critical": "#dc2626"}

    def table(head, rows, widths, style_extra=()):
        data = [[Paragraph(f"<b>{e(h)}</b>", small) for h in head]] + \
               [[Paragraph(e(c), small) for c in r] for r in (rows or [["None"] + [""] * (len(head) - 1)])]
        t = Table(data, colWidths=[w * mm for w in widths], repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                               ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#cbd5e1")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"), *style_extra]))
        return t

    st = [Paragraph(e(APP_TITLE), h1), Paragraph("Security Incident Report", h3),
          Paragraph(f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S} &middot; Source analysed: {e(source_name or '-')}",
                    body)]
    if synthetic:
        st.append(Spacer(1, 4))
        st.append(Paragraph("SYNTHETIC DATA: the analysed log was generated for demonstration. The IP addresses are "
                            "RFC 5737 documentation addresses and the activity is not real.", warn))
    st += [Paragraph("1. Summary", h2),
           table(["Metric", "Value"], [
               ["Total analysed authentication events", m["total_events"]],
               ["Failed login attempts", m["failed_attempts"]],
               ["Successful logins", m["successful_logins"]],
               ["Unique source IPs", m["unique_ips"]],
               ["Suspicious IP addresses", m["suspicious_ips"]],
               ["Detected incidents", m["incidents"]],
               ["Successful logins after failures", m["success_after_failures"]],
               ["Log time range", f"{fmt_ts(m['first_event'])}  to  {fmt_ts(m['last_event'])}"]], [80, 95]),
           Paragraph("2. Incident severity breakdown", h2)]
    counts = {lv: sum(1 for i in incidents if i["risk_level"] == lv) for lv in RISK_LEVELS}
    st.append(table(["Critical", "High", "Medium", "Low"],
                    [[counts["Critical"], counts["High"], counts["Medium"], counts["Low"]]], [43] * 4))
    cfg = result.config
    st.append(Paragraph(f"Detection settings: {cfg['max_failed_attempts']} failures within "
                        f"{cfg['time_window_minutes']} min flags an IP; High at {cfg['high_risk_threshold']}, Critical at "
                        f"{cfg['critical_risk_threshold']} failures; multiple-username rule at "
                        f"{cfg['multi_user_threshold']} usernames; distributed rule at {cfg['distributed_ip_threshold']} IPs.",
                        small))
    st.append(Paragraph("3. Suspicious IP addresses", h2))
    ips = result.suspicious_ips
    st.append(table(["IP address", "Failed", "Success", "Users", "First seen", "Last seen", "Score", "Level"],
                    [[r.ip_address, r.total_failed_attempts, r.successful_logins, r.usernames_targeted,
                      fmt_ts(r.first_detected), fmt_ts(r.last_detected), r.risk_score, r.risk_level]
                     for r in ips.itertuples()], [30, 15, 17, 13, 32, 32, 14, 21]))
    st.append(CondPageBreak(70 * mm))
    st.append(Paragraph("4. Incident details", h2))
    if not incidents:
        st.append(Paragraph("No incidents were detected with the current settings. This does not prove that no "
                            "attack happened - only that no pattern crossed the thresholds.", body))
    for n, i in enumerate(incidents, 1):
        col = level_color.get(i["risk_level"], "#334155")
        block = [Paragraph(f'{n}. <font color="{col}"><b>[{e(i["risk_level"]).upper()} {i["risk_score"]}/100]</b></font> '
                           f'{e(i["incident_type"])} &middot; {e(i["incident_id"])}', h3),
                 table(["Field", "Value"], [
                     ["Source IP(s)", i["source_ip"] if not i["incident_type"].startswith("Distributed")
                      else ", ".join(i["source_ips"])],
                     ["Targeted usernames", ", ".join(i["usernames"])[:400]],
                     ["Failed attempts", f"{i['failed_attempts']} (peak {i['peak_window_attempts']} in one window)"],
                     ["Successful logins", i["successful_logins"]],
                     ["First / last activity", f"{fmt_ts(i['first_seen'])}  /  {fmt_ts(i['last_seen'])} "
                                               f"({fmt_duration(i['duration_s'])})"],
                     ["Status", i.get("status", "Open")],
                     ["Analyst notes", i.get("analyst_notes") or "-"]], [40, 135]),
                 Paragraph("<b>Why it was flagged:</b> " + e("; ".join(i["reasons"])), body),
                 Paragraph("<b>Score:</b> " + e(" + ".join(f"{b['factor']} ({b['points']})" for b in i["score_breakdown"]))
                           + f" = {i['risk_score']}", small)]
        if i.get("success_details"):
            block.append(Paragraph("<b>Successful login(s):</b> " + e("; ".join(i["success_details"])), body))
        block.append(Paragraph("<b>Example log lines:</b>", small))
        block += [Paragraph(e(msg[:180]), mono) for msg in i["sample_messages"][:3]]
        block.append(Paragraph("<b>Recommended defensive actions:</b>", body))
        block += [Paragraph("&bull; " + e(r), body) for r in i["recommendations"]]
        st.append(KeepTogether(block[:3]))
        st += block[3:] + [Spacer(1, 6)]
    st += [Paragraph("5. General recommendations", h2)]
    for r in ["Disable password authentication for SSH where possible and use keys or MFA.",
              "Disable direct root login (PermitRootLogin no) and remove unused accounts.",
              "Restrict SSH exposure with firewall allow-lists or a VPN; use fail2ban or similar with care.",
              "Forward authentication logs to a central SIEM and alert on the same patterns in real time.",
              "Blocking is a manual decision: confirm an address is not your own scanner, monitoring or a shared NAT "
              "before blocking it. This tool does not block or contact any system."]:
        st.append(Paragraph("&bull; " + e(r), body))
    st += [Spacer(1, 8), Paragraph(e(DISCLAIMER), small)]

    def footer(c, d):
        c.saveState()
        c.setFont("Helvetica", 7)
        c.drawString(15 * mm, 8 * mm, f"Brute Force Detection Dashboard - security incident report - page {d.page}"
                     + (" - SYNTHETIC DATA" if synthetic else ""))
        c.restoreState()

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=14 * mm,
                      title="Brute Force Incident Report").build(st, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
