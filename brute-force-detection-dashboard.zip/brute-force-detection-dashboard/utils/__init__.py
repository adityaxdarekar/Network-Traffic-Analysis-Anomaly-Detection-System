"""Utilities: reports, sample log generator, helpers."""
