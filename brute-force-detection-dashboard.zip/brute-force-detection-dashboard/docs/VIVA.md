# Viva Questions and Answers (30)

### Brute-force attacks

**1. What is a brute-force attack?**
An attacker systematically tries many passwords (or username/password pairs) until one works. Against SSH, automated tools try thousands of combinations. MITRE ATT&CK lists it as T1110.

**2. What is the difference between brute force, password spraying and credential stuffing?**

| Attack | What it does | Pattern in the log |
|---|---|---|
| Brute force | Many passwords against one account | Many failures on one username |
| Password spraying | A few common passwords against *many* accounts | Many usernames, few attempts each (our multi-username rule) |
| Credential stuffing | Username/password pairs leaked from other sites | Varied usernames, sometimes successful logins |

**3. Why is a successful login after many failures important?**
It may mean the attacker finally guessed the password. That turns an *attempted* attack into a *possible compromise*, so the project adds +25 points and highlights it in red.

**4. What is a distributed brute-force attack and how do you detect it?**
The attempts come from many IPs (a botnet), so no single IP crosses the per-IP threshold. We detect it per *username*: at least 5 failures within one window, coming from at least 3 different IPs.

### Authentication logs and SSH

**5. What is SSH?**
Secure Shell is an encrypted protocol, usually on TCP port 22, for remote login and command execution. OpenSSH's server is `sshd`.

**6. Where are SSH authentication logs stored?**
- Debian, Ubuntu and Kali: `/var/log/auth.log`.
- RHEL, CentOS and Fedora: `/var/log/secure`.
- On systemd systems you can also use `journalctl -u ssh` (or `-u sshd`).

**7. What does a failed SSH login look like in auth.log?**
`Nov  8 10:12:09 host sshd[2190]: Failed password for root from 203.0.113.45 port 47731 ssh2`. The line contains the timestamp, host, process and PID, the result, the username, the source IP and the port.

**8. Why does one failed attempt produce several log lines, and how did you handle it?**
PAM logs an "authentication failure", sshd logs "Invalid user" for unknown accounts, and then sshd logs "Failed password". All of them come from the same sshd PID. We count only the "Failed …" line and keep the others as supporting evidence. Otherwise every attack would look two to three times larger.

**9. What does "Invalid user" mean?**
The username does not exist on the server. Many invalid users from one IP means the attacker is guessing names, which adds +5 points in our scoring.

### IP addresses

**10. What is an IP address, and why do the samples use 192.0.2.x, 198.51.100.x and 203.0.113.x?**
An IP address identifies a network interface. Those three ranges are reserved for documentation by RFC 5737 and are never routed on the Internet. The synthetic attackers therefore cannot be confused with, or accidentally implicate, real hosts.

**11. Why shouldn't you automatically block every flagged IP?**
- The address might be your own scanner, a monitoring system, a VPN, or a shared NAT carrying many legitimate users.
- Attackers can rotate IPs, so blocking alone doesn't stop a distributed attack.
- Wrong blocks cause outages.

The tool recommends actions, and the analyst decides.

### SIEM and SOC

**12. What is a SIEM?**
Security Information and Event Management. It collects logs from many sources, normalises them, correlates events with rules, alerts, and stores data for investigation. Examples are Splunk, Elastic Security, Wazuh and Microsoft Sentinel. This project is a small, single-source version of the same idea.

**13. What is a SOC, and what does an analyst do with an incident?**
A Security Operations Centre monitors and responds to security events. The workflow is triage (is it real?), investigation (scope and impact), containment, eradication, recovery and lessons learned (NIST SP 800-61). Our Open, Investigating and Resolved statuses and the notes support the first stages.

**14. What recommendations does the tool give?**
- Verify who owns the IP.
- Consider a manual firewall rule or fail2ban jail.
- Use SSH keys instead of passwords (`PasswordAuthentication no`).
- Disable direct root login.
- Use MFA.
- If a success followed the failures: review the session, reset the password and revoke sessions.

### Detection thresholds, false positives and time windows

**15. What are the default detection thresholds?**
- Flag an IP at 5 failed attempts within 5 minutes.
- High risk at 10 failures; Critical at 20.
- Extra rules: 3 usernames from one IP; 3 IPs against one username; a success after at least 3 failures within 30 minutes.

All of them can be changed in the sidebar.

**16. What is a false positive? Give an example from this project.**
An alert on benign activity. For example:
- A user mistypes a password three times and then logs in. This produces a Medium "success after repeated failures" incident.
- An office behind one NAT IP where several users mistype in the same few minutes can trigger the multi-username rule.

**17. What is a false negative?**
An attack that isn't detected. For example, a "low and slow" attacker trying once every 10 minutes never puts 5 failures in a 5-minute window.

**18. Why use a time window instead of counting all failures in the file?**
Counting the whole file would flag a user with 6 typos spread over a week, and it would treat a 15-attempts-in-2-minutes burst the same as 15 attempts over a month. A window measures *rate*, which is what distinguishes automation from human error. Demo 1 shows 6 failures over 2.5 hours that are correctly *not* flagged.

**19. How does the sliding window algorithm work?**
Failures are sorted by time. For each start index `i`, a second pointer `j` advances while `t[j] − t[i] ≤ window`, so `j − i` is the count in that window. Both pointers only move forward, which makes the scan O(n) per IP. Overlapping qualifying windows are merged into one episode, so one attack gives one incident.

**20. What is the difference between a sliding window and a fixed window?**
Fixed windows (10:00–10:05, 10:05–10:10 …) can split a burst across a boundary: 4 attempts at 10:04 and 4 at 10:06 never show 5 in one bucket. A sliding window starts at every event, so it never misses a burst.

### Risk scoring

**21. How is the risk score calculated?**
- Base points come from the number of failures: 15, 35, 55 or 75 for the Low, Medium, High and Critical tiers.
- Indicators add points:
  - multiple usernames +10 (+5);
  - concentrated attempts +10;
  - success after failures +25;
  - repeated episodes +10;
  - non-existent usernames +5;
  - many IPs +10.
- The total is capped at 100. The bands are 0–24 Low, 25–49 Medium, 50–74 High and 75–100 Critical.

**22. Why is the score called heuristic and not proof?**
The points are rule-of-thumb weights, not probabilities learned from labelled data. The same pattern can come from a forgotten password, a broken script, or an authorised penetration test. The score ranks what an analyst should look at first.

**23. Why do 15 failures score 65 (High) and not just 55?**
15 failures put the incident in the High tier (55). The attempts came about 8 seconds apart, which is faster than a person can type, so the "concentrated" indicator adds 10.

### Streamlit, Python log processing and SQLite

**24. What is Streamlit and why use it?**
A Python framework that turns a script into a web app. Each interaction re-runs the script top to bottom, and `st.session_state` keeps values between runs. It lets a security analyst build an interactive dashboard without writing HTML or JavaScript.

**25. How did you avoid saving the same analysis many times when Streamlit re-runs the script?**
We hash the source and settings into a key stored in `session_state`. Incidents are synced to SQLite only when that key changes. The upsert also uses a stable incident ID, so duplicates are impossible.

**26. How are the logs parsed in Python?**
- Regular expressions match the syslog prefix (month, day, time, host, process, PID) and then the sshd message (Failed, Accepted, Invalid user, pam_unix, and so on).
- IPs are validated with the `ipaddress` module.
- The CSV path uses `csv.DictReader` with column aliases and `pandas.to_datetime`.

**27. How does the program handle malformed log lines?**
Every line is processed inside error handling. A bad timestamp, an invalid IP, binary data, an oversized line or an unknown format is counted, stored with its line number and reason, and skipped. The rest of the file is still analysed, and the dashboard lists the skipped lines.

**28. Why SQLite, and how is it used safely?**
SQLite is a serverless, file-based relational database included with Python, which makes it ideal for a single-user tool.
- All queries are parameterised (`?` placeholders), which prevents SQL injection; a test passes `'; DROP TABLE incidents; --` as a search.
- A CHECK constraint restricts status values.
- Notes are sanitised and length-limited.

**29. How does incident status survive a restart?**
The status and notes are stored in `database/incidents.db`. When the same log is analysed again, the same incident ID is produced (a hash of type, IP and first timestamp). The upsert updates the detection fields but deliberately never touches status or notes. Demo 5 proves this.

**30. How does live monitoring avoid re-processing the same lines?**
`LogTailer` stores the byte offset it has read up to. Each refresh seeks to that offset and reads only the new bytes. An incomplete last line is buffered until its newline arrives. If the file shrinks or its inode changes (log rotation), reading restarts from the beginning of the new file.
