# Brute Force Attack Detection and Monitoring Dashboard Using Python and Streamlit
### College Project Report

---

## 1. Abstract

Brute-force and password-guessing attacks against SSH are among the most common attacks on Internet-facing servers. Every attempt leaves traces in the system's authentication log. This project implements a defensive monitoring tool in Python that:

- parses Linux SSH authentication logs and standardised CSV logs;
- detects brute-force behaviour using sliding time windows;
- identifies suspicious IP addresses and targeted usernames;
- flags successful logins that follow repeated failures;
- detects distributed attacks on a single account;
- assigns each incident an explainable 0–100 risk score.

Incidents are stored in SQLite with an analyst workflow (Open, Investigating, Resolved, plus notes). They are presented on a seven-page Streamlit dashboard with Plotly charts and exported as CSV and PDF reports.

A synthetic log generator supplies reproducible demonstration data. Six demonstration scenarios produced the expected results, and 119 automated tests pass. The tool only reads logs: it never attempts logins, cracks passwords or blocks addresses.

## 2. Problem Statement

A public SSH server typically receives thousands of failed logins per day. Reading raw `auth.log` files manually is slow and error-prone:

- one failed attempt produces two or three log lines;
- attacks are spread over time and across many IP addresses;
- the most important event, a *successful* login after many failures, is easily lost among thousands of lines.

Simple tools that count failures per IP over a whole file either flag ordinary users who mistype passwords or miss slow and distributed attacks.

The problem is to build an understandable system that detects brute-force patterns **in time**, explains why it flagged them, supports an analyst's investigation, and does so safely, without interfering with any system.

## 3. Project Objectives

1. Parse Linux SSH authentication logs and CSV logs, extracting timestamp, IP, username, status, event type and the original message, and handle malformed input gracefully.
2. Detect repeated failed logins using configurable sliding time windows (defaults: 5 failures within 5 minutes; High at 10; Critical at 20).
3. Identify suspicious IPs, targeted usernames, multi-username attacks, successful logins after failures, and distributed attacks on one username.
4. Calculate an explainable risk score out of 100, with a category and reasons.
5. Store incidents, statuses and notes persistently in SQLite.
6. Provide a professional SOC-style Streamlit dashboard with interactive charts.
7. Offer optional incremental real-time monitoring of a local log file.
8. Generate CSV and PDF reports from real analysis results.
9. Provide synthetic data for safe, repeatable demonstrations.

## 4. Existing System

| Existing approach | Limitation |
|---|---|
| Manual `grep "Failed password" /var/log/auth.log` | No time context, no scoring, no history, hard to share |
| `lastb` / `last` | Shows failed/successful logins, no pattern detection |
| fail2ban | Automatically blocks IPs; little visibility and no investigation workflow; can lock out legitimate users |
| SIEM (Splunk, Elastic, Wazuh) | Powerful but heavy to deploy and configure for a student or small team |
| Logwatch-style daily summaries | Daily totals only; no per-attack timeline or real-time view |

## 5. Proposed System

A lightweight, modular Python application that:

- accepts a bundled synthetic log, an uploaded log, or a monitored local log file;
- normalises events and merges duplicate lines that describe the same attempt;
- runs seven detection rules on sliding windows;
- scores each incident with transparent points;
- keeps an analyst-managed incident register in SQLite;
- visualises everything and exports reports.

It recommends defensive actions but never takes them automatically.

## 6. Hardware and Software Requirements

| Hardware | Minimum | Recommended |
|---|---|---|
| CPU | Dual-core | Quad-core |
| RAM | 2 GB | 4 GB |
| Disk | 200 MB | 1 GB (large logs) |
| Network | Not needed (localhost dashboard) | — |

| Software | Version |
|---|---|
| OS | Kali Linux, Ubuntu 22.04/24.04, Windows 10/11 |
| Python | 3.11+ (tested on 3.13) |
| Streamlit | 1.32+ |
| Pandas | 2.x (tested 3.0) |
| Plotly | 5.18+ |
| reportlab | 4.x |
| SQLite | bundled with Python |
| pytest | 7+ |

## 7. System Architecture

The system has five layers:

1. **Input layer.** `sample_logs/`, the upload widget with validation, and `LogTailer` for monitoring.
2. **Parsing layer.** `log_parser.py` uses regular expressions to turn lines into `AuthEvent` records.
3. **Analysis layer.** `brute_force_detector.py` (rules) and `risk_scoring.py` (scores and recommendations).
4. **Persistence layer.** `incident_manager.py` and `db_manager.py` (SQLite).
5. **Presentation layer.** `app.py` (Streamlit and Plotly), `analyze.py` (terminal) and `report_generator.py` (CSV and PDF).

```
 Inputs ──► Parser ──► Detector ──► Risk scorer ──► Incident manager ⇄ SQLite
                                         │                   │
                                         └──────► Dashboard / CLI / Reports
```

## 8. Module Descriptions

- **config.py** holds `DetectionConfig` with nine settings and validation (types, ranges, and the ordering max < high < critical).
- **log_parser.py**:
  - regexes for the classic syslog and ISO-8601 prefixes;
  - six sshd message rules;
  - expansion of `message repeated N times`;
  - IPv4 and IPv6 validation and username sanitising;
  - the CSV reader with column aliases;
  - per-PID merging of supporting lines;
  - malformed-line accounting.
- **brute_force_detector.py**:
  - a two-pointer sliding window;
  - merging of qualifying windows into episodes;
  - incident builders (single IP, success-after-failures, distributed);
  - the suspicious-IP, targeted-username and metrics tables.
- **risk_scoring.py** holds the tiered base points, the indicator points, the cap, the category bands, the reasons and the recommendations.
- **incident_manager.py** syncs results to the database while preserving analyst data, and provides filters and the status workflow.
- **log_monitor.py** reads only new bytes, keeps a partial-line buffer, and detects rotation and truncation.
- **db_manager.py** provides the schema, upsert, filters, notes history and analysis log.
- **report_generator.py** writes the CSV files (with a formula-injection guard) and the PDF report.
- **sample_log_generator.py** produces the seven synthetic scenarios, with a seed and a streaming mode.
- **helpers.py** handles upload validation, formatting and logging.
- **app.py** is the seven-page dashboard. **analyze.py** and **run_demos.py** are the terminal tools.

## 9. Data Flow Diagram

**Level 0 (context):**

```
 Analyst ──(log file, thresholds, status/notes)──► [ Brute Force Detection System ] ──(dashboard, alerts, reports)──► Analyst
                                                          ▲
                                     Server auth log ─────┘ (read-only)
```

**Level 1:**

```
 auth.log / CSV ─► 1.0 Validate & Parse ─► events ─► 2.0 Detect (windows) ─► incidents ─► 3.0 Score
                         │ malformed lines                                                │
                         ▼                                                                ▼
                    Parse report                                   4.0 Store / Update ◄─ status, notes (Analyst)
                                                                         │  ▲
                                                                         ▼  │
                                                                   D1 SQLite incidents DB
                                                                         │
                                         5.0 Visualise & Report ◄────────┘──► Dashboard, CSV, PDF
```

```mermaid
flowchart LR
  A[Log file / upload / monitored file] --> B[1. Validate & parse]
  B --> C[2. Sliding-window detection]
  C --> D[3. Risk scoring]
  D --> E[4. Incident manager]
  E <--> F[(SQLite)]
  E --> G[5. Dashboard / CLI / Reports]
  H[Analyst] -->|thresholds| C
  H -->|status & notes| E
```

## 10. Use-Case Diagram

```
                ┌──────────────────────── Brute Force Detection Dashboard ────────────────────────┐
                │  (UC1) Load sample log        (UC2) Upload log file       (UC3) Monitor local log │
 ┌─────────┐    │  (UC4) Configure thresholds   (UC5) View overview & charts                         │
 │ Analyst │────│  (UC6) Review incidents       (UC7) Inspect suspicious IP                         │
 └─────────┘    │  (UC8) Update status / add notes                                                  │
                │  (UC9) Download CSV / PDF report   (UC10) Clear incident database (confirmed)     │
                └───────────────────────────────────────────────────────────────────────────────────┘
 Generator script (secondary actor) ──► (UC11) Create synthetic logs
```

## 11. Flowchart of the Detection Algorithm

```
 START
   │ load events, keep counted failures and successes, sort by time
   ▼
 FOR each source IP ─────────────────────────────────────────────┐
   │ i = 0, j = 0                                                  │
   │ FOR each failure i: advance j while t[j] − t[i] ≤ window      │
   │   count = j − i ; users = distinct usernames in [i, j)        │
   │   IF count ≥ max_failed OR users ≥ multi_user_threshold       │
   │       mark window [i, j−1]; merge with previous if overlapping│
   │ each merged span = EPISODE ──► build incident                 │
   │   success from same IP within episode + 30 min? ─► add flag   │
   │ successes not covered: ≥3 failures in previous 30 min?        │
   │   ─► "success after repeated failures" incident               │
   └───────────────────────────────────────────────────────────────┘
   ▼
 FOR each username: sliding window over failures from all IPs
   IF count ≥ max_failed AND distinct IPs ≥ distributed_threshold ─► distributed incident
   ▼
 FOR each incident: base points (by count) + indicator points → cap 100 → category, reasons
   ▼
 sort by score → suspicious-IP table, targeted usernames, metrics → save to SQLite (keep status/notes)
   ▼
 END
```

## 12. Database Schema

| Table | Column | Type | Notes |
|---|---|---|---|
| incidents | incident_id | TEXT PK | `INC-` + SHA-1 of (type, key, first timestamp) |
| | incident_type | TEXT | e.g. "Brute force - multiple usernames" |
| | source_ip, username_key | TEXT | |
| | usernames, reasons | TEXT (JSON) | |
| | failed_attempts, successful_logins | INTEGER | |
| | first_seen, last_seen | TEXT | ISO timestamps |
| | risk_score, risk_level | INTEGER, TEXT | |
| | details | TEXT (JSON) | full incident incl. score breakdown |
| | status | TEXT | CHECK IN ('Open','Investigating','Resolved') |
| | analyst_notes | TEXT | latest note |
| | created_at, updated_at, times_detected | | |
| incident_notes | id, incident_id (FK), timestamp, analyst, status, note | | full history |
| analyses | id, timestamp, source_name, synthetic, totals, settings (JSON) | | one row per analysis |

## 13. Algorithm Explanation

**Sliding window.** Failures for one IP are sorted by time. Two pointers `i` and `j` maintain the window `[t[i], t[i] + W]`. Because both pointers only move forward, the scan is O(n) per IP after sorting. A window *qualifies* when it holds at least `max_failed_attempts` failures, or at least `multi_user_threshold` distinct usernames. Qualifying windows that overlap are merged into one episode, so a long attack becomes one incident rather than dozens.

**Duplicate-line merging.** sshd writes PAM, "Invalid user" and "Failed password" lines for one attempt, all with the same PID. Only the "Failed …" line counts. Without this, every attack would look two to three times larger.

**Success after failures.** For each successful login, the algorithm looks back over the previous `success_lookahead_minutes` from the same IP. This is the strongest indicator of a possible compromise, so it adds +25 points.

**Distributed detection.** The same window logic is applied per *username* across all IPs, requiring several distinct sources. This catches attacks deliberately kept below per-IP thresholds.

**Scoring.** The base points come from the attempt count, and indicators add to them. The result is capped at 100 and mapped to bands whose base values sit inside their own band. The categories therefore match the specification for plain counts and only rise when there are extra indicators.

## 14. Testing Methodology

| Level | What | How |
|---|---|---|
| Unit | Parser (valid, invalid, IPv6, ISO, repeated lines, merging, year rollover, CSV aliases, malformed CSV rows), upload validation | `tests/test_log_parser.py` |
| Unit | Window boundaries, thresholds, episodes, multi-username, success-after-failures, distributed, stable IDs | `tests/test_detector.py` |
| Unit | Score tiers, indicator points, cap, config validation | `tests/test_risk_scoring.py` |
| Integration | SQLite persistence across restart, filters, SQL-injection input, note sanitising, monitoring (new lines only, partial lines, rotation, truncation, missing file), reports, generator | `tests/test_risk_scoring.py` |
| Scenario | Every bundled synthetic log yields exactly its expected incident type | `tests/test_detector.py::test_sample_scenarios` |
| UI smoke | All 7 pages, upload accept and reject, thresholds, status persistence, downloads, monitoring, with and without Plotly | `tests/test_app_smoke.py` (with a stand-in for Streamlit) |
| Demonstration | Demos 1–6 end to end | `python run_demos.py` → all PASS |

Run the tests with `python -m pytest -q`. The expected output is `119 passed`.

## 15. Sample Outputs

These come from `python run_demos.py` and `python analyze.py sample_logs/auth.log`. All of it is synthetic data.

```
[CRITICAL 75/100] Brute force - multiple usernames          198.51.100.23   12 failures, 12 usernames
[HIGH 65/100]     Brute force - single username             203.0.113.45    15 failures in 1m 53s
[HIGH 65/100]     Distributed attack on one username        6 IPs           12 failures on 'backup'
[HIGH 60/100]     Brute force - successful login after failures  192.0.2.77  8 failures, then login as deploy
[MEDIUM 35/100]   Brute force - repeated failures from one IP    203.0.113.10  7 failures
Normal log (demo1_normal.log): 14 ordinary failures, 0 incidents.
```

The full outputs are in `sample_output/`. Screenshots are in `screenshots/`, and the PDF is `sample_output/security_incident_report.pdf`.

## 16. Advantages and Limitations

**Advantages**

- Time-window detection avoids flagging ordinary typos and slow failures.
- Explainable scores, with a points breakdown and plain-language reasons.
- Catches distributed attacks and highlights successful logins after failures.
- Persistent incident workflow with notes history.
- Safe by design: read-only, synthetic demo data, no automatic blocking.
- Works offline, is lightweight, and is fully tested.

**Limitations**

- Only SSH (sshd) messages and CSV logs are supported. Web logins, RDP, Windows Event Logs and FTP are not.
- Syslog lines carry no year or time zone, so the year is inferred and times are taken as written.
- The thresholds are static. The tool does not learn what is normal for a particular server.
- There is no threat-intelligence enrichment (IP reputation or geolocation).
- Large files (millions of lines) are processed in memory.
- Monitoring is polling-based and works on one file.
- Very slow attacks (one attempt every 10 minutes) stay below window thresholds by design.
- The Streamlit dashboard could not be rendered in a browser in the build environment. It was exercised through automated smoke tests only (see PROJECT_STATUS.md).

## 17. Future Enhancements

- Windows Security log (event IDs 4625/4624), web application and VPN log parsers.
- GeoIP and reputation enrichment (AbuseIPDB or MISP), opt-in and clearly labelled.
- Adaptive baselines per server and user (anomaly detection), plus "low and slow" detection over long windows.
- Alerting by e-mail, Slack or a SIEM webhook, and integration with fail2ban in *recommendation* mode.
- Multi-file and rotated-log ingestion (`.gz`), and a streaming architecture for very large logs.
- User authentication and roles for the dashboard.
- Mapping incidents to MITRE ATT&CK T1110 (Brute Force: password guessing, spraying, credential stuffing).

## 18. Conclusion

The project delivers a working, tested and explainable brute-force detection dashboard. By analysing authentication events in sliding time windows, merging duplicate log lines and combining several indicators into a transparent score, it separates real attack patterns from ordinary user mistakes. In the synthetic demonstrations, the normal log produced no incidents, and every attack scenario was identified with the expected severity, including a compromised account and a distributed attack invisible to per-IP counting. The incident register persists analyst decisions across restarts, and the reports turn the findings into documentation. The project demonstrates core SOC skills (log analysis, detection engineering, triage and reporting) while remaining strictly defensive.

## 19. References

1. OpenSSH `sshd(8)` and `sshd_config(5)` manual pages, openssh.com.
2. Linux-PAM documentation: `pam_unix(8)`.
3. RFC 5737, *IPv4 Address Blocks Reserved for Documentation*, IETF, 2010.
4. RFC 3849, *IPv6 Address Prefix Reserved for Documentation*, IETF, 2004.
5. MITRE ATT&CK, *T1110 Brute Force* (and sub-techniques T1110.001 to T1110.004).
6. NIST SP 800-92, *Guide to Computer Security Log Management*.
7. NIST SP 800-61 Rev. 2, *Computer Security Incident Handling Guide*.
8. OWASP, *Blocking Brute Force Attacks* and *CSV Injection* cheat sheets.
9. Streamlit documentation, docs.streamlit.io; Plotly Express documentation, plotly.com/python.
10. pandas documentation, pandas.pydata.org; Python `sqlite3` and `re` module documentation, docs.python.org.
11. fail2ban project documentation, fail2ban.org.
