# Practical Demonstration Guide (Kali Linux / Ubuntu)

All demos use **synthetic logs** created by `utils/sample_log_generator.py`. No SSH service is contacted and no login is attempted. The outputs below are the real output of `python run_demos.py` from the build environment (`sample_output/demo_results.txt`). Incident IDs and timestamps come from fixed seeds, so they will be identical on your machine.

## Preparation (once)

```bash
cd brute-force-detection-dashboard
source .venv/bin/activate
python -m utils.sample_log_generator      # writes sample_logs/*.log + auth_sample.csv
streamlit run app.py                      # browser: http://localhost:8501
```

The sidebar has three parts: **Navigation**, **Log source** (choose *Bundled sample log* and pick a file, or *Upload a log file*) and **Detection thresholds**, with defaults 5 / 5 min / 10 / 20.

If you want the terminal version of every demo, run `python run_demos.py`.

---

## Demo 1 — Normal authentication

**Steps:** Choose sample file `demo1_normal.log` (or upload it). Open *Security Overview*, then *Brute Force Detection*.

**Expected:**

```
events 58 | failed 14 | successful 16 | suspicious IPs 0 | incidents 0
includes 14 ordinary failures (typos and a slow series of 6 failures over 2.5 h from 10.20.3.41)
RESULT: no brute force reported - ordinary activity is not misclassified
```

The dashboard shows "No brute-force pattern crossed the thresholds".

**Explain:**
- Users typed a wrong password once or twice and then logged in.
- One account failed 6 times, but 30 minutes apart. No 5-minute window ever holds 5 failures, which is why the detector uses **time windows** rather than counting the whole file.

## Demo 2 — Brute force detection (15 failures from one IP within five minutes)

**Steps:** Sample file `demo2_brute_force.log`, then *Brute Force Detection* and *Suspicious IP Analysis*.

**Expected:**

```
[HIGH 65/100] Brute force - single username  INC-9E89278DB6
   source 203.0.113.45 | failed 15 (peak 15 in one window) | usernames: root
   first 2026-11-08 10:12:08  last 2026-11-08 10:14:01  (1m 53s)
   score: 15 failed attempt(s) -> High tier (55) + attempts every 8.1s on average (concentrated) (10)
```

**Explain:**
- 15 failures is in the High tier (10–19).
- A failure every 8 s is faster than a human types, which adds +10.
- The timeline chart shows the burst.
- Try setting *High-risk threshold* to 16 in the sidebar: the incident drops to Medium immediately.

## Demo 3 — Multiple username targeting

**Steps:** Sample file `demo3_multi_username.log`, then *Brute Force Detection*. The "Usernames targeted" table is on the same page.

**Expected:**

```
[CRITICAL 75/100] Brute force - multiple usernames  INC-0647056E19
   source 198.51.100.23 | failed 12 | usernames: admin, ftpuser, git, guest, mysql, oracle, pi, postgres, support, test, ubuntu, user
   score: 12 failed attempt(s) -> High tier (55) + 12 different usernames targeted (10) + very wide username list (5)
          + 11 non-existent usernames tried (5)
```

**Explain:**
- Trying many common account names is typical of automated scanners.
- 11 of the 12 names produced `Invalid user` lines, meaning they do not exist on the server. That is username guessing, and it raises the score into Critical.

## Demo 4 — Successful login after failures

**Steps:** Sample file `demo4_success_after_failures.log`, then *Brute Force Detection*. A red box shows the successful login.

**Expected:**

```
[HIGH 60/100] Brute force - successful login after failures  INC-75B48E6DB6
   source 192.0.2.77 | failed 8 | usernames: deploy
   score: 8 failed attempt(s) -> Medium tier (35) + successful login after the failures (25)
   ! SUCCESSFUL LOGIN after failures: 2026-11-08 14:50:55 deploy (password)
```

**Why it deserves investigation:**
- The same IP failed 8 times and then got in with a **password**. The attacker may have guessed it.
- The recommendations tell the analyst to:
  - review the session that followed (commands, sudo use, new SSH keys);
  - reset the password;
  - revoke active sessions.
- Without the success, 8 failures would only be Medium (35). The success adds +25.

## Demo 5 — Incident management and persistence

**Steps:**

1. Choose sample file `auth.log`, the mixed day with all scenarios.
2. Go to *Incident Management*, then open incident **INC-0647056E19** (Critical, 198.51.100.23).
3. Set **Set status** = *Investigating*, enter an analyst name and a note, then click **Save status and note**.
4. Stop Streamlit (Ctrl+C) and start it again with `streamlit run app.py`.
5. Open *Incident Management*. The status and note are still there, and the History table shows the change.

**Terminal equivalent (real output):**

```
INC-0647056E19 set to Investigating with a note
...closing the database (simulated application restart)...
after restart: status=Investigating note='Demo 5: 12 usernames from one TEST-NET IP; checking whether any account
exists with a weak password.' detected 2 times
```

You can also run `python analyze.py --incidents` to list stored incidents, and `python analyze.py --set-status INC-0647056E19 Resolved --note "..."` to change one.

**Explain:**
- Status and notes live in SQLite (`database/incidents.db`).
- The incident ID is derived from the attack itself, so re-analysing the same log finds the same incident.
- The upsert never overwrites the analyst's status.

## Demo 6 — Report generation

**Steps:** *Reports and Downloads*, then **Build PDF report**, **Download PDF security report** and **Suspicious IPs CSV**.

**Expected files:** see `sample_output/security_incident_report.pdf` (4 pages), `suspicious_ips.csv` and `incidents_report.csv`.

```
Suspicious IPs:
 198.51.100.23   failed  12 success 0 users 12 score  75 Critical
 203.0.113.45    failed  15 success 0 users  1 score  65 High
 192.0.2.81      failed   2 success 0 users  1 score  65 High     <- part of the distributed attack on 'backup'
 ...
 192.0.2.77      failed   8 success 1 users  1 score  60 High
 203.0.113.10    failed   7 success 0 users  2 score  35 Medium
```

**Explain the findings:**
- There are 5 incidents: 1 Critical, 3 High and 1 Medium.
- One account (`deploy`) was probably compromised.
- `backup` was attacked from 6 IPs with only 2 attempts each. Per-IP rules miss this; the per-username rule (R7) catches it.
- The PDF states that the data is synthetic and that scores are heuristics.

## Optional — live monitoring mode

```bash
# terminal 1: append SYNTHETIC lines slowly to a local file
python -m utils.sample_log_generator --scenario brute_force --stream sample_logs/live_auth.log --delay 0.5
```

Then, in the dashboard sidebar:

1. Choose *Monitor a local log file* with the path `sample_logs/live_auth.log`.
2. Tick **Auto-refresh** (every 2–10 s), or click **Refresh now**.

You will watch the incident appear and escalate. Real output from the build environment (`sample_output/monitoring_demo.txt`):

```
refresh 1: + 6 events (total  6, counted failures  2) -> no incident yet
refresh 2: +10 events (total 16, counted failures  6) -> Medium 45 Brute force - single username from 203.0.113.45
refresh 4: +10 events (total 36, counted failures 12) -> High 65 Brute force - single username from 203.0.113.45
refresh 6: + 0 events (total 45, counted failures 15) -> High 65 ...  | no new data
```

Only new bytes are read on each refresh, and log rotation and truncation are handled.

## Screenshot checklist

The dashboard screenshots must be taken by you, because Streamlit could not run in the build environment:

1. Overview with the synthetic banner.
2. Log Analyzer statistics.
3. Demo 2 incident and its timeline.
4. Demo 3 usernames.
5. Demo 4 red success box.
6. Incident Management after the restart.
7. Reports page.
8. The PDF.

Terminal and PDF screenshots are already in `screenshots/`.
