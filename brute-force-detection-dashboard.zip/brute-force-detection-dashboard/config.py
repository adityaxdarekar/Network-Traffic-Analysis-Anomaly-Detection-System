"""
config.py - detection settings, paths and validation.

All thresholds can be changed in the Streamlit sidebar (Detection
Configuration page) or passed to the CLI. Values are validated before use.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "database" / "incidents.db"
SAMPLE_DIR = BASE_DIR / "sample_logs"
REPORT_DIR = BASE_DIR / "reports"
LOG_FILE = BASE_DIR / "logs" / "app.log"
CSS_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "Brute Force Attack Detection and Monitoring Dashboard"
MAX_UPLOAD_MB = 50
MAX_LINES = 2_000_000

RISK_LEVELS = ["Low", "Medium", "High", "Critical"]
RISK_COLORS = {"Low": "#22c55e", "Medium": "#eab308", "High": "#f97316", "Critical": "#ef4444"}
INCIDENT_STATUSES = ["Open", "Investigating", "Resolved"]


@dataclass
class DetectionConfig:
    # --- the four settings named in the brief
    max_failed_attempts: int = 5          # failures inside one window that flag an IP
    time_window_minutes: float = 5.0      # sliding detection window
    high_risk_threshold: int = 10         # failures -> High
    critical_risk_threshold: int = 20     # failures -> Critical
    # --- extra rules
    multi_user_threshold: int = 3         # distinct usernames from one IP inside a window
    distributed_ip_threshold: int = 3     # distinct IPs failing against one username inside a window
    success_after_failures_min: int = 3   # failures from an IP before a success that we call suspicious
    success_lookahead_minutes: float = 30.0  # how long after the failures a success still counts
    fast_attempt_seconds: float = 10.0    # mean gap <= this inside the peak window = "concentrated"
    extra_fields: dict = field(default_factory=dict)

    def validate(self) -> list[str]:
        e = []

        def chk(name, lo, hi, integer=True):
            v = getattr(self, name)
            ok_type = isinstance(v, int) if integer else isinstance(v, (int, float))
            if isinstance(v, bool) or not ok_type or not lo <= v <= hi:
                e.append(f"{name} must be {'an integer' if integer else 'a number'} between {lo} and {hi}")

        chk("max_failed_attempts", 2, 10_000)
        chk("time_window_minutes", 0.1, 1440, integer=False)
        chk("high_risk_threshold", 2, 100_000)
        chk("critical_risk_threshold", 3, 1_000_000)
        chk("multi_user_threshold", 2, 1000)
        chk("distributed_ip_threshold", 2, 10_000)
        chk("success_after_failures_min", 1, 10_000)
        chk("success_lookahead_minutes", 0, 1440, integer=False)
        chk("fast_attempt_seconds", 0.1, 3600, integer=False)
        if not e and not (self.max_failed_attempts < self.high_risk_threshold < self.critical_risk_threshold):
            e.append("thresholds must satisfy: max failed attempts < high-risk threshold < critical-risk threshold")
        return e

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("extra_fields", None)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "DetectionConfig":
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in (d or {}).items() if k in names and k != "extra_fields"})
