"""
Smoke test for app.py with STAND-INS for Streamlit and Plotly (neither could be
installed in the build environment). It runs every page against real analysis
data so wiring mistakes are caught; it does NOT prove the real UI looks right.
"""
import importlib
import sys
import types

import pytest

from config import SAMPLE_DIR


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeUpload:
    def __init__(self, name, data):
        self.name, self._d = name, data

    def getvalue(self):
        return self._d


class FakeSt(types.ModuleType):
    current = None

    def __init__(self):
        super().__init__("streamlit")
        self.session_state, self.calls, self.clicks, self.inputs = {}, [], set(), {}
        self.sidebar = _Ctx()
        self.upload = None
        FakeSt.current = self

    def cache_resource(self, fn=None, **kw):
        return fn if fn else (lambda f: f)

    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def expander(self, *a, **kw):
        return _Ctx()

    def radio(self, label, options, **kw):
        return self.inputs.get(label, options[0])

    def selectbox(self, label, options, index=0, format_func=None, **kw):
        options = list(options)
        if format_func and options:
            format_func(options[0])
        return self.inputs.get(label, options[index] if options else None)

    def multiselect(self, label, options, default=None, **kw):
        return self.inputs.get(label, default or [])

    def number_input(self, label, lo=None, hi=None, value=None, **kw):
        return self.inputs.get(label, value)

    def text_input(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def text_area(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def checkbox(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    def button(self, label, **kw):
        return label in self.clicks

    def file_uploader(self, *a, **kw):
        return self.upload

    def download_button(self, label, data, *a, **kw):
        assert data, label
        self.calls.append(("download", label, data))
        return False

    def rerun(self):
        self.calls.append(("rerun", None))

    def __getattr__(self, name):
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


def fake_plotly():
    calls = []

    class Fig:
        def update_layout(self, **kw):
            pass

    def mk(n):
        def f(*a, **kw):
            calls.append(n)
            return Fig()
        return f
    px = types.ModuleType("plotly.express")
    for n in ("bar", "line", "pie", "scatter"):
        setattr(px, n, mk(n))
    pl = types.ModuleType("plotly")
    pl.express = px
    return pl, px, calls


@pytest.fixture(params=["plotly", "no-plotly"])
def app(request, monkeypatch, tmp_path):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    calls = []
    if request.param == "plotly":
        pl, px, calls = fake_plotly()
        monkeypatch.setitem(sys.modules, "plotly", pl)
        monkeypatch.setitem(sys.modules, "plotly.express", px)
    else:
        monkeypatch.setitem(sys.modules, "plotly", None)
        monkeypatch.setitem(sys.modules, "plotly.express", None)
    sys.modules.pop("app", None)
    mod = importlib.import_module("app")
    from database.db_manager import DBManager
    dbs = {}

    def get_db(path=None):
        if "db" not in dbs:
            dbs["db"] = DBManager(tmp_path / "incidents.db")
        return dbs["db"]
    monkeypatch.setattr(mod, "get_db", get_db)
    yield mod, fake, request.param, calls, dbs, tmp_path
    if "db" in dbs:
        dbs["db"].close()


def errors(fake):
    """Error calls, excluding the intentional red 'Successful login(s)' highlight on incidents."""
    return [c for c in fake.calls if c[0] in ("error", "exception") and not str(c[1]).startswith("Successful login(s)")]


def run_page(mod, fake, page):
    fake.inputs["Navigation"] = page
    mod.main()


def test_all_pages_with_bundled_sample(app):
    mod, fake, mode, calls, dbs, _ = app
    for page in mod.PAGES:
        run_page(mod, fake, page)
    assert not errors(fake), errors(fake)
    assert any(c[0] == "markdown" and "SYNTHETIC DATA" in str(c[1]) for c in fake.calls)
    assert len(dbs["db"].list_incidents()) == 5          # synced once despite 7 reruns
    assert dbs["db"].list_incidents()[0]["times_detected"] == 1
    if mode == "plotly":
        assert {"bar", "pie", "scatter"} <= set(calls)


def test_normal_log_shows_no_incidents(app):
    mod, fake, *_ = app
    fake.inputs["Sample file"] = "demo1_normal.log"
    run_page(mod, fake, "Brute Force Detection")
    assert any(c[0] == "success" and "No brute-force pattern" in str(c[1]) for c in fake.calls)


def test_sidebar_thresholds_change_results(app):
    mod, fake, *_ = app
    fake.inputs.update({"Sample file": "demo2_brute_force.log", "High-risk threshold (failures)": 16,
                        "Critical-risk threshold (failures)": 30})
    run_page(mod, fake, "Brute Force Detection")
    md = " ".join(str(c[1]) for c in fake.calls if c[0] == "expander" or c[0] == "dataframe")
    assert fake.session_state["cfg"]["high_risk_threshold"] == 16
    fake.inputs["Critical-risk threshold (failures)"] = 5          # invalid: critical < high
    fake.calls.clear()
    run_page(mod, fake, "Detection Configuration")
    assert any(c[0] == "error" for c in fake.calls)              # shown in sidebar, previous config kept
    assert fake.session_state["cfg"]["critical_risk_threshold"] == 30
    del md


def test_upload_valid_and_rejected(app):
    mod, fake, *_ = app
    fake.inputs["Source"] = mod.SOURCES[1]
    fake.upload = FakeUpload("auth.log", (SAMPLE_DIR / "demo3_multi_username.log").read_bytes())
    run_page(mod, fake, "Suspicious IP Analysis")
    assert not errors(fake), errors(fake)
    assert fake.session_state["source_name"] == "auth.log"
    fake.upload = FakeUpload("auth.log.gz", b"\x1f\x8b\x08")
    fake.calls.clear()
    run_page(mod, fake, "Security Overview")
    assert any(c[0] == "error" and "compressed" in str(c[1]) for c in fake.calls)


def test_incident_status_persists_after_restart(app, monkeypatch):
    mod, fake, _, _, dbs, tmp_path = app
    run_page(mod, fake, "Incident Management")
    first = dbs["db"].list_incidents()[0]["incident_id"]
    fake.inputs.update({"Open incident": first, "Set status": "Investigating", "Analyst note": "Demo 5 note", "Analyst": "me"})
    fake.clicks = {"Save status and note"}
    run_page(mod, fake, "Incident Management")
    assert any(c[0] == "success" and "Investigating" in str(c[1]) for c in fake.calls)
    # restart: drop session state and DB connection, reload the module
    dbs["db"].close()
    dbs.clear()
    fake.session_state.clear()
    fake.clicks = set()
    fake.inputs = {}
    run_page(mod, fake, "Incident Management")
    got = dbs["db"].get_incident(first)
    assert got["status"] == "Investigating" and got["analyst_notes"] == "Demo 5 note"


def test_reports_page_downloads(app):
    mod, fake, *_ = app
    fake.clicks = {"Build PDF report"}
    run_page(mod, fake, "Reports and Downloads")
    labels = {c[1] for c in fake.calls if c[0] == "download"}
    assert {"Incidents CSV", "Suspicious IPs CSV", "Download PDF security report"} <= labels
    pdf = next(c[2] for c in fake.calls if c[0] == "download" and c[1] == "Download PDF security report")
    assert pdf[:4] == b"%PDF"


def test_monitoring_mode(app):
    mod, fake, _, _, _, tmp_path = app
    live = tmp_path / "live.log"
    from utils.sample_log_generator import generate
    generate("brute_force", live)
    fake.inputs.update({"Source": mod.SOURCES[2], "Local log file path": str(live)})
    run_page(mod, fake, "Security Overview")
    assert not errors(fake), errors(fake)
    assert len(fake.session_state["monitor"].events) == 45
    fake.inputs["Local log file path"] = str(tmp_path / "missing.log")
    run_page(mod, fake, "Security Overview")
    assert "not found" in fake.session_state["monitor"].status


def test_clear_database_requires_confirmation(app):
    mod, fake, _, _, dbs, _ = app
    run_page(mod, fake, "Security Overview")
    fake.clicks = {"Clear incident database"}
    run_page(mod, fake, "Detection Configuration")
    assert dbs["db"].list_incidents()                      # not confirmed -> kept
    fake.inputs["I understand"] = True
    run_page(mod, fake, "Detection Configuration")
    assert not dbs["db"].list_incidents()
