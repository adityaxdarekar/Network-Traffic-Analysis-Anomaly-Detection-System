"""Detection engine: time windows, thresholds, multi-username, success-after-failures, distributed attacks."""
import pytest

from config import DetectionConfig, SAMPLE_DIR
from detector.brute_force_detector import analyze_events, peak_window, window_spans
from detector.log_parser import parse_file
from conftest import T0, ev


def types(res):
    return sorted(i["incident_type"] for i in res.incidents)


def test_failed_attempts_counted_per_ip(cfg):
    events = [ev(i * 10) for i in range(6)] + [ev(i * 10, ip="198.51.100.1") for i in range(2)]
    res = analyze_events(events, cfg)
    assert res.metrics["failed_attempts"] == 8
    assert [i["source_ip"] for i in res.incidents] == ["203.0.113.5"]
    assert res.incidents[0]["failed_attempts"] == 6


def test_below_threshold_not_flagged(cfg):
    assert not analyze_events([ev(i * 10) for i in range(4)], cfg).incidents


def test_exactly_threshold_flagged(cfg):
    assert len(analyze_events([ev(i * 10) for i in range(5)], cfg).incidents) == 1


def test_time_window_not_whole_file(cfg):
    """6 failures 2 minutes apart = 10 minutes: never 5 inside one 5-minute window."""
    events = [ev(i * 120) for i in range(6)]
    assert not analyze_events(events, cfg).incidents
    wide = DetectionConfig(time_window_minutes=11)
    assert analyze_events(events, wide).incidents


def test_window_boundary_inclusive(cfg):
    events = [ev(0), ev(75), ev(150), ev(225), ev(300)]        # exactly 5 minutes first->last
    assert analyze_events(events, cfg).incidents
    events[-1] = ev(301)
    assert not analyze_events(events, cfg).incidents


def test_two_separate_episodes(cfg):
    events = [ev(i * 5) for i in range(6)] + [ev(3600 + i * 5) for i in range(6)]
    res = analyze_events(events, cfg)
    assert len(res.incidents) == 2
    assert all(i["repeat_episodes"] == 2 for i in res.incidents)
    assert any("separate attack episodes" in b["factor"] for b in res.incidents[0]["score_breakdown"])
    assert len({i["incident_id"] for i in res.incidents}) == 2


def test_episode_merges_overlapping_windows(cfg):
    events = [ev(i * 30) for i in range(20)]           # 20 failures over 9.5 minutes, steady
    res = analyze_events(events, cfg)
    assert len(res.incidents) == 1
    assert res.incidents[0]["failed_attempts"] == 20
    assert res.incidents[0]["peak_window_attempts"] == 11


@pytest.mark.parametrize("n,level", [(5, "Medium"), (9, "Medium"), (10, "High"), (19, "High"), (20, "Critical")])
def test_threshold_categories_slow_attempts(cfg, n, level):
    """Attempts 25 s apart (not 'concentrated'), single user: category comes from the count alone."""
    w = DetectionConfig(time_window_minutes=60)
    res = analyze_events([ev(i * 25) for i in range(n)], w)
    assert res.incidents[0]["risk_level"] == level


def test_multiple_usernames_one_ip(cfg):
    users = ["admin", "test", "oracle", "guest"]
    events = [ev(i * 20, user=u, invalid=True) for i, u in enumerate(users)]   # only 4 failures
    res = analyze_events(events, cfg)
    assert len(res.incidents) == 1
    inc = res.incidents[0]
    assert inc["incident_type"] == "Brute force - multiple usernames"
    assert inc["usernames"] == sorted(users)
    assert inc["invalid_usernames"] == 4


def test_two_usernames_below_multi_rule(cfg):
    events = [ev(0, user="a"), ev(10, user="b")]
    assert not analyze_events(events, cfg).incidents


def test_success_after_repeated_failures_in_episode(cfg):
    events = [ev(i * 10, user="deploy") for i in range(8)] + [ev(100, user="deploy", status="success")]
    inc = analyze_events(events, cfg).incidents[0]
    assert inc["success_after_failures"] and inc["successful_logins"] == 1
    assert inc["incident_type"] == "Brute force - successful login after failures"
    assert inc["risk_score"] == 35 + 25 + 10      # medium tier + success + concentrated (10 s gaps)


def test_success_after_few_failures_separate_incident(cfg):
    events = [ev(0, user="bob"), ev(20, user="bob"), ev(40, user="bob"), ev(60, user="bob", status="success")]
    inc = analyze_events(events, cfg).incidents
    assert len(inc) == 1 and inc[0]["incident_type"] == "Successful login after repeated failures"
    assert inc[0]["risk_level"] == "Medium"


def test_normal_typo_then_success_not_flagged(cfg):
    events = [ev(0, user="alice", ip="10.0.0.5"), ev(15, user="alice", ip="10.0.0.5"),
              ev(30, user="alice", ip="10.0.0.5", status="success")]
    assert not analyze_events(events, cfg).incidents


def test_success_long_after_failures_not_linked(cfg):
    events = [ev(i * 10) for i in range(6)] + [ev(4 * 3600, status="success")]
    inc = analyze_events(events, cfg).incidents[0]
    assert not inc["success_after_failures"]


def test_distributed_attack_on_one_username(cfg):
    ips = [f"198.51.100.{n}" for n in range(1, 7)]
    events = [ev(k * 15, ip=ips[k % 6], user="backup") for k in range(12)]
    res = analyze_events(events, cfg)
    dist = [i for i in res.incidents if i["incident_type"].startswith("Distributed")]
    assert len(dist) == 1
    assert dist[0]["ip_count"] == 6 and dist[0]["failed_attempts"] == 12
    assert not [i for i in res.incidents if i["incident_type"].startswith("Brute")]   # 2 per IP each
    assert set(res.suspicious_ips["ip_address"]) == set(ips)


def test_distributed_needs_several_ips(cfg):
    events = [ev(k * 15, ip=f"198.51.100.{k % 2}", user="backup") for k in range(10)]
    res = analyze_events(events, cfg)
    assert not [i for i in res.incidents if i["incident_type"].startswith("Distributed")]


def test_info_and_supporting_events_ignored(cfg):
    events = [ev(i, etype="connection_closed", status="info") for i in range(10)]
    s = [ev(i, etype="auth_failure") for i in range(10)]
    for e in s:
        e.counts_as_attempt = False
    assert not analyze_events(events + s, cfg).incidents


def test_suspicious_ip_table_fields(cfg):
    events = [ev(i * 10, user=f"u{i % 3}") for i in range(7)] + [ev(200, status="success", user="u1")]
    df = analyze_events(events, cfg).suspicious_ips
    r = df.iloc[0]
    assert r["ip_address"] == "203.0.113.5" and r["total_failed_attempts"] == 7 and r["successful_logins"] == 1
    assert r["usernames_targeted"] == 3
    assert r["first_detected"] == T0


def test_incident_id_is_stable(cfg):
    events = [ev(i * 10) for i in range(6)]
    a = analyze_events(events, cfg).incidents[0]["incident_id"]
    b = analyze_events(list(reversed(events)), cfg).incidents[0]["incident_id"]
    assert a == b and a.startswith("INC-")


def test_invalid_config_rejected():
    with pytest.raises(ValueError):
        analyze_events([], DetectionConfig(max_failed_attempts=10, high_risk_threshold=5))


def test_window_helpers():
    from datetime import timedelta
    t = [T0 + timedelta(seconds=s) for s in (0, 10, 20, 400, 410)]
    assert window_spans(t, timedelta(minutes=5), lambda i, j: j - i >= 3) == [(0, 2)]
    assert peak_window(t, timedelta(minutes=5)) == (3, 10.0)


# ------------------------------------------------------------------ the bundled synthetic scenarios
@pytest.mark.parametrize("fname,expected", [
    ("demo1_normal.log", []),
    ("demo2_brute_force.log", ["Brute force - single username"]),
    ("demo3_multi_username.log", ["Brute force - multiple usernames"]),
    ("demo4_success_after_failures.log", ["Brute force - successful login after failures"]),
    ("demo_multiple_failed.log", ["Brute force - repeated failures from one IP"]),
    ("demo_distributed.log", ["Distributed attack on one username"]),
])
def test_sample_scenarios(fname, expected, cfg):
    res = analyze_events(parse_file(SAMPLE_DIR / fname).events, cfg)
    assert types(res) == expected


def test_demo2_fifteen_failures_high(cfg):
    inc = analyze_events(parse_file(SAMPLE_DIR / "demo2_brute_force.log").events, cfg).incidents[0]
    assert inc["failed_attempts"] == 15 and inc["source_ip"] == "203.0.113.45"
    assert inc["duration_s"] <= 300 and inc["risk_level"] == "High"


def test_mixed_log_all_scenarios(cfg):
    res = analyze_events(parse_file(SAMPLE_DIR / "auth.log").events, cfg)
    assert len(res.incidents) == 5
    assert res.metrics["total_events"] >= 100
    assert "10.20.3.41" not in set(res.suspicious_ips["ip_address"])     # slow failures stay unflagged


def test_csv_sample_matches_syslog_sample(cfg):
    a = analyze_events(parse_file(SAMPLE_DIR / "auth.log").events, cfg)
    b = analyze_events(parse_file(SAMPLE_DIR / "auth_sample.csv").events, cfg)
    assert types(a) == types(b)
    assert a.metrics["failed_attempts"] == b.metrics["failed_attempts"]
