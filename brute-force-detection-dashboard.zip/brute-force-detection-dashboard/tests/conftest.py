import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import DetectionConfig          # noqa: E402
from database.db_manager import DBManager   # noqa: E402
from detector.log_parser import AuthEvent   # noqa: E402

T0 = datetime(2026, 11, 8, 10, 0, 0)


@pytest.fixture
def cfg():
    return DetectionConfig()


@pytest.fixture
def db(tmp_path):
    d = DBManager(tmp_path / "incidents.db")
    yield d
    d.close()


def ev(sec, ip="203.0.113.5", user="root", status="failure", etype=None, invalid=False):
    """Build an AuthEvent `sec` seconds after T0."""
    etype = etype or ("accepted" if status == "success" else "failed_password")
    return AuthEvent(T0 + timedelta(seconds=sec), ip, user, status, etype, f"synthetic {etype} {user} {ip}",
                     line_no=int(sec), invalid_user=invalid)


@pytest.fixture
def make_ev():
    return ev


def syslog(sec, msg, pid=1000, host="srv"):
    t = T0 + timedelta(seconds=sec)
    return f"{t:%b} {t.day:>2} {t:%H:%M:%S} {host} sshd[{pid}]: {msg}"


@pytest.fixture
def line():
    return syslog
