"""Parsing of SSH syslog lines and CSV logs, including malformed input."""
from datetime import datetime

import pytest

from detector.log_parser import (classify_message, detect_format, parse_csv_text, parse_file, parse_syslog_lines,
                                 parse_text, valid_ip)
from utils.helpers import UploadError, validate_upload


@pytest.mark.parametrize("msg,etype,status,user,ip", [
    ("Failed password for root from 203.0.113.5 port 52144 ssh2", "failed_password", "failure", "root", "203.0.113.5"),
    ("Failed password for invalid user admin from 198.51.100.7 port 4000 ssh2", "failed_password", "failure", "admin",
     "198.51.100.7"),
    ("Failed publickey for git from 192.0.2.1 port 22 ssh2: RSA SHA256:x", "failed_password", "failure", "git", "192.0.2.1"),
    ("Accepted password for alice from 10.0.0.5 port 50000 ssh2", "accepted", "success", "alice", "10.0.0.5"),
    ("Accepted publickey for bob from 10.0.0.6 port 50001 ssh2: ED25519 SHA256:abc", "accepted", "success", "bob",
     "10.0.0.6"),
    ("Invalid user oracle from 198.51.100.9 port 1234", "invalid_user", "failure", "oracle", "198.51.100.9"),
    ("pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost=203.0.113.9  user=root",
     "auth_failure", "failure", "root", "203.0.113.9"),
    ("error: maximum authentication attempts exceeded for root from 203.0.113.9 port 1 ssh2 [preauth]",
     "max_auth_exceeded", "info", "root", "203.0.113.9"),
    ("Connection closed by authenticating user root 203.0.113.9 port 1 [preauth]", "connection_closed", "info", "root",
     "203.0.113.9"),
])
def test_classify_messages(msg, etype, status, user, ip):
    t, s, f = classify_message(msg)
    assert (t, s, f["user"], f["ip"]) == (etype, status, user, ip)


def test_non_auth_sshd_message_is_none():
    assert classify_message("Server listening on 0.0.0.0 port 22.") is None


def test_valid_syslog_extracts_fields(line):
    r = parse_syslog_lines([line(0, "Failed password for root from 203.0.113.5 port 52144 ssh2")], year=2026,
                           now=datetime(2026, 11, 9))
    e = r.events[0]
    assert e.timestamp == datetime(2026, 11, 8, 10, 0, 0)
    assert (e.source_ip, e.username, e.status, e.event_type, e.host, e.pid) == \
        ("203.0.113.5", "root", "failure", "failed_password", "srv", "1000")
    assert "Failed password" in e.message


def test_iso_timestamp_and_ipv6():
    r = parse_syslog_lines(["2026-11-08T10:19:00.123456+01:00 host sshd[5]: Failed password for root from 2001:db8::5 "
                            "port 22 ssh2"])
    assert r.events[0].source_ip == "2001:db8::5"
    assert r.events[0].timestamp.hour == 10


def test_invalid_lines_do_not_crash(line):
    lines = ["garbage", "", "Foo 99 10:00:00 x sshd[1]: Failed password for a from 1.2.3.4 port 1 ssh2",
             line(1, "Failed password for root from 999.1.1.1 port 1 ssh2"), "\x00\x00binary",
             "Nov 31 10:00:00 x sshd[1]: Failed password for a from 1.2.3.4 port 1 ssh2",
             line(2, "Failed password for root from 203.0.113.5 port 1 ssh2"), "x" * 10000]
    r = parse_syslog_lines(lines, year=2026)
    assert len(r.events) == 1
    assert r.malformed_lines == 6
    reasons = " ".join(x[1] for x in r.errors)
    assert "invalid IP" in reasons and "bad timestamp" in reasons and "too long" in reasons


def test_unrelated_lines_counted(line):
    r = parse_syslog_lines(["Nov  8 10:00:00 srv CRON[1]: pam_unix(cron:session): session opened",
                            line(0, "Server listening on 0.0.0.0 port 22.")], year=2026)
    assert r.unrelated_lines == 2 and not r.events


def test_repeated_message_expanded(line):
    r = parse_syslog_lines([line(0, "message repeated 4 times: [ Failed password for root from 203.0.113.5 port 1 ssh2]")],
                           year=2026)
    assert len(r.events) == 4 and r.repeated_expanded == 3


def test_supporting_lines_not_double_counted(line):
    lines = [line(0, "pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= "
                     "rhost=203.0.113.5  user=root", 77),
             line(2, "Failed password for root from 203.0.113.5 port 1 ssh2", 77),
             line(3, "Invalid user zz from 198.51.100.1 port 2", 78),
             line(4, "Failed password for invalid user zz from 198.51.100.1 port 2 ssh2", 78),
             line(5, "Invalid user only from 198.51.100.2 port 3", 79)]       # no Failed line -> counts
    r = parse_syslog_lines(lines, year=2026)
    counted = [e for e in r.events if e.counts_as_attempt]
    assert len(counted) == 3
    assert r.supporting_lines == 2
    assert any(e.username == "only" for e in counted)
    assert [e for e in r.events if e.event_type == "failed_password" and e.username == "zz"][0].invalid_user


def test_year_rollover():
    r = parse_syslog_lines(["Dec 31 23:59:00 srv sshd[1]: Failed password for root from 203.0.113.5 port 1 ssh2"],
                           year=2027, now=datetime(2027, 1, 2))
    assert r.events[0].timestamp.year == 2026


def test_synthetic_header_detected(line):
    r = parse_syslog_lines(["# SYNTHETIC test log", line(0, "Failed password for a from 192.0.2.1 port 1 ssh2")], year=2026)
    assert r.synthetic and r.comment_lines == 1


def test_valid_ip():
    assert valid_ip("::ffff:192.0.2.1") == "192.0.2.1"
    assert valid_ip("256.1.1.1") is None
    assert valid_ip("") is None


# ------------------------------------------------------------------ CSV
CSV_OK = """# SYNTHETIC
timestamp,source_ip,username,status,event_type
2026-11-08 10:00:00,203.0.113.5,root,failure,failed_password
2026-11-08T10:00:05Z,203.0.113.5,root,failed,
2026-11-08 10:01:00,10.0.0.5,alice,success,accepted
"""


def test_csv_valid():
    r = parse_csv_text(CSV_OK)
    assert r.synthetic and len(r.events) == 3 and r.malformed_lines == 0
    assert [e.status for e in r.events] == ["failure", "failure", "success"]
    assert r.events[1].timestamp.tzinfo is None


def test_csv_aliases():
    r = parse_csv_text("time,ip,user,result\n2026-11-08 10:00:00,192.0.2.1,bob,Accepted\n")
    assert r.events[0].status == "success" and r.events[0].username == "bob"


def test_csv_invalid_rows_reported_with_line_numbers():
    text = ("timestamp,source_ip,username,status\n2026-11-08 10:00:00,192.0.2.1,a,failure\n"
            "not a date,192.0.2.1,a,failure\n2026-11-08 10:00:00,999.0.0.1,a,failure\n"
            "2026-11-08 10:00:00,192.0.2.1,a,maybe\n2026-11-08 10:00:00,192.0.2.1,a,failure,extra\n")
    r = parse_csv_text(text)
    assert len(r.events) == 1 and r.malformed_lines == 4
    assert [x[0] for x in r.errors] == [3, 4, 5, 6]


def test_csv_missing_columns():
    r = parse_csv_text("foo,bar\n1,2\n")
    assert not r.events and "needs columns" in r.errors[0][1]


def test_detect_format_and_unknown():
    assert detect_format("timestamp,source_ip,status\n") == "csv"
    assert detect_format("Nov  8 10:00:00 h sshd[1]: x") == "syslog"
    r = parse_text("hello world\nnothing here\n")
    assert r.log_format == "unknown" and not r.events and r.malformed_lines == 1


def test_bundled_sample_has_100_plus_events():
    from config import SAMPLE_DIR
    r = parse_file(SAMPLE_DIR / "auth.log")
    assert r.synthetic and len(r.events) >= 100 and r.malformed_lines == 0


@pytest.mark.parametrize("name,data,ok", [
    ("auth.log", b"Nov  8 10:00:00 h sshd[1]: x\n", True), ("auth.log.1", b"a\n", True), ("secure", b"a\n", True),
    ("auth.log.gz", b"\x1f\x8b", False), ("x.exe", b"MZ", False), ("a.log", b"", False),
    ("a.log", b"abc\x00def\n", False)])
def test_upload_validation(name, data, ok):
    if ok:
        validate_upload(name, data)
    else:
        with pytest.raises(UploadError):
            validate_upload(name, data)


def test_upload_size_limit():
    with pytest.raises(UploadError):
        validate_upload("a.log", b"a\n" * 600_000, max_mb=1)
