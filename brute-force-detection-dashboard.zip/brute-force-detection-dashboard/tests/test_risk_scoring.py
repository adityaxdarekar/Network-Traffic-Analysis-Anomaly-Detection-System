"""Risk scoring, SQLite incident persistence, live monitoring, reports and sample generator."""
import csv
import io
import os
import time

import pytest

from config import DetectionConfig
from database.db_manager import DBManager
from detector.brute_force_detector import analyze_events
from detector.incident_manager import IncidentManager
from detector.log_monitor import LogTailer, MonitorSession
from detector.risk_scoring import attempt_category, category_for_score, score_incident
from utils.report_generator import incidents_csv, pdf_report, suspicious_ips_csv
from utils.sample_log_generator import generate, generate_all
from conftest import ev, syslog


def inc(**kw):
    base = {"failed_attempts": 5, "usernames": ["root"], "invalid_usernames": 0, "mean_interval_s": 60.0,
            "success_after_failures": False, "repeat_episodes": 1, "ip_count": 1, "incident_type": "Brute force"}
    base.update(kw)
    return base


@pytest.mark.parametrize("n,cat", [(1, "Low"), (4, "Low"), (5, "Medium"), (9, "Medium"), (10, "High"), (19, "High"),
                                   (20, "Critical"), (500, "Critical")])
def test_attempt_categories_match_brief(cfg, n, cat):
    assert attempt_category(n, cfg) == cat
    score, level, _, _ = score_incident(inc(failed_attempts=n), cfg)
    assert level == cat


@pytest.mark.parametrize("s,cat", [(0, "Low"), (24, "Low"), (25, "Medium"), (49, "Medium"), (50, "High"), (74, "High"),
                                   (75, "Critical"), (100, "Critical")])
def test_score_bands(s, cat):
    assert category_for_score(s) == cat


def test_indicators_add_points(cfg):
    s0 = score_incident(inc(), cfg)[0]
    assert s0 == 35
    assert score_incident(inc(usernames=["a", "b", "c"]), cfg)[0] == 45
    assert score_incident(inc(usernames=list("abcdef")), cfg)[0] == 50
    assert score_incident(inc(mean_interval_s=5.0), cfg)[0] == 45
    assert score_incident(inc(success_after_failures=True), cfg)[0] == 60
    assert score_incident(inc(repeat_episodes=3), cfg)[0] == 45
    assert score_incident(inc(usernames=["a", "b", "c"], invalid_usernames=3), cfg)[0] == 50


def test_success_raises_category(cfg):
    score, level, reasons, _ = score_incident(inc(failed_attempts=12, success_after_failures=True), cfg)
    assert score == 80 and level == "Critical"
    assert any("SUCCESSFUL" in r for r in reasons)


def test_score_capped(cfg):
    s = score_incident(inc(failed_attempts=50, usernames=list("abcdefgh"), invalid_usernames=8, mean_interval_s=1,
                           success_after_failures=True, repeat_episodes=4, ip_count=20), cfg)[0]
    assert s == 100


def test_custom_thresholds_change_categories():
    c = DetectionConfig(max_failed_attempts=3, high_risk_threshold=6, critical_risk_threshold=8)
    assert [attempt_category(n, c) for n in (2, 3, 6, 8)] == ["Low", "Medium", "High", "Critical"]


def test_config_validation():
    assert DetectionConfig().validate() == []
    assert DetectionConfig(time_window_minutes=0).validate()
    assert DetectionConfig(max_failed_attempts=True).validate()
    assert DetectionConfig(high_risk_threshold=30).validate()       # high > critical


# ------------------------------------------------------------------ SQLite persistence
def _result(cfg):
    return analyze_events([ev(i * 10) for i in range(12)] + [ev(i * 10, ip="198.51.100.9", user=f"u{i}") for i in range(4)],
                          cfg)


def test_incidents_persist_across_restart(tmp_path, cfg):
    path = tmp_path / "inc.db"
    db = DBManager(path)
    im = IncidentManager(db)
    res = _result(cfg)
    assert im.sync(res, "test.log", True) == 2
    iid = res.incidents[0]["incident_id"]
    assert im.set_status(iid, "Investigating", "checking with admin team", "ana")
    db.close()
    # "restart": new connection, same file, re-analyse the same log
    db2 = DBManager(path)
    im2 = IncidentManager(db2)
    im2.sync(_result(cfg), "test.log", True)
    got = im2.get(iid)
    assert got["status"] == "Investigating"
    assert got["analyst_notes"] == "checking with admin team"
    assert got["times_detected"] == 2
    assert got["notes"][0]["analyst"] == "ana"
    merged = {i["incident_id"]: i for i in im2.merged(_result(cfg))}
    assert merged[iid]["status"] == "Investigating"
    db2.close()


def test_status_validation_and_unknown(db, cfg):
    im = IncidentManager(db)
    im.sync(_result(cfg), "x", False)
    iid = db.list_incidents()[0]["incident_id"]
    with pytest.raises(ValueError):
        im.set_status(iid, "Deleted")
    assert not im.set_status("INC-NOPE", "Resolved")
    assert im.add_note(iid, "second note")
    assert len(db.notes(iid)) == 1


def test_filters_and_search(db, cfg):
    im = IncidentManager(db)
    im.sync(_result(cfg), "x", False)
    assert len(im.list(levels=["High"])) == 1
    assert len(im.list(ip_search="198.51.100")) == 1
    assert im.list(ip_search="'; DROP TABLE incidents; --") == []
    assert len(im.list()) == 2
    im.set_status(im.list(levels=["High"])[0]["incident_id"], "Resolved")
    assert len(im.list(statuses=["Open"])) == 1
    assert db.status_counts() == {"Open": 1, "Investigating": 0, "Resolved": 1}
    assert im.list(current_ids=[]) == []


def test_notes_are_sanitised(db, cfg):
    im = IncidentManager(db)
    im.sync(_result(cfg), "x", False)
    iid = db.list_incidents()[0]["incident_id"]
    im.set_status(iid, "Investigating", "ok\x07\x1b[31m" + "x" * 5000)
    n = db.get_incident(iid)["analyst_notes"]
    assert "\x07" not in n and "\x1b" not in n and len(n) == 2000


# ------------------------------------------------------------------ monitoring
def test_tailer_reads_only_new_lines(tmp_path):
    p = tmp_path / "auth.log"
    p.write_text(syslog(0, "Failed password for root from 203.0.113.5 port 1 ssh2") + "\n")
    t = LogTailer(p)
    assert len(t.read_new_lines()) == 1
    assert t.read_new_lines() == []
    with p.open("a") as fh:
        fh.write(syslog(5, "Failed password for root from 203.0.113.5 port 1 ssh2") + "\n" + "Nov  8 10:00:")
    assert len(t.read_new_lines()) == 1          # partial line kept back
    with p.open("a") as fh:
        fh.write("09 srv sshd[1]: Failed password for root from 203.0.113.5 port 1 ssh2\n")
    lines = t.read_new_lines()
    assert len(lines) == 1 and lines[0].startswith("Nov  8 10:00:09")


def test_tailer_rotation_and_truncation(tmp_path):
    p = tmp_path / "auth.log"
    p.write_text("a\nb\nc\n")
    t = LogTailer(p)
    t.read_new_lines()
    p.write_text("x\n")                 # truncated
    assert t.read_new_lines() == ["x"]
    os.replace(tmp_path / "auth.log", tmp_path / "auth.log.1")
    (tmp_path / "auth.log").write_text("new1\nnew2\n")
    assert t.read_new_lines() == ["new1", "new2"]
    assert t.rotations >= 1


def test_tailer_missing_and_unreadable(tmp_path):
    t = LogTailer(tmp_path / "nope.log")
    assert t.read_new_lines() == [] and "not found" in t.status
    d = LogTailer(tmp_path)
    assert d.read_new_lines() == [] and "not a regular file" in d.status
    p = tmp_path / "secret.log"
    p.write_text("x\n")
    p.chmod(0)
    if os.geteuid() != 0:          # root can read anything; only meaningful as a normal user
        assert LogTailer(p).read_new_lines() == []


def test_monitor_session_detects_growing_attack(tmp_path, cfg):
    p = tmp_path / "live.log"
    p.write_text("")
    m = MonitorSession(p)
    with p.open("a") as fh:
        for i in range(3):
            fh.write(syslog(i * 5, "Failed password for root from 203.0.113.5 port 1 ssh2", pid=100 + i) + "\n")
    m.refresh()
    assert not analyze_events(m.events, cfg).incidents
    with p.open("a") as fh:
        for i in range(3, 7):
            fh.write(syslog(i * 5, "Failed password for root from 203.0.113.5 port 1 ssh2", pid=100 + i) + "\n")
    m.refresh()
    m.refresh()          # nothing new: no duplicates
    assert len(m.events) == 7
    assert analyze_events(m.events, cfg).incidents[0]["failed_attempts"] == 7


def test_monitor_merges_supporting_lines_across_refreshes(tmp_path):
    p = tmp_path / "live.log"
    p.write_text(syslog(0, "pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= "
                           "rhost=203.0.113.5  user=root", pid=9) + "\n")
    m = MonitorSession(p)
    m.refresh()
    with p.open("a") as fh:
        fh.write(syslog(2, "Failed password for root from 203.0.113.5 port 1 ssh2", pid=9) + "\n")
    m.refresh()
    assert sum(e.counts_as_attempt for e in m.events) == 1


# ------------------------------------------------------------------ reports & generator
def test_reports_from_real_analysis(cfg):
    res = _result(cfg)
    rows = list(csv.reader(io.StringIO(incidents_csv(res.incidents).decode())))
    assert rows[0][0] == "incident_id" and len(rows) == 3
    ips = list(csv.reader(io.StringIO(suspicious_ips_csv(res).decode())))
    assert {r[0] for r in ips[1:]} == {"203.0.113.5", "198.51.100.9"}
    pdf = pdf_report(res, res.incidents, "test.log", synthetic=True)
    assert pdf[:4] == b"%PDF" and len(pdf) > 3000


def test_pdf_with_no_incidents(cfg):
    res = analyze_events([ev(0, status="success")], cfg)
    assert pdf_report(res, [], "clean.log")[:4] == b"%PDF"


def test_csv_formula_injection_guard(cfg):
    res = analyze_events([ev(i * 5, user="=HYPERLINK(1)") for i in range(6)], cfg)
    assert "'=HYPERLINK" in incidents_csv(res.incidents).decode()


def test_generator_is_deterministic_and_synthetic(tmp_path):
    a, b = tmp_path / "a.log", tmp_path / "b.log"
    generate("mixed", a, seed=3)
    generate("mixed", b, seed=3)
    assert a.read_text() == b.read_text()
    assert a.read_text().startswith("# SYNTHETIC")
    out = generate_all(tmp_path / "all")
    assert out["auth.log"] >= 100 and (tmp_path / "all" / "auth_sample.csv").exists()


def test_generator_uses_only_documentation_or_private_ips(tmp_path):
    import ipaddress
    import re
    generate("mixed", tmp_path / "m.log")
    ips = set(re.findall(r"\b\d+\.\d+\.\d+\.\d+\b", (tmp_path / "m.log").read_text()))
    docs = [ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24", "10.0.0.0/8")]
    assert ips and all(any(ipaddress.ip_address(i) in n for n in docs) for i in ips)


def test_stream_is_bounded(tmp_path):
    from utils.sample_log_generator import stream
    t = time.time()
    n = stream(tmp_path / "live.log", "brute_force", delay=0, max_lines=10)
    assert n == 10 and time.time() - t < 5
