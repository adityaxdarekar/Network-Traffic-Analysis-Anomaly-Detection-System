# Brute Force Attack Detection and Monitoring Dashboard

**Python · Streamlit · Pandas · Plotly · Regex · SQLite**

This is a defensive SOC/Blue-Team tool. It reads SSH authentication logs (Linux `auth.log` / `secure`) or standardised CSV logs, and finds brute-force patterns using **sliding time windows**. It scores each finding with an explainable 0–100 risk score, stores incidents with analyst status and notes in SQLite, and shows everything on a 7-page Streamlit dashboard with CSV and PDF reports.

> **Ethics and safety.**
> - The project never attempts a login, cracks a password, connects to SSH, or blocks an IP. It only reads files.
> - All demo data is **synthetic**. Attacker addresses come from the RFC 5737 documentation ranges, which are never routed on the internet.
> - Risk scores are **heuristic indicators, not proof of malicious intent**.
> - Analyse only logs from systems you are authorised to monitor.

---

## Architecture

```
            ┌───────────── sources ─────────────┐
            │ bundled synthetic sample │ upload │ monitored local file (LogTailer: new bytes only)
            └──────────────┬────────────────────┘
                           ▼
                detector/log_parser.py   regex → AuthEvent(timestamp, ip, user, status, type, message)
                           │              malformed lines counted, never fatal; duplicate pam/invalid-user
                           │              lines merged into the "Failed password" attempt
                           ▼
          detector/brute_force_detector.py   sliding-window rules R1–R7 → incidents, suspicious IPs,
                           │                  targeted usernames, metrics
                           ▼
              detector/risk_scoring.py   base points from attempt count + indicator points → 0–100, category
                           ▼
   detector/incident_manager.py ⇄ database/db_manager.py (SQLite: incidents, notes history, analyses)
                           ▼
        app.py (Streamlit, 7 pages)   ·   analyze.py (terminal)   ·   utils/report_generator.py (CSV/PDF)
```

## Folder structure

```
brute-force-detection-dashboard/
├── app.py                       Streamlit dashboard (7 pages, sidebar navigation + thresholds)
├── analyze.py                   terminal analysis, incident listing, status updates
├── run_demos.py                 runs Demos 1-6 end to end and verifies them
├── config.py                    DetectionConfig (defaults 5 / 5 min / 10 / 20) + validation, paths
├── requirements.txt  pytest.ini  .gitignore  .streamlit/config.toml
├── detector/
│   ├── log_parser.py            syslog + ISO + CSV parsing, malformed-line handling
│   ├── brute_force_detector.py  sliding-window detection engine
│   ├── risk_scoring.py          scoring algorithm, categories, recommendations
│   ├── incident_manager.py      detection results ⇄ SQLite, analyst workflow
│   └── log_monitor.py           safe incremental monitoring of a local log file
├── database/
│   ├── db_manager.py            SQLite schema and queries (parameterised only)
│   └── incidents.db             created on first run (sample DB from the demo run included)
├── utils/
│   ├── report_generator.py      incidents CSV, suspicious-IP CSV, PDF report
│   ├── sample_log_generator.py  SYNTHETIC log generator (7 scenarios, streaming mode)
│   └── helpers.py               upload validation, formatting, logging
├── sample_logs/                 auth.log (mixed, 221 events), demo1…demo4, distributed, CSV
├── assets/style.css             dark SOC theme
├── tests/                       119 pytest tests
├── docs/                        PROJECT_REPORT.md, VIVA.md, DEMO_GUIDE.md
├── sample_output/               real output of run_demos.py / analyze.py, PDF and CSV reports
└── screenshots/                 terminal and PDF screenshots
```

---

## Phase 1: Environment setup

**Requirements:** Python **3.11+**. It was tested here on 3.13, and the dashboard needs `streamlit` and `plotly`.

### Kali Linux / Ubuntu

```bash
sudo apt update && sudo apt install -y python3 python3-venv python3-pip
cd brute-force-detection-dashboard
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py              # opens http://localhost:8501
```

### Windows 10/11 (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

No administrator rights are needed for the sample logs. To analyse the real `/var/log/auth.log`, your user must be able to read it. On Debian, Ubuntu and Kali, add yourself to the `adm` group (`sudo usermod -aG adm $USER`, then log in again) or copy the file. The tool never asks for elevation.

## Phase 2: Module responsibilities

| Module | Responsibility |
|---|---|
| `config.py` | Detection settings dataclass, defaults, validation (for example `max < high < critical`), and paths. |
| `detector/log_parser.py` | Turns log lines or CSV rows into `AuthEvent`s. Expands `message repeated N times`, validates IPs (v4/v6), and records malformed lines with their reason. |
| `detector/brute_force_detector.py` | Applies the detection rules with sliding windows. Builds incidents, the suspicious-IP table, targeted usernames and metrics. |
| `detector/risk_scoring.py` | Scoring algorithm, categories, the reason text and defensive recommendations. |
| `detector/incident_manager.py` | Saves incidents (keeping analyst status and notes), lists and filters them, and updates their status. |
| `detector/log_monitor.py` | `LogTailer` reads only new bytes and handles rotation, truncation and partial lines. `MonitorSession` accumulates events. |
| `database/db_manager.py` | SQLite tables `incidents`, `incident_notes` and `analyses`. Uses parameterised SQL and a status CHECK constraint. |
| `utils/report_generator.py` | CSV reports (protected against formula injection) and the PDF report (reportlab). |
| `utils/sample_log_generator.py` | Synthetic scenarios, deterministic with a seed, plus a streaming mode for the monitoring demo. |
| `utils/helpers.py` | Upload validation (size, compressed or binary files), formatting, rotating log file. |
| `app.py` | The 7-page dashboard. |
| `analyze.py` / `run_demos.py` | Terminal tools that use the same engine. |

## Phase 3: Log processing

**Linux SSH (`/var/log/auth.log`, `/var/log/secure`)** lines look like this:

```
Nov  8 10:12:09 lab-server sshd[2190]: Failed password for root from 203.0.113.45 port 47731 ssh2
Nov  8 11:30:02 lab-server sshd[2261]: Invalid user admin from 198.51.100.23 port 64809
Nov  8 11:30:04 lab-server sshd[2261]: Failed password for invalid user admin from 198.51.100.23 port 64809 ssh2
Nov  8 14:50:55 lab-server sshd[2330]: Accepted password for deploy from 192.0.2.77 port 51515 ssh2
Nov  8 10:12:07 lab-server sshd[2190]: pam_unix(sshd:auth): authentication failure; ... rhost=203.0.113.45  user=root
2026-11-08T10:19:00+00:00 host sshd[2180]: Failed password for root from 2001:db8::5 port 22 ssh2   (ISO prefix)
```

How these lines are handled:

- **Event types:** `failed_password` (password, publickey or keyboard-interactive), `accepted`, `invalid_user`, `auth_failure` (PAM), `max_auth_exceeded`, and `connection_closed` (info only).
- **One attempt, several lines.** A single failed SSH attempt writes 2–3 lines from the same `sshd[PID]`. The `Failed …` line counts as the attempt. The PAM and "Invalid user" lines from the same PID and IP are kept as evidence but **not counted again**. Without this, every attack would look 2–3× larger.
- **Missing year.** Syslog lines carry no year. The current year is assumed, a December line read in January goes to the previous year, and `--year` overrides this.
- **Malformed lines** (bad timestamp, invalid IP, binary data, lines over 8 KB, unknown format) are counted and listed with their line number. Analysis continues.

**CSV:** a header row with `timestamp, source_ip, username, status`, optionally followed by `event_type` and `message`. Common aliases such as `ip`, `user`, `result` and `@timestamp` are accepted. Status values like `success`, `accepted` and `ok` count as success; `failure`, `failed`, `invalid` and `denied` count as failure.

**Uploads are validated.** The limit is 50 MB. Compressed and binary files are rejected with a hint (for example `zcat auth.log.2.gz`, or `journalctl -u ssh --no-pager > ssh.log`).

## Phase 4: Detection engine (all rules use sliding windows of `time_window_minutes`)

| Rule | What it does |
|---|---|
| R1–R3 | For each IP, failures are counted inside **every** window. The IP is flagged when one window holds ≥ `max_failed_attempts` (default 5). Overlapping qualifying windows merge into one *episode*, and each episode is one incident. |
| R4 | Usernames targeted by flagged IPs are listed, with attempts and whether they exist ("invalid user"). |
| R5 | One IP trying ≥ 3 different usernames within one window is flagged, even below 5 failures. |
| R6 | A success from an IP after its failures (within 30 minutes) is added to the incident. Three or more failures followed by a success also creates a separate "success after failures" incident. |
| R7 | One username failing from ≥ 3 IPs with ≥ 5 failures within one window is a distributed attack. A later success for that account from *any* IP is noted. |

Because the rules use windows, 6 failures spread over 2.5 hours are **not** flagged. Demo 1 includes exactly this case.

## Phase 5: Risk scoring

| Failed attempts | Base category | Base points |
|---|---|---|
| 1–4 | Low | 15 |
| 5–9 | Medium | 35 |
| 10–19 | High | 55 |
| 20+ | Critical | 75 |

**Indicators** add points:

| Indicator | Points |
|---|---|
| ≥ 3 usernames targeted | +10 |
| ≥ 6 usernames targeted | +5 more |
| Attempts concentrated (mean gap ≤ 10 s) | +10 |
| **Successful login after failures** | **+25** |
| Repeated episodes from the same IP | +10 |
| Mostly non-existent usernames | +5 |
| ≥ 6 source IPs | +10 |

The score is capped at **100**. Category: 0–24 Low · 25–49 Medium · 50–74 High · 75–100 Critical. The base points sit inside their own band, so the attempt count alone reproduces the brief's table, and indicators can only raise the category. Every incident shows its breakdown, for example `15 failed attempt(s) -> High tier (55) + attempts every 8.1s on average (concentrated) (10) = 65`.

## Phase 6: Database

```sql
incidents(incident_id PK, incident_type, source_ip, username_key, usernames JSON, failed_attempts,
          successful_logins, first_seen, last_seen, risk_score, risk_level, reasons JSON, details JSON,
          source_name, status CHECK IN ('Open','Investigating','Resolved'), analyst_notes,
          created_at, updated_at, times_detected)
incident_notes(id PK, incident_id FK, timestamp, analyst, status, note)
analyses(id PK, timestamp, source_name, synthetic, total_events, failed, successful, incidents, settings JSON)
```

An incident ID is a hash of (type, IP or username, first timestamp). Re-analysing the same log after a restart therefore maps to the same row. The upsert **never overwrites** status or notes.

## Phase 7: Dashboard pages

1. **Security Overview** shows 6 metric cards and 6 Plotly charts:
   - failed attempts over time;
   - top 10 suspicious IPs;
   - most targeted usernames;
   - successful vs failed logins;
   - risk distribution;
   - attempts grouped by IP.
2. **Authentication Log Analyzer** shows parse statistics, malformed lines, and a searchable event table.
3. **Brute Force Detection** shows incidents with reasons, score breakdown, attempt timeline and the success alert.
4. **Suspicious IP Analysis** shows the IP table, a per-IP timeline, usernames tried and related incidents.
5. **Incident Management** lets you filter by level, status or IP, view details, set Open, Investigating or Resolved, and add notes with history.
6. **Reports and Downloads** offers the incidents CSV, the suspicious-IPs CSV and the PDF report.
7. **Detection Configuration** shows the current settings, the scoring table, a reset button and a confirmed database clear.

The sidebar holds navigation, the log source (sample, upload or monitor) and **all thresholds**. Changes apply immediately.

## Phase 8: Reports

The CSV and PDF reports are built only from the current analysis. The PDF contains:

- the title and generation time;
- the source analysed, with a **synthetic-data banner** when applicable;
- totals and failed/successful counts;
- the suspicious IPs;
- the severity breakdown;
- a detailed description of each incident (reasons, score, successful logins, example lines, status and notes);
- recommended defensive actions;
- the heuristic disclaimer.

## Phase 9: Sample data, demos and tests

```bash
python -m utils.sample_log_generator                  # (re)create all sample logs (SYNTHETIC)
python -m utils.sample_log_generator --scenario brute_force --out bf.log
python -m utils.sample_log_generator --stream sample_logs/live_auth.log --delay 0.3   # monitoring demo
python run_demos.py                                   # Demos 1-6, prints PASS/FAIL
python analyze.py sample_logs/auth.log --pdf reports/report.pdf --csv reports/
python -m pytest -q                                   # expected: 119 passed
```

Step-by-step demos with real expected output are in **docs/DEMO_GUIDE.md**.

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: streamlit` | Activate the venv, then run `pip install -r requirements.txt`. |
| "plotly not installed – basic charts" | `pip install plotly` |
| Upload rejected: compressed | Run `zcat auth.log.2.gz > auth2.log` and upload `auth2.log`. |
| Upload rejected: binary | journald stores binary data. Run `journalctl -u ssh --no-pager > ssh.log` (on RHEL use `-u sshd`). |
| "permission denied" when monitoring `/var/log/auth.log` | Add your user to `adm`, or copy the file. Do not run Streamlit as root. |
| Dates show the wrong year | Syslog has no year. Use `analyze.py --year 2025`. |
| No incidents on a real log | Lower the thresholds in the sidebar or widen the window. Your attackers may be slow ("low and slow"). |
| Port 8501 in use | `streamlit run app.py --server.port 8502` |
| Start with an empty incident DB | Detection Configuration → Danger zone, or delete `database/incidents.db`. |

## Security notes

- Passwords are never in sshd logs and are never stored. A user can, however, type a password into the *username* prompt, and sshd will then log it as an "invalid user". Treat the usernames column of real logs as sensitive.
- HTML in the dashboard is escaped, CSV cells starting with `= + - @` are prefixed with `'`, and analyst notes are stripped of control characters and limited to 2000 characters.
