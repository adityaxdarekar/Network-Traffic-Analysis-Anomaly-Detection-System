"""
incident_manager.py - connects detection results to the SQLite incident store.

  * sync()        saves the incidents of an analysis (new ones as Open, existing
                  ones keep their analyst status and notes) and records the run.
  * list/get      read incidents with their status and note history.
  * set_status()  analyst workflow: Open -> Investigating -> Resolved, with notes.

Incident IDs are a hash of (type, source IP or username, first timestamp), so
analysing the same log again maps onto the same stored incident.
"""
from __future__ import annotations

from config import INCIDENT_STATUSES
from database.db_manager import DBManager


class IncidentManager:
    def __init__(self, db: DBManager):
        self.db = db

    def sync(self, result, source_name: str, synthetic: bool = False) -> int:
        n = self.db.upsert_incidents(result.incidents, source_name)
        self.db.record_analysis(source_name, synthetic, result.metrics, result.config)
        return n

    def merged(self, result) -> list[dict]:
        """Incidents of the CURRENT analysis with their stored status/notes attached."""
        stored = {d["incident_id"]: d for d in self.db.list_incidents(ids=[i["incident_id"] for i in result.incidents])}
        out = []
        for inc in result.incidents:
            s = stored.get(inc["incident_id"], {})
            out.append({**inc, "status": s.get("status", "Open"), "analyst_notes": s.get("analyst_notes", "")})
        return out

    def list(self, levels=None, ip_search="", statuses=None, current_ids=None):
        return self.db.list_incidents(levels=levels, ip_search=ip_search.strip(), statuses=statuses, ids=current_ids)

    def get(self, incident_id):
        return self.db.get_incident(incident_id)

    def set_status(self, incident_id, status, note="", analyst="analyst") -> bool:
        if status not in INCIDENT_STATUSES:
            raise ValueError(f"status must be one of {INCIDENT_STATUSES}")
        return self.db.update_status(incident_id, status, note, analyst)

    def add_note(self, incident_id, note, analyst="analyst") -> bool:
        cur = self.db.get_incident(incident_id)
        if not cur:
            return False
        return self.db.update_status(incident_id, cur["status"], note, analyst)
