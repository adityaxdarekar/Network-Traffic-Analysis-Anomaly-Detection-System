"""
risk_scoring.py - explainable 0-100 risk score for a detected incident.

  1. Base points from the number of failed attempts in the incident
     (tiers follow the configurable thresholds):
         1 .. max_failed-1            Low       15
         max_failed .. high-1         Medium    35
         high .. critical-1           High      55
         critical and above           Critical  75
  2. Indicator points added on top:
         multiple usernames targeted (>= multi_user_threshold)      +10
           ... at least twice that many usernames                   +5 more
         attempts concentrated in a short time (fast mean interval) +10
         successful login after the failures                        +25
         repeated attack episodes from the same IP                  +10
         most usernames tried do not exist ("invalid user")         +5
         distributed: many source IPs (>= 2x distributed threshold) +10
  3. Score capped at 100. Category from the final score:
         0-24 Low · 25-49 Medium · 50-74 High · 75-100 Critical
     Base points sit inside their own band, so the attempt count alone
     reproduces the brief's table; indicators can only raise the category.

These are HEURISTIC indicators of attention-worthiness, not proof of
malicious intent: a forgotten password, a misconfigured script or a
vulnerability scanner you run yourself can produce the same pattern.
"""
from __future__ import annotations

BANDS = [(75, "Critical"), (50, "High"), (25, "Medium"), (0, "Low")]
BASE = {"Low": 15, "Medium": 35, "High": 55, "Critical": 75}
DISCLAIMER = ("Risk scores are heuristic indicators based on log patterns. They are not proof of malicious intent: "
              "forgotten passwords, misconfigured scripts or authorised scanners can produce the same patterns.")


def attempt_category(failures: int, cfg) -> str:
    if failures >= cfg.critical_risk_threshold:
        return "Critical"
    if failures >= cfg.high_risk_threshold:
        return "High"
    if failures >= cfg.max_failed_attempts:
        return "Medium"
    return "Low"


def category_for_score(score: int) -> str:
    for lo, name in BANDS:
        if score >= lo:
            return name
    return "Low"


def score_incident(inc: dict, cfg) -> tuple[int, str, list[str], list[tuple[str, int]]]:
    """inc needs: failed_attempts, usernames (list), invalid_usernames, mean_interval_s, success_after_failures,
    repeat_episodes, ip_count, incident_type. Returns (score, category, reasons, breakdown)."""
    n = inc["failed_attempts"]
    cat = attempt_category(n, cfg)
    breakdown = [(f"{n} failed attempt(s) -> {cat} tier", BASE[cat])]
    reasons = [f"{n} failed login attempt(s) within the detection window(s)"]
    users = len(inc.get("usernames") or [])
    if users >= cfg.multi_user_threshold:
        breakdown.append((f"{users} different usernames targeted", 10))
        reasons.append(f"{users} different usernames targeted from the same source")
        if users >= 2 * cfg.multi_user_threshold:
            breakdown.append(("very wide username list", 5))
    mi = inc.get("mean_interval_s")
    if mi is not None and n >= 2 and mi <= cfg.fast_attempt_seconds:
        breakdown.append((f"attempts every {mi:.1f}s on average (concentrated)", 10))
        reasons.append(f"attempts concentrated in a short time (about one every {mi:.1f}s - faster than a person types)")
    if inc.get("success_after_failures"):
        breakdown.append(("successful login after the failures", 25))
        reasons.append("a SUCCESSFUL login followed the failed attempts - the account may be compromised")
    if inc.get("repeat_episodes", 1) >= 2:
        breakdown.append((f"{inc['repeat_episodes']} separate attack episodes from this IP", 10))
        reasons.append(f"same source attacked again in {inc['repeat_episodes']} separate episodes")
    inv = inc.get("invalid_usernames", 0)
    if users and inv / max(users, 1) >= 0.5 and inv >= 2:
        breakdown.append((f"{inv} non-existent usernames tried", 5))
        reasons.append(f"{inv} of the usernames do not exist on the server (username guessing)")
    if inc.get("ip_count", 1) >= 2 * cfg.distributed_ip_threshold:
        breakdown.append((f"{inc['ip_count']} source IPs", 10))
    if inc.get("ip_count", 1) >= cfg.distributed_ip_threshold and inc.get("incident_type", "").startswith("Distributed"):
        reasons.append(f"{inc['ip_count']} different source IPs attacked the same account (distributed attack)")
    score = min(100, sum(p for _, p in breakdown))
    return score, category_for_score(score), reasons, breakdown


def recommendations(inc: dict) -> list[str]:
    recs = []
    if inc.get("success_after_failures"):
        recs += [f"Treat account(s) {', '.join(inc.get('success_users') or ['?'])} as possibly compromised: review "
                 f"the session that followed the successful login (commands, sudo, new keys in ~/.ssh/authorized_keys).",
                 "Reset the affected password and revoke active sessions if the login was not expected."]
    if inc.get("incident_type", "").startswith("Distributed"):
        recs.append(f"Account '{inc.get('username_key')}' is targeted from many IPs: enforce key-only or MFA login "
                    f"for it; IP blocking alone will not stop a distributed attack.")
    if len(inc.get("usernames") or []) >= 3:
        recs.append("Many usernames were tried: confirm none of the existing accounts have weak passwords; "
                    "disable unused accounts and direct root login (PermitRootLogin no).")
    recs += ["Verify whether the source IP belongs to your organisation (admin, monitoring, scanner) before acting.",
             "Consider a manual firewall rule or fail2ban jail for the source IP - this tool never blocks automatically.",
             "Prefer SSH keys over passwords (PasswordAuthentication no) and limit SSH exposure (VPN, allow-lists).",
             "Check the same IP in your other logs and threat-intelligence sources."]
    return list(dict.fromkeys(recs))
