"""Detection package: log parsing, brute-force detection, risk scoring, incidents."""
