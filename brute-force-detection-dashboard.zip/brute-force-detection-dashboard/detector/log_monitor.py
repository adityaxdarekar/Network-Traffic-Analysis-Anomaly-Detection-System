"""
log_monitor.py - safe, incremental monitoring of a LOCAL auth log file.

  * Reads only bytes appended since the last read (keeps a byte offset), so
    the same entries are never processed twice.
  * Detects log rotation (file replaced - inode changed) and truncation
    (file got smaller) and starts again from the beginning of the new file.
  * Keeps an incomplete last line in a buffer until its newline arrives.
  * Missing or unreadable files produce a status message, never an exception.
  * Read-only: opens the file with mode "rb". Does not need administrator
    rights for the sample logs; /var/log/auth.log usually needs the user to be
    in the 'adm' group (Debian/Ubuntu/Kali) - the tool does not try to elevate.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from detector.log_parser import decode_bytes, merge_supporting_lines, parse_syslog_lines

MAX_READ = 20 * 1024 * 1024        # read at most 20 MB per refresh
MAX_EVENTS = 500_000


class LogTailer:
    def __init__(self, path, from_start: bool = True):
        self.path = Path(path).expanduser()
        self.offset = 0
        self.inode = None
        self.line_no = 0
        self._partial = b""
        self.from_start = from_start
        self.status = "not started"
        self.last_read = None
        self.rotations = 0

    def read_new_lines(self) -> list[str]:
        try:
            st = os.stat(self.path)
        except FileNotFoundError:
            self.status = f"file not found: {self.path}"
            return []
        except PermissionError:
            self.status = f"permission denied: {self.path} (on Linux add your user to the 'adm' group)"
            return []
        except OSError as exc:
            self.status = f"cannot stat file: {exc}"
            return []
        if not self.path.is_file():
            self.status = f"not a regular file: {self.path}"
            return []
        ino = (st.st_dev, st.st_ino)
        if self.inode is None:
            self.inode = ino
            if not self.from_start:
                self.offset = st.st_size
        elif ino != self.inode or st.st_size < self.offset:
            self.rotations += 1
            self.inode, self.offset, self._partial = ino, 0, b""
        if st.st_size == self.offset:
            self.status = f"no new data ({datetime.now():%H:%M:%S})"
            return []
        try:
            with open(self.path, "rb") as fh:
                fh.seek(self.offset)
                data = fh.read(MAX_READ)
        except PermissionError:
            self.status = f"permission denied: {self.path}"
            return []
        except OSError as exc:
            self.status = f"read error: {exc}"
            return []
        self.offset += len(data)
        data = self._partial + data
        if data.endswith(b"\n"):
            complete, self._partial = data, b""
        else:
            cut = data.rfind(b"\n")
            complete, self._partial = (data[:cut + 1], data[cut + 1:]) if cut >= 0 else (b"", data)
        lines = decode_bytes(complete).splitlines()
        self.last_read = datetime.now()
        self.status = f"read {len(lines)} new line(s) at {self.last_read:%H:%M:%S}"
        return lines


class MonitorSession:
    """Accumulates parsed events from a LogTailer across refreshes."""

    def __init__(self, path, from_start: bool = True, year: int | None = None):
        self.tailer = LogTailer(path, from_start)
        self.events: list = []
        self.year = year
        self.stats = {"lines": 0, "auth_events": 0, "malformed": 0, "unrelated": 0, "refreshes": 0}
        self.synthetic = False

    def refresh(self) -> int:
        lines = self.tailer.read_new_lines()
        self.stats["refreshes"] += 1
        if not lines:
            return 0
        res = parse_syslog_lines(lines, year=self.year, start_line=self.tailer.line_no + 1)
        self.tailer.line_no += len(lines)
        self.synthetic = self.synthetic or res.synthetic
        self.events.extend(res.events)
        self.events.sort(key=lambda e: (e.timestamp, e.line_no))
        del self.events[:-MAX_EVENTS]
        merge_supporting_lines(self.events)
        self.stats["lines"] += res.total_lines
        self.stats["auth_events"] += len(res.events)
        self.stats["malformed"] += res.malformed_lines
        self.stats["unrelated"] += res.unrelated_lines
        return len(res.events)

    @property
    def status(self) -> str:
        return self.tailer.status
