"""
log_parser.py - parse Linux SSH authentication logs and standardized CSV logs.

Supported inputs
  1. Linux syslog auth logs (/var/log/auth.log on Debian/Ubuntu/Kali,
     /var/log/secure on RHEL), both the classic prefix
         Nov  8 10:15:02 web01 sshd[2143]: Failed password for root from 203.0.113.5 port 52144 ssh2
     and the ISO-8601 prefix used by newer rsyslog/journald exports
         2026-11-08T10:15:02.123456+00:00 web01 sshd[2143]: ...
  2. CSV with a header row: timestamp, source_ip, username, status
     [, event_type, message]  (common column aliases accepted)

Recognised sshd messages
  Failed password|publickey|keyboard-interactive/pam|none for [invalid user] U from IP port P
  Accepted password|publickey|keyboard-interactive/pam for U from IP port P
  Invalid user U from IP [port P]
  pam_unix(sshd:auth): authentication failure; ... rhost=IP [user=U]
  error: maximum authentication attempts exceeded for [invalid user] U from IP ...
  Connection closed / Disconnected ... [preauth]
  message repeated N times: [ <one of the above> ]

One failed SSH attempt often produces 2-3 lines (pam_unix failure,
"Invalid user", "Failed password") from the same sshd PID. To avoid counting
one attempt three times, "Failed ..." lines are the canonical attempt and the
supporting lines from the same PID and IP are marked counts_as_attempt=False.

Malformed lines never raise: they are counted and a few examples are kept.
Passwords never appear in sshd logs and are never stored. (A user who types
a password into the username prompt CAN leak it into logs as a "username" -
see README, Security notes.)
"""
from __future__ import annotations

import csv
import io
import ipaddress
import re
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime

import pandas as pd

MONTHS = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                      "Dec"], 1)}
MAX_LINE = 8192

SYSLOG_RE = re.compile(r"^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s(?P<time>\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+"
                       r"(?P<proc>[^\s\[:]+)(?:\[(?P<pid>\d+)\])?:\s?(?P<msg>.*)$")
ISO_RE = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+(?P<host>\S+)\s+"
                    r"(?P<proc>[^\s\[:]+)(?:\[(?P<pid>\d+)\])?:\s?(?P<msg>.*)$")

IP = r"(?P<ip>[0-9A-Fa-f:.]+)"
USER = r"(?P<user>\S*)"
MSG_RULES = [
    ("failed_password", "failure",
     re.compile(rf"^Failed (?P<method>password|publickey|keyboard-interactive/pam|none|hostbased) for "
                rf"(?P<invalid>invalid user )?{USER} from {IP} port (?P<port>\d+)")),
    ("accepted", "success",
     re.compile(rf"^Accepted (?P<method>password|publickey|keyboard-interactive/pam|gssapi-with-mic|hostbased) for "
                rf"{USER} from {IP} port (?P<port>\d+)")),
    ("invalid_user", "failure", re.compile(rf"^Invalid user {USER} from {IP}(?: port (?P<port>\d+))?")),
    ("auth_failure", "failure",
     re.compile(rf"^pam_unix\(sshd:auth\): authentication failure;.*?rhost={IP}(?:\s+user={USER})?")),
    ("max_auth_exceeded", "info",
     re.compile(rf"^error: maximum authentication attempts exceeded for (?:invalid user )?{USER} from {IP}")),
    ("connection_closed", "info",
     re.compile(rf"^(?:Connection closed by|Disconnected from|Received disconnect from)\s+"
                rf"(?:(?:authenticating |invalid )?user {USER}\s+)?{IP}")),
]
REPEATED_RE = re.compile(r"^message repeated (?P<n>\d+) times: \[\s*(?P<inner>.*?)\s*\]$")

CSV_ALIASES = {
    "timestamp": ["timestamp", "time", "datetime", "date", "event_time", "@timestamp"],
    "source_ip": ["source_ip", "ip", "src_ip", "ip_address", "client_ip", "remote_ip", "rhost"],
    "username": ["username", "user", "account", "user_name", "login"],
    "status": ["status", "result", "outcome", "auth_status"],
    "event_type": ["event_type", "event", "type", "action"],
    "message": ["message", "msg", "raw", "log", "original_message"],
}
SUCCESS_WORDS = {"success", "successful", "succeeded", "accepted", "ok", "allowed", "pass", "passed", "true"}
FAILURE_WORDS = {"failure", "failed", "fail", "invalid", "denied", "rejected", "error", "false", "invalid_user",
                 "failed_password", "auth_failure"}


@dataclass
class AuthEvent:
    timestamp: datetime
    source_ip: str
    username: str
    status: str               # failure | success | info
    event_type: str           # failed_password | accepted | invalid_user | auth_failure | ...
    message: str              # original log line (trimmed)
    line_no: int = 0
    host: str = ""
    pid: str = ""
    method: str = ""
    invalid_user: bool = False
    counts_as_attempt: bool = True
    source: str = "syslog"

    def to_dict(self):
        return asdict(self)


@dataclass
class ParseResult:
    events: list = field(default_factory=list)
    log_format: str = "unknown"
    total_lines: int = 0
    auth_lines: int = 0
    unrelated_lines: int = 0
    malformed_lines: int = 0
    comment_lines: int = 0
    repeated_expanded: int = 0
    supporting_lines: int = 0          # pam/invalid-user lines merged into a Failed line
    errors: list = field(default_factory=list)   # [(line_no, reason, excerpt)] first 50
    synthetic: bool = False

    def _err(self, line_no, reason, text):
        self.malformed_lines += 1
        if len(self.errors) < 50:
            self.errors.append((line_no, reason, text[:160]))

    def summary(self) -> dict:
        ev = self.events
        return {"format": self.log_format, "synthetic": self.synthetic, "total_lines": self.total_lines,
                "auth_events": len(ev), "failed_attempts": sum(1 for e in ev if e.status == "failure" and
                                                                e.counts_as_attempt),
                "successful_logins": sum(1 for e in ev if e.status == "success"),
                "unrelated_lines": self.unrelated_lines, "malformed_lines": self.malformed_lines,
                "repeated_expanded": self.repeated_expanded, "supporting_lines": self.supporting_lines}


# ------------------------------------------------------------------ helpers
def valid_ip(s: str) -> str | None:
    s = (s or "").strip().strip("[]")
    if s.lower().startswith("::ffff:") and "." in s:
        s = s[7:]
    try:
        return str(ipaddress.ip_address(s))
    except ValueError:
        return None


def clean_user(u: str | None) -> str:
    u = (u or "").strip()
    u = "".join(ch for ch in u if ch.isprintable())
    return u[:64]


def _syslog_time(mon, day, hms, year, ref: datetime | None):
    dt = datetime(year, MONTHS[mon], int(day), *map(int, hms.split(":")))
    # syslog has no year: a December line read in January belongs to last year
    if ref is not None and (dt - ref).days > 31:
        dt = dt.replace(year=year - 1)
    return dt


def _iso_time(ts: str) -> datetime:
    ts = ts.replace(" ", "T").replace("Z", "+00:00")
    if re.search(r"[+-]\d{4}$", ts):
        ts = ts[:-2] + ":" + ts[-2:]
    dt = datetime.fromisoformat(ts)
    return dt.replace(tzinfo=None)     # keep the wall-clock time written in the log


def classify_message(msg: str):
    """Return (event_type, status, fields) or None for non-auth sshd messages."""
    for etype, status, rx in MSG_RULES:
        m = rx.search(msg)
        if m:
            g = m.groupdict()
            user = g.get("user")
            if etype == "connection_closed" and user is None:
                user = ""
            return etype, status, {"ip": g.get("ip"), "user": clean_user(user), "method": g.get("method") or "",
                                   "invalid": bool(g.get("invalid")) or etype == "invalid_user"}
    return None


# ------------------------------------------------------------------ syslog
def parse_syslog_lines(lines, year: int | None = None, now: datetime | None = None,
                       start_line: int = 1) -> ParseResult:
    now = now or datetime.now()
    year = year or now.year
    res = ParseResult(log_format="syslog")
    for i, raw in enumerate(lines, start_line):
        res.total_lines += 1
        line = raw.rstrip("\r\n").replace("\x00", "")
        if not line.strip():
            res.total_lines -= 1
            continue
        if line.lstrip().startswith("#"):
            res.comment_lines += 1
            if "SYNTHETIC" in line.upper():
                res.synthetic = True
            continue
        if len(line) > MAX_LINE:
            res._err(i, "line too long", line)
            continue
        m = SYSLOG_RE.match(line)
        try:
            if m:
                if m["mon"] not in MONTHS:
                    res._err(i, "bad month", line)
                    continue
                ts = _syslog_time(m["mon"], m["day"], m["time"], year, now)
            else:
                m = ISO_RE.match(line)
                if not m:
                    res._err(i, "not a syslog line", line)
                    continue
                ts = _iso_time(m["ts"])
        except ValueError as exc:
            res._err(i, f"bad timestamp ({exc})", line)
            continue
        proc = m["proc"].lower()
        if not proc.startswith("sshd"):
            res.unrelated_lines += 1
            continue
        msg = m["msg"].strip()
        repeat = 1
        rm = REPEATED_RE.match(msg)
        if rm:
            repeat, msg = int(rm["n"]), rm["inner"]
            if repeat > 10_000:
                res._err(i, "implausible repeat count", line)
                continue
        cls = classify_message(msg)
        if not cls:
            res.unrelated_lines += 1        # other sshd messages (key exchange, session opened, ...)
            continue
        etype, status, f = cls
        ip = valid_ip(f["ip"] or "")
        if not ip:
            res._err(i, "invalid IP address", line)
            continue
        res.auth_lines += 1
        if repeat > 1:
            res.repeated_expanded += repeat - 1
        for _ in range(repeat):
            res.events.append(AuthEvent(ts, ip, f["user"], status, etype, line.strip()[:500], i, m["host"],
                                        m["pid"] or "", f["method"], f["invalid"]))
    _merge_supporting_lines(res)
    return res


def _merge_supporting_lines(res: ParseResult):
    res.supporting_lines = merge_supporting_lines(res.events)


def merge_supporting_lines(events) -> int:
    """Within one sshd PID and IP, 'Failed ...' lines are the attempts; pam/invalid-user lines that
    accompany them are supporting evidence and are not counted again. Safe to re-run on a growing list
    (used by the live monitor). Returns the number of supporting lines."""
    groups = defaultdict(list)
    for e in events:
        if e.source == "syslog":
            e.counts_as_attempt = e.status != "info"
        if e.pid:
            groups[(e.host, e.pid, e.source_ip)].append(e)
    n = 0
    for evs in groups.values():
        if any(e.event_type == "failed_password" for e in evs):
            for e in evs:
                if e.event_type in ("auth_failure", "invalid_user"):
                    e.counts_as_attempt = False
                    n += 1
    for e in events:
        if e.status == "info":
            e.counts_as_attempt = False
    return n


# ------------------------------------------------------------------ CSV
def _pick(cols, key):
    for alias in CSV_ALIASES[key]:
        if alias in cols:
            return cols[alias]
    return None


def parse_csv_text(text: str) -> ParseResult:
    res = ParseResult(log_format="csv")
    lines = text.splitlines()
    while lines and lines[0].lstrip().startswith("#"):
        if "SYNTHETIC" in lines[0].upper():
            res.synthetic = True
        res.comment_lines += 1
        lines.pop(0)
    if not lines:
        return res
    reader = csv.DictReader(io.StringIO("\n".join(lines)))
    cols = {c.strip().lower(): c for c in (reader.fieldnames or []) if c}
    c_ts, c_ip, c_user = _pick(cols, "timestamp"), _pick(cols, "source_ip"), _pick(cols, "username")
    c_status, c_type, c_msg = _pick(cols, "status"), _pick(cols, "event_type"), _pick(cols, "message")
    if not c_ts or not c_ip or not (c_status or c_type):
        res._err(1, "CSV needs columns: timestamp, source_ip and status (or event_type)", ",".join(cols))
        return res
    for row in reader:
        n = reader.line_num
        res.total_lines += 1
        try:
            if None in row:     # more fields than headers
                raise ValueError("too many fields")
            ts_raw = (row.get(c_ts) or "").strip()
            ts = pd.to_datetime(ts_raw, errors="raise")
            if ts is pd.NaT:
                raise ValueError("empty timestamp")
            ts = ts.tz_convert(None) if ts.tzinfo else ts
            ts = ts.to_pydatetime()
            ip = valid_ip(row.get(c_ip) or "")
            if not ip:
                raise ValueError(f"invalid IP {row.get(c_ip)!r}")
            word = ((row.get(c_status) if c_status else "") or "").strip().lower()
            etype = ((row.get(c_type) if c_type else "") or "").strip().lower()
            if word in SUCCESS_WORDS or etype in ("accepted", "success", "login_success"):
                status = "success"
            elif word in FAILURE_WORDS or etype in FAILURE_WORDS:
                status = "failure"
            else:
                raise ValueError(f"unknown status {word or etype!r}")
            etype = etype or ("accepted" if status == "success" else "failed_password")
            user = clean_user(row.get(c_user) if c_user else "")
            msg = ((row.get(c_msg) if c_msg else "") or "").strip()[:500] or \
                f"{ts_raw} {status} login for {user or '?'} from {ip}"
        except (ValueError, TypeError, OverflowError, pd.errors.ParserError) as exc:
            res._err(n, str(exc)[:80], ",".join(str(v) for v in row.values()))
            continue
        res.auth_lines += 1
        res.events.append(AuthEvent(ts, ip, user, status, etype, msg, n, "", "", "", etype == "invalid_user",
                                    True, "csv"))
    return res


# ------------------------------------------------------------------ entry points
def detect_format(text: str) -> str:
    for line in text.splitlines()[:50]:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if SYSLOG_RE.match(s) or ISO_RE.match(s):
            return "syslog"
        low = s.lower()
        if "," in s and any(a in low for a in CSV_ALIASES["timestamp"]) and \
                any(a in low for a in CSV_ALIASES["source_ip"]):
            return "csv"
    return "unknown"


def parse_text(text: str, fmt: str = "auto", year: int | None = None) -> ParseResult:
    fmt = detect_format(text) if fmt == "auto" else fmt
    if fmt == "csv":
        res = parse_csv_text(text)
    elif fmt == "syslog":
        res = parse_syslog_lines(text.splitlines(), year=year)
    else:
        res = ParseResult(log_format="unknown")
        res.total_lines = sum(1 for ln in text.splitlines() if ln.strip())
        res._err(1, "unrecognised format: expected Linux auth.log lines or CSV with a header", text[:120])
    res.events.sort(key=lambda e: (e.timestamp, e.line_no))
    return res


def decode_bytes(data: bytes) -> str:
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    return data.decode("utf-8", errors="replace")


def parse_file(path, fmt: str = "auto", year: int | None = None) -> ParseResult:
    with open(path, "rb") as fh:
        return parse_text(decode_bytes(fh.read()), fmt, year)


def events_to_frame(events) -> pd.DataFrame:
    cols = ["timestamp", "source_ip", "username", "status", "event_type", "message", "line_no", "host", "pid",
            "method", "invalid_user", "counts_as_attempt", "source"]
    if not events:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame([e.to_dict() for e in events], columns=cols)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df
