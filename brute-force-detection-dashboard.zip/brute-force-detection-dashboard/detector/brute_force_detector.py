"""
brute_force_detector.py - time-window based brute-force detection.

Rules (all windows are SLIDING windows of `time_window_minutes`):
  R1/R2/R3  per source IP: count failed attempts inside every window; an IP is
            flagged when some window holds >= max_failed_attempts failures.
            Overlapping/adjacent flagged windows are merged into one EPISODE,
            and each episode becomes one incident.
  R4        usernames targeted by flagged IPs are summarised per username.
  R5        one IP trying >= multi_user_threshold distinct usernames inside a
            window is flagged even if it stays below max_failed_attempts.
  R6        a successful login from an IP that had >= success_after_failures_min
            failures in the preceding success_lookahead_minutes. Added to the
            IP's brute-force incident, or reported as its own incident.
  R7        one username failing from >= distributed_ip_threshold distinct IPs
            with >= max_failed_attempts failures inside a window (distributed
            attack). A later success for that username, from ANY IP, is noted.

Failures spread over a long time (e.g. 6 typos across a day) never reach
the in-window threshold - the detector does not count the whole file.
Nothing here blocks IPs or contacts any system: it only reads events.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import timedelta

import pandas as pd

from config import DetectionConfig
from detector.log_parser import events_to_frame
from detector.risk_scoring import DISCLAIMER, recommendations, score_incident


@dataclass
class DetectionResult:
    incidents: list = field(default_factory=list)          # list[dict], highest risk first
    suspicious_ips: pd.DataFrame = field(default_factory=pd.DataFrame)
    targeted_usernames: pd.DataFrame = field(default_factory=pd.DataFrame)
    events: pd.DataFrame = field(default_factory=pd.DataFrame)
    metrics: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)
    disclaimer: str = DISCLAIMER


def incident_id(kind: str, key: str, first) -> str:
    h = hashlib.sha1(f"{kind}|{key}|{first.isoformat()}".encode()).hexdigest()[:10].upper()
    return f"INC-{h}"


def window_spans(times: list, window: timedelta, qualifies) -> list[tuple[int, int]]:
    """Two-pointer sliding window. For each start i, the window is times[i..j) with
    times[j-1] - times[i] <= window. Returns merged index ranges [(a, b_inclusive)] of all
    windows for which qualifies(i, j) is True, merging windows that overlap or touch."""
    spans, j, n = [], 0, len(times)
    for i in range(n):
        if j < i:
            j = i
        while j < n and times[j] - times[i] <= window:
            j += 1
        if qualifies(i, j):
            if spans and (i <= spans[-1][1] or
                          (i == spans[-1][1] + 1 and times[i] - times[spans[-1][1]] <= window)):
                spans[-1] = (spans[-1][0], max(spans[-1][1], j - 1))
            else:
                spans.append((i, j - 1))
    return spans


def peak_window(times: list, window: timedelta) -> tuple[int, float | None]:
    """Largest number of events inside any one window, and the mean gap in that window (seconds)."""
    best, best_gap, j = 0, None, 0
    for i in range(len(times)):
        j = max(j, i)
        while j < len(times) and times[j] - times[i] <= window:
            j += 1
        if j - i > best:
            best = j - i
            best_gap = (times[j - 1] - times[i]).total_seconds() / (best - 1) if best > 1 else None
    return best, best_gap


class BruteForceDetector:
    def __init__(self, cfg: DetectionConfig | None = None):
        self.cfg = cfg or DetectionConfig()
        problems = self.cfg.validate()
        if problems:
            raise ValueError("; ".join(problems))
        self.window = timedelta(minutes=self.cfg.time_window_minutes)
        self.lookahead = timedelta(minutes=self.cfg.success_lookahead_minutes)

    # ------------------------------------------------------------------ main
    def analyze(self, events) -> DetectionResult:
        cfg = self.cfg
        fails = [e for e in events if e.status == "failure" and e.counts_as_attempt]
        succ = [e for e in events if e.status == "success"]
        by_ip_f, by_ip_s, by_user_f = defaultdict(list), defaultdict(list), defaultdict(list)
        for e in fails:
            by_ip_f[e.source_ip].append(e)
            by_user_f[e.username].append(e)
        for e in succ:
            by_ip_s[e.source_ip].append(e)
        for d in (by_ip_f, by_ip_s, by_user_f):
            for v in d.values():
                v.sort(key=lambda e: e.timestamp)

        incidents = []
        # ---- R1-R3, R5, R6: per-IP episodes
        for ip, fl in by_ip_f.items():
            times = [e.timestamp for e in fl]

            def qualifies(i, j, fl=fl):
                return (j - i) >= cfg.max_failed_attempts or \
                    len({e.username for e in fl[i:j]}) >= cfg.multi_user_threshold

            spans = window_spans(times, self.window, qualifies)
            episodes = [fl[a:b + 1] for a, b in spans]
            for ep in episodes:
                incidents.append(self._ip_incident(ip, ep, by_ip_s.get(ip, []), len(episodes)))
            # R6 for IPs without a brute-force episode around the success
            covered = [(ep[0].timestamp, ep[-1].timestamp + self.lookahead) for ep in episodes]
            for s in by_ip_s.get(ip, []):
                if any(a <= s.timestamp <= b for a, b in covered):
                    continue
                prior = [e for e in fl if s.timestamp - self.lookahead <= e.timestamp < s.timestamp]
                if len(prior) >= cfg.success_after_failures_min:
                    incidents.append(self._success_incident(ip, prior, s))
                    covered.append((prior[0].timestamp, s.timestamp))
        # ---- R7: distributed attacks per username
        for user, fl in by_user_f.items():
            times = [e.timestamp for e in fl]

            def q2(i, j, fl=fl):
                return (j - i) >= cfg.max_failed_attempts and \
                    len({e.source_ip for e in fl[i:j]}) >= cfg.distributed_ip_threshold

            for a, b in window_spans(times, self.window, q2):
                incidents.append(self._distributed_incident(user, fl[a:b + 1], succ))

        incidents.sort(key=lambda x: (-x["risk_score"], x["first_seen"]))
        df = events_to_frame(events)
        return DetectionResult(incidents, self._suspicious_ips(incidents, by_ip_f, by_ip_s),
                               self._targeted_users(incidents, fails), df, self._metrics(events, incidents),
                               cfg.to_dict())

    # ------------------------------------------------------------------ incident builders
    def _base(self, kind, key, ep):
        times = [e.timestamp for e in ep]
        peak, gap = peak_window(times, self.window)
        users = sorted({e.username for e in ep})
        invalid = sorted({e.username for e in ep if e.invalid_user})
        return {"incident_type": kind, "first_seen": times[0], "last_seen": times[-1],
                "duration_s": (times[-1] - times[0]).total_seconds(), "failed_attempts": len(ep),
                "peak_window_attempts": peak, "mean_interval_s": round(gap, 1) if gap is not None else None,
                "usernames": users, "invalid_usernames": len(invalid), "line_numbers": [e.line_no for e in ep][:500],
                "sample_messages": [e.message for e in ep[:5]], "successful_logins": 0,
                "success_after_failures": False, "success_users": [], "success_details": [], "repeat_episodes": 1,
                "ip_count": len({e.source_ip for e in ep}), "source_ips": sorted({e.source_ip for e in ep}),
                "id_key": key}

    def _finish(self, inc):
        score, level, reasons, breakdown = score_incident(inc, self.cfg)
        inc.update(risk_score=score, risk_level=level, reasons=reasons,
                   score_breakdown=[{"factor": f, "points": p} for f, p in breakdown],
                   recommendations=recommendations(inc),
                   incident_id=incident_id(inc["incident_type"], inc["id_key"], inc["first_seen"]))
        return inc

    def _ip_incident(self, ip, ep, successes, n_episodes):
        cfg = self.cfg
        n_users = len({e.username for e in ep})
        multi = n_users >= cfg.multi_user_threshold
        kind = ("Brute force - multiple usernames" if multi else
                "Brute force - single username" if n_users == 1 else "Brute force - repeated failures from one IP")
        inc = self._base(kind, ip, ep)
        inc.update(source_ip=ip, username_key=ep[0].username if not multi else "", repeat_episodes=n_episodes)
        start, end = ep[0].timestamp, ep[-1].timestamp + self.lookahead
        hits = [s for s in successes if start <= s.timestamp <= end]
        inc["successful_logins"] = len(hits)
        if hits:
            inc["success_after_failures"] = True
            inc["success_users"] = sorted({s.username for s in hits})
            inc["success_details"] = [f"{s.timestamp:%Y-%m-%d %H:%M:%S} {s.username} ({s.method or s.event_type})"
                                      for s in hits[:10]]
            if inc["incident_type"] == "Brute force - single username":
                inc["incident_type"] = "Brute force - successful login after failures"
        return self._finish(inc)

    def _success_incident(self, ip, prior, s):
        inc = self._base("Successful login after repeated failures", ip, prior)
        inc.update(source_ip=ip, username_key=s.username, successful_logins=1, success_after_failures=True,
                   success_users=[s.username],
                   success_details=[f"{s.timestamp:%Y-%m-%d %H:%M:%S} {s.username} ({s.method or s.event_type})"],
                   last_seen=s.timestamp)
        return self._finish(inc)

    def _distributed_incident(self, user, ep, successes):
        inc = self._base("Distributed attack on one username", user, ep)
        start, end = ep[0].timestamp, ep[-1].timestamp + self.lookahead
        hits = [s for s in successes if s.username == user and start <= s.timestamp <= end]
        inc.update(source_ip=f"{inc['ip_count']} IPs", username_key=user, successful_logins=len(hits))
        if hits:
            inc.update(success_after_failures=True, success_users=[user],
                       success_details=[f"{s.timestamp:%Y-%m-%d %H:%M:%S} {user} from {s.source_ip}" for s in hits[:10]])
        return self._finish(inc)

    # ------------------------------------------------------------------ summaries
    def _suspicious_ips(self, incidents, by_ip_f, by_ip_s) -> pd.DataFrame:
        rows = {}
        for inc in incidents:
            ips = inc["source_ips"] if inc["incident_type"].startswith("Distributed") else [inc["source_ip"]]
            for ip in ips:
                r = rows.setdefault(ip, {"ip_address": ip, "risk_score": 0, "risk_level": "Low", "incidents": 0,
                                         "incident_types": set()})
                r["incidents"] += 1
                r["incident_types"].add(inc["incident_type"])
                if inc["risk_score"] > r["risk_score"]:
                    r["risk_score"], r["risk_level"] = inc["risk_score"], inc["risk_level"]
        out = []
        for ip, r in rows.items():
            f, s = by_ip_f.get(ip, []), by_ip_s.get(ip, [])
            out.append({"ip_address": ip, "total_failed_attempts": len(f), "successful_logins": len(s),
                        "usernames_targeted": len({e.username for e in f}),
                        "usernames": ", ".join(sorted({e.username for e in f}))[:300],
                        "first_detected": f[0].timestamp if f else None, "last_detected": f[-1].timestamp if f else None,
                        "risk_score": r["risk_score"], "risk_level": r["risk_level"], "incidents": r["incidents"],
                        "incident_types": "; ".join(sorted(r["incident_types"]))})
        df = pd.DataFrame(out, columns=["ip_address", "total_failed_attempts", "successful_logins", "usernames_targeted",
                                        "usernames", "first_detected", "last_detected", "risk_score", "risk_level",
                                        "incidents", "incident_types"])
        return df.sort_values(["risk_score", "total_failed_attempts"], ascending=False).reset_index(drop=True)

    def _targeted_users(self, incidents, fails) -> pd.DataFrame:
        flagged = set()
        for inc in incidents:
            flagged.update(inc["source_ips"])
        per = defaultdict(lambda: {"failed_attempts": 0, "ips": set(), "from_flagged": 0})
        for e in fails:
            p = per[e.username]
            p["failed_attempts"] += 1
            p["ips"].add(e.source_ip)
            if e.source_ip in flagged:
                p["from_flagged"] += 1
        rows = [{"username": u or "(empty)", "failed_attempts": v["failed_attempts"], "source_ips": len(v["ips"]),
                 "attempts_from_suspicious_ips": v["from_flagged"],
                 "exists_on_server": "no (invalid user)" if any(e.invalid_user for e in fails if e.username == u)
                 else "unknown/yes"} for u, v in per.items()]
        df = pd.DataFrame(rows, columns=["username", "failed_attempts", "source_ips", "attempts_from_suspicious_ips",
                                         "exists_on_server"])
        return df.sort_values(["attempts_from_suspicious_ips", "failed_attempts"], ascending=False).reset_index(drop=True)

    def _metrics(self, events, incidents) -> dict:
        lv = defaultdict(int)
        for i in incidents:
            lv[i["risk_level"]] += 1
        ips = set()
        for i in incidents:
            ips.update(i["source_ips"])
        return {"total_events": len(events),
                "failed_attempts": sum(1 for e in events if e.status == "failure" and e.counts_as_attempt),
                "successful_logins": sum(1 for e in events if e.status == "success"),
                "unique_ips": len({e.source_ip for e in events}), "suspicious_ips": len(ips),
                "incidents": len(incidents),
                "brute_force_incidents": sum(1 for i in incidents if i["incident_type"].startswith(("Brute", "Distributed"))),
                "critical": lv["Critical"], "high": lv["High"], "medium": lv["Medium"], "low": lv["Low"],
                "success_after_failures": sum(1 for i in incidents if i["success_after_failures"]),
                "first_event": min((e.timestamp for e in events), default=None),
                "last_event": max((e.timestamp for e in events), default=None)}


def analyze_events(events, cfg: DetectionConfig | None = None) -> DetectionResult:
    return BruteForceDetector(cfg).analyze(events)
