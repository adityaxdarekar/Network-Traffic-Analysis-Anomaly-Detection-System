"""SQLite storage for incidents."""
