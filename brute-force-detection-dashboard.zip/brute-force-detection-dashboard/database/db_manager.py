"""
db_manager.py - SQLite storage for incidents, analyst notes and analysis runs.

Tables
  incidents       one row per detected incident (stable ID), detection fields,
                  analyst status (Open / Investigating / Resolved)
  incident_notes  timestamped analyst notes and status changes (history)
  analyses        one row per analysis run (source, counts, settings used)

Only parameterised SQL is used. Status and notes survive restarts because
re-analysing the same log produces the same incident IDs and the upsert
never overwrites status or notes.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
    incident_id       TEXT PRIMARY KEY,
    incident_type     TEXT NOT NULL,
    source_ip         TEXT,
    username_key      TEXT,
    usernames         TEXT,            -- JSON list
    failed_attempts   INTEGER,
    successful_logins INTEGER,
    first_seen        TEXT,
    last_seen         TEXT,
    risk_score        INTEGER,
    risk_level        TEXT,
    reasons           TEXT,            -- JSON list
    details           TEXT,            -- JSON (full incident)
    source_name       TEXT,
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Investigating','Resolved')),
    analyst_notes     TEXT DEFAULT '',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    times_detected    INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_inc_ip ON incidents(source_ip);
CREATE INDEX IF NOT EXISTS ix_inc_level ON incidents(risk_level);
CREATE TABLE IF NOT EXISTS incident_notes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id  TEXT NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    timestamp    TEXT NOT NULL,
    analyst      TEXT,
    status       TEXT,
    note         TEXT
);
CREATE TABLE IF NOT EXISTS analyses (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp      TEXT NOT NULL,
    source_name    TEXT,
    synthetic      INTEGER,
    total_events   INTEGER,
    failed         INTEGER,
    successful     INTEGER,
    incidents      INTEGER,
    settings       TEXT
);
"""
STATUSES = ("Open", "Investigating", "Resolved")


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _clean(text: str, limit: int) -> str:
    text = "".join(ch for ch in (text or "") if ch.isprintable() or ch in "\n\t")
    return text.strip()[:limit]


class DBManager:
    def __init__(self, path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    @contextmanager
    def tx(self):
        with self._lock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def close(self):
        with self._lock:
            self.conn.close()

    # ---------------------------------------------------------------- incidents
    def upsert_incidents(self, incidents: list[dict], source_name: str) -> int:
        now = now_iso()
        rows = []
        for i in incidents:
            rows.append({
                "incident_id": i["incident_id"], "incident_type": i["incident_type"], "source_ip": i["source_ip"],
                "username_key": i.get("username_key", ""), "usernames": json.dumps(i["usernames"]),
                "failed_attempts": i["failed_attempts"], "successful_logins": i["successful_logins"],
                "first_seen": i["first_seen"].isoformat(sep=" "), "last_seen": i["last_seen"].isoformat(sep=" "),
                "risk_score": i["risk_score"], "risk_level": i["risk_level"], "reasons": json.dumps(i["reasons"]),
                "details": json.dumps(i, default=str), "source_name": source_name[:200], "now": now})
        with self.tx() as c:
            c.executemany("""
                INSERT INTO incidents(incident_id, incident_type, source_ip, username_key, usernames, failed_attempts,
                    successful_logins, first_seen, last_seen, risk_score, risk_level, reasons, details, source_name,
                    created_at, updated_at)
                VALUES (:incident_id, :incident_type, :source_ip, :username_key, :usernames, :failed_attempts,
                    :successful_logins, :first_seen, :last_seen, :risk_score, :risk_level, :reasons, :details,
                    :source_name, :now, :now)
                ON CONFLICT(incident_id) DO UPDATE SET
                    incident_type=excluded.incident_type, usernames=excluded.usernames,
                    failed_attempts=excluded.failed_attempts, successful_logins=excluded.successful_logins,
                    last_seen=excluded.last_seen, risk_score=excluded.risk_score, risk_level=excluded.risk_level,
                    reasons=excluded.reasons, details=excluded.details, source_name=excluded.source_name,
                    updated_at=excluded.updated_at, times_detected=incidents.times_detected + 1
                    -- status and analyst_notes are deliberately NOT overwritten
                """, rows)
        return len(rows)

    def _row(self, r) -> dict:
        d = dict(r)
        d["usernames"] = json.loads(d["usernames"] or "[]")
        d["reasons"] = json.loads(d["reasons"] or "[]")
        d["details"] = json.loads(d["details"] or "{}")
        return d

    def get_incident(self, incident_id: str) -> dict | None:
        with self._lock:
            r = self.conn.execute("SELECT * FROM incidents WHERE incident_id=?", (incident_id,)).fetchone()
        if not r:
            return None
        d = self._row(r)
        d["notes"] = self.notes(incident_id)
        return d

    def list_incidents(self, levels=None, ip_search: str = "", statuses=None, ids=None, limit: int = 5000) -> list:
        sql, args = "SELECT * FROM incidents WHERE 1=1", []
        if levels:
            sql += f" AND risk_level IN ({','.join('?' * len(levels))})"
            args += list(levels)
        if statuses:
            sql += f" AND status IN ({','.join('?' * len(statuses))})"
            args += list(statuses)
        if ip_search:
            sql += " AND (source_ip LIKE ? OR details LIKE ?)"
            args += [f"%{ip_search}%", f'%"{ip_search}%']
        if ids is not None:
            ids = list(ids)
            if not ids:
                return []
            sql += f" AND incident_id IN ({','.join('?' * len(ids))})"
            args += ids
        sql += " ORDER BY risk_score DESC, first_seen LIMIT ?"
        args.append(limit)
        with self._lock:
            return [self._row(r) for r in self.conn.execute(sql, args).fetchall()]

    def update_status(self, incident_id: str, status: str, note: str = "", analyst: str = "analyst") -> bool:
        if status not in STATUSES:
            raise ValueError(f"status must be one of {STATUSES}")
        note = _clean(note, 2000)
        analyst = _clean(analyst, 60) or "analyst"
        ts = now_iso()
        with self.tx() as c:
            cur = c.execute("UPDATE incidents SET status=?, updated_at=?, analyst_notes=CASE WHEN ?<>'' THEN ? "
                            "ELSE analyst_notes END WHERE incident_id=?", (status, ts, note, note, incident_id))
            if cur.rowcount != 1:
                return False
            c.execute("INSERT INTO incident_notes(incident_id, timestamp, analyst, status, note) VALUES (?,?,?,?,?)",
                      (incident_id, ts, analyst, status, note))
        return True

    def notes(self, incident_id: str) -> list:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT timestamp, analyst, status, note FROM incident_notes WHERE incident_id=? ORDER BY id",
                (incident_id,)).fetchall()]

    def status_counts(self) -> dict:
        with self._lock:
            rows = self.conn.execute("SELECT status, COUNT(*) n FROM incidents GROUP BY status").fetchall()
        out = {s: 0 for s in STATUSES}
        out.update({r["status"]: r["n"] for r in rows})
        return out

    def delete_all(self):
        """Used only by the 'Clear incident database' button (asks for confirmation in the UI)."""
        with self.tx() as c:
            c.execute("DELETE FROM incident_notes")
            c.execute("DELETE FROM incidents")
            c.execute("DELETE FROM analyses")

    # ---------------------------------------------------------------- analyses
    def record_analysis(self, source_name, synthetic, metrics, settings) -> int:
        with self.tx() as c:
            return c.execute("INSERT INTO analyses(timestamp, source_name, synthetic, total_events, failed, successful,"
                             " incidents, settings) VALUES (?,?,?,?,?,?,?,?)",
                             (now_iso(), source_name[:200], int(bool(synthetic)), metrics["total_events"],
                              metrics["failed_attempts"], metrics["successful_logins"], metrics["incidents"],
                              json.dumps(settings))).lastrowid

    def analyses(self, limit=50) -> list:
        with self._lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM analyses ORDER BY id DESC LIMIT ?", (limit,))]
