#!/usr/bin/env python3
"""
run_demos.py - runs the six college demonstrations end to end on SYNTHETIC logs,
using exactly the modules the dashboard uses, and prints the results.

    python run_demos.py              # all demos, uses database/incidents.db
    python run_demos.py --db /tmp/x.db

The dashboard shows the same results visually; this script lets you verify
them (and is what produced sample_output/demo_results.txt).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from config import DB_PATH, SAMPLE_DIR, DetectionConfig
from database.db_manager import DBManager
from detector.brute_force_detector import analyze_events
from detector.incident_manager import IncidentManager
from detector.log_parser import parse_file
from utils.helpers import fmt_duration, fmt_ts
from utils.report_generator import incidents_csv, pdf_report, suspicious_ips_csv
from utils.sample_log_generator import generate_all

ROOT = Path(__file__).resolve().parent


def banner(t):
    print("\n" + "=" * 76 + f"\n {t}\n" + "=" * 76)


def show(res):
    m = res.metrics
    print(f"  events {m['total_events']} | failed {m['failed_attempts']} | successful {m['successful_logins']} | "
          f"suspicious IPs {m['suspicious_ips']} | incidents {m['incidents']}")
    for i in res.incidents:
        print(f"  [{i['risk_level'].upper()} {i['risk_score']}/100] {i['incident_type']}  {i['incident_id']}")
        print(f"     source {i['source_ip']} | failed {i['failed_attempts']} (peak {i['peak_window_attempts']} in one window)"
              f" | usernames: {', '.join(i['usernames'])}")
        print(f"     first {fmt_ts(i['first_seen'])}  last {fmt_ts(i['last_seen'])}  ({fmt_duration(i['duration_s'])})")
        print("     score: " + " + ".join(f"{b['factor']} ({b['points']})" for b in i["score_breakdown"]))
        for d in i["success_details"]:
            print(f"     ! SUCCESSFUL LOGIN after failures: {d}")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=str(DB_PATH))
    ap.add_argument("--out", default=str(ROOT / "sample_output"))
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    cfg = DetectionConfig()
    print("SYNTHETIC DATA ONLY - no SSH service is contacted. Settings:", cfg.to_dict())
    print("Regenerating sample logs:", generate_all(SAMPLE_DIR))
    ok = {}

    banner("DEMO 1 - Normal authentication (demo1_normal.log)")
    p = parse_file(SAMPLE_DIR / "demo1_normal.log")
    r = analyze_events(p.events, cfg)
    show(r)
    print(f"  includes {sum(1 for e in p.events if e.status == 'failure' and e.counts_as_attempt)} ordinary failures "
          "(typos and a slow series of 6 failures over 2.5 h from 10.20.3.41)")
    ok[1] = r.metrics["incidents"] == 0
    print("  RESULT:", "no brute force reported - ordinary activity is not misclassified" if ok[1] else "UNEXPECTED")

    banner("DEMO 2 - Brute force: 15 failures from one IP within five minutes")
    r = analyze_events(parse_file(SAMPLE_DIR / "demo2_brute_force.log").events, cfg)
    show(r)
    i = r.incidents[0]
    ok[2] = i["failed_attempts"] == 15 and i["duration_s"] <= 300 and i["risk_level"] == "High"

    banner("DEMO 3 - One IP targeting multiple usernames")
    r = analyze_events(parse_file(SAMPLE_DIR / "demo3_multi_username.log").events, cfg)
    show(r)
    print("  targeted accounts:", ", ".join(r.targeted_usernames["username"]))
    ok[3] = r.incidents[0]["incident_type"] == "Brute force - multiple usernames"

    banner("DEMO 4 - Successful login after failures")
    r = analyze_events(parse_file(SAMPLE_DIR / "demo4_success_after_failures.log").events, cfg)
    show(r)
    print("  WHY IT MATTERS: the same IP failed 8 times and then logged in - the password may have been guessed.")
    ok[4] = r.incidents[0]["success_after_failures"]

    banner("DEMO 5 - Incident management with persistence (auth.log, the mixed sample)")
    db = DBManager(a.db)
    im = IncidentManager(db)
    p = parse_file(SAMPLE_DIR / "auth.log")
    r = analyze_events(p.events, cfg)
    im.sync(r, "auth.log", p.synthetic)
    target = r.incidents[0]["incident_id"]
    im.set_status(target, "Investigating", "Demo 5: 12 usernames from one TEST-NET IP; checking whether any account "
                                           "exists with a weak password.", "student-analyst")
    print(f"  {target} set to Investigating with a note")
    db.close()
    print("  ...closing the database (simulated application restart)...")
    db = DBManager(a.db)
    im = IncidentManager(db)
    r = analyze_events(parse_file(SAMPLE_DIR / "auth.log").events, cfg)
    im.sync(r, "auth.log", True)
    got = im.get(target)
    print(f"  after restart: status={got['status']} note={got['analyst_notes']!r} detected {got['times_detected']} times")
    ok[5] = got["status"] == "Investigating" and got["analyst_notes"].startswith("Demo 5")

    banner("DEMO 6 - Report generation")
    merged = im.merged(r)
    (out / "incidents_report.csv").write_bytes(incidents_csv(merged))
    (out / "suspicious_ips.csv").write_bytes(suspicious_ips_csv(r))
    (out / "security_incident_report.pdf").write_bytes(pdf_report(r, merged, "auth.log", True))
    for f in ("incidents_report.csv", "suspicious_ips.csv", "security_incident_report.pdf"):
        print(f"  wrote sample_output/{f} ({(out / f).stat().st_size} bytes)")
    print("\n  Suspicious IPs:")
    for row in r.suspicious_ips.itertuples():
        print(f"   {row.ip_address:15} failed {row.total_failed_attempts:>3} success {row.successful_logins} users "
              f"{row.usernames_targeted:>2} score {row.risk_score:>3} {row.risk_level}")
    ok[6] = all((out / f).stat().st_size > 0 for f in ("incidents_report.csv", "suspicious_ips.csv",
                                                        "security_incident_report.pdf"))
    db.close()

    banner("SUMMARY")
    for k in sorted(ok):
        print(f"  Demo {k}: {'PASS' if ok[k] else 'FAIL'}")
    return 0 if all(ok.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
