# Demonstration Guide (≈ 10–12 minutes)

A script for showing the project to a professor or in a viva. Practise it once beforehand.

## Before the demo
1. `venv\Scripts\activate` then `streamlit run app.py` (or double-click `run_app.bat`).
2. Open <http://localhost:8501> and check the **Upload PCAP** page loads.
3. Optional: in another terminal run `python -m pytest` so you can show the test results.
4. Optional: have Wireshark open with `sample_data\mixed_demo.pcapng` to show the raw packets.

## 1. Introduce the problem (1 min)
"Raw captures contain thousands of packets. A SOC analyst needs them summarised and needs the suspicious
parts pointed out, with an explanation. This tool does that, locally and without decrypting anything."
Show **About Project** (architecture diagram and privacy principles).

## 2. Baseline: normal traffic (1.5 min)
**Upload PCAP → Sample capture → `normal_traffic.pcapng` → Analyse sample → Open the Overview dashboard.**
* Point at the KPI cards and the protocol donut (DNS, HTTPS/TLS, TCP...).
* **Anomaly Detection** shows *no alerts* - "a good detector must also stay quiet on normal traffic".
* **HTTP/TLS Analysis**: the two tabs show clear-text HTTP (method, host, path) versus HTTPS where only the
  TLS version and SNI are visible. "We never decrypt HTTPS."

## 3. The full scenario (4 min)
Load **`mixed_demo.pcapng`** - it triggers all ten rules.
* **Overview**: 19 alerts, severity donut, traffic spike in the timeline (the SYN burst).
* **Anomaly Detection**: filter *Severity = Critical*. Open **Possible Port Scanning**:
  reason (300 ports in 60 s, threshold 20), evidence (which ports answered SYN-ACK), recommended steps.
  Open **Possible SYN Flood Pattern**: 450 SYNs, none answered, many distinct sources.
  Open **Possible DNS Tunneling Indicators** and then go to **DNS Analysis → Unusual DNS behaviour** to
  show the long random sub-domains of `tunnel-lab.example`.
* **TCP/UDP Analysis**: connection states, the failed RDP attempts, retransmissions.
* **IP Investigation**: pick `192.168.1.50` → its peers, protocols and related alerts. Show the address
  categories ("public ≠ malicious").
* **Packet Explorer**: filter *Port = 3389* → open a packet's detail view.

## 4. Tuning (1 min)
**Settings → R1 Possible Port Scanning** → raise *port scan unique ports* to 400 → **Save settings**.
Back on **Anomaly Detection** the port-scan alert is gone (detection re-ran instantly). Reset to defaults.
"Thresholds are transparent and per-network."

## 5. Report and history (1.5 min)
**Reports → PDF report → Generate → Download**. Scroll through: cover, contents, executive summary,
methodology with thresholds, charts, alert details, recommendations. Then **Previous sessions** to show the
SQLite history, and **Export data** for CSV/ZIP.

## 6. Live capture (1 min, only on your own network)
**Live Capture**: show the capture-environment panel (TShark/Npcap detected), choose Wi-Fi, 20 s, tick the
permission box, **Start**, open a website, watch the counter, then **Analyse this capture**.
If capture is unavailable on the demo PC, explain the fallback: upload mode gives the full analysis.

## 7. Quality (30 s)
Show `python -m pytest` → **95 passed**. Mention synthetic test traffic and the edge cases (empty, corrupt,
truncated, huge files, missing TShark).

## Likely viva questions - short answers
| Question | Answer |
|---|---|
| Why not decrypt HTTPS? | It would require the private keys/MITM, is intrusive and unnecessary; metadata (SNI, version, volume, destinations) is enough for these detections. |
| How does port-scan detection work? | Sliding 60 s window per source/target pair; counts distinct destination ports; ≥ 20 → alert; severity rises at 3× and 10× the threshold. |
| How do you avoid false positives? | Context checks (RST counts as an answer for SYN flood, echo replies ignored, failures required for R4), configurable thresholds, allow-lists, and alerts are worded as indicators. |
| What is DNS tunnelling? | Encoding data in DNS queries; indicators are many unique, long, high-entropy sub-domains of one domain and TXT-heavy queries. |
| Why your own PCAP parser instead of only Scapy/PyShark? | Streaming (low memory), never crashes on corrupt files, fast, no dependency for analysis/tests. Scapy is still supported as an engine and for capture. |
| What happens with a corrupted file? | Complete packets are analysed, the truncation is reported, malformed packets are flagged - no crash. |
| How is privacy handled? | Local processing only, no payload storage, HTTP query strings and cookies dropped, IP masking option, mandatory permission confirmation for capture. |
| Limitations? | Encrypted content, capture completeness, threshold heuristics, tested on synthetic data only. |
| Where is the data stored? | `output/analysis_history.db` (SQLite): statistics and alerts only. |
