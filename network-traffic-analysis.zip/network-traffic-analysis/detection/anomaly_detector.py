"""
Anomaly detection engine: runs the enabled rules, numbers the alerts and
returns them as a sorted DataFrame.
"""

from __future__ import annotations

import pandas as pd

from config import MAX_ALERTS_PER_RULE, RULE_NAMES, SEVERITY_ORDER, load_settings
from detection.detection_rules import ALL_RULES, Alert, RuleContext

ALERT_COLUMNS = ["alert_id", "rule_id", "detection", "category", "severity", "src_ip", "dst_ip", "port",
                 "start_time", "end_time", "time_range", "event_count", "reason", "recommendation", "evidence"]


class AnomalyDetector:
    """Run the rule set against analysed packets.

    Example::

        detector = AnomalyDetector(settings)
        alerts_df = detector.run(packets_df, connections_df)
        print(detector.errors)        # any rule that failed (other rules still run)
    """

    def __init__(self, settings: dict | None = None):
        self.settings = settings or load_settings()
        self.errors: list[str] = []
        self.notes: list[str] = []
        self.rules_run: list[str] = []

    def run(self, packets: pd.DataFrame, connections: pd.DataFrame) -> pd.DataFrame:
        self.errors, self.notes, self.rules_run = [], [], []
        if packets is None or packets.empty:
            return pd.DataFrame(columns=ALERT_COLUMNS)
        ctx = RuleContext(packets=packets, connections=connections,
                          thresholds=self.settings["thresholds"], settings=self.settings)
        enabled = self.settings.get("rules_enabled", {})
        alerts: list[Alert] = []
        for rule_id, rule in ALL_RULES.items():
            if not enabled.get(rule_id, True):
                continue
            self.rules_run.append(rule_id)
            try:
                found = rule(ctx)
            except Exception as exc:  # noqa: BLE001 - one broken rule must not stop the others
                self.errors.append(f"{rule_id} ({RULE_NAMES[rule_id]}) failed: {exc.__class__.__name__}: {exc}")
                continue
            if len(found) > MAX_ALERTS_PER_RULE:
                self.notes.append(f"{RULE_NAMES[rule_id]}: {len(found)} alerts found, showing the "
                                  f"{MAX_ALERTS_PER_RULE} most severe.")
                found.sort(key=lambda a: (-SEVERITY_ORDER.index(a.severity), -a.event_count))
                found = found[:MAX_ALERTS_PER_RULE]
            alerts.extend(found)
        self.notes.extend(ctx.notes)

        alerts.sort(key=lambda a: (-SEVERITY_ORDER.index(a.severity), a.start_time or 0))
        for i, alert in enumerate(alerts, start=1):
            alert.alert_id = f"ALERT-{i:04d}"
        if not alerts:
            return pd.DataFrame(columns=ALERT_COLUMNS)
        df = pd.DataFrame([a.to_dict() for a in alerts])
        df["port"] = pd.to_numeric(df["port"], errors="coerce").astype("Int64")
        return df[ALERT_COLUMNS]


def severity_counts(alerts: pd.DataFrame) -> dict:
    counts = {s: 0 for s in SEVERITY_ORDER}
    if alerts is not None and not alerts.empty:
        for sev, n in alerts["severity"].value_counts().items():
            counts[sev] = int(n)
    return counts
