"""
The ten transparent, threshold-based detection rules.

Every rule:
    * receives a :class:`RuleContext` (packets, TCP connections, settings),
    * returns a list of :class:`Alert` objects,
    * explains *why* it fired in plain language, and
    * suggests investigation steps.

Alerts are HEURISTIC INDICATORS that deserve a look - they are never
described as confirmed attacks. Each rule's docstring states its logic.
"""

from __future__ import annotations

import ipaddress
from collections import Counter
from dataclasses import asdict, dataclass, field

import pandas as pd

from analyzer.dns_analyzer import domain_heuristics
from analyzer.ip_analyzer import classify_ip, is_external
from config import RULE_NAMES, SEVERITY_ORDER
from utils.helpers import human_bytes, registered_domain, ts_to_str


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------
@dataclass
class Alert:
    rule_id: str
    detection: str
    severity: str
    src_ip: str | None
    dst_ip: str | None
    port: int | None
    start_time: float | None
    end_time: float | None
    event_count: int
    reason: str
    recommendation: str
    category: str = ""
    evidence: dict = field(default_factory=dict)
    alert_id: str = ""            # assigned by the AnomalyDetector

    def to_dict(self) -> dict:
        d = asdict(self)
        d["time_range"] = f"{ts_to_str(self.start_time)} → {ts_to_str(self.end_time)}"
        d["evidence"] = "; ".join(f"{k}: {v}" for k, v in self.evidence.items())
        return d


@dataclass
class RuleContext:
    packets: pd.DataFrame
    connections: pd.DataFrame
    thresholds: dict
    settings: dict
    notes: list[str] = field(default_factory=list)   # rule-level remarks (e.g. capture limitations)

    def base_severity(self, rule_id: str) -> str:
        return self.settings.get("rule_severity", {}).get(rule_id, "Low")


def scale_severity(base: str, observed: float, threshold: float) -> str:
    """Raise severity by one level at 3x the threshold and by two levels at 10x."""
    level = SEVERITY_ORDER.index(base) if base in SEVERITY_ORDER else 0
    ratio = observed / threshold if threshold else 1
    if ratio >= 10:
        level += 2
    elif ratio >= 3:
        level += 1
    return SEVERITY_ORDER[min(level, len(SEVERITY_ORDER) - 1)]


def lower_severity(sev: str) -> str:
    return SEVERITY_ORDER[max(SEVERITY_ORDER.index(sev) - 1, 0)]


def _window_peak(times: list[float], items: list, window: float, distinct: bool) -> tuple[int, float, float]:
    """
    Sliding time window over (sorted) events.
    Returns (peak count, window start, window end) where count is the number
    of events - or of distinct items when ``distinct`` is True.
    """
    best, best_start, best_end = 0, None, None
    left = 0
    counts: Counter = Counter()
    for right, (t, item) in enumerate(zip(times, items)):
        counts[item] += 1
        while t - times[left] > window:
            counts[items[left]] -= 1
            if counts[items[left]] == 0:
                del counts[items[left]]
            left += 1
        value = len(counts) if distinct else (right - left + 1)
        if value > best:
            best, best_start, best_end = value, times[left], t
    return best, best_start, best_end


def _syn_only(df: pd.DataFrame) -> pd.DataFrame:
    return df[(df["transport"] == "TCP") & df["flag_syn"] & ~df["flag_ack"]]


def _syn_ack_keys(df: pd.DataFrame) -> set:
    sa = df[(df["transport"] == "TCP") & df["flag_syn"] & df["flag_ack"]]
    # key written from the client's point of view: (client ip, client port, server ip, server port)
    return set(zip(sa["dst_ip"], sa["dst_port"], sa["src_ip"], sa["src_port"]))


def _port(value):
    return int(value) if value is not None and not pd.isna(value) else None


# ---------------------------------------------------------------------------
# Rule 1 - Possible port scanning
# ---------------------------------------------------------------------------
REC_PORT_SCAN = ("Identify the device that owns the source IP and whether a scan was authorised (IT audit, "
                 "vulnerability scanner). Check which probed ports answered (SYN-ACK = open). Review firewall "
                 "logs on the target and confirm only required services are exposed.")


def rule_port_scan(ctx: RuleContext) -> list[Alert]:
    """One source contacting >= N distinct destination ports on one target inside a time window.
    TCP SYN packets and UDP datagrams are evaluated separately."""
    t = ctx.thresholds
    df = ctx.packets
    alerts = []
    syn = _syn_only(df)
    udp = df[(df["transport"] == "UDP") & ~df["protocol"].eq("DNS")]
    synack = _syn_ack_keys(df)
    rst = df[(df["transport"] == "TCP") & df["flag_rst"]]
    rst_keys = set(zip(rst["dst_ip"], rst["dst_port"], rst["src_ip"], rst["src_port"]))
    for proto, frame in (("TCP", syn), ("UDP", udp)):
        if frame.empty:
            continue
        frame = frame.sort_values("timestamp")
        for (src, dst), g in frame.groupby(["src_ip", "dst_ip"]):
            if g["dst_port"].nunique() < t["port_scan_unique_ports"]:
                continue
            peak, start, end = _window_peak(g["timestamp"].tolist(), g["dst_port"].tolist(),
                                            t["port_scan_window_sec"], distinct=True)
            if peak < t["port_scan_unique_ports"]:
                continue
            evidence = {"distinct ports in window": peak, "total distinct ports": g["dst_port"].nunique(),
                        "protocol": proto}
            if proto == "TCP":
                open_ports = sorted({int(p) for s, sp, d, p in zip(g["src_ip"], g["src_port"], g["dst_ip"], g["dst_port"])
                                     if (s, sp, d, p) in synack})
                closed = sum((s, sp, d, p) in rst_keys for s, sp, d, p in
                             zip(g["src_ip"], g["src_port"], g["dst_ip"], g["dst_port"]))
                evidence["ports that answered SYN-ACK"] = ", ".join(map(str, open_ports[:15])) or "none"
                evidence["ports that answered RST"] = closed
            sample = sorted(g["dst_port"].dropna().astype(int).unique())[:12]
            evidence["sample ports"] = ", ".join(map(str, sample))
            alerts.append(Alert(
                "R1", RULE_NAMES["R1"], scale_severity(ctx.base_severity("R1"), peak, t["port_scan_unique_ports"]),
                src, dst, None, start, end, len(g),
                f"{src} sent {proto} probes to {peak} different ports on {dst} within "
                f"{t['port_scan_window_sec']} s (threshold {t['port_scan_unique_ports']}). Contacting many ports on "
                f"one host in a short time is typical of port scanning, but also of some inventory/monitoring tools.",
                REC_PORT_SCAN, "Reconnaissance", evidence))
    return alerts


# ---------------------------------------------------------------------------
# Rule 2 - Possible SYN flood pattern
# ---------------------------------------------------------------------------
REC_SYN_FLOOD = ("Check whether the target service was slow or unavailable at this time. Look at the number of "
                 "distinct source addresses (many random sources suggests spoofing). Verify the capture saw both "
                 "directions of traffic before drawing conclusions. Consider SYN cookies / rate limiting.")


def rule_syn_flood(ctx: RuleContext) -> list[Alert]:
    """>= N SYNs to one destination inside a window where most received no reply at all (no SYN-ACK / RST).
    Severity is lowered when the capture contains no SYN-ACKs at all (likely one-direction capture)."""
    t = ctx.thresholds
    df = ctx.packets
    syn = _syn_only(df).sort_values("timestamp")
    if syn.empty:
        return []
    synack = _syn_ack_keys(df)
    rst = df[(df["transport"] == "TCP") & df["flag_rst"]]
    rst_keys = set(zip(rst["dst_ip"], rst["dst_port"], rst["src_ip"], rst["src_port"]))
    capture_has_synack = bool(synack)
    alerts = []
    for dst, g in syn.groupby("dst_ip"):
        if len(g) < t["syn_flood_syn_count"]:
            continue
        peak, start, end = _window_peak(g["timestamp"].tolist(), [0] * len(g), t["syn_flood_window_sec"], False)
        if peak < t["syn_flood_syn_count"]:
            continue
        w = g[(g["timestamp"] >= start) & (g["timestamp"] <= end)]
        # A SYN counts as "answered" if the target replied with SYN-ACK (open) or RST (closed port).
        # RST replies are typical of port scans, which Rule 1 covers - so they do not count here.
        answered = sum((s, sp, d, dp) in synack or (s, sp, d, dp) in rst_keys for s, sp, d, dp in
                       zip(w["src_ip"], w["src_port"], w["dst_ip"], w["dst_port"]))
        incomplete = 1 - answered / len(w)
        if incomplete < t["syn_flood_incomplete_ratio"]:
            continue
        sev = scale_severity(ctx.base_severity("R2"), peak, t["syn_flood_syn_count"])
        note = ""
        if not capture_has_synack:
            sev = lower_severity(sev)
            note = (" Note: the capture contains no SYN-ACK packets at all, so replies may simply not have been "
                    "captured (one-direction capture); severity was lowered.")
        port = w["dst_port"].mode().iloc[0] if not w["dst_port"].mode().empty else None
        alerts.append(Alert(
            "R2", RULE_NAMES["R2"], sev, None if w["src_ip"].nunique() > 1 else w["src_ip"].iloc[0], dst,
            _port(port), start, end, peak,
            f"{peak} TCP SYN packets were sent to {dst} within {t['syn_flood_window_sec']} s and "
            f"{incomplete:.0%} of them received no reply (no SYN-ACK or RST) (thresholds: {t['syn_flood_syn_count']} SYNs, "
            f"{t['syn_flood_incomplete_ratio']:.0%} unanswered).{note}",
            REC_SYN_FLOOD, "Denial of Service",
            {"distinct sources": w["src_ip"].nunique(), "distinct target ports": w["dst_port"].nunique(),
             "unanswered ratio": f"{incomplete:.0%}"}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 3 - DNS query anomaly
# ---------------------------------------------------------------------------
REC_DNS = ("Identify the process generating the queries on the host (e.g. Windows Event Viewer / Sysmon, "
           "'ipconfig /displaydns'). Compare with the host's normal behaviour. Malware, misconfigured software "
           "and some security tools can all generate bursts of DNS lookups.")


def rule_dns_anomaly(ctx: RuleContext) -> list[Alert]:
    """Per host: total DNS queries, distinct domains, or a burst of queries in a time window above thresholds."""
    t = ctx.thresholds
    df = ctx.packets
    q = df[df["dns_qname"].notna() & (df["dns_is_response"] == False)].sort_values("timestamp")  # noqa: E712
    alerts = []
    for src, g in q.groupby("src_ip"):
        total, unique = len(g), g["dns_qname"].nunique()
        peak, ws, we = _window_peak(g["timestamp"].tolist(), [0] * total, t["dns_window_sec"], False)
        reasons, ratios = [], []
        if total >= t["dns_queries_per_host"]:
            reasons.append(f"{total} DNS queries in the capture (threshold {t['dns_queries_per_host']})")
            ratios.append(total / t["dns_queries_per_host"])
        if unique >= t["dns_unique_domains_per_host"]:
            reasons.append(f"{unique} distinct domain names (threshold {t['dns_unique_domains_per_host']})")
            ratios.append(unique / t["dns_unique_domains_per_host"])
        if peak >= t["dns_queries_per_window"]:
            reasons.append(f"{peak} queries within {t['dns_window_sec']} s (threshold {t['dns_queries_per_window']})")
            ratios.append(peak / t["dns_queries_per_window"])
        if not reasons:
            continue
        sev = scale_severity(ctx.base_severity("R3"), max(ratios), 1)
        top = g["dns_qname"].value_counts().head(3)
        alerts.append(Alert(
            "R3", RULE_NAMES["R3"], sev, src, g["dst_ip"].mode().iloc[0], 53, g["timestamp"].min(),
            g["timestamp"].max(), total,
            f"Host {src} shows unusual DNS activity: " + "; ".join(reasons) + ".",
            REC_DNS, "DNS", {"top domains": ", ".join(f"{d} ({n})" for d, n in top.items()),
                             "peak window": f"{ts_to_str(ws)} → {ts_to_str(we)}"}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 4 - Repeated connection attempts
# ---------------------------------------------------------------------------
REC_REPEAT = ("Check whether the destination service is down or blocked by a firewall (common, harmless cause). "
              "If connections keep failing to a remote-access or login service, review authentication logs on the "
              "server for brute-force attempts. Identify the process on the client that keeps retrying.")


def rule_repeated_connections(ctx: RuleContext) -> list[Alert]:
    """>= N SYN attempts from one source to the same destination IP:port where most connections FAILED
    (failure ratio >= threshold). Successful repeats only alert at 5x the threshold (e.g. aggressive polling)."""
    t = ctx.thresholds
    conns = ctx.connections
    if conns.empty:
        return []
    fails = {"No reply to SYN", "Rejected (RST)", "Handshake incomplete"}
    alerts = []
    attempts = conns[conns["syn"] > 0]
    for (cli, srv, port), g in attempts.groupby(["client_ip", "server_ip", "server_port"]):
        n_attempts = int(g["syn"].sum())
        if n_attempts < t["repeated_conn_attempts"]:
            continue
        failed = int(g["state"].isin(fails).sum())
        ratio = failed / len(g)
        mostly_failing = ratio >= t["repeated_conn_failure_ratio"]
        if not mostly_failing and n_attempts < 5 * t["repeated_conn_attempts"]:
            continue          # many successful connections to one service is normal (browsers, APIs)
        sev = scale_severity(ctx.base_severity("R4"), n_attempts, t["repeated_conn_attempts"])
        if mostly_failing and sev == "Low":
            sev = "Medium"
        alerts.append(Alert(
            "R4", RULE_NAMES["R4"], sev, cli, srv, _port(port), g["start"].min(), g["end"].max(), n_attempts,
            f"{cli} made {n_attempts} connection attempts (SYN packets, incl. retries) to {srv}:{_port(port)} across "
            f"{len(g)} connections; {failed} of them ({ratio:.0%}) did not complete "
            f"(thresholds: {t['repeated_conn_attempts']} attempts, {t['repeated_conn_failure_ratio']:.0%} failing).",
            REC_REPEAT, "Connection behaviour",
            {"connections": len(g), "failed connections": failed,
             "states": ", ".join(f"{k}: {v}" for k, v in g["state"].value_counts().items())}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 5 - Unusual traffic volume
# ---------------------------------------------------------------------------
REC_VOLUME = ("Identify the application responsible for the volume (OS updates, cloud backup, video streaming "
              "and game downloads are common). If unexpected, check the destination, the timing and whether data "
              "was mainly sent (upload) or received (download).")


def rule_traffic_volume(ctx: RuleContext) -> list[Alert]:
    """(a) a host whose total bytes exceed N x the median host AND a minimum byte count;
    (b) one-second spikes with packets > N x the median packets-per-second."""
    t = ctx.thresholds
    df = ctx.packets[ctx.packets["src_ip"].notna()]
    alerts = []
    if df.empty:
        return alerts
    sent = df.groupby("src_ip")["length"].sum()
    recv = df.groupby("dst_ip")["length"].sum()
    total = sent.add(recv, fill_value=0)
    if len(total) >= 3:
        baseline = float(total.median())
        limit = max(baseline * t["volume_baseline_multiplier"], t["volume_min_bytes"])
        for ip, b in total[total >= limit].sort_values(ascending=False).items():
            s, r = int(sent.get(ip, 0)), int(recv.get(ip, 0))
            alerts.append(Alert(
                "R5", RULE_NAMES["R5"], scale_severity(ctx.base_severity("R5"), b, limit), ip, None, None,
                df["timestamp"].min(), df["timestamp"].max(), int((df["src_ip"] == ip).sum() + (df["dst_ip"] == ip).sum()),
                f"{ip} transferred {human_bytes(b)} - more than {t['volume_baseline_multiplier']}x the median host "
                f"({human_bytes(baseline)}) and above the minimum of {human_bytes(t['volume_min_bytes'])}.",
                REC_VOLUME, "Traffic volume",
                {"sent": human_bytes(s), "received": human_bytes(r), "category": classify_ip(ip)}))
    # Per-second spikes
    per_sec = ctx.packets.groupby(ctx.packets["timestamp"].astype(int)).size()
    if len(per_sec) >= 10:
        med = max(float(per_sec.median()), 1.0)
        limit = max(med * t["volume_spike_multiplier"], t["volume_spike_min_packets"])
        spikes = per_sec[per_sec >= limit]
        if not spikes.empty:
            alerts.append(Alert(
                "R5", RULE_NAMES["R5"], scale_severity(ctx.base_severity("R5"), spikes.max(), limit), None, None, None,
                float(spikes.index.min()), float(spikes.index.max()) + 1, int(spikes.sum()),
                f"{len(spikes)} one-second interval(s) carried up to {int(spikes.max())} packets/s, compared with a "
                f"median of {med:.0f} packets/s (threshold {limit:.0f}).",
                REC_VOLUME, "Traffic volume", {"peak packets/s": int(spikes.max()), "median packets/s": round(med, 1)}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 6 - Unusual destination ports
# ---------------------------------------------------------------------------
REC_PORT = ("Confirm whether the service on this port is expected on the destination host. Clear-text protocols "
            "(Telnet, FTP) expose credentials; remote-access ports (RDP, VNC, SMB) should not normally be reachable "
            "from outside. Disable or firewall the service if it is not needed.")


def rule_unusual_ports(ctx: RuleContext) -> list[Alert]:
    """Connections (TCP SYN, or any UDP/TCP packet when no SYN was captured) to ports on the watch-list."""
    watch = {int(k): v for k, v in ctx.settings.get("suspicious_ports", {}).items()}
    if not watch:
        return []
    df = ctx.packets
    syn = _syn_only(df)
    tcp_hits = syn[syn["dst_port"].isin(watch)]
    # TCP flows whose SYN was not captured
    tcp_other = df[(df["transport"] == "TCP") & df["dst_port"].isin(watch) & ~df["flag_syn"]]
    seen = set(zip(tcp_hits["src_ip"], tcp_hits["dst_ip"], tcp_hits["dst_port"]))
    tcp_other = tcp_other[[k not in seen for k in zip(tcp_other["src_ip"], tcp_other["dst_ip"], tcp_other["dst_port"])]]
    udp_hits = df[(df["transport"] == "UDP") & df["dst_port"].isin(watch)]
    hits = pd.concat([tcp_hits, tcp_other, udp_hits])
    alerts = []
    for (src, dst, port), g in hits.groupby(["src_ip", "dst_ip", "dst_port"]):
        port = int(port)
        sev = ctx.base_severity("R6")
        if is_external(dst) or is_external(src):
            sev = SEVERITY_ORDER[min(SEVERITY_ORDER.index(sev) + 1, 3)]   # crosses the network boundary
        alerts.append(Alert(
            "R6", RULE_NAMES["R6"], sev, src, dst, port, g["timestamp"].min(), g["timestamp"].max(), len(g),
            f"Traffic from {src} to {dst} on port {port} ({watch[port]}). This port is on the configurable "
            f"'ports worth investigating' list; the traffic is not necessarily malicious.",
            REC_PORT, "Policy", {"transport": ", ".join(sorted(g["transport"].dropna().unique())),
                                 "source category": classify_ip(src), "destination category": classify_ip(dst)}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 7 - ICMP traffic anomaly
# ---------------------------------------------------------------------------
REC_ICMP = ("Check whether a monitoring or troubleshooting tool (ping, traceroute) was running. Many echo requests "
            "to many different hosts suggest a ping sweep (host discovery). Large numbers of 'Destination "
            "Unreachable' messages point to failing connections or scanning.")


def rule_icmp(ctx: RuleContext) -> list[Alert]:
    """>= N ICMP packets (echo replies excluded) from one source inside a time window. Notes ping sweeps."""
    t = ctx.thresholds
    icmp = ctx.packets[ctx.packets["protocol"] == "ICMP"].sort_values("timestamp")
    # Echo replies are answers to someone else's pings - the host sending them is not the one to look at.
    icmp = icmp[~icmp["icmp_desc"].isin(["Echo Reply"])]
    alerts = []
    for src, g in icmp.groupby("src_ip"):
        if len(g) < t["icmp_packets_per_host"]:
            continue
        peak, start, end = _window_peak(g["timestamp"].tolist(), [0] * len(g), t["icmp_window_sec"], False)
        if peak < t["icmp_packets_per_host"]:
            continue
        targets = g["dst_ip"].nunique()
        types = g["icmp_desc"].value_counts()
        sweep = targets >= 10 and types.index[0] == "Echo Request"
        reason = (f"{src} sent {peak} ICMP packets within {t['icmp_window_sec']} s "
                  f"(threshold {t['icmp_packets_per_host']}) to {targets} destination(s).")
        if sweep:
            reason += " Echo requests to many different hosts resemble a ping sweep (host discovery)."
        alerts.append(Alert(
            "R7", RULE_NAMES["R7"], scale_severity(ctx.base_severity("R7"), peak, t["icmp_packets_per_host"]),
            src, g["dst_ip"].iloc[0] if targets == 1 else None, None, start, end, len(g), reason, REC_ICMP,
            "Reconnaissance" if sweep else "ICMP",
            {"ICMP types": ", ".join(f"{k}: {v}" for k, v in types.head(4).items()), "destinations": targets}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 8 - TCP retransmissions
# ---------------------------------------------------------------------------
REC_RETRANS = ("High retransmission rates usually indicate network quality problems (Wi-Fi interference, "
               "congestion, a faulty cable) or an overloaded server - rarely an attack. Check interface error "
               "counters and latency. Remember that packets dropped by the capture itself can look like "
               "retransmissions.")


def rule_retransmissions(ctx: RuleContext) -> list[Alert]:
    """Retransmission rate >= threshold for a conversation with at least N TCP packets (and overall)."""
    t = ctx.thresholds
    tcp = ctx.packets[ctx.packets["transport"] == "TCP"]
    if len(tcp) < t["retransmission_min_packets"] or not tcp["is_retransmission"].any():
        return []
    alerts = []
    a = tcp["src_ip"].where(tcp["src_ip"] < tcp["dst_ip"], tcp["dst_ip"])
    b = tcp["dst_ip"].where(tcp["src_ip"] < tcp["dst_ip"], tcp["src_ip"])
    grouped = tcp.assign(ip_a=a, ip_b=b).groupby(["ip_a", "ip_b"])
    stats = grouped.agg(packets=("no", "size"), retrans=("is_retransmission", "sum"),
                        start=("timestamp", "min"), end=("timestamp", "max")).reset_index()
    stats["rate"] = stats["retrans"] / stats["packets"]
    hits = stats[(stats["packets"] >= t["retransmission_min_packets"]) & (stats["rate"] >= t["retransmission_rate"])]
    for row in hits.sort_values("rate", ascending=False).itertuples():
        alerts.append(Alert(
            "R8", RULE_NAMES["R8"], scale_severity(ctx.base_severity("R8"), row.rate, t["retransmission_rate"]),
            row.ip_a, row.ip_b, None, row.start, row.end, int(row.retrans),
            f"{int(row.retrans)} of {row.packets} TCP packets ({row.rate:.1%}) between {row.ip_a} and {row.ip_b} "
            f"look like retransmissions (threshold {t['retransmission_rate']:.0%}).",
            REC_RETRANS, "Network health", {"conversation packets": row.packets}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 9 - Possible DNS tunnelling indicators
# ---------------------------------------------------------------------------
REC_TUNNEL = ("Look up who owns the base domain (WHOIS, reputation sites). Check which process on the host issues "
              "the queries. DNS tunnelling encodes data in long, random-looking sub-domains, but CDNs, anti-virus "
              "and telemetry services also use such names - confirm before acting.")


def rule_dns_tunneling(ctx: RuleContext) -> list[Alert]:
    """Per base domain: many distinct sub-domains AND (most names long/random-looking OR many TXT queries)."""
    t = ctx.thresholds
    q = ctx.packets[ctx.packets["dns_qname"].notna() & (ctx.packets["dns_is_response"] == False)]  # noqa: E712
    if q.empty:
        return []
    q = q.assign(base=q["dns_qname"].map(registered_domain))
    alerts = []
    for base, g in q.groupby("base"):
        names = g["dns_qname"].unique()
        if len(names) < t["dns_tunnel_subdomains_per_domain"]:
            continue
        flagged = [n for n in names if domain_heuristics(n, t)]
        flagged_ratio = len(flagged) / len(names)
        txt_ratio = float((g["dns_qtype"] == "TXT").mean())
        avg_len = sum(map(len, names)) / len(names)
        if flagged_ratio < 0.5 and txt_ratio < 0.5:
            continue
        sev = scale_severity(ctx.base_severity("R9"), len(names), t["dns_tunnel_subdomains_per_domain"])
        alerts.append(Alert(
            "R9", RULE_NAMES["R9"], sev, g["src_ip"].mode().iloc[0], g["dst_ip"].mode().iloc[0], 53,
            g["timestamp"].min(), g["timestamp"].max(), len(g),
            f"{len(names)} distinct sub-domains of {base} were queried (threshold "
            f"{t['dns_tunnel_subdomains_per_domain']}); {flagged_ratio:.0%} of the names are long or random-looking "
            f"and {txt_ratio:.0%} of the queries are TXT records. These are common DNS-tunnelling indicators.",
            REC_TUNNEL, "DNS", {"average name length": round(avg_len, 1), "example": flagged[0] if flagged else names[0],
                                "querying hosts": g["src_ip"].nunique()}))
    return alerts


# ---------------------------------------------------------------------------
# Rule 10 - Unusual external communication
# ---------------------------------------------------------------------------
REC_EXTERNAL = ("Confirm which application on the internal host opened the connection and whether the "
                "destination service is expected. Large outbound transfers to unknown destinations deserve a "
                "check for data exfiltration; unusual ports may simply be games, VPNs or video calls.")


def rule_external_communication(ctx: RuleContext) -> list[Alert]:
    """User-configurable rules:
      (a) any traffic to/from a *watched* external network,
      (b) internal hosts opening connections to external IPs on ports not in the allowed list,
      (c) internal hosts sending more than N bytes to a single public destination.
    Destinations in *allowed* networks are always ignored."""
    t = ctx.thresholds
    rules = ctx.settings.get("external_rules", {})
    allowed_nets = [ipaddress.ip_network(n, strict=False) for n in rules.get("allowed_external_networks", [])]
    watched_nets = [ipaddress.ip_network(n, strict=False) for n in rules.get("watched_external_networks", [])]
    allowed_ports = set(int(p) for p in rules.get("allowed_external_ports", []))
    df = ctx.packets[ctx.packets["src_ip"].notna()]
    if df.empty:
        return []

    def in_nets(ip, nets):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(a.version == n.version and a in n for n in nets)

    cat_src = df["src_ip"].map(classify_ip)
    cat_dst = df["dst_ip"].map(classify_ip)
    alerts: list[Alert] = []

    # (a) watched networks
    if watched_nets:
        watch_mask = df["src_ip"].map(lambda x: in_nets(x, watched_nets)) | df["dst_ip"].map(lambda x: in_nets(x, watched_nets))
        for (src, dst), g in df[watch_mask].groupby(["src_ip", "dst_ip"]):
            alerts.append(Alert(
                "R10", RULE_NAMES["R10"], "Medium", src, dst, _port(g["dst_port"].mode().iloc[0]) if g["dst_port"].notna().any() else None,
                g["timestamp"].min(), g["timestamp"].max(), len(g),
                f"Traffic between {src} and {dst}, which is inside a network on your 'watched external networks' list.",
                REC_EXTERNAL, "External communication", {"bytes": human_bytes(g["length"].sum())}))

    outbound = df[(cat_src == "Private") & cat_dst.isin(["Public", "Documentation"])]
    if allowed_nets:
        outbound = outbound[~outbound["dst_ip"].map(lambda x: in_nets(x, allowed_nets))]
    if watched_nets:
        outbound = outbound[~outbound["dst_ip"].map(lambda x: in_nets(x, watched_nets))]

    # (b) new outbound connections on non-allowed ports
    initiators = outbound[((outbound["transport"] == "TCP") & outbound["flag_syn"] & ~outbound["flag_ack"]) |
                          ((outbound["transport"] == "UDP") & (outbound["dst_port"] < 49152))]
    odd = initiators[~initiators["dst_port"].isin(allowed_ports)]
    for (src, dst, port), g in odd.groupby(["src_ip", "dst_ip", "dst_port"]):
        alerts.append(Alert(
            "R10", RULE_NAMES["R10"], ctx.base_severity("R10"), src, dst, _port(port), g["timestamp"].min(),
            g["timestamp"].max(), len(g),
            f"Internal host {src} initiated {g['transport'].iloc[0]} traffic to external address {dst} on port "
            f"{_port(port)}, which is not in the list of allowed external ports.",
            REC_EXTERNAL, "External communication", {"packets": len(g)}))

    # (c) large outbound transfers
    volume = outbound.groupby(["src_ip", "dst_ip"]).agg(bytes=("length", "sum"), packets=("no", "size"),
                                                        start=("timestamp", "min"), end=("timestamp", "max"))
    for (src, dst), row in volume[volume["bytes"] >= t["external_bytes_per_destination"]].iterrows():
        alerts.append(Alert(
            "R10", RULE_NAMES["R10"],
            scale_severity("Medium", row["bytes"], t["external_bytes_per_destination"]), src, dst, None,
            row["start"], row["end"], int(row["packets"]),
            f"Internal host {src} sent {human_bytes(row['bytes'])} to external address {dst} "
            f"(threshold {human_bytes(t['external_bytes_per_destination'])}).",
            REC_EXTERNAL, "External communication", {"packets": int(row["packets"])}))
    return alerts


ALL_RULES = {
    "R1": rule_port_scan,
    "R2": rule_syn_flood,
    "R3": rule_dns_anomaly,
    "R4": rule_repeated_connections,
    "R5": rule_traffic_volume,
    "R6": rule_unusual_ports,
    "R7": rule_icmp,
    "R8": rule_retransmissions,
    "R9": rule_dns_tunneling,
    "R10": rule_external_communication,
}


def describe_rules() -> list[dict]:
    """Rule descriptions for the dashboard / report (taken from the docstrings)."""
    return [{"rule_id": rid, "name": RULE_NAMES[rid], "logic": " ".join((fn.__doc__ or "").split())}
            for rid, fn in ALL_RULES.items()]


__all__ = ["Alert", "RuleContext", "ALL_RULES", "describe_rules", "scale_severity"]
