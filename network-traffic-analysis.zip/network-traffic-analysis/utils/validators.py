"""Input validation: capture files, IP addresses, ports, CIDR ranges, file names."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from pathlib import Path

from config import ALLOWED_EXTENSIONS, MAX_UPLOAD_MB

# Magic numbers at the start of capture files
PCAP_MAGICS = {
    b"\xd4\xc3\xb2\xa1": "pcap",   # little-endian, microseconds
    b"\xa1\xb2\xc3\xd4": "pcap",   # big-endian, microseconds
    b"\x4d\x3c\xb2\xa1": "pcap",   # little-endian, nanoseconds
    b"\xa1\xb2\x3c\x4d": "pcap",   # big-endian, nanoseconds
}
PCAPNG_MAGIC = b"\x0a\x0d\x0d\x0a"   # Section Header Block type


@dataclass
class FileCheck:
    ok: bool
    message: str
    file_format: str | None = None
    size_bytes: int = 0


def detect_format(header: bytes) -> str | None:
    """Return 'pcap', 'pcapng' or None from the first 4 bytes of a file."""
    if len(header) < 4:
        return None
    if header[:4] == PCAPNG_MAGIC:
        return "pcapng"
    return PCAP_MAGICS.get(header[:4])


def validate_capture_file(path: str | Path, max_mb: int = MAX_UPLOAD_MB) -> FileCheck:
    """
    Check that a file exists, has an allowed extension, is not too large and
    really is a PCAP/PCAPNG file (we look at the magic bytes, not just the name).
    """
    p = Path(path)
    if not p.exists() or not p.is_file():
        return FileCheck(False, f"File not found: {p.name}")
    if p.suffix.lower() not in ALLOWED_EXTENSIONS:
        return FileCheck(False, f"Unsupported extension '{p.suffix}'. Allowed: {', '.join(ALLOWED_EXTENSIONS)}")
    size = p.stat().st_size
    if size == 0:
        return FileCheck(False, "The file is empty (0 bytes).", None, 0)
    if size > max_mb * 1024 * 1024:
        return FileCheck(False, f"File is {size / 1048576:.1f} MB; the limit is {max_mb} MB.", None, size)
    with open(p, "rb") as fh:
        header = fh.read(4)
    fmt = detect_format(header)
    if fmt is None:
        return FileCheck(False, "This does not look like a PCAP or PCAPNG file (unknown file signature).", None, size)
    if size < 24 and fmt == "pcap":
        return FileCheck(False, "PCAP file is truncated (shorter than its 24-byte global header).", fmt, size)
    return FileCheck(True, f"Valid {fmt.upper()} file.", fmt, size)


def sanitize_filename(name: str) -> str:
    """Remove path components and unsafe characters from an uploaded file name."""
    name = Path(name or "upload.pcap").name
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
    return name[:120] or "upload.pcap"


def is_valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(str(value).strip())
        return True
    except ValueError:
        return False


def is_valid_port(value) -> bool:
    try:
        return 0 <= int(value) <= 65535
    except (TypeError, ValueError):
        return False


def parse_cidr_list(text: str) -> tuple[list[str], list[str]]:
    """Parse comma/newline separated CIDRs. Returns (valid, invalid)."""
    valid, invalid = [], []
    for item in re.split(r"[,\n]", text or ""):
        item = item.strip()
        if not item:
            continue
        try:
            valid.append(str(ipaddress.ip_network(item, strict=False)))
        except ValueError:
            invalid.append(item)
    return valid, invalid


def parse_port_list(text: str) -> tuple[list[int], list[str]]:
    """Parse comma separated ports. Returns (valid, invalid)."""
    valid, invalid = [], []
    for item in re.split(r"[,\s]+", text or ""):
        if not item:
            continue
        if is_valid_port(item):
            valid.append(int(item))
        else:
            invalid.append(item)
    return sorted(set(valid)), invalid
