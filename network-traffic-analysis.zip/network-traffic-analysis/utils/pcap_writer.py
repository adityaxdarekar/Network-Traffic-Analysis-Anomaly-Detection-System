"""
Build SYNTHETIC network packets and write them to PCAP / PCAPNG files.

Used for:
    * the demonstration captures in ``sample_data/``,
    * the unit tests (so tests never depend on real or malicious traffic).

All packets are generated locally - nothing is ever sent on a network.
Checksums are calculated properly, so Wireshark opens the files without
"bad checksum" warnings.
"""

from __future__ import annotations

import ipaddress
import os
import random
import struct
from pathlib import Path

# ---------------------------------------------------------------------------
# Checksums and basic layers
# ---------------------------------------------------------------------------


def checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    s = sum(struct.unpack(f"!{len(data) // 2}H", data))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return ~s & 0xFFFF


def mac_bytes(mac: str) -> bytes:
    return bytes(int(x, 16) for x in mac.split(":"))


def ethernet(src_mac: str, dst_mac: str, ethertype: int, payload: bytes) -> bytes:
    return mac_bytes(dst_mac) + mac_bytes(src_mac) + struct.pack("!H", ethertype) + payload


def _pseudo_header(src: str, dst: str, proto: int, length: int) -> bytes:
    s, d = ipaddress.ip_address(src), ipaddress.ip_address(dst)
    if s.version == 4:
        return s.packed + d.packed + struct.pack("!BBH", 0, proto, length)
    return s.packed + d.packed + struct.pack("!I3xB", length, proto)


def ipv4(src: str, dst: str, proto: int, payload: bytes, ttl: int = 64, ident: int | None = None) -> bytes:
    ident = random.randint(0, 65535) if ident is None else ident
    header = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(payload), ident, 0x4000, ttl, proto, 0,
                         ipaddress.IPv4Address(src).packed, ipaddress.IPv4Address(dst).packed)
    header = header[:10] + struct.pack("!H", checksum(header)) + header[12:]
    return header + payload


def ipv6(src: str, dst: str, next_header: int, payload: bytes, hop_limit: int = 64) -> bytes:
    return struct.pack("!IHBB", 6 << 28, len(payload), next_header, hop_limit) + \
        ipaddress.IPv6Address(src).packed + ipaddress.IPv6Address(dst).packed + payload


TCP_FLAGS = {"F": 0x01, "S": 0x02, "R": 0x04, "P": 0x08, "A": 0x10, "U": 0x20}


def tcp(src: str, dst: str, sport: int, dport: int, seq: int, ack: int, flags: str,
        payload: bytes = b"", window: int = 64240) -> bytes:
    fl = sum(TCP_FLAGS[c] for c in flags)
    header = struct.pack("!HHIIHHHH", sport, dport, seq % 2**32, ack % 2**32, (5 << 12) | fl, window, 0, 0)
    seg = header + payload
    csum = checksum(_pseudo_header(src, dst, 6, len(seg)) + seg)
    return seg[:16] + struct.pack("!H", csum) + seg[18:]


def udp(src: str, dst: str, sport: int, dport: int, payload: bytes) -> bytes:
    seg = struct.pack("!HHHH", sport, dport, 8 + len(payload), 0) + payload
    csum = checksum(_pseudo_header(src, dst, 17, len(seg)) + seg) or 0xFFFF
    return seg[:6] + struct.pack("!H", csum) + seg[8:]


def icmp_echo(request: bool, ident: int, seq: int, data: bytes = b"abcdefghijklmnopqrstuvwabcdefghi") -> bytes:
    msg = struct.pack("!BBHHH", 8 if request else 0, 0, 0, ident, seq) + data
    return msg[:2] + struct.pack("!H", checksum(msg)) + msg[4:]


def icmp_unreachable(code: int, original: bytes) -> bytes:
    msg = struct.pack("!BBHI", 3, code, 0, 0) + original[:28]
    return msg[:2] + struct.pack("!H", checksum(msg)) + msg[4:]


def arp(op: int, src_mac: str, src_ip: str, dst_mac: str, dst_ip: str) -> bytes:
    return struct.pack("!HHBBH", 1, 0x0800, 6, 4, op) + mac_bytes(src_mac) + \
        ipaddress.IPv4Address(src_ip).packed + mac_bytes(dst_mac) + ipaddress.IPv4Address(dst_ip).packed


# ---------------------------------------------------------------------------
# Application layer messages
# ---------------------------------------------------------------------------
QTYPES = {"A": 1, "NS": 2, "CNAME": 5, "MX": 15, "TXT": 16, "AAAA": 28}


def dns_name(name: str) -> bytes:
    out = b""
    for label in name.strip(".").split("."):
        out += bytes([len(label)]) + label.encode()
    return out + b"\x00"


def dns_query(txid: int, name: str, qtype: str = "A") -> bytes:
    return struct.pack("!HHHHHH", txid, 0x0100, 1, 0, 0, 0) + dns_name(name) + struct.pack("!HH", QTYPES[qtype], 1)


def dns_response(txid: int, name: str, qtype: str = "A", answers: list[tuple[str, str]] | None = None,
                 rcode: int = 0) -> bytes:
    answers = answers or []
    msg = struct.pack("!HHHHHH", txid, 0x8180 | rcode, 1, len(answers), 0, 0)
    msg += dns_name(name) + struct.pack("!HH", QTYPES[qtype], 1)
    for rtype, value in answers:
        if rtype == "A":
            rdata = ipaddress.IPv4Address(value).packed
        elif rtype == "AAAA":
            rdata = ipaddress.IPv6Address(value).packed
        elif rtype in ("CNAME", "NS"):
            rdata = dns_name(value)
        elif rtype == "MX":
            rdata = struct.pack("!H", 10) + dns_name(value)
        else:  # TXT
            txt = value.encode()[:255]
            rdata = bytes([len(txt)]) + txt
        msg += b"\xc0\x0c" + struct.pack("!HHIH", QTYPES[rtype], 1, 300, len(rdata)) + rdata
    return msg


def tls_client_hello(sni: str | None, versions=(0x0304, 0x0303)) -> bytes:
    exts = b""
    if sni:
        name = sni.encode()
        sni_list = struct.pack("!BH", 0, len(name)) + name
        exts += struct.pack("!HH", 0, len(sni_list) + 2) + struct.pack("!H", len(sni_list)) + sni_list
    sv = b"".join(struct.pack("!H", v) for v in versions)
    exts += struct.pack("!HHB", 43, len(sv) + 1, len(sv)) + sv
    ciphers = struct.pack("!HHHH", 0x1301, 0x1302, 0xC02F, 0xC030)
    body = struct.pack("!H", 0x0303) + os.urandom(32) + b"\x20" + os.urandom(32) + \
        struct.pack("!H", len(ciphers)) + ciphers + b"\x01\x00" + struct.pack("!H", len(exts)) + exts
    hs = b"\x01" + struct.pack("!I", len(body))[1:] + body
    return b"\x16\x03\x01" + struct.pack("!H", len(hs)) + hs


def tls_server_hello(version: int = 0x0304) -> bytes:
    exts = struct.pack("!HHH", 43, 2, version) if version == 0x0304 else b""
    body = struct.pack("!H", 0x0303 if version >= 0x0303 else version) + os.urandom(32) + b"\x20" + \
        os.urandom(32) + struct.pack("!HB", 0x1301 if version == 0x0304 else 0xC02F, 0)
    body += struct.pack("!H", len(exts)) + exts
    hs = b"\x02" + struct.pack("!I", len(body))[1:] + body
    return b"\x16\x03\x03" + struct.pack("!H", len(hs)) + hs


def tls_app_data(size: int) -> bytes:
    data = os.urandom(size)     # random bytes stand in for encrypted content
    return b"\x17\x03\x03" + struct.pack("!H", len(data)) + data


def http_request(method: str, host: str, path: str, user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)") -> bytes:
    return (f"{method} {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {user_agent}\r\n"
            f"Accept: */*\r\nConnection: keep-alive\r\n\r\n").encode()


def http_response(code: int, reason: str = "OK", body: bytes = b"<html><body>demo</body></html>") -> bytes:
    return (f"HTTP/1.1 {code} {reason}\r\nContent-Type: text/html\r\nContent-Length: {len(body)}\r\n"
            f"Server: demo\r\n\r\n").encode() + body


# ---------------------------------------------------------------------------
# File writers
# ---------------------------------------------------------------------------
class PcapWriter:
    """Classic libpcap file (microsecond resolution, Ethernet link type)."""

    def __init__(self, path: str | Path, linktype: int = 1):
        self.fh = open(path, "wb")
        self.fh.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 262144, linktype))

    def write(self, ts: float, frame: bytes) -> None:
        sec = int(ts)
        usec = int(round((ts - sec) * 1e6))
        if usec >= 1_000_000:
            sec, usec = sec + 1, usec - 1_000_000
        self.fh.write(struct.pack("<IIII", sec, usec, len(frame), len(frame)) + frame)

    def close(self) -> None:
        self.fh.close()


class PcapngWriter:
    """Minimal PCAPNG file: one section, one Ethernet interface, Enhanced Packet Blocks."""

    def __init__(self, path: str | Path, linktype: int = 1):
        self.fh = open(path, "wb")
        shb_body = struct.pack("<IHHq", 0x1A2B3C4D, 1, 0, -1)
        self.fh.write(struct.pack("<II", 0x0A0D0D0A, 12 + len(shb_body)) + shb_body + struct.pack("<I", 12 + len(shb_body)))
        idb_body = struct.pack("<HHI", linktype, 0, 262144)
        self.fh.write(struct.pack("<II", 1, 12 + len(idb_body)) + idb_body + struct.pack("<I", 12 + len(idb_body)))

    def write(self, ts: float, frame: bytes) -> None:
        t = int(round(ts * 1e6))
        pad = (4 - len(frame) % 4) % 4
        body = struct.pack("<IIIII", 0, t >> 32, t & 0xFFFFFFFF, len(frame), len(frame)) + frame + b"\x00" * pad
        total = 12 + len(body)
        self.fh.write(struct.pack("<II", 6, total) + body + struct.pack("<I", total))

    def close(self) -> None:
        self.fh.close()


def open_writer(path: str | Path):
    return PcapngWriter(path) if str(path).lower().endswith(".pcapng") else PcapWriter(path)


# ---------------------------------------------------------------------------
# High-level traffic builder
# ---------------------------------------------------------------------------
class TrafficBuilder:
    """
    Collects synthetic frames with timestamps, then writes them sorted by time.

    Each host gets a stable fake MAC address. All helpers take an explicit
    start time so scenarios can be interleaved.
    """

    def __init__(self, seed: int = 7):
        random.seed(seed)
        self.frames: list[tuple[float, bytes]] = []
        self._macs: dict[str, str] = {}

    def mac(self, ip: str) -> str:
        if ip not in self._macs:
            n = len(self._macs) + 1
            self._macs[ip] = f"02:00:00:{(n >> 16) & 255:02x}:{(n >> 8) & 255:02x}:{n & 255:02x}"
        return self._macs[ip]

    # -- raw adders ----------------------------------------------------------
    def add_ip(self, ts: float, src: str, dst: str, proto: int, payload: bytes, ttl: int = 64) -> None:
        if ":" in src:
            frame = ethernet(self.mac(src), self.mac(dst), 0x86DD, ipv6(src, dst, proto, payload, ttl))
        else:
            frame = ethernet(self.mac(src), self.mac(dst), 0x0800, ipv4(src, dst, proto, payload, ttl))
        self.frames.append((ts, frame))

    def add_tcp(self, ts, src, dst, sport, dport, seq, ack, flags, payload=b"") -> None:
        self.add_ip(ts, src, dst, 6, tcp(src, dst, sport, dport, seq, ack, flags, payload))

    def add_udp(self, ts, src, dst, sport, dport, payload) -> None:
        self.add_ip(ts, src, dst, 17, udp(src, dst, sport, dport, payload))

    def add_arp(self, ts, src_ip, dst_ip, reply=False) -> None:
        if reply:
            frame = ethernet(self.mac(src_ip), self.mac(dst_ip), 0x0806,
                             arp(2, self.mac(src_ip), src_ip, self.mac(dst_ip), dst_ip))
        else:
            frame = ethernet(self.mac(src_ip), "ff:ff:ff:ff:ff:ff", 0x0806,
                             arp(1, self.mac(src_ip), src_ip, "00:00:00:00:00:00", dst_ip))
        self.frames.append((ts, frame))

    # -- scenarios -----------------------------------------------------------
    def dns_lookup(self, ts, client, server, name, qtype="A", answers=None, rcode=0, rtt=0.02) -> None:
        txid = random.randint(0, 65535)
        sport = random.randint(49152, 65535)
        self.add_udp(ts, client, server, sport, 53, dns_query(txid, name, qtype))
        if answers is not None or rcode:
            self.add_udp(ts + rtt, server, client, 53, sport, dns_response(txid, name, qtype, answers or [], rcode))

    def tcp_session(self, ts, client, server, dport, exchanges: list[tuple[str, bytes]], rtt=0.03,
                    sport=None, close=True, retransmit_every: int = 0) -> float:
        """
        Full TCP conversation: 3-way handshake, data exchanges, FIN close.
        ``exchanges`` is a list of ("c"|"s", payload) - who sends what.
        Returns the time of the last packet.
        """
        sport = sport or random.randint(49152, 65535)
        cseq, sseq = random.randint(0, 2**31), random.randint(0, 2**31)
        t = ts
        self.add_tcp(t, client, server, sport, dport, cseq, 0, "S")
        t += rtt / 2
        self.add_tcp(t, server, client, dport, sport, sseq, cseq + 1, "SA")
        t += rtt / 2
        cseq += 1
        sseq += 1
        self.add_tcp(t, client, server, sport, dport, cseq, sseq, "A")
        n = 0
        for who, payload in exchanges:
            t += 0.005
            n += 1
            if who == "c":
                self.add_tcp(t, client, server, sport, dport, cseq, sseq, "PA", payload)
                if retransmit_every and n % retransmit_every == 0:
                    t += 0.2
                    self.add_tcp(t, client, server, sport, dport, cseq, sseq, "PA", payload)
                cseq += len(payload)
                t += rtt / 2
                self.add_tcp(t, server, client, dport, sport, sseq, cseq, "A")
            else:
                self.add_tcp(t, server, client, dport, sport, sseq, cseq, "PA", payload)
                if retransmit_every and n % retransmit_every == 0:
                    t += 0.2
                    self.add_tcp(t, server, client, dport, sport, sseq, cseq, "PA", payload)
                sseq += len(payload)
                t += rtt / 2
                self.add_tcp(t, client, server, sport, dport, cseq, sseq, "A")
        if close:
            t += 0.01
            self.add_tcp(t, client, server, sport, dport, cseq, sseq, "FA")
            t += rtt / 2
            self.add_tcp(t, server, client, dport, sport, sseq, cseq + 1, "FA")
            t += rtt / 2
            self.add_tcp(t, client, server, sport, dport, cseq + 1, sseq + 1, "A")
        return t

    def https_visit(self, ts, client, server, sni, version=0x0304, data_chunks=4, chunk=1200, **kw) -> float:
        exchanges = [("c", tls_client_hello(sni, (version,) if version != 0x0304 else (0x0304, 0x0303))),
                     ("s", tls_server_hello(version))]
        for i in range(data_chunks):
            exchanges.append(("c" if i % 3 == 0 else "s", tls_app_data(chunk if i % 3 else 300)))
        return self.tcp_session(ts, client, server, 443, exchanges, **kw)

    def http_visit(self, ts, client, server, host, path="/", method="GET", status=200, reason="OK", **kw) -> float:
        return self.tcp_session(ts, client, server, 80, [("c", http_request(method, host, path)),
                                                         ("s", http_response(status, reason))], **kw)

    def ping(self, ts, src, dst, count=4, interval=1.0, reply=True) -> None:
        ident = random.randint(0, 65535)
        for i in range(count):
            t = ts + i * interval
            self.add_ip(t, src, dst, 1, icmp_echo(True, ident, i + 1))
            if reply:
                self.add_ip(t + 0.01, dst, src, 1, icmp_echo(False, ident, i + 1))

    # -- output ----------------------------------------------------------------
    def write(self, path: str | Path) -> int:
        self.frames.sort(key=lambda x: x[0])
        writer = open_writer(path)
        try:
            for ts, frame in self.frames:
                writer.write(ts, frame)
        finally:
            writer.close()
        return len(self.frames)
