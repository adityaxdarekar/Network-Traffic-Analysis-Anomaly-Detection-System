"""Small, dependency-free helper functions used across the project."""

from __future__ import annotations

import hashlib
import math
from collections import Counter
from datetime import datetime, timezone


def human_bytes(num: float | int | None) -> str:
    """Format a byte count as a human-readable string (e.g. 1.5 MB)."""
    if num is None or (isinstance(num, float) and math.isnan(num)):
        return "0 B"
    num = float(num)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num) < 1024 or unit == "TB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.2f} {unit}"
        num /= 1024
    return f"{num:.2f} TB"


def ts_to_str(ts: float | None) -> str:
    """Convert a UNIX timestamp to an ISO-like UTC string."""
    if ts is None or (isinstance(ts, float) and math.isnan(ts)):
        return "-"
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] + " UTC"
    except (OverflowError, OSError, ValueError):
        return "-"


def now_str() -> str:
    """Current local time as a readable string."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def shannon_entropy(text: str) -> float:
    """Shannon entropy (bits per character). Random-looking strings score higher."""
    if not text:
        return 0.0
    counts = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def registered_domain(name: str) -> str:
    """
    Very small approximation of the "registered domain" (example.co.uk / example.com).

    A full public-suffix list is not bundled to keep the project lightweight,
    so a few common two-level suffixes are handled explicitly.
    """
    if not name:
        return ""
    parts = name.strip(".").lower().split(".")
    if len(parts) <= 2:
        return ".".join(parts)
    two_level = {"co.uk", "ac.uk", "gov.uk", "org.uk", "co.in", "ac.in", "com.au",
                 "co.jp", "com.br", "co.nz", "com.cn", "org.in", "net.in", "edu.in"}
    if ".".join(parts[-2:]) in two_level:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def file_sha256(path) -> str:
    """SHA-256 of a file, read in chunks so large captures do not fill RAM."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def mask_ip(ip: str | None) -> str:
    """Mask the host part of an IP address for privacy-friendly screenshots."""
    if not ip or not isinstance(ip, str):
        return ip or ""
    if "." in ip and ip.count(".") == 3:
        a, b, _c, _d = ip.split(".")
        return f"{a}.{b}.x.x"
    if ":" in ip:
        parts = ip.split(":")
        return ":".join(parts[:2]) + ":xxxx::"
    return ip


def safe_int(value, default=None):
    """int() that never raises."""
    try:
        if value is None:
            return default
        if isinstance(value, float) and math.isnan(value):
            return default
        return int(value)
    except (TypeError, ValueError):
        return default
