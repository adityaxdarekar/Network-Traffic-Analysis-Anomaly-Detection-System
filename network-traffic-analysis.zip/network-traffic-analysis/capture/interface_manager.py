"""
Discover capture tools (TShark / dumpcap / Scapy / Npcap) and network interfaces.

Nothing here needs administrator rights: listing interfaces with ``tshark -D``
works for normal users once Npcap is installed. Only the capture itself may
need extra permissions.
"""

from __future__ import annotations

import ctypes
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

IS_WINDOWS = platform.system() == "Windows"

WINDOWS_TSHARK_PATHS = [
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Wireshark" / "tshark.exe",
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Wireshark" / "tshark.exe",
]


def find_tshark() -> str | None:
    """Return the path of tshark, checking PATH and the default Windows install folder."""
    env = os.environ.get("TSHARK_PATH")
    if env and Path(env).exists():
        return env
    found = shutil.which("tshark")
    if found:
        return found
    if IS_WINDOWS:
        for candidate in WINDOWS_TSHARK_PATHS:
            if candidate.exists():
                return str(candidate)
    return None


def tshark_version(tshark: str | None = None) -> str | None:
    tshark = tshark or find_tshark()
    if not tshark:
        return None
    try:
        out = subprocess.run([tshark, "--version"], capture_output=True, text=True, timeout=15,
                             creationflags=_no_window()).stdout
        return out.splitlines()[0].strip() if out else None
    except (OSError, subprocess.SubprocessError):
        return None


def scapy_available() -> bool:
    try:
        import scapy  # noqa: F401
        return True
    except ImportError:
        return False


def npcap_installed() -> bool | None:
    """True/False on Windows, None on other systems (libpcap is used there)."""
    if not IS_WINDOWS:
        return None
    system_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
    return (system_root / "System32" / "Npcap").exists()


def is_admin() -> bool:
    try:
        if IS_WINDOWS:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())   # type: ignore[attr-defined]
        return os.geteuid() == 0
    except (AttributeError, OSError):
        return False


def _no_window() -> int:
    """Stop a console window from flashing up on Windows when running tshark."""
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if IS_WINDOWS else 0


def parse_tshark_interfaces(output: str) -> list[dict]:
    r"""
    Parse ``tshark -D`` output, e.g.::

        1. \Device\NPF_{2C4E...} (Wi-Fi)
        2. \Device\NPF_Loopback (Adapter for loopback traffic capture)
        3. eth0
    """
    interfaces = []
    for line in output.splitlines():
        m = re.match(r"^\s*(\d+)\.\s+(\S+)(?:\s+\((.*)\))?\s*$", line)
        if m:
            index, name, desc = m.groups()
            interfaces.append({"id": index, "name": name, "description": desc or name, "source": "tshark"})
    return interfaces


def list_interfaces() -> tuple[list[dict], str | None]:
    """
    Return (interfaces, error_message). Tries TShark first, then Scapy.
    Each interface is a dict with ``id`` (what to pass to the capture),
    ``name``, ``description`` and ``source``.
    """
    errors = []
    tshark = find_tshark()
    if tshark:
        try:
            proc = subprocess.run([tshark, "-D"], capture_output=True, text=True, timeout=30,
                                  creationflags=_no_window())
            interfaces = parse_tshark_interfaces(proc.stdout)
            if interfaces:
                return interfaces, None
            errors.append(f"tshark -D returned no interfaces: {proc.stderr.strip()[:300]}")
        except (OSError, subprocess.SubprocessError) as exc:
            errors.append(f"Could not run tshark: {exc}")
    else:
        errors.append("TShark was not found (install Wireshark and tick 'TShark' during setup).")

    if scapy_available():
        try:
            from scapy.all import conf   # noqa: WPS433 - optional dependency
            interfaces = []
            for iface in conf.ifaces.data.values():
                name = getattr(iface, "network_name", None) or getattr(iface, "name", str(iface))
                desc = getattr(iface, "description", "") or getattr(iface, "name", name)
                interfaces.append({"id": name, "name": name, "description": desc, "source": "scapy"})
            if interfaces:
                return interfaces, None
            errors.append("Scapy found no interfaces (is Npcap installed?).")
        except Exception as exc:  # noqa: BLE001 - Scapy raises many platform-specific errors
            errors.append(f"Scapy interface discovery failed: {exc}")
    else:
        errors.append("Scapy is not installed (pip install scapy).")
    return [], " ".join(errors)


def capture_capabilities() -> dict:
    """Everything the Live Capture page needs to explain what will or will not work."""
    tshark = find_tshark()
    return {
        "platform": f"{platform.system()} {platform.release()}",
        "tshark_path": tshark,
        "tshark_version": tshark_version(tshark) if tshark else None,
        "scapy_available": scapy_available(),
        "npcap_installed": npcap_installed(),
        "is_admin": is_admin(),
        "can_capture": bool(tshark) or scapy_available(),
    }
