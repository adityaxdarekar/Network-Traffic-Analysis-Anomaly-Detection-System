"""
Live packet capture using TShark (preferred) or Scapy (fallback).

LEGAL / ETHICAL NOTE: only capture on networks and devices that you own or
have explicit written permission to monitor.

Usage::

    session = CaptureSession()
    session.start(interface="Wi-Fi", duration=30, packet_limit=1000)
    ...
    status = session.status()      # running, elapsed time, packets captured
    session.stop()
    print(session.output_file)

The capture runs in the background (a TShark child process, or a Scapy
AsyncSniffer thread), so the dashboard stays responsive.
"""

from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

from analyzer.pcap_reader import CaptureReader
from capture.interface_manager import IS_WINDOWS, find_tshark, scapy_available
from config import CAPTURE_DIR, DEFAULT_CAPTURE

PERMISSION_HINTS = ("permission", "privileges", "operation not permitted", "access is denied",
                    "you don't have permission")
INTERFACE_HINTS = ("no such device", "doesn't exist", "is not a valid interface", "no interfaces",
                   "the capture session could not be initiated", "interface")


class CaptureError(Exception):
    """Raised with a beginner-friendly message when a capture cannot start."""


def friendly_error(stderr: str) -> str:
    text = (stderr or "").lower()
    if any(h in text for h in PERMISSION_HINTS):
        return ("Permission denied while opening the interface. On Windows make sure Npcap is installed "
                "(and, if you chose 'restrict to administrators' during setup, run the terminal as "
                "Administrator). On Linux run with sudo or add your user to the 'wireshark' group.")
    if any(h in text for h in INTERFACE_HINTS):
        return "The selected network interface is not available. Refresh the interface list and pick another."
    return (stderr or "Unknown capture error").strip()[:500]


def count_packets(path: Path) -> int:
    """Count packets written so far (tolerates a file that is still being written)."""
    try:
        if not path.exists() or path.stat().st_size < 24:
            return 0
        return sum(1 for _ in CaptureReader(path))
    except Exception:  # noqa: BLE001 - partially written file
        return 0


class CaptureSession:
    def __init__(self, tshark_cmd: list[str] | None = None, output_dir: Path = CAPTURE_DIR):
        """``tshark_cmd`` can override the TShark command (used by the unit tests)."""
        self.tshark_cmd = tshark_cmd
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.engine: str | None = None
        self.output_file: Path | None = None
        self.started_at: float | None = None
        self.stopped_at: float | None = None
        self.duration: int = 0
        self.packet_limit: int = 0
        self.error: str | None = None
        self._proc: subprocess.Popen | None = None
        self._sniffer = None
        self._scapy_count = 0
        self._scapy_writer = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def start(self, interface: str, duration: int = DEFAULT_CAPTURE["duration_sec"],
              packet_limit: int = DEFAULT_CAPTURE["packet_limit"], output_format: str = "pcapng",
              bpf_filter: str = "", engine: str = "auto") -> Path:
        if self.is_running():
            raise CaptureError("A capture is already running. Stop it first.")
        if not interface:
            raise CaptureError("Please select a network interface.")
        duration = max(1, min(int(duration), DEFAULT_CAPTURE["max_duration_sec"]))
        packet_limit = max(0, int(packet_limit or 0))
        self.duration, self.packet_limit, self.error = duration, packet_limit, None

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        tshark = self.tshark_cmd or ([find_tshark()] if find_tshark() else None)
        use_tshark = engine in ("auto", "tshark") and tshark
        if engine == "tshark" and not tshark:
            raise CaptureError("TShark is not installed. Install Wireshark (with TShark) or choose Scapy.")
        if not use_tshark and not scapy_available():
            raise CaptureError("Neither TShark nor Scapy is available, so live capture is not possible on "
                               "this machine. You can still analyse existing files on the Upload PCAP page.")

        if use_tshark:
            ext = "pcapng" if output_format == "pcapng" else "pcap"
            self.output_file = self.output_dir / f"capture_{stamp}.{ext}"
            cmd = list(tshark) + ["-i", interface, "-a", f"duration:{duration}", "-w", str(self.output_file),
                                  "-F", ext, "-q"]
            if packet_limit:
                cmd += ["-c", str(packet_limit)]
            if bpf_filter:
                cmd += ["-f", bpf_filter]
            flags = subprocess.CREATE_NEW_PROCESS_GROUP if IS_WINDOWS else 0
            try:
                self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                              creationflags=flags)
            except OSError as exc:
                raise CaptureError(f"Could not start TShark: {exc}") from exc
            self.engine = "tshark"
            self.started_at = time.time()
            # Detect immediate failures (bad interface, no permission)
            time.sleep(0.8)
            if self._proc.poll() not in (None, 0):
                _, err = self._proc.communicate(timeout=5)
                self.error = friendly_error(err)
                self.stopped_at = time.time()
                raise CaptureError(self.error)
            return self.output_file

        # ---- Scapy fallback ------------------------------------------
        from scapy.all import AsyncSniffer           # optional dependency, imported lazily
        from scapy.utils import PcapWriter as ScapyPcapWriter

        self.output_file = self.output_dir / f"capture_{stamp}.pcap"   # Scapy writes classic pcap
        self._scapy_writer = ScapyPcapWriter(str(self.output_file), append=False, sync=True)
        self._scapy_count = 0

        def on_packet(pkt):
            with self._lock:
                self._scapy_writer.write(pkt)
                self._scapy_count += 1

        try:
            self._sniffer = AsyncSniffer(iface=interface, prn=on_packet, store=False,
                                         count=packet_limit or 0, timeout=duration,
                                         filter=bpf_filter or None)
            self._sniffer.start()
        except Exception as exc:  # noqa: BLE001 - Scapy raises OSError/PermissionError/Scapy_Exception
            self.error = friendly_error(str(exc))
            raise CaptureError(self.error) from exc
        self.engine = "scapy"
        self.started_at = time.time()
        return self.output_file

    # ------------------------------------------------------------------
    def is_running(self) -> bool:
        if self.engine == "tshark" and self._proc is not None:
            return self._proc.poll() is None
        if self.engine == "scapy" and self._sniffer is not None:
            return bool(getattr(self._sniffer, "running", False))
        return False

    def packets_captured(self) -> int:
        if self.engine == "scapy":
            return self._scapy_count
        return count_packets(self.output_file) if self.output_file else 0

    def status(self) -> dict:
        running = self.is_running()
        if not running and self.started_at and self.stopped_at is None:
            self._finish()
        end = time.time() if running else (self.stopped_at or time.time())
        elapsed = round(end - self.started_at, 1) if self.started_at else 0.0
        return {
            "running": running,
            "engine": self.engine,
            "elapsed_sec": elapsed,
            "duration_sec": self.duration,
            "packet_limit": self.packet_limit,
            "packets": self.packets_captured(),
            "output_file": str(self.output_file) if self.output_file else None,
            "error": self.error,
        }

    def stop(self) -> dict:
        """Stop the capture gracefully (the file stays valid) and return final status."""
        if self.engine == "tshark" and self._proc is not None and self._proc.poll() is None:
            try:
                if IS_WINDOWS:
                    os.kill(self._proc.pid, signal.CTRL_BREAK_EVENT)   # like pressing Ctrl+C
                else:
                    self._proc.send_signal(signal.SIGINT)
                self._proc.wait(timeout=8)
            except (subprocess.TimeoutExpired, OSError, ValueError):
                self._proc.terminate()
                try:
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._proc.kill()
        elif self.engine == "scapy" and self._sniffer is not None and self.is_running():
            try:
                self._sniffer.stop()
            except Exception:  # noqa: BLE001
                pass
        self._finish()
        return self.status()

    def _finish(self) -> None:
        if self.stopped_at is None:
            self.stopped_at = time.time()
        if self.engine == "tshark" and self._proc is not None and self._proc.poll() not in (None,):
            try:
                _, err = self._proc.communicate(timeout=2)
            except (subprocess.TimeoutExpired, ValueError, OSError):
                err = ""
            if self._proc.returncode not in (0, None, -2, 130, 3221225786) and not self.packets_captured():
                self.error = friendly_error(err)
        if self.engine == "scapy" and self._scapy_writer is not None:
            try:
                self._scapy_writer.close()
            except Exception:  # noqa: BLE001
                pass
