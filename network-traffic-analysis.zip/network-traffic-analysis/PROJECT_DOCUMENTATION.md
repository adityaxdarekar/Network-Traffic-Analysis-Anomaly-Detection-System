# Network Traffic Analysis and Anomaly Detection System Using Python and Wireshark
### Project Documentation

| | |
|---|---|
| **Project type** | Cybersecurity / Network security (defensive) |
| **Platform** | Python 3.11+, Windows 10/11 (also Linux/macOS) |
| **Version** | 1.0.0 |
| **Student** | *(your name, roll number, department)* |
| **Guide** | *(your guide's name)* |
| **Institution** | *(college name, academic year)* |

---

## Abstract
Organisations and individuals depend on networks whose traffic is largely invisible to them. Security
Operations Centres (SOCs) monitor this traffic to detect reconnaissance, denial-of-service patterns,
covert channels and policy violations, but commercial monitoring platforms are expensive and difficult for
students to study. This project designs and implements a lightweight, SOC-style network traffic analysis
and anomaly detection system in Python. Traffic is captured with Wireshark's command-line tool TShark (with
Scapy as a fallback) or supplied as PCAP/PCAPNG files. A custom streaming packet reader and protocol
decoders extract metadata from Ethernet, ARP, IPv4, IPv6, TCP, UDP, ICMP, DNS, HTTP and TLS without
storing payloads or decrypting HTTPS. Dedicated modules analyse DNS, HTTP/TLS, TCP/UDP and IP-address
behaviour, and a rule-based engine evaluates ten transparent, configurable detection rules - port
scanning, SYN-flood patterns, DNS anomalies, repeated connection failures, traffic-volume spikes, unusual
ports, ICMP anomalies, TCP retransmissions, DNS-tunnelling indicators and unusual external communication.
Results are stored in SQLite, presented in an interactive Streamlit dashboard and exported as professional
PDF reports. The system was verified with 95 automated tests on synthetic traffic and five synthetic
demonstration captures: the benign capture produced no alerts, and a combined scenario capture triggered
all ten rules.

**Keywords:** network traffic analysis, intrusion detection, anomaly detection, Wireshark, TShark, PCAP,
DNS tunnelling, port scanning, SOC, Python, Streamlit.

---

## 1. Introduction
Network traffic is the most complete record of what devices on a network actually do. Tools such as
Wireshark allow an analyst to inspect individual packets, but manually reviewing thousands of packets is
slow and requires expertise. SOC analysts therefore combine packet capture with automated summarisation and
detection logic that points them to the activity most worth investigating.

This project builds such a pipeline end-to-end: capture → decode → analyse → detect → store → visualise →
report. It is intended for education and for monitoring small networks that the user owns (a home or lab
network), and it is designed around three principles:

1. **Transparency** - every alert explains which rule fired, the observed value, the threshold and the
   evidence, so that results can be explained and defended (for example during a viva).
2. **Privacy by design** - only metadata is processed; payloads are not stored; HTTPS is never decrypted;
   all processing is local.
3. **Robustness** - malformed, truncated, empty or very large captures must never crash the application.

## 2. Problem Statement
Students and small organisations need a way to understand what is happening on their networks and to spot
potentially malicious activity, but:
* raw packet captures are too large and detailed to review manually;
* commercial SOC/IDS platforms are costly, complex and opaque;
* signature-based IDS tools require rule sets and tuning beyond a beginner's reach;
* many tutorials stop at printing packets and do not produce explainable findings or reports.

The problem addressed is: *design and implement an affordable, explainable system that converts packet
captures into protocol statistics, host profiles and prioritised, human-readable alerts with
recommendations, while respecting privacy and running on an ordinary laptop.*

## 3. Objectives
1. Capture packets from a selected interface with configurable duration and packet limits.
2. Read PCAP and PCAPNG files robustly.
3. Classify traffic into DNS, HTTP, HTTPS/TLS, TCP, UDP, ICMP, ARP and Other.
4. Extract addresses, ports, flags and application metadata.
5. Identify top talkers, frequent destinations, packet-size distribution and traffic volume over time.
6. Identify unusual ports and communication patterns.
7. Detect potentially suspicious behaviour with ten transparent, configurable rules.
8. Visualise results in an interactive dashboard.
9. Store analysis history in a database.
10. Automatically generate a professional PDF report.

## 4. Literature / Background Overview
This section summarises established concepts the project builds on; standards documents are listed in the
References.

* **Packet capture.** The libpcap file format (`.pcap`) and its successor PCAPNG are the de-facto formats
  for storing captured traffic, produced by tools such as tcpdump, Wireshark and TShark. On Windows, capture
  requires a driver such as Npcap.
* **Protocol layering.** Ethernet frames carry IPv4/IPv6 packets (RFC 791, RFC 8200), which carry TCP
  (RFC 9293), UDP (RFC 768) or ICMP (RFC 792). Application protocols analysed here are DNS (RFC 1035),
  HTTP/1.1 (RFC 9110/9112) and TLS (RFC 8446), whose ClientHello may contain the Server Name Indication
  extension (RFC 6066) in clear text.
* **Intrusion detection approaches.** NIST SP 800-94 describes signature-based, anomaly-based and stateful
  protocol analysis detection. Signature-based systems match known patterns; anomaly-based systems compare
  activity against a baseline or threshold. This project uses *threshold-based anomaly heuristics*, chosen
  because they are simple to explain and to tune.
* **Behaviours detected.** Port scanning corresponds to network service discovery (MITRE ATT&CK T1046);
  TCP SYN flooding is described in RFC 4987; DNS can be abused as a covert channel (ATT&CK T1071.004),
  typically visible as long, high-entropy sub-domains and many unique names under one domain; network
  denial of service corresponds to ATT&CK T1498.
* **Address classes.** Private ranges (RFC 1918), shared address space (RFC 6598), documentation ranges
  (RFC 5737, RFC 3849) and multicast/loopback/link-local ranges help separate internal from external traffic.
* **Incident handling.** NIST SP 800-61 frames alerts as *precursors/indicators* that must be analysed and
  validated - the reason this project never labels an alert as a confirmed attack.

## 5. Existing System
| Existing approach | Strengths | Limitations addressed by this project |
|---|---|---|
| Manual inspection in Wireshark | Very detailed, free | No automatic detection; overwhelming for large captures; needs expertise |
| Signature IDS (e.g. Snort/Suricata) | Mature, fast | Rule sets and tuning are complex; alerts can be hard for beginners to interpret; separate dashboards needed |
| Commercial SIEM/NDR platforms | Comprehensive, scalable | Expensive, heavyweight, opaque logic |
| Simple scripts/tutorials | Easy to start | Usually print packets only; no reporting, history, robustness or explanation |

## 6. Proposed System
A modular Python application that:
* captures with TShark (or Scapy) **or** accepts uploaded capture files;
* decodes packets with a streaming, fault-tolerant reader;
* produces per-protocol and per-host analytics;
* applies ten explainable rules with configurable thresholds and severity;
* stores results in SQLite;
* presents everything in a 12-page dark SOC-style dashboard;
* generates a PDF report from the same analysis results.

**Advantages:** free and lightweight; runs offline on a laptop; explainable alerts with evidence and
investigation steps; privacy-preserving defaults; works without Wireshark for file analysis; automated
tests.

## 7. System Architecture
```
NETWORK INTERFACE
       │
WIRESHARK / TSHARK ──(fallback)── SCAPY             capture/
       │
PACKET CAPTURE (.pcap / .pcapng)  ◄── file upload
       │
PYTHON PACKET ANALYSIS ENGINE                       analyzer/pcap_reader.py, decoders.py, packet_analyzer.py
       │
 ┌─────┴──────────────────────┐
PROTOCOL ANALYSIS          IP ANALYSIS              analyzer/*_analyzer.py, ip_reputation.py
DNS·HTTP·TLS·TCP·UDP       source/destination, categories
 └─────┬──────────────────────┘
ANOMALY DETECTION (10 rules)                        detection/
       │
DATABASE STORAGE (SQLite)                           database/
       │
STREAMLIT DASHBOARD (12 pages)                      app.py, dashboard/
       │
PDF REPORT GENERATOR                                reports/
```

### Data flow
1. A capture file is validated by its magic number, size and extension.
2. `CaptureReader` streams frames; `decode_frame` produces one flat metadata record per packet.
3. Records become a pandas DataFrame; TCP retransmissions are marked.
4. Analysers compute DNS, HTTP, TLS, TCP, UDP and IP statistics.
5. `AnomalyDetector` runs the enabled rules and returns numbered, sorted alerts.
6. `pipeline.run_analysis` returns one `AnalysisResult` used by the dashboard, the database and the PDF.

### Database design (SQLite)
| Table | Main columns |
|---|---|
| `sessions` | session_id (PK), file_name, file_size, analyzed_at, packet_count, total_bytes, duration, unique_ips, dns_queries, http_requests, tcp_connections, udp_packets, alert_count, severity_json, warnings_json |
| `protocol_stats` | session_id (FK), protocol, packets |
| `ip_stats` | session_id, ip, category, packets/bytes sent/received |
| `dns_stats` | session_id, domain, queries |
| `alerts` | session_id, alert_id, rule_id, detection, category, severity, src_ip, dst_ip, port, start/end time, event_count, reason, recommendation, evidence |
| `reports` | session_id, report_path, created_at, pages |

Packet lists and payloads are deliberately **not** stored.

## 8. Hardware Requirements
| Component | Minimum | Recommended |
|---|---|---|
| Processor | Dual-core x86-64 | Quad-core |
| RAM | 4 GB | 8 GB (large captures) |
| Storage | 1 GB free | 5 GB+ for captures |
| Network adapter | Any Ethernet/Wi-Fi adapter (for live capture) | Wired Ethernet for complete captures |

## 9. Software Requirements
| Software | Version / note |
|---|---|
| Operating system | Windows 10/11 (Linux/macOS supported) |
| Python | 3.11 or newer |
| Wireshark + TShark | Current release (live capture only) |
| Npcap | Installed with Wireshark (Windows live capture) |
| Python packages | streamlit ≥ 1.50, plotly, pandas, scapy, reportlab, matplotlib, pytest |
| Browser | Edge / Chrome / Firefox |
| Editor | Visual Studio Code (optional) |

## 10. Methodology
The project followed an incremental, test-driven sequence:
1. **Setup** - environment inspection, project structure, configuration module, dependency list.
2. **Packet analysis** - PCAP/PCAPNG reader, layer-by-layer decoders, protocol classification, per-protocol
   analysers, IP analysis; a synthetic traffic generator was written to create safe test captures.
3. **Anomaly detection** - ten rules, configurable thresholds, structured alerts, severity scaling.
4. **Dashboard** - Streamlit navigation, 12 pages, Plotly charts, filters and search.
5. **Database** - SQLite persistence and session history.
6. **Reporting** - ReportLab PDF with cover, contents, charts, tables; CSV/ZIP/JSON exports.
7. **Testing** - unit, rule, robustness and dashboard smoke tests; bugs fixed and rules refined.
8. **Documentation** - README, this document, demonstration guide.

### Detection approach
Each rule computes an observable quantity over a sliding time window or over the whole capture and compares
it with a threshold. A sliding-window helper finds the peak number of events (or distinct items, e.g.
ports) within any window of the configured length. Severity starts at the rule's configurable base level and
is raised by one level when the observed value reaches 3× the threshold and by two levels at 10×. Rules are
designed to reduce false positives with context, for example:
* R2 counts a SYN as answered if it received a SYN-ACK **or** RST, so a port scan (which receives RSTs) is not
  mistaken for a flood, and severity is lowered when the capture contains no SYN-ACKs at all (likely a
  one-direction capture).
* R4 requires most attempts to fail, because many successful connections to one server are normal.
* R7 ignores echo replies, so a host answering pings is not blamed.
* R9 requires both many distinct sub-domains and long/random-looking names (or TXT-heavy querying).

## 11. Module Descriptions
| Module | Responsibility |
|---|---|
| `config.py` | Paths, limits, default thresholds, rule names/severities, suspicious ports, settings load/save |
| `capture/interface_manager.py` | Locate TShark, list interfaces (`tshark -D` or Scapy), detect Npcap/admin rights |
| `capture/packet_capture.py` | `CaptureSession`: start/stop/status, duration & packet limits, BPF filter, graceful stop, friendly permission/interface errors, Scapy fallback |
| `analyzer/pcap_reader.py` | Streaming PCAP (µs/ns, both endians) and PCAPNG (SHB/IDB/EPB/SPB, ts resolution) reader with truncation handling |
| `analyzer/decoders.py` | Link-layer handling, IPv4/IPv6 (extension headers, fragments), ARP, TCP, UDP, ICMP/ICMPv6, DNS (compression-safe), HTTP, TLS, QUIC; classification |
| `analyzer/packet_analyzer.py` | Validation + decoding into a DataFrame; optional Scapy engine |
| `analyzer/dns_analyzer.py` | Queries/responses, types, rcodes, failures, unanswered, latency, repeats, per host, name heuristics, sub-domain diversity |
| `analyzer/http_analyzer.py` | Methods, hosts, paths, status codes, User-Agents, request rate |
| `analyzer/tls_analyzer.py` | ClientHello/ServerHello versions, SNI, destinations and connection frequency, legacy TLS, QUIC |
| `analyzer/tcp_analyzer.py` | Flag counts, connection reconstruction & state, failures, durations, retransmissions |
| `analyzer/udp_analyzer.py` | Counts, ports, conversations, rates, DNS share |
| `analyzer/ip_analyzer.py` | Address classification, per-host traffic, top talkers, conversations, patterns |
| `analyzer/ip_reputation.py` | Offline watch-list and manual reputation links |
| `analyzer/pipeline.py` | Orchestration, summary KPIs, timeline, size distribution |
| `detection/detection_rules.py` | The ten rules, alert data structure, severity scaling |
| `detection/anomaly_detector.py` | Runs enabled rules, isolates rule errors, caps alerts per rule, numbers alerts |
| `database/db_manager.py` | SQLite schema, save/list/get/delete sessions, report metadata |
| `reports/charts.py`, `reports/pdf_generator.py` | Matplotlib charts; ReportLab report with TOC and "Page X of Y" |
| `dashboard/*` | Theme, shared widgets and the 12 pages |
| `utils/*` | Helpers, validators, synthetic packet builder/writer |

## 12. Implementation
### 12.1 Packet decoding
Frames are parsed with Python's `struct` module. For example a TCP header is unpacked as
`struct.unpack("!HHIIHH", segment[:16])` giving ports, sequence/acknowledgement numbers, data offset/flags
and window. Every decoder checks lengths first; any `struct.error`/`IndexError` marks the packet
`malformed=True` and keeps whatever fields were already decoded. DNS names are read with a loop limit and a
compression-pointer depth limit, so a malicious self-referencing pointer cannot hang the program.

### 12.2 TLS metadata
For a TLS handshake record, the ClientHello is walked to its extensions; the `server_name` extension
(type 0) gives the SNI and `supported_versions` (type 43) gives the highest offered version (TLS 1.3 hides
its real version in this extension). Application-data records are only counted.

### 12.3 TCP connection reconstruction and retransmissions
Packets are grouped by the unordered pair of endpoints. The side that sends a SYN without ACK is the
client. States are derived from the observed SYN, SYN-ACK, client ACK, FIN and RST packets ("Established",
"Closed (FIN)", "No reply to SYN", "Rejected (RST)", "Handshake incomplete", "Partial (handshake not
captured)"). A segment is marked as a retransmission when the same (sequence number, length) was already
sent in that direction, or when the whole segment lies below the highest sequence number already sent
(32-bit wrap-around handled).

### 12.4 Detection rule example (R1 - port scan)
```python
for (src, dst), g in syn_packets.groupby(["src_ip", "dst_ip"]):
    peak, start, end = _window_peak(g.timestamp, g.dst_port, window=60, distinct=True)
    if peak >= threshold:            # e.g. 20 distinct ports in 60 s
        severity = scale_severity("Medium", peak, threshold)
        alerts.append(Alert("R1", "Possible Port Scanning", severity, src, dst, ...,
                            reason=f"{src} sent TCP probes to {peak} different ports on {dst} ..."))
```

### 12.5 Live capture
TShark is started as a child process:
`tshark -i <iface> -a duration:<s> [-c <count>] [-f <bpf>] -w <file> -F pcapng -q`. The dashboard polls the
growing file to show the packet count. Stopping sends Ctrl+Break on Windows (SIGINT elsewhere) so the file is
closed cleanly. Common errors (missing TShark, permission denied, invalid interface) are translated into
beginner-friendly messages.

### 12.6 Dashboard and report
The Streamlit app keeps the current `AnalysisResult` in session state; every page reads from it. The PDF
uses ReportLab's `BaseDocTemplate` with two page templates (cover/content), a `TableOfContents` populated by
`afterFlowable`, a two-pass `multiBuild`, and a custom canvas that writes "Page X of Y".

## 13. Testing
### 13.1 Strategy
* **Synthetic data only.** `utils/pcap_writer.py` builds real, checksum-correct packets for every scenario;
  no real or malicious traffic is used.
* **Unit tests** for each analyser, **rule tests** with positive and negative cases, **robustness tests**,
  **integration tests** of the full pipeline, PDF and database tests, capture tests with a fake TShark
  executable, and a **headless smoke test** of all dashboard pages using stand-ins for Streamlit/Plotly.

### 13.2 Test cases (95 automated tests, all passing in the development environment)
| # | Required test | Implemented as (examples) | Result |
|---|---|---|---|
| 1 | PCAP file reading | identical results from `.pcap` and `.pcapng`; all sample files readable; timestamps exact | Pass |
| 2 | DNS packet extraction | queries/answers (A, AAAA, MX, TXT, CNAME, NS), NXDOMAIN, unanswered, latency, repeats | Pass |
| 3 | HTTP request extraction | method, host, path, status, User-Agent; query string removed | Pass |
| 4 | TCP packet analysis | flags, connection states, retransmissions (positive and none-in-normal-session) | Pass |
| 5 | UDP packet analysis | counts, DNS share, NTP service recognition | Pass |
| 6 | IP address classification | 21 parametrised cases (private, public, loopback, multicast, broadcast, link-local, CGNAT, documentation, reserved, invalid) | Pass |
| 7 | Port-scan heuristic | 100-port scan detected with open ports listed; below-threshold and slow scans not flagged | Pass |
| 8 | SYN anomaly heuristic | flood detected; severity lowered for one-way capture; answered SYNs and port scans not flagged | Pass |
| 9 | DNS anomaly heuristic | per-host burst detected (R3); tunnelling indicators (R9); normal names not flagged | Pass |
| 10 | PDF report generation | all sections present, real numbers, page numbers; no-alert, screenshot and empty-capture variants | Pass |

### 13.3 Edge cases
| Case | Expected behaviour | Result |
|---|---|---|
| Empty capture (header only) / zero-byte file | Warning "no packets" / clear rejection | Pass |
| Invalid file format (text renamed `.pcap`, wrong extension) | Rejected with a friendly message | Pass |
| Truncated capture (pcap and pcapng) | Reads all complete packets, reports truncation | Pass |
| Missing / malformed packet fields | Packet flagged malformed; analysis continues | Pass |
| Unsupported packet / link types | Classified "Other" / "Unsupported link type" | Pass |
| Large capture (50,000 packets) and packet limit | Completes; limit respected | Pass |
| No detected alerts | Dashboard and PDF state this clearly | Pass |
| Missing TShark installation | Capture disabled with guidance; upload still works | Pass |
| A detection rule raising an error | Error reported; other rules still run | Pass |

### 13.4 Defects found and fixed during testing
* SYN-flood rule also fired on port scans (RST replies were counted as unanswered) → RST now counts as an answer.
* ICMP rule flagged the gateway for *replying* to a ping flood → echo replies excluded.
* Repeated-connection rule flagged 20 successful HTTPS connections in a busy synthetic capture → the rule now
  requires mostly failing attempts (or 5× the threshold).
* An f-string used syntax valid only in Python 3.12 → rewritten for 3.11 compatibility; all sources
  compile under Python 3.11, 3.12 and 3.13.

## 14. Results
Results of analysing the included **synthetic** demonstration captures with default thresholds
(measured in the development environment):

| Capture | Packets | Unique IPs | DNS queries | TCP conversations | Alerts | Rules triggered |
|---|---|---|---|---|---|---|
| normal_traffic.pcapng | 592 | 15 | 46 | 24 | 0 | - |
| port_scan.pcap | 2,361 | 89 | 18 | 1,034 | 7 (1 Critical, 6 Low) | R1, R6, R7 |
| syn_flood.pcap | 602 | 328 | 16 | 409 | 2 (1 Critical, 1 Low) | R2, R5 |
| dns_tunneling.pcapng | 798 | 15 | 188 | 20 | 2 (1 High, 1 Low) | R3, R9 |
| mixed_demo.pcapng | 2,537 | 411 | 180 | 804 | 19 (2 Critical, 1 High, 3 Medium, 13 Low) | R1–R10 (all) |

Additional observations:
* A synthetic busy-but-benign capture of 88,000 packets (4,000 HTTPS sessions) was analysed in about 2.7 s
  (≈ 33,000 packets/s) and produced **no alerts** after the R4 refinement.
* Each analysis of the sample files took under 0.3 s; a full PDF report took about 1–1.5 s.

These results show that the rules fire on the behaviours they were designed for and stay quiet on the
benign scenarios used. They are **not** a measurement of detection accuracy on real-world networks, because
no real-world or labelled attack dataset was evaluated in this project.

*Screenshots of the running dashboard should be inserted here (see `screenshots/README.md`).*

## 15. Limitations
* Encrypted payloads (HTTPS, QUIC) are not inspected; Encrypted Client Hello hides SNI.
* Threshold heuristics can produce false positives and miss slow or stealthy activity; thresholds need tuning
  per network.
* Results depend on capture completeness (dropped packets, mid-connection starts, asymmetric capture).
* No TCP stream or IP fragment reassembly; HTTP headers split across segments may be missed.
* Detection effectiveness has been verified only on synthetic data.
* Designed for offline/laptop-scale analysis, not continuous high-speed monitoring.

## 16. Future Scope
* Learned baselines and machine-learning anomaly scores trained on the user's own traffic.
* Evaluation on public, labelled intrusion-detection datasets.
* TCP stream reassembly; more protocol parsers; JA3/JA4 TLS fingerprints.
* Opt-in threat-intelligence and GeoIP enrichment.
* Continuous ring-buffer capture, scheduled analysis and notifications.
* SIEM integration and standard alert formats.

## 17. Conclusion
The project delivers a complete, working network traffic analysis and anomaly detection system: capture,
robust decoding, protocol and host analytics, ten explainable detection rules, persistent history, an
interactive SOC-style dashboard and automated PDF reporting. Its emphasis on transparency, privacy and
robustness makes it suitable for learning how SOC tooling works and for monitoring small networks the user
is authorised to observe. Automated tests on synthetic traffic confirm that each component behaves as
designed, while the documented limitations make clear that alerts are investigation leads rather than
proof of malicious activity.

## 18. References
1. J. Postel, *Internet Protocol*, RFC 791, IETF, 1981.
2. J. Postel, *User Datagram Protocol*, RFC 768, IETF, 1980.
3. J. Postel, *Internet Control Message Protocol*, RFC 792, IETF, 1981.
4. P. Mockapetris, *Domain Names - Implementation and Specification*, RFC 1035, IETF, 1987.
5. Y. Rekhter et al., *Address Allocation for Private Internets*, RFC 1918, IETF, 1996.
6. W. Eddy, *TCP SYN Flooding Attacks and Common Mitigations*, RFC 4987, IETF, 2007.
7. J. Arkko, M. Cotton, L. Vegoda, *IPv4 Address Blocks Reserved for Documentation*, RFC 5737, IETF, 2010.
8. D. Eastlake 3rd, *Transport Layer Security (TLS) Extensions: Extension Definitions*, RFC 6066, IETF, 2011.
9. S. Deering, R. Hinden, *Internet Protocol, Version 6 (IPv6) Specification*, RFC 8200, IETF, 2017.
10. E. Rescorla, *The Transport Layer Security (TLS) Protocol Version 1.3*, RFC 8446, IETF, 2018.
11. K. Moriarty, S. Farrell, *Deprecating TLS 1.0 and TLS 1.1*, RFC 8996, IETF, 2021.
12. R. Fielding, M. Nottingham, J. Reschke (eds.), *HTTP Semantics*, RFC 9110, IETF, 2022.
13. W. Eddy (ed.), *Transmission Control Protocol (TCP)*, RFC 9293, IETF, 2022.
14. IETF OPSAWG, *PCAP Now Generic (pcapng) Capture File Format*, Internet-Draft (draft-ietf-opsawg-pcapng).
15. K. Scarfone, P. Mell, *Guide to Intrusion Detection and Prevention Systems (IDPS)*, NIST SP 800-94, 2007.
16. P. Cichonski et al., *Computer Security Incident Handling Guide*, NIST SP 800-61 Rev. 2, 2012.
17. MITRE ATT&CK®: T1046 Network Service Discovery; T1071.004 Application Layer Protocol: DNS; T1498 Network
    Denial of Service. <https://attack.mitre.org/>
18. Wireshark Foundation, *Wireshark User's Guide* and *tshark(1) manual*. <https://www.wireshark.org/docs/>
19. Npcap documentation. <https://npcap.com/guide/>
20. Scapy documentation. <https://scapy.readthedocs.io/>
21. Streamlit documentation. <https://docs.streamlit.io/>
22. ReportLab, *ReportLab PDF Library User Guide*. <https://docs.reportlab.com/>
