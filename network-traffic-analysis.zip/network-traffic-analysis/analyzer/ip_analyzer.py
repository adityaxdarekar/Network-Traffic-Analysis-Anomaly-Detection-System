"""
IP address analysis: classification, per-host statistics, top talkers, conversations.

Important: an address being *public* or *unfamiliar* is never treated as
malicious. Classification only describes what kind of address it is.
"""

from __future__ import annotations

import ipaddress
from functools import lru_cache

import pandas as pd

CGNAT = ipaddress.ip_network("100.64.0.0/10")
DOCUMENTATION = [ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24", "2001:db8::/32")]


@lru_cache(maxsize=65536)
def classify_ip(ip: str) -> str:
    """
    Return one of: Loopback, Private, Link-local, Multicast, Broadcast,
    Shared (CGNAT), Documentation, Unspecified, Reserved, Public, Invalid.
    """
    try:
        addr = ipaddress.ip_address(str(ip))
    except ValueError:
        return "Invalid"
    if addr.is_unspecified:
        return "Unspecified"
    if addr.is_loopback:
        return "Loopback"
    if addr.is_multicast:
        return "Multicast"
    if addr.version == 4 and str(addr) == "255.255.255.255":
        return "Broadcast"
    if addr.is_link_local:
        return "Link-local"
    if addr.version == 4 and addr in CGNAT:
        return "Shared (CGNAT)"
    if any(addr in net for net in DOCUMENTATION if net.version == addr.version):
        return "Documentation"
    if addr.is_private:          # RFC 1918, fc00::/7 and other non-global ranges
        net_private = (addr.version == 4 and any(addr in ipaddress.ip_network(n) for n in
                                                  ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))) \
            or (addr.version == 6 and addr in ipaddress.ip_network("fc00::/7"))
        return "Private" if net_private else "Reserved"
    if addr.is_reserved:
        return "Reserved"
    if addr.is_global:
        return "Public"
    return "Reserved"


def is_internal(ip: str) -> bool:
    """Internal = private LAN address (RFC 1918 / IPv6 ULA)."""
    return classify_ip(ip) == "Private"


def is_external(ip: str) -> bool:
    """
    External = an Internet address. Documentation ranges (RFC 5737/3849,
    e.g. 203.0.113.0/24) are treated as external too, so that the synthetic
    demo captures - which deliberately use those reserved "example" ranges
    instead of real companies' addresses - behave like Internet traffic.
    """
    return classify_ip(ip) in ("Public", "Documentation")


def analyze_ips(df: pd.DataFrame, top_n: int = 10) -> dict:
    ipdf = df[df["src_ip"].notna() & df["dst_ip"].notna()] if not df.empty else df
    host_cols = ["ip", "version", "category", "packets_sent", "packets_received", "total_packets",
                 "bytes_sent", "bytes_received", "total_bytes", "unique_peers", "first_seen", "last_seen"]
    if ipdf.empty:
        empty = pd.DataFrame(columns=host_cols)
        return {"hosts": empty, "unique_ips": 0, "category_counts": {}, "top_sources": empty,
                "top_destinations": empty,
                "conversations": pd.DataFrame(columns=["src_ip", "dst_ip", "packets", "bytes"]),
                "patterns": []}

    sent = ipdf.groupby("src_ip").agg(packets_sent=("no", "size"), bytes_sent=("length", "sum"),
                                      first_tx=("timestamp", "min"), last_tx=("timestamp", "max"))
    recv = ipdf.groupby("dst_ip").agg(packets_received=("no", "size"), bytes_received=("length", "sum"),
                                      first_rx=("timestamp", "min"), last_rx=("timestamp", "max"))
    hosts = sent.join(recv, how="outer")
    for col in ("packets_sent", "bytes_sent", "packets_received", "bytes_received"):
        hosts[col] = hosts[col].fillna(0).astype(int)
    hosts["first_seen"] = hosts[["first_tx", "first_rx"]].min(axis=1)
    hosts["last_seen"] = hosts[["last_tx", "last_rx"]].max(axis=1)
    hosts["total_packets"] = hosts["packets_sent"] + hosts["packets_received"]
    hosts["total_bytes"] = hosts["bytes_sent"] + hosts["bytes_received"]

    pairs = pd.concat([ipdf[["src_ip", "dst_ip"]].rename(columns={"src_ip": "ip", "dst_ip": "peer"}),
                       ipdf[["dst_ip", "src_ip"]].rename(columns={"dst_ip": "ip", "src_ip": "peer"})])
    hosts["unique_peers"] = pairs.drop_duplicates().groupby("ip").size()
    hosts = hosts.reset_index().rename(columns={"index": "ip"})
    if "ip" not in hosts.columns:
        hosts = hosts.rename(columns={hosts.columns[0]: "ip"})
    hosts["category"] = hosts["ip"].map(classify_ip)
    hosts["version"] = hosts["ip"].map(lambda x: 6 if ":" in str(x) else 4)
    hosts["unique_peers"] = hosts["unique_peers"].fillna(0).astype(int)
    hosts = hosts[host_cols].sort_values("total_bytes", ascending=False).reset_index(drop=True)

    conv = (ipdf.groupby(["src_ip", "dst_ip"]).agg(packets=("no", "size"), bytes=("length", "sum"))
            .reset_index().sort_values("bytes", ascending=False).reset_index(drop=True))

    patterns = _patterns(hosts)
    return {
        "hosts": hosts,
        "unique_ips": len(hosts),
        "category_counts": hosts["category"].value_counts().to_dict(),
        "top_sources": hosts.sort_values("packets_sent", ascending=False).head(top_n).reset_index(drop=True),
        "top_destinations": hosts.sort_values("packets_received", ascending=False).head(top_n).reset_index(drop=True),
        "conversations": conv,
        "patterns": patterns,
    }


def _patterns(hosts: pd.DataFrame) -> list[dict]:
    """Descriptive (not accusatory) observations about communication patterns."""
    notes = []
    if hosts.empty:
        return notes
    median_peers = max(float(hosts["unique_peers"].median()), 1.0)
    for row in hosts.itertuples():
        if row.unique_peers >= max(25, 5 * median_peers):
            notes.append({"ip": row.ip, "observation": f"Communicates with {row.unique_peers} different hosts "
                          f"(median is {median_peers:.0f}).",
                          "why_it_matters": "Could be a server, a scanner or a busy client - verify its role."})
        if row.packets_sent >= 20 and row.packets_received == 0:
            notes.append({"ip": row.ip, "observation": f"Sent {row.packets_sent} packets but received none.",
                          "why_it_matters": "One-way traffic can mean unanswered requests, scanning, or that "
                          "only one direction was captured."})
        if row.category == "Private" and row.bytes_sent > 10 * max(row.bytes_received, 1) \
                and row.bytes_sent > 1_000_000:
            notes.append({"ip": row.ip, "observation": "Internal host sent far more data than it received.",
                          "why_it_matters": "Normal for backups, cloud sync or video calls; large unexpected "
                          "uploads are worth confirming with the device owner."})
    return notes[:50]
