"""
HTTPS / TLS metadata analysis.

HTTPS content is encrypted and is NOT decrypted or inspected. The only data
used is what is visible to any network device:
    * destination IP and port,
    * the TLS version offered/negotiated in the handshake,
    * the Server Name Indication (SNI) in the ClientHello - when present
      (TLS 1.3 with Encrypted Client Hello hides it),
    * how often each destination is contacted.
QUIC (HTTP/3 over UDP 443) is counted but cannot be inspected further.
"""

from __future__ import annotations

import pandas as pd

from config import TLS_PORTS

LEGACY_VERSIONS = {"SSL 3.0", "TLS 1.0", "TLS 1.1"}


def analyze_tls(df: pd.DataFrame, top_n: int = 10) -> dict:
    tls = df[df["protocol"] == "HTTPS/TLS"] if not df.empty else df
    hello_cols = ["no", "datetime", "src_ip", "dst_ip", "dst_port", "tls_version", "tls_sni"]
    if tls.empty:
        return {"packet_count": 0, "bytes": 0, "client_hellos": pd.DataFrame(columns=hello_cols),
                "server_hellos": pd.DataFrame(columns=hello_cols), "version_counts": {},
                "negotiated_versions": {}, "top_sni": pd.DataFrame(columns=["sni", "connections"]),
                "destinations": pd.DataFrame(columns=["dst_ip", "dst_port", "connections", "packets", "bytes", "sni"]),
                "legacy_tls": pd.DataFrame(columns=hello_cols), "quic_packets": 0, "encrypted_packets": 0,
                "sni_missing": 0}

    ch = tls[tls["tls_handshake"] == "ClientHello"]
    sh = tls[tls["tls_handshake"] == "ServerHello"]
    sni = ch["tls_sni"].dropna().value_counts().head(top_n)

    # A "connection" to a TLS destination = a SYN to a TLS port, or a ClientHello if SYNs were not captured.
    syns = df[(df["transport"] == "TCP") & df["flag_syn"] & ~df["flag_ack"] & df["dst_port"].isin(TLS_PORTS)
              & ~df["is_retransmission"]]
    conn_src = syns if len(syns) >= len(ch) else ch
    conns = conn_src.groupby(["dst_ip", "dst_port"]).size().rename("connections")
    # traffic towards the server (client -> server direction) plus the reverse direction
    fwd = tls.groupby(["dst_ip", "dst_port"]).agg(packets=("no", "size"), bytes=("length", "sum"))
    rev = tls.groupby(["src_ip", "src_port"]).agg(packets=("no", "size"), bytes=("length", "sum"))
    rev.index = rev.index.set_names(["dst_ip", "dst_port"])
    traffic = fwd.add(rev, fill_value=0)
    dest = traffic.join(conns, how="left").fillna({"connections": 0})
    sni_by_dest = ch.dropna(subset=["tls_sni"]).groupby(["dst_ip", "dst_port"])["tls_sni"].agg(
        lambda s: ", ".join(sorted(set(s))[:3]))
    dest = dest.join(sni_by_dest.rename("sni"), how="left").reset_index()
    dest = dest[dest["dst_port"].isin(TLS_PORTS) | (dest["connections"] > 0) | dest["sni"].notna()]
    dest["connections"] = dest["connections"].astype(int)
    dest["packets"] = dest["packets"].astype(int)
    dest["bytes"] = dest["bytes"].astype(int)
    dest = dest.sort_values(["connections", "bytes"], ascending=False).reset_index(drop=True)
    dest = dest[["dst_ip", "dst_port", "connections", "packets", "bytes", "sni"]]

    return {
        "packet_count": len(tls),
        "bytes": int(tls["length"].sum()),
        "client_hellos": ch[hello_cols].reset_index(drop=True),
        "server_hellos": sh[hello_cols].reset_index(drop=True),
        "version_counts": ch["tls_version"].value_counts().to_dict(),
        "negotiated_versions": sh["tls_version"].value_counts().to_dict(),
        "top_sni": pd.DataFrame({"sni": sni.index, "connections": sni.values}),
        "destinations": dest,
        "legacy_tls": pd.concat([ch, sh])[lambda x: x["tls_version"].isin(LEGACY_VERSIONS)][hello_cols],
        "quic_packets": int((tls["app_protocol"] == "QUIC").sum()),
        "encrypted_packets": int(tls["tls_handshake"].isna().sum()),
        "sni_missing": int(ch["tls_sni"].isna().sum()),
    }
