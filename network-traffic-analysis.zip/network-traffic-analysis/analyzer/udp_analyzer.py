"""UDP analysis: packet counts, ports, conversations, communication frequency."""

from __future__ import annotations

import pandas as pd

from config import DNS_PORTS

WELL_KNOWN_UDP = {53: "DNS", 67: "DHCP server", 68: "DHCP client", 123: "NTP", 137: "NetBIOS-NS",
                  138: "NetBIOS-DGM", 161: "SNMP", 443: "QUIC (HTTP/3)", 500: "IKE/IPsec", 514: "Syslog",
                  1900: "SSDP/UPnP", 3478: "STUN", 5353: "mDNS", 5355: "LLMNR"}


def analyze_udp(df: pd.DataFrame) -> dict:
    udp = df[df["transport"] == "UDP"] if not df.empty else df
    empty_conv = pd.DataFrame(columns=["src_ip", "dst_ip", "dst_port", "service", "packets", "bytes",
                                       "first_seen", "last_seen", "packets_per_sec"])
    if udp.empty:
        return {"packet_count": 0, "bytes": 0, "dns_packets": 0, "conversations": empty_conv,
                "top_dst_ports": pd.DataFrame(columns=["port", "service", "packets"]),
                "top_src_ports": pd.DataFrame(columns=["port", "packets"])}

    dns_mask = udp["src_port"].isin(DNS_PORTS) | udp["dst_port"].isin(DNS_PORTS)
    conv = (udp.groupby(["src_ip", "dst_ip", "dst_port"], dropna=False)
            .agg(packets=("no", "size"), bytes=("length", "sum"),
                 first_seen=("timestamp", "min"), last_seen=("timestamp", "max"))
            .reset_index())
    span = (conv["last_seen"] - conv["first_seen"]).clip(lower=1.0)
    conv["packets_per_sec"] = (conv["packets"] / span).round(2)
    conv["service"] = conv["dst_port"].map(lambda p: WELL_KNOWN_UDP.get(int(p), "") if pd.notna(p) else "")
    conv = conv.sort_values("packets", ascending=False).reset_index(drop=True)[list(empty_conv.columns)]

    dports = udp["dst_port"].value_counts().head(15)
    sports = udp["src_port"].value_counts().head(15)
    return {
        "packet_count": len(udp),
        "bytes": int(udp["length"].sum()),
        "dns_packets": int(dns_mask.sum()),
        "conversations": conv,
        "top_dst_ports": pd.DataFrame({"port": dports.index.astype(int),
                                       "service": [WELL_KNOWN_UDP.get(int(p), "") for p in dports.index],
                                       "packets": dports.values}),
        "top_src_ports": pd.DataFrame({"port": sports.index.astype(int), "packets": sports.values}),
    }
