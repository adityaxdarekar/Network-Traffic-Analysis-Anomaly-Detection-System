"""
TCP analysis: flag statistics, connection reconstruction, retransmissions.

Limitations (also shown in the dashboard):
    * If the capture started after a connection was opened, its handshake is
      missing and it is reported as "Partial (handshake not captured)".
    * If the capture missed packets (busy interface, Wi-Fi, packet limits),
      a normal connection can look "unanswered" or "retransmitted".
    * Retransmission detection uses sequence numbers only; out-of-order
      delivery can occasionally be counted as a retransmission.
"""

from __future__ import annotations

import pandas as pd

TCP_LIMITATIONS = [
    "Connections that started before the capture began have no visible handshake; they are marked 'Partial'.",
    "Packets dropped by the capturing machine can make normal connections look unanswered or retransmitted.",
    "Retransmissions are inferred from repeated TCP sequence numbers; reordered packets may be counted too.",
    "Connection duration is the time between the first and last captured packet, not necessarily the full lifetime.",
    "Asymmetric routing (seeing only one direction) makes every connection look incomplete.",
]


def _seq_le(a: int, b: int) -> bool:
    """a <= b in 32-bit TCP sequence space (handles wrap-around)."""
    return ((b - a) % 2**32) < 2**31


def mark_retransmissions(df: pd.DataFrame) -> pd.DataFrame:
    """Set ``is_retransmission`` for TCP segments that repeat already-seen sequence space."""
    if df.empty:
        return df
    tcp = df[df["transport"] == "TCP"]
    if tcp.empty:
        return df
    seen: dict[tuple, set] = {}
    max_end: dict[tuple, int] = {}
    retrans_idx = []
    for idx, src, sport, dst, dport, seq, plen, syn, fin, rst in zip(
            tcp.index, tcp["src_ip"], tcp["src_port"], tcp["dst_ip"], tcp["dst_port"], tcp["tcp_seq"],
            tcp["payload_len"], tcp["flag_syn"], tcp["flag_fin"], tcp["flag_rst"]):
        if seq is None or pd.isna(seq) or rst:
            continue
        seg_len = int(plen) + int(bool(syn)) + int(bool(fin))
        if seg_len == 0:                     # pure ACKs carry no sequence space
            continue
        key = (src, sport, dst, dport)
        seq = int(seq)
        end = (seq + seg_len) % 2**32
        flow_seen = seen.setdefault(key, set())
        if (seq, seg_len) in flow_seen:
            # Exactly the same segment was already sent once.
            retrans_idx.append(idx)
        elif key in max_end and _seq_le(end, max_end[key]):
            # The whole segment lies inside sequence space this sender already sent.
            retrans_idx.append(idx)
        elif key not in max_end or _seq_le(max_end[key], end):
            max_end[key] = end
        flow_seen.add((seq, seg_len))
    df["is_retransmission"] = False
    if retrans_idx:
        df.loc[retrans_idx, "is_retransmission"] = True
    return df


def build_connections(df: pd.DataFrame) -> pd.DataFrame:
    """Group TCP packets into bidirectional conversations and describe each one."""
    cols = ["client_ip", "client_port", "server_ip", "server_port", "start", "end", "duration_sec",
            "packets", "bytes", "syn", "syn_ack", "rst", "fin", "retransmissions", "state"]
    tcp = df[df["transport"] == "TCP"]
    if tcp.empty:
        return pd.DataFrame(columns=cols)

    conns: dict[tuple, dict] = {}
    for src, sport, dst, dport, ts, length, syn, ack, fin, rst, retrans in zip(
            tcp["src_ip"], tcp["src_port"], tcp["dst_ip"], tcp["dst_port"], tcp["timestamp"], tcp["length"],
            tcp["flag_syn"], tcp["flag_ack"], tcp["flag_fin"], tcp["flag_rst"], tcp["is_retransmission"]):
        a, b = (src, sport), (dst, dport)
        key = (a, b) if (str(a[0]), a[1] or 0) <= (str(b[0]), b[1] or 0) else (b, a)
        c = conns.get(key)
        if c is None:
            # Assume the first sender is the client until we see a SYN that says otherwise.
            c = conns[key] = {"client": a, "server": b, "start": ts, "end": ts, "packets": 0, "bytes": 0,
                              "syn": 0, "syn_ack": 0, "rst": 0, "fin": 0, "retrans": 0,
                              "client_ack_after_synack": False, "known_client": False}
        if syn and not ack and not c["known_client"]:
            c["client"], c["server"], c["known_client"] = a, b, True
        c["packets"] += 1
        c["bytes"] += int(length)
        c["start"], c["end"] = min(c["start"], ts), max(c["end"], ts)
        if syn and not ack:
            c["syn"] += 1
        if syn and ack:
            c["syn_ack"] += 1
        if ack and not syn and c["syn_ack"] and a == c["client"]:
            c["client_ack_after_synack"] = True
        c["fin"] += int(bool(fin))
        c["rst"] += int(bool(rst))
        c["retrans"] += int(bool(retrans))

    rows = []
    for c in conns.values():
        if c["syn"] and c["syn_ack"] and c["client_ack_after_synack"]:
            state = "Closed (FIN)" if c["fin"] else "Reset after handshake" if c["rst"] else "Established"
        elif c["syn"] and c["rst"] and not c["syn_ack"]:
            state = "Rejected (RST)"
        elif c["syn"] and c["syn_ack"]:
            state = "Handshake incomplete"
        elif c["syn"]:
            state = "No reply to SYN"
        else:
            state = "Partial (handshake not captured)"
        rows.append({
            "client_ip": c["client"][0], "client_port": c["client"][1],
            "server_ip": c["server"][0], "server_port": c["server"][1],
            "start": c["start"], "end": c["end"], "duration_sec": round(c["end"] - c["start"], 3),
            "packets": c["packets"], "bytes": c["bytes"], "syn": c["syn"], "syn_ack": c["syn_ack"],
            "rst": c["rst"], "fin": c["fin"], "retransmissions": c["retrans"], "state": state,
        })
    return pd.DataFrame(rows, columns=cols).sort_values("start").reset_index(drop=True)


def analyze_tcp(df: pd.DataFrame) -> dict:
    tcp = df[df["transport"] == "TCP"] if not df.empty else df
    connections = build_connections(df) if not df.empty else build_connections(pd.DataFrame(columns=["transport"]))
    if tcp.empty:
        return {"packet_count": 0, "flag_counts": {}, "connections": connections, "connection_attempts": 0,
                "completed_handshakes": 0, "failed_connections": connections, "retransmissions": 0,
                "retransmission_rate": 0.0, "top_dst_ports": pd.DataFrame(columns=["port", "packets"]),
                "state_counts": {}, "limitations": TCP_LIMITATIONS}

    syn_only = tcp["flag_syn"] & ~tcp["flag_ack"]
    flag_counts = {
        "SYN": int(syn_only.sum()),
        "SYN-ACK": int((tcp["flag_syn"] & tcp["flag_ack"]).sum()),
        "ACK": int(tcp["flag_ack"].sum()),
        "FIN": int(tcp["flag_fin"].sum()),
        "RST": int(tcp["flag_rst"].sum()),
        "PSH": int(tcp["flag_psh"].sum()),
    }
    retrans = int(tcp["is_retransmission"].sum())
    ports = (tcp[syn_only]["dst_port"] if syn_only.any() else tcp["dst_port"]).value_counts().head(15)
    top_ports = pd.DataFrame({"port": ports.index.astype(int), "packets": ports.values})
    failed = connections[connections["state"].isin(["No reply to SYN", "Rejected (RST)", "Handshake incomplete"])]
    return {
        "packet_count": len(tcp),
        "flag_counts": flag_counts,
        "connections": connections,
        "connection_attempts": int((syn_only & ~tcp["is_retransmission"]).sum()),
        "completed_handshakes": int(connections["state"].isin(["Established", "Closed (FIN)", "Reset after handshake"]).sum()),
        "failed_connections": failed,
        "retransmissions": retrans,
        "retransmission_rate": round(retrans / len(tcp), 4),
        "top_dst_ports": top_ports,
        "state_counts": connections["state"].value_counts().to_dict(),
        "limitations": TCP_LIMITATIONS,
    }
