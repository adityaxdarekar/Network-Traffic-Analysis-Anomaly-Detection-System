"""
Packet analysis engine - step 1 of the pipeline.

Reads a PCAP/PCAPNG file, decodes every frame into metadata and returns a
pandas DataFrame with one row per packet. Higher-level analysers (DNS, HTTP,
TCP, ...) all work on this DataFrame.

Two reading engines are available:
    * ``builtin`` (default) - the streaming reader in ``pcap_reader.py``.
      No external dependencies, tolerant of truncated/corrupt files.
    * ``scapy``   - uses Scapy's ``PcapReader`` to load frames, then the same
      decoders. Useful for unusual link types. Falls back to ``builtin``
      automatically if Scapy is missing or fails.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import pandas as pd

from analyzer.decoders import decode_frame, empty_record
from analyzer.pcap_reader import CaptureReadError, CaptureReader, Frame
from config import DEFAULT_MAX_PACKETS
from utils.validators import validate_capture_file

ProgressCallback = Callable[[int], None]

PACKET_COLUMNS = list(empty_record().keys())


@dataclass
class ParseResult:
    """Output of :func:`parse_capture`."""
    packets: pd.DataFrame
    file_name: str
    file_path: str
    file_size: int
    file_format: str | None
    engine: str
    warnings: list[str] = field(default_factory=list)
    truncated: bool = False
    limit_reached: bool = False
    malformed_count: int = 0
    parse_seconds: float = 0.0
    linktypes: list[int] = field(default_factory=list)

    @property
    def packet_count(self) -> int:
        return len(self.packets)


def _empty_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=PACKET_COLUMNS)


def _frames_builtin(path: Path, max_packets: int, meta: dict):
    reader = CaptureReader(path, max_packets=max_packets)
    meta["reader"] = reader
    yield from reader


def _frames_scapy(path: Path, max_packets: int, meta: dict):
    """Read frames through Scapy (optional engine)."""
    from scapy.config import conf          # imported lazily: Scapy is optional here
    from scapy.utils import PcapReader

    index = 0
    with PcapReader(str(path)) as reader:
        for pkt in reader:
            if index >= max_packets:
                meta["limit_reached"] = True
                break
            index += 1
            linktype = conf.l2types.layer2num.get(type(pkt), 1)
            raw = bytes(pkt)
            yield Frame(index, float(pkt.time), linktype, raw, int(getattr(pkt, "wirelen", None) or len(raw)))


def parse_capture(path: str | Path, max_packets: int = DEFAULT_MAX_PACKETS, engine: str = "builtin",
                  progress: ProgressCallback | None = None, display_name: str | None = None) -> ParseResult:
    """
    Parse a capture file into a packet DataFrame.

    Raises ``ValueError`` with a friendly message if the file is not a valid
    capture file. Malformed individual packets never raise - they are flagged
    in the ``malformed`` column instead.
    """
    path = Path(path)
    check = validate_capture_file(path)
    if not check.ok:
        raise ValueError(check.message)

    start = time.perf_counter()
    meta: dict = {}
    warnings: list[str] = []
    used_engine = engine
    records: list[dict] = []

    def run(frames):
        for frame in frames:
            rec = empty_record()
            rec["no"] = frame.index
            rec["timestamp"] = frame.timestamp
            rec["length"] = frame.orig_len
            decode_frame(frame.data, frame.linktype, rec)
            records.append(rec)
            if progress and frame.index % 5000 == 0:
                progress(frame.index)

    try:
        if engine == "scapy":
            try:
                run(_frames_scapy(path, max_packets, meta))
            except Exception as exc:   # noqa: BLE001 - any Scapy failure -> fallback
                warnings.append(f"Scapy engine unavailable ({exc.__class__.__name__}); used built-in reader.")
                records.clear()
                used_engine = "builtin"
                run(_frames_builtin(path, max_packets, meta))
        else:
            run(_frames_builtin(path, max_packets, meta))
    except CaptureReadError as exc:
        raise ValueError(str(exc)) from exc

    reader = meta.get("reader")
    truncated = bool(reader and reader.truncated)
    limit_reached = bool(meta.get("limit_reached") or (reader and reader.limit_reached))
    if reader:
        warnings.extend(reader.warnings)
    if limit_reached and not any("limit" in w.lower() for w in warnings):
        warnings.append(f"Packet limit of {max_packets:,} reached - remaining packets were not analysed.")

    df = pd.DataFrame.from_records(records, columns=PACKET_COLUMNS) if records else _empty_frame()
    if not df.empty:
        df["timestamp"] = df["timestamp"].astype(float)
        t0 = df["timestamp"].min()
        df["time_rel"] = (df["timestamp"] - t0).round(6)
        df["datetime"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
        for col in ("src_port", "dst_port", "ip_version", "ttl", "ip_proto", "icmp_type", "icmp_code",
                    "http_status", "dns_answer_count"):
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")
    else:
        df["time_rel"] = pd.Series(dtype=float)
        df["datetime"] = pd.Series(dtype="datetime64[ns, UTC]")
        if not warnings:
            warnings.append("The capture file contains no packets.")

    malformed = int(df["malformed"].sum()) if not df.empty else 0
    if malformed:
        warnings.append(f"{malformed} packet(s) were malformed or truncated; their available fields were kept.")

    return ParseResult(
        packets=df,
        file_name=display_name or path.name,
        file_path=str(path),
        file_size=check.size_bytes,
        file_format=check.file_format,
        engine=used_engine,
        warnings=warnings,
        truncated=truncated,
        limit_reached=limit_reached,
        malformed_count=malformed,
        parse_seconds=round(time.perf_counter() - start, 3),
        linktypes=sorted(reader.linktypes) if reader else [],
    )
