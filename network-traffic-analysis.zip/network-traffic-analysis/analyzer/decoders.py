"""
Protocol decoders: turn raw frame bytes into a flat dictionary of metadata.

Layers handled: Ethernet (+VLAN), Linux cooked capture (SLL/SLL2), BSD/Npcap
loopback, raw IP, ARP, IPv4, IPv6, TCP, UDP, ICMP, ICMPv6, DNS, HTTP/1.x and
TLS handshakes (ClientHello / ServerHello) plus QUIC detection.

Privacy rules applied here (see section 18 of the project brief):
    * Packet payloads are NEVER stored - only header metadata.
    * HTTP URLs are stored without their query string (it may hold tokens).
    * Cookie / Authorization headers are ignored completely.
    * Encrypted TLS/QUIC data is not inspected - only the clear-text
      handshake metadata (version, SNI) that any network device can see.

Every decoder is defensive: a short or malformed packet sets
``malformed=True`` instead of raising an exception.
"""

from __future__ import annotations

import ipaddress
import struct

from config import DNS_PORTS, HTTP_PORTS, TLS_PORTS

# ---------------------------------------------------------------------------
# Lookup tables
# ---------------------------------------------------------------------------
ETH_IPV4, ETH_IPV6, ETH_ARP, ETH_VLAN, ETH_QINQ = 0x0800, 0x86DD, 0x0806, 0x8100, 0x88A8

DNS_TYPES = {1: "A", 2: "NS", 5: "CNAME", 6: "SOA", 12: "PTR", 15: "MX", 16: "TXT",
             28: "AAAA", 33: "SRV", 64: "SVCB", 65: "HTTPS", 255: "ANY"}
DNS_RCODES = {0: "NOERROR", 1: "FORMERR", 2: "SERVFAIL", 3: "NXDOMAIN", 4: "NOTIMP", 5: "REFUSED"}

TLS_VERSIONS = {0x0300: "SSL 3.0", 0x0301: "TLS 1.0", 0x0302: "TLS 1.1",
                0x0303: "TLS 1.2", 0x0304: "TLS 1.3"}

ICMP_TYPES = {0: "Echo Reply", 3: "Destination Unreachable", 5: "Redirect", 8: "Echo Request",
              11: "Time Exceeded", 12: "Parameter Problem", 13: "Timestamp", 14: "Timestamp Reply"}
ICMP6_TYPES = {1: "Destination Unreachable", 2: "Packet Too Big", 3: "Time Exceeded",
               128: "Echo Request", 129: "Echo Reply", 133: "Router Solicitation",
               134: "Router Advertisement", 135: "Neighbor Solicitation", 136: "Neighbor Advertisement"}

HTTP_METHODS = (b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ", b"OPTIONS ", b"PATCH ", b"CONNECT ", b"TRACE ")

IP_PROTO_NAMES = {1: "ICMP", 2: "IGMP", 6: "TCP", 17: "UDP", 47: "GRE", 50: "ESP", 58: "ICMPv6", 132: "SCTP"}


def empty_record() -> dict:
    """All fields a decoded packet can have. Missing information stays None."""
    return {
        "no": None, "timestamp": None, "length": 0, "captured_length": 0,
        "src_mac": None, "dst_mac": None,
        "ip_version": None, "src_ip": None, "dst_ip": None, "ttl": None, "ip_proto": None,
        "transport": None, "src_port": None, "dst_port": None,
        "protocol": "Other", "app_protocol": None,
        "tcp_flags": None, "flag_syn": False, "flag_ack": False, "flag_fin": False,
        "flag_rst": False, "flag_psh": False,
        "tcp_seq": None, "tcp_ack": None, "tcp_window": None, "payload_len": 0,
        "is_retransmission": False,
        "dns_id": None, "dns_is_response": None, "dns_qname": None, "dns_qtype": None,
        "dns_rcode": None, "dns_answer_count": None, "dns_answers": None,
        "http_method": None, "http_host": None, "http_uri": None, "http_user_agent": None,
        "http_status": None, "http_version": None,
        "tls_handshake": None, "tls_version": None, "tls_sni": None, "tls_record_version": None,
        "icmp_type": None, "icmp_code": None, "icmp_desc": None,
        "arp_op": None, "arp_sender_ip": None, "arp_target_ip": None,
        "info": "", "malformed": False,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def decode_frame(data: bytes, linktype: int, rec: dict | None = None) -> dict:
    """Decode a frame starting at the link layer. Never raises."""
    rec = rec if rec is not None else empty_record()
    rec["captured_length"] = len(data)
    try:
        if linktype == 1:                                  # Ethernet
            _decode_ethernet(data, rec)
        elif linktype in (101, 12, 14):                    # raw IP
            _decode_ip_auto(data, rec)
        elif linktype == 228:                              # raw IPv4
            _decode_ipv4(data, rec)
        elif linktype == 229:                              # raw IPv6
            _decode_ipv6(data, rec)
        elif linktype == 0 or linktype == 108:             # BSD / Npcap loopback
            if len(data) < 4:
                raise ValueError("loopback header too short")
            _decode_ip_auto(data[4:], rec)
        elif linktype == 113:                              # Linux cooked capture v1
            if len(data) < 16:
                raise ValueError("SLL header too short")
            _dispatch_ethertype(struct.unpack("!H", data[14:16])[0], data[16:], rec)
        elif linktype == 276:                              # Linux cooked capture v2
            if len(data) < 20:
                raise ValueError("SLL2 header too short")
            _dispatch_ethertype(struct.unpack("!H", data[0:2])[0], data[20:], rec)
        else:
            rec["info"] = f"Unsupported link type {linktype}"
    except (struct.error, IndexError, ValueError) as exc:
        rec["malformed"] = True
        rec["info"] = (rec["info"] + f" [malformed: {exc}]").strip()
    _classify(rec)
    return rec


# ---------------------------------------------------------------------------
# Link layer
# ---------------------------------------------------------------------------
def _mac(b: bytes) -> str:
    return ":".join(f"{x:02x}" for x in b)


def _decode_ethernet(data: bytes, rec: dict) -> None:
    if len(data) < 14:
        raise ValueError("Ethernet header too short")
    rec["dst_mac"], rec["src_mac"] = _mac(data[0:6]), _mac(data[6:12])
    ethertype = struct.unpack("!H", data[12:14])[0]
    offset = 14
    while ethertype in (ETH_VLAN, ETH_QINQ):              # skip 802.1Q tags
        if len(data) < offset + 4:
            raise ValueError("VLAN header too short")
        ethertype = struct.unpack("!H", data[offset + 2:offset + 4])[0]
        offset += 4
    _dispatch_ethertype(ethertype, data[offset:], rec)


def _dispatch_ethertype(ethertype: int, payload: bytes, rec: dict) -> None:
    if ethertype == ETH_IPV4:
        _decode_ipv4(payload, rec)
    elif ethertype == ETH_IPV6:
        _decode_ipv6(payload, rec)
    elif ethertype == ETH_ARP:
        _decode_arp(payload, rec)
    else:
        rec["info"] = f"EtherType 0x{ethertype:04x}"


def _decode_ip_auto(data: bytes, rec: dict) -> None:
    if not data:
        raise ValueError("empty IP packet")
    version = data[0] >> 4
    if version == 4:
        _decode_ipv4(data, rec)
    elif version == 6:
        _decode_ipv6(data, rec)
    else:
        raise ValueError(f"unknown IP version {version}")


def _decode_arp(data: bytes, rec: dict) -> None:
    if len(data) < 28:
        raise ValueError("ARP packet too short")
    op = struct.unpack("!H", data[6:8])[0]
    sender_ip = str(ipaddress.IPv4Address(data[14:18]))
    target_ip = str(ipaddress.IPv4Address(data[24:28]))
    rec["arp_op"] = "request" if op == 1 else "reply" if op == 2 else str(op)
    rec["arp_sender_ip"], rec["arp_target_ip"] = sender_ip, target_ip
    rec["transport"] = "ARP"
    rec["info"] = (f"Who has {target_ip}? Tell {sender_ip}" if op == 1
                   else f"{sender_ip} is at {_mac(data[8:14])}")


# ---------------------------------------------------------------------------
# Network layer
# ---------------------------------------------------------------------------
def _decode_ipv4(data: bytes, rec: dict) -> None:
    if len(data) < 20:
        raise ValueError("IPv4 header too short")
    ihl = (data[0] & 0x0F) * 4
    if ihl < 20 or len(data) < ihl:
        raise ValueError("invalid IPv4 header length")
    total_len = struct.unpack("!H", data[2:4])[0]
    frag = struct.unpack("!H", data[6:8])[0]
    rec["ip_version"] = 4
    rec["ttl"] = data[8]
    rec["ip_proto"] = data[9]
    rec["src_ip"] = str(ipaddress.IPv4Address(data[12:16]))
    rec["dst_ip"] = str(ipaddress.IPv4Address(data[16:20]))
    end = total_len if ihl <= total_len <= len(data) else len(data)   # strip Ethernet padding
    payload = data[ihl:end]
    if frag & 0x1FFF:          # non-first fragment: no transport header inside
        rec["transport"] = IP_PROTO_NAMES.get(data[9], str(data[9]))
        rec["info"] = "IP fragment"
        return
    _decode_transport(data[9], payload, rec)


def _decode_ipv6(data: bytes, rec: dict) -> None:
    if len(data) < 40:
        raise ValueError("IPv6 header too short")
    payload_len = struct.unpack("!H", data[4:6])[0]
    next_header = data[6]
    rec["ip_version"] = 6
    rec["ttl"] = data[7]
    rec["src_ip"] = str(ipaddress.IPv6Address(data[8:24]))
    rec["dst_ip"] = str(ipaddress.IPv6Address(data[24:40]))
    payload = data[40:40 + payload_len] if payload_len else data[40:]
    # Walk common extension headers (hop-by-hop, routing, destination options, fragment)
    for _ in range(8):
        if next_header in (0, 43, 60) and len(payload) >= 8:
            nh, hlen = payload[0], (payload[1] + 1) * 8
            next_header, payload = nh, payload[hlen:]
        elif next_header == 44 and len(payload) >= 8:
            nh = payload[0]
            frag_off = struct.unpack("!H", payload[2:4])[0] >> 3
            next_header, payload = nh, payload[8:]
            if frag_off:
                rec["ip_proto"] = next_header
                rec["info"] = "IPv6 fragment"
                return
        else:
            break
    rec["ip_proto"] = next_header
    _decode_transport(next_header, payload, rec)


# ---------------------------------------------------------------------------
# Transport layer
# ---------------------------------------------------------------------------
def _decode_transport(proto: int, payload: bytes, rec: dict) -> None:
    if proto == 6:
        _decode_tcp(payload, rec)
    elif proto == 17:
        _decode_udp(payload, rec)
    elif proto == 1:
        _decode_icmp(payload, rec, v6=False)
    elif proto == 58:
        _decode_icmp(payload, rec, v6=True)
    else:
        rec["transport"] = IP_PROTO_NAMES.get(proto, f"IP proto {proto}")
        rec["info"] = rec["transport"]


def _decode_tcp(seg: bytes, rec: dict) -> None:
    if len(seg) < 20:
        raise ValueError("TCP header too short")
    sport, dport, seq, ack, off_flags, window = struct.unpack("!HHIIHH", seg[:16])
    data_off = (off_flags >> 12) * 4
    flags = off_flags & 0x01FF
    rec.update(transport="TCP", src_port=sport, dst_port=dport, tcp_seq=seq, tcp_ack=ack, tcp_window=window)
    names = []
    for bit, name in ((0x02, "SYN"), (0x10, "ACK"), (0x01, "FIN"), (0x04, "RST"), (0x08, "PSH"), (0x20, "URG")):
        if flags & bit:
            names.append(name)
    rec["tcp_flags"] = ",".join(names) if names else "NONE"
    rec["flag_syn"], rec["flag_ack"] = bool(flags & 0x02), bool(flags & 0x10)
    rec["flag_fin"], rec["flag_rst"], rec["flag_psh"] = bool(flags & 0x01), bool(flags & 0x04), bool(flags & 0x08)
    if data_off < 20:
        raise ValueError("invalid TCP data offset")
    payload = seg[data_off:] if len(seg) >= data_off else b""
    rec["payload_len"] = len(payload)
    rec["info"] = f"{sport} → {dport} [{rec['tcp_flags']}] Seq={seq} Len={len(payload)}"

    if not payload:
        return
    ports = {sport, dport}
    if ports & DNS_PORTS and len(payload) > 14:
        _decode_dns(payload[2:], rec)                     # DNS over TCP has a 2-byte length
    elif payload.startswith(HTTP_METHODS) or payload.startswith(b"HTTP/1."):
        _decode_http(payload, rec)
    elif payload[0] in (20, 21, 22, 23) and len(payload) >= 5 and payload[1] == 3:
        _decode_tls(payload, rec)


def _decode_udp(dgram: bytes, rec: dict) -> None:
    if len(dgram) < 8:
        raise ValueError("UDP header too short")
    sport, dport, length = struct.unpack("!HHH", dgram[:6])
    payload = dgram[8:length] if 8 <= length <= len(dgram) else dgram[8:]
    rec.update(transport="UDP", src_port=sport, dst_port=dport, payload_len=len(payload))
    rec["info"] = f"{sport} → {dport} Len={len(payload)}"
    if {sport, dport} & DNS_PORTS and len(payload) >= 12:
        _decode_dns(payload, rec)
    elif 443 in (sport, dport) and payload:
        # QUIC (HTTP/3) is encrypted UDP; only note that it is QUIC.
        rec["app_protocol"] = "QUIC"
        rec["tls_version"] = "QUIC"
        rec["info"] = f"QUIC (encrypted) {sport} → {dport} Len={len(payload)}"


def _decode_icmp(data: bytes, rec: dict, v6: bool) -> None:
    if len(data) < 4:
        raise ValueError("ICMP header too short")
    itype, code = data[0], data[1]
    rec["transport"] = "ICMPv6" if v6 else "ICMP"
    rec["icmp_type"], rec["icmp_code"] = itype, code
    table = ICMP6_TYPES if v6 else ICMP_TYPES
    rec["icmp_desc"] = table.get(itype, f"Type {itype}")
    rec["payload_len"] = max(len(data) - 8, 0)
    rec["info"] = f"{rec['transport']} {rec['icmp_desc']} (code {code})"


# ---------------------------------------------------------------------------
# Application layer
# ---------------------------------------------------------------------------
def _read_dns_name(msg: bytes, offset: int, depth: int = 0) -> tuple[str, int]:
    """Read a (possibly compressed) DNS name. Returns (name, offset after name)."""
    labels, jumped, end_offset = [], False, offset
    for _ in range(128):                       # hard loop limit = no infinite loops
        if offset >= len(msg):
            raise ValueError("DNS name runs past end of packet")
        length = msg[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0 == 0xC0:              # compression pointer
            if offset + 1 >= len(msg) or depth > 10:
                raise ValueError("bad DNS compression pointer")
            pointer = ((length & 0x3F) << 8) | msg[offset + 1]
            if not jumped:
                end_offset = offset + 2
            jumped = True
            offset = pointer
            depth += 1
            continue
        offset += 1
        labels.append(msg[offset:offset + length].decode("ascii", errors="replace"))
        offset += length
    name = ".".join(labels)
    return name, (end_offset if jumped else offset)


def _decode_dns(msg: bytes, rec: dict) -> None:
    if len(msg) < 12:
        return
    try:
        txid, flags, qd, an, _ns, _ar = struct.unpack("!HHHHHH", msg[:12])
        rec["app_protocol"] = "DNS"
        rec["dns_id"] = txid
        rec["dns_is_response"] = bool(flags & 0x8000)
        rec["dns_rcode"] = DNS_RCODES.get(flags & 0x000F, str(flags & 0x000F))
        rec["dns_answer_count"] = an
        offset = 12
        if qd:
            name, offset = _read_dns_name(msg, offset)
            qtype = struct.unpack("!H", msg[offset:offset + 2])[0]
            offset += 4
            rec["dns_qname"] = name.lower()
            rec["dns_qtype"] = DNS_TYPES.get(qtype, str(qtype))
            for _ in range(qd - 1):            # skip any further questions
                _, offset = _read_dns_name(msg, offset)
                offset += 4
        answers = []
        if rec["dns_is_response"]:
            for _ in range(min(an, 20)):
                _, offset = _read_dns_name(msg, offset)
                rtype, _cls, _ttl, rdlen = struct.unpack("!HHIH", msg[offset:offset + 10])
                offset += 10
                rdata = msg[offset:offset + rdlen]
                tname = DNS_TYPES.get(rtype, str(rtype))
                if rtype == 1 and rdlen == 4:
                    answers.append(f"A {ipaddress.IPv4Address(rdata)}")
                elif rtype == 28 and rdlen == 16:
                    answers.append(f"AAAA {ipaddress.IPv6Address(rdata)}")
                elif rtype in (2, 5, 12):
                    answers.append(f"{tname} {_read_dns_name(msg, offset)[0]}")
                elif rtype == 15 and rdlen > 2:
                    answers.append(f"MX {_read_dns_name(msg, offset + 2)[0]}")
                elif rtype == 16:
                    answers.append(f"TXT ({rdlen} bytes)")       # content not stored
                else:
                    answers.append(tname)
                offset += rdlen
        rec["dns_answers"] = "; ".join(answers) if answers else None
        kind = "response" if rec["dns_is_response"] else "query"
        rec["info"] = f"DNS {kind} {rec['dns_qtype'] or ''} {rec['dns_qname'] or ''}".strip()
        if rec["dns_is_response"]:
            rec["info"] += f" → {rec['dns_rcode']}"
    except (struct.error, ValueError, IndexError):
        rec["malformed"] = True
        rec["info"] = "Malformed DNS message"


def _decode_http(payload: bytes, rec: dict) -> None:
    head = payload.split(b"\r\n\r\n", 1)[0][:4096]
    lines = head.split(b"\r\n")
    first = lines[0].decode("latin-1", errors="replace")
    rec["app_protocol"] = "HTTP"
    if first.startswith("HTTP/1."):
        parts = first.split(" ", 2)
        rec["http_version"] = parts[0]
        if len(parts) > 1 and parts[1].isdigit():
            rec["http_status"] = int(parts[1])
        rec["info"] = f"HTTP response {first[:60]}"
    else:
        parts = first.split(" ")
        rec["http_method"] = parts[0]
        if len(parts) > 1:
            rec["http_uri"] = parts[1].split("?", 1)[0][:200]   # query string dropped for privacy
        if len(parts) > 2:
            rec["http_version"] = parts[2]
        rec["info"] = f"HTTP {rec['http_method']} {rec['http_uri'] or ''}"
    for line in lines[1:40]:
        if b":" not in line:
            continue
        key, value = line.split(b":", 1)
        key = key.strip().lower()
        if key == b"host":
            rec["http_host"] = value.strip().decode("latin-1", errors="replace")[:200]
        elif key == b"user-agent":
            rec["http_user_agent"] = value.strip().decode("latin-1", errors="replace")[:200]
        # Cookie, Authorization etc. are deliberately ignored.


def _decode_tls(payload: bytes, rec: dict) -> None:
    """Read the clear-text TLS record/handshake header. Encrypted data is never touched."""
    content_type = payload[0]
    rec_version = struct.unpack("!H", payload[1:3])[0]
    rec["app_protocol"] = "TLS"
    rec["tls_record_version"] = TLS_VERSIONS.get(rec_version, hex(rec_version))
    names = {20: "ChangeCipherSpec", 21: "Alert", 22: "Handshake", 23: "Application Data (encrypted)"}
    rec["info"] = f"TLS {names.get(content_type, content_type)}"
    if content_type != 22 or len(payload) < 9:
        return
    hs_type = payload[5]
    body = payload[9:]
    if hs_type not in (1, 2) or len(body) < 38:
        return
    try:
        legacy_version = struct.unpack("!H", body[0:2])[0]
        pos = 2 + 32                                        # version + random
        sid_len = body[pos]
        pos += 1 + sid_len
        if hs_type == 1:                                    # ClientHello
            cs_len = struct.unpack("!H", body[pos:pos + 2])[0]
            pos += 2 + cs_len
            comp_len = body[pos]
            pos += 1 + comp_len
        else:                                               # ServerHello
            pos += 2 + 1
        version = legacy_version
        sni = None
        if pos + 2 <= len(body):
            ext_total = struct.unpack("!H", body[pos:pos + 2])[0]
            pos += 2
            end = min(pos + ext_total, len(body))
            while pos + 4 <= end:
                etype, elen = struct.unpack("!HH", body[pos:pos + 4])
                edata = body[pos + 4:pos + 4 + elen]
                if etype == 0 and len(edata) >= 5:          # server_name
                    name_len = struct.unpack("!H", edata[3:5])[0]
                    sni = edata[5:5 + name_len].decode("ascii", errors="replace")
                elif etype == 43 and edata:                 # supported_versions
                    if hs_type == 1:
                        vers = [struct.unpack("!H", edata[i:i + 2])[0] for i in range(1, 1 + edata[0], 2)
                                if i + 2 <= len(edata)]
                        known = [v for v in vers if v in TLS_VERSIONS]
                        if known:
                            version = max(known)
                    elif len(edata) >= 2:
                        version = struct.unpack("!H", edata[:2])[0]
                pos += 4 + elen
        rec["tls_handshake"] = "ClientHello" if hs_type == 1 else "ServerHello"
        rec["tls_version"] = TLS_VERSIONS.get(version, hex(version))
        rec["tls_sni"] = sni
        label = "max offered" if hs_type == 1 else "negotiated"
        rec["info"] = f"TLS {rec['tls_handshake']} {rec['tls_version']} ({label})" + (f" SNI={sni}" if sni else "")
    except (struct.error, IndexError):
        rec["info"] = "TLS handshake (partially captured)"


# ---------------------------------------------------------------------------
# Final classification
# ---------------------------------------------------------------------------
def _classify(rec: dict) -> None:
    """Assign one of: DNS, HTTP, HTTPS/TLS, TCP, UDP, ICMP, ARP, Other."""
    transport = rec["transport"]
    app = rec["app_protocol"]
    ports = {rec["src_port"], rec["dst_port"]}
    if transport == "ARP":
        rec["protocol"] = "ARP"
    elif transport in ("ICMP", "ICMPv6"):
        rec["protocol"] = "ICMP"
    elif app == "DNS" or (transport == "UDP" and ports & DNS_PORTS):
        rec["protocol"] = "DNS"
    elif app == "HTTP":
        rec["protocol"] = "HTTP"
    elif app in ("TLS", "QUIC"):
        rec["protocol"] = "HTTPS/TLS"
    elif transport == "TCP" and ports & TLS_PORTS and rec["payload_len"] > 0:
        rec["protocol"] = "HTTPS/TLS"                     # encrypted continuation segments
    elif transport == "TCP":
        rec["protocol"] = "TCP"
    elif transport == "UDP":
        rec["protocol"] = "UDP"
    else:
        rec["protocol"] = "Other"


__all__ = ["decode_frame", "empty_record", "HTTP_PORTS"]
