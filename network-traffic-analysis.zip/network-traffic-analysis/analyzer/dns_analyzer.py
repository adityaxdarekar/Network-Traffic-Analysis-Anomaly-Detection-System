"""
DNS analysis: queries, responses, failures, repeated requests and transparent
"worth a look" heuristics for domain names.

The heuristics below only describe *properties* of a name (long, random
looking, many sub-domains ...). Plenty of legitimate services (CDNs, cloud
telemetry, anti-virus look-ups) have such names, so nothing here labels a
domain as malicious.
"""

from __future__ import annotations

import re

import pandas as pd

from utils.helpers import registered_domain, shannon_entropy

FAILED_RCODES = {"NXDOMAIN", "SERVFAIL", "REFUSED", "FORMERR", "NOTIMP"}
TRACKED_QTYPES = ["A", "AAAA", "MX", "TXT", "CNAME", "NS"]


def domain_heuristics(name: str, thresholds: dict) -> list[str]:
    """Return human-readable reasons why a domain name stands out (may be empty)."""
    reasons = []
    if not name:
        return reasons
    base = registered_domain(name)
    sub = name[: -len(base)].rstrip(".") if base and name.endswith(base) else ""
    labels = name.split(".")
    longest = max((len(x) for x in labels), default=0)
    if len(name) >= thresholds.get("dns_tunnel_query_length", 52):
        reasons.append(f"long name ({len(name)} chars)")
    if longest >= thresholds.get("dns_tunnel_label_length", 40):
        reasons.append(f"very long label ({longest} chars)")
    sub_clean = sub.replace(".", "")
    if len(sub_clean) >= 12 and shannon_entropy(sub_clean) >= thresholds.get("dns_tunnel_entropy", 3.8):
        reasons.append(f"random-looking sub-domain (entropy {shannon_entropy(sub_clean):.2f})")
    digits = sum(ch.isdigit() for ch in sub_clean)
    if len(sub_clean) >= 12 and digits / len(sub_clean) > 0.4:
        reasons.append("sub-domain is mostly digits")
    if len(labels) >= 7:
        reasons.append(f"many labels ({len(labels)})")
    if re.search(r"[0-9a-f]{24,}", sub_clean):
        reasons.append("long hex-like string")
    return reasons


def analyze_dns(df: pd.DataFrame, thresholds: dict, top_n: int = 10) -> dict:
    dns = df[df["dns_qname"].notna()] if not df.empty else df
    if dns.empty:
        return {"query_count": 0, "response_count": 0, "queries": pd.DataFrame(), "responses": pd.DataFrame(),
                "top_domains": pd.DataFrame(columns=["domain", "queries"]), "qtype_counts": {},
                "rcode_counts": {}, "failed_count": 0, "failed": pd.DataFrame(),
                "repeated": pd.DataFrame(columns=["domain", "queries"]),
                "per_host": pd.DataFrame(columns=["src_ip", "queries", "unique_domains"]),
                "unanswered_count": 0, "unusual_domains": pd.DataFrame(columns=["domain", "queries", "reasons"]),
                "subdomain_diversity": pd.DataFrame(columns=["base_domain", "unique_subdomains", "queries"]),
                "avg_response_ms": None}

    queries = dns[dns["dns_is_response"] == False]   # noqa: E712 - pandas boolean mask
    responses = dns[dns["dns_is_response"] == True]  # noqa: E712

    q_cols = ["no", "datetime", "src_ip", "dst_ip", "dns_qname", "dns_qtype", "dns_id"]
    r_cols = ["no", "datetime", "src_ip", "dst_ip", "dns_qname", "dns_qtype", "dns_rcode", "dns_answer_count",
              "dns_answers"]

    top = queries["dns_qname"].value_counts().head(top_n)
    qtype_counts = queries["dns_qtype"].value_counts().to_dict()
    for t in TRACKED_QTYPES:
        qtype_counts.setdefault(t, 0)
    rcode_counts = responses["dns_rcode"].value_counts().to_dict()
    failed = responses[responses["dns_rcode"].isin(FAILED_RCODES)]

    counts = queries["dns_qname"].value_counts()
    repeated = counts[counts >= 5]

    per_host = (queries.groupby("src_ip").agg(queries=("no", "size"), unique_domains=("dns_qname", "nunique"))
                .reset_index().sort_values("queries", ascending=False))

    # Match responses to queries (same transaction id, client and name) for latency & unanswered count
    q_key = queries.assign(client=queries["src_ip"])[["client", "dns_id", "dns_qname", "timestamp"]]
    r_key = responses.assign(client=responses["dst_ip"])[["client", "dns_id", "dns_qname", "timestamp"]]
    merged = q_key.merge(r_key, on=["client", "dns_id", "dns_qname"], how="left", suffixes=("_q", "_r"))
    merged = merged.drop_duplicates(subset=["client", "dns_id", "dns_qname", "timestamp_q"])
    unanswered = int(merged["timestamp_r"].isna().sum())
    latency = (merged["timestamp_r"] - merged["timestamp_q"]).dropna()
    latency = latency[(latency >= 0) & (latency < 10)]
    avg_ms = round(float(latency.mean()) * 1000, 2) if not latency.empty else None

    unusual_rows = []
    for name, n in counts.items():
        reasons = domain_heuristics(name, thresholds)
        if reasons:
            unusual_rows.append({"domain": name, "queries": int(n), "reasons": "; ".join(reasons)})
    unusual = pd.DataFrame(unusual_rows, columns=["domain", "queries", "reasons"])

    qn = queries[["dns_qname"]].copy()
    qn["base_domain"] = qn["dns_qname"].map(registered_domain)
    diversity = (qn.groupby("base_domain").agg(unique_subdomains=("dns_qname", "nunique"),
                                               queries=("dns_qname", "size"))
                 .reset_index().sort_values("unique_subdomains", ascending=False))

    return {
        "query_count": len(queries),
        "response_count": len(responses),
        "queries": queries[q_cols].reset_index(drop=True),
        "responses": responses[r_cols].reset_index(drop=True),
        "top_domains": pd.DataFrame({"domain": top.index, "queries": top.values}),
        "qtype_counts": qtype_counts,
        "rcode_counts": rcode_counts,
        "failed_count": len(failed),
        "failed": failed[r_cols].reset_index(drop=True),
        "repeated": pd.DataFrame({"domain": repeated.index, "queries": repeated.values}),
        "per_host": per_host.reset_index(drop=True),
        "unanswered_count": unanswered,
        "unusual_domains": unusual,
        "subdomain_diversity": diversity.reset_index(drop=True),
        "avg_response_ms": avg_ms,
    }
