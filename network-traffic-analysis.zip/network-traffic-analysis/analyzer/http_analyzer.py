"""
Clear-text HTTP analysis (HTTP/1.x only).

Only metadata is used: method, host, path (query string removed), status
code and User-Agent. Request/response bodies, cookies and authorization
headers are never stored.
"""

from __future__ import annotations

import pandas as pd


def analyze_http(df: pd.DataFrame, top_n: int = 10) -> dict:
    http = df[df["protocol"] == "HTTP"] if not df.empty else df
    req_cols = ["no", "datetime", "src_ip", "dst_ip", "dst_port", "http_method", "http_host", "http_uri",
                "http_user_agent"]
    resp_cols = ["no", "datetime", "src_ip", "dst_ip", "src_port", "http_status", "http_version"]
    if http.empty:
        return {"request_count": 0, "response_count": 0, "requests": pd.DataFrame(columns=req_cols),
                "responses": pd.DataFrame(columns=resp_cols), "method_counts": {}, "status_counts": {},
                "top_hosts": pd.DataFrame(columns=["host", "requests"]),
                "user_agents": pd.DataFrame(columns=["user_agent", "requests"]),
                "requests_per_minute": pd.DataFrame(columns=["minute", "requests"]),
                "error_responses": 0}

    requests = http[http["http_method"].notna()]
    responses = http[http["http_status"].notna()]
    hosts = requests["http_host"].fillna("(no Host header)").value_counts().head(top_n)
    agents = requests["http_user_agent"].dropna().value_counts().head(top_n)
    if not requests.empty:
        per_min = requests.set_index("datetime").resample("1min").size()
        per_min = pd.DataFrame({"minute": per_min.index, "requests": per_min.values})
    else:
        per_min = pd.DataFrame(columns=["minute", "requests"])
    status_counts = {int(k): int(v) for k, v in responses["http_status"].value_counts().items()}
    return {
        "request_count": len(requests),
        "response_count": len(responses),
        "requests": requests[req_cols].reset_index(drop=True),
        "responses": responses[resp_cols].reset_index(drop=True),
        "method_counts": requests["http_method"].value_counts().to_dict(),
        "status_counts": status_counts,
        "top_hosts": pd.DataFrame({"host": hosts.index, "requests": hosts.values}),
        "user_agents": pd.DataFrame({"user_agent": agents.index, "requests": agents.values}),
        "requests_per_minute": per_min,
        "error_responses": int((responses["http_status"] >= 400).sum()),
    }
