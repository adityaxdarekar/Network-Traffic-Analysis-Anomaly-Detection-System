"""
Streaming reader for PCAP and PCAPNG capture files.

Why a built-in reader?
    * It streams packets one at a time, so very large captures do not need
      to fit in memory.
    * It never crashes on truncated or corrupted files - problems are recorded
      in ``reader.warnings`` and reading stops cleanly.
    * It has no third-party dependency, so the analysis engine and the unit
      tests run even on a machine without Wireshark.

Scapy's reader can be used instead (``engine="scapy"`` in
:func:`analyzer.packet_analyzer.analyze_capture`).

File format references: the libpcap file format and the PCAPNG
specification (IETF draft-ietf-opsawg-pcapng).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from utils.validators import PCAPNG_MAGIC, detect_format


@dataclass
class Frame:
    """One captured frame exactly as stored in the file."""
    index: int          # 1-based packet number
    timestamp: float    # UNIX epoch seconds
    linktype: int       # link-layer header type (1 = Ethernet ...)
    data: bytes         # captured bytes (may be shorter than orig_len)
    orig_len: int       # original length on the wire


class CaptureReadError(Exception):
    """Raised when a file cannot be read at all (e.g. not a capture file)."""


class CaptureReader:
    """Iterate over frames in a .pcap or .pcapng file.

    Example::

        reader = CaptureReader("traffic.pcapng")
        for frame in reader:
            print(frame.index, frame.timestamp, len(frame.data))
        print(reader.warnings)
    """

    def __init__(self, path: str | Path, max_packets: int | None = None):
        self.path = Path(path)
        self.max_packets = max_packets
        self.warnings: list[str] = []
        self.file_format: str | None = None
        self.linktypes: set[int] = set()
        self.truncated = False
        self.limit_reached = False

        with open(self.path, "rb") as fh:
            header = fh.read(4)
        self.file_format = detect_format(header)
        if self.file_format is None:
            raise CaptureReadError("Not a PCAP/PCAPNG file (unknown magic number).")

    # ------------------------------------------------------------------
    def __iter__(self) -> Iterator[Frame]:
        gen = self._iter_pcap() if self.file_format == "pcap" else self._iter_pcapng()
        count = 0
        for frame in gen:
            if self.max_packets and count >= self.max_packets:
                self.limit_reached = True
                self.warnings.append(
                    f"Packet limit of {self.max_packets:,} reached - remaining packets were not analysed."
                )
                break
            count += 1
            yield frame

    # ------------------------------------------------------------------
    # Classic libpcap format
    # ------------------------------------------------------------------
    def _iter_pcap(self) -> Iterator[Frame]:
        with open(self.path, "rb") as fh:
            gh = fh.read(24)
            if len(gh) < 24:
                self.truncated = True
                self.warnings.append("PCAP global header is truncated - no packets could be read.")
                return
            magic = gh[:4]
            if magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"):
                endian = "<"
            else:
                endian = ">"
            nano = magic in (b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d")
            divisor = 1e9 if nano else 1e6
            _vmaj, _vmin, _zone, _sig, snaplen, linktype = struct.unpack(endian + "HHiIII", gh[4:24])
            linktype &= 0xFFFF
            self.linktypes.add(linktype)

            index = 0
            while True:
                rh = fh.read(16)
                if not rh:
                    return
                if len(rh) < 16:
                    self.truncated = True
                    self.warnings.append(f"File ends in the middle of record header after packet {index}.")
                    return
                ts_sec, ts_frac, incl_len, orig_len = struct.unpack(endian + "IIII", rh)
                # Sanity check: a corrupt length would make us read garbage.
                if incl_len > max(snaplen, 262144) or incl_len > 16 * 1024 * 1024:
                    self.truncated = True
                    self.warnings.append(f"Corrupt record length ({incl_len}) after packet {index}; stopping.")
                    return
                data = fh.read(incl_len)
                if len(data) < incl_len:
                    self.truncated = True
                    self.warnings.append(f"Packet {index + 1} is cut short (incomplete capture); stopping.")
                    return
                index += 1
                yield Frame(index, ts_sec + ts_frac / divisor, linktype, data, orig_len or incl_len)

    # ------------------------------------------------------------------
    # PCAPNG format
    # ------------------------------------------------------------------
    def _iter_pcapng(self) -> Iterator[Frame]:
        endian = "<"
        interfaces: list[tuple[int, float]] = []   # (linktype, ts_resolution)
        index = 0
        with open(self.path, "rb") as fh:
            while True:
                head = fh.read(8)
                if not head:
                    return
                if len(head) < 8:
                    self.truncated = True
                    self.warnings.append("File ends inside a PCAPNG block header.")
                    return

                if head[:4] == PCAPNG_MAGIC:
                    # Section Header Block: byte-order magic tells us endianness.
                    bom = fh.read(4)
                    if len(bom) < 4:
                        self.truncated = True
                        self.warnings.append("Section header block is truncated.")
                        return
                    if bom == b"\x4d\x3c\x2b\x1a":
                        endian = "<"
                    elif bom == b"\x1a\x2b\x3c\x4d":
                        endian = ">"
                    else:
                        self.warnings.append("Invalid PCAPNG byte-order magic; stopping.")
                        return
                    block_len = struct.unpack(endian + "I", head[4:8])[0]
                    if block_len < 28 or block_len % 4:
                        self.warnings.append("Invalid section header length; stopping.")
                        return
                    rest = fh.read(block_len - 12)
                    if len(rest) < block_len - 12:
                        self.truncated = True
                        return
                    interfaces = []          # a new section resets interface IDs
                    continue

                block_type, block_len = struct.unpack(endian + "II", head)
                if block_len < 12 or block_len % 4 or block_len > 64 * 1024 * 1024:
                    self.truncated = True
                    self.warnings.append(f"Corrupt PCAPNG block length ({block_len}) after packet {index}; stopping.")
                    return
                body = fh.read(block_len - 8)
                if len(body) < block_len - 8:
                    self.truncated = True
                    self.warnings.append(f"PCAPNG block after packet {index} is cut short; stopping.")
                    return
                body = body[:-4]   # drop the trailing length copy

                try:
                    if block_type == 1:            # Interface Description Block
                        linktype = struct.unpack(endian + "H", body[0:2])[0]
                        resolution = self._parse_tsresol(body[8:], endian)
                        interfaces.append((linktype, resolution))
                        self.linktypes.add(linktype)
                    elif block_type == 6:          # Enhanced Packet Block
                        if_id, ts_hi, ts_lo, cap_len, orig_len = struct.unpack(endian + "IIIII", body[:20])
                        data = body[20:20 + cap_len]
                        linktype, res = interfaces[if_id] if if_id < len(interfaces) else (1, 1e-6)
                        index += 1
                        yield Frame(index, ((ts_hi << 32) | ts_lo) * res, linktype, data, orig_len or cap_len)
                    elif block_type == 3:          # Simple Packet Block (no timestamp)
                        orig_len = struct.unpack(endian + "I", body[:4])[0]
                        data = body[4:4 + orig_len]
                        linktype, _ = interfaces[0] if interfaces else (1, 1e-6)
                        index += 1
                        yield Frame(index, 0.0, linktype, data, orig_len)
                    elif block_type == 2:          # obsolete Packet Block
                        if_id, _drops, ts_hi, ts_lo, cap_len, orig_len = struct.unpack(endian + "HHIIII", body[:20])
                        data = body[20:20 + cap_len]
                        linktype, res = interfaces[if_id] if if_id < len(interfaces) else (1, 1e-6)
                        index += 1
                        yield Frame(index, ((ts_hi << 32) | ts_lo) * res, linktype, data, orig_len or cap_len)
                    # Other block types (statistics, name resolution, custom ...) are ignored.
                except (struct.error, IndexError):
                    self.warnings.append(f"Skipped a malformed PCAPNG block (type {block_type}).")
                    continue

    @staticmethod
    def _parse_tsresol(options: bytes, endian: str) -> float:
        """Find the if_tsresol option (code 9) in an Interface Description Block."""
        pos = 0
        while pos + 4 <= len(options):
            code, length = struct.unpack(endian + "HH", options[pos:pos + 4])
            if code == 0:
                break
            if code == 9 and length >= 1:
                v = options[pos + 4]
                return 2 ** -(v & 0x7F) if v & 0x80 else 10 ** -v
            pos += 4 + length + ((4 - length % 4) % 4)
        return 1e-6
