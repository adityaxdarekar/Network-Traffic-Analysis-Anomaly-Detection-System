"""
Full analysis pipeline:

    capture file → parse/decode → TCP retransmissions → protocol analysers
                 → IP analysis → anomaly detection → AnalysisResult

The dashboard, the PDF report and the database all consume the single
:class:`AnalysisResult` object produced here, so every number shown
anywhere comes from the same real analysis.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import pandas as pd

from analyzer.dns_analyzer import analyze_dns
from analyzer.http_analyzer import analyze_http
from analyzer.ip_analyzer import analyze_ips
from analyzer.packet_analyzer import ParseResult, parse_capture
from analyzer.tcp_analyzer import analyze_tcp, mark_retransmissions
from analyzer.tls_analyzer import analyze_tls
from analyzer.udp_analyzer import analyze_udp
from config import load_settings
from detection.anomaly_detector import AnomalyDetector, severity_counts

PROTOCOL_ORDER = ["DNS", "HTTP", "HTTPS/TLS", "TCP", "UDP", "ICMP", "ARP", "Other"]


@dataclass
class AnalysisResult:
    session_id: str
    analyzed_at: str
    parse: ParseResult
    packets: pd.DataFrame
    summary: dict
    protocol_counts: dict
    timeline: pd.DataFrame
    size_distribution: pd.DataFrame
    dns: dict
    http: dict
    tls: dict
    tcp: dict
    udp: dict
    ip: dict
    alerts: pd.DataFrame
    detection_errors: list[str] = field(default_factory=list)
    detection_notes: list[str] = field(default_factory=list)
    settings: dict = field(default_factory=dict)

    @property
    def file_name(self) -> str:
        return self.parse.file_name


def traffic_timeline(df: pd.DataFrame, max_points: int = 300) -> pd.DataFrame:
    """Packets and bytes per time bucket. Bucket size adapts to the capture length."""
    if df.empty:
        return pd.DataFrame(columns=["time", "packets", "bytes", "bucket_sec"])
    duration = max(df["timestamp"].max() - df["timestamp"].min(), 1e-6)
    candidates = [0.1, 0.5, 1, 2, 5, 10, 30, 60, 300, 600, 1800, 3600, 21600, 86400]
    bucket = next((c for c in candidates if duration / c <= max_points), candidates[-1])
    t0 = df["timestamp"].min()
    b = ((df["timestamp"] - t0) // bucket).astype(int)
    grouped = df.groupby(b).agg(packets=("no", "size"), bytes=("length", "sum"))
    grouped = grouped.reindex(range(int(b.max()) + 1), fill_value=0)
    out = pd.DataFrame({"time": pd.to_datetime(t0 + grouped.index * bucket, unit="s", utc=True),
                        "packets": grouped["packets"].values, "bytes": grouped["bytes"].values})
    out["bucket_sec"] = bucket
    return out


def size_distribution(df: pd.DataFrame) -> pd.DataFrame:
    bins = [0, 64, 128, 256, 512, 1024, 1514, 10**9]
    labels = ["≤64", "65-128", "129-256", "257-512", "513-1024", "1025-1514", ">1514 (jumbo/TSO)"]
    if df.empty:
        return pd.DataFrame({"size_range": labels, "packets": [0] * len(labels)})
    cut = pd.cut(df["length"].astype(int), bins=bins, labels=labels, include_lowest=True)
    counts = cut.value_counts().reindex(labels, fill_value=0)
    return pd.DataFrame({"size_range": labels, "packets": counts.values})


def run_analysis(path: str | Path, settings: dict | None = None, display_name: str | None = None,
                 engine: str = "builtin", progress=None) -> AnalysisResult:
    """Analyse a capture file end-to-end. Raises ValueError for invalid files."""
    settings = settings or load_settings()
    top_n = int(settings.get("dashboard", {}).get("top_n", 10))
    parsed = parse_capture(path, max_packets=int(settings.get("max_packets", 500_000)), engine=engine,
                           progress=progress, display_name=display_name)
    df = mark_retransmissions(parsed.packets)
    thresholds = settings["thresholds"]

    tcp = analyze_tcp(df)
    dns = analyze_dns(df, thresholds, top_n)
    http = analyze_http(df, top_n)
    tls = analyze_tls(df, top_n)
    udp = analyze_udp(df)
    ip = analyze_ips(df, top_n)

    detector = AnomalyDetector(settings)
    alerts = detector.run(df, tcp["connections"])

    proto = df["protocol"].value_counts().to_dict() if not df.empty else {}
    protocol_counts = {p: int(proto.get(p, 0)) for p in PROTOCOL_ORDER}

    duration = float(df["timestamp"].max() - df["timestamp"].min()) if len(df) > 1 else 0.0
    total_bytes = int(df["length"].sum()) if not df.empty else 0
    summary = {
        "file_name": parsed.file_name,
        "file_size": parsed.file_size,
        "file_format": parsed.file_format,
        "total_packets": len(df),
        "total_bytes": total_bytes,
        "start_time": float(df["timestamp"].min()) if not df.empty else None,
        "end_time": float(df["timestamp"].max()) if not df.empty else None,
        "duration_sec": round(duration, 3),
        "avg_packet_size": round(total_bytes / len(df), 1) if len(df) else 0,
        "min_packet_size": int(df["length"].min()) if not df.empty else 0,
        "max_packet_size": int(df["length"].max()) if not df.empty else 0,
        "median_packet_size": float(df["length"].median()) if not df.empty else 0,
        "packets_per_sec": round(len(df) / duration, 2) if duration > 0 else float(len(df)),
        "bytes_per_sec": round(total_bytes / duration, 1) if duration > 0 else float(total_bytes),
        "unique_ips": ip["unique_ips"],
        "dns_queries": dns["query_count"],
        "http_requests": http["request_count"],
        "tcp_connections": len(tcp["connections"]),
        "tcp_packets": tcp["packet_count"],
        "udp_packets": udp["packet_count"],
        "icmp_packets": protocol_counts["ICMP"],
        "tls_packets": tls["packet_count"],
        "alert_count": len(alerts),
        "severity_counts": severity_counts(alerts),
        "malformed_packets": parsed.malformed_count,
        "warnings": parsed.warnings,
        "engine": parsed.engine,
        "parse_seconds": parsed.parse_seconds,
    }
    return AnalysisResult(
        session_id=uuid.uuid4().hex[:12],
        analyzed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        parse=parsed, packets=df, summary=summary, protocol_counts=protocol_counts,
        timeline=traffic_timeline(df), size_distribution=size_distribution(df),
        dns=dns, http=http, tls=tls, tcp=tcp, udp=udp, ip=ip, alerts=alerts,
        detection_errors=detector.errors, detection_notes=detector.notes, settings=settings,
    )
