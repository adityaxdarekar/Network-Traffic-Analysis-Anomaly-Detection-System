"""
OPTIONAL IP reputation lookup - fully offline by default.

To respect the privacy rules of this project, nothing is sent to the
Internet automatically. Two things are offered:

1. A *local* watch-list: put one IP or CIDR per line in
   ``sample_data/local_watchlist.txt`` (lines starting with # are comments,
   anything after a comma is treated as a note). Matches are shown as
   "on your local watch-list" - still not proof of malicious activity.
2. Links to well-known public reputation websites that the *user* can click
   to check an address manually in their browser. No API key is needed and
   no request is made by this application.
"""

from __future__ import annotations

import ipaddress
from pathlib import Path

from config import SAMPLE_DIR
from analyzer.ip_analyzer import classify_ip

WATCHLIST_FILE = SAMPLE_DIR / "local_watchlist.txt"


def load_watchlist(path: Path = WATCHLIST_FILE) -> list[tuple[ipaddress._BaseNetwork, str]]:
    entries = []
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            net, _, note = line.partition(",")
            try:
                entries.append((ipaddress.ip_network(net.strip(), strict=False), note.strip()))
            except ValueError:
                continue
    except OSError:
        pass
    return entries


def lookup(ip: str, watchlist: list | None = None) -> dict:
    """Return local information about an IP. Makes no network requests."""
    category = classify_ip(ip)
    result = {"ip": ip, "category": category, "watchlist_match": False, "watchlist_note": "",
              "external_links": {}}
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        result["category"] = "Invalid"
        return result
    for net, note in (watchlist if watchlist is not None else load_watchlist()):
        if addr.version == net.version and addr in net:
            result["watchlist_match"] = True
            result["watchlist_note"] = note or f"matches {net}"
            break
    if category == "Public":
        result["external_links"] = {
            "AbuseIPDB": f"https://www.abuseipdb.com/check/{ip}",
            "VirusTotal": f"https://www.virustotal.com/gui/ip-address/{ip}",
            "Shodan": f"https://www.shodan.io/host/{ip}",
        }
    return result
