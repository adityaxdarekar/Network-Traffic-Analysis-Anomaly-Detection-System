"""
Central configuration for the Network Traffic Analysis and Anomaly Detection System.

Everything that a user might want to tune (detection thresholds, capture
limits, file-size limits, suspicious ports ...) lives here, so the rest of
the code never contains "magic numbers".

User changes made on the Settings page are saved to ``user_settings.json``
and merged on top of these defaults by :func:`load_settings`.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
SAMPLE_DIR = BASE_DIR / "sample_data"
SCREENSHOT_DIR = BASE_DIR / "screenshots"
CAPTURE_DIR = OUTPUT_DIR / "captures"
UPLOAD_DIR = OUTPUT_DIR / "uploads"
REPORT_DIR = OUTPUT_DIR / "reports"
DB_PATH = OUTPUT_DIR / "analysis_history.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"

for _d in (OUTPUT_DIR, CAPTURE_DIR, UPLOAD_DIR, REPORT_DIR, SCREENSHOT_DIR):
    _d.mkdir(parents=True, exist_ok=True)

APP_TITLE = "Network Traffic Analysis and Anomaly Detection System"
APP_SHORT_TITLE = "NetSentinel SOC"
APP_VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# File handling
# ---------------------------------------------------------------------------
ALLOWED_EXTENSIONS = (".pcap", ".pcapng", ".cap")
MAX_UPLOAD_MB = 500            # files larger than this are rejected
DEFAULT_MAX_PACKETS = 500_000  # analysis stops after this many packets (protects RAM)

# ---------------------------------------------------------------------------
# Well-known ports used for classification
# ---------------------------------------------------------------------------
DNS_PORTS = {53, 5353}
HTTP_PORTS = {80, 8080, 8000, 8008, 8888}
TLS_PORTS = {443, 8443, 993, 995, 465, 636, 853}

# Ports that are not malicious by themselves but often deserve a second look
# in a home / campus network (remote access, legacy clear-text, common
# backdoor/IRC ports). Users can edit this list on the Settings page.
DEFAULT_SUSPICIOUS_PORTS = {
    21: "FTP (clear-text credentials)",
    23: "Telnet (clear-text remote shell)",
    135: "MS-RPC",
    139: "NetBIOS session",
    445: "SMB file sharing",
    1433: "MS-SQL",
    3306: "MySQL",
    3389: "RDP remote desktop",
    4444: "Common reverse-shell / Metasploit default",
    5900: "VNC remote desktop",
    6667: "IRC (historic botnet C2 channel)",
    31337: "Historic backdoor port",
}

# ---------------------------------------------------------------------------
# Detection thresholds (all configurable on the Settings page)
# ---------------------------------------------------------------------------
DEFAULT_THRESHOLDS = {
    # Rule 1 - port scan
    "port_scan_unique_ports": 20,       # distinct dst ports from one src to one dst
    "port_scan_window_sec": 60,
    # Rule 2 - SYN flood pattern
    "syn_flood_syn_count": 100,         # SYNs to one destination inside window
    "syn_flood_window_sec": 10,
    "syn_flood_incomplete_ratio": 0.8,  # share of SYNs never answered by SYN-ACK
    # Rule 3 - DNS query anomaly
    "dns_queries_per_host": 200,        # total DNS queries by one host
    "dns_unique_domains_per_host": 100,
    "dns_window_sec": 60,
    "dns_queries_per_window": 60,       # queries by one host inside the window
    # Rule 4 - repeated connection attempts
    "repeated_conn_attempts": 15,       # SYNs to same dst ip:port
    "repeated_conn_failure_ratio": 0.5,
    # Rule 5 - traffic volume
    "volume_baseline_multiplier": 5.0,  # host bytes > N x median host bytes
    "volume_min_bytes": 5_000_000,      # ...and at least this many bytes
    "volume_spike_multiplier": 5.0,     # per-second volume > N x median second
    "volume_spike_min_packets": 100,
    # Rule 7 - ICMP
    "icmp_packets_per_host": 50,
    "icmp_window_sec": 10,
    # Rule 8 - TCP retransmissions
    "retransmission_rate": 0.10,        # 10 %
    "retransmission_min_packets": 50,
    # Rule 9 - DNS tunnelling indicators
    "dns_tunnel_query_length": 52,      # characters in full query name
    "dns_tunnel_label_length": 40,      # longest single label
    "dns_tunnel_subdomains_per_domain": 30,
    "dns_tunnel_entropy": 3.8,          # Shannon entropy of the sub-domain part
    # Rule 10 - unusual external communication
    "external_unique_ports_per_host": 50,
    "external_bytes_per_destination": 50_000_000,
}

# Rule 10: optional allow-list / watch-list of external networks (CIDR strings)
DEFAULT_EXTERNAL_RULES = {
    "allowed_external_networks": [],   # e.g. ["8.8.8.0/24"] - never alert on these
    "watched_external_networks": [],   # e.g. ["203.0.113.0/24"] - always alert
    "allowed_external_ports": [53, 80, 123, 443, 853, 993, 995, 587, 465, 5223, 3478, 19302],
}

# Base severity for each rule. Severity is raised automatically when the
# observed value is far above the threshold (3x -> +1 level, 10x -> +2 levels).
# Rules can be switched off on the Settings page.
RULE_NAMES = {
    "R1": "Possible Port Scanning",
    "R2": "Possible SYN Flood Pattern",
    "R3": "DNS Query Anomaly",
    "R4": "Repeated Connection Attempts",
    "R5": "Unusual Traffic Volume",
    "R6": "Unusual Destination Port",
    "R7": "ICMP Traffic Anomaly",
    "R8": "High TCP Retransmission Rate",
    "R9": "Possible DNS Tunneling Indicators",
    "R10": "Unusual External Communication",
}
DEFAULT_RULE_SEVERITY = {
    "R1": "Medium", "R2": "High", "R3": "Low", "R4": "Low", "R5": "Low",
    "R6": "Low", "R7": "Low", "R8": "Low", "R9": "Medium", "R10": "Low",
}
DEFAULT_RULES_ENABLED = {rule: True for rule in RULE_NAMES}
MAX_ALERTS_PER_RULE = 50

DEFAULT_CAPTURE = {
    "duration_sec": 30,
    "packet_limit": 5000,
    "max_duration_sec": 600,
    "output_format": "pcapng",
}

DEFAULT_DASHBOARD = {
    "top_n": 10,
    "explorer_page_size": 500,
    "mask_ip_addresses": False,   # privacy option for screenshots/demos
    "show_dns_responses": True,
}

SEVERITY_ORDER = ["Low", "Medium", "High", "Critical"]
SEVERITY_COLORS = {
    "Low": "#38bdf8",
    "Medium": "#facc15",
    "High": "#fb923c",
    "Critical": "#ef4444",
}


def default_settings() -> dict:
    """Return a fresh copy of all default settings."""
    return {
        "thresholds": copy.deepcopy(DEFAULT_THRESHOLDS),
        "suspicious_ports": {str(k): v for k, v in DEFAULT_SUSPICIOUS_PORTS.items()},
        "external_rules": copy.deepcopy(DEFAULT_EXTERNAL_RULES),
        "rule_severity": copy.deepcopy(DEFAULT_RULE_SEVERITY),
        "rules_enabled": copy.deepcopy(DEFAULT_RULES_ENABLED),
        "capture": copy.deepcopy(DEFAULT_CAPTURE),
        "dashboard": copy.deepcopy(DEFAULT_DASHBOARD),
        "max_packets": DEFAULT_MAX_PACKETS,
    }


def load_settings(path: Path | None = None) -> dict:
    """Load user settings, falling back to defaults for anything missing/broken."""
    settings = default_settings()
    path = path or SETTINGS_FILE
    try:
        if path.exists():
            stored = json.loads(path.read_text(encoding="utf-8"))
            for key, value in stored.items():
                if isinstance(value, dict) and isinstance(settings.get(key), dict):
                    settings[key].update(value)
                elif key in settings:
                    settings[key] = value
    except (OSError, ValueError):
        # A corrupt settings file must never stop the app - use defaults.
        pass
    return settings


def save_settings(settings: dict, path: Path | None = None) -> None:
    """Persist settings as pretty JSON."""
    path = path or SETTINGS_FILE
    path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
