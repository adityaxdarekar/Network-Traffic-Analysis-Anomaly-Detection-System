"""Anomaly Detection page."""

from __future__ import annotations

import html

import pandas as pd
import streamlit as st

from config import SEVERITY_ORDER
from dashboard.common import (bar, csv_button, get_settings, kpi_row, page_header, require_result, severity_badge,
                              severity_donut, show_table)
from detection.detection_rules import describe_rules
from utils.helpers import mask_ip


def render() -> None:
    page_header("Anomaly Detection", "Transparent rule-based alerts - heuristic indicators, not confirmed attacks")
    r = require_result()
    a = r.alerts
    sev = r.summary["severity_counts"]
    kpi_row([("Total alerts", len(a), "", "alert" if len(a) else "accent"),
             ("Critical", sev["Critical"], "", "alert" if sev["Critical"] else "accent"),
             ("High", sev["High"], "", "alert" if sev["High"] else "accent"),
             ("Medium", sev["Medium"]), ("Low", sev["Low"])])
    for msg in r.detection_errors:
        st.error(msg)
    for msg in r.detection_notes:
        st.info(msg)

    with st.expander("How detection works (rules and thresholds)"):
        st.markdown("Each rule compares what was observed with a configurable threshold (Settings page). Severity "
                    "starts at the rule's base level and rises one level at 3× the threshold and two levels at 10×.")
        show_table(pd.DataFrame(describe_rules()))

    if a.empty:
        st.success("No detection rule exceeded its threshold for this capture. That does not prove the traffic is "
                   "benign - only that none of the configured heuristics matched.")
        return

    c1, c2 = st.columns(2)
    with c1:
        severity_donut(sev)
    with c2:
        by_rule = a["detection"].value_counts()
        bar(pd.DataFrame({"detection": by_rule.index, "alerts": by_rule.values}), "detection", "alerts",
            "Alerts by detection", horizontal=True, color="#fb923c")

    f1, f2, f3 = st.columns([1, 1.5, 1])
    sev_f = f1.multiselect("Severity", SEVERITY_ORDER[::-1], key="al_sev")
    det_f = f2.multiselect("Detection category", sorted(a["detection"].unique()), key="al_det")
    ip_f = f3.text_input("IP contains", key="al_ip")
    view = a
    if sev_f:
        view = view[view["severity"].isin(sev_f)]
    if det_f:
        view = view[view["detection"].isin(det_f)]
    if ip_f:
        view = view[view["src_ip"].fillna("").str.contains(ip_f, regex=False) |
                    view["dst_ip"].fillna("").str.contains(ip_f, regex=False)]

    st.markdown(f"**{len(view)} alert(s)**")
    show_table(view[["alert_id", "severity", "detection", "category", "src_ip", "dst_ip", "port", "event_count",
                     "time_range"]], height=300)
    csv_button(a, "alerts.csv")

    st.markdown("### Alert details")
    mask = get_settings()["dashboard"].get("mask_ip_addresses")
    show = (lambda v: mask_ip(v) if isinstance(v, str) else "-") if mask else (lambda v: v if isinstance(v, str) else "-")
    for row in view.head(60).itertuples():
        port = "-" if pd.isna(row.port) else int(row.port)
        with st.expander(f"{row.alert_id} · {row.severity} · {row.detection} · {show(row.src_ip)} → {show(row.dst_ip)}"):
            st.markdown(f"{severity_badge(row.severity)} &nbsp; <b>{html.escape(row.detection)}</b> "
                        f"<span class='muted'>({html.escape(row.category)}, rule {row.rule_id})</span>",
                        unsafe_allow_html=True)
            c1, c2, c3, c4 = st.columns(4)
            c1.markdown(f"**Source**  \n{show(row.src_ip)}")
            c2.markdown(f"**Destination**  \n{show(row.dst_ip)}")
            c3.markdown(f"**Port**  \n{port}")
            c4.markdown(f"**Events observed**  \n{row.event_count}")
            st.markdown(f"**Time range:** {row.time_range}")
            st.markdown(f"**Why this was flagged:** {row.reason}")
            if row.evidence:
                st.markdown(f"**Evidence:** {row.evidence}")
            st.info(f"**Recommended investigation:** {row.recommendation}")
    if len(view) > 60:
        st.caption("Showing the first 60 alerts; download the CSV for all of them.")
