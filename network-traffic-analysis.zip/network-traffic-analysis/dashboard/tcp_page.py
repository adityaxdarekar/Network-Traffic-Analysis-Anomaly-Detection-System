"""TCP / UDP Analysis page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import bar, csv_button, donut, kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("TCP / UDP Analysis", "Flags, connections, retransmissions and port usage")
    r = require_result()
    tcp, udp = r.tcp, r.udp
    kpi_row([("TCP packets", f"{tcp['packet_count']:,}"), ("TCP conversations", len(tcp["connections"])),
             ("Connection attempts", tcp["connection_attempts"], "SYN packets"),
             ("Completed handshakes", tcp["completed_handshakes"]),
             ("Failed connections", len(tcp["failed_connections"]), "no reply / RST",
              "alert" if len(tcp["failed_connections"]) else "accent"),
             ("Retransmissions", tcp["retransmissions"], f"{tcp['retransmission_rate']:.1%} of TCP"),
             ("UDP packets", f"{udp['packet_count']:,}", f"{udp['dns_packets']} DNS")])

    tab_tcp, tab_udp, tab_lim = st.tabs(["TCP", "UDP", "Limitations"])
    with tab_tcp:
        if tcp["packet_count"] == 0:
            st.info("No TCP traffic in this capture.")
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                fc = tcp["flag_counts"]
                bar(pd.DataFrame({"flag": list(fc), "packets": list(fc.values())}), "flag", "packets", "TCP flags")
            with c2:
                sc = tcp["state_counts"]
                donut(list(sc.keys()), list(sc.values()), "Connection states")
            with c3:
                ports = tcp["top_dst_ports"].assign(port=lambda d: d["port"].astype(str))
                bar(ports, "port", "packets", "Most used destination ports", horizontal=True, color="#22d3ee")
            st.markdown("**TCP conversations**")
            state = st.multiselect("Filter by state", sorted(tcp["connections"]["state"].unique()), key="tcp_state")
            conns = tcp["connections"]
            if state:
                conns = conns[conns["state"].isin(state)]
            show_table(conns.drop(columns=["start", "end"]), height=360)
            csv_button(tcp["connections"], "tcp_connections.csv")
            st.markdown("**Failed / unanswered connections**")
            show_table(tcp["failed_connections"].drop(columns=["start", "end"]),
                       empty_msg="Every captured connection attempt was answered.")
            if tcp["retransmissions"]:
                st.markdown("**Retransmitted segments**")
                show_table(r.packets[r.packets["is_retransmission"]][["no", "datetime", "src_ip", "src_port", "dst_ip",
                                                                     "dst_port", "tcp_seq", "payload_len", "info"]],
                           height=260)
    with tab_udp:
        if udp["packet_count"] == 0:
            st.info("No UDP traffic in this capture.")
        else:
            c1, c2 = st.columns(2)
            with c1:
                d = udp["top_dst_ports"].assign(label=lambda x: x["port"].astype(str) + " " + x["service"])
                bar(d[["label", "packets"]], "label", "packets", "UDP destination ports", horizontal=True)
            with c2:
                d = udp["top_src_ports"].assign(port=lambda x: x["port"].astype(str))
                bar(d, "port", "packets", "UDP source ports", horizontal=True, color="#22d3ee")
            st.markdown("**UDP communications** (source → destination:port, with frequency)")
            show_table(udp["conversations"].drop(columns=["first_seen", "last_seen"]), height=360)
            csv_button(udp["conversations"], "udp_conversations.csv")
    with tab_lim:
        st.markdown("Packet captures only show what the capturing machine saw. Keep these limits in mind:")
        for line in tcp["limitations"]:
            st.markdown(f"- {line}")
