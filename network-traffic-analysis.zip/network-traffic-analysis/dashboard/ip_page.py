"""IP Investigation page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from analyzer.ip_reputation import load_watchlist, lookup
from dashboard.common import bar, csv_button, donut, kpi_row, page_header, require_result, show_table
from utils.helpers import human_bytes, ts_to_str
from utils.validators import is_valid_ip


def render() -> None:
    page_header("IP Investigation", "Who talked to whom, how much, and what kind of address it is")
    r = require_result()
    ip = r.ip
    cats = ip["category_counts"]
    kpi_row([("Unique IPs", ip["unique_ips"]), ("Private", cats.get("Private", 0)),
             ("Public", cats.get("Public", 0)), ("Multicast/broadcast", cats.get("Multicast", 0) + cats.get("Broadcast", 0)),
             ("Other special", sum(v for k, v in cats.items() if k not in ("Private", "Public", "Multicast", "Broadcast")),
              "loopback, link-local, reserved...")])
    st.caption("Address categories describe the *type* of address only. Public or unfamiliar addresses are not "
               "treated as malicious. 'Documentation' = reserved example ranges such as 203.0.113.0/24.")

    c1, c2, c3 = st.columns([1, 1.2, 1.2])
    with c1:
        donut(list(cats.keys()), list(cats.values()), "Address categories")
    with c2:
        bar(ip["top_sources"][["ip", "packets_sent"]], "ip", "packets_sent", "Top sources", horizontal=True)
    with c3:
        bar(ip["top_destinations"][["ip", "packets_received"]], "ip", "packets_received", "Top destinations",
            horizontal=True, color="#22d3ee")

    st.markdown("**All hosts**")
    f1, f2 = st.columns([2, 1])
    query = f1.text_input("Filter by IP address (partial match)", key="ip_filter", placeholder="e.g. 192.168.1.")
    cat_filter = f2.multiselect("Category", sorted(cats.keys()), key="ip_cat")
    hosts = ip["hosts"]
    if query:
        hosts = hosts[hosts["ip"].str.contains(query.strip(), regex=False)]
    if cat_filter:
        hosts = hosts[hosts["category"].isin(cat_filter)]
    view = hosts.assign(data=hosts["total_bytes"].map(human_bytes),
                        first_seen=hosts["first_seen"].map(ts_to_str), last_seen=hosts["last_seen"].map(ts_to_str))
    show_table(view, height=360)
    csv_button(ip["hosts"], "ip_hosts.csv")

    st.markdown("**Most frequent conversations**")
    show_table(ip["conversations"].head(100), height=300)
    if ip["patterns"]:
        st.markdown("**Communication patterns worth reviewing**")
        show_table(pd.DataFrame(ip["patterns"]))

    st.divider()
    st.subheader("Investigate one address")
    options = ip["hosts"]["ip"].tolist()
    target = st.selectbox("Select an IP from this capture", options, key="ip_target") if options else None
    if target and is_valid_ip(target):
        row = ip["hosts"][ip["hosts"]["ip"] == target].iloc[0]
        kpi_row([("Category", row["category"]), ("Packets sent", f"{row['packets_sent']:,}"),
                 ("Packets received", f"{row['packets_received']:,}"), ("Data", human_bytes(row["total_bytes"])),
                 ("Peers", row["unique_peers"])])
        pk = r.packets
        mine = pk[(pk["src_ip"] == target) | (pk["dst_ip"] == target)]
        peers = pd.concat([mine.loc[mine["src_ip"] == target, "dst_ip"], mine.loc[mine["dst_ip"] == target, "src_ip"]])
        c1, c2 = st.columns(2)
        with c1:
            vc = peers.value_counts().head(10)
            bar(pd.DataFrame({"peer": vc.index, "packets": vc.values}), "peer", "packets", "Top peers", horizontal=True)
        with c2:
            vc = mine["protocol"].value_counts()
            donut(list(vc.index), list(vc.values), "Protocols used")
        related = r.alerts[(r.alerts["src_ip"] == target) | (r.alerts["dst_ip"] == target)] if not r.alerts.empty else r.alerts
        if not related.empty:
            st.warning(f"{len(related)} alert(s) involve this address.")
            show_table(related[["alert_id", "severity", "detection", "src_ip", "dst_ip", "port", "event_count"]])

        st.markdown("**Optional reputation check (offline)**")
        info = lookup(target, load_watchlist())
        if info["watchlist_match"]:
            st.warning(f"On your local watch-list: {info['watchlist_note']}. This is a note you configured, "
                       "not proof of malicious activity.")
        else:
            st.caption("Not on the local watch-list (sample_data/local_watchlist.txt).")
        if info["external_links"]:
            st.caption("Nothing is sent to the Internet automatically. If you choose, open one of these public "
                       "reputation sites in your browser to check the address manually:")
            st.markdown(" · ".join(f"[{name}]({url})" for name, url in info["external_links"].items()))
        else:
            st.caption("Non-public address - Internet reputation services have no information about it.")
