"""Settings page: thresholds, rules, severities, ports, external rules, capture and dashboard preferences."""

from __future__ import annotations

import streamlit as st

from config import (DEFAULT_CAPTURE, RULE_NAMES, SEVERITY_ORDER, default_settings, save_settings)
from dashboard.actions import rerun_detection
from dashboard.common import get_result, get_settings, page_header
from utils.validators import parse_cidr_list, parse_port_list

THRESHOLD_GROUPS = {
    "R1": ["port_scan_unique_ports", "port_scan_window_sec"],
    "R2": ["syn_flood_syn_count", "syn_flood_window_sec", "syn_flood_incomplete_ratio"],
    "R3": ["dns_queries_per_host", "dns_unique_domains_per_host", "dns_window_sec", "dns_queries_per_window"],
    "R4": ["repeated_conn_attempts", "repeated_conn_failure_ratio"],
    "R5": ["volume_baseline_multiplier", "volume_min_bytes", "volume_spike_multiplier", "volume_spike_min_packets"],
    "R6": [],
    "R7": ["icmp_packets_per_host", "icmp_window_sec"],
    "R8": ["retransmission_rate", "retransmission_min_packets"],
    "R9": ["dns_tunnel_query_length", "dns_tunnel_label_length", "dns_tunnel_subdomains_per_domain",
           "dns_tunnel_entropy"],
    "R10": ["external_unique_ports_per_host", "external_bytes_per_destination"],
}


def render() -> None:
    page_header("Settings", "Tune detection to your network's normal behaviour")
    settings = get_settings()
    new = {k: (dict(v) if isinstance(v, dict) else v) for k, v in settings.items()}

    st.subheader("Detection rules, severity and thresholds")
    st.caption("Lower thresholds = more sensitive (more alerts, more false positives). Raise them if normal "
               "activity on your network is being flagged.")
    for rid, keys in THRESHOLD_GROUPS.items():
        with st.expander(f"{rid} · {RULE_NAMES[rid]}"):
            c1, c2 = st.columns(2)
            new["rules_enabled"][rid] = c1.toggle("Enabled", value=settings["rules_enabled"].get(rid, True),
                                                  key=f"en_{rid}")
            new["rule_severity"][rid] = c2.selectbox("Base severity", SEVERITY_ORDER,
                                                     index=SEVERITY_ORDER.index(settings["rule_severity"].get(rid, "Low")),
                                                     key=f"sev_{rid}")
            cols = st.columns(2)
            for i, key in enumerate(keys):
                value = settings["thresholds"][key]
                label = key.replace("_", " ")
                if isinstance(value, float):
                    new["thresholds"][key] = cols[i % 2].number_input(label, min_value=0.0, value=float(value),
                                                                      step=0.05 if value < 1 else 0.5, key=f"th_{key}")
                else:
                    new["thresholds"][key] = int(cols[i % 2].number_input(label, min_value=1, value=int(value),
                                                                          step=1, key=f"th_{key}"))
            if rid == "R6":
                text = "\n".join(f"{p}: {d}" for p, d in settings["suspicious_ports"].items())
                edited = st.text_area("Ports worth investigating (one per line, 'port: description')", text,
                                      height=220, key="susp_ports")
                ports, bad = {}, []
                for line in edited.splitlines():
                    port, _, desc = line.partition(":")
                    if port.strip().isdigit() and 0 < int(port) < 65536:
                        ports[str(int(port))] = desc.strip() or "custom"
                    elif line.strip():
                        bad.append(line)
                if bad:
                    st.error(f"Ignored invalid lines: {bad}")
                new["suspicious_ports"] = ports
            if rid == "R10":
                ext = settings["external_rules"]
                allowed, bad1 = parse_cidr_list(st.text_area(
                    "Allowed external networks (never alert), CIDR, comma/newline separated",
                    "\n".join(ext["allowed_external_networks"]), key="ext_allowed"))
                watched, bad2 = parse_cidr_list(st.text_area(
                    "Watched external networks (always alert), e.g. 203.0.113.0/24",
                    "\n".join(ext["watched_external_networks"]), key="ext_watched"))
                aports, bad3 = parse_port_list(st.text_input(
                    "Allowed external destination ports", ", ".join(map(str, ext["allowed_external_ports"])),
                    key="ext_ports"))
                for bad in (bad1, bad2, bad3):
                    if bad:
                        st.error(f"Ignored invalid entries: {bad}")
                new["external_rules"] = {"allowed_external_networks": allowed, "watched_external_networks": watched,
                                         "allowed_external_ports": aports}

    st.subheader("Live capture defaults")
    c1, c2, c3 = st.columns(3)
    new["capture"]["duration_sec"] = int(c1.number_input("Default duration (s)", 1, DEFAULT_CAPTURE["max_duration_sec"],
                                                         int(settings["capture"]["duration_sec"])))
    new["capture"]["packet_limit"] = int(c2.number_input("Default packet limit (0 = none)", 0, 10_000_000,
                                                         int(settings["capture"]["packet_limit"])))
    new["capture"]["output_format"] = c3.selectbox("Default format", ["pcapng", "pcap"],
                                                   index=0 if settings["capture"]["output_format"] == "pcapng" else 1)
    new["max_packets"] = int(st.number_input("Maximum packets to analyse per file (protects memory on large captures)",
                                             1000, 20_000_000, int(settings["max_packets"]), step=50_000))

    st.subheader("Dashboard preferences")
    c1, c2, c3 = st.columns(3)
    new["dashboard"]["top_n"] = int(c1.number_input("Items in 'top' charts", 3, 50, int(settings["dashboard"]["top_n"])))
    new["dashboard"]["explorer_page_size"] = int(c2.number_input("Packet Explorer rows", 50, 20_000,
                                                                 int(settings["dashboard"]["explorer_page_size"])))
    new["dashboard"]["mask_ip_addresses"] = c3.toggle("Mask IP addresses (for screenshots/demos)",
                                                      value=bool(settings["dashboard"]["mask_ip_addresses"]))

    b1, b2, b3 = st.columns(3)
    if b1.button("💾 Save settings", type="primary"):
        st.session_state["settings"] = new
        save_settings(new)
        if get_result() is not None:
            rerun_detection()
            st.success("Settings saved and detection re-run on the loaded capture "
                       "('top' chart sizes apply to the next analysis).")
        else:
            st.success("Settings saved.")
    if b2.button("↺ Reset to defaults"):
        st.session_state["settings"] = default_settings()
        save_settings(st.session_state["settings"])
        for key in list(st.session_state.keys()):
            if key.startswith(("th_", "en_", "sev_", "ext_", "susp_")):
                del st.session_state[key]
        st.rerun()
    b3.caption("Settings are stored in user_settings.json in the project folder.")
