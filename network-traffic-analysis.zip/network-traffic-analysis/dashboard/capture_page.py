"""Live Capture page."""

from __future__ import annotations

import time
from pathlib import Path

import streamlit as st

from capture.interface_manager import capture_capabilities, list_interfaces
from capture.packet_capture import CaptureError, CaptureSession
from config import DEFAULT_CAPTURE
from dashboard.actions import analyze_file
from dashboard.common import get_settings, go_to, page_header


@st.cache_data(ttl=60, show_spinner=False)
def _capabilities():
    return capture_capabilities()


@st.cache_data(ttl=60, show_spinner=False)
def _interfaces():
    return list_interfaces()


def render() -> None:
    page_header("Live Capture", "Record traffic from a network interface with TShark (or Scapy)")
    st.warning("⚠️ **Only capture traffic on networks and devices you own or have explicit permission to "
               "monitor.** Captures can contain personal data. Files are stored only on this computer in "
               "`output/captures/`.")

    caps = _capabilities()
    with st.expander("Capture environment", expanded=not caps["can_capture"]):
        st.markdown(f"- Operating system: **{caps['platform']}**\n"
                    f"- TShark: **{caps['tshark_version'] or 'not found'}** {('(' + caps['tshark_path'] + ')') if caps['tshark_path'] else ''}\n"
                    f"- Scapy: **{'installed' if caps['scapy_available'] else 'not installed'}**\n"
                    f"- Npcap: **{ {True: 'installed', False: 'NOT found', None: 'n/a (not Windows)'}[caps['npcap_installed']] }**\n"
                    f"- Running as administrator/root: **{'yes' if caps['is_admin'] else 'no'}**")
        if st.button("Re-check environment"):
            _capabilities.clear()
            _interfaces.clear()
            st.rerun()

    if not caps["can_capture"]:
        st.error("Live capture is not available: install Wireshark (with TShark and Npcap), see README section "
                 "'Wireshark installation'. You can still use every other feature with the **Upload PCAP** page.")
        return

    session: CaptureSession | None = st.session_state.get("capture_session")
    running = bool(session and session.is_running())

    interfaces, err = _interfaces()
    if not interfaces:
        st.error(f"No network interfaces could be listed. {err or ''}")
        return
    cfg = get_settings()["capture"]
    labels = {f"{i['description']}  [{i['name']}]": i["id"] for i in interfaces}
    c1, c2 = st.columns([2, 1])
    iface_label = c1.selectbox("Network interface", list(labels), disabled=running)
    fmt = c2.selectbox("Save format", ["pcapng", "pcap"], index=0 if cfg.get("output_format") == "pcapng" else 1,
                       disabled=running)
    c3, c4, c5 = st.columns(3)
    duration = c3.number_input("Duration (seconds)", 1, DEFAULT_CAPTURE["max_duration_sec"],
                               int(cfg.get("duration_sec", 30)), disabled=running)
    limit = c4.number_input("Packet limit (0 = no limit)", 0, 10_000_000, int(cfg.get("packet_limit", 5000)),
                            disabled=running)
    bpf = c5.text_input("Capture filter (optional, BPF)", placeholder="e.g. port 53 or tcp", disabled=running)
    consent = st.checkbox("I own this network/device or have explicit permission to monitor it.", disabled=running)

    b1, b2, _ = st.columns([1, 1, 3])
    if b1.button("▶ Start capture", type="primary", disabled=running or not consent):
        session = CaptureSession()
        try:
            session.start(labels[iface_label], duration=duration, packet_limit=limit, output_format=fmt,
                          bpf_filter=bpf.strip())
            st.session_state["capture_session"] = session
            st.rerun()
        except CaptureError as exc:
            st.error(f"❌ {exc}")
    if b2.button("■ Stop capture", disabled=not running):
        session.stop()
        st.rerun()

    if session is None:
        st.info("Status: idle. Choose an interface, tick the permission box and press Start.")
        return

    status = session.status()
    if status["running"]:
        st.progress(min(status["elapsed_sec"] / max(status["duration_sec"], 1), 1.0),
                    text=f"🔴 Capturing with {status['engine']}... {status['elapsed_sec']:.0f}/{status['duration_sec']} s")
    else:
        st.success("Capture finished." if not status["error"] else "Capture stopped.")
    m1, m2, m3 = st.columns(3)
    m1.metric("Status", "Running" if status["running"] else "Stopped")
    m2.metric("Packets captured", f"{status['packets']:,}")
    m3.metric("Elapsed", f"{status['elapsed_sec']:.0f} s")
    if status["output_file"]:
        st.caption(f"Saved to: `{status['output_file']}`")
    if status["error"]:
        st.error(status["error"])

    if status["running"]:
        time.sleep(1)                    # simple auto-refresh while capturing
        st.rerun()
    elif status["output_file"] and Path(status["output_file"]).exists() and status["packets"] > 0:
        if st.button("🔍 Analyse this capture", type="primary"):
            if analyze_file(status["output_file"], display_name=Path(status["output_file"]).name):
                go_to("Overview")
    elif status["output_file"]:
        st.info("No packets were captured. Check that the interface carries traffic (e.g. open a web page).")
