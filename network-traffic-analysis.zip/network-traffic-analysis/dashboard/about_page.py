"""About Project page."""

from __future__ import annotations

import streamlit as st

from config import APP_TITLE, APP_VERSION
from dashboard.common import page_header

ARCHITECTURE = """
Network interface ──► TShark / Scapy capture ──► .pcap / .pcapng
                                                    │
                                     Packet analysis engine (decoders)
                                       │                         │
                          Protocol analysis               IP analysis
                    (DNS · HTTP · TLS · TCP · UDP)   (source / destination)
                                       └──────────┬──────────────┘
                                         Anomaly detection (10 rules)
                                                  │
                                       SQLite database (history)
                                                  │
                                         Streamlit dashboard
                                                  │
                                       PDF report generator
"""


def render() -> None:
    page_header("About Project", APP_TITLE)
    st.markdown(f"""
**{APP_TITLE}** (version {APP_VERSION}) is a defensive, educational SOC-style tool. It analyses packet
captures, classifies traffic, extracts DNS / HTTP / TLS / TCP / UDP / IP metadata, applies ten transparent
detection rules and produces dashboards, CSV exports and PDF reports.
""")
    st.code(ARCHITECTURE, language=None)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("""
**Technology**
- Python 3.11+, pandas
- Wireshark / TShark / Npcap for capture, Scapy as fallback
- Built-in PCAP/PCAPNG reader and protocol decoders
- Streamlit + Plotly dashboard
- ReportLab + Matplotlib PDF reports
- SQLite history database
""")
    with c2:
        st.markdown("""
**Privacy and ethics by design**
- Everything runs locally; captures are never sent anywhere
- Payloads are not stored; HTTP query strings and cookies are dropped
- HTTPS is never decrypted - only visible handshake metadata is used
- Alerts are heuristic indicators, never "confirmed attacks"
- Live capture requires explicit confirmation of permission
""")
    st.info("Only capture and analyse traffic on networks you own or are explicitly authorised to monitor.")
