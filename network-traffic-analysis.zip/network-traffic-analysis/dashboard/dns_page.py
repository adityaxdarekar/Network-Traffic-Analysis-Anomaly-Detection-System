"""DNS Analysis page."""

from __future__ import annotations

import streamlit as st

from dashboard.common import bar, csv_button, donut, kpi_row, page_header, require_result, show_table


def render() -> None:
    page_header("DNS Analysis", "Queries, responses, failures and unusual domain names")
    r = require_result()
    d = r.dns
    kpi_row([("DNS queries", d["query_count"]), ("DNS responses", d["response_count"]),
             ("Failed responses", d["failed_count"], "NXDOMAIN / SERVFAIL / REFUSED"),
             ("Unanswered queries", d["unanswered_count"], "no response captured"),
             ("Avg response time", f"{d['avg_response_ms']} ms" if d["avg_response_ms"] is not None else "-"),
             ("Unusual names", len(d["unusual_domains"]), "heuristic", "alert" if len(d["unusual_domains"]) else "accent")])
    if d["query_count"] == 0:
        st.info("This capture contains no DNS traffic.")
        return

    c1, c2, c3 = st.columns([1.4, 1, 1])
    with c1:
        bar(d["top_domains"], "domain", "queries", "Most requested domains", horizontal=True, color="#818cf8")
    with c2:
        donut(list(d["qtype_counts"].keys()), list(d["qtype_counts"].values()), "Query types")
    with c3:
        donut(list(d["rcode_counts"].keys()), list(d["rcode_counts"].values()), "Response codes")

    tabs = st.tabs(["Query table", "Responses", "Failed requests", "Repeated requests", "Per host",
                    "Unusual DNS behaviour"])
    with tabs[0]:
        search = st.text_input("Filter by domain", key="dns_search", placeholder="e.g. example.com")
        q = d["queries"]
        if search:
            q = q[q["dns_qname"].str.contains(search.strip().lower(), regex=False, na=False)]
        show_table(q, height=380)
        csv_button(d["queries"], "dns_queries.csv")
    with tabs[1]:
        show_table(d["responses"], height=380)
    with tabs[2]:
        show_table(d["failed"], empty_msg="No failed DNS responses were captured.")
    with tabs[3]:
        st.caption("Domains queried 5 or more times. Repetition is normal for popular services and short DNS TTLs.")
        show_table(d["repeated"], empty_msg="No domain was queried 5 or more times.")
    with tabs[4]:
        show_table(d["per_host"])
    with tabs[5]:
        st.caption("These names are listed because of their *shape* (length, randomness, depth, many sub-domains). "
                   "CDNs, telemetry and anti-virus services often look like this too - nothing here is classified "
                   "as malicious.")
        show_table(d["unusual_domains"], empty_msg="No domain name matched the heuristics.")
        st.markdown("**Sub-domain diversity per base domain** (high values can indicate DNS tunnelling)")
        show_table(d["subdomain_diversity"].head(20))
        dns_alerts = r.alerts[r.alerts["rule_id"].isin(["R3", "R9"])] if not r.alerts.empty else r.alerts
        if not dns_alerts.empty:
            st.warning(f"{len(dns_alerts)} DNS-related alert(s) were raised - see the Anomaly Detection page.")
