"""Overview page: headline KPIs and the main charts."""

from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from dashboard.common import bar, donut, kpi_row, page_header, require_result, severity_donut
from dashboard.theme import BLUE, CYAN, plotly_layout
from utils.helpers import human_bytes, ts_to_str


def render() -> None:
    page_header("Security Overview", "Summary of the currently loaded capture")
    r = require_result()
    s = r.summary
    sev = s["severity_counts"]
    high = sev.get("High", 0) + sev.get("Critical", 0)

    kpi_row([("Total packets", f"{s['total_packets']:,}", human_bytes(s["total_bytes"])),
             ("Unique IP addresses", s["unique_ips"], f"{r.ip['category_counts'].get('Private', 0)} private"),
             ("DNS queries", s["dns_queries"], f"{r.dns['failed_count']} failed"),
             ("HTTP requests", s["http_requests"], "clear-text"),
             ("TCP connections", s["tcp_connections"], f"{r.tcp['completed_handshakes']} completed"),
             ("UDP packets", f"{s['udp_packets']:,}", ""),
             ("Suspicious alerts", s["alert_count"], f"{high} high/critical", "alert" if s["alert_count"] else "accent")])

    st.caption(f"Capture window: {ts_to_str(s['start_time'])} → {ts_to_str(s['end_time'])}  ·  "
               f"duration {s['duration_sec']:.1f} s  ·  {s['packets_per_sec']} packets/s  ·  "
               f"average packet {s['avg_packet_size']} bytes")
    for w in s["warnings"]:
        st.warning(w)

    c1, c2 = st.columns(2)
    with c1:
        donut(list(r.protocol_counts.keys()), list(r.protocol_counts.values()), "Protocol distribution")
    with c2:
        tl = r.timeline
        if tl.empty:
            st.caption("Traffic volume over time: no data.")
        else:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=tl["time"], y=tl["packets"], mode="lines", name="packets",
                                     line=dict(color=CYAN, width=1.6), fill="tozeroy",
                                     fillcolor="rgba(34,211,238,0.15)"))
            fig.add_trace(go.Scatter(x=tl["time"], y=tl["bytes"], mode="lines", name="bytes", yaxis="y2",
                                     line=dict(color=BLUE, width=1, dash="dot")))
            fig.update_layout(yaxis=dict(title=f"packets / {tl['bucket_sec'].iloc[0]:g}s"),
                              yaxis2=dict(title="bytes", overlaying="y", side="right", showgrid=False))
            st.plotly_chart(plotly_layout(fig, "Traffic volume over time (UTC)"), width="stretch")

    c3, c4 = st.columns(2)
    with c3:
        bar(r.ip["top_sources"][["ip", "packets_sent"]], "ip", "packets_sent", "Top source IP addresses",
            horizontal=True)
    with c4:
        bar(r.ip["top_destinations"][["ip", "packets_received"]], "ip", "packets_received",
            "Top destination IP addresses", horizontal=True, color=CYAN)

    c5, c6 = st.columns(2)
    with c5:
        bar(r.dns["top_domains"], "domain", "queries", "DNS request distribution (top domains)",
            horizontal=True, color="#818cf8")
    with c6:
        if s["alert_count"]:
            severity_donut(sev)
        else:
            st.markdown("<div class='panel'><b>Alert severity distribution</b><br><span class='muted'>No detection "
                        "rule exceeded its threshold for this capture.</span></div>", unsafe_allow_html=True)
