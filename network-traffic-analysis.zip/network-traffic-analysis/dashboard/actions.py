"""Actions shared by several pages: analyse a file, save it to the database, re-run detection."""

from __future__ import annotations

import streamlit as st

from analyzer.pipeline import run_analysis
from dashboard.common import get_settings
from database.db_manager import DatabaseManager
from detection.anomaly_detector import AnomalyDetector, severity_counts


@st.cache_resource
def get_db() -> DatabaseManager:
    return DatabaseManager()


def analyze_file(path, display_name: str | None = None) -> bool:
    """Analyse a capture, store the result in session state and SQLite. Returns True on success."""
    progress = st.progress(0, text="Reading packets...")

    def on_progress(n):
        progress.progress(min(0.9, n / 200_000 + 0.05), text=f"Decoded {n:,} packets...")

    try:
        with st.spinner("Analysing capture..."):
            result = run_analysis(path, settings=get_settings(), display_name=display_name, progress=on_progress)
    except ValueError as exc:
        progress.empty()
        st.error(f"❌ {exc}")
        return False
    except MemoryError:
        progress.empty()
        st.error("The capture is too large for the available memory. Lower 'Maximum packets to analyse' on the "
                 "Settings page and try again.")
        return False
    progress.progress(1.0, text="Analysis complete")
    try:
        get_db().save_analysis(result)
    except Exception as exc:  # noqa: BLE001 - history is optional; analysis is still usable
        st.warning(f"Analysis finished but could not be saved to the history database: {exc}")
    st.session_state["result"] = result
    st.session_state.pop("last_report", None)
    return True


def rerun_detection() -> None:
    """Apply changed thresholds to the loaded capture without re-reading the file."""
    result = st.session_state.get("result")
    if result is None:
        return
    settings = get_settings()
    detector = AnomalyDetector(settings)
    result.alerts = detector.run(result.packets, result.tcp["connections"])
    result.detection_errors, result.detection_notes = detector.errors, detector.notes
    result.settings = settings
    result.summary["alert_count"] = len(result.alerts)
    result.summary["severity_counts"] = severity_counts(result.alerts)
    try:
        get_db().save_analysis(result)
    except Exception:  # noqa: BLE001
        pass
