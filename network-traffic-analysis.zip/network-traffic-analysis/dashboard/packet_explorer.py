"""Packet Explorer page: searchable packet list and per-packet detail view."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import csv_button, get_settings, page_header, require_result, show_table
from utils.helpers import mask_ip, ts_to_str

LIST_COLUMNS = ["no", "datetime", "src_ip", "src_port", "dst_ip", "dst_port", "protocol", "length", "tcp_flags", "info"]

DETAIL_GROUPS = {
    "Frame": ["no", "timestamp", "length", "captured_length", "malformed"],
    "Link layer": ["src_mac", "dst_mac"],
    "Network layer": ["ip_version", "src_ip", "dst_ip", "ttl", "ip_proto"],
    "Transport layer": ["transport", "src_port", "dst_port", "tcp_flags", "tcp_seq", "tcp_ack", "tcp_window",
                        "payload_len", "is_retransmission"],
    "ICMP": ["icmp_type", "icmp_code", "icmp_desc"],
    "ARP": ["arp_op", "arp_sender_ip", "arp_target_ip"],
    "DNS": ["dns_id", "dns_is_response", "dns_qname", "dns_qtype", "dns_rcode", "dns_answer_count", "dns_answers"],
    "HTTP": ["http_method", "http_host", "http_uri", "http_user_agent", "http_status", "http_version"],
    "TLS": ["tls_handshake", "tls_record_version", "tls_version", "tls_sni"],
}


def _present(value) -> bool:
    try:
        return value is not None and not pd.isna(value) and value != ""
    except (TypeError, ValueError):
        return True


def render() -> None:
    page_header("Packet Explorer", "Search and inspect individual packets (metadata only - no payloads)")
    r = require_result()
    df = r.packets
    if df.empty:
        st.info("This capture contains no packets.")
        return
    page_size = int(get_settings()["dashboard"].get("explorer_page_size", 500) or 500)

    c1, c2, c3, c4 = st.columns(4)
    src = c1.text_input("Source IP contains", key="px_src")
    dst = c2.text_input("Destination IP contains", key="px_dst")
    protos = c3.multiselect("Protocol", sorted(df["protocol"].unique()), key="px_proto")
    port = c4.number_input("Port (src or dst, 0 = any)", min_value=0, max_value=65535, value=0, key="px_port")
    c5, c6 = st.columns([2, 2])
    lo, hi = int(df["length"].min()), int(df["length"].max())
    length = c5.slider("Packet length (bytes)", lo, max(hi, lo + 1), (lo, max(hi, lo + 1)), key="px_len")
    text = c6.text_input("Search in summary (e.g. SYN, NXDOMAIN, example.com)", key="px_text")

    view = df
    if src:
        view = view[view["src_ip"].fillna("").str.contains(src.strip(), regex=False)]
    if dst:
        view = view[view["dst_ip"].fillna("").str.contains(dst.strip(), regex=False)]
    if protos:
        view = view[view["protocol"].isin(protos)]
    if port:
        view = view[(view["src_port"] == port) | (view["dst_port"] == port)]
    view = view[(view["length"] >= length[0]) & (view["length"] <= length[1])]
    if text:
        view = view[view["info"].str.contains(text, case=False, regex=False, na=False)]

    st.markdown(f"**{len(view):,}** of {len(df):,} packets match" +
                (f" - showing the first {page_size:,}" if len(view) > page_size else ""))
    show_table(view[LIST_COLUMNS].head(page_size), height=420)
    csv_button(view[LIST_COLUMNS], "packets_filtered.csv", "⬇ Download filtered packets (CSV)")

    st.divider()
    st.subheader("Packet details")
    if view.empty:
        return
    numbers = view["no"].head(page_size).tolist()
    pick = st.selectbox("Packet number", numbers, key="px_pick")
    pkt = df[df["no"] == pick].iloc[0]
    mask = get_settings()["dashboard"].get("mask_ip_addresses")
    st.markdown(f"<div class='panel'><b>#{pick}</b> · {ts_to_str(pkt['timestamp'])} · "
                f"<b>{pkt['protocol']}</b> · {pkt['info']}</div>", unsafe_allow_html=True)
    cols = st.columns(3)
    i = 0
    for group, fields in DETAIL_GROUPS.items():
        rows = []
        for f in fields:
            v = pkt.get(f)
            if _present(v) and not (isinstance(v, (bool,)) and not v and f not in ("malformed",)):
                if mask and f.endswith("_ip") and isinstance(v, str):
                    v = mask_ip(v)
                rows.append(f"- **{f}**: `{v}`")
        if rows:
            with cols[i % 3]:
                st.markdown(f"**{group}**\n" + "\n".join(rows))
            i += 1
    st.caption("Packet payloads are intentionally not stored or displayed (privacy by design).")

