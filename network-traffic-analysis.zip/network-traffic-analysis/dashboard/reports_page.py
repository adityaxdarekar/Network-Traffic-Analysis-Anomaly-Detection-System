"""Reports page: PDF report, CSV/JSON exports and analysis history."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

from config import SCREENSHOT_DIR
from dashboard.actions import get_db
from dashboard.common import get_result, page_header, show_table
from reports.pdf_generator import generate_pdf_report
from utils.helpers import human_bytes, now_str


def _exports(r) -> dict[str, pd.DataFrame]:
    pk_cols = [c for c in r.packets.columns if c not in ("datetime",)]
    return {
        "packets.csv": r.packets[pk_cols],
        "alerts.csv": r.alerts,
        "dns_queries.csv": r.dns["queries"],
        "dns_responses.csv": r.dns["responses"],
        "http_requests.csv": r.http["requests"],
        "tls_destinations.csv": r.tls["destinations"],
        "tcp_connections.csv": r.tcp["connections"],
        "udp_conversations.csv": r.udp["conversations"],
        "ip_hosts.csv": r.ip["hosts"],
        "protocol_counts.csv": pd.DataFrame(list(r.protocol_counts.items()), columns=["protocol", "packets"]),
    }


def _summary_json(r) -> str:
    s = dict(r.summary)
    s.update(session_id=r.session_id, analyzed_at=r.analyzed_at, protocol_counts=r.protocol_counts)
    return json.dumps(s, indent=2, default=str)


def render() -> None:
    page_header("Reports", "PDF report, data exports and previous analysis sessions")
    r = get_result()
    tab_pdf, tab_csv, tab_hist = st.tabs(["📄 PDF report", "⬇ Export data", "🗂 Previous sessions"])

    with tab_pdf:
        if r is None:
            st.info("Analyse a capture first (Upload PCAP page).")
        else:
            st.markdown(f"Generate a professional PDF report for **{r.file_name}** "
                        f"({r.summary['total_packets']:,} packets, {r.summary['alert_count']} alerts). All content "
                        "comes from the current analysis.")
            analyst = st.text_input("Analyst name (optional, shown on the cover)")
            shots = sorted(p for p in SCREENSHOT_DIR.glob("*") if p.suffix.lower() in (".png", ".jpg", ".jpeg"))
            chosen = st.multiselect("Screenshots to include (from the screenshots/ folder)", [p.name for p in shots])
            if st.button("Generate PDF report", type="primary"):
                with st.spinner("Building charts and PDF..."):
                    try:
                        path = generate_pdf_report(r, screenshots=[SCREENSHOT_DIR / n for n in chosen], analyst=analyst)
                        get_db().add_report(r.session_id, str(path), now_str())
                        st.session_state["last_report"] = str(path)
                    except Exception as exc:  # noqa: BLE001 - show the reason instead of crashing
                        st.error(f"Report generation failed: {exc}")
            last = st.session_state.get("last_report")
            if last and Path(last).exists():
                st.success(f"Report saved to `{last}` ({human_bytes(Path(last).stat().st_size)})")
                st.download_button("⬇ Download PDF report", Path(last).read_bytes(), file_name=Path(last).name,
                                   mime="application/pdf", type="primary")

    with tab_csv:
        if r is None:
            st.info("Analyse a capture first.")
        else:
            exports = _exports(r)
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for name, df in exports.items():
                    zf.writestr(name, df.to_csv(index=False))
                zf.writestr("summary.json", _summary_json(r))
            st.download_button("⬇ Download everything (ZIP of CSV files + summary.json)", buf.getvalue(),
                               file_name=f"analysis_{r.session_id}.zip", mime="application/zip", type="primary")
            st.download_button("⬇ Summary (JSON)", _summary_json(r), file_name=f"summary_{r.session_id}.json",
                               mime="application/json")
            st.markdown("**Individual CSV files**")
            cols = st.columns(3)
            for i, (name, df) in enumerate(exports.items()):
                cols[i % 3].download_button(f"{name} ({len(df):,} rows)", df.to_csv(index=False).encode("utf-8"),
                                            file_name=name, mime="text/csv", key=f"exp_{name}")
            st.caption("Exports contain packet metadata only - no payloads.")

    with tab_hist:
        db = get_db()
        sessions = db.list_sessions()
        if sessions.empty:
            st.info("No analysis sessions stored yet.")
            return
        view = sessions.assign(size=sessions["total_bytes"].map(human_bytes)).drop(columns=["severity_json"])
        show_table(view, height=300)
        trend = db.alert_trend()
        if len(trend) > 1:
            st.line_chart(trend.set_index("analyzed_at")[["alert_count"]])
        pick = st.selectbox("Open a previous session", sessions["session_id"],
                            format_func=lambda sid: f"{sid} — {sessions.set_index('session_id').loc[sid, 'file_name']}")
        data = db.get_session(pick)
        if data:
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Packets", f"{data['packet_count']:,}")
            c2.metric("Unique IPs", data["unique_ips"])
            c3.metric("DNS queries", data["dns_queries"])
            c4.metric("Alerts", data["alert_count"])
            st.caption(f"File {data['file_name']} · analysed {data['analyzed_at']} · severities "
                       f"{data['severity_counts']}")
            t1, t2, t3, t4, t5 = st.tabs(["Alerts", "Protocols", "Top IPs", "Top domains", "Reports"])
            with t1:
                show_table(data["alerts"], empty_msg="No alerts in this session.")
            with t2:
                show_table(data["protocol_stats"])
            with t3:
                show_table(data["ip_stats"])
            with t4:
                show_table(data["dns_stats"])
            with t5:
                show_table(data["reports"], empty_msg="No PDF report was generated for this session.")
            if st.button("🗑 Delete this session from history"):
                db.delete_session(pick)
                st.rerun()
