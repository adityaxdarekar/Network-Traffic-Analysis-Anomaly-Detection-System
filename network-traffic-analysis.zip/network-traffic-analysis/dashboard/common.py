"""Shared dashboard helpers: KPI cards, privacy-aware tables, chart wrappers, state access."""

from __future__ import annotations

import html

import pandas as pd
import plotly.express as px
import streamlit as st

from config import SEVERITY_COLORS, load_settings
from dashboard.theme import CHART_COLORS, plotly_layout
from utils.helpers import mask_ip


# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
def get_settings() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = load_settings()
    return st.session_state["settings"]


def get_result():
    return st.session_state.get("result")


def require_result():
    """Return the current analysis or show a friendly hint and stop the page."""
    result = get_result()
    if result is None:
        st.info("No capture has been analysed yet. Go to **Upload PCAP** to analyse a file (sample captures are "
                "included), or record traffic on the **Live Capture** page.")
        st.stop()
    return result


def go_to(page: str) -> None:
    """Switch sidebar page on the next run."""
    st.session_state["nav_target"] = page
    st.rerun()


# ---------------------------------------------------------------------------
# Visual building blocks
# ---------------------------------------------------------------------------
def page_header(title: str, subtitle: str = "") -> None:
    result = get_result()
    pill = f"<span class='soc-pill'>📄 {html.escape(result.file_name)}</span>" if result else \
        "<span class='soc-pill'>no capture loaded</span>"
    st.markdown(f"<div class='soc-header'><div><div class='title'>{html.escape(title)}</div>"
                f"<div class='subtitle'>{html.escape(subtitle)}</div></div><div>{pill}</div></div>",
                unsafe_allow_html=True)


def kpi(col, label: str, value, sub: str = "", style: str = "accent") -> None:
    col.markdown(f"<div class='kpi {style}'><div class='label'>{html.escape(label)}</div>"
                 f"<div class='value'>{html.escape(str(value))}</div>"
                 f"<div class='sub'>{html.escape(sub)}</div></div>", unsafe_allow_html=True)


def kpi_row(items: list[tuple]) -> None:
    cols = st.columns(len(items))
    for col, item in zip(cols, items):
        kpi(col, *item)
    st.write("")


def severity_badge(sev: str) -> str:
    return f"<span class='sev sev-{html.escape(sev)}'>{html.escape(sev.upper())}</span>"


def _mask_frame(df: pd.DataFrame) -> pd.DataFrame:
    if not get_settings()["dashboard"].get("mask_ip_addresses"):
        return df
    df = df.copy()
    for col in df.columns:
        if "ip" in col.lower().split("_") or col.lower() in ("ip", "src", "dst", "client", "server"):
            df[col] = df[col].map(lambda v: mask_ip(v) if isinstance(v, str) else v)
    return df


def show_table(df: pd.DataFrame, height: int | None = None, empty_msg: str = "Nothing to show.") -> None:
    """Display a dataframe with the privacy mask applied (if enabled)."""
    if df is None or df.empty:
        st.caption(empty_msg)
        return
    display = _mask_frame(df)
    for col in display.columns:
        if str(display[col].dtype).startswith("datetime64"):
            display[col] = display[col].dt.strftime("%Y-%m-%d %H:%M:%S.%f").str[:-3]
    kwargs = {"hide_index": True, "width": "stretch"}
    if height:
        kwargs["height"] = height
    st.dataframe(display, **kwargs)


def bar(df: pd.DataFrame, x: str, y: str, title: str, horizontal: bool = False, color: str | None = None,
        height: int = 340):
    if df is None or df.empty:
        st.caption(f"{title}: no data in this capture.")
        return
    df = _mask_frame(df)
    if horizontal:
        fig = px.bar(df.iloc[::-1], x=y, y=x, orientation="h", color_discrete_sequence=[color or CHART_COLORS[0]])
    else:
        fig = px.bar(df, x=x, y=y, color_discrete_sequence=[color or CHART_COLORS[0]])
    fig.update_traces(hovertemplate="%{x}<br>%{y}<extra></extra>")
    st.plotly_chart(plotly_layout(fig, title, height), width="stretch")


def donut(labels, values, title: str, colors: list[str] | None = None, height: int = 340):
    data = [(lab, v) for lab, v in zip(labels, values) if v]
    if not data:
        st.caption(f"{title}: no data in this capture.")
        return
    labs, vals = zip(*data)
    fig = px.pie(names=list(labs), values=list(vals), hole=0.55,
                 color=list(labs), color_discrete_map=dict(zip(labels, colors)) if colors else None,
                 color_discrete_sequence=CHART_COLORS)
    fig.update_traces(textinfo="percent", hovertemplate="%{label}: %{value:,}<extra></extra>")
    st.plotly_chart(plotly_layout(fig, title, height), width="stretch")


def severity_donut(counts: dict, title: str = "Alert severity distribution", height: int = 340):
    donut(list(counts.keys()), list(counts.values()), title, [SEVERITY_COLORS[k] for k in counts], height)


def csv_button(df: pd.DataFrame, filename: str, label: str = "⬇ Download CSV") -> None:
    if df is None or df.empty:
        return
    st.download_button(label, df.to_csv(index=False).encode("utf-8"), file_name=filename, mime="text/csv",
                       key=f"dl_{filename}")
