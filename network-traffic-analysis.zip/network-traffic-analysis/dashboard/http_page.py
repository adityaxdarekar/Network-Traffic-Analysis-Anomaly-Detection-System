"""HTTP / TLS Analysis page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import bar, csv_button, donut, kpi_row, page_header, require_result, show_table
from utils.helpers import human_bytes


def render() -> None:
    page_header("HTTP / TLS Analysis", "Clear-text HTTP versus encrypted HTTPS metadata")
    r = require_result()
    h, t = r.http, r.tls
    kpi_row([("HTTP requests", h["request_count"], "unencrypted"), ("HTTP responses", h["response_count"]),
             ("HTTP errors (4xx/5xx)", h["error_responses"]),
             ("TLS / QUIC packets", f"{t['packet_count']:,}", human_bytes(t["bytes"])),
             ("TLS handshakes", len(t["client_hellos"]), "ClientHello"),
             ("Legacy TLS", len(t["legacy_tls"]), "TLS 1.1 or older", "alert" if len(t["legacy_tls"]) else "accent")])

    st.markdown("<div class='panel'><b>🔓 HTTP (port 80…)</b> is clear text: method, host, path and status are "
                "visible to anyone on the path. &nbsp; <b>🔒 HTTPS/TLS</b> is encrypted: this tool only reads the "
                "handshake metadata that is visible to every router (TLS version, Server Name Indication, "
                "destination). Encrypted content is never decrypted. Query strings in HTTP URLs are dropped for "
                "privacy.</div>", unsafe_allow_html=True)

    tab_http, tab_tls = st.tabs(["🔓 HTTP (clear text)", "🔒 HTTPS / TLS (encrypted)"])
    with tab_http:
        if h["request_count"] == 0 and h["response_count"] == 0:
            st.info("No clear-text HTTP traffic in this capture (most web traffic today is HTTPS).")
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                donut(list(h["method_counts"].keys()), list(h["method_counts"].values()), "HTTP methods")
            with c2:
                sc = h["status_counts"]
                bar(pd.DataFrame({"status": [str(k) for k in sc], "responses": list(sc.values())}),
                    "status", "responses", "Response codes")
            with c3:
                bar(h["top_hosts"], "host", "requests", "Hostnames", horizontal=True)
            st.markdown("**HTTP requests**")
            show_table(h["requests"], height=320)
            csv_button(h["requests"], "http_requests.csv")
            c4, c5 = st.columns(2)
            with c4:
                st.markdown("**User-Agents**")
                show_table(h["user_agents"])
            with c5:
                st.markdown("**Request frequency (per minute)**")
                show_table(h["requests_per_minute"])
            st.markdown("**HTTP responses**")
            show_table(h["responses"])

    with tab_tls:
        if t["packet_count"] == 0:
            st.info("No TLS/HTTPS traffic in this capture.")
            return
        c1, c2 = st.columns(2)
        with c1:
            vc = t["version_counts"]
            donut(list(vc.keys()), list(vc.values()), "TLS versions (max offered in ClientHello)")
        with c2:
            bar(t["top_sni"], "sni", "connections", "Server Name Indication (SNI)", horizontal=True, color="#22d3ee")
        if t["negotiated_versions"]:
            st.caption("Negotiated (ServerHello): " +
                       ", ".join(f"{k}: {v}" for k, v in t["negotiated_versions"].items()))
        st.caption(f"ClientHellos without SNI: {t['sni_missing']} · QUIC (HTTP/3) packets: {t['quic_packets']} · "
                   f"encrypted record packets: {t['encrypted_packets']:,}")
        st.markdown("**Destinations and connection frequency**")
        show_table(t["destinations"], height=320)
        csv_button(t["destinations"], "tls_destinations.csv")
        st.markdown("**TLS handshakes (ClientHello)**")
        show_table(t["client_hellos"], height=280)
        if not t["legacy_tls"].empty:
            st.warning("Legacy TLS (1.1 or older) was seen. These versions are deprecated and should be disabled.")
            show_table(t["legacy_tls"])
