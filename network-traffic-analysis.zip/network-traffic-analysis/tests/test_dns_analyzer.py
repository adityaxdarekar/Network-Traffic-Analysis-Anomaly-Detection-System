"""Tests for DNS extraction and analysis."""

from __future__ import annotations

from analyzer.dns_analyzer import analyze_dns, domain_heuristics
from analyzer.packet_analyzer import parse_capture
from tests.conftest import GATEWAY, LAN_CLIENT, T0


def _dns(builder, write_capture, settings):
    b = builder
    b.dns_lookup(T0, LAN_CLIENT, GATEWAY, "www.example.com", "A", answers=[("A", "203.0.113.10")])
    b.dns_lookup(T0 + 1, LAN_CLIENT, GATEWAY, "www.example.com", "AAAA", answers=[("AAAA", "2001:db8::10")])
    b.dns_lookup(T0 + 2, LAN_CLIENT, GATEWAY, "example.com", "MX", answers=[("MX", "mail.example.com")])
    b.dns_lookup(T0 + 3, LAN_CLIENT, GATEWAY, "example.com", "TXT", answers=[("TXT", "v=spf1 -all")])
    b.dns_lookup(T0 + 4, LAN_CLIENT, GATEWAY, "alias.example.com", "CNAME", answers=[("CNAME", "www.example.com")])
    b.dns_lookup(T0 + 5, LAN_CLIENT, GATEWAY, "example.com", "NS", answers=[("NS", "ns1.example.com")])
    b.dns_lookup(T0 + 6, LAN_CLIENT, GATEWAY, "nosuch.example", "A", rcode=3)          # NXDOMAIN
    b.dns_lookup(T0 + 7, LAN_CLIENT, GATEWAY, "lost.example", "A", answers=None)       # never answered
    for i in range(5):
        b.dns_lookup(T0 + 10 + i, LAN_CLIENT, GATEWAY, "repeat.example.org", "A", answers=[("A", "198.51.100.1")])
    df = parse_capture(write_capture(b)).packets
    return df, analyze_dns(df, settings["thresholds"])


def test_dns_query_and_response_extraction(builder, write_capture, settings):
    df, d = _dns(builder, write_capture, settings)
    assert d["query_count"] == 13 and d["response_count"] == 12
    q = df[df["dns_qname"] == "www.example.com"]
    assert set(q["dns_qtype"]) == {"A", "AAAA"}
    ans = df[(df["dns_qname"] == "www.example.com") & (df["dns_is_response"] == True)]  # noqa: E712
    assert "A 203.0.113.10" in ans["dns_answers"].tolist()
    assert "AAAA 2001:db8::10" in ans["dns_answers"].tolist()


def test_dns_query_types(builder, write_capture, settings):
    _, d = _dns(builder, write_capture, settings)
    for t in ("A", "AAAA", "MX", "TXT", "CNAME", "NS"):
        assert d["qtype_counts"][t] >= 1, t


def test_failed_unanswered_and_repeated(builder, write_capture, settings):
    _, d = _dns(builder, write_capture, settings)
    assert d["failed_count"] == 1 and d["failed"].iloc[0]["dns_qname"] == "nosuch.example"
    assert d["rcode_counts"]["NXDOMAIN"] == 1
    assert d["unanswered_count"] == 1
    assert d["repeated"].iloc[0]["domain"] == "repeat.example.org" and d["repeated"].iloc[0]["queries"] == 5
    assert d["top_domains"].iloc[0]["domain"] == "repeat.example.org"
    assert d["avg_response_ms"] == 20.0


def test_normal_domains_are_not_flagged(builder, write_capture, settings):
    _, d = _dns(builder, write_capture, settings)
    assert d["unusual_domains"].empty


def test_domain_heuristics(settings):
    th = settings["thresholds"]
    assert domain_heuristics("www.google.com", th) == []
    assert domain_heuristics("mail.example.co.uk", th) == []
    weird = "a9f3c2e18b7d4f60a1c3e5f7092b4d6f8a0c2e4f6081a3c5e7.tunnel.example"
    reasons = domain_heuristics(weird, th)
    assert any("long" in r for r in reasons) and any("random" in r or "hex" in r for r in reasons)


def test_no_dns_traffic(builder, write_capture, settings):
    builder.ping(T0, LAN_CLIENT, GATEWAY, 2)
    d = analyze_dns(parse_capture(write_capture(builder)).packets, settings["thresholds"])
    assert d["query_count"] == 0 and d["top_domains"].empty
