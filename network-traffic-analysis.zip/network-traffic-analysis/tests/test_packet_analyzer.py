"""Tests for PCAP/PCAPNG reading, decoding, protocol classification and robustness."""

from __future__ import annotations

import struct
import time

import pandas as pd
import pytest

from analyzer.decoders import decode_frame
from analyzer.http_analyzer import analyze_http
from analyzer.packet_analyzer import parse_capture
from analyzer.pcap_reader import CaptureReader
from analyzer.pipeline import run_analysis
from analyzer.tcp_analyzer import analyze_tcp, mark_retransmissions
from analyzer.tls_analyzer import analyze_tls
from analyzer.udp_analyzer import analyze_udp
from tests.conftest import GATEWAY, LAN_CLIENT, LAN_SERVER, T0
from utils import pcap_writer as pw
from utils.validators import validate_capture_file


# ---------------------------------------------------------------- 1. PCAP reading
def test_reads_pcap_and_pcapng_identically(builder, write_capture):
    builder.dns_lookup(T0, LAN_CLIENT, GATEWAY, "a.example.com", answers=[("A", "203.0.113.1")])
    builder.https_visit(T0 + 1, LAN_CLIENT, "203.0.113.1", "a.example.com")
    p1 = write_capture(builder, "x.pcap")
    p2 = write_capture(builder, "x.pcapng")
    a, b = parse_capture(p1), parse_capture(p2)
    assert a.file_format == "pcap" and b.file_format == "pcapng"
    assert a.packet_count == b.packet_count == len(builder.frames)
    assert list(a.packets["protocol"]) == list(b.packets["protocol"])
    assert abs(a.packets["timestamp"].iloc[0] - T0) < 1e-5
    assert abs(b.packets["timestamp"].iloc[-1] - a.packets["timestamp"].iloc[-1]) < 1e-5


def test_sample_files_are_readable(sample_dir):
    files = sorted(sample_dir.glob("*.pcap*"))
    assert len(files) >= 5, "run sample_data/generate_samples.py"
    for f in files:
        r = parse_capture(f)
        assert r.packet_count > 0 and r.malformed_count == 0 and not r.warnings


def test_protocol_classification(basic_capture):
    df = parse_capture(basic_capture).packets
    protos = set(df["protocol"])
    assert {"DNS", "HTTPS/TLS", "HTTP", "TCP", "ICMP", "ARP", "UDP"} <= protos
    arp = df[df["protocol"] == "ARP"].iloc[0]
    assert arp["arp_op"] == "request" and pd.isna(arp["src_ip"])   # ARP is not counted as IP traffic


def test_fields_extracted(basic_capture):
    df = parse_capture(basic_capture).packets
    syn = df[df["tcp_flags"] == "SYN"].iloc[0]
    assert syn["src_ip"] == LAN_CLIENT and syn["dst_port"] == 443 and syn["flag_syn"] and not syn["flag_ack"]
    icmp = df[df["protocol"] == "ICMP"].iloc[0]
    assert icmp["icmp_desc"] == "Echo Request" and icmp["icmp_type"] == 8
    assert (df["length"] > 0).all()


# ---------------------------------------------------------------- 3. HTTP / TLS
def test_http_request_extraction_and_privacy(basic_capture):
    df = parse_capture(basic_capture).packets
    h = analyze_http(df)
    assert h["request_count"] == 1 and h["response_count"] == 1
    req = h["requests"].iloc[0]
    assert req["http_method"] == "GET" and req["http_host"] == "intranet.example.edu"
    assert req["http_uri"] == "/page"                        # query string removed
    assert "SECRET" not in df.to_csv()                       # nothing from the query string is stored
    assert h["status_counts"] == {200: 1}
    assert req["http_user_agent"].startswith("Mozilla")


def test_tls_sni_and_version(basic_capture):
    df = parse_capture(basic_capture).packets
    t = analyze_tls(mark_retransmissions(df))
    assert t["client_hellos"]["tls_sni"].tolist() == ["www.example.com"]
    assert t["version_counts"] == {"TLS 1.3": 1}
    assert t["negotiated_versions"] == {"TLS 1.3": 1}
    assert t["destinations"].iloc[0]["dst_ip"] == "203.0.113.10"


def test_legacy_tls_detected(builder, write_capture):
    builder.https_visit(T0, LAN_CLIENT, "203.0.113.5", "old.example.com", version=0x0301)
    t = analyze_tls(mark_retransmissions(parse_capture(write_capture(builder)).packets))
    assert len(t["legacy_tls"]) == 2 and "TLS 1.0" in t["version_counts"]


# ---------------------------------------------------------------- 4. TCP
def test_tcp_connection_states_and_flags(builder, write_capture):
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 22, [("c", b"hello"), ("s", b"world")])
    builder.add_tcp(T0 + 5, LAN_CLIENT, LAN_SERVER, 40000, 81, 100, 0, "S")                 # no reply
    builder.add_tcp(T0 + 6, LAN_CLIENT, LAN_SERVER, 40001, 82, 200, 0, "S")                 # rejected
    builder.add_tcp(T0 + 6.01, LAN_SERVER, LAN_CLIENT, 82, 40001, 0, 201, "RA")
    df = mark_retransmissions(parse_capture(write_capture(builder)).packets)
    t = analyze_tcp(df)
    states = t["connections"].set_index("server_port")["state"].to_dict()
    assert states == {22: "Closed (FIN)", 81: "No reply to SYN", 82: "Rejected (RST)"}
    assert t["flag_counts"]["SYN"] == 3 and t["flag_counts"]["SYN-ACK"] == 1 and t["flag_counts"]["RST"] == 1
    assert t["completed_handshakes"] == 1 and len(t["failed_connections"]) == 2


def test_tcp_retransmissions(builder, write_capture):
    ex = [("c" if i % 2 else "s", b"x" * 500) for i in range(12)]
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 445, ex, retransmit_every=3)
    df = mark_retransmissions(parse_capture(write_capture(builder)).packets)
    assert int(df["is_retransmission"].sum()) == 4
    assert analyze_tcp(df)["retransmissions"] == 4


def test_no_false_retransmissions_in_normal_session(builder, write_capture):
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 80, [("c", b"a" * 100), ("s", b"b" * 1000), ("c", b"c" * 50)])
    df = mark_retransmissions(parse_capture(write_capture(builder)).packets)
    assert not df["is_retransmission"].any()


# ---------------------------------------------------------------- 5. UDP
def test_udp_analysis(basic_capture):
    u = analyze_udp(parse_capture(basic_capture).packets)
    assert u["packet_count"] == 3 and u["dns_packets"] == 2
    assert 123 in u["top_dst_ports"]["port"].tolist()
    assert "NTP" in u["conversations"]["service"].tolist()


# ---------------------------------------------------------------- robustness
def test_empty_pcap_header_only(tmp_path):
    p = tmp_path / "empty.pcap"
    pw.PcapWriter(p).close()
    r = run_analysis(p)
    assert r.summary["total_packets"] == 0 and r.alerts.empty
    assert any("no packets" in w.lower() for w in r.summary["warnings"])


def test_zero_byte_and_invalid_files(tmp_path):
    zero = tmp_path / "zero.pcap"
    zero.write_bytes(b"")
    text = tmp_path / "notes.pcap"
    text.write_text("this is not a capture")
    wrong_ext = tmp_path / "data.txt"
    wrong_ext.write_bytes(b"\xd4\xc3\xb2\xa1" + b"\x00" * 20)
    assert not validate_capture_file(zero).ok
    assert "does not look like" in validate_capture_file(text).message
    assert not validate_capture_file(wrong_ext).ok
    for p in (zero, text, wrong_ext):
        with pytest.raises(ValueError):
            parse_capture(p)


def test_truncated_capture_does_not_crash(builder, write_capture):
    builder.https_visit(T0, LAN_CLIENT, "203.0.113.1", "t.example.com")
    for name in ("trunc.pcap", "trunc.pcapng"):
        path = write_capture(builder, name)
        data = path.read_bytes()
        path.write_bytes(data[:-37])                  # cut the last packet in half
        r = parse_capture(path)
        assert r.truncated and r.packet_count == len(builder.frames) - 1
        assert any("cut short" in w or "ends" in w for w in r.warnings)


def test_malformed_packets_are_flagged_not_fatal(tmp_path):
    p = tmp_path / "bad.pcap"
    w = pw.PcapWriter(p)
    good = pw.ethernet("02:00:00:00:00:01", "02:00:00:00:00:02", 0x0800,
                       pw.ipv4("10.0.0.1", "10.0.0.2", 17, pw.udp("10.0.0.1", "10.0.0.2", 1, 53, b"\x00" * 5)))
    w.write(T0, good)                                             # DNS too short -> ignored, still UDP/DNS
    w.write(T0 + 1, good[:20])                                    # IPv4 header cut off
    w.write(T0 + 2, b"\x00" * 6)                                  # shorter than Ethernet header
    eth_tcp = pw.ethernet("02:00:00:00:00:01", "02:00:00:00:00:02", 0x0800,
                          pw.ipv4("10.0.0.1", "10.0.0.2", 6, b"\x00\x50"))  # 2-byte TCP header
    w.write(T0 + 3, eth_tcp)
    w.write(T0 + 4, pw.ethernet("02:00:00:00:00:01", "ff:ff:ff:ff:ff:ff", 0x88CC, b"lldp"))  # unsupported type
    w.close()
    r = run_analysis(p)
    df = r.packets
    assert len(df) == 5 and r.summary["malformed_packets"] == 3
    assert df.iloc[4]["protocol"] == "Other"


def test_dns_compression_loop_is_safe():
    # A DNS name whose compression pointer points to itself must not hang.
    msg = struct.pack("!HHHHHH", 1, 0x8180, 1, 1, 0, 0) + b"\xc0\x0c" + b"\x00\x01\x00\x01"
    frame = pw.ethernet("02:00:00:00:00:01", "02:00:00:00:00:02", 0x0800,
                        pw.ipv4("10.0.0.2", "10.0.0.1", 17, pw.udp("10.0.0.2", "10.0.0.1", 53, 5000, msg)))
    rec = decode_frame(frame, 1)
    assert rec["protocol"] == "DNS" and rec["malformed"]


def test_other_link_types():
    ip_pkt = pw.ipv4("10.0.0.1", "10.0.0.2", 17, pw.udp("10.0.0.1", "10.0.0.2", 1000, 2000, b"hi"))
    assert decode_frame(ip_pkt, 101)["protocol"] == "UDP"                       # raw IP
    assert decode_frame(b"\x02\x00\x00\x00" + ip_pkt, 0)["src_ip"] == "10.0.0.1"   # Npcap loopback
    vlan = (b"\x02" * 6 + b"\x04" * 6 + b"\x81\x00\x00\x0a\x08\x00" + ip_pkt)    # 802.1Q tagged
    assert decode_frame(vlan, 1)["dst_port"] == 2000
    v6 = pw.ethernet("02:00:00:00:00:01", "02:00:00:00:00:02", 0x86DD,
                     pw.ipv6("fd00::1", "2001:db8::1", 6, pw.tcp("fd00::1", "2001:db8::1", 5555, 443, 1, 0, "S")))
    rec = decode_frame(v6, 1)
    assert rec["ip_version"] == 6 and rec["flag_syn"] and rec["dst_ip"] == "2001:db8::1"
    assert decode_frame(b"abc", 147)["info"].startswith("Unsupported link type")


def test_large_capture_and_packet_limit(tmp_path):
    """50,000 packets: analysed in reasonable time; the packet limit is respected."""
    p = tmp_path / "large.pcapng"
    w = pw.PcapngWriter(p)
    payload = pw.ipv4("192.168.1.5", "203.0.113.9", 17, pw.udp("192.168.1.5", "203.0.113.9", 5000, 6000, b"x" * 100))
    frame = pw.ethernet("02:00:00:00:00:01", "02:00:00:00:00:02", 0x0800, payload)
    for i in range(50_000):
        w.write(T0 + i * 0.001, frame)
    w.close()
    start = time.perf_counter()
    r = parse_capture(p)
    assert r.packet_count == 50_000
    assert time.perf_counter() - start < 60
    limited = parse_capture(p, max_packets=1000)
    assert limited.packet_count == 1000 and limited.limit_reached
    assert sum(1 for _ in CaptureReader(p, max_packets=10)) == 10
