"""
Headless smoke test of every dashboard page.

Streamlit and Plotly are replaced by light stand-ins (tests/streamlit_stub.py)
so that each page's real code runs against real analysis results: no capture
loaded, a capture with alerts, one without alerts, an empty capture, IP
masking on, and key button clicks (analyse sample, generate PDF, save settings).
"""

from __future__ import annotations

import importlib

import pytest

from tests import streamlit_stub as stub

PAGES = ["Overview", "Live Capture", "Upload PCAP", "DNS Analysis", "HTTP/TLS Analysis", "TCP/UDP Analysis",
         "IP Investigation", "Anomaly Detection", "Packet Explorer", "Reports", "Settings", "About Project"]


@pytest.fixture
def app(tmp_path, monkeypatch):
    stub.install()
    import config
    monkeypatch.setattr(config, "SETTINGS_FILE", tmp_path / "settings.json")
    application = importlib.import_module("app")
    from database.db_manager import DatabaseManager
    import dashboard.actions as actions
    import dashboard.reports_page as rp
    import reports.pdf_generator as pg
    db = DatabaseManager(tmp_path / "db.sqlite")
    monkeypatch.setattr(actions, "get_db", lambda: db)
    monkeypatch.setattr(rp, "get_db", lambda: db)
    monkeypatch.setattr(pg, "REPORT_DIR", tmp_path)
    st = stub._module
    st.session_state.clear()
    stub.StubState.press, stub.StubState.inputs, stub.StubState.calls = set(), {}, []
    return application, st


def run_page(application, st, page):
    st.session_state["nav"] = page
    try:
        application.main()
    except (stub.StopException, stub.RerunException):
        pass
    errors = [c for c in stub.StubState.calls if c[0] in ("error", "exception")
              and "Live capture is not available" not in str(c[1])]   # expected when TShark is absent
    stub.StubState.calls = []
    return errors


def load(st, path):
    from analyzer.pipeline import run_analysis
    st.session_state["result"] = run_analysis(path)


def test_pages_without_capture(app):
    application, st = app
    for page in PAGES:
        errs = run_page(application, st, page)
        assert not [e for e in errs if "Something went wrong" in str(e[1])], (page, errs)


@pytest.mark.parametrize("sample", ["mixed_demo.pcapng", "normal_traffic.pcapng", "port_scan.pcap"])
def test_all_pages_with_capture(app, sample_dir, sample):
    application, st = app
    load(st, sample_dir / sample)
    for page in PAGES:
        assert run_page(application, st, page) == [], page


def test_pages_with_ip_masking_and_filters(app, sample_dir):
    application, st = app
    load(st, sample_dir / "mixed_demo.pcapng")
    import config
    st.session_state["settings"] = config.load_settings()
    st.session_state["settings"]["dashboard"]["mask_ip_addresses"] = True
    stub.StubState.inputs = {"px_src": "192.168", "px_proto": ["TCP"], "px_port": 445, "px_text": "SYN",
                             "al_sev": ["Critical", "High"], "al_ip": "192.168.1", "ip_filter": "192.168.1.",
                             "dns_search": "example", "tcp_state": ["No reply to SYN"]}
    for page in PAGES:
        assert run_page(application, st, page) == [], page


def test_empty_capture_pages(app, tmp_path):
    from utils.pcap_writer import PcapWriter
    p = tmp_path / "empty.pcap"
    PcapWriter(p).close()
    application, st = app
    load(st, p)
    for page in PAGES:
        assert run_page(application, st, page) == [], page


def test_analyse_sample_button_and_pdf_and_settings(app, sample_dir, tmp_path):
    application, st = app
    stub.StubState.press = {"Analyse sample"}
    stub.StubState.inputs = {"Sample capture": "mixed_demo.pcapng"}
    run_page(application, st, "Upload PCAP")
    assert st.session_state["result"].file_name == "mixed_demo.pcapng"
    assert len(st.session_state["result"].alerts) > 0

    stub.StubState.press = {"Generate PDF report"}
    assert run_page(application, st, "Reports") == []
    assert st.session_state["last_report"].endswith(".pdf")

    stub.StubState.press = {"💾 Save settings"}
    stub.StubState.inputs = {"en_R6": False}
    before = (st.session_state["result"].alerts["rule_id"] == "R6").sum()
    assert before > 0
    assert run_page(application, st, "Settings") == []
    assert (st.session_state["result"].alerts["rule_id"] == "R6").sum() == 0     # detection re-ran
    assert (tmp_path / "settings.json").exists()


def test_invalid_upload_is_rejected(app, tmp_path):
    application, st = app

    class FakeUpload:
        name = "evil.pcap"
        file_id = "1"

        def getbuffer(self):
            return memoryview(b"not a capture at all")
    stub.StubState.inputs = {"Choose a capture file": FakeUpload()}
    errs = run_page(application, st, "Upload PCAP")
    assert errs and "does not look like" in str(errs[0][1])
    assert "result" not in st.session_state


def test_live_capture_page_with_fake_tshark(app, tmp_path, monkeypatch):
    """Start -> running status -> stop -> analyse, using tests/fake_tshark.py instead of real TShark."""
    import sys
    from pathlib import Path
    import dashboard.capture_page as cp
    from capture.packet_capture import CaptureSession
    fake = [sys.executable, str(Path(__file__).with_name("fake_tshark.py"))]
    monkeypatch.setattr(cp, "_capabilities", lambda: {"platform": "Test", "tshark_path": "fake", "tshark_version":
                        "TShark (fake)", "scapy_available": False, "npcap_installed": None, "is_admin": False,
                        "can_capture": True})
    monkeypatch.setattr(cp, "_interfaces", lambda: ([{"id": "eth0", "name": "eth0", "description": "Test NIC",
                                                       "source": "tshark"}], None))
    monkeypatch.setattr(cp, "CaptureSession", lambda: CaptureSession(tshark_cmd=fake, output_dir=tmp_path))
    application, st = app
    # Start is disabled until the permission box is ticked; in the stub, pressing it starts the capture
    stub.StubState.inputs = {"I own this network/device or have explicit permission to monitor it.": True}
    stub.StubState.press = {"▶ Start capture"}
    assert run_page(application, st, "Live Capture") == []
    session = st.session_state["capture_session"]
    assert session.is_running()
    stub.StubState.press = {"■ Stop capture"}
    assert run_page(application, st, "Live Capture") == []
    assert not session.is_running() and session.status()["packets"] == 592
    stub.StubState.press = {"🔍 Analyse this capture"}
    run_page(application, st, "Live Capture")
    assert st.session_state["result"].summary["total_packets"] == 592
    assert st.session_state["nav_target"] == "Overview"
