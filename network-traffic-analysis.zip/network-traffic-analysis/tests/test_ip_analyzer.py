"""Tests for IP classification and per-host statistics."""

from __future__ import annotations

import pytest

from analyzer.ip_analyzer import analyze_ips, classify_ip, is_external
from analyzer.ip_reputation import lookup
from analyzer.packet_analyzer import parse_capture
from tests.conftest import GATEWAY, LAN_CLIENT, T0


@pytest.mark.parametrize("ip,expected", [
    ("192.168.1.10", "Private"), ("10.1.2.3", "Private"), ("172.16.5.5", "Private"), ("fd00::1", "Private"),
    ("8.8.8.8", "Public"), ("1.1.1.1", "Public"), ("2606:4700:4700::1111", "Public"),
    ("127.0.0.1", "Loopback"), ("::1", "Loopback"),
    ("224.0.0.251", "Multicast"), ("ff02::fb", "Multicast"), ("239.255.255.250", "Multicast"),
    ("255.255.255.255", "Broadcast"), ("169.254.10.1", "Link-local"), ("fe80::1", "Link-local"),
    ("100.64.0.1", "Shared (CGNAT)"), ("203.0.113.5", "Documentation"), ("2001:db8::1", "Documentation"),
    ("0.0.0.0", "Unspecified"), ("240.0.0.1", "Reserved"), ("not-an-ip", "Invalid"),
])
def test_classify_ip(ip, expected):
    assert classify_ip(ip) == expected


def test_public_is_not_malicious():
    info = lookup("8.8.8.8", watchlist=[])
    assert info["category"] == "Public" and not info["watchlist_match"]
    assert "AbuseIPDB" in info["external_links"]          # links only - no request is made
    assert lookup("192.168.1.1", watchlist=[])["external_links"] == {}


def test_external_helper():
    assert is_external("8.8.8.8") and is_external("203.0.113.1")
    assert not is_external("192.168.1.1") and not is_external("224.0.0.1")


def test_watchlist_match():
    import ipaddress
    wl = [(ipaddress.ip_network("203.0.113.0/24"), "demo range")]
    assert lookup("203.0.113.77", wl)["watchlist_match"]
    assert not lookup("198.51.100.1", wl)["watchlist_match"]


def test_host_statistics(builder, write_capture):
    builder.ping(T0, LAN_CLIENT, GATEWAY, count=5)          # 5 requests + 5 replies, 74 bytes each
    builder.add_udp(T0 + 10, LAN_CLIENT, "8.8.8.8", 5000, 5001, b"x" * 100)
    ip = analyze_ips(parse_capture(write_capture(builder)).packets)
    hosts = ip["hosts"].set_index("ip")
    assert ip["unique_ips"] == 3
    assert hosts.loc[LAN_CLIENT, "packets_sent"] == 6 and hosts.loc[LAN_CLIENT, "packets_received"] == 5
    assert hosts.loc[GATEWAY, "bytes_sent"] == 5 * 74
    assert hosts.loc[LAN_CLIENT, "unique_peers"] == 2
    assert hosts.loc["8.8.8.8", "category"] == "Public"
    assert ip["top_sources"].iloc[0]["ip"] == LAN_CLIENT
    assert ip["category_counts"] == {"Private": 2, "Public": 1}


def test_one_way_traffic_pattern(builder, write_capture):
    for i in range(25):
        builder.add_udp(T0 + i, LAN_CLIENT, "203.0.113.9", 5000, 7000, b"x")
    ip = analyze_ips(parse_capture(write_capture(builder)).packets)
    assert any("received none" in p["observation"] for p in ip["patterns"])
