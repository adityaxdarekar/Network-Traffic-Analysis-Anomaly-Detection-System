"""Tests for the capture module. A fake 'tshark' script is used - no real traffic is captured."""

from __future__ import annotations

import sys
import time
from pathlib import Path

import pytest

from capture import interface_manager as im
from capture.packet_capture import CaptureError, CaptureSession, friendly_error

FAKE = [sys.executable, str(Path(__file__).with_name("fake_tshark.py"))]


def test_parse_tshark_interface_list():
    out = ("1. \\Device\\NPF_{2C4E1C1A-1234} (Wi-Fi)\n2. \\Device\\NPF_Loopback (Adapter for loopback traffic capture)\n"
           "3. eth0\n")
    ifaces = im.parse_tshark_interfaces(out)
    assert [i["description"] for i in ifaces] == ["Wi-Fi", "Adapter for loopback traffic capture", "eth0"]
    assert ifaces[0]["id"] == "1"


def test_missing_tshark_is_handled(monkeypatch, tmp_path):
    monkeypatch.setattr(im, "find_tshark", lambda: None)
    monkeypatch.setattr("capture.packet_capture.find_tshark", lambda: None)
    monkeypatch.setattr("capture.packet_capture.scapy_available", lambda: False)
    monkeypatch.setattr(im, "scapy_available", lambda: False)
    caps = im.capture_capabilities()
    assert caps["can_capture"] is False and caps["tshark_path"] is None
    interfaces, err = im.list_interfaces()
    assert interfaces == [] and "TShark was not found" in err
    with pytest.raises(CaptureError, match="Upload PCAP"):
        CaptureSession(output_dir=tmp_path).start("eth0")


def test_capture_start_status_stop(tmp_path):
    s = CaptureSession(tshark_cmd=FAKE, output_dir=tmp_path)
    out = s.start("eth0", duration=30, packet_limit=0)
    assert s.is_running() and out.suffix == ".pcapng"
    time.sleep(0.3)
    st = s.status()
    assert st["running"] and st["packets"] > 0
    final = s.stop()
    assert not final["running"] and final["packets"] == 592 and final["error"] is None


def test_capture_stops_after_duration(tmp_path):
    s = CaptureSession(tshark_cmd=FAKE, output_dir=tmp_path)
    s.start("eth0", duration=1, output_format="pcap")
    time.sleep(1.8)
    assert not s.status()["running"]


@pytest.mark.parametrize("iface,expected", [("bad0", "not available"), ("denied0", "Permission denied")])
def test_capture_errors_are_friendly(tmp_path, iface, expected):
    with pytest.raises(CaptureError, match=expected):
        CaptureSession(tshark_cmd=FAKE, output_dir=tmp_path).start(iface)


def test_capture_input_validation(tmp_path):
    with pytest.raises(CaptureError, match="select a network interface"):
        CaptureSession(tshark_cmd=FAKE, output_dir=tmp_path).start("")
    assert "Permission denied" in friendly_error("Operation not permitted")
