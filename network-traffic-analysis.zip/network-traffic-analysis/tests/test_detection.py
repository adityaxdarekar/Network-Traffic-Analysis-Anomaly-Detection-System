"""Tests for the ten detection rules, using synthetic traffic only."""

from __future__ import annotations

import random

from analyzer.pipeline import run_analysis
from detection.anomaly_detector import AnomalyDetector
from detection.detection_rules import scale_severity
from tests.conftest import GATEWAY, LAN_CLIENT, LAN_SERVER, T0

SCANNER = "192.168.1.50"


def rules(result):
    return sorted(set(result.alerts["rule_id"])) if not result.alerts.empty else []


def alerts_for(result, rule_id):
    return result.alerts[result.alerts["rule_id"] == rule_id]


def _normal(b, seconds=60):
    t = T0
    while t < T0 + seconds:
        b.dns_lookup(t, LAN_CLIENT, GATEWAY, "www.example.com", answers=[("A", "203.0.113.10")])
        b.https_visit(t + 0.05, LAN_CLIENT, "203.0.113.10", "www.example.com")
        t += 5


def test_normal_traffic_has_no_alerts(builder, write_capture, settings):
    _normal(builder)
    r = run_analysis(write_capture(builder), settings)
    assert r.alerts.empty and not r.detection_errors


def test_sample_normal_capture_has_no_alerts(sample_dir, settings):
    assert run_analysis(sample_dir / "normal_traffic.pcapng", settings).alerts.empty


# ------------------------------------------------------------------ Rule 1
def test_port_scan(builder, write_capture, settings):
    for i, port in enumerate(range(1, 101)):
        seq = random.randint(0, 2**31)
        builder.add_tcp(T0 + i * 0.05, SCANNER, LAN_SERVER, 40000 + i, port, seq, 0, "S")
        if port == 22:
            builder.add_tcp(T0 + i * 0.05 + 0.001, LAN_SERVER, SCANNER, 22, 40000 + i, 9, seq + 1, "SA")
        else:
            builder.add_tcp(T0 + i * 0.05 + 0.001, LAN_SERVER, SCANNER, port, 40000 + i, 0, seq + 1, "RA")
    r = run_analysis(write_capture(builder), settings)
    a = alerts_for(r, "R1")
    assert len(a) == 1
    row = a.iloc[0]
    assert row["src_ip"] == SCANNER and row["dst_ip"] == LAN_SERVER
    assert row["severity"] == "High"                       # 100 ports = 5x threshold -> one level up from Medium
    assert "22" in row["evidence"] and "ports that answered SYN-ACK" in row["evidence"]
    assert "R2" not in rules(r)                             # RST replies mean it is not a SYN flood


def test_port_scan_below_threshold(builder, write_capture, settings):
    for port in range(1, 10):
        builder.add_tcp(T0 + port, SCANNER, LAN_SERVER, 40000 + port, port, 1, 0, "S")
    assert "R1" not in rules(run_analysis(write_capture(builder), settings))


def test_port_scan_outside_time_window(builder, write_capture, settings):
    for i, port in enumerate(range(1, 41)):                 # 40 ports, but one every 10 s
        builder.add_tcp(T0 + i * 10, SCANNER, LAN_SERVER, 40000 + i, port, 1, 0, "S")
    assert "R1" not in rules(run_analysis(write_capture(builder), settings))


# ------------------------------------------------------------------ Rule 2
def test_syn_flood(builder, write_capture, settings):
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 80, [("c", b"GET / HTTP/1.1\r\n\r\n")])   # SYN-ACKs exist
    for i in range(200):
        builder.add_tcp(T0 + 1 + i * 0.01, f"198.51.100.{i % 250 + 1}", LAN_SERVER, 1024 + i, 80, i, 0, "S")
    r = run_analysis(write_capture(builder), settings)
    a = alerts_for(r, "R2").iloc[0]
    assert a["dst_ip"] == LAN_SERVER and a["port"] == 80 and a["event_count"] == 201  # 200 flood SYNs + 1 normal
    assert a["severity"] == "High" and "distinct sources: 201" in a["evidence"]
    assert "confirmed" not in a["reason"].lower()


def test_syn_flood_severity_lowered_for_one_way_capture(builder, write_capture, settings):
    for i in range(200):
        builder.add_tcp(T0 + i * 0.01, f"198.51.100.{i % 250 + 1}", LAN_SERVER, 1024 + i, 80, i, 0, "S")
    a = alerts_for(run_analysis(write_capture(builder), settings), "R2").iloc[0]
    assert a["severity"] == "Medium" and "one-direction capture" in a["reason"]


def test_answered_syns_are_not_a_flood(builder, write_capture, settings):
    for i in range(150):
        builder.tcp_session(T0 + i * 0.05, f"192.168.1.{i % 200 + 20}", LAN_SERVER, 80, [], sport=30000 + i)
    assert "R2" not in rules(run_analysis(write_capture(builder), settings))


# ------------------------------------------------------------------ Rules 3 and 9
def test_dns_query_anomaly(builder, write_capture, settings):
    for i in range(120):
        builder.dns_lookup(T0 + i * 0.3, LAN_CLIENT, GATEWAY, f"site{i}.example.com", answers=[("A", "203.0.113.1")])
    r = run_analysis(write_capture(builder), settings)
    a = alerts_for(r, "R3").iloc[0]
    assert a["src_ip"] == LAN_CLIENT
    assert "distinct domain names" in a["reason"] and "within 60 s" in a["reason"]
    assert "R9" not in rules(r)                              # short normal names are not tunnelling indicators


def test_dns_tunneling_indicators(builder, write_capture, settings):
    rnd = random.Random(3)
    for i in range(60):
        label = "".join(rnd.choice("0123456789abcdef") for _ in range(48))
        builder.dns_lookup(T0 + i * 2, LAN_CLIENT, GATEWAY, f"{label}.tunnel.example", "TXT",
                           answers=[("TXT", "ok")])
    r = run_analysis(write_capture(builder), settings)
    a = alerts_for(r, "R9").iloc[0]
    assert "tunnel.example" in a["reason"] and a["src_ip"] == LAN_CLIENT
    assert a["severity"] == "Medium"                          # 60 sub-domains = 2x threshold -> base severity


# ------------------------------------------------------------------ Rule 4
def test_repeated_connection_attempts(builder, write_capture, settings):
    for i in range(16):
        builder.add_tcp(T0 + i, LAN_CLIENT, "203.0.113.200", 50000 + i, 3389, i, 0, "S")
    r = run_analysis(write_capture(builder), settings)
    a = alerts_for(r, "R4").iloc[0]
    assert a["port"] == 3389 and a["event_count"] == 16 and a["severity"] == "Medium"   # mostly failed
    assert "R6" in rules(r) and "R10" in rules(r)


def test_successful_repeated_connections_are_normal(builder, write_capture, settings):
    for i in range(30):                                        # 30 completed HTTPS connections to one server
        builder.https_visit(T0 + i, LAN_CLIENT, "203.0.113.10", "www.example.com", data_chunks=1)
    assert "R4" not in rules(run_analysis(write_capture(builder), settings))


# ------------------------------------------------------------------ Rule 5
def test_traffic_volume_spike(builder, write_capture, settings):
    for s in range(30):
        builder.add_udp(T0 + s, LAN_CLIENT, GATEWAY, 5000, 5001, b"x" * 50)      # 1 packet per second
    for i in range(300):
        builder.add_udp(T0 + 15 + i / 400, "192.168.1.77", GATEWAY, 6000, 6001, b"x" * 50)
    a = alerts_for(run_analysis(write_capture(builder), settings), "R5")
    assert len(a) == 1 and "packets/s" in a.iloc[0]["reason"]


def test_traffic_volume_host(builder, write_capture, settings):
    settings["thresholds"]["volume_min_bytes"] = 100_000
    for host in range(20, 30):
        builder.add_udp(T0 + host, f"192.168.1.{host}", GATEWAY, 5000, 5001, b"x" * 100)
    for i in range(200):
        builder.add_udp(T0 + 40 + i * 0.1, "192.168.1.99", "203.0.113.50", 5000, 443, b"x" * 1200)
    a = alerts_for(run_analysis(write_capture(builder), settings), "R5")
    assert set(a["src_ip"].dropna()) >= {"192.168.1.99"}


# ------------------------------------------------------------------ Rule 6
def test_unusual_ports(builder, write_capture, settings):
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 23, [("s", b"login: ")])
    builder.tcp_session(T0 + 2, LAN_CLIENT, LAN_SERVER, 443, [("c", b"x")])     # normal port -> no alert
    a = alerts_for(run_analysis(write_capture(builder), settings), "R6")
    assert a["port"].tolist() == [23] and "Telnet" in a.iloc[0]["reason"]


def test_unusual_ports_configurable(builder, write_capture, settings):
    settings["suspicious_ports"] = {"8443": "custom watch"}
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 8443, [])
    builder.tcp_session(T0 + 1, LAN_CLIENT, LAN_SERVER, 23, [])
    a = alerts_for(run_analysis(write_capture(builder), settings), "R6")
    assert a["port"].tolist() == [8443]


# ------------------------------------------------------------------ Rule 7
def test_icmp_anomaly_and_sweep(builder, write_capture, settings):
    for h in range(1, 61):
        builder.ping(T0 + h * 0.05, SCANNER, f"192.168.1.{h}", count=1)
    a = alerts_for(run_analysis(write_capture(builder), settings), "R7")
    assert len(a) == 1                                        # replies from 60 hosts are not flagged
    assert a.iloc[0]["src_ip"] == SCANNER and "ping sweep" in a.iloc[0]["reason"]


# ------------------------------------------------------------------ Rule 8
def test_retransmission_rule(builder, write_capture, settings):
    ex = [("c" if i % 2 else "s", b"y" * 800) for i in range(40)]
    builder.tcp_session(T0, LAN_CLIENT, LAN_SERVER, 445, ex, retransmit_every=3)
    a = alerts_for(run_analysis(write_capture(builder), settings), "R8")
    assert len(a) == 1 and "retransmissions" in a.iloc[0]["reason"]


# ------------------------------------------------------------------ Rule 10
def test_external_communication_rules(builder, write_capture, settings):
    builder.tcp_session(T0, LAN_CLIENT, "203.0.113.66", 4444, [("c", b"x")])
    builder.tcp_session(T0 + 1, LAN_CLIENT, "203.0.113.10", 443, [("c", b"x")])       # allowed port
    builder.tcp_session(T0 + 2, LAN_CLIENT, "198.51.100.7", 80, [("c", b"x")])
    settings["external_rules"]["watched_external_networks"] = ["198.51.100.0/24"]
    a = alerts_for(run_analysis(write_capture(builder), settings), "R10")
    assert set(zip(a["dst_ip"], a["severity"])) >= {("203.0.113.66", "Low"), ("198.51.100.7", "Medium")}
    assert "203.0.113.10" not in a["dst_ip"].tolist()
    settings["external_rules"]["allowed_external_networks"] = ["203.0.113.0/24"]
    settings["external_rules"]["watched_external_networks"] = []
    builder2 = type(builder)(seed=2)
    builder2.tcp_session(T0, LAN_CLIENT, "203.0.113.66", 4444, [("c", b"x")])
    assert "R10" not in rules(run_analysis(write_capture(builder2, "b.pcap"), settings))


# ------------------------------------------------------------------ engine behaviour
def test_mixed_demo_triggers_all_rules(sample_dir, settings):
    r = run_analysis(sample_dir / "mixed_demo.pcapng", settings)
    assert rules(r) == sorted(["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "R10"], key=str)
    a = r.alerts
    assert a["alert_id"].is_unique and a["alert_id"].iloc[0] == "ALERT-0001"
    required = ["alert_id", "detection", "src_ip", "dst_ip", "port", "time_range", "event_count", "severity",
                "reason", "recommendation"]
    assert all(c in a.columns for c in required)
    assert a["reason"].str.len().min() > 20 and a["recommendation"].str.len().min() > 20
    assert set(a["severity"]) <= {"Low", "Medium", "High", "Critical"}


def test_rules_can_be_disabled(sample_dir, settings):
    settings["rules_enabled"] = {k: False for k in settings["rules_enabled"]}
    assert run_analysis(sample_dir / "mixed_demo.pcapng", settings).alerts.empty


def test_failing_rule_does_not_stop_others(sample_dir, settings, monkeypatch):
    import detection.anomaly_detector as ad

    def broken(ctx):
        raise RuntimeError("boom")
    monkeypatch.setitem(ad.ALL_RULES, "R1", broken)
    r = run_analysis(sample_dir / "port_scan.pcap", settings)
    assert any("boom" in e for e in r.detection_errors)
    assert "R7" in rules(r)


def test_empty_input():
    import pandas as pd
    assert AnomalyDetector().run(pd.DataFrame(), pd.DataFrame()).empty


def test_scale_severity():
    assert scale_severity("Low", 1, 1) == "Low"
    assert scale_severity("Low", 3, 1) == "Medium"
    assert scale_severity("Medium", 10, 1) == "Critical"
    assert scale_severity("High", 100, 1) == "Critical"
