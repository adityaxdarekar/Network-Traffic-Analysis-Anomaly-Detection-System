"""Tests for PDF report generation (test case 10) and the SQLite database."""

from __future__ import annotations

import pytest

from analyzer.pipeline import run_analysis
from database.db_manager import DatabaseManager
from reports.pdf_generator import generate_pdf_report
from utils import pcap_writer as pw


def _pdf_text(path):
    pypdf = pytest.importorskip("pypdf")
    reader = pypdf.PdfReader(str(path))
    return len(reader.pages), "\n".join(page.extract_text() for page in reader.pages)


def test_pdf_report_with_alerts(sample_dir, tmp_path):
    r = run_analysis(sample_dir / "mixed_demo.pcapng")
    out = generate_pdf_report(r, tmp_path / "report.pdf", analyst="Test Student")
    assert out.exists() and out.read_bytes()[:4] == b"%PDF"
    pages, text = _pdf_text(out)
    assert pages >= 10
    for heading in ("Table of Contents", "Executive Summary", "Capture File Information", "Analysis Methodology",
                    "DNS Analysis", "HTTP and HTTPS/TLS Analysis", "TCP and UDP Analysis",
                    "IP Address Investigation", "Anomaly Detection Results", "Alert Details",
                    "Security Recommendations", "Conclusion"):
        assert heading in text, heading
    assert "mixed_demo.pcapng" in text and "Test Student" in text
    assert f"{r.summary['total_packets']:,}" in text            # real numbers, not placeholders
    assert "ALERT-0001" in text and "Page 3 of" in text


def test_pdf_report_without_alerts_and_with_screenshot(sample_dir, tmp_path):
    r = run_analysis(sample_dir / "normal_traffic.pcapng")
    shot = tmp_path / "shot.png"
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.figure(figsize=(2, 1))
    plt.savefig(shot)
    plt.close("all")
    out = generate_pdf_report(r, tmp_path / "r.pdf", screenshots=[shot])
    _, text = _pdf_text(out)
    assert "No alerts were generated" in text and "Screenshots" in text


def test_pdf_report_for_empty_capture(tmp_path):
    p = tmp_path / "empty.pcapng"
    pw.PcapngWriter(p).close()
    out = generate_pdf_report(run_analysis(p), tmp_path / "e.pdf")
    assert out.stat().st_size > 1000


def test_database_roundtrip(sample_dir, tmp_path):
    db = DatabaseManager(tmp_path / "t.db")
    r = run_analysis(sample_dir / "port_scan.pcap")
    sid = db.save_analysis(r)
    db.add_report(sid, "x.pdf", "2026-11-05 10:00:00", 12)
    sessions = db.list_sessions()
    assert len(sessions) == 1 and sessions.iloc[0]["packet_count"] == r.summary["total_packets"]
    s = db.get_session(sid)
    assert s["alert_count"] == len(r.alerts) == len(s["alerts"])
    assert dict(zip(s["protocol_stats"]["protocol"], s["protocol_stats"]["packets"])) == r.protocol_counts
    assert len(s["reports"]) == 1 and s["severity_counts"] == r.summary["severity_counts"]
    db.save_analysis(r)                                 # saving again replaces, does not duplicate
    assert len(db.list_sessions()) == 1
    db.delete_session(sid)
    assert db.list_sessions().empty and db.get_session(sid) is None


def test_database_has_no_payloads(sample_dir, tmp_path):
    db = DatabaseManager(tmp_path / "t.db")
    db.save_analysis(run_analysis(sample_dir / "normal_traffic.pcapng"))
    import sqlite3
    con = sqlite3.connect(tmp_path / "t.db")
    tables = [t for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    assert "packets" not in tables
    con.close()
