"""A stand-in for tshark used by the unit tests (no real capture happens).

It understands just enough arguments: -i <iface>, -a duration:N, -w <file>.
It copies a synthetic sample capture to the output file and then waits
until the duration ends or it is interrupted (Ctrl+C / SIGINT).
"""
import shutil
import signal
import sys
import time
from pathlib import Path

args = sys.argv[1:]
iface = args[args.index("-i") + 1] if "-i" in args else ""
if iface == "bad0":
    sys.stderr.write("tshark: The capture session could not be initiated on interface 'bad0' (No such device).\n")
    sys.exit(2)
if iface == "denied0":
    sys.stderr.write("tshark: You don't have permission to capture on that device.\n")
    sys.exit(2)
out = Path(args[args.index("-w") + 1])
duration = int(args[args.index("-a") + 1].split(":")[1]) if "-a" in args else 5
shutil.copy(Path(__file__).resolve().parent.parent / "sample_data" / "normal_traffic.pcapng", out)
stop = False
def handler(*_):
    global stop
    stop = True
signal.signal(signal.SIGINT, handler)
end = time.time() + duration
while time.time() < end and not stop:
    time.sleep(0.05)
sys.exit(0)
