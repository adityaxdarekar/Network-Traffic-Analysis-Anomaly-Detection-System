"""Shared pytest fixtures. All test traffic is synthetic (built with utils/pcap_writer.py)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import default_settings  # noqa: E402
from utils.pcap_writer import TrafficBuilder  # noqa: E402

T0 = 1_780_000_000.0   # fixed timestamp so results are reproducible

LAN_CLIENT = "192.168.1.23"
LAN_SERVER = "192.168.1.10"
GATEWAY = "192.168.1.1"


@pytest.fixture
def settings():
    return default_settings()


@pytest.fixture
def builder():
    return TrafficBuilder(seed=1)


@pytest.fixture
def write_capture(tmp_path):
    """Return a function that writes a TrafficBuilder to tmp_path/<name> and returns the path."""
    def _write(b: TrafficBuilder, name: str = "test.pcap") -> Path:
        path = tmp_path / name
        b.write(path)
        return path
    return _write


@pytest.fixture
def basic_capture(builder, write_capture):
    """A small mixed capture: DNS, HTTPS, HTTP, ping, ARP, NTP."""
    b = builder
    b.add_arp(T0, LAN_CLIENT, GATEWAY)
    b.add_arp(T0 + 0.001, GATEWAY, LAN_CLIENT, reply=True)
    b.dns_lookup(T0 + 1, LAN_CLIENT, GATEWAY, "www.example.com", "A", answers=[("A", "203.0.113.10")])
    b.https_visit(T0 + 1.1, LAN_CLIENT, "203.0.113.10", "www.example.com")
    b.http_visit(T0 + 3, LAN_CLIENT, "198.51.100.80", "intranet.example.edu", "/page?token=SECRET123")
    b.ping(T0 + 5, LAN_CLIENT, GATEWAY, count=3)
    b.add_udp(T0 + 6, LAN_CLIENT, "192.0.2.123", 50000, 123, b"\x23" + b"\x00" * 47)
    return write_capture(b, "basic.pcap")


@pytest.fixture
def sample_dir():
    return ROOT / "sample_data"
