# 🛡️ Network Traffic Analysis and Anomaly Detection System
### Using Python and Wireshark

A defensive, SOC-style (Security Operations Center) tool that **captures**, **analyses**, **visualises** and
**reports on** network traffic, and flags potentially suspicious behaviour with ten transparent,
configurable detection rules.

> ⚠️ **Ethics first.** Only capture or analyse traffic on networks and devices that you own or have explicit
> permission to monitor. Everything in this project runs locally; nothing is sent to the Internet.

---

## Table of contents
1. [Introduction](#1-introduction)
2. [Objectives](#2-objectives)
3. [Features](#3-features)
4. [Technology stack](#4-technology-stack)
5. [Architecture](#5-architecture)
6. [Prerequisites](#6-prerequisites)
7. [Installation](#7-installation)
8. [Dependency installation](#8-dependency-installation)
9. [Wireshark installation](#9-wireshark-installation)
10. [Npcap installation](#10-npcap-installation)
11. [TShark configuration](#11-tshark-configuration)
12. [Running the application](#12-running-the-application)
13. [Dashboard usage](#13-dashboard-usage)
14. [PCAP upload instructions](#14-pcap-upload-instructions)
15. [PDF report generation](#15-pdf-report-generation)
16. [Running the tests](#16-running-the-tests)
17. [Troubleshooting](#17-troubleshooting)
18. [Limitations](#18-limitations)
19. [Future improvements](#19-future-improvements)
20. [Project structure](#20-project-structure)

---

## 1. Introduction
Every device on a network constantly exchanges packets: DNS look-ups, web requests, encrypted HTTPS
sessions, pings, and so on. Security analysts inspect this traffic to understand what is normal and to
spot activity that deserves a closer look - for example a host scanning many ports, a burst of unanswered
connection requests, or DNS queries that look like data is being smuggled out.

This project is a simplified SOC network-monitoring tool. It reads packet captures (`.pcap` / `.pcapng`)
produced by Wireshark/TShark (or records them itself), decodes every packet's metadata, builds statistics
per protocol and per IP address, runs rule-based anomaly detection, stores the results in SQLite and shows
everything in an interactive Streamlit dashboard, with one-click PDF reports.

## 2. Objectives
1. Capture network packets (TShark, with Scapy as a fallback).
2. Read PCAP and PCAPNG files - robustly, even when truncated or containing malformed packets.
3. Identify DNS, HTTP, HTTPS/TLS, TCP, UDP, ICMP and ARP traffic.
4. Extract source/destination IP addresses and ports.
5. Identify the most frequently contacted IP addresses.
6. Analyse packet sizes and traffic volume over time.
7. Identify unusual ports and communication patterns.
8. Detect potentially suspicious behaviour with transparent, rule-based detection.
9. Visualise network activity in an interactive dashboard.
10. Automatically generate detailed PDF reports.

## 3. Features
| Area | What you get |
|---|---|
| **Live capture** | Interface list, start/stop, duration, packet limit, optional BPF filter, live packet counter, permission checks and a mandatory "I am authorised" confirmation |
| **File analysis** | `.pcap`, `.pcapng`, `.cap`; signature validation; streaming reader; handles empty, truncated and malformed captures; configurable packet limit for very large files |
| **Protocol decoding** | Ethernet (+VLAN), Linux cooked, Npcap loopback, raw IP, ARP, IPv4, IPv6, TCP, UDP, ICMP/ICMPv6, DNS (UDP & TCP), HTTP/1.x, TLS ClientHello/ServerHello (version + SNI), QUIC detection |
| **DNS analysis** | Query/response tables, A/AAAA/MX/TXT/CNAME/NS counts, failed responses, unanswered queries, response time, repeated requests, per-host volume, transparent "unusual name" heuristics, sub-domain diversity |
| **HTTP / TLS** | Methods, hosts, paths (query string removed), status codes, User-Agents, request rate; TLS versions offered/negotiated, SNI, destinations & connection frequency, legacy-TLS warning. HTTPS is **never decrypted** |
| **TCP / UDP** | SYN, SYN-ACK, ACK, FIN, RST counts; connection reconstruction & states; failed connections; retransmissions; durations; UDP conversations, ports and rates |
| **IP investigation** | Unique IPv4/IPv6 addresses, private/public/loopback/multicast/link-local/reserved classification, packets & bytes per host, top talkers, conversations, communication patterns, optional **offline** reputation (local watch-list + links you may open manually) |
| **Anomaly detection** | 10 rules (below), configurable thresholds, enable/disable, base severity per rule, automatic severity scaling, explanation + evidence + investigation steps for every alert |
| **Dashboard** | 12-page dark SOC interface, KPI cards, Plotly charts, filters, search, packet detail view, optional IP masking for screenshots |
| **Reports** | Professional PDF (cover, table of contents, page numbers, tables, charts, screenshots, recommendations), CSV/ZIP/JSON exports |
| **History** | SQLite database of previous sessions (statistics and alerts only - no payloads) |

### The ten detection rules
| ID | Rule | Logic (all thresholds configurable) |
|---|---|---|
| R1 | Possible Port Scanning | One source → ≥ 20 distinct ports on one target within 60 s (TCP SYN and UDP separately) |
| R2 | Possible SYN Flood Pattern | ≥ 100 SYNs to one destination within 10 s and ≥ 80 % got **no reply at all**; severity lowered if the capture has no SYN-ACKs anywhere (probably one-direction capture) |
| R3 | DNS Query Anomaly | Per host: ≥ 200 queries, ≥ 100 distinct domains, or ≥ 60 queries within 60 s |
| R4 | Repeated Connection Attempts | ≥ 15 SYNs to the same IP:port with ≥ 50 % failing (or ≥ 75 even if successful) |
| R5 | Unusual Traffic Volume | Host bytes > 5× the median host and ≥ 5 MB; or 1-second spikes > 5× median and ≥ 100 packets |
| R6 | Unusual Destination Port | Traffic to ports on an editable watch-list (Telnet, FTP, RDP, SMB, 4444, ...) |
| R7 | ICMP Traffic Anomaly | ≥ 50 ICMP packets (echo replies excluded) from one host within 10 s; notes ping sweeps |
| R8 | High TCP Retransmission Rate | ≥ 10 % retransmissions in a conversation with ≥ 50 TCP packets |
| R9 | Possible DNS Tunneling Indicators | ≥ 30 distinct sub-domains of one domain and most names long/random-looking or TXT queries |
| R10 | Unusual External Communication | Watched external networks; internal hosts connecting out on non-allowed ports; ≥ 50 MB sent to one external host; allow-listed networks ignored |

Severity starts at the rule's base level and is raised one level at 3× the threshold and two levels at 10×.
**Alerts are heuristic indicators, never "confirmed attacks".**

## 4. Technology stack
| Purpose | Technology |
|---|---|
| Language | Python 3.11+ |
| Capture | Wireshark / **TShark** (via `subprocess`), **Npcap** on Windows, **Scapy** fallback |
| Packet analysis | Built-in streaming PCAP/PCAPNG reader and protocol decoders (`analyzer/`), optional Scapy reader, Python `ipaddress`/`struct` |
| Data | pandas |
| Dashboard | Streamlit + Plotly |
| PDF reports | ReportLab + Matplotlib (static charts) |
| Storage | SQLite (`sqlite3`, built into Python) |
| Tests | pytest |

**Why a built-in packet reader?** It streams packets one at a time (low memory), never crashes on corrupt
files, is about 30,000+ packets/second on a normal laptop, and lets the whole analysis engine and test suite
run even on a computer without Wireshark. Scapy can still be selected as the reading engine
(`run_analysis(path, engine="scapy")`). PyShark is **not required**: TShark is called directly, which is
simpler and faster; it is listed as optional in `requirements.txt`.

## 5. Architecture
```
NETWORK INTERFACE
       │
WIRESHARK / TSHARK  (capture/packet_capture.py, capture/interface_manager.py; Scapy fallback)
       │
PACKET CAPTURE (.pcap / .pcapng)  ── or ──  file upload
       │
PYTHON PACKET ANALYSIS ENGINE  (analyzer/pcap_reader.py, analyzer/decoders.py, analyzer/packet_analyzer.py)
       │
       ├──────────────────────────────┐
PROTOCOL ANALYSIS                  IP ANALYSIS
dns_analyzer · http_analyzer       ip_analyzer · ip_reputation
tls_analyzer · tcp_analyzer
udp_analyzer
       └──────────────┬───────────────┘
              ANOMALY DETECTION  (detection/detection_rules.py, detection/anomaly_detector.py)
                      │
              DATABASE STORAGE  (database/db_manager.py → output/analysis_history.db)
                      │
              STREAMLIT DASHBOARD  (app.py, dashboard/*.py)
                      │
              PDF REPORT GENERATOR  (reports/pdf_generator.py, reports/charts.py)
```
`analyzer/pipeline.py` ties the stages together and returns one `AnalysisResult` object that the dashboard,
the database and the PDF report all use - so every number shown anywhere comes from the same analysis.

## 6. Prerequisites
* Windows 10 or 11 (Linux/macOS also work)
* **Python 3.11 or newer** - <https://www.python.org/downloads/> (tick **"Add python.exe to PATH"**)
* 4 GB RAM (8 GB recommended for captures above ~1 million packets)
* **Wireshark with TShark and Npcap** - only needed for *live capture*. Uploading/analysing existing files
  works without it.
* A modern browser (Edge, Chrome, Firefox)

## 7. Installation
Open **PowerShell** or **Command Prompt** in the folder where you unzipped the project:

```powershell
cd network-traffic-analysis

# 1. Create a virtual environment (an isolated Python for this project)
py -3.11 -m venv venv            # or: python -m venv venv

# 2. Activate it
venv\Scripts\activate            # Command Prompt / PowerShell
# If PowerShell refuses ("running scripts is disabled"), run this once, then activate again:
#   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned

# 3. Install the dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt
```
Shortcut: double-click **`setup_windows.bat`**, which runs exactly these steps.

## 8. Dependency installation
`requirements.txt` contains:

| Package | Why |
|---|---|
| `streamlit` (≥ 1.50) | web dashboard |
| `plotly` | interactive charts |
| `pandas` | tables and statistics |
| `scapy` | interface discovery + fallback capture engine |
| `reportlab` | PDF generation |
| `matplotlib` | charts inside the PDF |
| `pytest` | unit tests |

If one package fails to install (e.g. no Internet on a lab PC), the analysis engine still works for
everything except that feature: without Scapy, live capture uses TShark only; without Streamlit/Plotly the
engine can still be used from Python and the tests still run.

## 9. Wireshark installation
1. Download the Windows installer from <https://www.wireshark.org/download.html>.
2. Run it. On the **Choose Components** page make sure **TShark** is ticked.
3. When asked, **install Npcap** (next section) - Wireshark cannot capture on Windows without it.
4. Finish and restart the computer if asked.

Check it worked (new terminal):
```powershell
"C:\Program Files\Wireshark\tshark.exe" --version
```

## 10. Npcap installation
Npcap is the Windows packet-capture driver. The Wireshark installer offers it; you can also download it
from <https://npcap.com/#download>.

During setup:
* ✅ **"Install Npcap in WinPcap API-compatible Mode"** - recommended (helps Scapy).
* ⬜ **"Restrict Npcap driver's access to Administrators only"** - leave **unticked** so that you do *not*
  need to run as Administrator. If you tick it, you must start the terminal with *Run as administrator*
  before launching the app.
* ✅ "Support loopback traffic" - lets you capture traffic to `127.0.0.1`.

## 11. TShark configuration
The application finds TShark automatically in this order:
1. The `TSHARK_PATH` environment variable,
2. your `PATH`,
3. `C:\Program Files\Wireshark\tshark.exe` (and the x86 folder).

Optional - add Wireshark to PATH so you can type `tshark` anywhere:
*Start → "Edit the system environment variables" → Environment Variables → Path → Edit → New →*
`C:\Program Files\Wireshark` → OK. Open a new terminal and run `tshark -D` - it should list your
interfaces (Wi-Fi, Ethernet, ...).

Custom location example:
```powershell
setx TSHARK_PATH "D:\Tools\Wireshark\tshark.exe"
```
The **Live Capture → Capture environment** panel shows what the app detected (TShark version, Scapy,
Npcap, admin rights).

## 12. Running the application
```powershell
cd network-traffic-analysis
venv\Scripts\activate
streamlit run app.py
```
Your browser opens <http://localhost:8501>. (Shortcut: double-click **`run_app.bat`**.) Stop the server with
**Ctrl + C** in the terminal.

The five demo captures in `sample_data/` are already included. To re-create them:
```powershell
python sample_data\generate_samples.py
```

## 13. Dashboard usage
| Page | Use it to |
|---|---|
| 📊 Overview | KPIs (packets, unique IPs, DNS queries, HTTP requests, TCP connections, UDP packets, alerts) and charts: protocol mix, top sources/destinations, traffic over time, top domains, alert severity |
| 📡 Live Capture | Pick an interface, set duration/packet limit/filter, confirm authorisation, Start/Stop, watch the counter, then **Analyse this capture** |
| 📁 Upload PCAP | Upload a file or load a sample; analysis starts automatically |
| 🌐 DNS Analysis | Query table (searchable), top domains, query types, response codes, failures, repeated requests, unusual names |
| 🔒 HTTP/TLS Analysis | Clear-text HTTP requests vs. encrypted TLS metadata (versions, SNI, destinations) |
| 🔌 TCP/UDP Analysis | Flags, connection states, failed connections, retransmissions, ports, UDP conversations, limitations |
| 🧭 IP Investigation | All hosts with category and traffic, filter by IP/category, drill into one IP, offline reputation check |
| 🚨 Anomaly Detection | Alert counts by severity, filters (severity, detection, IP), full explanation and investigation steps |
| 🔎 Packet Explorer | Filter by source/destination IP, protocol, port, length, text; detailed per-packet view |
| 📄 Reports | Generate/download the PDF, export CSV/ZIP/JSON, browse/delete previous sessions |
| ⚙️ Settings | Thresholds, enable/disable rules, base severities, port watch-list, external-network rules, capture defaults, IP masking |
| ℹ️ About Project | Architecture and privacy principles |

Tip: turn on **Settings → Mask IP addresses** before taking screenshots for a public portfolio.

## 14. PCAP upload instructions
1. Open **📁 Upload PCAP**.
2. Click **Browse files** and choose a `.pcap`, `.pcapng` or `.cap` file (max 500 MB, configurable in
   `.streamlit/config.toml` and `config.py`).
3. The file is validated by its *signature* (not just its name). Invalid files are rejected with a clear message.
4. Analysis runs automatically; you see the file name, size, packet count, alert count and analysis time.
5. Click **Open the Overview dashboard**.

To make your own capture in Wireshark: *Capture → choose interface → Start*, browse a few websites,
*Stop*, then *File → Save As* (`.pcapng`). Or with TShark:
```powershell
tshark -D                                   # list interfaces
tshark -i 1 -a duration:30 -w mycapture.pcapng
```

## 15. PDF report generation
1. Analyse a capture.
2. Go to **📄 Reports → PDF report**.
3. Optionally type your name and pick screenshots (any `.png`/`.jpg` placed in the `screenshots/` folder).
4. Click **Generate PDF report**, then **Download PDF report**.

The PDF (saved in `output/reports/`) contains a cover page, table of contents, page numbers, executive
summary, file information with SHA-256, methodology with the exact thresholds used, protocol/DNS/HTTP/TLS/
TCP/UDP/IP sections with tables and charts, all alerts with evidence and investigation steps, security
recommendations and a conclusion - all generated from the real analysis.

## 16. Running the tests
```powershell
venv\Scripts\activate
python -m pytest            # or double-click run_tests.bat
```
95 tests cover PCAP/PCAPNG reading, DNS/HTTP/TLS/TCP/UDP extraction, IP classification, every detection
rule (positive and negative cases), PDF generation, the database, the capture module (using a fake TShark
script) and a headless smoke test of all 12 dashboard pages. Edge cases: empty and zero-byte files, invalid
formats, truncated captures, malformed packets, unsupported link types, a 50,000-packet capture, no alerts,
and missing TShark. All test traffic is synthetic.

## 17. Troubleshooting
| Problem | Fix |
|---|---|
| `'python' is not recognized` | Reinstall Python and tick "Add python.exe to PATH", or use `py` instead of `python` |
| PowerShell: *running scripts is disabled* | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, then `venv\Scripts\activate` again |
| `streamlit` not recognized | Activate the venv first, or run `python -m streamlit run app.py` |
| Live Capture says TShark not found | Install Wireshark with TShark, or set `TSHARK_PATH` (section 11), then press *Re-check environment* |
| "No interfaces" / empty list | Install Npcap; reboot; run `tshark -D` in a terminal to test |
| "Permission denied" when capturing | Npcap was installed with *admin-only* access → run the terminal as Administrator, or reinstall Npcap without that option |
| 0 packets captured | Wrong interface (pick the one marked Wi-Fi/Ethernet), or nothing happened on the network - open a website during the capture |
| Upload rejected "does not look like a PCAP" | The file is not a capture (e.g. a renamed text file) or is a different format (e.g. `.etl`). Re-save it in Wireshark as pcapng |
| Very large file is slow / runs out of memory | Lower *Settings → Maximum packets to analyse*, or split the file with `editcap -c 500000 big.pcapng part.pcapng` |
| Too many alerts on my network | Raise thresholds or disable rules on the Settings page - each network has its own normal |
| Port 8501 in use | `streamlit run app.py --server.port 8502` |

## 18. Limitations
* **Encrypted traffic**: HTTPS/QUIC content is invisible by design; only handshake metadata is analysed.
  TLS 1.3 *Encrypted Client Hello* hides the SNI as well.
* **Capture completeness**: packets dropped by the capturing machine, captures started mid-connection or
  one-direction (asymmetric) captures can make normal connections look failed or retransmitted.
* **Heuristics, not verdicts**: rules use thresholds; they can produce false positives (e.g. a backup job,
  a vulnerability scanner you own) and miss slow or well-disguised attacks.
* **Protocol coverage**: HTTP/2 and HTTP/3 are encrypted in practice; SMB, SSH, etc. are classified as TCP
  by port only; IP fragments are not reassembled; TCP streams are not reassembled (an HTTP header split
  across segments may be missed).
* **Scale**: designed for laptop-sized captures (up to a few million packets); it is not a 24/7 IDS.
* **No threat intelligence feed**: the optional reputation check is offline by design.
* **Live capture on Windows** requires Npcap; on Linux it requires root or the `wireshark` group.

## 19. Future improvements
* Statistical / machine-learning baselines learned from the user's own normal traffic.
* TCP stream reassembly and more application parsers (SMB, SSH banners, SMTP).
* JA3/JA4 TLS fingerprints.
* Optional, opt-in threat-intelligence integration (e.g. AbuseIPDB API key) and GeoIP maps.
* Continuous ring-buffer capture with scheduled analysis and e-mail alerts.
* Export alerts in standard formats (Sigma, STIX) or to a SIEM (Elastic, Splunk).
* Multi-user authentication for shared deployments.

## 20. Project structure
```
network-traffic-analysis/
├── app.py                     Streamlit entry point (sidebar navigation)
├── config.py                  all settings, thresholds, paths
├── requirements.txt · pytest.ini · .streamlit/config.toml
├── setup_windows.bat · run_app.bat · run_tests.bat
├── README.md · PROJECT_DOCUMENTATION.md · DEMO_GUIDE.md · PROJECT_STATUS.md
├── capture/      interface_manager.py, packet_capture.py
├── analyzer/     pcap_reader.py, decoders.py, packet_analyzer.py, pipeline.py,
│                 dns_analyzer.py, http_analyzer.py, tls_analyzer.py, tcp_analyzer.py,
│                 udp_analyzer.py, ip_analyzer.py, ip_reputation.py
├── detection/    detection_rules.py (10 rules), anomaly_detector.py
├── dashboard/    theme.py, common.py, actions.py and one module per page (12 pages)
├── reports/      pdf_generator.py, charts.py
├── database/     db_manager.py
├── utils/        helpers.py, validators.py, pcap_writer.py (synthetic traffic builder)
├── tests/        95 pytest tests + fake_tshark.py + streamlit_stub.py
├── sample_data/  5 synthetic captures, generate_samples.py, local_watchlist.txt
├── output/       captures/, uploads/, reports/, analysis_history.db (created at runtime)
└── screenshots/  put dashboard screenshots here (they can be added to PDF reports)
```
