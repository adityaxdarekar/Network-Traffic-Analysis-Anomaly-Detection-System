# Screenshots

Screenshots of the running application must be taken on your own computer (they show the real app as it
runs for you). Suggested set for the documentation and portfolio:

| File name | What to capture |
|---|---|
| `01_overview.png` | Overview page with `mixed_demo.pcapng` loaded |
| `02_upload.png` | Upload PCAP page after a successful analysis |
| `03_live_capture.png` | Live Capture page with the environment panel and a finished capture |
| `04_dns.png` | DNS Analysis → Unusual DNS behaviour tab |
| `05_http_tls.png` | HTTP/TLS Analysis, HTTPS tab (versions + SNI) |
| `06_tcp_udp.png` | TCP/UDP Analysis with connection states |
| `07_ip.png` | IP Investigation with one address selected |
| `08_alerts.png` | Anomaly Detection with an alert expanded |
| `09_packet_explorer.png` | Packet Explorer with a packet detail view |
| `10_report.png` | First pages of the generated PDF |
| `11_tests.png` | Terminal showing `95 passed` |

How: Windows key + Shift + S (Snipping Tool) → save the image into this folder.
Tip: enable **Settings → Mask IP addresses** first if the screenshot shows your real network.

Images placed here can be selected on **Reports → PDF report** to be included in the report.
