"""
Professional PDF report generation with ReportLab.

Every number, table and chart in the report comes from the AnalysisResult
that the dashboard shows - nothing is invented. Sections:

    Cover page · Table of contents · 1 Executive summary · 2 Capture file
    information · 3 Methodology · 4 Traffic overview · 5 DNS · 6 HTTP &
    HTTPS/TLS · 7 TCP/UDP · 8 IP investigation · 9 Anomaly detection results
    · 10 Alert details · 11 Screenshots (if supplied) · 12 Security
    recommendations · 13 Conclusion
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Frame, Image, KeepTogether, NextPageTemplate,
                                PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle)
from reportlab.platypus.tableofcontents import TableOfContents

from config import APP_TITLE, APP_VERSION, REPORT_DIR, RULE_NAMES, SEVERITY_COLORS, SEVERITY_ORDER
from detection.detection_rules import describe_rules
from reports.charts import build_report_charts
from utils.helpers import file_sha256, human_bytes, ts_to_str

NAVY = colors.HexColor("#0b1f3a")
BLUE = colors.HexColor("#2563eb")
CYAN = colors.HexColor("#06b6d4")
LIGHT = colors.HexColor("#f1f5f9")
BORDER = colors.HexColor("#cbd5e1")
TEXT = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#64748b")

PAGE_W, PAGE_H = A4
MARGIN = 2 * cm
CONTENT_W = PAGE_W - 2 * MARGIN

RULE_RECOMMENDATIONS = {
    "R1": "Review which services are exposed on scanned hosts; close unused ports and confirm whether the scanning "
          "device was authorised (e.g. an IT vulnerability scanner).",
    "R2": "Confirm the availability of the targeted service at that time; enable SYN cookies / connection rate "
          "limiting on servers and firewalls if floods recur.",
    "R3": "Identify the process responsible for bursts of DNS lookups on the reported host and compare with its "
          "normal behaviour.",
    "R4": "Check whether the destination service is down or blocked; if it is a login service, review its "
          "authentication logs for repeated failures.",
    "R5": "Attribute large transfers to an application (backups, updates, streaming) and confirm they are expected.",
    "R6": "Disable clear-text and remote-access services that are not required (Telnet, FTP, RDP, SMB exposed "
          "beyond the LAN) or restrict them with firewall rules.",
    "R7": "Determine whether ping sweeps or ICMP bursts came from monitoring tools; restrict ICMP at the perimeter "
          "if not needed.",
    "R8": "Investigate network quality on the affected path (Wi-Fi interference, congestion, faulty cabling, "
          "overloaded server).",
    "R9": "Investigate the base domain and the querying process; consider DNS filtering and logging of DNS "
          "queries at the resolver.",
    "R10": "Maintain an allow-list of expected external services and review outbound connections on unusual ports "
           "or with large upload volumes.",
}

GENERAL_RECOMMENDATIONS = [
    "Treat every alert as a lead for investigation, not as proof of an attack; correlate with host logs.",
    "Prefer encrypted protocols (HTTPS, SSH, SFTP) over clear-text ones (HTTP, Telnet, FTP).",
    "Keep operating systems, browsers and router firmware up to date.",
    "Tune the detection thresholds on the Settings page to match this network's normal baseline.",
    "Only capture traffic on networks you own or are explicitly authorised to monitor, and store captures securely.",
]


# ---------------------------------------------------------------------------
# Styles
# ---------------------------------------------------------------------------
def _styles():
    ss = getSampleStyleSheet()
    s = {
        "body": ParagraphStyle("body", parent=ss["BodyText"], fontName="Helvetica", fontSize=9.5, leading=13.5,
                               textColor=TEXT, spaceAfter=6),
        "small": ParagraphStyle("small", parent=ss["BodyText"], fontName="Helvetica", fontSize=8, leading=10.5,
                                textColor=MUTED),
        "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=7.6, leading=9.6, textColor=TEXT),
        "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=7.6, leading=9.6, textColor=colors.white),
        "h1": ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=16, leading=20,
                             textColor=NAVY, spaceBefore=6, spaceAfter=10),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=11.5, leading=15,
                             textColor=BLUE, spaceBefore=10, spaceAfter=5),
        "bullet": ParagraphStyle("bullet", parent=ss["BodyText"], fontName="Helvetica", fontSize=9.5, leading=13,
                                 textColor=TEXT, leftIndent=12, bulletIndent=2, spaceAfter=3),
        "cover_title": ParagraphStyle("ct", fontName="Helvetica-Bold", fontSize=24, leading=30,
                                      textColor=colors.white),
        "cover_sub": ParagraphStyle("cs", fontName="Helvetica", fontSize=13, leading=18, textColor=CYAN),
        "cover_meta": ParagraphStyle("cm", fontName="Helvetica", fontSize=10, leading=15,
                                     textColor=colors.HexColor("#cbd5e1")),
        "toc_title": ParagraphStyle("tt", fontName="Helvetica-Bold", fontSize=16, textColor=NAVY, spaceAfter=14),
        "center": ParagraphStyle("center", fontName="Helvetica", fontSize=9, alignment=TA_CENTER, textColor=MUTED),
    }
    return s


def fmt(value) -> str:
    """Render a table value; None / NaN / pandas NA become '-'."""
    try:
        if value is None or pd.isna(value):
            return "-"
    except (TypeError, ValueError):
        pass
    return str(value)


def p(text, style) -> Paragraph:
    return Paragraph(escape(str(text)) if text is not None else "-", style)


# ---------------------------------------------------------------------------
# Document template with TOC support and "Page X of Y"
# ---------------------------------------------------------------------------
class ReportDoc(BaseDocTemplate):
    def __init__(self, filename, **kw):
        super().__init__(filename, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=2.2 * cm,
                         bottomMargin=2 * cm, title=APP_TITLE, author="Network Traffic Analysis System", **kw)
        frame = Frame(MARGIN, 2 * cm, CONTENT_W, PAGE_H - 4.2 * cm, id="normal")
        cover_frame = Frame(MARGIN, MARGIN, CONTENT_W, PAGE_H - 2 * MARGIN, id="cover")
        self.addPageTemplates([PageTemplate(id="cover", frames=[cover_frame], onPage=_draw_cover_bg),
                               PageTemplate(id="content", frames=[frame], onPage=_draw_header_footer)])
        self.file_label = ""

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("h1", "h2"):
            level = 0 if flowable.style.name == "h1" else 1
            text = flowable.getPlainText()
            key = f"h{id(flowable)}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (level, text, self.page, key))


def _draw_cover_bg(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, 0, PAGE_W, PAGE_H, stroke=0, fill=1)
    canvas.setFillColor(CYAN)
    canvas.rect(0, PAGE_H - 1.1 * cm, PAGE_W, 0.25 * cm, stroke=0, fill=1)
    canvas.setFillColor(BLUE)
    canvas.rect(0, 0, PAGE_W, 0.6 * cm, stroke=0, fill=1)
    canvas.restoreState()


def _draw_header_footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(CYAN)
    canvas.setLineWidth(1.2)
    canvas.line(MARGIN, PAGE_H - 1.5 * cm, PAGE_W - MARGIN, PAGE_H - 1.5 * cm)
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(NAVY)
    canvas.drawString(MARGIN, PAGE_H - 1.3 * cm, "Network Traffic Analysis Report")
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 1.3 * cm, getattr(doc, "file_label", ""))
    canvas.restoreState()


class NumberedCanvasFactory:
    """Creates canvases that write 'Page X of Y' after all pages are known."""

    def __new__(cls, *args, **kwargs):
        from reportlab.pdfgen.canvas import Canvas

        class _NumberedCanvas(Canvas):
            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                self._saved = []

            def showPage(self):
                self._saved.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                total = len(self._saved)
                for state in self._saved:
                    self.__dict__.update(state)
                    if self._pageNumber > 1:                    # no number on the cover
                        self.setFont("Helvetica", 8)
                        self.setFillColor(MUTED)
                        self.drawRightString(PAGE_W - MARGIN, 1.2 * cm, f"Page {self._pageNumber} of {total}")
                        self.drawString(MARGIN, 1.2 * cm, "Heuristic findings - verify before acting")
                    super().showPage()
                super().save()

        return _NumberedCanvas(*args, **kwargs)


# ---------------------------------------------------------------------------
# Building blocks
# ---------------------------------------------------------------------------
def make_table(rows, header, col_widths=None, styles=None, max_rows: int | None = None, sev_col: int | None = None):
    """Build a zebra-striped table. ``rows`` is a list of lists (values become Paragraphs)."""
    s = styles
    total = len(rows)
    if max_rows is not None and total > max_rows:
        rows = rows[:max_rows]
    data = [[Paragraph(escape(str(h)), s["cellb"]) for h in header]]
    for r in rows:
        data.append([Paragraph(escape(fmt(v)), s["cell"]) for v in r])
    if col_widths is None:
        col_widths = [CONTENT_W / len(header)] * len(header)
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]
    if sev_col is not None:
        for i, r in enumerate(rows, start=1):
            color = SEVERITY_COLORS.get(str(r[sev_col]))
            if color:
                style.append(("BACKGROUND", (sev_col, i), (sev_col, i), colors.HexColor(color)))
    t.setStyle(TableStyle(style))
    out = [t]
    if max_rows is not None and total > max_rows:
        out.append(p(f"Showing {max_rows} of {total} rows. The full data is available as CSV from the dashboard.",
                     s["small"]))
    return out


def kv_table(pairs, styles, widths=(5.2 * cm, CONTENT_W - 5.2 * cm)):
    data = [[Paragraph(f"<b>{escape(str(k))}</b>", styles["cell"]), Paragraph(escape(fmt(v)), styles["cell"])]
            for k, v in pairs]
    t = Table(data, colWidths=list(widths))
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 3),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def chart(png: bytes, width=CONTENT_W) -> Image:
    img = Image(io.BytesIO(png))
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth, img.drawHeight = width, width * ratio
    return img


def kpi_strip(items, styles):
    cells = [[Paragraph(f"<font size=15 color='#2563eb'><b>{escape(str(v))}</b></font><br/>"
                        f"<font size=7.5 color='#64748b'>{escape(k)}</font>", styles["cell"]) for k, v in items]]
    t = Table(cells, colWidths=[CONTENT_W / len(items)] * len(items))
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.6, BORDER),
                           ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 7),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 7), ("LEFTPADDING", (0, 0), (-1, -1), 7)]))
    return t


def _bullets(lines, styles):
    return [Paragraph(escape(line), styles["bullet"], bulletText="•") for line in lines]


# ---------------------------------------------------------------------------
# Report sections
# ---------------------------------------------------------------------------
def _executive_summary(result) -> list[str]:
    s = result.summary
    sev = s["severity_counts"]
    lines = [
        f"The capture '{s['file_name']}' contains {s['total_packets']:,} packets ({human_bytes(s['total_bytes'])}) "
        f"recorded over {s['duration_sec']:.1f} seconds, involving {s['unique_ips']} unique IP addresses.",
    ]
    proto = sorted(((k, v) for k, v in result.protocol_counts.items() if v), key=lambda x: -x[1])
    if proto and s["total_packets"]:
        top = ", ".join(f"{k} {v / s['total_packets']:.0%}" for k, v in proto[:3])
        lines.append(f"The most common traffic classes were {top}.")
    if s["alert_count"]:
        parts = ", ".join(f"{sev[x]} {x}" for x in reversed(SEVERITY_ORDER) if sev.get(x))
        lines.append(f"The rule-based detection engine raised {s['alert_count']} alert(s): {parts}. These are "
                     f"heuristic indicators that warrant investigation; they are not confirmed attacks.")
        rules = result.alerts.drop_duplicates("rule_id").head(5)
        for a in rules.itertuples():
            lines.append(f"{a.severity}: {a.detection} - {a.reason.split('. ')[0]}.")
    else:
        lines.append("No detection rule exceeded its threshold for this capture. This does not prove the traffic "
                     "is benign - only that none of the configured heuristics matched.")
    if s["malformed_packets"]:
        lines.append(f"{s['malformed_packets']} packet(s) were malformed or truncated; available fields were used.")
    return lines


def _recommendations(result) -> list[str]:
    rules = list(dict.fromkeys(result.alerts["rule_id"])) if not result.alerts.empty else []
    recs = [f"{RULE_NAMES[r]}: {RULE_RECOMMENDATIONS[r]}" for r in rules if r in RULE_RECOMMENDATIONS]
    if result.http["request_count"]:
        recs.append(f"{result.http['request_count']} clear-text HTTP request(s) were observed; migrate these "
                    f"services to HTTPS where possible.")
    if not result.tls["legacy_tls"].empty:
        recs.append("Legacy TLS versions (1.1 or older) were negotiated/offered; disable them on servers and clients.")
    if result.dns["failed_count"]:
        recs.append(f"{result.dns['failed_count']} DNS lookups failed; check for typos, misconfiguration or "
                    f"software repeatedly resolving non-existent names.")
    return recs + GENERAL_RECOMMENDATIONS


def _conclusion(result) -> str:
    s = result.summary
    sev = s["severity_counts"]
    high = sev.get("High", 0) + sev.get("Critical", 0)
    if high:
        verdict = (f"{high} high or critical alert(s) were raised and should be investigated first, starting with "
                   f"the alert details in section 10.")
    elif s["alert_count"]:
        verdict = "Only low or medium severity alerts were raised; review them against the network's normal activity."
    else:
        verdict = "No heuristic alerts were raised for this capture with the current thresholds."
    return (f"This report analysed {s['total_packets']:,} packets from '{s['file_name']}' using transparent, "
            f"threshold-based rules on packet metadata only (no payload decryption). {verdict} Findings depend on "
            f"capture completeness and on the thresholds configured, so they should be confirmed with host logs "
            f"and the owners of the systems involved before any action is taken.")


def generate_pdf_report(result, output_path: str | Path | None = None, screenshots: list[str | Path] | None = None,
                        analyst: str = "", max_alert_details: int = 50) -> Path:
    """Create the PDF report for an AnalysisResult and return its path."""
    styles = _styles()
    s = result.summary
    stamp = datetime.now()
    if output_path is None:
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in Path(s["file_name"]).stem)[:40]
        output_path = REPORT_DIR / f"report_{safe}_{stamp:%Y%m%d_%H%M%S}.pdf"
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    charts = build_report_charts(result)

    doc = ReportDoc(str(output_path))
    doc.file_label = f"{s['file_name']} · session {result.session_id}"
    story = []

    # ---- Cover ----------------------------------------------------------
    story += [Spacer(1, 4 * cm),
              Paragraph("SECURITY OPERATIONS · NETWORK ANALYSIS", styles["cover_sub"]), Spacer(1, 0.4 * cm),
              Paragraph("Network Traffic Analysis and Anomaly Detection Report", styles["cover_title"]),
              Spacer(1, 0.6 * cm),
              Paragraph(escape(APP_TITLE) + " — using Python and Wireshark", styles["cover_meta"]),
              Spacer(1, 3 * cm)]
    meta = [("Capture file", s["file_name"]), ("Report generated", stamp.strftime("%Y-%m-%d %H:%M:%S")),
            ("Analysis session", result.session_id), ("Analysed at", result.analyzed_at),
            ("Packets analysed", f"{s['total_packets']:,}"), ("Alerts", f"{s['alert_count']}"),
            ("Software version", APP_VERSION)]
    if analyst:
        meta.insert(2, ("Analyst", analyst))
    for k, v in meta:
        story.append(Paragraph(f"<font color='#06b6d4'>{escape(k)}:</font>&nbsp;&nbsp;{escape(str(v))}",
                               styles["cover_meta"]))
    story += [Spacer(1, 2.5 * cm),
              Paragraph("Generated from real analysis of the supplied capture. Alerts are heuristic indicators, "
                        "not confirmed attacks. For authorised, defensive use only.", styles["cover_meta"]),
              NextPageTemplate("content"), PageBreak()]

    # ---- TOC ------------------------------------------------------------
    toc = TableOfContents()
    toc.levelStyles = [ParagraphStyle("toc1", fontName="Helvetica-Bold", fontSize=10.5, leading=17, textColor=NAVY),
                       ParagraphStyle("toc2", fontName="Helvetica", fontSize=9, leading=13, leftIndent=14,
                                      textColor=TEXT)]
    story += [Paragraph("Table of Contents", styles["toc_title"]), toc, PageBreak()]

    # ---- 1 Executive summary --------------------------------------------
    story.append(Paragraph("1. Executive Summary", styles["h1"]))
    sev = s["severity_counts"]
    story.append(kpi_strip([("Packets", f"{s['total_packets']:,}"), ("Data", human_bytes(s["total_bytes"])),
                            ("Unique IPs", s["unique_ips"]), ("Alerts", s["alert_count"]),
                            ("High / Critical", sev.get("High", 0) + sev.get("Critical", 0))], styles))
    story.append(Spacer(1, 8))
    story += _bullets(_executive_summary(result), styles)

    # ---- 2 File information ---------------------------------------------
    story.append(Paragraph("2. Capture File Information", styles["h1"]))
    sha = "-"
    try:
        if Path(result.parse.file_path).exists():
            sha = file_sha256(result.parse.file_path)
    except OSError:
        pass
    story.append(kv_table([
        ("File name", s["file_name"]), ("File size", human_bytes(s["file_size"])),
        ("Format", (s["file_format"] or "-").upper()), ("SHA-256", sha),
        ("First packet", ts_to_str(s["start_time"])), ("Last packet", ts_to_str(s["end_time"])),
        ("Capture duration", f"{s['duration_sec']:.2f} s"), ("Packets", f"{s['total_packets']:,}"),
        ("Total bytes (on the wire)", human_bytes(s["total_bytes"])),
        ("Average packet size", f"{s['avg_packet_size']} bytes"),
        ("Packet size min / median / max", f"{s['min_packet_size']} / {s['median_packet_size']:.0f} / "
                                           f"{s['max_packet_size']} bytes"),
        ("Average rate", f"{s['packets_per_sec']} packets/s, {human_bytes(s['bytes_per_sec'])}/s"),
        ("Parser", f"{s['engine']} engine, {s['parse_seconds']} s"),
        ("Parser warnings", "; ".join(s["warnings"]) or "none"),
    ], styles))

    # ---- 3 Methodology ----------------------------------------------------
    story.append(Paragraph("3. Analysis Methodology", styles["h1"]))
    story += [p("The capture file was validated (file signature, size) and read packet by packet. Each frame was "
                "decoded from the link layer up (Ethernet/IPv4/IPv6/ARP/TCP/UDP/ICMP) and application metadata was "
                "extracted for DNS, clear-text HTTP and TLS handshakes. Only header metadata is used: packet "
                "payloads are not stored, HTTP query strings are removed and encrypted HTTPS content is never "
                "decrypted - only the TLS version and the Server Name Indication visible in the handshake are read.",
                styles["body"]),
              p("Protocol, DNS, HTTP/TLS, TCP/UDP and IP statistics were computed from the decoded packets. TCP "
                "conversations were reconstructed from SYN/SYN-ACK/ACK/FIN/RST flags, and retransmissions were "
                "inferred from repeated sequence numbers. Ten transparent detection rules were then evaluated with "
                "the thresholds listed below.", styles["body"]),
              Paragraph("Detection rules and thresholds used", styles["h2"])]
    th = result.settings.get("thresholds", {})
    enabled = result.settings.get("rules_enabled", {})
    rule_rows = [[r["rule_id"], r["name"], "on" if enabled.get(r["rule_id"], True) else "off",
                  result.settings.get("rule_severity", {}).get(r["rule_id"], "-"), r["logic"]] for r in describe_rules()]
    story += make_table(rule_rows, ["ID", "Rule", "Enabled", "Base severity", "Logic"],
                        [1.0 * cm, 3.6 * cm, 1.3 * cm, 1.8 * cm, CONTENT_W - 7.7 * cm], styles)
    story.append(Spacer(1, 6))
    story += make_table([[k, v] for k, v in th.items()], ["Threshold", "Value"],
                        [CONTENT_W * 0.6, CONTENT_W * 0.4], styles)
    story.append(p("Severity starts at each rule's base level and is raised by one level when the observed value is "
                   "3x the threshold and by two levels at 10x.", styles["small"]))

    # ---- 4 Traffic overview -------------------------------------------------
    story += [PageBreak(), Paragraph("4. Traffic Overview", styles["h1"]),
              Paragraph("4.1 Protocol distribution", styles["h2"]), chart(charts["protocols"])]
    total = max(s["total_packets"], 1)
    story += make_table([[k, f"{v:,}", f"{v / total:.1%}"] for k, v in result.protocol_counts.items()],
                        ["Protocol class", "Packets", "Share"], [CONTENT_W * 0.5, CONTENT_W * 0.25, CONTENT_W * 0.25],
                        styles)
    story += [Paragraph("4.2 Traffic volume over time", styles["h2"]), chart(charts["timeline"]),
              Paragraph("4.3 Packet sizes", styles["h2"]), chart(charts["sizes"], CONTENT_W * 0.9)]

    # ---- 5 DNS ------------------------------------------------------------------
    dns = result.dns
    story += [PageBreak(), Paragraph("5. DNS Analysis", styles["h1"])]
    story.append(kv_table([("DNS queries", dns["query_count"]), ("DNS responses", dns["response_count"]),
                           ("Failed responses (NXDOMAIN/SERVFAIL/REFUSED...)", dns["failed_count"]),
                           ("Queries without a captured response", dns["unanswered_count"]),
                           ("Average response time", f"{dns['avg_response_ms']} ms" if dns["avg_response_ms"] is not None else "-"),
                           ("Query types", ", ".join(f"{k}: {v}" for k, v in dns["qtype_counts"].items() if v) or "-"),
                           ("Response codes", ", ".join(f"{k}: {v}" for k, v in dns["rcode_counts"].items()) or "-")],
                          styles, widths=(7 * cm, CONTENT_W - 7 * cm)))
    story += [Paragraph("5.1 Most requested domains", styles["h2"]), chart(charts["dns_domains"])]
    if dns["failed_count"]:
        story.append(Paragraph("5.2 Failed DNS responses", styles["h2"]))
        story += make_table(dns["failed"][["no", "dst_ip", "dns_qname", "dns_qtype", "dns_rcode"]].values.tolist(),
                            ["Pkt", "Client", "Domain", "Type", "Result"],
                            [1.3 * cm, 3 * cm, CONTENT_W - 8.3 * cm, 1.5 * cm, 2.5 * cm], styles, max_rows=15)
    story.append(Paragraph("5.3 Domains with unusual characteristics", styles["h2"]))
    if dns["unusual_domains"].empty:
        story.append(p("No domain names matched the length/randomness heuristics.", styles["body"]))
    else:
        story.append(p("Listed because of their shape only (length, randomness, depth). Many legitimate services use "
                       "such names; these are not classified as malicious.", styles["small"]))
        story += make_table(dns["unusual_domains"].values.tolist(), ["Domain", "Queries", "Why it stands out"],
                            [CONTENT_W * 0.45, 1.6 * cm, CONTENT_W * 0.55 - 1.6 * cm], styles, max_rows=15)

    # ---- 6 HTTP / TLS -------------------------------------------------------------
    http, tls = result.http, result.tls
    story += [PageBreak(), Paragraph("6. HTTP and HTTPS/TLS Analysis", styles["h1"]),
              p("HTTP is unencrypted: its method, host, path and status are visible to anyone on the network path. "
                "HTTPS/TLS is encrypted: only handshake metadata (TLS version, SNI) and connection details are "
                "visible, and no attempt is made to decrypt it.", styles["body"]),
              Paragraph("6.1 Clear-text HTTP", styles["h2"])]
    story.append(kv_table([("HTTP requests", http["request_count"]), ("HTTP responses", http["response_count"]),
                           ("Methods", ", ".join(f"{k}: {v}" for k, v in http["method_counts"].items()) or "-"),
                           ("Status codes", ", ".join(f"{k}: {v}" for k, v in sorted(http["status_counts"].items())) or "-"),
                           ("Error responses (4xx/5xx)", http["error_responses"])], styles))
    if http["request_count"]:
        story.append(Spacer(1, 5))
        req = http["requests"][["no", "src_ip", "http_method", "http_host", "http_uri"]].values.tolist()
        story += make_table(req, ["Pkt", "Client", "Method", "Host", "Path (query removed)"],
                            [1.3 * cm, 2.8 * cm, 1.6 * cm, 4.5 * cm, CONTENT_W - 10.2 * cm], styles, max_rows=15)
    story.append(Paragraph("6.2 HTTPS / TLS metadata", styles["h2"]))
    story.append(kv_table([("TLS/QUIC packets", tls["packet_count"]), ("TLS bytes", human_bytes(tls["bytes"])),
                           ("ClientHello messages", len(tls["client_hellos"])),
                           ("Versions offered (max)", ", ".join(f"{k}: {v}" for k, v in tls["version_counts"].items()) or "-"),
                           ("Versions negotiated", ", ".join(f"{k}: {v}" for k, v in tls["negotiated_versions"].items()) or "-"),
                           ("ClientHellos without SNI", tls["sni_missing"]), ("QUIC packets", tls["quic_packets"]),
                           ("Legacy TLS (≤1.1) handshakes", len(tls["legacy_tls"]))], styles))
    if not tls["destinations"].empty:
        story.append(Spacer(1, 5))
        d = tls["destinations"].copy()
        d["bytes"] = d["bytes"].map(human_bytes)
        story += make_table(d[["dst_ip", "dst_port", "connections", "packets", "bytes", "sni"]].values.tolist(),
                            ["Server", "Port", "Connections", "Packets", "Bytes", "SNI"],
                            [3.3 * cm, 1.3 * cm, 2 * cm, 1.7 * cm, 2 * cm, CONTENT_W - 10.3 * cm], styles, max_rows=15)

    # ---- 7 TCP / UDP ---------------------------------------------------------------
    tcp, udp = result.tcp, result.udp
    story += [PageBreak(), Paragraph("7. TCP and UDP Analysis", styles["h1"]), Paragraph("7.1 TCP", styles["h2"])]
    story.append(kv_table([("TCP packets", f"{tcp['packet_count']:,}"), ("TCP conversations", len(tcp["connections"])),
                           ("Connection attempts (SYN)", tcp["connection_attempts"]),
                           ("Completed handshakes", tcp["completed_handshakes"]),
                           ("Failed / unanswered connections", len(tcp["failed_connections"])),
                           ("Retransmissions", f"{tcp['retransmissions']} ({tcp['retransmission_rate']:.1%})"),
                           ("Connection states", ", ".join(f"{k}: {v}" for k, v in tcp["state_counts"].items()) or "-")],
                          styles))
    story.append(chart(charts["tcp_flags"], CONTENT_W * 0.9))
    if not tcp["failed_connections"].empty:
        fc = tcp["failed_connections"]
        story.append(Paragraph("Failed or unanswered connections", styles["h2"]))
        story += make_table(fc[["client_ip", "server_ip", "server_port", "syn", "state"]].values.tolist(),
                            ["Client", "Server", "Port", "SYNs", "State"],
                            [3.5 * cm, 3.5 * cm, 1.6 * cm, 1.4 * cm, CONTENT_W - 10 * cm], styles, max_rows=15)
    story.append(Paragraph("7.2 UDP", styles["h2"]))
    story.append(kv_table([("UDP packets", f"{udp['packet_count']:,}"), ("UDP bytes", human_bytes(udp["bytes"])),
                           ("DNS-related UDP packets", udp["dns_packets"])], styles))
    if not udp["conversations"].empty:
        story.append(Spacer(1, 5))
        story += make_table(udp["conversations"][["src_ip", "dst_ip", "dst_port", "service", "packets", "packets_per_sec"]]
                            .values.tolist(), ["Source", "Destination", "Port", "Service", "Packets", "Pkts/s"],
                            None, styles, max_rows=12)
    story.append(Paragraph("7.3 Limitations of packet-capture analysis", styles["h2"]))
    story += _bullets(tcp["limitations"], styles)

    # ---- 8 IP investigation -----------------------------------------------------------
    ip = result.ip
    story += [PageBreak(), Paragraph("8. IP Address Investigation", styles["h1"]),
              p(f"{ip['unique_ips']} unique IP addresses were observed. Address categories: " +
                (", ".join(f"{k}: {v}" for k, v in ip["category_counts"].items()) or "-") +
                ". Public or unfamiliar addresses are not treated as malicious.", styles["body"]),
              chart(charts["top_sources"]), chart(charts["top_destinations"])]
    hosts = ip["hosts"].head(20)
    story.append(Paragraph("Hosts by data transferred", styles["h2"]))
    story += make_table([[r.ip, r.category, f"{r.packets_sent:,}", f"{r.packets_received:,}", human_bytes(r.total_bytes),
                          r.unique_peers] for r in hosts.itertuples()],
                        ["IP address", "Category", "Pkts sent", "Pkts recv", "Total data", "Peers"],
                        [4.8 * cm, 2.6 * cm, 2 * cm, 2 * cm, 2.3 * cm, CONTENT_W - 13.7 * cm], styles)
    if ip["patterns"]:
        story.append(Paragraph("Communication patterns worth reviewing", styles["h2"]))
        story += make_table([[x["ip"], x["observation"], x["why_it_matters"]] for x in ip["patterns"]],
                            ["IP", "Observation", "Why it matters"], [3.5 * cm, 6 * cm, CONTENT_W - 9.5 * cm],
                            styles, max_rows=15)

    # ---- 9 Anomaly detection ------------------------------------------------------------
    alerts = result.alerts
    story += [PageBreak(), Paragraph("9. Anomaly Detection Results", styles["h1"]), chart(charts["severity"], CONTENT_W * 0.9)]
    if alerts.empty:
        story.append(p("No alerts were generated with the current thresholds.", styles["body"]))
    else:
        rows = [[a.alert_id, a.severity, a.detection, a.src_ip, a.dst_ip,
                 fmt(a.port), a.event_count] for a in alerts.itertuples()]
        story += make_table(rows, ["Alert ID", "Severity", "Detection", "Source", "Destination", "Port", "Events"],
                            [2.1 * cm, 1.7 * cm, 4.2 * cm, 2.8 * cm, 2.8 * cm, 1.3 * cm, CONTENT_W - 14.9 * cm],
                            styles, sev_col=1)
    for note in result.detection_notes + result.detection_errors:
        story.append(p(note, styles["small"]))

    # ---- 10 Alert details -----------------------------------------------------------------
    story += [PageBreak(), Paragraph("10. Alert Details", styles["h1"])]
    if alerts.empty:
        story.append(p("There are no alerts to detail.", styles["body"]))
    for a in alerts.head(max_alert_details).itertuples():
        color = SEVERITY_COLORS.get(a.severity, "#64748b")
        header = Paragraph(f"<font color='{color}'><b>■ {escape(a.severity.upper())}</b></font>&nbsp;&nbsp;"
                           f"<b>{escape(a.alert_id)} · {escape(a.detection)}</b>", styles["body"])
        block = [header, kv_table([("Source → Destination",
                                    f"{fmt(a.src_ip)} → {fmt(a.dst_ip)}  (port {fmt(a.port)})"),
                                   ("Time range", a.time_range), ("Observed events", a.event_count),
                                   ("Category", a.category), ("Reason", a.reason), ("Evidence", a.evidence or "-"),
                                   ("Recommended investigation", a.recommendation)], styles), Spacer(1, 10)]
        story.append(CondPageBreak(5 * cm))
        story.append(KeepTogether(block))
    if len(alerts) > max_alert_details:
        story.append(p(f"{len(alerts) - max_alert_details} further alert(s) are available in the CSV export.",
                       styles["small"]))

    # ---- 11 Screenshots ------------------------------------------------------------------
    shots = [Path(x) for x in (screenshots or []) if Path(x).exists()]
    if shots:
        story += [PageBreak(), Paragraph("11. Screenshots", styles["h1"])]
        for shot in shots:
            try:
                story += [chart(shot.read_bytes()), p(shot.name, styles["center"]), Spacer(1, 10)]
            except Exception:  # noqa: BLE001 - unreadable image: skip it
                story.append(p(f"Could not include {shot.name}.", styles["small"]))
    n = 12 if shots else 11

    # ---- Recommendations & conclusion --------------------------------------------------------
    story += [PageBreak(), Paragraph(f"{n}. Security Recommendations", styles["h1"])]
    story += _bullets(_recommendations(result), styles)
    story += [Paragraph(f"{n + 1}. Conclusion", styles["h1"]), p(_conclusion(result), styles["body"])]

    doc.multiBuild(story, canvasmaker=NumberedCanvasFactory)
    return output_path
