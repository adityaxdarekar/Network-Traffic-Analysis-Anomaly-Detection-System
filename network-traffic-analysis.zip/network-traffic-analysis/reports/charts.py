"""
Static PNG charts for the PDF report (Matplotlib, no GUI needed).

The interactive dashboard uses Plotly; the PDF needs static images, and
Matplotlib renders them reliably on Windows without extra tools.
"""

from __future__ import annotations

import io

import matplotlib

matplotlib.use("Agg")   # headless backend - must be set before pyplot is imported
import matplotlib.pyplot as plt  # noqa: E402

from config import SEVERITY_COLORS, SEVERITY_ORDER  # noqa: E402

NAVY = "#0b1f3a"
CYAN = "#06b6d4"
BLUE = "#2563eb"
GREY = "#64748b"
PALETTE = ["#2563eb", "#06b6d4", "#0ea5e9", "#6366f1", "#14b8a6", "#f59e0b", "#94a3b8", "#475569"]


def _style(ax, title: str, grid_axis: str = "y") -> None:
    ax.set_title(title, fontsize=11, color=NAVY, loc="left", fontweight="bold", pad=10)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color("#cbd5e1")
    ax.tick_params(colors="#334155", labelsize=8)
    ax.grid(axis=grid_axis, color="#e2e8f0", linewidth=0.6)
    ax.set_axisbelow(True)


def _to_png(fig) -> bytes:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    return buf.getvalue()


def _empty(title: str, message: str = "No data in this capture") -> bytes:
    fig, ax = plt.subplots(figsize=(7, 2.2))
    ax.axis("off")
    ax.set_title(title, fontsize=11, color=NAVY, loc="left", fontweight="bold")
    ax.text(0.5, 0.45, message, ha="center", va="center", color=GREY, fontsize=10)
    return _to_png(fig)


def hbar(labels, values, title: str, xlabel: str = "", color: str = BLUE) -> bytes:
    labels, values = list(labels), list(values)
    if not labels or sum(values) == 0:
        return _empty(title)
    labels = [str(x) if len(str(x)) <= 42 else str(x)[:39] + "..." for x in labels][::-1]
    values = values[::-1]
    fig, ax = plt.subplots(figsize=(7, 0.32 * len(labels) + 1.1))
    bars = ax.barh(labels, values, color=color, height=0.6)
    ax.bar_label(bars, labels=[f"{v:,}" for v in values], fontsize=7, padding=3, color="#334155")
    ax.set_xlabel(xlabel, fontsize=8, color="#334155")
    _style(ax, title, grid_axis="x")
    return _to_png(fig)


def protocol_chart(protocol_counts: dict) -> bytes:
    items = [(k, v) for k, v in protocol_counts.items() if v]
    if not items:
        return _empty("Protocol distribution")
    labels, values = zip(*sorted(items, key=lambda x: -x[1]))
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={"width_ratios": [1, 1.3]})
    ax1.pie(values, colors=PALETTE[:len(values)], startangle=90, wedgeprops={"width": 0.38, "edgecolor": "white"})
    ax1.set_title("Protocol distribution", fontsize=11, color=NAVY, loc="left", fontweight="bold")
    total = sum(values)
    ax2.axis("off")
    for i, (lab, val) in enumerate(zip(labels, values)):
        y = 0.92 - i * 0.12
        ax2.add_patch(plt.Rectangle((0.02, y - 0.035), 0.05, 0.07, color=PALETTE[i % len(PALETTE)],
                                    transform=ax2.transAxes))
        ax2.text(0.11, y, f"{lab}", va="center", fontsize=8.5, color="#0f172a", transform=ax2.transAxes)
        ax2.text(0.98, y, f"{val:,}  ({val / total:.1%})", va="center", ha="right", fontsize=8.5,
                 color="#334155", transform=ax2.transAxes)
    return _to_png(fig)


def timeline_chart(timeline) -> bytes:
    if timeline is None or timeline.empty:
        return _empty("Traffic volume over time")
    fig, ax = plt.subplots(figsize=(7.2, 2.6))
    ax.fill_between(timeline["time"], timeline["packets"], color=CYAN, alpha=0.25, step="mid")
    ax.plot(timeline["time"], timeline["packets"], color=BLUE, linewidth=1.2, drawstyle="steps-mid")
    bucket = timeline["bucket_sec"].iloc[0]
    ax.set_ylabel(f"packets / {bucket:g} s", fontsize=8, color="#334155")
    _style(ax, "Traffic volume over time (UTC)")
    fig.autofmt_xdate(rotation=0, ha="center")
    return _to_png(fig)


def severity_chart(severity_counts: dict) -> bytes:
    values = [severity_counts.get(s, 0) for s in SEVERITY_ORDER]
    if sum(values) == 0:
        return _empty("Alert severity distribution", "No alerts were generated for this capture")
    fig, ax = plt.subplots(figsize=(7, 2.3))
    bars = ax.bar(SEVERITY_ORDER, values, color=[SEVERITY_COLORS[s] for s in SEVERITY_ORDER], width=0.55)
    ax.bar_label(bars, fontsize=8, padding=2)
    _style(ax, "Alert severity distribution")
    return _to_png(fig)


def vbar(labels, values, title: str, color: str = BLUE) -> bytes:
    labels, values = [str(x) for x in labels], list(values)
    if not labels or sum(values) == 0:
        return _empty(title)
    fig, ax = plt.subplots(figsize=(7, 2.5))
    bars = ax.bar(labels, values, color=color, width=0.6)
    ax.bar_label(bars, labels=[f"{v:,}" for v in values], fontsize=7, padding=2)
    _style(ax, title)
    plt.setp(ax.get_xticklabels(), rotation=0)
    return _to_png(fig)


def build_report_charts(result) -> dict[str, bytes]:
    """All charts used in the report, keyed by name."""
    ip = result.ip
    dns = result.dns
    flags = result.tcp.get("flag_counts", {})
    return {
        "protocols": protocol_chart(result.protocol_counts),
        "timeline": timeline_chart(result.timeline),
        "top_sources": hbar(ip["top_sources"]["ip"], ip["top_sources"]["packets_sent"],
                            "Top source IP addresses", "packets sent"),
        "top_destinations": hbar(ip["top_destinations"]["ip"], ip["top_destinations"]["packets_received"],
                                 "Top destination IP addresses", "packets received", color=CYAN),
        "dns_domains": hbar(dns["top_domains"]["domain"], dns["top_domains"]["queries"],
                            "Most requested domains", "queries", color="#6366f1"),
        "severity": severity_chart(result.summary["severity_counts"]),
        "sizes": vbar(result.size_distribution["size_range"], result.size_distribution["packets"],
                      "Packet size distribution (bytes)", color="#14b8a6"),
        "tcp_flags": vbar(list(flags.keys()), list(flags.values()), "TCP flag counts", color=BLUE),
    }
