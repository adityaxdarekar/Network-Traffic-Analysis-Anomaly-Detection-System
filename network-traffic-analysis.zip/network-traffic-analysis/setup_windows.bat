@echo off
REM One-time setup: creates a virtual environment and installs the dependencies.
cd /d "%~dp0"
echo === Network Traffic Analysis - setup ===
where py >nul 2>nul && (py -3 -m venv venv) || (python -m venv venv)
if not exist venv\Scripts\python.exe (
  echo Could not create the virtual environment. Is Python 3.11+ installed and on PATH?
  pause
  exit /b 1
)
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed - check your Internet connection and try again.
  pause
  exit /b 1
)
echo.
echo Setup complete. Start the dashboard with run_app.bat
pause
