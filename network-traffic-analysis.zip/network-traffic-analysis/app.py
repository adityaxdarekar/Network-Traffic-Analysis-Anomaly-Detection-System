"""
Network Traffic Analysis and Anomaly Detection System - Streamlit entry point.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import APP_SHORT_TITLE, APP_TITLE, APP_VERSION  # noqa: E402
from dashboard import (about_page, alerts_page, capture_page, dns_page, http_page, ip_page,  # noqa: E402
                       overview, packet_explorer, reports_page, settings_page, tcp_page, upload_page)
from dashboard.common import get_result, get_settings  # noqa: E402
from dashboard.theme import CSS  # noqa: E402

PAGES = {
    "Overview": ("📊", overview.render),
    "Live Capture": ("📡", capture_page.render),
    "Upload PCAP": ("📁", upload_page.render),
    "DNS Analysis": ("🌐", dns_page.render),
    "HTTP/TLS Analysis": ("🔒", http_page.render),
    "TCP/UDP Analysis": ("🔌", tcp_page.render),
    "IP Investigation": ("🧭", ip_page.render),
    "Anomaly Detection": ("🚨", alerts_page.render),
    "Packet Explorer": ("🔎", packet_explorer.render),
    "Reports": ("📄", reports_page.render),
    "Settings": ("⚙️", settings_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def main() -> None:
    st.set_page_config(page_title=APP_SHORT_TITLE, page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")
    st.markdown(CSS, unsafe_allow_html=True)
    get_settings()

    # Programmatic navigation (e.g. "open overview after upload") must happen before the radio is drawn.
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Overview" if get_result() else "Upload PCAP"

    with st.sidebar:
        st.markdown(f"## 🛡️ {APP_SHORT_TITLE}")
        st.caption(f"{APP_TITLE} · v{APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        result = get_result()
        if result:
            s = result.summary
            st.markdown(f"**Loaded:** `{result.file_name}`")
            st.caption(f"{s['total_packets']:,} packets · {s['alert_count']} alerts · session {result.session_id}")
        else:
            st.caption("No capture loaded yet.")
        st.caption("🔐 All processing is local. Analyse only traffic you are authorised to monitor.")

    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001 - last-resort guard so one page bug never kills the app
        # st.stop() / st.rerun() work by raising control-flow exceptions - let those through.
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException")
               for c in type(exc).__mro__):
            raise
        st.error(f"Something went wrong on this page: {exc.__class__.__name__}: {exc}")
        st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
