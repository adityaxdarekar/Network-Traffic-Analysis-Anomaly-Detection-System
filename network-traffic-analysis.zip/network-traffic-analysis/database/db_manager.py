"""
SQLite storage for analysis history.

Privacy: only summary statistics and alerts are stored - never packet
payloads or full packet lists. Tables:

    sessions       one row per analysed capture
    protocol_stats packets per protocol
    ip_stats       top hosts (address, category, packets, bytes)
    dns_stats      top queried domains
    alerts         every alert generated
    reports        PDF reports produced for a session
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id     TEXT PRIMARY KEY,
    file_name      TEXT NOT NULL,
    file_size      INTEGER,
    file_format    TEXT,
    analyzed_at    TEXT NOT NULL,
    packet_count   INTEGER,
    total_bytes    INTEGER,
    duration_sec   REAL,
    capture_start  REAL,
    capture_end    REAL,
    unique_ips     INTEGER,
    dns_queries    INTEGER,
    http_requests  INTEGER,
    tcp_connections INTEGER,
    udp_packets    INTEGER,
    alert_count    INTEGER,
    severity_json  TEXT,
    warnings_json  TEXT
);
CREATE TABLE IF NOT EXISTS protocol_stats (
    session_id TEXT REFERENCES sessions(session_id) ON DELETE CASCADE,
    protocol   TEXT, packets INTEGER
);
CREATE TABLE IF NOT EXISTS ip_stats (
    session_id TEXT REFERENCES sessions(session_id) ON DELETE CASCADE,
    ip TEXT, category TEXT, packets_sent INTEGER, packets_received INTEGER,
    bytes_sent INTEGER, bytes_received INTEGER
);
CREATE TABLE IF NOT EXISTS dns_stats (
    session_id TEXT REFERENCES sessions(session_id) ON DELETE CASCADE,
    domain TEXT, queries INTEGER
);
CREATE TABLE IF NOT EXISTS alerts (
    session_id TEXT REFERENCES sessions(session_id) ON DELETE CASCADE,
    alert_id TEXT, rule_id TEXT, detection TEXT, category TEXT, severity TEXT,
    src_ip TEXT, dst_ip TEXT, port INTEGER, start_time REAL, end_time REAL,
    event_count INTEGER, reason TEXT, recommendation TEXT, evidence TEXT
);
CREATE TABLE IF NOT EXISTS reports (
    session_id TEXT REFERENCES sessions(session_id) ON DELETE CASCADE,
    report_path TEXT, created_at TEXT, pages INTEGER
);
CREATE INDEX IF NOT EXISTS idx_alerts_session ON alerts(session_id);
"""


class DatabaseManager:
    def __init__(self, path: str | Path = DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.executescript(SCHEMA)

    @contextmanager
    def _connect(self):
        con = sqlite3.connect(self.path)
        con.execute("PRAGMA foreign_keys = ON")
        try:
            yield con
            con.commit()
        finally:
            con.close()

    # ------------------------------------------------------------------
    def save_analysis(self, result, top_ips: int = 50, top_domains: int = 50) -> str:
        """Store an AnalysisResult. Returns its session id."""
        s = result.summary
        with self._connect() as con:
            con.execute("DELETE FROM sessions WHERE session_id = ?", (result.session_id,))
            con.execute(
                "INSERT INTO sessions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (result.session_id, s["file_name"], s["file_size"], s["file_format"], result.analyzed_at,
                 s["total_packets"], s["total_bytes"], s["duration_sec"], s["start_time"], s["end_time"],
                 s["unique_ips"], s["dns_queries"], s["http_requests"], s["tcp_connections"], s["udp_packets"],
                 s["alert_count"], json.dumps(s["severity_counts"]), json.dumps(s["warnings"])))
            con.executemany("INSERT INTO protocol_stats VALUES (?,?,?)",
                            [(result.session_id, p, int(n)) for p, n in result.protocol_counts.items()])
            hosts = result.ip["hosts"].head(top_ips)
            con.executemany("INSERT INTO ip_stats VALUES (?,?,?,?,?,?,?)",
                            [(result.session_id, r.ip, r.category, int(r.packets_sent), int(r.packets_received),
                              int(r.bytes_sent), int(r.bytes_received)) for r in hosts.itertuples()])
            dom = result.dns["top_domains"]
            if not result.dns["queries"].empty:
                counts = result.dns["queries"]["dns_qname"].value_counts().head(top_domains)
                dom = pd.DataFrame({"domain": counts.index, "queries": counts.values})
            con.executemany("INSERT INTO dns_stats VALUES (?,?,?)",
                            [(result.session_id, r.domain, int(r.queries)) for r in dom.itertuples()])
            con.executemany(
                "INSERT INTO alerts VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [(result.session_id, a.alert_id, a.rule_id, a.detection, a.category, a.severity, _s(a.src_ip),
                  _s(a.dst_ip), None if pd.isna(a.port) else int(a.port), a.start_time, a.end_time,
                  int(a.event_count), a.reason, a.recommendation, a.evidence)
                 for a in result.alerts.itertuples()])
        return result.session_id

    def add_report(self, session_id: str, report_path: str, created_at: str, pages: int | None = None) -> None:
        with self._connect() as con:
            con.execute("INSERT INTO reports VALUES (?,?,?,?)", (session_id, str(report_path), created_at, pages))

    # ------------------------------------------------------------------
    def list_sessions(self) -> pd.DataFrame:
        with self._connect() as con:
            return pd.read_sql_query(
                "SELECT session_id, file_name, analyzed_at, packet_count, total_bytes, duration_sec, unique_ips, "
                "dns_queries, alert_count, severity_json FROM sessions ORDER BY analyzed_at DESC", con)

    def get_session(self, session_id: str) -> dict | None:
        with self._connect() as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
            if row is None:
                return None
            data = dict(row)
            data["severity_counts"] = json.loads(data.pop("severity_json") or "{}")
            data["warnings"] = json.loads(data.pop("warnings_json") or "[]")
            for table in ("protocol_stats", "ip_stats", "dns_stats", "alerts", "reports"):
                data[table] = pd.read_sql_query(f"SELECT * FROM {table} WHERE session_id = ?", con,
                                                params=(session_id,)).drop(columns=["session_id"])
            return data

    def delete_session(self, session_id: str) -> None:
        with self._connect() as con:
            con.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))

    def alert_trend(self) -> pd.DataFrame:
        """Alerts per session over time (for the Reports page)."""
        with self._connect() as con:
            return pd.read_sql_query("SELECT analyzed_at, file_name, alert_count, packet_count FROM sessions "
                                     "ORDER BY analyzed_at", con)


def _s(value):
    return None if value is None or (isinstance(value, float) and pd.isna(value)) else str(value)
