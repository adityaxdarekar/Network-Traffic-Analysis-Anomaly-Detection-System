"""
Generate the SYNTHETIC demonstration captures in this folder.

    python sample_data/generate_samples.py

Every packet is fabricated locally by ``utils/pcap_writer.py``; no real
network traffic and no malicious software is involved. "Internet" hosts use
the reserved documentation ranges 192.0.2.0/24, 198.51.100.0/24,
203.0.113.0/24 and 2001:db8::/32, and domains use example.* names, so no
real company or person is associated with the simulated behaviour.

Files produced:
    normal_traffic.pcapng   everyday browsing - should raise no alerts
    port_scan.pcap          TCP port scan + ICMP ping sweep on the LAN
    syn_flood.pcap          burst of unanswered SYNs from many sources
    dns_tunneling.pcapng    long, random-looking TXT queries to one domain
    mixed_demo.pcapng       all of the above plus other rule triggers (best for demos)
"""

from __future__ import annotations

import random
import string
import zlib
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from utils.pcap_writer import TrafficBuilder, http_request, tls_app_data  # noqa: E402

OUT = Path(__file__).resolve().parent
T0 = datetime(2026, 11, 5, 10, 0, 0, tzinfo=timezone.utc).timestamp()

GATEWAY = "192.168.1.1"       # home router, also the DNS resolver
LAPTOP = "192.168.1.23"
PHONE = "192.168.1.31"
SERVER = "192.168.1.10"       # small LAN file/web server
SCANNER = "192.168.1.50"

SITES = [  # (domain, ip)
    ("www.example.com", "203.0.113.10"), ("news.example.org", "203.0.113.20"),
    ("cdn.example.net", "198.51.100.40"), ("mail.example.com", "203.0.113.25"),
    ("video.example.net", "198.51.100.77"), ("docs.example.org", "203.0.113.31"),
    ("shop.example.com", "198.51.100.12"), ("api.example.net", "203.0.113.45"),
]


def normal_traffic(b: TrafficBuilder, t0: float, duration: float = 120) -> None:
    b.add_arp(t0, LAPTOP, GATEWAY)
    b.add_arp(t0 + 0.002, GATEWAY, LAPTOP, reply=True)
    t = t0 + 0.5
    while t < t0 + duration:
        client = random.choice([LAPTOP, LAPTOP, PHONE])
        domain, ip = random.choice(SITES)
        b.dns_lookup(t, client, GATEWAY, domain, "A", answers=[("A", ip)])
        b.dns_lookup(t + 0.001, client, GATEWAY, domain, "AAAA", answers=[])
        b.https_visit(t + 0.05, client, ip, domain, data_chunks=random.randint(3, 8))
        t += random.uniform(4, 9)
    # IPv6 HTTPS session
    b.https_visit(t0 + 30, "fd00::23", "2001:db8::443", "v6.example.com", data_chunks=4)
    # clear-text HTTP (for the HTTP page)
    b.dns_lookup(t0 + 12, LAPTOP, GATEWAY, "intranet.example.edu", "A", answers=[("A", "198.51.100.80")])
    b.http_visit(t0 + 12.1, LAPTOP, "198.51.100.80", "intranet.example.edu", "/index.html")
    b.http_visit(t0 + 40, LAPTOP, "198.51.100.80", "intranet.example.edu", "/missing-page", status=404, reason="Not Found")
    b.tcp_session(t0 + 55, LAPTOP, "198.51.100.80", 80,
                  [("c", http_request("POST", "intranet.example.edu", "/api/feedback")),
                   ("s", b"HTTP/1.1 201 Created\r\nContent-Length: 0\r\n\r\n")])
    # other everyday protocols
    b.dns_lookup(t0 + 20, PHONE, GATEWAY, "typo-domian.example", "A", rcode=3)            # NXDOMAIN
    b.dns_lookup(t0 + 21, LAPTOP, GATEWAY, "example.com", "MX", answers=[("MX", "mail.example.com")])
    b.dns_lookup(t0 + 22, LAPTOP, GATEWAY, "www.example.org", "CNAME", answers=[("CNAME", "cdn.example.net")])
    b.dns_lookup(t0 + 23, LAPTOP, GATEWAY, "example.org", "NS", answers=[("NS", "ns1.example.org")])
    b.dns_lookup(t0 + 24, LAPTOP, GATEWAY, "example.net", "TXT", answers=[("TXT", "v=spf1 -all")])
    b.ping(t0 + 5, LAPTOP, GATEWAY, count=4)
    b.add_udp(t0 + 2, LAPTOP, "192.0.2.123", 50123, 123, b"\x23" + b"\x00" * 47)          # NTP
    b.add_udp(t0 + 2.05, "192.0.2.123", LAPTOP, 123, 50123, b"\x24" + b"\x00" * 47)
    for i in range(6):                                                                    # QUIC (HTTP/3)
        b.add_udp(t0 + 60 + i * 0.03, PHONE, "203.0.113.60", 51515, 443, bytes([0xC0]) + b"\x00" * 1199)
        b.add_udp(t0 + 60.01 + i * 0.03, "203.0.113.60", PHONE, 443, 51515, bytes([0x40]) + b"\x00" * 900)


def port_scan(b: TrafficBuilder, t0: float, ports=range(1, 1025), sweep_hosts=80) -> None:
    open_ports = {22, 80, 445, 3389}
    for i, port in enumerate(ports):
        t = t0 + i * 0.02
        sport = 40000 + (i % 20000)
        seq = random.randint(0, 2**31)
        b.add_tcp(t, SCANNER, SERVER, sport, port, seq, 0, "S")
        if port in open_ports:
            b.add_tcp(t + 0.001, SERVER, SCANNER, port, sport, 777, seq + 1, "SA")
            b.add_tcp(t + 0.002, SCANNER, SERVER, sport, port, seq + 1, 0, "R")
        else:
            b.add_tcp(t + 0.001, SERVER, SCANNER, port, sport, 0, seq + 1, "RA")
    # ICMP ping sweep across the LAN
    ts = t0 + len(ports) * 0.02 + 2
    for host in range(1, sweep_hosts + 1):
        target = f"192.168.1.{host}"
        b.ping(ts + host * 0.05, SCANNER, target, count=1, reply=host in (1, 10, 23, 31))


def syn_flood(b: TrafficBuilder, t0: float, count=400, seconds=4.0) -> None:
    for i in range(count):
        src = f"{random.choice(['198.51.100', '203.0.113', '192.0.2'])}.{random.randint(1, 254)}"
        b.add_tcp(t0 + i * seconds / count, src, SERVER, random.randint(1024, 65535), 80,
                  random.randint(0, 2**31), 0, "S")


def dns_tunnel(b: TrafficBuilder, t0: float, count=150, seconds=90) -> None:
    for i in range(count):
        chunk = "".join(random.choice("0123456789abcdef") for _ in range(random.randint(40, 56)))
        name = f"{chunk}.{i:04d}.tunnel-lab.example"
        b.dns_lookup(t0 + i * seconds / count, LAPTOP, GATEWAY, name, "TXT",
                     answers=[("TXT", "".join(random.choice(string.ascii_letters) for _ in range(60)))])


def extra_mixed_triggers(b: TrafficBuilder, t0: float) -> None:
    # Repeated, failing RDP connection attempts to an external address (R4, R6, R10)
    for i in range(20):
        b.add_tcp(t0 + i * 1.5, LAPTOP, "203.0.113.200", 50000 + i, 3389, random.randint(0, 2**31), 0, "S")
    # Clear-text Telnet session to the LAN server (R6)
    b.tcp_session(t0 + 5, LAPTOP, SERVER, 23, [("s", b"login: "), ("c", b"demo\r\n"), ("s", b"Welcome\r\n")])
    # Outbound connection to an uncommon port on an external host (R6 4444 + R10)
    b.tcp_session(t0 + 8, PHONE, "203.0.113.66", 4444, [("c", tls_app_data(200)), ("s", tls_app_data(200))])
    # A poor-quality SMB transfer with many retransmissions (R8)
    exchanges = [("c" if i % 2 else "s", tls_app_data(900)) for i in range(40)]
    b.tcp_session(t0 + 12, LAPTOP, SERVER, 445, exchanges, retransmit_every=3)
    # Ping flood towards the gateway (R7)
    b.ping(t0 + 20, LAPTOP, GATEWAY, count=120, interval=0.04)


def build(name: str, *scenarios) -> None:
    b = TrafficBuilder(seed=zlib.crc32(name.encode()))
    for fn, args in scenarios:
        fn(b, *args)
    n = b.write(OUT / name)
    print(f"  {name:<24} {n:>6} packets  {(OUT / name).stat().st_size / 1024:8.1f} KB")


def main() -> None:
    random.seed(2026)
    print("Generating synthetic sample captures in", OUT)
    build("normal_traffic.pcapng", (normal_traffic, (T0,)))
    build("port_scan.pcap", (normal_traffic, (T0, 40)), (port_scan, (T0 + 5,)))
    build("syn_flood.pcap", (normal_traffic, (T0, 30)), (syn_flood, (T0 + 10,)))
    build("dns_tunneling.pcapng", (normal_traffic, (T0, 100)), (dns_tunnel, (T0 + 5,)))
    build("mixed_demo.pcapng", (normal_traffic, (T0, 180)), (port_scan, (T0 + 30, range(1, 301), 60)),
          (syn_flood, (T0 + 70, 450, 3.0)), (dns_tunnel, (T0 + 90, 120, 60)), (extra_mixed_triggers, (T0 + 10,)))
    print("Done.")


if __name__ == "__main__":
    main()
