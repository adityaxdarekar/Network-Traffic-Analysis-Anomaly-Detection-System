"""
controller.py - orchestration for one run of the simulator.

It wires the pieces together:
    monitor -> event queue -> processing thread -> detection -> alerts -> database
and drives the workflow: initialise environment, baseline hashes, back up,
run a SAFE or DEMONSTRATION simulation, compare integrity, recover, report.

SAFE mode never changes the filesystem (synthetic events are fed straight to
detection). DEMONSTRATION mode performs the benign file operations and the live
monitor observes them; a backup is always taken first.
"""
from __future__ import annotations

import logging
import queue
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from activity_generator import DEMONSTRATION, SAFE, ActivityGenerator
from alert_manager import Alert, AlertManager
from backup_manager import BackupManager
from config_loader import Config
from database import Database
from detection_engine import DetectionEngine
from environment import EnvironmentBuilder
from file_monitor import CREATED, DELETED, MODIFIED, MOVED, FileEvent, make_monitor
from integrity_checker import IntegrityChecker
from recovery import RecoveryManager
from safety import Sandbox

_STOP = object()


@dataclass
class EventStats:
    files_modified: int = 0
    files_renamed: int = 0
    files_deleted: int = 0
    files_created: int = 0
    total_events: int = 0

    def update(self, ev: FileEvent):
        self.total_events += 1
        if ev.kind == MODIFIED:
            self.files_modified += 1
        elif ev.kind == MOVED:
            self.files_renamed += 1
        elif ev.kind == DELETED:
            self.files_deleted += 1
        elif ev.kind == CREATED:
            self.files_created += 1


class SimulationController:
    def __init__(self, config: Config, db: Optional[Database] = None):
        self.cfg = config
        self.test_box = Sandbox(config.d("test_dir"), "test directory")
        self.backup_box = Sandbox(config.d("backup_dir"), "backup directory")
        self.env = EnvironmentBuilder(self.test_box, config.sample_files)
        self.integrity = IntegrityChecker(self.test_box)
        self.backups = BackupManager(self.test_box, self.backup_box)
        self.recovery = RecoveryManager(self.test_box, self.backups)
        self.db = db
        self.baseline = None
        self.baseline_path = config.base_dir / "database" / "baseline.json"

        self.monitor = None
        self.monitoring = False
        self._queue: queue.Queue = queue.Queue(maxsize=20000)
        self._worker: Optional[threading.Thread] = None
        self._engine: Optional[DetectionEngine] = None
        self._alerts: Optional[AlertManager] = None
        self.stats = EventStats()
        self.sim_id: Optional[int] = None
        self.mode = "-"
        self.backup_id: str = "-"
        self.recovery_status = ""
        self.new_alerts: "queue.Queue[Alert]" = queue.Queue()
        self.errors: list[str] = []
        self.log = self._make_logger(config.d("log_dir"))

    @staticmethod
    def _make_logger(log_dir: Path) -> logging.Logger:
        """Activity log in logs/simulator.log (preserved across runs)."""
        log_dir.mkdir(parents=True, exist_ok=True)
        logger = logging.getLogger(f"rbs.{log_dir}")
        if not logger.handlers:
            h = logging.FileHandler(log_dir / "simulator.log", encoding="utf-8")
            h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            logger.addHandler(h)
            logger.setLevel(logging.INFO)
            logger.propagate = False
        return logger

    # ------------------------------------------------------------- setup
    def initialize_environment(self):
        self.env.initialize()
        return self.test_box.root

    def generate_samples(self, overwrite=False):
        files = self.env.generate_sample_files(overwrite=overwrite)
        self.baseline = self.integrity.build_baseline()
        self.integrity.save_baseline(self.baseline, self.baseline_path)
        return files

    def ensure_baseline(self):
        if self.baseline is None:
            if self.baseline_path.exists():
                self.baseline = self.integrity.load_baseline(self.baseline_path)
            else:
                self.baseline = self.integrity.build_baseline()
                self.integrity.save_baseline(self.baseline, self.baseline_path)
        return self.baseline

    # --------------------------------------------------- detection pipeline
    def _new_pipeline(self, sim_id):
        self._engine = DetectionEngine(self.cfg.detection, self.test_box)
        self._alerts = AlertManager(self.cfg["alerts"], simulation_id=sim_id)
        if self.db is not None:
            self._alerts.add_listener(lambda a, new: self._save_alert(a))
        self._alerts.add_listener(lambda a, new: self.new_alerts.put(a) if new else None)

    def _save_alert(self, alert: Alert):
        self.log.warning("ALERT %s [%s] %s file=%s", alert.alert_id, alert.severity, alert.title, alert.file)
        try:
            self.db.save_alert(alert)
        except Exception as exc:
            self.errors.append(f"database: {exc}")

    def _handle_event(self, ev: FileEvent):
        self.stats.update(ev)
        if self.db is not None and self.sim_id is not None and not ev.synthetic:
            try:
                self.db.save_event(self.sim_id, ev)
            except Exception as exc:
                self.errors.append(f"database: {exc}")
        if self._engine is not None and self._alerts is not None:
            try:
                for det in self._engine.process(ev):
                    self._alerts.submit(det)
            except Exception as exc:
                self.errors.append(f"detection: {exc}")

    # ------------------------------------------------------------- monitor
    def start_monitoring(self):
        if self.monitoring:
            return
        self.env.initialize()
        self._queue = queue.Queue(maxsize=20000)
        self._worker = threading.Thread(target=self._process_loop, name="rbs-processing", daemon=True)
        self._worker.start()
        self.monitor = make_monitor(self.test_box, self._on_event, self.cfg["monitor"])
        self.monitor.start()
        self.monitoring = True

    def _on_event(self, ev: FileEvent):
        try:
            self._queue.put_nowait(ev)
        except queue.Full:
            pass

    def _process_loop(self):
        last_flush = time.monotonic()
        while True:
            try:
                item = self._queue.get(timeout=0.3)
            except queue.Empty:
                item = None
            if item is _STOP:
                break
            if item is not None:
                self._handle_event(item)
            if self._alerts is not None and time.monotonic() - last_flush >= 1.5:
                self._alerts.flush()
                last_flush = time.monotonic()
        if self._alerts is not None:
            self._alerts.flush()

    def stop_monitoring(self):
        if not self.monitoring:
            return
        try:
            if self.monitor:
                self.monitor.stop()
        except Exception as exc:
            self.errors.append(f"monitor: {exc}")
        self._queue.put(_STOP)
        if self._worker:
            self._worker.join(timeout=10)
        self.monitoring = False

    def _drain(self, timeout=5.0):
        """Wait until the queue is processed (used after a demo run)."""
        # A polling monitor only sees changes on its next scan, so give it at
        # least two scan intervals before checking that the queue is empty.
        interval = getattr(self.monitor, "interval", 0.0) or 0.0
        time.sleep(max(0.3, interval * 2 + 0.2))
        deadline = time.monotonic() + timeout
        while not self._queue.empty() and time.monotonic() < deadline:
            time.sleep(0.05)
        time.sleep(0.2)
        if self._alerts:
            self._alerts.flush()

    # ----------------------------------------------------------- SAFE mode
    def run_safe_simulation(self, on_operation: Optional[Callable] = None) -> int:
        self.ensure_baseline()
        files_before = list(self.test_box.iter_files())
        self.mode = SAFE
        self.sim_id = self.db.create_simulation(SAFE, str(self.test_box.root)) if self.db else None
        self.backup_id = "-"
        self._new_pipeline(self.sim_id)
        self.stats = EventStats()
        gen = ActivityGenerator(self.test_box, self.cfg, simulation_id=self.sim_id)
        gen.run_safe(self._handle_event, delay=self.cfg.simulation["operation_delay_seconds"])
        if self._alerts:
            self._alerts.flush()
        # SAFE mode changes nothing - assert it.
        files_after = list(self.test_box.iter_files())
        if len(files_after) != len(files_before):
            self.errors.append("SAFE mode unexpectedly changed the filesystem")
        self._finish_simulation(self.integrity.compare(self.baseline), recovery_status="N/A (safe mode)")
        self.log.info("SAFE simulation %s finished: %s alerts", self.sim_id, self.alert_counts()["total"])
        return self.sim_id

    # ---------------------------------------------------- DEMONSTRATION mode
    def run_demo_simulation(self, on_operation: Optional[Callable] = None) -> int:
        self.ensure_baseline()
        info = self.backups.create_backup("pre_demo")
        self.backup_id = info.backup_id
        self.log.info("Backup %s created (%s files) before demonstration", info.backup_id, info.file_count)
        self.mode = DEMONSTRATION
        self.sim_id = self.db.create_simulation(DEMONSTRATION, str(self.test_box.root), info.backup_id) \
            if self.db else None
        if self._alerts is None or not self.monitoring:
            self._new_pipeline(self.sim_id)
        else:
            self._alerts.simulation_id = self.sim_id
        started_here = False
        if not self.monitoring:
            self.start_monitoring()
            started_here = True
        self.stats = EventStats()
        gen = ActivityGenerator(self.test_box, self.cfg, simulation_id=self.sim_id)
        gen.run_demo(delay=self.cfg.simulation["operation_delay_seconds"], on_operation=on_operation)
        self._drain()
        result = self.integrity.compare(self.baseline)
        if started_here:
            self.stop_monitoring()
        self._record_affected(result)
        self._finish_simulation(result, recovery_status="PENDING")
        self.log.info("DEMONSTRATION simulation %s finished: %s alerts, integrity %s",
                      self.sim_id, self.alert_counts()["total"], result.counts())
        return self.sim_id

    def _record_affected(self, result):
        if self.db is None or self.sim_id is None:
            return
        base = self.baseline.files
        for rel, old, new in result.modified:
            self.db.save_affected(self.sim_id, rel, "MODIFIED", old, new)
        for rel in result.missing:
            self.db.save_affected(self.sim_id, rel, "MISSING", base.get(rel).sha256 if base.get(rel) else "")
        for rel in result.new:
            self.db.save_affected(self.sim_id, rel, "NEW")

    # ------------------------------------------------------------- recovery
    def recover(self) -> Optional[object]:
        info = self.backups.latest()
        if info is None:
            raise RuntimeError("no backup available to restore from")
        result = self.recovery.restore(info)
        self.recovery_status = "VERIFIED" if result.all_verified else "INCOMPLETE"
        self.log.info("Recovery from %s: %s (%s)", info.backup_id, self.recovery_status, result.counts())
        if self.db is not None and self.sim_id is not None:
            for item in result.items:
                if item.status in ("RESTORED", "FAILED"):
                    self.db.save_affected(self.sim_id, item.file, "RESTORED" if item.verified else "RESTORE_FAILED",
                                          recovery_status=item.status, verified=item.verified)
            sim = self.db.simulation(self.sim_id) or {}
            self.db.finish_simulation(self.sim_id, {
                "files_monitored": sim.get("files_monitored", 0), "files_modified": sim.get("files_modified", 0),
                "files_renamed": sim.get("files_renamed", 0), "files_deleted": sim.get("files_deleted", 0),
                "suspicious_ops": sim.get("suspicious_ops", 0), "alert_count": sim.get("alert_count", 0),
                "backup_id": info.backup_id}, recovery_status=self.recovery_status)
        return result

    # ------------------------------------------------------------- integrity
    def check_integrity(self):
        self.ensure_baseline()
        return self.integrity.compare(self.baseline)

    # ------------------------------------------------------------- finish
    def _finish_simulation(self, integrity_result, recovery_status=""):
        counts = self._alerts.counts() if self._alerts else {"total": 0}
        stats = {"files_monitored": len(self.baseline.files) if self.baseline else 0,
                 "files_modified": self.stats.files_modified, "files_renamed": self.stats.files_renamed,
                 "files_deleted": self.stats.files_deleted, "suspicious_ops": counts["total"],
                 "alert_count": counts["total"], "backup_id": self.backup_id if self.backup_id != "-" else None}
        if self.db is not None and self.sim_id is not None:
            self.db.finish_simulation(self.sim_id, stats, recovery_status=recovery_status)
        self._last_integrity = integrity_result

    # ------------------------------------------------------------- dashboard
    def meta(self) -> dict:
        return {"sim_status": "RUNNING" if self.monitoring else "IDLE", "monitoring": self.monitoring,
                "mode": self.mode, "test_dir": str(self.test_box.root), "simulation_id": self.sim_id,
                "backup_id": self.backup_id}

    def alert_counts(self) -> dict:
        return self._alerts.counts() if self._alerts else {"total": 0, "CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

    def active_alerts(self, limit=None):
        return self._alerts.active_alerts(limit) if self._alerts else []
