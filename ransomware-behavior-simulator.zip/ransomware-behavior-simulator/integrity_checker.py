"""
integrity_checker.py - SHA-256 baseline and comparison for the test files.

A baseline maps each file (path relative to the sandbox root) to its SHA-256
digest and size. Comparing the live sandbox against the baseline yields the
classic integrity verdict: unchanged / modified / missing / new.

Hashing is read-only and streamed in chunks, so large files do not load into
memory. Nothing here writes to the monitored files.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

from safety import Sandbox

CHUNK = 65536
UNCHANGED, MODIFIED, MISSING, NEW = "UNCHANGED", "MODIFIED", "MISSING", "NEW"


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class FileRecord:
    path: str                 # relative to the sandbox root
    sha256: str
    size: int

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Baseline:
    created: str
    root: str
    files: dict = field(default_factory=dict)      # relpath -> FileRecord

    def to_json(self) -> str:
        return json.dumps({"created": self.created, "root": self.root,
                           "files": {k: v.to_dict() for k, v in self.files.items()}}, indent=2)

    @classmethod
    def from_json(cls, text: str) -> "Baseline":
        data = json.loads(text)
        files = {k: FileRecord(**v) for k, v in data.get("files", {}).items()}
        return cls(created=data.get("created", ""), root=data.get("root", ""), files=files)


@dataclass
class IntegrityResult:
    unchanged: list = field(default_factory=list)
    modified: list = field(default_factory=list)   # (relpath, old_hash, new_hash)
    missing: list = field(default_factory=list)
    new: list = field(default_factory=list)

    @property
    def intact(self) -> bool:
        return not (self.modified or self.missing or self.new)

    def counts(self) -> dict:
        return {"unchanged": len(self.unchanged), "modified": len(self.modified),
                "missing": len(self.missing), "new": len(self.new)}

    def status_for(self, relpath: str) -> str:
        if any(relpath == m[0] for m in self.modified):
            return MODIFIED
        if relpath in self.missing:
            return MISSING
        if relpath in self.new:
            return NEW
        return UNCHANGED


class IntegrityChecker:
    def __init__(self, sandbox: Sandbox):
        self.sandbox = sandbox

    def build_baseline(self) -> Baseline:
        base = Baseline(created=datetime.now().isoformat(timespec="seconds"), root=str(self.sandbox.root))
        for f in self.sandbox.iter_files():
            rel = self.sandbox.relative(f)
            base.files[rel] = FileRecord(path=rel, sha256=sha256_file(f), size=f.stat().st_size)
        return base

    def save_baseline(self, baseline: Baseline, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(baseline.to_json(), encoding="utf-8")
        return p

    def load_baseline(self, path: str | Path) -> Baseline:
        return Baseline.from_json(Path(path).read_text(encoding="utf-8"))

    def compare(self, baseline: Baseline) -> IntegrityResult:
        res = IntegrityResult()
        live: dict[str, Path] = {self.sandbox.relative(f): f for f in self.sandbox.iter_files()}
        for rel, rec in baseline.files.items():
            if rel not in live:
                res.missing.append(rel)
                continue
            current = sha256_file(live[rel])
            if current == rec.sha256:
                res.unchanged.append(rel)
            else:
                res.modified.append((rel, rec.sha256, current))
        for rel in live:
            if rel not in baseline.files:
                res.new.append(rel)
        res.modified.sort()
        res.missing.sort()
        res.new.sort()
        return res
