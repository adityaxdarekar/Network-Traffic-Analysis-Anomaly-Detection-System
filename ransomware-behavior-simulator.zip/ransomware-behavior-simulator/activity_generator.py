"""
activity_generator.py - the "simulator". It produces ransomware-LIKE file
activity so the monitoring, detection, alerting and recovery can be
demonstrated. It is deliberately harmless:

  * It only ever touches disposable sample files inside the test sandbox.
  * It performs NO encryption of any kind - not even reversible. The
    "simulated encryption" step overwrites a *disposable copy* with a fixed,
    clearly-labelled placeholder string (config: simulation.scrambled_marker).
    The original is backed up first and restored afterwards.
  * The ransom note is the project's educational marker text, which states
    plainly that nothing has been encrypted.
  * There is no persistence, no networking, no process control, no stealth.

Two modes (brief Feature 2):
  SAFE MODE      - emits synthetic FileEvent objects to the detection pipeline;
                   the filesystem is NOT changed at all.
  DEMONSTRATION  - performs the real (benign) file operations inside the
                   sandbox; the live monitor observes them. A backup must be
                   taken before this runs, and recovery restores the files.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from file_monitor import CREATED, DELETED, MODIFIED, MOVED, FileEvent
from safety import Sandbox

SAFE = "SAFE"
DEMONSTRATION = "DEMONSTRATION"

NOTE_TEXT = """SIMULATED RANSOMWARE ACTIVITY DETECTED

This is an educational demonstration.
Your files have NOT been encrypted by real ransomware.

Suspicious file activity was detected by the Ransomware Behavior Simulator,
a defensive teaching tool. All affected files are disposable samples inside a
dedicated test directory and have been backed up; they can be restored.

Detection timestamp: {when}
Simulation ID: {sid}
"""


@dataclass
class Operation:
    action: str          # modify / rename / create_note / delete
    target: str          # relative path
    detail: str = ""


@dataclass
class SimulationPlan:
    """How many of each operation to perform, derived from the detection
    thresholds so the run reliably crosses them."""
    modify: int
    rename: int
    delete: int
    create_note: bool = True

    @classmethod
    def from_config(cls, detection: dict) -> "SimulationPlan":
        return cls(
            modify=detection["rapid_modification"]["files"] + 2,
            rename=detection["bulk_rename"]["files"] + 1,
            delete=detection["mass_deletion"]["files"] + 1,
            create_note=True,
        )


class ActivityGenerator:
    def __init__(self, sandbox: Sandbox, config, simulation_id: Optional[int] = None):
        self.sandbox = sandbox
        self.sim_cfg = config.simulation if hasattr(config, "simulation") else config["simulation"]
        self.detection_cfg = config.detection if hasattr(config, "detection") else config["detection"]
        self.simulation_id = simulation_id
        self.operations: list[Operation] = []

    def _targets(self, n: int) -> list[Path]:
        """Pick up to n disposable sample files (never the note, never .simulated)."""
        files = [f for f in self.sandbox.iter_files()
                 if f.suffix != self.sim_cfg["simulated_extension"]
                 and f.name != self.sim_cfg["ransom_note_name"]]
        return files[:n]

    def _note_body(self) -> str:
        return NOTE_TEXT.format(when=datetime.now().isoformat(timespec="seconds"),
                                sid=self.simulation_id if self.simulation_id is not None else "n/a")

    # ------------------------------------------------------------- SAFE mode
    def run_safe(self, emit: Callable[[FileEvent], None], delay: Optional[float] = None) -> list[Operation]:
        """Emit synthetic events describing the scenario WITHOUT changing any file.
        'emit' receives FileEvent objects (fed straight to the detection engine)."""
        plan = SimulationPlan.from_config(self.detection_cfg)
        delay = self.sim_cfg["operation_delay_seconds"] if delay is None else delay
        targets = self._targets(max(plan.modify, plan.rename, plan.delete))
        if not targets:
            raise RuntimeError("no sample files to simulate against - generate sample files first")
        names = [self.sandbox.relative(t) for t in targets]
        ops: list[Operation] = []
        now = time.time()

        def fire(kind, path, dest=None, old=None, new=None):
            nonlocal now
            emit(FileEvent(kind=kind, path=path, timestamp=now, dest_path=dest,
                           old_suffix=old, new_suffix=new, synthetic=True))
            now += delay
            if delay:
                time.sleep(delay)

        for rel in names[:plan.modify]:
            fire(MODIFIED, rel)
            ops.append(Operation("modify", rel, "synthetic modify event"))
        ext = self.sim_cfg["simulated_extension"]
        for rel in names[:plan.rename]:
            dest = rel + ext
            fire(MOVED, rel, dest=dest, old=Path(rel).suffix, new=ext)
            ops.append(Operation("rename", rel, f"-> {dest}"))
        note = self.sim_cfg["ransom_note_name"]
        fire(CREATED, note)
        ops.append(Operation("create_note", note, "synthetic note event"))
        for rel in names[:plan.delete]:
            fire(DELETED, rel)
            ops.append(Operation("delete", rel, "synthetic delete event"))
        self.operations = ops
        return ops

    # ----------------------------------------------------- DEMONSTRATION mode
    def run_demo(self, delay: Optional[float] = None,
                 on_operation: Optional[Callable[[Operation], None]] = None) -> list[Operation]:
        """Perform the real, benign operations inside the sandbox. A backup must
        already have been taken by the caller. Returns the operations performed.

        NOTE: no encryption is performed. 'modify' overwrites a disposable copy
        with a fixed placeholder marker; everything is restorable from backup.
        """
        plan = SimulationPlan.from_config(self.detection_cfg)
        delay = self.sim_cfg["operation_delay_seconds"] if delay is None else delay
        targets = self._targets(max(plan.modify, plan.rename, plan.delete))
        if not targets:
            raise RuntimeError("no sample files to simulate against - generate sample files first")
        marker = self.sim_cfg["scrambled_marker"]
        ext = self.sim_cfg["simulated_extension"]
        ops: list[Operation] = []

        def step(op: Operation):
            ops.append(op)
            if on_operation:
                on_operation(op)
            if delay:
                time.sleep(delay)

        # 1) Modify: overwrite disposable copies with a benign placeholder (NOT encryption).
        rels = [self.sandbox.relative(t) for t in targets]
        for rel in rels[:plan.modify]:
            p = self.sandbox.resolve(*rel.split("/"))
            self.sandbox.write_text(p, f"{marker}\n(original file: {rel})\n")
            step(Operation("modify", rel, "overwritten with placeholder marker"))

        # 2) Rename: append the harmless .simulated extension to disposable copies.
        for rel in rels[:plan.rename]:
            src = self.sandbox.resolve(*rel.split("/"))
            if not src.exists():
                continue
            dst = self.sandbox.resolve(*(rel + ext).split("/"))
            self.sandbox.rename(src, dst)
            step(Operation("rename", rel, f"-> {rel + ext}"))

        # 3) Create the clearly-labelled simulation note.
        note_rel = self.sim_cfg["ransom_note_name"]
        self.sandbox.write_text(self.sandbox.resolve(note_rel), self._note_body())
        step(Operation("create_note", note_rel, "harmless simulation marker written"))

        # 4) Delete a few disposable copies (all backed up, all restorable).
        deletable = [self.sandbox.relative(f) for f in self.sandbox.iter_files()
                     if f.name != note_rel][: plan.delete]
        for rel in deletable:
            self.sandbox.delete(self.sandbox.resolve(*rel.split("/")))
            step(Operation("delete", rel, "disposable copy deleted (restorable)"))

        self.operations = ops
        return ops
