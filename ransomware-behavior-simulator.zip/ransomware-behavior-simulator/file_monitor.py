"""
file_monitor.py - watch the test directory and turn OS file events into a
uniform FileEvent stream.

Two engines, same output:
  * WatchdogMonitor - uses the Watchdog library's observer (real OS events)
  * PollingMonitor  - scans the directory on a timer (fallback when Watchdog
                      is unavailable, e.g. on some network filesystems)

Both only ever observe; they never change files. Events are pushed to a
thread-safe callback, so the detection engine runs in its own thread and a
slow rule cannot stall the observer.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from safety import Sandbox

CREATED, MODIFIED, DELETED, MOVED = "created", "modified", "deleted", "moved"


@dataclass
class FileEvent:
    kind: str                       # created / modified / deleted / moved
    path: str                       # relative to the sandbox root
    timestamp: float
    is_directory: bool = False
    dest_path: Optional[str] = None     # for moves/renames (relative)
    old_suffix: Optional[str] = None
    new_suffix: Optional[str] = None
    synthetic: bool = False             # True when emitted by the activity generator in SAFE mode

    def time_text(self) -> str:
        from datetime import datetime
        return datetime.fromtimestamp(self.timestamp).strftime("%H:%M:%S")

    def summary(self) -> str:
        if self.kind == MOVED:
            return f"{self.time_text()}  MOVED    {self.path} -> {self.dest_path}"
        return f"{self.time_text()}  {self.kind.upper():<8} {self.path}"


def watchdog_available() -> bool:
    try:
        import watchdog.observers  # noqa: F401
        return True
    except Exception:
        return False


def _suffix(path: str) -> str:
    return Path(path).suffix.lower()


class _BaseMonitor:
    def __init__(self, sandbox: Sandbox, on_event: Callable[[FileEvent], None],
                 ignore_suffixes: tuple[str, ...] = ()):
        self.sandbox = sandbox
        self.on_event = on_event
        self.ignore = tuple(ignore_suffixes)
        self.running = False
        self.count = 0

    def _emit(self, kind, path, *, dest=None, is_dir=False, ts=None):
        try:
            rel = self.sandbox.relative(path)
        except Exception:
            return                       # event outside the sandbox: ignore entirely
        if any(rel.endswith(s) for s in self.ignore):
            return
        rel_dest = None
        if dest is not None:
            try:
                rel_dest = self.sandbox.relative(dest)
            except Exception:
                rel_dest = None
        ev = FileEvent(kind=kind, path=rel, timestamp=ts or time.time(), is_directory=is_dir,
                       dest_path=rel_dest,
                       old_suffix=_suffix(rel) or None,
                       new_suffix=_suffix(rel_dest) if rel_dest else None)
        self.count += 1
        self.on_event(ev)


class PollingMonitor(_BaseMonitor):
    """Detects created/modified/deleted by comparing directory snapshots."""
    engine = "poll"

    def __init__(self, sandbox, on_event, interval=0.5, ignore_suffixes=()):
        super().__init__(sandbox, on_event, ignore_suffixes)
        self.interval = interval
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._snapshot: dict[str, float] = {}

    def _scan(self) -> dict[str, float]:
        snap = {}
        for f in self.sandbox.iter_files():
            try:
                snap[self.sandbox.relative(f)] = f.stat().st_mtime
            except OSError:
                pass
        return snap

    def start(self):
        self._snapshot = self._scan()
        self.running = True
        self._thread = threading.Thread(target=self._run, name="poll-monitor", daemon=True)
        self._thread.start()

    def _run(self):
        while not self._stop.is_set():
            self._stop.wait(self.interval)
            if self._stop.is_set():
                break
            current = self._scan()
            for rel, mtime in current.items():
                if rel not in self._snapshot:
                    self._emit(CREATED, self.sandbox.resolve(*rel.split("/")))
                elif mtime != self._snapshot[rel]:
                    self._emit(MODIFIED, self.sandbox.resolve(*rel.split("/")))
            for rel in self._snapshot:
                if rel not in current:
                    self._emit(DELETED, self.sandbox.resolve(*rel.split("/")))
            self._snapshot = current

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        self.running = False


class WatchdogMonitor(_BaseMonitor):
    """Uses Watchdog's observer for real OS filesystem events."""
    engine = "watchdog"

    def __init__(self, sandbox, on_event, ignore_suffixes=()):
        super().__init__(sandbox, on_event, ignore_suffixes)
        self._observer = None

    def start(self):
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        monitor = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event):
                if not event.is_directory:
                    monitor._emit(CREATED, event.src_path, is_dir=event.is_directory)

            def on_modified(self, event):
                if not event.is_directory:
                    monitor._emit(MODIFIED, event.src_path, is_dir=event.is_directory)

            def on_deleted(self, event):
                if not event.is_directory:
                    monitor._emit(DELETED, event.src_path, is_dir=event.is_directory)

            def on_moved(self, event):
                if not event.is_directory:
                    monitor._emit(MOVED, event.src_path, dest=event.dest_path, is_dir=event.is_directory)

        self._observer = Observer()
        self._observer.schedule(Handler(), str(self.sandbox.root), recursive=True)
        self._observer.start()
        self.running = True

    def stop(self):
        if self._observer is not None:
            try:
                self._observer.stop()
                self._observer.join(timeout=5)
            except Exception:
                pass
        self.running = False


def make_monitor(sandbox: Sandbox, on_event, config: dict):
    """Pick an engine from config ('auto' prefers Watchdog, falls back to polling)."""
    engine = config.get("engine", "auto")
    ignore = tuple(config.get("ignore_suffixes", []))
    if engine == "poll" or (engine == "auto" and not watchdog_available()):
        return PollingMonitor(sandbox, on_event, config.get("poll_interval_seconds", 0.5), ignore)
    if engine == "watchdog" and not watchdog_available():
        raise RuntimeError("monitor.engine is 'watchdog' but the watchdog package is not installed")
    return WatchdogMonitor(sandbox, on_event, ignore)
