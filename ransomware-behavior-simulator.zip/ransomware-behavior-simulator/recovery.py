"""
recovery.py - restore the sample files from a verified backup and confirm the
restored files match the backup hashes.

Recovery only ever writes inside the test sandbox, and only restores files that
are present in the backup manifest. It will not touch anything else.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from backup_manager import BackupInfo, BackupManager
from integrity_checker import sha256_file
from safety import Sandbox, guarded_copy

RESTORED, VERIFIED, FAILED, UNCHANGED = "RESTORED", "VERIFIED", "FAILED", "UNCHANGED"


@dataclass
class FileRecovery:
    file: str
    status: str            # RESTORED / UNCHANGED / FAILED
    verified: bool
    note: str = ""


@dataclass
class RecoveryResult:
    backup_id: str
    items: list = field(default_factory=list)
    extra_removed: list = field(default_factory=list)   # stray files deleted during cleanup

    @property
    def restored(self):
        return [i for i in self.items if i.status == RESTORED]

    @property
    def failed(self):
        return [i for i in self.items if i.status == FAILED]

    @property
    def all_verified(self) -> bool:
        return all(i.verified for i in self.items) and not self.failed

    def counts(self) -> dict:
        return {"restored": len(self.restored), "unchanged": len([i for i in self.items if i.status == UNCHANGED]),
                "failed": len(self.failed), "verified": len([i for i in self.items if i.verified]),
                "extra_removed": len(self.extra_removed), "total": len(self.items)}


class RecoveryManager:
    def __init__(self, test_sandbox: Sandbox, backup_manager: BackupManager):
        self.test = test_sandbox
        self.backups = backup_manager

    def restore(self, info: BackupInfo, remove_extra: bool = True) -> RecoveryResult:
        """Restore every file in the backup manifest into the test directory,
        verifying each restored file against its backup hash. Optionally remove
        files that are not in the backup (e.g. the simulation note and
        .simulated copies created during the demo)."""
        if not self.backups.verify_backup(info):
            raise RuntimeError(f"backup {info.backup_id} failed its own integrity check; refusing to restore from it")
        result = RecoveryResult(backup_id=info.backup_id)
        manifest_paths = set(info.manifest.keys())

        for rel, rec in info.manifest.items():
            dst = self.test.resolve(*rel.split("/"))
            src = self.backups.backup_file_path(info, rel)
            try:
                if dst.is_file() and sha256_file(dst) == rec["sha256"]:
                    result.items.append(FileRecovery(rel, UNCHANGED, True, "already matches backup"))
                    continue
                guarded_copy(src, dst, self.test)
                ok = sha256_file(dst) == rec["sha256"]
                result.items.append(FileRecovery(rel, RESTORED if ok else FAILED, ok,
                                                 "" if ok else "hash mismatch after restore"))
            except Exception as exc:
                result.items.append(FileRecovery(rel, FAILED, False, str(exc)))

        if remove_extra:
            for f in list(self.test.iter_files()):
                rel = self.test.relative(f)
                if rel not in manifest_paths:
                    try:
                        self.test.delete(f)
                        result.extra_removed.append(rel)
                    except Exception:
                        pass
        return result
