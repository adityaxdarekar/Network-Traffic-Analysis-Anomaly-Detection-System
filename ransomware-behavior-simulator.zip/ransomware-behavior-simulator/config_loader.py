"""
config_loader.py - load config.json over built-in defaults and validate it.

Returns a Config object with resolved absolute directories (all under the
project root) and validated detection thresholds. Any problem raises
ConfigError listing every mistake at once.
"""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")

DEFAULTS: dict = {
    "directories": {"test_dir": "test_environment", "backup_dir": "backups",
                    "report_html_dir": "reports/html", "report_json_dir": "reports/json",
                    "log_dir": "logs", "database": "database/simulator.db"},
    "sample_files": {"count": 10, "subfolder": "sample_data", "subfolder_count": 4,
                     "min_bytes": 400, "max_bytes": 2000},
    "monitor": {"engine": "auto", "poll_interval_seconds": 0.5, "ignore_suffixes": [".swp", ".tmp~"]},
    "simulation": {"simulated_extension": ".simulated", "ransom_note_name": "SIMULATED_RANSOM_NOTE.txt",
                   "scrambled_marker": "[SIMULATED-PLACEHOLDER CONTENT - original safely backed up and restorable]",
                   "operation_delay_seconds": 0.05, "require_demo_confirmation_phrase": "RUN SIMULATION"},
    "detection": {
        "rapid_modification": {"enabled": True, "files": 10, "window_seconds": 5, "severity": "HIGH"},
        "bulk_rename": {"enabled": True, "files": 5, "window_seconds": 5, "severity": "HIGH"},
        "suspicious_extension_change": {"enabled": True, "files": 3, "window_seconds": 5, "severity": "MEDIUM",
                                        "watched_extensions": [".simulated", ".locked", ".encrypted"]},
        "ransom_note": {"enabled": True, "severity": "HIGH",
                        "name_markers": ["ransom", "readme_decrypt", "how_to_decrypt", "recover_files"],
                        "content_marker": "SIMULATED RANSOMWARE ACTIVITY"},
        "mass_deletion": {"enabled": True, "files": 5, "window_seconds": 5, "severity": "CRITICAL"},
        "rapid_creation": {"enabled": True, "files": 12, "window_seconds": 5, "severity": "MEDIUM"},
    },
    "alerts": {"cooldown_seconds": 10, "active_alert_limit": 500},
    "display": {"color": True, "max_alerts_shown": 8},
}


class ConfigError(ValueError):
    pass


@dataclass
class Config:
    raw: dict
    base_dir: Path

    def d(self, key: str) -> Path:
        """Resolved absolute path for a configured directory/file, kept under base_dir."""
        rel = self.raw["directories"][key]
        p = (self.base_dir / rel).resolve()
        if self.base_dir not in p.parents and p != self.base_dir:
            raise ConfigError(f"directories.{key} ({rel}) escapes the project folder")
        return p

    @property
    def detection(self) -> dict:
        return self.raw["detection"]

    @property
    def simulation(self) -> dict:
        return self.raw["simulation"]

    @property
    def sample_files(self) -> dict:
        return self.raw["sample_files"]

    def __getitem__(self, key):
        return self.raw[key]


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _validate(cfg: dict) -> list[str]:
    errs: list[str] = []

    def posint(path, v, lo=1, hi=10_000_000):
        if isinstance(v, bool) or not isinstance(v, int) or v < lo or v > hi:
            errs.append(f"{path} must be an integer in [{lo}, {hi}] (got {v!r})")

    def posnum(path, v, lo=0.0, hi=3600):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v < lo or v > hi:
            errs.append(f"{path} must be a number in [{lo}, {hi}] (got {v!r})")

    def boolean(path, v):
        if not isinstance(v, bool):
            errs.append(f"{path} must be true/false (got {v!r})")

    def severity(path, v):
        if v not in SEVERITIES:
            errs.append(f"{path} must be one of {SEVERITIES} (got {v!r})")

    for key in ("test_dir", "backup_dir", "report_html_dir", "report_json_dir", "log_dir", "database"):
        val = cfg["directories"].get(key)
        if not isinstance(val, str) or not val.strip():
            errs.append(f"directories.{key} must be a non-empty string")
        elif val.startswith(("/", "\\")) or ".." in Path(val).parts:
            errs.append(f"directories.{key} must be a relative path inside the project (got {val!r})")

    sf = cfg["sample_files"]
    posint("sample_files.count", sf.get("count"), 1, 100000)
    posint("sample_files.subfolder_count", sf.get("subfolder_count"), 0, 100000)
    posint("sample_files.min_bytes", sf.get("min_bytes"), 1, 10_000_000)
    posint("sample_files.max_bytes", sf.get("max_bytes"), 1, 10_000_000)
    if isinstance(sf.get("min_bytes"), int) and isinstance(sf.get("max_bytes"), int) \
            and sf["min_bytes"] > sf["max_bytes"]:
        errs.append("sample_files.min_bytes must be <= max_bytes")

    posnum("monitor.poll_interval_seconds", cfg["monitor"].get("poll_interval_seconds"), 0.05, 60)
    if cfg["monitor"].get("engine") not in ("auto", "watchdog", "poll"):
        errs.append("monitor.engine must be 'auto', 'watchdog' or 'poll'")

    sim = cfg["simulation"]
    ext = sim.get("simulated_extension", "")
    if not isinstance(ext, str) or not ext.startswith(".") or len(ext) < 2:
        errs.append("simulation.simulated_extension must be like '.simulated'")
    if not isinstance(sim.get("ransom_note_name"), str) or not sim["ransom_note_name"]:
        errs.append("simulation.ransom_note_name must be a non-empty string")
    posnum("simulation.operation_delay_seconds", sim.get("operation_delay_seconds"), 0.0, 10)

    det = cfg["detection"]
    for rule in ("rapid_modification", "bulk_rename", "suspicious_extension_change",
                 "ransom_note", "mass_deletion", "rapid_creation"):
        r = det.get(rule)
        if not isinstance(r, dict):
            errs.append(f"detection.{rule} must be an object")
            continue
        boolean(f"detection.{rule}.enabled", r.get("enabled"))
        severity(f"detection.{rule}.severity", r.get("severity"))
        if rule not in ("ransom_note",):
            posint(f"detection.{rule}.files", r.get("files"), 2, 1_000_000)
            posnum(f"detection.{rule}.window_seconds", r.get("window_seconds"), 0.1, 3600)
    ext_rule = det.get("suspicious_extension_change", {})
    if not isinstance(ext_rule.get("watched_extensions"), list):
        errs.append("detection.suspicious_extension_change.watched_extensions must be a list")
    rn = det.get("ransom_note", {})
    if not isinstance(rn.get("name_markers"), list) or not rn.get("name_markers"):
        errs.append("detection.ransom_note.name_markers must be a non-empty list")
    if not isinstance(rn.get("content_marker"), str) or not rn.get("content_marker"):
        errs.append("detection.ransom_note.content_marker must be a non-empty string")

    posnum("alerts.cooldown_seconds", cfg["alerts"].get("cooldown_seconds"), 0, 86400)
    posint("alerts.active_alert_limit", cfg["alerts"].get("active_alert_limit"), 10, 1_000_000)
    boolean("display.color", cfg["display"].get("color"))
    posint("display.max_alerts_shown", cfg["display"].get("max_alerts_shown"), 1, 1000)
    return errs


def load_config(path: str | Path | None = None, base_dir: Path = BASE_DIR) -> Config:
    path = Path(path) if path else base_dir / "config.json"
    user: dict = {}
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"{path.name} is not valid JSON: line {exc.lineno} col {exc.colno}: {exc.msg}")
        if not isinstance(user, dict):
            raise ConfigError(f"{path.name} must contain a JSON object")
    merged = _merge(DEFAULTS, user)
    problems = _validate(merged)
    if problems:
        raise ConfigError("invalid configuration:\n  - " + "\n  - ".join(problems))
    return Config(raw=merged, base_dir=base_dir)
