#!/usr/bin/env python3
"""
main.py - Ransomware Behavior Simulator: interactive menu and CLI.

A defensive teaching tool. It demonstrates ransomware-LIKE file activity inside
a dedicated test directory it creates, detects that activity, raises alerts,
monitors file integrity and recovers the sample files from backups.

It performs NO real encryption, no persistence, no networking and never touches
anything outside its own test_environment/ directory.

    python3 main.py                 # interactive menu
    python3 main.py --safe          # run a SAFE-mode simulation and exit
    python3 main.py --demo --yes    # run a DEMONSTRATION simulation + recovery
    python3 main.py --report N      # write a report for simulation N
"""
from __future__ import annotations

import argparse
import sys
from typing import Callable, Optional

import ui
from config_loader import ConfigError, load_config
from controller import SimulationController
from database import Database, DatabaseError
from report_generator import build_report, save_report

SAFE_EXPLAIN = ("SAFE MODE logs and detects ransomware-like events WITHOUT changing any file.")
DEMO_EXPLAIN = ("DEMONSTRATION MODE performs real but harmless operations on disposable sample files inside the "
                "test directory (overwrite with a placeholder marker, rename to .simulated, write a labelled note, "
                "delete copies). A backup is taken first and the files are restorable. No encryption is performed.")


class App:
    def __init__(self, config, db, input_fn: Callable[[str], str] = input, out=None):
        self.cfg = config
        self.db = db
        self.ctl = SimulationController(config, db)
        self.input = input_fn
        self.out = out or sys.stdout

    def say(self, text=""):
        print(text, file=self.out)

    def ask(self, prompt, default=""):
        try:
            v = self.input(prompt).strip()
        except EOFError:
            v = ""
        return v or default

    # --------------------------------------------------------------- actions
    def initialize_env(self):
        root = self.ctl.initialize_environment()
        self.say(ui.ok(f"Test environment ready: {root}"))

    def generate_samples(self):
        overwrite = False
        if self.ctl.env.is_initialized():
            overwrite = self.ask("Sample files exist. Regenerate them? (y/N): ").lower() in ("y", "yes")
        files = self.ctl.generate_samples(overwrite=overwrite)
        self.say(ui.ok(f"{len(files)} sample files ready, baseline SHA-256 hashes stored."))

    def start_monitoring(self):
        if self.ctl.monitoring:
            self.say(ui.info("Monitoring is already running."))
            return
        if not self.ctl.env.is_initialized():
            self.say(ui.warn("No sample files yet - generating them first."))
            self.ctl.generate_samples()
        self.ctl.start_monitoring()
        self.say(ui.ok(f"Monitoring started ({self.ctl.monitor.engine} engine) on {self.ctl.test_box.root}"))

    def stop_monitoring(self):
        if self.ctl.monitoring:
            self.ctl.stop_monitoring()
            self.say(ui.info("Monitoring stopped."))

    def run_safe(self):
        if not self.ctl.env.is_initialized():
            self.ctl.generate_samples()
        self.say(ui.info(SAFE_EXPLAIN))
        sid = self.ctl.run_safe_simulation()
        self.say(ui.ok(f"SAFE simulation {sid} complete - {self.ctl.alert_counts()['total']} alerts, no files changed."))
        self._show_alerts_brief()

    def run_demo(self, assume_yes=False):
        if not self.ctl.env.is_initialized():
            self.ctl.generate_samples()
        self.say(ui.warn(DEMO_EXPLAIN))
        phrase = self.cfg.simulation["require_demo_confirmation_phrase"]
        if not assume_yes:
            typed = self.ask(f'Type "{phrase}" to confirm (anything else cancels): ')
            if typed != phrase:
                self.say(ui.info("Demonstration cancelled."))
                return
        self.say(ui.info("Backing up sample files, then running the demonstration..."))
        sid = self.ctl.run_demo_simulation(on_operation=lambda op: self.say(ui.dim(f"   {op.action}: {op.target}")))
        res = self.ctl.check_integrity()
        self.say(ui.ok(f"DEMONSTRATION {sid} complete. Alerts: {self.ctl.alert_counts()['total']}; "
                       f"integrity -> modified {res.counts()['modified']}, missing {res.counts()['missing']}, "
                       f"new {res.counts()['new']}."))
        self._show_alerts_brief()
        if assume_yes or self.ask("Restore the sample files from backup now? (Y/n): ").lower() in ("", "y", "yes"):
            self.restore()

    def _show_alerts_brief(self):
        for a in self.ctl.active_alerts(self.cfg["display"]["max_alerts_shown"]):
            self.say(ui.alert_block(a))

    def view_alerts(self):
        alerts = self.ctl.active_alerts()
        if not alerts and self.db is not None:
            latest = self.db.latest_simulation()
            if latest:
                alerts = self.db.alerts_for(latest["id"])
                self.say(ui.info(f"Showing stored alerts for simulation {latest['id']}."))
        if not alerts:
            self.say(ui.info("No alerts yet. Run a SAFE or DEMONSTRATION simulation first."))
            return
        for a in alerts[-20:]:
            self.say(ui.alert_block(a))
            self.say("")

    def check_integrity(self):
        if not self.ctl.env.is_initialized():
            self.say(ui.warn("No test files to check. Generate sample files first."))
            return
        res = self.ctl.check_integrity()
        c = res.counts()
        self.say(ui.table([["Unchanged", c["unchanged"]], ["Modified", c["modified"]],
                           ["Missing", c["missing"]], ["New", c["new"]]], ["Integrity", "Count"]))
        for rel, old, new in res.modified[:20]:
            self.say(f"  {ui.yellow('MODIFIED')} {rel}")
            self.say(ui.dim(f"      baseline {old[:16]}...  current {new[:16]}..."))
        for rel in res.missing[:20]:
            self.say(f"  {ui.red('MISSING ')} {rel}")
        for rel in res.new[:20]:
            self.say(f"  {ui.cyan('NEW     ')} {rel}")
        if res.intact:
            self.say(ui.ok("All files match the baseline."))

    def restore(self):
        try:
            result = self.ctl.recover()
        except RuntimeError as exc:
            self.say(ui.error(str(exc)))
            return
        c = result.counts()
        self.say(ui.ok(f"Recovery from backup {result.backup_id}: restored {c['restored']}, "
                       f"unchanged {c['unchanged']}, verified {c['verified']}, failed {c['failed']}, "
                       f"extra removed {c['extra_removed']}."))
        for item in result.items:
            if item.status in ("RESTORED", "FAILED"):
                tag = ui.green("RESTORED") if item.verified else ui.red("FAILED  ")
                self.say(f"  {tag} {item.file}  integrity: {'PASSED' if item.verified else item.note}")
        self.say(ui.ok("Integrity verification passed.") if result.all_verified
                 else ui.warn("Some files could not be verified."))

    def view_simulations(self):
        if self.db is None:
            self.say(ui.info("Database disabled."))
            return
        sims = self.db.simulations(20)
        if not sims:
            self.say(ui.info("No previous simulations."))
            return
        self.say(ui.table([[s["id"], s["mode"], s["started"], s["files_modified"], s["files_renamed"],
                            s["files_deleted"], s["alert_count"], s["recovery_status"] or "-"] for s in sims],
                          ["ID", "Mode", "Started", "Mod", "Ren", "Del", "Alerts", "Recovery"]))

    def generate_report(self, sim_id: Optional[int] = None):
        if self.db is None:
            self.say(ui.error("Database disabled; cannot build a report."))
            return
        sims = self.db.simulations(20)
        if not sims:
            self.say(ui.info("No simulations to report on yet."))
            return
        if sim_id is None:
            self.say(ui.table([[s["id"], s["mode"], s["started"], s["alert_count"]] for s in sims],
                              ["ID", "Mode", "Started", "Alerts"]))
            text = self.ask(f"Simulation number (Enter = {sims[0]['id']}): ", str(sims[0]["id"]))
            if not text.isdigit():
                self.say(ui.error("Enter a simulation number."))
                return
            sim_id = int(text)
        sim = self.db.simulation(sim_id)
        if sim is None:
            self.say(ui.error(f"Simulation {sim_id} not found."))
            return
        affected = self.db.affected_for(sim_id)
        # Integrity results recorded right after the run (before any recovery).
        found = {s: len({a["path"] for a in affected if a.get("status") == s}) for s in ("MODIFIED", "MISSING", "NEW")}
        integ = {"modified": found["MODIFIED"], "missing": found["MISSING"], "new": found["NEW"],
                 "unchanged": max((sim["files_monitored"] or 0) - found["MODIFIED"] - found["MISSING"], 0)}
        rec = {"restored": len([a for a in affected if a.get("recovery_status") == "RESTORED"]),
               "verified": len([a for a in affected if a.get("verified")]),
               "failed": len([a for a in affected if a.get("recovery_status") == "FAILED"]),
               "all_verified": (sim.get("recovery_status") == "VERIFIED")}
        report = build_report(sim, self.db.alerts_for(sim_id), integ, rec, affected)
        try:
            h, j = save_report(report, self.cfg.d("report_html_dir"), self.cfg.d("report_json_dir"))
        except OSError as exc:
            self.say(ui.error(f"cannot write report: {exc}"))
            return
        self.say(ui.ok(f"HTML report: {h}"))
        self.say(ui.ok(f"JSON export: {j}"))

    def show_dashboard(self):
        res = self.ctl.check_integrity() if self.ctl.env.is_initialized() else None
        integ = res.counts() if res else {}
        self.say(ui.dashboard(self.ctl.meta(), {
            "files_monitored": len(self.ctl.ensure_baseline().files) if self.ctl.env.is_initialized() else 0,
            "files_modified": self.ctl.stats.files_modified, "files_renamed": self.ctl.stats.files_renamed,
            "files_deleted": self.ctl.stats.files_deleted, "suspicious_ops": self.ctl.alert_counts().get("total", 0)},
            self.ctl.alert_counts(), integ, self.ctl.recovery_status,
            self.ctl.active_alerts(self.cfg["display"]["max_alerts_shown"])))

    # ------------------------------------------------------------------ menu
    def menu(self):
        self.say(ui.banner())
        actions = {"1": self.initialize_env, "2": self.generate_samples, "3": self.start_monitoring,
                   "4": self.run_safe, "5": self.run_demo, "6": self.view_alerts, "7": self.check_integrity,
                   "8": self.restore, "9": self.view_simulations, "10": self.generate_report}
        try:
            while True:
                mon = ui.green("ON") if self.ctl.monitoring else ui.dim("OFF")
                self.say("")
                self.say(f"{ui.bold('MAIN MENU')}   Monitoring: {mon}   "
                         f"Alerts: {self.ctl.alert_counts().get('total', 0)}")
                self.say("  1. Initialize Test Environment\n  2. Generate Sample Files\n  3. Start File Monitoring\n"
                         "  4. Run SAFE MODE Simulation\n  5. Run DEMONSTRATION MODE Simulation\n"
                         "  6. View Security Alerts\n  7. Check File Integrity\n  8. Restore Sample Files\n"
                         "  9. View Previous Simulations\n 10. Generate Security Report\n 11. Exit")
                try:
                    choice = self.input("Select an option (1-11): ").strip()
                except EOFError:
                    choice = "11"
                if choice == "11":
                    break
                action = actions.get(choice)
                if action is None:
                    self.say(ui.warn("Please choose a number from 1 to 11."))
                    continue
                try:
                    action()
                except KeyboardInterrupt:
                    self.say("\n" + ui.info("Cancelled."))
                except DatabaseError as exc:
                    self.say(ui.error(f"database error: {exc}"))
        finally:
            self.stop_monitoring()
            self.say(ui.info("Goodbye - stay safe."))


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Ransomware Behavior Simulator (defensive teaching tool)")
    p.add_argument("--config", help="path to config.json")
    p.add_argument("--safe", action="store_true", help="run a SAFE-mode simulation and exit")
    p.add_argument("--demo", action="store_true", help="run a DEMONSTRATION simulation (requires --yes) and exit")
    p.add_argument("--yes", action="store_true", help="confirm the demonstration non-interactively")
    p.add_argument("--report", type=int, metavar="N", help="write a report for simulation N and exit")
    p.add_argument("--simulations", action="store_true", help="list previous simulations and exit")
    p.add_argument("--no-color", action="store_true", help="disable coloured output")
    p.add_argument("--db", help=argparse.SUPPRESS)
    return p.parse_args(argv)


def main(argv=None, input_fn=input) -> int:
    args = parse_args(argv)
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(ui.error(str(exc)))
        return 2
    ui.set_color(cfg["display"]["color"] and not args.no_color and sys.stdout.isatty())
    try:
        db = Database(args.db or cfg.d("database"))
    except DatabaseError as exc:
        print(ui.error(str(exc)))
        return 2
    app = App(cfg, db, input_fn=input_fn)
    try:
        if args.simulations:
            app.view_simulations()
            return 0
        if args.report is not None:
            app.generate_report(args.report)
            return 0
        if args.safe:
            app.run_safe()
            return 0
        if args.demo:
            if not args.yes:
                print(ui.error("--demo requires --yes to confirm it will modify disposable sample files."))
                return 2
            app.run_demo(assume_yes=True)
            return 0
        app.menu()
        return 0
    finally:
        app.ctl.stop_monitoring()
        db.close()


if __name__ == "__main__":
    sys.exit(main())
