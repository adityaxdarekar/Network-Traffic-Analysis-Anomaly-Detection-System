import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config_loader import load_config          # noqa: E402
from safety import Sandbox                     # noqa: E402
from environment import EnvironmentBuilder     # noqa: E402


@pytest.fixture
def project(tmp_path):
    """A throwaway project directory with a config.json, so the whole app can
    run against tmp_path instead of the real project folder."""
    cfg = json.loads((ROOT / "config.json").read_text())
    cfg["monitor"]["engine"] = "poll"                 # deterministic in tests
    cfg["simulation"]["operation_delay_seconds"] = 0.0
    (tmp_path / "config.json").write_text(json.dumps(cfg))
    return tmp_path


@pytest.fixture
def config(project):
    return load_config(project / "config.json", base_dir=project)


@pytest.fixture
def test_box(config):
    box = Sandbox(config.d("test_dir"), "test directory")
    box.ensure()
    return box


@pytest.fixture
def populated(config, test_box):
    EnvironmentBuilder(test_box, config.sample_files).generate_sample_files()
    return test_box
