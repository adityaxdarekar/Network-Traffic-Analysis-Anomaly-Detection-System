"""End-to-end workflow through the controller, menu and CLI, run inside tmp_path."""
import io

import main as app_main
from alert_manager import AlertManager
from controller import SimulationController
from database import Database
from detection_engine import Detection


def make(config, project):
    db = Database(project / "database" / "t.db")
    return SimulationController(config, db), db


def test_safe_mode_detects_and_changes_nothing(config, project):
    ctl, db = make(config, project)
    ctl.generate_samples()
    before = {p: p.read_bytes() for p in ctl.test_box.iter_files()}
    sid = ctl.run_safe_simulation()
    after = {p: p.read_bytes() for p in ctl.test_box.iter_files()}
    assert before == after                                   # SAFE mode touched nothing
    cats = {a["category"] for a in db.alerts_for(sid)}
    assert {"Rapid File Modification", "Bulk File Renaming", "Ransom Note Creation",
            "Mass File Deletion", "Suspicious Extension Change"} <= cats
    assert db.simulation(sid)["mode"] == "SAFE"
    db.close()


def test_demo_mode_then_recovery_restores_everything(config, project):
    ctl, db = make(config, project)
    ctl.generate_samples()
    sid = ctl.run_demo_simulation()
    res = ctl.check_integrity()
    assert not res.intact
    assert db.alerts_for(sid)                                # detections came from the live (poll) monitor
    note = ctl.test_box.resolve(config.simulation["ransom_note_name"])
    assert note.exists() and "NOT been encrypted" in note.read_text()
    result = ctl.recover()
    assert result.all_verified and ctl.check_integrity().intact
    assert not note.exists()
    assert db.simulation(sid)["recovery_status"] == "VERIFIED"
    db.close()


def test_demo_never_writes_outside_sandbox(config, project):
    ctl, db = make(config, project)
    ctl.generate_samples()
    outside = project / "user_document.txt"
    outside.write_text("real user data")
    ctl.run_demo_simulation()
    ctl.recover()
    assert outside.read_text() == "real user data"
    db.close()


def test_alert_cooldown_merges_repeats(config):
    am = AlertManager(config["alerts"], simulation_id=3)
    d = lambda ts, n: Detection("R", "Bulk File Renaming", "HIGH", "t", "d", ts, "f",
                                {"files_renamed": n}, ("R",), ("files_renamed",))
    first = am.submit(d(100, 5))
    assert first.alert_id == "RBS-0003-00001"
    assert am.submit(d(103, 8)) is None
    assert first.occurrences == 2 and first.details["files_renamed"] == 8
    assert am.submit(d(200, 5)) is not None
    assert am.counts()["total"] == 2


def scripted(answers):
    it = iter(answers)
    return lambda prompt="": next(it)


def test_menu_walkthrough_and_demo_confirmation(config, project):
    out = io.StringIO()
    db = Database(project / "database" / "m.db")
    answers = ["1", "2", "7", "4", "6",
               "5", "no thanks",            # wrong phrase -> demo cancelled
               "9", "10", "", "x", "11"]
    app = app_main.App(config, db, input_fn=scripted(answers), out=out)
    app.menu()
    text = out.getvalue()
    for expected in ("Test environment ready", "sample files ready", "All files match the baseline",
                     "SAFE simulation", "Demonstration cancelled", "HTML report", "choose a number", "Goodbye"):
        assert expected in text, expected
    assert app.ctl.check_integrity().intact                  # cancelled demo changed nothing
    db.close()


def test_cli_demo_requires_yes(project, capsys):
    rc = app_main.main(["--config", str(project / "config.json"), "--demo", "--no-color",
                        "--db", str(project / "c.db")])
    assert rc == 2 and "--yes" in capsys.readouterr().out
