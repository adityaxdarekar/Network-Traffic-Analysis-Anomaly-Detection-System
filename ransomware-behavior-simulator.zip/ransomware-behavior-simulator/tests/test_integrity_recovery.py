from backup_manager import BackupManager
from integrity_checker import IntegrityChecker, sha256_bytes, sha256_file
from recovery import RecoveryManager
from safety import Sandbox


def test_sha256_known_value(tmp_path):
    p = tmp_path / "x.txt"
    p.write_bytes(b"abc")
    assert sha256_file(p) == sha256_bytes(b"abc") == \
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"


def test_sample_generation(populated, config):
    files = list(populated.iter_files())
    assert len(files) == config.sample_files["count"]
    assert any("sample_data" in str(f) for f in files)
    assert "disposable SAMPLE FILE" in files[0].read_text()


def test_integrity_detects_modified_missing_new(populated):
    ic = IntegrityChecker(populated)
    base = ic.build_baseline()
    assert ic.compare(base).intact
    populated.write_text(populated.resolve("document1.txt"), "changed")
    populated.delete(populated.resolve("report.txt"))
    populated.write_text(populated.resolve("brand_new.txt"), "hi")
    res = ic.compare(base)
    assert [m[0] for m in res.modified] == ["document1.txt"]
    assert res.missing == ["report.txt"] and res.new == ["brand_new.txt"]
    assert res.status_for("document1.txt") == "MODIFIED"


def test_baseline_round_trip(populated, tmp_path):
    ic = IntegrityChecker(populated)
    base = ic.build_baseline()
    p = ic.save_baseline(base, tmp_path / "b.json")
    again = ic.load_baseline(p)
    assert again.files.keys() == base.files.keys()


def test_backup_verify_and_tamper_detection(populated, config):
    bm = BackupManager(populated, Sandbox(config.d("backup_dir")))
    info = bm.create_backup("t")
    assert info.file_count == 10 and bm.verify_backup(info)
    bm.backup_file_path(info, "document1.txt").write_text("tampered")
    assert not bm.verify_backup(info)


def test_recovery_restores_and_verifies(populated, config):
    bm = BackupManager(populated, Sandbox(config.d("backup_dir")))
    info = bm.create_backup()
    ic = IntegrityChecker(populated)
    base = ic.build_baseline()
    populated.write_text(populated.resolve("document1.txt"), "placeholder")
    populated.delete(populated.resolve("notes.txt"))
    populated.write_text(populated.resolve("extra.txt"), "x")
    result = RecoveryManager(populated, bm).restore(info)
    c = result.counts()
    assert c["restored"] == 2 and c["failed"] == 0 and result.all_verified
    assert result.extra_removed == ["extra.txt"]
    assert ic.compare(base).intact


def test_recovery_refuses_tampered_backup(populated, config):
    import pytest
    bm = BackupManager(populated, Sandbox(config.d("backup_dir")))
    info = bm.create_backup()
    bm.backup_file_path(info, "report.txt").write_text("bad")
    with pytest.raises(RuntimeError, match="integrity"):
        RecoveryManager(populated, bm).restore(info)
