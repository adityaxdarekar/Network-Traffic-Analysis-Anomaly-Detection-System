import json
import os

import pytest

from config_loader import ConfigError, load_config
from safety import Sandbox, SafetyError, is_within


def test_resolve_blocks_traversal_and_absolute(test_box):
    for bad in [("..", "outside.txt"), ("..", "..", "etc", "passwd"), ("/etc/passwd",), ("sub", "..", "..", "x")]:
        with pytest.raises(SafetyError):
            test_box.resolve(*bad)
    assert test_box.resolve("ok.txt").parent == test_box.root


def test_check_rejects_paths_outside(test_box, tmp_path):
    with pytest.raises(SafetyError):
        test_box.check(tmp_path / "elsewhere.txt")
    assert is_within(test_box.root, test_box.root / "a" / "b.txt")
    assert not is_within(test_box.root, tmp_path)


def test_symlink_escape_is_refused(test_box, tmp_path):
    outside = tmp_path / "secret.txt"
    outside.write_text("do not touch")
    link = test_box.root / "link.txt"
    os.symlink(outside, link)
    with pytest.raises(SafetyError):          # resolves outside the sandbox
        test_box.write_text(link, "overwrite")
    assert outside.read_text() == "do not touch"


def test_delete_refuses_directories(test_box):
    d = test_box.resolve("folder")
    d.mkdir()
    with pytest.raises(SafetyError):
        test_box.delete(d)
    assert d.exists()


def test_too_broad_root_rejected():
    with pytest.raises(SafetyError):
        Sandbox(os.path.expanduser("~"))
    with pytest.raises(SafetyError):
        Sandbox("/")


def test_shipped_config_valid(config):
    assert config.detection["rapid_modification"]["files"] == 10
    assert config.detection["mass_deletion"]["severity"] == "CRITICAL"
    assert config.simulation["simulated_extension"] == ".simulated"


def test_config_errors_reported_together(tmp_path):
    (tmp_path / "config.json").write_text(json.dumps({
        "directories": {"test_dir": "../../escape"},
        "detection": {"bulk_rename": {"files": 0, "severity": "URGENT"}},
        "simulation": {"simulated_extension": "simulated"}}))
    with pytest.raises(ConfigError) as e:
        load_config(tmp_path / "config.json", base_dir=tmp_path)
    msg = str(e.value)
    for part in ("test_dir", "bulk_rename.files", "bulk_rename.severity", "simulated_extension"):
        assert part in msg


def test_bad_json(tmp_path):
    (tmp_path / "config.json").write_text("{nope")
    with pytest.raises(ConfigError, match="not valid JSON"):
        load_config(tmp_path / "config.json", base_dir=tmp_path)
