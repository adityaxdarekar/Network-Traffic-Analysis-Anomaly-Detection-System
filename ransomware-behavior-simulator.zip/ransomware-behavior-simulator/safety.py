"""
safety.py - the confinement layer. Every file operation in this project goes
through here, so the simulator can never touch anything outside its own
sandbox.

Design rules enforced by this module:
  * There is exactly one sandbox root per run (the test directory). A second
    root (the backup directory) is allowed only for backup/restore.
  * Every path is resolved to an absolute, symlink-free real path and must sit
    inside the sandbox. Anything else raises SafetyError - it is never clamped
    or "fixed up", because silently redirecting a path is how accidents happen.
  * Directory traversal ("..", absolute paths, symlinks that escape) is
    rejected, not sanitised.
  * This module performs no destructive action itself. It only validates paths
    and offers guarded open/copy helpers that the other modules must use.

Nothing here encrypts, hides, persists or deletes outside the sandbox.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Iterable, Union

PathLike = Union[str, os.PathLike]


class SafetyError(Exception):
    """Raised when an operation would touch a path outside an allowed sandbox."""


def _real(path: PathLike) -> Path:
    """Absolute, symlink-resolved path. Works even if the path does not exist yet
    (it resolves the nearest existing parent, then re-appends the tail)."""
    p = Path(path).expanduser()
    try:
        return Path(os.path.realpath(p))
    except OSError as exc:
        raise SafetyError(f"cannot resolve path {path!r}: {exc}") from exc


def is_within(root: PathLike, path: PathLike) -> bool:
    """True if *path* resolves to a location inside *root* (or is root itself)."""
    root_r, path_r = _real(root), _real(path)
    try:
        path_r.relative_to(root_r)
        return True
    except ValueError:
        return False


class Sandbox:
    """A directory that confines all file operations.

    Example:
        box = Sandbox("/project/test_environment")
        box.ensure()
        f = box.resolve("document1.txt")   # safe absolute path inside the box
        box.write_text(f, "hello")
    """

    def __init__(self, root: PathLike, label: str = "sandbox"):
        self.label = label
        self.root = _real(root)
        if self.root == _real(Path.home()) or str(self.root) == os.sep:
            raise SafetyError(f"{label} root {self.root} is too broad; choose a dedicated subdirectory")

    # -- creation -----------------------------------------------------------
    def ensure(self) -> Path:
        self.root.mkdir(parents=True, exist_ok=True)
        return self.root

    # -- validation ---------------------------------------------------------
    def check(self, path: PathLike) -> Path:
        """Return the resolved path if it is inside the sandbox, else raise."""
        rp = _real(path)
        if not is_within(self.root, rp):
            raise SafetyError(f"path {path!r} is outside the {self.label} ({self.root})")
        return rp

    def resolve(self, *parts: str) -> Path:
        """Join *parts* onto the sandbox root and validate (blocks '..' escapes)."""
        if not parts:
            return self.root
        for part in parts:
            if part is None:
                raise SafetyError("path component is None")
            s = str(part)
            if s.startswith(("/", "\\")) or (len(s) > 1 and s[1] == ":"):
                raise SafetyError(f"absolute path component not allowed: {s!r}")
        candidate = self.root.joinpath(*(str(p) for p in parts))
        return self.check(candidate)

    def contains(self, path: PathLike) -> bool:
        return is_within(self.root, path)

    def assert_not_symlink(self, path: PathLike) -> Path:
        p = Path(path)
        if p.is_symlink():
            raise SafetyError(f"refusing to operate on a symlink: {p}")
        return p

    # -- guarded operations -------------------------------------------------
    def write_text(self, path: PathLike, text: str, *, encoding: str = "utf-8") -> Path:
        p = self.check(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.assert_not_symlink(p)
        p.write_text(text, encoding=encoding)
        return p

    def write_bytes(self, path: PathLike, data: bytes) -> Path:
        p = self.check(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.assert_not_symlink(p)
        p.write_bytes(data)
        return p

    def read_bytes(self, path: PathLike) -> bytes:
        return self.check(path).read_bytes()

    def rename(self, src: PathLike, dst: PathLike) -> Path:
        s, d = self.check(src), self.check(dst)
        self.assert_not_symlink(s)
        d.parent.mkdir(parents=True, exist_ok=True)
        os.replace(s, d)
        return d

    def delete(self, path: PathLike) -> None:
        """Delete a single file inside the sandbox. Never recurses, never
        follows symlinks, never touches a directory tree."""
        p = self.check(path)
        if p.is_symlink():
            raise SafetyError(f"refusing to delete a symlink: {p}")
        if p.is_dir():
            raise SafetyError(f"refusing to delete a directory: {p}")
        if p.exists():
            p.unlink()

    def iter_files(self, *, include_subdirs: bool = True) -> Iterable[Path]:
        """Yield every regular file in the sandbox (skips symlinks)."""
        it = self.root.rglob("*") if include_subdirs else self.root.glob("*")
        for p in sorted(it):
            if p.is_file() and not p.is_symlink():
                yield p

    def relative(self, path: PathLike) -> str:
        return str(self.check(path).relative_to(self.root))


def guarded_copy(src: PathLike, dst: PathLike, dst_sandbox: "Sandbox") -> Path:
    """Copy a real file into *dst_sandbox* (used by the backup manager). The
    source may be anywhere the user owns; the destination must be inside the
    backup sandbox."""
    d = dst_sandbox.check(dst)
    s = Path(src)
    if s.is_symlink():
        raise SafetyError(f"refusing to copy a symlink: {s}")
    if not s.is_file():
        raise SafetyError(f"source is not a regular file: {s}")
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(s, d)
    return d
