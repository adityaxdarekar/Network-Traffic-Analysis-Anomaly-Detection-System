"""
alert_manager.py - turn Detection objects into structured alerts with
de-duplication, cooldown and a recommended action.

One alert per dedupe key per cooldown period. Repeats within the cooldown only
update the existing alert (occurrence count, last seen, peak values), so the
dashboard is not flooded. Listeners (database, live display) are notified for
new alerts and, on flush(), for updated ones.
"""
from __future__ import annotations

import threading
from collections import Counter, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Callable, Optional

from detection_engine import (BULK_RENAME, MASS_DELETION, RANSOM_NOTE, RAPID_CREATION,
                              RAPID_MODIFICATION, SUSPICIOUS_EXT, Detection)

SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

RECOMMENDATIONS = {
    RAPID_MODIFICATION: ("Pause the activity and identify the process modifying the files. If it is not an "
                         "authorised batch job, stop it and restore affected files from a verified backup."),
    RAPID_CREATION: "Identify what is creating the files; confirm it is expected before continuing.",
    BULK_RENAME: ("Stop the renaming process. Mass renaming to a new extension is a strong ransomware indicator; "
                  "restore the original names/content from backup and investigate the source."),
    SUSPICIOUS_EXT: ("Check which process is appending the extension. Compare current file hashes with the "
                     "baseline and restore from backup if the content changed."),
    RANSOM_NOTE: ("Treat as an incident: isolate the machine, preserve the note and logs for analysis, and begin "
                  "recovery from verified backups. (Here the note is a harmless simulation marker.)"),
    MASS_DELETION: ("Highest priority: stop further deletion, preserve logs, and restore the deleted files from a "
                    "verified backup. Confirm backups themselves are intact and offline."),
}


@dataclass
class Alert:
    alert_id: str
    timestamp: str
    epoch: float
    category: str
    severity: str
    title: str
    description: str
    rule: str
    file: Optional[str]
    recommended_action: str
    details: dict = field(default_factory=dict)
    occurrences: int = 1
    last_seen: str = ""
    simulation_id: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)


def _iso(ts: float) -> str:
    try:
        return datetime.fromtimestamp(ts).isoformat(timespec="seconds")
    except (OverflowError, OSError, ValueError):
        return datetime.now().isoformat(timespec="seconds")


class AlertManager:
    def __init__(self, config: dict, simulation_id: Optional[int] = None):
        self.cooldown = float(config["cooldown_seconds"])
        self.limit = config["active_alert_limit"]
        self.simulation_id = simulation_id
        self._lock = threading.RLock()
        self._active: deque = deque(maxlen=self.limit)
        self._all = 0
        self._by_sev: Counter = Counter()
        self._by_cat: Counter = Counter()
        self._last: dict = {}
        self._last_epoch: dict = {}
        self._dirty: dict = {}
        self.suppressed = 0
        self._seq = 0
        self._listeners: list[Callable[[Alert, bool], None]] = []

    def add_listener(self, fn: Callable[[Alert, bool], None]):
        self._listeners.append(fn)

    def _notify(self, alert: Alert, is_new: bool):
        for fn in list(self._listeners):
            try:
                fn(alert, is_new)
            except Exception as exc:
                print(f"[alert listener error] {exc}")

    def _next_id(self) -> str:
        self._seq += 1
        sid = f"{self.simulation_id:04d}" if isinstance(self.simulation_id, int) else "0000"
        return f"RBS-{sid}-{self._seq:05d}"

    def submit(self, d: Detection) -> Optional[Alert]:
        with self._lock:
            key = d.dedupe_key or (d.rule, d.file)
            last = self._last_epoch.get(key)
            if last is not None and d.timestamp - last < self.cooldown:
                ex = self._last[key]
                ex.occurrences += 1
                ex.last_seen = _iso(d.timestamp)
                for f in d.peak_fields:
                    if isinstance(d.details.get(f), (int, float)):
                        ex.details[f] = max(ex.details.get(f, 0), d.details[f])
                self._dirty[ex.alert_id] = ex
                self.suppressed += 1
                return None
            alert = Alert(alert_id=self._next_id(), timestamp=_iso(d.timestamp), epoch=d.timestamp,
                          category=d.category, severity=d.severity, title=d.title, description=d.description,
                          rule=d.rule, file=d.file,
                          recommended_action=RECOMMENDATIONS.get(d.category, "Investigate the activity."),
                          details=dict(d.details), last_seen=_iso(d.timestamp), simulation_id=self.simulation_id)
            self._active.append(alert)
            self._all += 1
            self._by_sev[alert.severity] += 1
            self._by_cat[alert.category] += 1
            self._last[key] = alert
            self._last_epoch[key] = d.timestamp
        self._notify(alert, True)
        return alert

    def flush(self) -> int:
        with self._lock:
            updated = list(self._dirty.values())
            self._dirty.clear()
        for a in updated:
            self._notify(a, False)
        return len(updated)

    def active_alerts(self, limit: Optional[int] = None) -> list[Alert]:
        with self._lock:
            items = list(self._active)
        return items[-limit:] if limit else items

    def counts(self) -> dict:
        with self._lock:
            return {"total": self._all, **{s: self._by_sev.get(s, 0) for s in SEVERITY_ORDER},
                    "by_category": dict(self._by_cat), "suppressed_duplicates": self.suppressed}
