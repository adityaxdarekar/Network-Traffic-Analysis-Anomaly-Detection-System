"""
report_generator.py - SOC-style HTML report + JSON export for a simulation.

Every value placed into the HTML is escaped. The report is built from the
database rows for one simulation plus the integrity and recovery results.
"""
from __future__ import annotations

import html
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

TITLE = "Ransomware Behavior Simulator - Security Report"
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
SEV_COLORS = {"CRITICAL": "#b91c1c", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#2563eb"}


def build_report(simulation: dict, alerts: list[dict], integrity: dict, recovery: dict,
                 affected: list[dict]) -> dict:
    sev = Counter(a["severity"] for a in alerts)
    cats = Counter(a["category"] for a in alerts)
    return {
        "title": TITLE,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "simulation": {
            "id": simulation.get("id"), "mode": simulation.get("mode"),
            "start": simulation.get("started"), "end": simulation.get("ended"),
            "test_dir": simulation.get("test_dir"), "backup_id": simulation.get("backup_id"),
        },
        "files_monitored": simulation.get("files_monitored", 0),
        "files_modified": simulation.get("files_modified", 0),
        "files_renamed": simulation.get("files_renamed", 0),
        "files_deleted": simulation.get("files_deleted", 0),
        "suspicious_ops": simulation.get("suspicious_ops", 0),
        "alerts_by_severity": {s: sev.get(s, 0) for s in SEVERITIES},
        "alerts_by_category": dict(cats.most_common()),
        "total_alerts": len(alerts),
        "integrity": integrity,
        "recovery": recovery,
        "alerts": alerts,
        "affected_files": affected,
        "note": ("This is an educational simulation. No real encryption was performed; affected files are "
                 "disposable samples in a dedicated test directory and were restored from verified backups. "
                 "Detections are heuristic indicators requiring analyst verification."),
    }


def _e(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def to_html(r: dict) -> str:
    s = r["simulation"]
    sev_cards = "".join(
        f"<div class='card' style='border-top-color:{SEV_COLORS[k]}'><div class='big'>{v}</div>{k}</div>"
        for k, v in r["alerts_by_severity"].items())
    alert_rows = "".join(
        f"<tr><td>{_e(a['alert_id'])}</td><td>{_e(a['timestamp'])}</td>"
        f"<td><span class='sev' style='background:{SEV_COLORS.get(a['severity'],'#555')}'>{_e(a['severity'])}</span></td>"
        f"<td>{_e(a['category'])}</td><td>{_e(a.get('file') or '-')}</td>"
        f"<td><b>{_e(a.get('title'))}</b><br>{_e(a.get('description'))}"
        f"<div class='muted'>Action: {_e(a.get('recommended_action'))}</div></td></tr>"
        for a in r["alerts"]) or "<tr><td colspan='6'>No alerts.</td></tr>"
    cat_rows = "".join(f"<tr><td>{_e(c)}</td><td class='num'>{n}</td></tr>"
                       for c, n in r["alerts_by_category"].items()) or "<tr><td colspan='2'>None</td></tr>"
    aff_rows = "".join(
        f"<tr><td>{_e(a['path'])}</td><td>{_e(a.get('status'))}</td><td>{_e(a.get('recovery_status') or '-')}</td>"
        f"<td>{'PASSED' if a.get('verified') else '-'}</td></tr>" for a in r["affected_files"]) or \
        "<tr><td colspan='4'>None recorded.</td></tr>"
    integ, rec = r["integrity"], r["recovery"]
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>RBS Report</title><style>
body{{font-family:Segoe UI,Helvetica,Arial,sans-serif;margin:0;background:#f4f6f9;color:#1f2937}}
header{{background:#0f172a;color:#fff;padding:24px 32px}} header h1{{margin:0;font-size:22px}}
main{{max-width:1080px;margin:auto;padding:24px}} section{{background:#fff;border-radius:8px;padding:18px 22px;
margin-bottom:18px;box-shadow:0 1px 3px rgba(0,0,0,.08)}} h2{{font-size:17px;margin:0 0 12px}}
table{{width:100%;border-collapse:collapse;font-size:14px}} th,td{{text-align:left;padding:7px 8px;
border-bottom:1px solid #e5e7eb;vertical-align:top}} th{{background:#f9fafb}} .num{{text-align:right}}
.cards{{display:flex;gap:12px;flex-wrap:wrap}} .card{{flex:1;min-width:110px;background:#f9fafb;border-top:4px solid;
border-radius:6px;padding:12px;text-align:center;font-weight:600}} .big{{font-size:28px}}
.sev{{color:#fff;padding:2px 7px;border-radius:4px;font-size:12px;font-weight:700}}
.muted{{color:#6b7280;font-size:12px;margin-top:4px}} .grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
.note{{background:#fffbeb;border-left:4px solid #ca8a04}} .ok{{color:#15803d;font-weight:600}}
</style></head><body>
<header><h1>{_e(r['title'])}</h1><div>Generated {_e(r['generated'])}</div></header><main>
<section><h2>1. Simulation</h2><table>
<tr><th>Simulation ID</th><td>{_e(s['id'])}</td><th>Mode</th><td>{_e(s['mode'])}</td></tr>
<tr><th>Started</th><td>{_e(s['start'])}</td><th>Ended</th><td>{_e(s['end'] or '-')}</td></tr>
<tr><th>Test directory</th><td>{_e(s['test_dir'])}</td><th>Backup</th><td>{_e(s['backup_id'] or '-')}</td></tr>
</table></section>
<section><h2>2. Activity summary</h2><table>
<tr><th>Files monitored</th><td>{r['files_monitored']}</td><th>Files modified</th><td>{r['files_modified']}</td></tr>
<tr><th>Files renamed</th><td>{r['files_renamed']}</td><th>Files deleted</th><td>{r['files_deleted']}</td></tr>
<tr><th>Suspicious operations</th><td colspan='3'>{r['suspicious_ops']}</td></tr></table></section>
<section><h2>3. Alerts by severity (total {r['total_alerts']})</h2><div class='cards'>{sev_cards}</div></section>
<section class='grid'>
<div><h2>4. Detection engine results</h2><table><tr><th>Category</th><th class='num'>Alerts</th></tr>{cat_rows}</table></div>
<div><h2>5. File integrity</h2><table>
<tr><th>Modified</th><td class='num'>{integ.get('modified',0)}</td></tr>
<tr><th>Missing</th><td class='num'>{integ.get('missing',0)}</td></tr>
<tr><th>New</th><td class='num'>{integ.get('new',0)}</td></tr>
<tr><th>Unchanged</th><td class='num'>{integ.get('unchanged',0)}</td></tr></table></div></section>
<section><h2>6. Recovery results</h2><table>
<tr><th>Restored</th><td>{rec.get('restored',0)}</td><th>Verified</th><td>{rec.get('verified',0)}</td>
<th>Failed</th><td>{rec.get('failed',0)}</td></tr></table>
<p class="{'ok' if rec.get('all_verified') else ''}">{'All restored files verified against backup hashes.' if rec.get('all_verified') else 'Recovery not fully verified - see details.'}</p>
<table><tr><th>File</th><th>Status</th><th>Recovery</th><th>Integrity</th></tr>{aff_rows}</table></section>
<section><h2>7. Alert details</h2><table><tr><th>ID</th><th>Time</th><th>Severity</th><th>Category</th>
<th>File</th><th>Description</th></tr>{alert_rows}</table></section>
<section><h2>8. Security recommendations</h2><ul>
<li>Keep verified, offline backups; ransomware targets reachable backups first.</li>
<li>Alert on bulk file modification, renaming to new extensions, and mass deletion.</li>
<li>Monitor file integrity with hashing so unauthorised changes are caught early.</li>
<li>Rehearse recovery so restoration is fast and verified during a real incident.</li></ul></section>
<section class='note'><b>Note.</b> {_e(r['note'])}</section>
</main></body></html>"""


def to_json(r: dict) -> str:
    return json.dumps(r, indent=2, default=str)


def save_report(r: dict, html_dir: Path, json_dir: Path) -> tuple[Path, Path]:
    html_dir, json_dir = Path(html_dir), Path(json_dir)
    html_dir.mkdir(parents=True, exist_ok=True)
    json_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    sid = r["simulation"].get("id") or 0
    hp = html_dir / f"rbs_report_sim{sid}_{stamp}.html"
    jp = json_dir / f"rbs_report_sim{sid}_{stamp}.json"
    hp.write_text(to_html(r), encoding="utf-8")
    jp.write_text(to_json(r), encoding="utf-8")
    return hp, jp
