"""
database.py - SQLite storage for simulations, file-activity events, alerts,
affected files and recovery results.

One connection shared across threads (check_same_thread=False), serialised with
a lock. All queries are parameterised.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS simulations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    started    TEXT NOT NULL,
    ended      TEXT,
    mode       TEXT NOT NULL,
    test_dir   TEXT,
    backup_id  TEXT,
    files_monitored INTEGER DEFAULT 0,
    files_modified  INTEGER DEFAULT 0,
    files_renamed   INTEGER DEFAULT 0,
    files_deleted   INTEGER DEFAULT 0,
    suspicious_ops  INTEGER DEFAULT 0,
    alert_count     INTEGER DEFAULT 0,
    recovery_status TEXT,
    notes      TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    simulation_id INTEGER REFERENCES simulations(id),
    timestamp  TEXT NOT NULL,
    kind       TEXT NOT NULL,
    path       TEXT,
    dest_path  TEXT
);
CREATE TABLE IF NOT EXISTS alerts (
    alert_id   TEXT PRIMARY KEY,
    simulation_id INTEGER REFERENCES simulations(id),
    timestamp  TEXT NOT NULL,
    category   TEXT NOT NULL,
    severity   TEXT NOT NULL,
    title      TEXT,
    description TEXT,
    rule       TEXT,
    file       TEXT,
    recommended_action TEXT,
    details    TEXT,
    occurrences INTEGER DEFAULT 1,
    last_seen  TEXT
);
CREATE TABLE IF NOT EXISTS affected_files (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    simulation_id INTEGER REFERENCES simulations(id),
    path       TEXT NOT NULL,
    status     TEXT,
    baseline_sha256 TEXT,
    current_sha256  TEXT,
    recovery_status TEXT,
    verified   INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_alerts_sim ON alerts(simulation_id);
CREATE INDEX IF NOT EXISTS idx_events_sim ON events(simulation_id);
CREATE INDEX IF NOT EXISTS idx_affected_sim ON affected_files(simulation_id);
"""


class DatabaseError(RuntimeError):
    pass


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10)
            self.conn.row_factory = sqlite3.Row
            with self.conn:
                self.conn.executescript(SCHEMA)
        except sqlite3.Error as exc:
            raise DatabaseError(f"cannot open database {self.path}: {exc}") from exc

    def close(self):
        with self._lock:
            self.conn.close()

    def _exec(self, sql, params=()):
        with self._lock:
            try:
                with self.conn:
                    return self.conn.execute(sql, params)
            except sqlite3.Error as exc:
                raise DatabaseError(str(exc)) from exc

    def _rows(self, sql, params=()):
        with self._lock:
            try:
                rows = self.conn.execute(sql, params).fetchall()
            except sqlite3.Error as exc:
                raise DatabaseError(str(exc)) from exc
        out = []
        for r in rows:
            d = dict(r)
            if "details" in d and d["details"]:
                try:
                    d["details"] = json.loads(d["details"])
                except json.JSONDecodeError:
                    d["details"] = {}
            out.append(d)
        return out

    # ----------------------------------------------------------- simulations
    def create_simulation(self, mode: str, test_dir: str, backup_id: str = "") -> int:
        cur = self._exec("INSERT INTO simulations (started, mode, test_dir, backup_id) VALUES (?,?,?,?)",
                         (datetime.now().isoformat(timespec="seconds"), mode, test_dir, backup_id))
        return int(cur.lastrowid)

    def finish_simulation(self, sim_id: int, stats: dict, recovery_status: str = "") -> None:
        self._exec(
            """UPDATE simulations SET ended=?, files_monitored=?, files_modified=?, files_renamed=?,
               files_deleted=?, suspicious_ops=?, alert_count=?, recovery_status=?, backup_id=COALESCE(?, backup_id)
               WHERE id=?""",
            (datetime.now().isoformat(timespec="seconds"), stats.get("files_monitored", 0),
             stats.get("files_modified", 0), stats.get("files_renamed", 0), stats.get("files_deleted", 0),
             stats.get("suspicious_ops", 0), stats.get("alert_count", 0), recovery_status,
             stats.get("backup_id"), sim_id))

    def simulation(self, sim_id: int) -> Optional[dict]:
        rows = self._rows("SELECT * FROM simulations WHERE id=?", (sim_id,))
        return rows[0] if rows else None

    def simulations(self, limit: int = 20) -> list[dict]:
        return self._rows("SELECT * FROM simulations ORDER BY id DESC LIMIT ?", (int(limit),))

    def latest_simulation(self) -> Optional[dict]:
        rows = self.simulations(1)
        return rows[0] if rows else None

    # ---------------------------------------------------------------- events
    def save_event(self, sim_id: int, ev) -> None:
        self._exec("INSERT INTO events (simulation_id, timestamp, kind, path, dest_path) VALUES (?,?,?,?,?)",
                   (sim_id, datetime.fromtimestamp(ev.timestamp).isoformat(timespec="seconds"),
                    ev.kind, ev.path, ev.dest_path))

    def events_for(self, sim_id: int, limit: int = 1000) -> list[dict]:
        return self._rows("SELECT * FROM events WHERE simulation_id=? ORDER BY id LIMIT ?", (sim_id, int(limit)))

    # ---------------------------------------------------------------- alerts
    def save_alert(self, alert) -> None:
        a = alert.to_dict() if hasattr(alert, "to_dict") else dict(alert)
        self._exec(
            """INSERT INTO alerts (alert_id, simulation_id, timestamp, category, severity, title, description,
                   rule, file, recommended_action, details, occurrences, last_seen)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(alert_id) DO UPDATE SET occurrences=excluded.occurrences,
                   details=excluded.details, last_seen=excluded.last_seen""",
            (a["alert_id"], a.get("simulation_id"), a["timestamp"], a["category"], a["severity"], a.get("title"),
             a.get("description"), a.get("rule"), a.get("file"), a.get("recommended_action"),
             json.dumps(a.get("details", {}), default=str), a.get("occurrences", 1), a.get("last_seen")))

    def alerts_for(self, sim_id: int) -> list[dict]:
        return self._rows("SELECT * FROM alerts WHERE simulation_id=? ORDER BY timestamp, alert_id", (sim_id,))

    def recent_alerts(self, limit: int = 50) -> list[dict]:
        return self._rows("SELECT * FROM alerts ORDER BY timestamp DESC, alert_id DESC LIMIT ?", (int(limit),))

    # -------------------------------------------------------- affected files
    def save_affected(self, sim_id: int, path: str, status: str, baseline: str = "", current: str = "",
                      recovery_status: str = "", verified: bool = False) -> None:
        self._exec(
            """INSERT INTO affected_files (simulation_id, path, status, baseline_sha256, current_sha256,
               recovery_status, verified) VALUES (?,?,?,?,?,?,?)""",
            (sim_id, path, status, baseline, current, recovery_status, 1 if verified else 0))

    def affected_for(self, sim_id: int) -> list[dict]:
        return self._rows("SELECT * FROM affected_files WHERE simulation_id=? ORDER BY path", (sim_id,))
