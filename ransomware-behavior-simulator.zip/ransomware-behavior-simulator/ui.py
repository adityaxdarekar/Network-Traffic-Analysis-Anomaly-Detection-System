"""
ui.py - terminal presentation: banner, colours, tables and the dashboard.
colorama and tabulate are used if present, with plain-text fallbacks.
"""
from __future__ import annotations

import sys

try:
    from colorama import Fore, Style, init as _ci
    _ci()
    _HAS_COLOR = True
except ImportError:
    _HAS_COLOR = False

try:
    from tabulate import tabulate as _tab
except ImportError:
    _tab = None

COLOR = False


def set_color(on: bool):
    global COLOR
    COLOR = bool(on) and _HAS_COLOR


def _c(t, color):
    if not COLOR:
        return t
    codes = {"red": Fore.RED, "green": Fore.GREEN, "yellow": Fore.YELLOW, "blue": Fore.BLUE,
             "cyan": Fore.CYAN, "magenta": Fore.MAGENTA, "bold": Style.BRIGHT, "dim": Style.DIM}
    return f"{codes.get(color,'')}{t}{Style.RESET_ALL}"


def red(t): return _c(t, "red")
def green(t): return _c(t, "green")
def yellow(t): return _c(t, "yellow")
def cyan(t): return _c(t, "cyan")
def bold(t): return _c(t, "bold")
def dim(t): return _c(t, "dim")


SEV = {"CRITICAL": "magenta", "HIGH": "red", "MEDIUM": "yellow", "LOW": "blue"}


def sev(s): return _c(s, SEV.get(s, "blue"))


BANNER = r"""
 ____  ____  ____    ____  _           _       _
|  _ \| __ )/ ___|  / ___|(_)_ __ ___ | |_   _| |  __ _ _ __
| |_) |  _ \\___ \  \___ \| | '_ ` _ \| | | | | | / _` | '__|
|  _ <| |_) |___) |  ___) | | | | | | | | |_| | || (_| | |
|_| \_\____/|____/  |____/|_|_| |_| |_|_|\__,_|_(_)__,_|_|
   RANSOMWARE BEHAVIOR SIMULATOR  -  defensive teaching tool
   Safe by design: a sandboxed test directory only. No real encryption.
"""


def banner(): return cyan(BANNER)
def info(m): return f"{cyan('[*]')} {m}"
def ok(m): return f"{green('[+]')} {m}"
def warn(m): return f"{yellow('[!]')} {m}"
def error(m): return f"{red('[x]')} {m}"


def table(rows, headers):
    if not rows:
        return dim("(none)")
    if _tab:
        return _tab(rows, headers=headers, tablefmt="simple_grid")
    widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) for i, h in enumerate(headers)]
    line = "  ".join(str(h).ljust(w) for h, w in zip(headers, widths))
    body = "\n".join("  ".join(str(c).ljust(w) for c, w in zip(r, widths)) for r in rows)
    return f"{line}\n{'-'*len(line)}\n{body}"


def short(t, n):
    t = "" if t is None else str(t)
    return t if len(t) <= n else t[:n-3] + "..."


def alert_block(a) -> str:
    g = a.get if isinstance(a, dict) else (lambda k, d=None: getattr(a, k, d))
    det = g("details") or {}
    lines = [f"{sev('['+g('severity')+']')} {bold(g('title') or g('category'))}  {dim(g('alert_id'))}",
             f"   Time: {g('timestamp')}   File: {g('file') or '-'}"]
    nums = {k: det[k] for k in ("files_modified", "files_renamed", "files_deleted", "files_changed",
                                "files_created") if k in det}
    if nums:
        lines.append("   " + "   ".join(f"{k.replace('_',' ').title()}: {v}" for k, v in nums.items()))
    if (g("occurrences") or 1) > 1:
        lines.append(dim(f"   repeated {g('occurrences')} times (merged during cooldown)"))
    return "\n".join(lines)


def dashboard(meta: dict, stats: dict, counts: dict, integrity: dict, recovery: str, alerts: list,
              width: int = 78) -> str:
    out = [cyan("=" * width), bold("  RANSOMWARE BEHAVIOR SIMULATOR - DASHBOARD".center(width)), cyan("=" * width)]
    sim_status = green(meta.get("sim_status", "IDLE")) if meta.get("sim_status") == "RUNNING" \
        else yellow(meta.get("sim_status", "IDLE"))
    mon = green("ON") if meta.get("monitoring") else dim("OFF")
    out += [f"  Simulator: {sim_status}    Monitoring: {mon}    Mode: {meta.get('mode','-')}",
            f"  Test directory: {meta.get('test_dir','-')}",
            f"  Simulation: {meta.get('simulation_id','-')}    Backup: {meta.get('backup_id','-')}", ""]
    files = [["Files Monitored", stats.get("files_monitored", 0)], ["Files Modified", stats.get("files_modified", 0)],
             ["Files Renamed", stats.get("files_renamed", 0)], ["Files Deleted", stats.get("files_deleted", 0)],
             ["Suspicious Ops", stats.get("suspicious_ops", 0)]]
    al = [["Total Alerts", counts.get("total", 0)], [sev("CRITICAL"), counts.get("CRITICAL", 0)],
          [sev("HIGH"), counts.get("HIGH", 0)], [sev("MEDIUM"), counts.get("MEDIUM", 0)],
          [sev("LOW"), counts.get("LOW", 0)]]
    left, right = table(files, ["Activity", "Count"]).splitlines(), table(al, ["Alerts", "Count"]).splitlines()
    lw = max(len(_strip(x)) for x in left)
    for i in range(max(len(left), len(right))):
        l = left[i] if i < len(left) else ""
        r = right[i] if i < len(right) else ""
        out.append("  " + l + " " * (lw - len(_strip(l)) + 4) + r)
    out += ["", f"  File integrity -> modified: {integrity.get('modified',0)}  missing: {integrity.get('missing',0)}"
                f"  new: {integrity.get('new',0)}  unchanged: {integrity.get('unchanged',0)}",
            f"  Recovery status: {recovery or '-'}", "", bold("  SECURITY ALERTS (latest first):")]
    if not alerts:
        out.append(dim("  No alerts."))
    for a in reversed(alerts):
        import textwrap
        out.append(textwrap.indent(alert_block(a), "  "))
    out += ["", dim("  Press Ctrl+C to stop.")]
    return "\n".join(out)


def _strip(s):
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", s)
