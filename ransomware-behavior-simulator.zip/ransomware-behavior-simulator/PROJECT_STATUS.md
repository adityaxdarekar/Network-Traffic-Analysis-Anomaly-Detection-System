# Project status - verified vs. still to verify

## ✅ Verified in the build environment (Ubuntu 24.04, Python 3.13, watchdog installed)
| Item | Evidence |
|---|---|
| All modules compile and work together | full CLI runs: `--safe`, `--demo --yes`, `--report 1` |
| 21 automated tests pass | `python3 -m pytest -q` → 21 passed |
| Sandbox confinement | tests: `..`, absolute paths, a symlink pointing outside, directory deletion and over-broad roots are all rejected; a file outside the sandbox is untouched after a demo + restore |
| SAFE mode changes nothing | test compares every file's bytes before and after |
| Detection | all five main rules fire (modification, renaming, extension change, note, deletion) in SAFE mode and with the **real Watchdog monitor** in DEMONSTRATION mode |
| Integrity monitoring | modified / missing / new detected (tests and demo run: 4 modified, 6 missing, 1 new) |
| Backup and recovery | demo run: 10 restored, 10 verified, 0 failed; tampered backups are refused (test) |
| Cooldown, database history, HTML/JSON reports, menu (including a cancelled demo) | tests; visual check of the report (`screenshots/`) |

## ⚠️ Not verified here
| Item | How to check |
|---|---|
| Kali Linux / Ubuntu desktop and **Windows** | install per README Phase 3 and run `python3 -m pytest -q`, then the demo guide |
| Watchdog event timing on your machine | slower disks or VMs may need a larger `simulation.operation_delay_seconds` or different thresholds |
| Polling fallback on a real system | set `"monitor": {"engine": "poll"}`; renames show as delete + create |

## Scope decisions
* **No encryption of any kind.** This is deliberate. The "simulated encryption" step overwrites disposable sample copies with a placeholder line, which is the brief's "dummy content" option.
* The optional Tkinter GUI was not built. The terminal dashboard and menu cover the required features.
* `sample_output/` and `screenshots/` come from a real DEMONSTRATION run on the generated sample files in the build environment, and are labelled as such.
