# Ransomware Behavior Simulator (Python) - defensive teaching tool

This tool makes ransomware-*like* file activity happen inside a sandbox folder it creates itself. It then detects that activity, raises alerts, checks file integrity with SHA-256 and restores the files from verified backups. It is built for a college cybersecurity demonstration of the defensive side: monitoring, detection, integrity checking and recovery.

> **Safe by design.**
> * It performs **no encryption of any kind**. The "simulated encryption" step overwrites disposable sample copies with a fixed placeholder line, and those copies were backed up first.
> * It has no persistence, no networking, no process killing and no stealth.
> * Every file operation goes through `safety.py`, which confines it to `test_environment/` (and `backups/` for backups). Path traversal, absolute paths and symlinks that point outside the sandbox are rejected.
>
> Read **PROJECT_STATUS.md** for what was verified and what was not.

---

## PHASE 1 - Architecture and working method

```
             ┌──────────── main.py (menu / CLI) ────────────┐
             │                                              │
       controller.py  (orchestrates one run)                │
             │                                              │
  environment.py ─► test_environment/  ◄── activity_generator.py
  (sample files)        │      ▲              SAFE: synthetic events only (no file changes)
                        │      │              DEMO: benign real ops on disposable copies
             file_monitor.py (Watchdog, or polling fallback)
                        │ FileEvent
                   event queue ─► processing thread
                                     ├─ detection_engine.py  (sliding-window behaviour rules)
                                     ├─ alert_manager.py     (alerts, cooldown, recommended actions)
                                     └─ database.py          (SQLite: simulations, events, alerts, affected files)
  integrity_checker.py  SHA-256 baseline ⇄ live files  → modified / missing / new
  backup_manager.py     copy + manifest hashes (taken before every demo)
  recovery.py           restore from a *verified* backup, re-hash every restored file
  report_generator.py   HTML + JSON report          ui.py  banner, colours, dashboard
```

**Workflow** (brief §4): launch → environment → sample files → baseline hashes → backup → monitoring → SAFE or DEMONSTRATION run → detection → alerts → integrity comparison → recovery → verification → report.

### Detection rules (all in `config.json → detection`)

| Rule | Default threshold | Severity |
|---|---|---|
| Rapid file modification | 10 modifications in 5 s | HIGH |
| Bulk file renaming | 5 renames in 5 s | HIGH |
| Suspicious extension change | 3 files gaining a watched extension (`.simulated`, `.locked`, `.encrypted`, …) in 5 s | MEDIUM |
| Ransom note creation | file name contains a note marker, or a small `.txt` contains the simulation marker text | HIGH |
| Mass file deletion | 5 deletions in 5 s | CRITICAL |
| Rapid file creation | 12 creations in 5 s | MEDIUM |

Each rule looks for a **pattern within a time window**, so ordinary single edits do not alert. Repeats inside `alerts.cooldown_seconds` are merged into one alert: its occurrence count and peak value go up instead of a new alert appearing.

---

## PHASE 2 - Folder structure and dependencies

```
ransomware-behavior-simulator/
├── main.py                menu (11 options) and CLI
├── controller.py          orchestration: monitor → queue → detection → alerts → DB; workflow steps
├── activity_generator.py  the benign "simulator" (SAFE + DEMONSTRATION modes, no encryption)
├── file_monitor.py        Watchdog monitor + polling fallback → FileEvent
├── detection_engine.py    behaviour rules with sliding windows
├── integrity_checker.py   SHA-256 baseline and comparison
├── backup_manager.py      backups with manifest hashes and verification
├── recovery.py            restore from a verified backup and verify each file
├── alert_manager.py       structured alerts, de-duplication, cooldown, recommendations
├── report_generator.py    HTML + JSON reports
├── database.py            SQLite storage
├── safety.py              sandbox confinement for every file operation
├── config_loader.py       loads and validates config.json
├── environment.py         creates test_environment/ and the sample files
├── ui.py                  banner, colours, tables, dashboard
├── config.json  requirements.txt  README.md  PROJECT_STATUS.md
├── test_environment/  backups/  logs/  database/   (created at runtime)
├── reports/html/  reports/json/
├── sample_output/  screenshots/   (from a real DEMONSTRATION run here, labelled)
├── docs/  DEMO_GUIDE.md  PROJECT_REPORT.md  VIVA_QUESTIONS.md
└── tests/   pytest suite (21 tests)
```
Dependencies: `watchdog`, `colorama`, `tabulate`, `pytest`. Everything else is in the standard library (`os`, `pathlib`, `hashlib`, `json`, `sqlite3`, `logging`, `threading`, `datetime`).

---

## PHASE 3 - Installation

**Kali Linux / Ubuntu**
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
mkdir -p ~/projects && cd ~/projects
unzip ransomware-behavior-simulator.zip && cd ransomware-behavior-simulator
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -c "import watchdog; print('watchdog OK')"
python3 -m pytest -q          # optional: 21 tests
python3 main.py
```
No root is needed. The tool only works inside its own folder.

**Windows (PowerShell)**
```powershell
py -3 -m venv venv
.\venv\Scripts\Activate.ps1      # if blocked: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
pip install -r requirements.txt
python main.py
```
Note: one test creates a symlink, which on Windows needs Developer Mode or an administrator terminal. The application itself does not need this.

---

## PHASE 5 - Execution and configuration
```bash
python3 main.py                  # interactive menu
python3 main.py --safe           # SAFE simulation, prints alerts, exits
python3 main.py --demo --yes     # DEMONSTRATION + recovery, non-interactive
python3 main.py --simulations    # list previous runs
python3 main.py --report 1       # HTML + JSON report for simulation 1
```
Menu options:
1. Initialize test environment
2. Generate sample files (and the SHA-256 baseline)
3. Start file monitoring
4. SAFE run
5. DEMONSTRATION run (you must type `RUN SIMULATION`)
6. Alerts
7. Integrity check
8. Restore
9. Previous simulations
10. Report
11. Exit

Configuration (`config.json`):
* `detection.*` sets the thresholds, windows and severities.
* `alerts.cooldown_seconds` controls how often the same alert can repeat.
* `monitor.engine` is `auto` (Watchdog, with polling as fallback), `watchdog` or `poll`.
* `simulation.*` sets the extension, note name, placeholder marker, delay between operations and the confirmation phrase.

Directories must stay relative paths inside the project. The loader rejects anything else.

## PHASE 6 - Demonstrations
See **docs/DEMO_GUIDE.md**, which covers Tests 1–6 with commands, expected output, explanations and screenshot ideas.

## PHASE 7 - Recovery and reports
* Recovery first re-hashes the backup against its manifest and refuses to restore from a tampered backup.
* It then copies back only the files listed in the manifest, re-hashes each restored file, and removes files the demonstration added (the note and `.simulated` copies).
* Reports are written to `reports/html` and `reports/json`.
* `sample_output/` and `screenshots/` hold a report from a real DEMONSTRATION run on the generated sample files in the build environment.

## PHASE 8 - Documentation
`docs/PROJECT_REPORT.md` contains the 16-section college report. `docs/VIVA_QUESTIONS.md` contains 30 viva questions with answers.
