"""
detection_engine.py - behavioural detection over the FileEvent stream.

The engine looks for *patterns* associated with ransomware-like activity
rather than labelling every bulk operation as malicious. Each rule uses a
configurable sliding time window. Rules return Detection objects; de-duplication
and cooldown happen in alert_manager.py.

Rules:
  rapid_modification  - many files modified in a short window           HIGH
  rapid_creation      - many files created in a short window            MEDIUM
  bulk_rename         - many renames in a short window                  HIGH
  suspicious_ext      - files gaining a watched extension (.simulated)  MEDIUM
  ransom_note         - a file whose NAME or CONTENT marks it a note    HIGH
  mass_deletion       - many deletions in a short window                CRITICAL

Only the detector reads file content, and only for a small candidate note file,
to confirm the harmless simulation marker.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from file_monitor import CREATED, DELETED, MODIFIED, MOVED, FileEvent

RAPID_MODIFICATION = "Rapid File Modification"
RAPID_CREATION = "Rapid File Creation"
BULK_RENAME = "Bulk File Renaming"
SUSPICIOUS_EXT = "Suspicious Extension Change"
RANSOM_NOTE = "Ransom Note Creation"
MASS_DELETION = "Mass File Deletion"


@dataclass
class Detection:
    rule: str
    category: str
    severity: str
    title: str
    description: str
    timestamp: float
    file: Optional[str] = None
    details: dict = field(default_factory=dict)
    dedupe_key: tuple = ()
    peak_fields: tuple = ()


class _Window:
    """Timestamps of recent events, trimmed to a sliding window."""
    __slots__ = ("window", "_events")

    def __init__(self, window: float):
        self.window = float(window)
        self._events: deque = deque()

    def add(self, ts: float) -> int:
        self._events.append(ts)
        cutoff = ts - self.window
        while self._events and self._events[0] < cutoff:
            self._events.popleft()
        return len(self._events)

    def count(self) -> int:
        return len(self._events)


class DetectionEngine:
    def __init__(self, config: dict, sandbox=None):
        self.cfg = config
        self.sandbox = sandbox       # used only to read a candidate ransom note's content
        self.rule_hits = {}
        self._mod = _Window(config["rapid_modification"]["window_seconds"])
        self._create = _Window(config["rapid_creation"]["window_seconds"])
        self._rename = _Window(config["bulk_rename"]["window_seconds"])
        self._ext = _Window(config["suspicious_extension_change"]["window_seconds"])
        self._del = _Window(config["mass_deletion"]["window_seconds"])
        self._recent_mod_files: deque = deque(maxlen=200)
        self._recent_del_files: deque = deque(maxlen=200)
        self._recent_rename_files: deque = deque(maxlen=200)
        self._ext_files: deque = deque(maxlen=200)

    # --------------------------------------------------------------- helpers
    def _hit(self, rule: str):
        self.rule_hits[rule] = self.rule_hits.get(rule, 0) + 1

    def _looks_like_note(self, ev: FileEvent) -> bool:
        rn = self.cfg["ransom_note"]
        name = Path(ev.dest_path or ev.path).name.lower()
        if any(marker in name for marker in rn["name_markers"]):
            return True
        # Confirm by content only for small text files, and only inside the sandbox.
        if self.sandbox is not None and name.endswith(".txt"):
            try:
                p = self.sandbox.resolve(*(ev.dest_path or ev.path).split("/"))
                if p.is_file() and p.stat().st_size < 20000:
                    text = p.read_text(encoding="utf-8", errors="ignore")
                    if rn["content_marker"].lower() in text.lower():
                        return True
            except Exception:
                return False
        return False

    # ----------------------------------------------------------------- main
    def process(self, ev: FileEvent) -> list[Detection]:
        if ev.is_directory:
            return []
        out: list[Detection] = []
        c = self.cfg

        if ev.kind == MODIFIED and c["rapid_modification"]["enabled"]:
            n = self._mod.add(ev.timestamp)
            self._recent_mod_files.append(ev.path)
            if n >= c["rapid_modification"]["files"]:
                out.append(self._det("RAPID_MOD", RAPID_MODIFICATION, c["rapid_modification"]["severity"],
                                     "Rapid File Modification Detected",
                                     f"{n} file modifications within {c['rapid_modification']['window_seconds']:g}s "
                                     f"(threshold {c['rapid_modification']['files']}). Many files changing at once "
                                     "can indicate bulk encryption; it can also be a legitimate batch job.",
                                     ev, {"files_modified": n, "window_seconds": c["rapid_modification"]["window_seconds"],
                                          "recent": list(self._recent_mod_files)[-10:]},
                                     ("RAPID_MOD",), ("files_modified",)))

        if ev.kind == CREATED and c["rapid_creation"]["enabled"]:
            n = self._create.add(ev.timestamp)
            if n >= c["rapid_creation"]["files"]:
                out.append(self._det("RAPID_CREATE", RAPID_CREATION, c["rapid_creation"]["severity"],
                                     "Rapid File Creation Detected",
                                     f"{n} files created within {c['rapid_creation']['window_seconds']:g}s "
                                     f"(threshold {c['rapid_creation']['files']}).",
                                     ev, {"files_created": n}, ("RAPID_CREATE",), ("files_created",)))

        if ev.kind == MOVED and c["bulk_rename"]["enabled"]:
            n = self._rename.add(ev.timestamp)
            self._recent_rename_files.append(f"{ev.path} -> {ev.dest_path}")
            if n >= c["bulk_rename"]["files"]:
                out.append(self._det("BULK_RENAME", BULK_RENAME, c["bulk_rename"]["severity"],
                                     "Bulk File Renaming Detected",
                                     f"{n} files renamed within {c['bulk_rename']['window_seconds']:g}s "
                                     f"(threshold {c['bulk_rename']['files']}). Mass renaming to a new extension is a "
                                     "common ransomware trait.",
                                     ev, {"files_renamed": n, "recent": list(self._recent_rename_files)[-10:]},
                                     ("BULK_RENAME",), ("files_renamed",)))

        # Suspicious extension: a move/create whose NEW suffix is watched.
        if ev.kind in (MOVED, CREATED) and c["suspicious_extension_change"]["enabled"]:
            watched = [w.lower() for w in c["suspicious_extension_change"]["watched_extensions"]]
            suffix = (ev.new_suffix if ev.kind == MOVED else ev.old_suffix) or ""
            if suffix.lower() in watched:
                n = self._ext.add(ev.timestamp)
                self._ext_files.append(ev.dest_path or ev.path)
                if n >= c["suspicious_extension_change"]["files"]:
                    out.append(self._det("SUSPICIOUS_EXT", SUSPICIOUS_EXT,
                                         c["suspicious_extension_change"]["severity"],
                                         "Suspicious Extension Changes Detected",
                                         f"{n} files gained a watched extension ({suffix}) within "
                                         f"{c['suspicious_extension_change']['window_seconds']:g}s.",
                                         ev, {"files_changed": n, "extension": suffix,
                                              "recent": list(self._ext_files)[-10:]},
                                         ("SUSPICIOUS_EXT", suffix), ("files_changed",)))

        if ev.kind in (CREATED, MODIFIED, MOVED) and c["ransom_note"]["enabled"] and self._looks_like_note(ev):
            note = ev.dest_path or ev.path
            out.append(self._det("RANSOM_NOTE", RANSOM_NOTE, c["ransom_note"]["severity"],
                                 "Simulated Ransom Note Detected",
                                 f"A file matching the ransom-note pattern was observed: {note}. "
                                 "(In this project the note is the harmless simulation marker.)",
                                 ev, {"note_file": note}, ("RANSOM_NOTE", note)))

        if ev.kind == DELETED and c["mass_deletion"]["enabled"]:
            n = self._del.add(ev.timestamp)
            self._recent_del_files.append(ev.path)
            if n >= c["mass_deletion"]["files"]:
                out.append(self._det("MASS_DELETE", MASS_DELETION, c["mass_deletion"]["severity"],
                                     "Mass File Deletion Detected",
                                     f"{n} files deleted within {c['mass_deletion']['window_seconds']:g}s "
                                     f"(threshold {c['mass_deletion']['files']}). Rapid deletion can mean shadow "
                                     "copies or originals are being destroyed.",
                                     ev, {"files_deleted": n, "recent": list(self._recent_del_files)[-10:]},
                                     ("MASS_DELETE",), ("files_deleted",)))

        for d in out:
            self._hit(d.rule)
        return out

    def _det(self, rule, category, severity, title, desc, ev, details, key, peaks=()):
        return Detection(rule=rule, category=category, severity=severity, title=title, description=desc,
                         timestamp=ev.timestamp, file=ev.dest_path or ev.path, details=details,
                         dedupe_key=key, peak_fields=peaks)
