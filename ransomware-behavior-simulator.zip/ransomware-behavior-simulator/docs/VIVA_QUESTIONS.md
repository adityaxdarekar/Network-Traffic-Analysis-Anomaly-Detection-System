# Viva questions and answers

1. **What is ransomware?** Malware that denies access to a victim's data or system, usually by encrypting files, and then demands payment for restoring access. Modern variants also steal data and threaten to leak it ("double extortion").

2. **How does ransomware typically work (at a high level)?** It gains access (phishing, exposed services, stolen credentials), spreads, often disables backups, encrypts many files quickly, renames them, leaves ransom notes and demands payment. This project reproduces only the visible *file-level symptoms*, safely.

3. **What is file encryption?** Transforming data with an algorithm and a key so that it cannot be read without the key. It protects data legitimately; ransomware abuses it. This project performs **no** encryption.

4. **What is SHA-256?** A cryptographic hash function from the SHA-2 family. It produces a 256-bit digest; any change to the input changes the digest unpredictably, and finding two inputs with the same digest is infeasible.

5. **Hashing vs encryption?** Hashing is one-way and fixed-length, used for integrity. Encryption is reversible with a key, used for confidentiality.

6. **What is file integrity monitoring (FIM)?** Recording trusted hashes (a baseline) and comparing later hashes against them to detect unauthorised modification, deletion or addition of files.

7. **What is a baseline?** The trusted snapshot of file hashes taken when the files were known to be good. Here it is taken right after sample generation.

8. **What is behavioural detection?** Detecting threats from what software *does* (patterns of actions) rather than from known signatures, for example many files renamed within seconds.

9. **Signature-based vs behaviour-based detection?** Signatures match known samples precisely but miss new variants. Behaviour catches new variants but needs tuning to avoid false positives.

10. **What is a ransom note?** The message ransomware leaves explaining the attack and the demand. This project's note is a harmless educational marker stating that nothing was encrypted.

11. **What is a file-system event?** A notification from the OS that a file was created, modified, deleted or moved/renamed.

12. **What is Python Watchdog?** A library that wraps the OS file-notification APIs (inotify on Linux, ReadDirectoryChangesW on Windows, FSEvents on macOS) and delivers events to handler callbacks.

13. **Why have a polling fallback?** Some environments (network filesystems, some containers) do not deliver native events. Polling compares directory snapshots instead, but it cannot see renames directly.

14. **How does the sliding-window rule work?** Event timestamps are kept in a queue; entries older than the window are dropped; if the remaining count reaches the threshold, the rule fires.

15. **Why the cooldown/deduplication?** One burst can produce hundreds of matches. Merging them into one alert with an occurrence count prevents alert fatigue.

16. **What is a backup?** A separate copy of data that can be used to restore it after loss or corruption.

17. **Why verify backups?** A corrupted or tampered backup gives false confidence. Here every backup has a manifest of hashes, and restore refuses to use a backup that fails the check.

18. **What is disaster recovery?** The plans and procedures for restoring systems and data after a major incident within acceptable time (RTO) and data loss (RPO).

19. **What is the 3-2-1 backup rule?** Three copies of the data, on two different media, with one copy offsite or offline. Offline or immutable copies resist ransomware.

20. **What is ransomware detection in practice?** Combining behaviour (mass changes, renames, deletion of shadow copies), canary files, entropy checks, EDR telemetry and network indicators.

21. **What are false positives here?** Legitimate bulk activity, such as backup software, unzipping an archive or a build process, that crosses the thresholds. Mitigations are tuning, allowlisting and requiring several indicators together.

22. **What are false negatives here?** Slow ransomware that changes a few files per minute stays below the thresholds. Integrity checks still reveal the damage later.

23. **What is incident response?** The structured process of preparation, detection and analysis, containment, eradication, recovery and lessons learned.

24. **Antivirus vs EDR?** Antivirus mainly blocks known malicious files on one endpoint. EDR continuously records endpoint behaviour, detects suspicious activity, supports investigation and offers response actions such as isolating a host or killing a process.

25. **What automated response does this project perform?** It stops the simulation, preserves logs and database records, compares hashes, identifies affected files and restores from a verified backup. It never deletes user data or kills unrelated processes.

26. **How does this project detect suspicious behaviour?** Watchdog events → queue → detection engine (windowed counts and note markers) → alert manager (severity, cooldown, recommended action) → database and dashboard. Integrity comparison confirms what changed.

27. **Why is the simulator safe?** It performs no encryption. Every file operation passes through a sandbox that rejects traversal, absolute paths and escaping symlinks, and it refuses to delete directories. It works only on generated sample files. A backup is taken before any change, and a typed confirmation is required. SAFE mode changes nothing at all. There is no persistence, networking or stealth.

28. **What is directory traversal and how is it prevented?** Using `..` or absolute paths to reach files outside an intended folder. Here every path is resolved to its real absolute form and must lie inside the sandbox; otherwise a SafetyError is raised.

29. **What are the limitations of this project?** Threshold heuristics; visibility limited to its own sandbox; no process attribution; the polling fallback misses renames; no entropy-based detection; backups kept on the same disk.

30. **How could it be extended?** Canary files, entropy checks on test data, process attribution with psutil, offline backups, SIEM export, and a GUI dashboard.
