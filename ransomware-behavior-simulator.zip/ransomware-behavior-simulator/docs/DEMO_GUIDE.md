# Demonstration guide (college presentation)

Everything here runs on your own laptop or a lab VM. The tool only works on the sample files it generates in `test_environment/`.

```bash
cd ransomware-behavior-simulator && source venv/bin/activate
python3 main.py
```
Run menu options **1** (initialize) and **2** (generate sample files) once before the tests. Option 2 also stores the SHA-256 baseline.

---

## Test 1 - Normal file activity (no unnecessary alerts)
1. Menu **3**: start monitoring. You should see `[+] Monitoring started (watchdog engine) on …/test_environment`.
2. In a second terminal, make one small, ordinary change:
   ```bash
   echo "new note" > test_environment/my_note.txt
   echo "edit" >> test_environment/document1.txt
   ```
3. Menu **6** (alerts) → `No alerts yet`. Menu **7** (integrity) → `Modified 1`, `New 1`.

**Explain:** the monitor saw both events, but one creation and one edit are far below every threshold, so no alert fires. The integrity check still reports exactly what changed.
**Screenshot:** the integrity table showing 1 modified and 1 new file, with no alerts.
Then run menu **8** to restore. The restore also removes `my_note.txt`, because it is not in the backup. Menu 8 needs a backup, which is taken automatically before every demonstration. If you have not run a demonstration yet, run Test 2 first.

## Tests 2, 3 and 4 - Rapid modification, bulk renaming and the simulated note
Menu **5** prints what the run will do, then asks you to type `RUN SIMULATION`. It takes a backup and then performs these steps on the disposable sample files:

| Step | What happens | Expected alert |
|---|---|---|
| modify | 12 files overwritten with a placeholder line | `[HIGH] Rapid File Modification Detected`, Files Modified ≥ 10 |
| rename | 6 files renamed to `*.simulated` | `[HIGH] Bulk File Renaming Detected` and `[MEDIUM] Suspicious Extension Changes Detected` |
| note | `SIMULATED_RANSOM_NOTE.txt` written | `[HIGH] Simulated Ransom Note Detected` |
| delete | 6 disposable copies deleted | `[CRITICAL] Mass File Deletion Detected` |

Output from the build environment:
```
[MEDIUM] Suspicious Extension Changes Detected  RBS-0001-00002
   Files Changed: 6
   repeated 4 times (merged during cooldown)
[HIGH] Bulk File Renaming Detected  RBS-0001-00003
   Files Renamed: 6
[HIGH] Simulated Ransom Note Detected  RBS-0001-00004
   File: SIMULATED_RANSOM_NOTE.txt
[CRITICAL] Mass File Deletion Detected  RBS-0001-00005
   Files Deleted: 6
```
Open `test_environment/SIMULATED_RANSOM_NOTE.txt` to show that it says plainly the files have **not** been encrypted.

**Explain:**
* Every rule counts events in a 5-second window.
* Repeats are merged into one alert by the cooldown.
* The note is recognised both by its name and by its marker text.

**Screenshot:** the alert list, and the note file opened in an editor.

*If you are short on time or nervous:* menu **4** (SAFE mode) produces the same alerts from synthetic events and changes no files.

## Test 5 - File integrity monitoring
When the demonstration finishes, answer **n** when it asks to restore. Then choose menu **7**.

**Expected:** the integrity table shows the files that were overwritten as `MODIFIED`, with the baseline and current hash prefixes, and the renamed and deleted originals as `MISSING`. The exact counts depend on how the steps overlap. In the build-environment run, 4 files were modified and 6 were missing; the note was also created and later removed by recovery.

**Explain:** SHA-256 changes completely if even one byte changes, so comparing hashes against the baseline proves modification without reading or trusting the file names.
**Screenshot:** a `MODIFIED` row showing the two different hash prefixes.

## Test 6 - Automated recovery
Menu **8**.

**Expected:**
```
[+] Recovery from backup 20261107_..._pre_demo: restored 10, unchanged 0, verified 10, failed 0, extra removed 1.
  RESTORED document1.txt  integrity: PASSED
  ...
[+] Integrity verification passed.
```
Then run menu **7** again. It should show `All files match the baseline.`

**Explain:**
* Recovery first checks the backup itself against its manifest, and refuses to restore from a tampered backup.
* It restores each file and re-hashes it to confirm the copy is correct.
* It removes the extra files the demonstration created.

## Finish
* Menu **9** lists previous simulations.
* Menu **10** writes the HTML report, which you can open in a browser.
* Show the "Note" section at the bottom of the report, which states that no real encryption was performed.
