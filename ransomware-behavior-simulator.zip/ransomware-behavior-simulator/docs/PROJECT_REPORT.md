# Ransomware Behavior Simulator Using Python
### College project report

## 1. Abstract
Ransomware is one of the most damaging threats to organisations. Its file-level behaviour is easy to recognise but hard to study safely. This project builds a defensive teaching tool that reproduces ransomware-like file activity inside an isolated sandbox directory: rapid modification, bulk renaming, a ransom-note marker and mass deletion. It then detects that activity with behaviour rules over a live Watchdog event stream, raises severity-rated alerts, checks file integrity with SHA-256 and restores the files from hash-verified backups. No encryption is performed at any point. The results are stored in SQLite and summarised in HTML and JSON reports.

## 2. Introduction
Ransomware encrypts or destroys a victim's files and demands payment for their return. Defenders rely on three capabilities against it:
* early detection of its characteristic file behaviour;
* integrity monitoring to establish exactly what changed;
* reliable, verified backups for recovery.

This project lets students practise all three, safely, on disposable files.

## 3. Problem statement
Studying ransomware with real samples is dangerous and inappropriate in a classroom. Students still need to see how defensive controls react to ransomware-like activity. A tool is needed that generates realistic patterns of file activity without any real harm, and that demonstrates detection, alerting, integrity verification and recovery end to end.

## 4. Project objectives
1. Create a confined test environment with generated sample files and path-traversal protection.
2. Generate ransomware-like activity in a SAFE mode (no file changes) and a DEMONSTRATION mode (benign, reversible changes to disposable copies).
3. Monitor the directory in real time with Watchdog.
4. Detect suspicious behaviour with configurable, time-windowed rules.
5. Produce structured alerts with severity, de-duplication and recommended actions.
6. Monitor integrity with SHA-256 baselines.
7. Restore from verified backups and verify every restored file.
8. Store history in SQLite and produce HTML and JSON reports.

## 5. Existing system
* **Signature antivirus** detects known samples, but new or modified ransomware often evades it.
* **EDR platforms** provide behavioural detection and response, but they are commercial and complex, and their logic is hidden from students.
* **Manual backup and restore** has no detection, and backups are often unverified.
* **Live malware labs** are risky, need heavy isolation, and are not suitable for a college classroom.

## 6. Proposed system
A small, transparent Python application that:
* confines every file operation to its own sandbox;
* simulates ransomware-like behaviour without any encryption;
* runs readable behaviour-detection rules, integrity checks and verified recovery;
* records each run in a database and writes a SOC-style report.

## 7. System architecture
Layers:
1. **Safety** (`safety.py`): every path is validated.
2. **Environment** (`environment.py`): creates the sandbox and sample files.
3. **Activity** (`activity_generator.py`): SAFE and DEMONSTRATION modes.
4. **Observation** (`file_monitor.py`): Watchdog, with a polling fallback.
5. **Analysis** (`detection_engine.py`) and **alerting** (`alert_manager.py`).
6. **Integrity / backup / recovery** (`integrity_checker.py`, `backup_manager.py`, `recovery.py`).
7. **Persistence and presentation** (`database.py`, `report_generator.py`, `ui.py`).

These are coordinated by `controller.py` and `main.py`. Monitor events pass through a queue to a single processing thread, so detection never blocks the observer.

## 8. Hardware and software requirements
| Item | Requirement |
|---|---|
| CPU / RAM / disk | any dual-core PC, 4 GB RAM, 100 MB free |
| OS | Kali Linux, Ubuntu 22.04+, or Windows 10/11 |
| Python | 3.10+ |
| Libraries | watchdog, colorama, tabulate, pytest. Standard library: os, pathlib, hashlib, json, sqlite3, logging, threading, datetime |
| Other | a web browser for reports |

## 9. Module descriptions
| Module | Responsibility |
|---|---|
| main.py | 11-option menu, CLI flags, typed confirmation before a demonstration |
| controller.py | runs the workflow; wires monitor → queue → detection → alerts → database |
| activity_generator.py | SAFE (synthetic events) and DEMONSTRATION (benign operations) modes; no encryption |
| file_monitor.py | Watchdog observer and polling fallback; produces FileEvent records |
| detection_engine.py | sliding-window rules: modification, creation, renaming, extension change, note, deletion |
| alert_manager.py | alert IDs, cooldown and merging, severity counts, recommended actions |
| integrity_checker.py | streamed SHA-256 hashing, baseline save/load, comparison |
| backup_manager.py | timestamped backups with manifest hashes and verification |
| recovery.py | restore from a verified backup, re-hash every file, remove files the demonstration created |
| database.py | SQLite tables: simulations, events, alerts, affected files |
| report_generator.py | escaped HTML and JSON reports |
| safety.py | sandbox confinement: traversal, absolute-path and symlink checks; no directory deletion |
| config_loader.py | loads config.json over defaults and validates every value |
| environment.py | creates the sandbox and sample files |
| ui.py | banner, colours, tables, dashboard |

## 10. Algorithms and detection methodology
**Sliding window.** For each rule, the event timestamps are kept in a queue. On each new event, timestamps older than the window are removed. If the remaining count reaches the threshold, a Detection is produced.

**Rules.**
* Count MODIFIED events for rapid modification.
* Count MOVED events for bulk renaming.
* Count files whose new suffix is in a watched list for extension change.
* A note is recognised by a name marker, or by marker text inside a small `.txt` file.
* Count DELETED events for mass deletion.

**Cooldown.** Each detection has a key. A repeat of the same key within the cooldown updates the existing alert's occurrence count and peak value instead of creating a new alert.

**Integrity.**
```
baseline = {relpath: sha256(file)}       # after sample generation
for each baseline path: missing if absent; modified if the hash differs; unchanged otherwise
for each live path not in the baseline: new
```

**Recovery.**
1. Verify the backup: every manifest hash must match its backup file.
2. For each manifest file: skip it if it already matches; otherwise copy it into the sandbox, re-hash it and mark it VERIFIED or FAILED.
3. Remove files that are not in the manifest.

## 11. Implementation
* Written in Python 3 with dataclasses and type hints.
* Every write, rename and delete goes through `Sandbox` methods.
* SQL queries are parameterised and HTML output is escaped.
* Monitoring runs in background threads with a bounded queue.
* Configuration errors are all reported together.
* A demonstration needs a typed confirmation phrase, and a backup is taken automatically before it runs.

## 12. Testing and results
**Automated tests (pytest): 21 tests, all passing.** They cover:
* sandbox confinement: traversal, absolute paths, symlink escape, refusal to delete directories, roots that are too broad;
* configuration validation;
* SHA-256 and integrity states;
* backup verification, including detection of a tampered backup;
* recovery and its refusal to use a tampered backup;
* the SAFE run, where alerts fire in all five main categories and the file contents are byte-for-byte unchanged;
* the DEMONSTRATION run followed by recovery, after which the baseline is intact again;
* a check that a file outside the sandbox is never touched;
* alert cooldown;
* the menu walkthrough, including a cancelled demonstration that changes nothing;
* the CLI safety flag.

**End-to-end demonstration run (real Watchdog monitor, build environment):**

| Item | Result |
|---|---|
| Alerts | 5: 1 CRITICAL, 3 HIGH, 1 MEDIUM |
| Integrity after the run | 4 modified, 6 missing, 1 new |
| Recovery | 10 files restored, 10 verified, 0 failed, 1 extra file removed |
| Final state | all files match the baseline |

Add a "Observed in your lab" column with your own results and screenshots.

## 13. Advantages
* Safe: it is sandboxed, performs no encryption, and makes reversible changes after a backup.
* Transparent detection logic that is easy to explain.
* All thresholds are configurable.
* Verified backups and verified restores.
* Full history in a database, plus HTML and JSON reports.
* Runs on Linux and Windows.

## 14. Limitations
* The behavioural rules are threshold heuristics. Legitimate batch jobs can trigger them, and slow ransomware can stay below them.
* It sees only its own sandbox, not the whole system or individual processes. It has no process attribution or kill switch.
* The polling fallback cannot see renames directly. It reports them as a delete plus a create.
* It does not use real encryption or entropy-based detection, so it does not demonstrate content-entropy analysis.
* Backups are kept on the same disk. A real defence keeps them offline or immutable.

## 15. Future scope
* Entropy-based checks for content that looks encrypted (on test data).
* Process attribution with psutil, plus an analyst-approved response.
* Canary or honey files.
* A Tkinter or web dashboard.
* Exporting alerts to a SIEM (Wazuh/ELK).
* Scheduled baseline re-checks.
* Backup storage on separate media or offline.

## 16. Conclusion
The project shows the complete defensive lifecycle against ransomware-like activity, from detection to alerting, integrity verification and verified recovery, without exposing the machine to any real threat. It turns abstract ideas such as behavioural detection, hashing and backup verification into a working, demonstrable system.
