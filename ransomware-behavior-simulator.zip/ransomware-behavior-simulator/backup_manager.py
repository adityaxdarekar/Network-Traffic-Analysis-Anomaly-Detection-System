"""
backup_manager.py - back up the sample files before any demonstration, and
keep an integrity hash for each backup so recovery can be verified.

A backup is a full copy of the current test-directory contents into a
timestamped folder under backups/, plus a manifest.json mapping each relative
path to its SHA-256 and size. The manifest is what recovery.py trusts.

Backups are copies: the originals are never moved or altered here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from integrity_checker import sha256_file
from safety import Sandbox, SafetyError, guarded_copy


@dataclass
class BackupInfo:
    backup_id: str
    created: str
    path: str
    file_count: int
    manifest: dict      # relpath -> {"sha256", "size"}


class BackupManager:
    def __init__(self, test_sandbox: Sandbox, backup_sandbox: Sandbox):
        self.test = test_sandbox
        self.backups = backup_sandbox

    def create_backup(self, label: str = "") -> BackupInfo:
        self.backups.ensure()
        bid = datetime.now().strftime("%Y%m%d_%H%M%S")
        if label:
            safe = "".join(c for c in label if c.isalnum() or c in "-_")[:24]
            bid = f"{bid}_{safe}" if safe else bid
        folder = self.backups.resolve(bid)
        if folder.exists():
            bid += "_1"
            folder = self.backups.resolve(bid)
        folder.mkdir(parents=True)
        manifest: dict = {}
        for f in self.test.iter_files():
            rel = self.test.relative(f)
            dst = self.backups.resolve(bid, *rel.split("/"))
            guarded_copy(f, dst, self.backups)
            manifest[rel] = {"sha256": sha256_file(dst), "size": dst.stat().st_size}
        meta = {"backup_id": bid, "created": datetime.now().isoformat(timespec="seconds"),
                "source": str(self.test.root), "files": manifest}
        (folder / "manifest.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return BackupInfo(bid, meta["created"], str(folder), len(manifest), manifest)

    def list_backups(self) -> list[BackupInfo]:
        out: list[BackupInfo] = []
        if not self.backups.root.exists():
            return out
        for folder in sorted(self.backups.root.iterdir(), reverse=True):
            man = folder / "manifest.json"
            if folder.is_dir() and man.is_file():
                try:
                    meta = json.loads(man.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    continue
                out.append(BackupInfo(meta.get("backup_id", folder.name), meta.get("created", ""),
                                      str(folder), len(meta.get("files", {})), meta.get("files", {})))
        return out

    def latest(self) -> BackupInfo | None:
        backups = self.list_backups()
        return backups[0] if backups else None

    def get(self, backup_id: str) -> BackupInfo | None:
        for b in self.list_backups():
            if b.backup_id == backup_id:
                return b
        return None

    def verify_backup(self, info: BackupInfo) -> bool:
        """Re-hash every file in the backup folder and compare to the manifest."""
        for rel, rec in info.manifest.items():
            p = self.backups.resolve(info.backup_id, *rel.split("/"))
            if not p.is_file() or sha256_file(p) != rec["sha256"]:
                return False
        return True

    def backup_file_path(self, info: BackupInfo, relpath: str) -> Path:
        return self.backups.resolve(info.backup_id, *relpath.split("/"))
