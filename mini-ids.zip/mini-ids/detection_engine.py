"""
detection_engine.py - heuristic detection rules working on PacketInfo records.

The engine does not capture packets and does not print anything. It receives
one PacketInfo at a time (from the processing thread) and returns a list of
Detection objects. De-duplication, cool-down and storage happen later in
alert_manager.py.

All time windows use the *packet* timestamps, so the same logic works for
live capture, pcap replay and unit tests.

Threading: one DetectionEngine instance is used by a single processing
thread; it is therefore not locked. Shared state (statistics, alerts,
blacklist) is protected by locks in the other modules.

Memory: per-source state lives in LRU dictionaries limited by
engine.max_tracked_sources, rate counters use fixed-size time buckets, and
idle state is cleaned up every engine.cleanup_every_packets packets.
"""
from __future__ import annotations

import ipaddress
import math
from collections import Counter, OrderedDict, deque
from dataclasses import dataclass, field
from typing import Optional

from packet_analyzer import PacketInfo

# Detection categories (used for alert titles, recommendations and reports)
PORT_SCAN = "Port Scan"
SYN_FLOOD = "SYN Flood Indicator"
ARP_SPOOF = "ARP Spoofing Indicator"
ICMP_FLOOD = "ICMP Flood Indicator"
DNS_SUSPICIOUS = "Suspicious DNS Activity"
BLACKLISTED_IP = "Blacklisted IP"
CORRELATED = "Multiple Attack Indicators"


@dataclass
class Detection:
    """A rule match produced by the engine (before de-duplication)."""
    rule: str                     # rule id, e.g. "PORT_SCAN"
    category: str
    severity: str
    title: str
    description: str
    timestamp: float
    src_ip: Optional[str] = None
    dst_ip: Optional[str] = None
    details: dict = field(default_factory=dict)
    dedupe_key: tuple = ()
    # detail fields that should keep their *maximum* while an alert is in cool-down
    peak_fields: tuple = ()


# ---------------------------------------------------------------------------
# Efficient sliding-window helpers
# ---------------------------------------------------------------------------
class RateCounter:
    """Counts events in a sliding time window using fixed-size buckets.

    Memory is bounded by window/bucket buckets no matter how many packets
    arrive (important during a flood). Accuracy is +- one bucket.
    """
    __slots__ = ("window", "bucket", "_buckets", "_total", "last_ts")

    def __init__(self, window: float, buckets: int = 20):
        self.window = float(window)
        self.bucket = max(self.window / buckets, 0.001)
        self._buckets: deque = deque()      # [bucket_index, count]
        self._total = 0
        self.last_ts = 0.0

    def add(self, ts: float, n: int = 1) -> int:
        idx = int(ts // self.bucket)
        if self._buckets and self._buckets[-1][0] == idx:
            self._buckets[-1][1] += n
        elif self._buckets and idx < self._buckets[-1][0]:
            self._buckets[-1][1] += n       # slightly out-of-order packet: count it in the newest bucket
        else:
            self._buckets.append([idx, n])
        self._total += n
        self.last_ts = max(self.last_ts, ts)
        return self.count(ts)

    def count(self, now: float) -> int:
        oldest_allowed = int((now - self.window) // self.bucket)
        while self._buckets and self._buckets[0][0] <= oldest_allowed:
            self._total -= self._buckets.popleft()[1]
        return self._total


class UniqueTracker:
    """Counts distinct values (e.g. destination ports) seen in a time window."""
    __slots__ = ("window", "limit", "refresh", "_last", "_events", "last_ts")

    def __init__(self, window: float, limit: int = 4096):
        self.window = float(window)
        self.limit = limit                   # stop tracking new values beyond this (memory cap)
        self.refresh = self.window / 10      # re-record a value at most this often
        self._last: dict = {}
        self._events: deque = deque()
        self.last_ts = 0.0

    def add(self, ts: float, value) -> int:
        prev = self._last.get(value)
        if prev is None:
            if len(self._last) < self.limit:
                self._last[value] = ts
                self._events.append((ts, value))
        elif ts - prev >= self.refresh:
            self._last[value] = ts
            self._events.append((ts, value))
        self.last_ts = max(self.last_ts, ts)
        return self.count(ts)

    def count(self, now: float) -> int:
        cutoff = now - self.window
        while self._events and self._events[0][0] < cutoff:
            t, v = self._events.popleft()
            if self._last.get(v) == t:
                del self._last[v]
        return len(self._last)

    def values(self) -> list:
        return sorted(self._last)


class LRUState(OrderedDict):
    """Dict with a maximum size; least-recently-used keys are evicted first."""

    def __init__(self, max_items: int, factory):
        super().__init__()
        self.max_items = max_items
        self.factory = factory
        self.evicted = 0

    def get_or_create(self, key):
        if key in self:
            self.move_to_end(key)
            return self[key]
        value = self.factory()
        self[key] = value
        if len(self) > self.max_items:
            self.popitem(last=False)
            self.evicted += 1
        return value

    def purge_idle(self, now: float, idle: float) -> int:
        stale = [k for k, v in self.items() if now - getattr(v, "last_ts", now) > idle]
        for k in stale:
            del self[k]
        return len(stale)


def shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    counts = Counter(text)
    n = len(text)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


# ---------------------------------------------------------------------------
# The engine
# ---------------------------------------------------------------------------
class DetectionEngine:
    def __init__(self, config: dict, blacklist=None):
        self.cfg = config
        self.rules = config["rules"]
        self.blacklist = blacklist
        eng = config["engine"]
        self.max_sources = eng["max_tracked_sources"]
        self.cleanup_every = eng["cleanup_every_packets"]
        self.trusted = set(eng.get("trusted_sources", []))
        self.packets_seen = 0
        self.rule_hits: Counter = Counter()          # raw matches per rule (before de-dup)
        self.suppressed: Counter = Counter()         # matches suppressed by safeguards

        ps, sf, ic, dn = (self.rules["port_scan"], self.rules["syn_flood"],
                          self.rules["icmp_flood"], self.rules["dns"])
        n = self.max_sources
        self._ports = LRUState(n, lambda: UniqueTracker(ps["window_seconds"]))
        self._syn_src = LRUState(n, lambda: RateCounter(sf["window_seconds"]))
        self._syn_dst = LRUState(n, lambda: _DstSynState(sf["per_destination"]["window_seconds"]))
        self._icmp = LRUState(n, lambda: RateCounter(ic["window_seconds"]))
        self._dns_rate = LRUState(n, lambda: RateCounter(dn["window_seconds"]))
        self._dns_burst = LRUState(n, lambda: RateCounter(dn["burst_window_seconds"], buckets=10))
        self._dns_repeat = LRUState(n, lambda: RateCounter(dn["repeat_window_seconds"]))
        self._arp: dict[str, dict] = {}              # ip -> {"mac", "first_seen", "last_seen", "changes"}
        self.max_window = max(ps["window_seconds"], sf["window_seconds"],
                              sf["per_destination"]["window_seconds"], ic["window_seconds"],
                              dn["window_seconds"], dn["repeat_window_seconds"])

    # ----------------------------------------------------------------- main
    def process(self, p: PacketInfo) -> list[Detection]:
        """Run every enabled rule on one packet and return the matches."""
        self.packets_seen += 1
        out: list[Detection] = []
        if self.packets_seen % self.cleanup_every == 0:
            self.cleanup(p.timestamp)

        if self.rules["blacklist"]["enabled"] and self.blacklist is not None:
            out.extend(self._check_blacklist(p))
        if p.protocol == "ARP":
            if self.rules["arp_spoof"]["enabled"]:
                out.extend(self._check_arp(p))
            return self._count(out)

        if p.src_ip in self.trusted:                 # trusted hosts skip the rate/scan rules
            return self._count(out)

        if p.transport == "TCP" or (p.transport == "UDP" and p.protocol != "DNS"):
            if self.rules["port_scan"]["enabled"]:
                out.extend(self._check_port_scan(p))
        if p.transport == "TCP" and p.is_syn and self.rules["syn_flood"]["enabled"]:
            out.extend(self._check_syn_flood(p))
        if p.protocol == "ICMP" and self.rules["icmp_flood"]["enabled"]:
            out.extend(self._check_icmp(p))
        if p.protocol == "DNS" and p.is_dns_query and self.rules["dns"]["enabled"]:
            out.extend(self._check_dns(p))
        return self._count(out)

    def _count(self, out: list[Detection]) -> list[Detection]:
        for d in out:
            self.rule_hits[d.rule] += 1
        return out

    def cleanup(self, now: float) -> int:
        """Drop per-source state that has been idle for longer than the largest window."""
        idle = self.max_window * 2
        removed = 0
        for state in (self._ports, self._syn_src, self._syn_dst, self._icmp,
                      self._dns_rate, self._dns_burst, self._dns_repeat):
            removed += state.purge_idle(now, idle)
        return removed

    def tracked_sources(self) -> int:
        return sum(len(s) for s in (self._ports, self._syn_src, self._syn_dst, self._icmp,
                                    self._dns_rate, self._dns_burst, self._dns_repeat)) + len(self._arp)

    # ------------------------------------------------------------ port scan
    def _check_port_scan(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["port_scan"]
        if p.transport == "TCP":
            if not p.is_syn:                       # only count new connection attempts
                return []
        elif not r["include_udp"]:
            return []
        if p.src_ip is None or p.dst_port is None:
            return []
        tracker = self._ports.get_or_create(p.src_ip)
        unique = tracker.add(p.timestamp, p.dst_port)
        if unique < r["unique_ports"]:
            return []
        ports = tracker.values()
        sample = ", ".join(str(x) for x in ports[:20]) + (" ..." if len(ports) > 20 else "")
        return [Detection(
            rule="PORT_SCAN", category=PORT_SCAN, severity=r["severity"],
            title="Possible Port Scan Detected",
            description=(f"{p.src_ip} sent connection attempts to {unique} different destination ports "
                         f"within {r['window_seconds']:g} seconds (threshold {r['unique_ports']}). "
                         "This pattern matches port scanning; legitimate tools such as vulnerability "
                         "scanners or monitoring systems can produce it too."),
            timestamp=p.timestamp, src_ip=p.src_ip, dst_ip=p.dst_ip,
            details={"unique_ports": unique, "time_window_seconds": r["window_seconds"],
                     "threshold": r["unique_ports"], "ports_sample": sample,
                     "protocol": p.transport},
            dedupe_key=("PORT_SCAN", p.src_ip), peak_fields=("unique_ports",))]

    def is_scanning(self, src: str, now: float) -> bool:
        tracker = self._ports.get(src)
        return tracker is not None and tracker.count(now) >= self.rules["port_scan"]["unique_ports"]

    # ------------------------------------------------------------ SYN flood
    def _check_syn_flood(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["syn_flood"]
        out: list[Detection] = []
        if p.src_ip:
            count = self._syn_src.get_or_create(p.src_ip).add(p.timestamp)
            if count >= r["syn_packets"]:
                if self.is_scanning(p.src_ip, p.timestamp):
                    # Many SYNs to many ports = the port-scan rule already covers it.
                    self.suppressed["SYN_FLOOD (source is port scanning)"] += 1
                else:
                    out.append(Detection(
                        rule="SYN_FLOOD", category=SYN_FLOOD, severity=r["severity"],
                        title="SYN Flood Indicator",
                        description=(f"{p.src_ip} sent {count} TCP SYN packets within "
                                     f"{r['window_seconds']:g} seconds (threshold {r['syn_packets']}). "
                                     "Heuristic indicator only - it is not proof of a denial-of-service attack; "
                                     "check whether the connections complete and whether the service is affected."),
                        timestamp=p.timestamp, src_ip=p.src_ip, dst_ip=p.dst_ip,
                        details={"syn_packets": count, "time_window_seconds": r["window_seconds"],
                                 "threshold": r["syn_packets"], "target_port": p.dst_port},
                        dedupe_key=("SYN_FLOOD", p.src_ip), peak_fields=("syn_packets",)))
        pd = r["per_destination"]
        if pd["enabled"] and p.dst_ip:
            state = self._syn_dst.get_or_create(p.dst_ip)
            count, sources = state.add(p.timestamp, p.src_ip)
            if count >= pd["syn_packets"] and sources > 1:
                out.append(Detection(
                    rule="SYN_FLOOD_DEST", category=SYN_FLOOD, severity=r["severity"],
                    title="SYN Flood Indicator (many sources, one target)",
                    description=(f"{p.dst_ip} received {count} TCP SYN packets from {sources} different "
                                 f"source addresses within {pd['window_seconds']:g} seconds "
                                 f"(threshold {pd['syn_packets']}). Spoofed-source floods look like this; "
                                 "so can a sudden burst of legitimate clients. Heuristic indicator only."),
                    timestamp=p.timestamp, src_ip=None, dst_ip=p.dst_ip,
                    details={"syn_packets": count, "unique_sources": sources,
                             "time_window_seconds": pd["window_seconds"], "threshold": pd["syn_packets"]},
                    dedupe_key=("SYN_FLOOD_DEST", p.dst_ip), peak_fields=("syn_packets", "unique_sources")))
        return out

    # ------------------------------------------------------------------ ARP
    def _check_arp(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["arp_spoof"]
        if p.arp_op != 2 and not (r["include_requests"] and p.arp_op == 1):
            return []
        ip, mac = p.arp_src_ip, (p.arp_src_mac or "").lower()
        # Safeguards: ignore ARP probes (0.0.0.0) and invalid/placeholder MACs.
        if not ip or ip == "0.0.0.0" or mac in ("", "00:00:00:00:00:00", "ff:ff:ff:ff:ff:ff"):
            self.suppressed["ARP (probe or placeholder MAC ignored)"] += 1
            return []

        static = r["static_mappings"].get(ip)
        entry = self._arp.get(ip)
        if entry is None:
            if len(self._arp) >= self.max_sources:              # memory cap
                oldest = min(self._arp, key=lambda k: self._arp[k]["last_seen"])
                del self._arp[oldest]
            self._arp[ip] = {"mac": mac, "first_seen": p.timestamp, "last_seen": p.timestamp, "changes": 0}
            if static and mac != static:
                return [self._arp_detection(p, ip, static, mac, r["severity"], "static", 0)]
            return []

        if entry["mac"] == mac:
            entry["last_seen"] = p.timestamp
            return []

        old_mac, idle = entry["mac"], p.timestamp - entry["last_seen"]
        entry.update(mac=mac, last_seen=p.timestamp, changes=entry["changes"] + 1)

        if static:
            if mac == static:
                # Returning to the configured, trusted MAC is not an attack.
                self.suppressed["ARP (changed back to static mapping)"] += 1
                return []
            return [self._arp_detection(p, ip, old_mac, mac, r["severity"], "static", entry["changes"])]
        if idle >= r["stale_after_seconds"] and entry["changes"] == 1:
            # Old mapping unused for a long time: most likely a replaced device or DHCP re-use.
            return [self._arp_detection(p, ip, old_mac, mac, "LOW", "stale", entry["changes"], idle)]
        return [self._arp_detection(p, ip, old_mac, mac, r["severity"], "conflict", entry["changes"], idle)]

    def _arp_detection(self, p, ip, old_mac, new_mac, severity, kind, changes, idle=0.0) -> Detection:
        if kind == "static":
            title = "ARP Reply Contradicts Static Mapping"
            why = f"{ip} is configured as {old_mac} in config.json, but an ARP reply claimed {new_mac}."
        elif kind == "stale":
            title = "ARP Mapping Changed After Long Inactivity"
            why = (f"{ip} moved from {old_mac} to {new_mac} after the old MAC was idle for "
                   f"{idle / 60:.0f} minutes. Usually a replaced device or DHCP address re-use.")
        else:
            title = "Suspicious ARP Mapping Change"
            why = (f"{ip} was {old_mac} and is now claimed by {new_mac}"
                   + (f" (mapping has changed {changes} times)" if changes > 1 else "") + ".")
        return Detection(
            rule="ARP_SPOOF", category=ARP_SPOOF, severity=severity, title=title,
            description=why + " Possible ARP spoofing / man-in-the-middle indicator; legitimate causes "
                              "include NIC replacement, VM cloning, failover and DHCP changes.",
            timestamp=p.timestamp, src_ip=ip, dst_ip=p.arp_dst_ip,
            details={"ip_address": ip, "previous_mac": old_mac, "new_mac": new_mac,
                     "mapping_changes": changes, "kind": kind,
                     "previous_mac_idle_seconds": round(idle, 1)},
            dedupe_key=("ARP_SPOOF", ip, old_mac, new_mac), peak_fields=("mapping_changes",))

    def arp_table(self) -> dict:
        return {ip: dict(v) for ip, v in self._arp.items()}

    # ----------------------------------------------------------------- ICMP
    def _check_icmp(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["icmp_flood"]
        if p.icmp_type in r["ignore_types"] or not p.src_ip:
            return []                     # replies/errors are responses, not floods from this host
        count = self._icmp.get_or_create(p.src_ip).add(p.timestamp)
        if count < r["icmp_packets"]:
            return []
        return [Detection(
            rule="ICMP_FLOOD", category=ICMP_FLOOD, severity=r["severity"],
            title="ICMP Flood Indicator",
            description=(f"{p.src_ip} sent {count} ICMP packets within {r['window_seconds']:g} seconds "
                         f"(threshold {r['icmp_packets']}). Unusually high ICMP rate; could be a ping flood "
                         "or an aggressive monitoring/discovery tool."),
            timestamp=p.timestamp, src_ip=p.src_ip, dst_ip=p.dst_ip,
            details={"icmp_packets": count, "time_window_seconds": r["window_seconds"],
                     "threshold": r["icmp_packets"], "icmp_type": p.icmp_type},
            dedupe_key=("ICMP_FLOOD", p.src_ip), peak_fields=("icmp_packets",))]

    # ------------------------------------------------------------------ DNS
    def domain_traits(self, name: str) -> list[str]:
        """Why a domain name looks unusual (empty list = normal)."""
        r = self.rules["dns"]
        traits = []
        labels = [x for x in name.split(".") if x]
        if len(name) > r["max_domain_length"]:
            traits.append(f"long name ({len(name)} chars)")
        longest = max(labels, key=len) if labels else ""
        if len(longest) > r["max_label_length"]:
            traits.append(f"long label ({len(longest)} chars)")
        if len(longest) >= r["min_label_length_for_entropy"]:
            ent = shannon_entropy(longest)
            if ent >= r["entropy_threshold"]:
                traits.append(f"random-looking label (entropy {ent:.2f})")
        return traits

    def _check_dns(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["dns"]
        name, src = p.dns_qname or "", p.src_ip
        if not src:
            return []
        out: list[Detection] = []
        base = dict(timestamp=p.timestamp, src_ip=src, dst_ip=p.dst_ip)

        count = self._dns_rate.get_or_create(src).add(p.timestamp)
        if count >= r["excessive_queries"]:
            out.append(Detection(
                rule="DNS_EXCESSIVE", category=DNS_SUSPICIOUS, severity="MEDIUM",
                title="Excessive DNS Requests",
                description=(f"{src} sent {count} DNS queries within {r['window_seconds']:g} seconds "
                             f"(threshold {r['excessive_queries']}). Unusual volume; not on its own "
                             "evidence of malware."),
                details={"dns_queries": count, "time_window_seconds": r["window_seconds"],
                         "threshold": r["excessive_queries"]},
                dedupe_key=("DNS_EXCESSIVE", src), peak_fields=("dns_queries",), **base))

        burst = self._dns_burst.get_or_create(src).add(p.timestamp)
        if burst >= r["burst_queries"]:
            out.append(Detection(
                rule="DNS_BURST", category=DNS_SUSPICIOUS, severity="LOW",
                title="Suspiciously Frequent DNS Queries",
                description=(f"{src} sent {burst} DNS queries within {r['burst_window_seconds']:g} second(s) "
                             f"(threshold {r['burst_queries']})."),
                details={"dns_queries": burst, "time_window_seconds": r["burst_window_seconds"],
                         "threshold": r["burst_queries"]},
                dedupe_key=("DNS_BURST", src), peak_fields=("dns_queries",), **base))

        if any(name == s or name.endswith("." + s) for s in r["allowlisted_suffixes"]):
            return out
        traits = self.domain_traits(name)
        if not traits:
            return out
        out.append(Detection(
            rule="DNS_UNUSUAL_NAME", category=DNS_SUSPICIOUS, severity="LOW",
            title="Unusual DNS Query Name",
            description=(f"{src} queried {name!r}: {', '.join(traits)}. Long or random-looking names are "
                         "sometimes used for DNS tunnelling or generated domains, but CDNs and "
                         "security products use them legitimately too."),
            details={"domain": name, "traits": "; ".join(traits), "length": len(name)},
            dedupe_key=("DNS_UNUSUAL_NAME", src, name), **base))

        repeats = self._dns_repeat.get_or_create((src, name)).add(p.timestamp)
        if repeats >= r["repeat_unusual_threshold"]:
            out.append(Detection(
                rule="DNS_REPEATED_UNUSUAL", category=DNS_SUSPICIOUS, severity="MEDIUM",
                title="Repeated Queries for an Unusual Domain",
                description=(f"{src} queried the unusual domain {name!r} {repeats} times within "
                             f"{r['repeat_window_seconds']:g} seconds (threshold {r['repeat_unusual_threshold']}). "
                             "Repeated look-ups of odd names can indicate automated beaconing - verify the "
                             "process making them before drawing conclusions."),
                details={"domain": name, "repeats": repeats, "traits": "; ".join(traits),
                         "time_window_seconds": r["repeat_window_seconds"]},
                dedupe_key=("DNS_REPEATED_UNUSUAL", src, name), peak_fields=("repeats",), **base))
        return out

    # ------------------------------------------------------------ blacklist
    def _check_blacklist(self, p: PacketInfo) -> list[Detection]:
        r = self.rules["blacklist"]
        out = []
        checks = [("source", p.src_ip)]
        if r["check_destination"]:
            checks.append(("destination", p.dst_ip))
        for direction, ip in checks:
            entry = self.blacklist.lookup(ip)
            if entry is None:
                continue
            out.append(Detection(
                rule="BLACKLIST", category=BLACKLISTED_IP, severity=r["severity"],
                title="Traffic Involving a Blacklisted IP",
                description=(f"{p.protocol} packet with blacklisted {direction} {ip} "
                             f"(list entry {entry['ip']}). Reason: {entry['reason']}"),
                timestamp=p.timestamp, src_ip=p.src_ip, dst_ip=p.dst_ip,
                details={"blacklisted_ip": ip, "matched_entry": entry["ip"], "reason": entry["reason"],
                         "direction": direction, "protocol": p.protocol},
                dedupe_key=("BLACKLIST", ip, direction)))
        return out


class _DstSynState:
    """SYN count and number of distinct sources for one destination."""
    __slots__ = ("rate", "sources", "last_ts")

    def __init__(self, window: float):
        self.rate = RateCounter(window)
        self.sources = UniqueTracker(window, limit=65536)
        self.last_ts = 0.0

    def add(self, ts: float, src: Optional[str]) -> tuple[int, int]:
        self.last_ts = max(self.last_ts, ts)
        return self.rate.add(ts), self.sources.add(ts, src or "?")


def is_valid_ip(text: str) -> bool:
    try:
        ipaddress.ip_address(text)
        return True
    except ValueError:
        return False
