"""
config_loader.py - load and validate config.json.

The file is merged over built-in defaults, so a config.json that only
changes a few values still works. Every value is type- and range-checked;
any problem is reported as a ConfigError listing *all* mistakes at once.
"""
from __future__ import annotations

import copy
import ipaddress
import json
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
BLACKLIST_PATH = BASE_DIR / "blacklist.json"
DB_PATH = BASE_DIR / "database" / "ids_alerts.db"
REPORT_HTML_DIR = BASE_DIR / "reports" / "html"
REPORT_JSON_DIR = BASE_DIR / "reports" / "json"

SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
DISPLAY_MODES = ("dashboard", "packets")
MAC_RE = re.compile(r"^[0-9a-fA-F]{2}([:-][0-9a-fA-F]{2}){5}$")

DEFAULTS: dict = {
    "interface": "eth0",
    "bpf_filter": "",
    "display": {"mode": "dashboard", "refresh_seconds": 1.0, "max_alerts_shown": 8,
                "max_packet_lines_per_refresh": 25, "color": True},
    "capture": {"queue_size": 10000, "promiscuous": True},
    "engine": {"max_tracked_sources": 5000, "cleanup_every_packets": 2000, "trusted_sources": []},
    "alerts": {"cooldown_seconds": 60, "active_alert_limit": 500,
               "correlation": {"enabled": True, "window_seconds": 300, "min_categories": 3}},
    "rules": {
        "port_scan": {"enabled": True, "unique_ports": 15, "window_seconds": 10,
                      "include_udp": False, "severity": "HIGH"},
        "syn_flood": {"enabled": True, "syn_packets": 100, "window_seconds": 10, "severity": "HIGH",
                      "per_destination": {"enabled": True, "syn_packets": 300, "window_seconds": 10}},
        "arp_spoof": {"enabled": True, "severity": "HIGH", "include_requests": False,
                      "stale_after_seconds": 3600, "static_mappings": {}},
        "icmp_flood": {"enabled": True, "icmp_packets": 100, "window_seconds": 10,
                       "ignore_types": [0, 3, 11], "severity": "MEDIUM"},
        "dns": {"enabled": True, "excessive_queries": 100, "window_seconds": 60,
                "burst_queries": 20, "burst_window_seconds": 1,
                "max_domain_length": 60, "max_label_length": 40,
                "entropy_threshold": 3.8, "min_label_length_for_entropy": 12,
                "repeat_unusual_threshold": 5, "repeat_window_seconds": 60,
                "allowlisted_suffixes": ["in-addr.arpa", "ip6.arpa"]},
        "blacklist": {"enabled": True, "severity": "HIGH", "check_destination": False},
    },
}


class ConfigError(ValueError):
    """Raised when config.json is missing, unreadable or contains invalid values."""


def _merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into a copy of *base*."""
    out = copy.deepcopy(base)
    for key, value in override.items():
        if key.startswith("_"):            # "_comment" keys are allowed and ignored
            continue
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def valid_ip(text: str) -> bool:
    try:
        ipaddress.ip_address(str(text).strip())
        return True
    except ValueError:
        return False


def valid_interface_name(name: str) -> bool:
    """Linux interface names: max 15 chars in the kernel; we allow a little more for aliases."""
    return bool(re.fullmatch(r"[A-Za-z0-9_.:@-]{1,32}", str(name or "")))


def validate_bpf(expr: str) -> str:
    """Basic sanity check of a BPF filter string (libpcap does the real parsing)."""
    expr = (expr or "").strip()
    if len(expr) > 512:
        raise ConfigError("BPF filter is too long (max 512 characters)")
    if any(ord(c) < 32 or ord(c) > 126 for c in expr):
        raise ConfigError("BPF filter contains non-printable characters")
    return expr


def validate(cfg: dict) -> list[str]:
    """Return a list of human-readable problems (empty list = valid)."""
    errors: list[str] = []

    def num(path, value, lo, hi=None, integer=True):
        ok_type = isinstance(value, int) if integer else isinstance(value, (int, float))
        if isinstance(value, bool) or not ok_type:
            errors.append(f"{path} must be {'an integer' if integer else 'a number'} (got {value!r})")
            return
        if value < lo or (hi is not None and value > hi):
            errors.append(f"{path} must be between {lo} and {hi if hi is not None else 'infinity'} (got {value})")

    def boolean(path, value):
        if not isinstance(value, bool):
            errors.append(f"{path} must be true or false (got {value!r})")

    def severity(path, value):
        if value not in SEVERITIES:
            errors.append(f"{path} must be one of {', '.join(SEVERITIES)} (got {value!r})")

    if not valid_interface_name(cfg.get("interface", "")):
        errors.append(f"interface has an invalid name: {cfg.get('interface')!r}")
    try:
        validate_bpf(cfg.get("bpf_filter", ""))
    except ConfigError as exc:
        errors.append(str(exc))

    d = cfg["display"]
    if d.get("mode") not in DISPLAY_MODES:
        errors.append(f"display.mode must be one of {DISPLAY_MODES}")
    num("display.refresh_seconds", d.get("refresh_seconds"), 0.2, 60, integer=False)
    num("display.max_alerts_shown", d.get("max_alerts_shown"), 1, 100)
    num("display.max_packet_lines_per_refresh", d.get("max_packet_lines_per_refresh"), 1, 1000)
    boolean("display.color", d.get("color"))

    num("capture.queue_size", cfg["capture"].get("queue_size"), 100, 1_000_000)
    boolean("capture.promiscuous", cfg["capture"].get("promiscuous"))

    e = cfg["engine"]
    num("engine.max_tracked_sources", e.get("max_tracked_sources"), 10, 1_000_000)
    num("engine.cleanup_every_packets", e.get("cleanup_every_packets"), 10, 10_000_000)
    if not isinstance(e.get("trusted_sources"), list):
        errors.append("engine.trusted_sources must be a list of IP addresses")
    else:
        for ip in e["trusted_sources"]:
            if not valid_ip(ip):
                errors.append(f"engine.trusted_sources contains an invalid IP: {ip!r}")

    a = cfg["alerts"]
    num("alerts.cooldown_seconds", a.get("cooldown_seconds"), 0, 86400, integer=False)
    num("alerts.active_alert_limit", a.get("active_alert_limit"), 10, 100_000)
    c = a.get("correlation", {})
    boolean("alerts.correlation.enabled", c.get("enabled"))
    num("alerts.correlation.window_seconds", c.get("window_seconds"), 1, 86400, integer=False)
    num("alerts.correlation.min_categories", c.get("min_categories"), 2, 10)

    r = cfg["rules"]
    ps = r["port_scan"]
    boolean("rules.port_scan.enabled", ps.get("enabled"))
    num("rules.port_scan.unique_ports", ps.get("unique_ports"), 2, 65535)
    num("rules.port_scan.window_seconds", ps.get("window_seconds"), 0.1, 3600, integer=False)
    boolean("rules.port_scan.include_udp", ps.get("include_udp"))
    severity("rules.port_scan.severity", ps.get("severity"))

    sf = r["syn_flood"]
    boolean("rules.syn_flood.enabled", sf.get("enabled"))
    num("rules.syn_flood.syn_packets", sf.get("syn_packets"), 2, 10_000_000)
    num("rules.syn_flood.window_seconds", sf.get("window_seconds"), 0.1, 3600, integer=False)
    severity("rules.syn_flood.severity", sf.get("severity"))
    pd = sf.get("per_destination", {})
    boolean("rules.syn_flood.per_destination.enabled", pd.get("enabled"))
    num("rules.syn_flood.per_destination.syn_packets", pd.get("syn_packets"), 2, 10_000_000)
    num("rules.syn_flood.per_destination.window_seconds", pd.get("window_seconds"), 0.1, 3600, integer=False)

    ar = r["arp_spoof"]
    boolean("rules.arp_spoof.enabled", ar.get("enabled"))
    severity("rules.arp_spoof.severity", ar.get("severity"))
    boolean("rules.arp_spoof.include_requests", ar.get("include_requests"))
    num("rules.arp_spoof.stale_after_seconds", ar.get("stale_after_seconds"), 1, 10_000_000, integer=False)
    sm = ar.get("static_mappings")
    if not isinstance(sm, dict):
        errors.append("rules.arp_spoof.static_mappings must be an object {\"ip\": \"mac\"}")
    else:
        for ip, mac in sm.items():
            if not valid_ip(ip):
                errors.append(f"rules.arp_spoof.static_mappings has an invalid IP: {ip!r}")
            if not isinstance(mac, str) or not MAC_RE.match(mac):
                errors.append(f"rules.arp_spoof.static_mappings has an invalid MAC for {ip}: {mac!r}")

    ic = r["icmp_flood"]
    boolean("rules.icmp_flood.enabled", ic.get("enabled"))
    num("rules.icmp_flood.icmp_packets", ic.get("icmp_packets"), 2, 10_000_000)
    num("rules.icmp_flood.window_seconds", ic.get("window_seconds"), 0.1, 3600, integer=False)
    severity("rules.icmp_flood.severity", ic.get("severity"))
    it = ic.get("ignore_types")
    if not isinstance(it, list) or not all(isinstance(t, int) and 0 <= t <= 255 for t in it):
        errors.append("rules.icmp_flood.ignore_types must be a list of ICMP type numbers 0-255")

    dn = r["dns"]
    boolean("rules.dns.enabled", dn.get("enabled"))
    num("rules.dns.excessive_queries", dn.get("excessive_queries"), 2, 10_000_000)
    num("rules.dns.window_seconds", dn.get("window_seconds"), 0.1, 86400, integer=False)
    num("rules.dns.burst_queries", dn.get("burst_queries"), 2, 10_000_000)
    num("rules.dns.burst_window_seconds", dn.get("burst_window_seconds"), 0.1, 3600, integer=False)
    num("rules.dns.max_domain_length", dn.get("max_domain_length"), 10, 253)
    num("rules.dns.max_label_length", dn.get("max_label_length"), 5, 63)
    num("rules.dns.entropy_threshold", dn.get("entropy_threshold"), 0.5, 8, integer=False)
    num("rules.dns.min_label_length_for_entropy", dn.get("min_label_length_for_entropy"), 4, 63)
    num("rules.dns.repeat_unusual_threshold", dn.get("repeat_unusual_threshold"), 2, 100_000)
    num("rules.dns.repeat_window_seconds", dn.get("repeat_window_seconds"), 0.1, 86400, integer=False)
    if not isinstance(dn.get("allowlisted_suffixes"), list) or not all(
            isinstance(s, str) for s in dn["allowlisted_suffixes"]):
        errors.append("rules.dns.allowlisted_suffixes must be a list of domain suffixes")

    bl = r["blacklist"]
    boolean("rules.blacklist.enabled", bl.get("enabled"))
    severity("rules.blacklist.severity", bl.get("severity"))
    boolean("rules.blacklist.check_destination", bl.get("check_destination"))
    return errors


def load_config(path: str | Path | None = None) -> dict:
    """Load config.json (or defaults if it does not exist) and validate it."""
    path = Path(path) if path else CONFIG_PATH
    user: dict = {}
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"{path.name} is not valid JSON: line {exc.lineno}, column {exc.colno}: {exc.msg}")
        except OSError as exc:
            raise ConfigError(f"cannot read {path}: {exc}")
        if not isinstance(user, dict):
            raise ConfigError(f"{path.name} must contain a JSON object")
    cfg = _merge(DEFAULTS, user)
    problems = validate(cfg)
    if problems:
        raise ConfigError("invalid configuration:\n  - " + "\n  - ".join(problems))
    # Normalise static ARP MACs once so comparisons are simple later.
    cfg["rules"]["arp_spoof"]["static_mappings"] = {
        str(ipaddress.ip_address(ip)): mac.lower().replace("-", ":")
        for ip, mac in cfg["rules"]["arp_spoof"]["static_mappings"].items()
    }
    return cfg
