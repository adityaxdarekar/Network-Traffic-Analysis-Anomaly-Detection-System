"""
database.py - SQLite storage for monitoring sessions and security alerts.

Tables
  sessions : one row per monitoring run (interface, start/end, packet counts)
  alerts   : one row per alert (id, time, IPs, category, severity, description, ...)

One connection is shared between threads (check_same_thread=False) and every
access is serialised with a lock. All queries use parameters (no string
formatting of user input into SQL).
"""
from __future__ import annotations

import ipaddress
import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    started       TEXT NOT NULL,
    ended         TEXT,
    interface     TEXT NOT NULL,
    source        TEXT NOT NULL,          -- live / pcap
    bpf_filter    TEXT,
    total_packets INTEGER DEFAULT 0,
    total_bytes   INTEGER DEFAULT 0,
    tcp INTEGER DEFAULT 0, udp INTEGER DEFAULT 0, icmp INTEGER DEFAULT 0,
    arp INTEGER DEFAULT 0, dns INTEGER DEFAULT 0, other INTEGER DEFAULT 0,
    dropped       INTEGER DEFAULT 0,
    malformed     INTEGER DEFAULT 0,
    alert_count   INTEGER DEFAULT 0,
    notes         TEXT
);
CREATE TABLE IF NOT EXISTS alerts (
    alert_id       TEXT PRIMARY KEY,
    session_id     INTEGER REFERENCES sessions(id),
    timestamp      TEXT NOT NULL,
    source_ip      TEXT,
    destination_ip TEXT,
    category       TEXT NOT NULL,
    severity       TEXT NOT NULL,
    title          TEXT,
    description    TEXT,
    rule           TEXT,
    recommended_action TEXT,
    details        TEXT,
    occurrences    INTEGER DEFAULT 1,
    last_seen      TEXT
);
CREATE INDEX IF NOT EXISTS idx_alerts_src ON alerts(source_ip);
CREATE INDEX IF NOT EXISTS idx_alerts_dst ON alerts(destination_ip);
CREATE INDEX IF NOT EXISTS idx_alerts_sev ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_time ON alerts(timestamp);
"""


class DatabaseError(RuntimeError):
    pass


class AlertDatabase:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10)
            self.conn.row_factory = sqlite3.Row
            with self.conn:
                self.conn.executescript(SCHEMA)
        except sqlite3.Error as exc:
            raise DatabaseError(f"cannot open database {self.path}: {exc}") from exc

    def close(self) -> None:
        with self._lock:
            self.conn.close()

    # --------------------------------------------------------------- helpers
    def _exec(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            try:
                with self.conn:
                    return self.conn.execute(sql, params)
            except sqlite3.Error as exc:
                raise DatabaseError(str(exc)) from exc

    def _rows(self, sql: str, params: tuple = ()) -> list[dict]:
        with self._lock:
            try:
                rows = self.conn.execute(sql, params).fetchall()
            except sqlite3.Error as exc:
                raise DatabaseError(str(exc)) from exc
        out = []
        for r in rows:
            d = dict(r)
            if "details" in d:
                try:
                    d["details"] = json.loads(d["details"] or "{}")
                except json.JSONDecodeError:
                    d["details"] = {}
            out.append(d)
        return out

    # -------------------------------------------------------------- sessions
    def create_session(self, interface: str, source: str, bpf_filter: str = "", notes: str = "") -> int:
        cur = self._exec(
            "INSERT INTO sessions (started, interface, source, bpf_filter, notes) VALUES (?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), interface, source, bpf_filter, notes))
        return int(cur.lastrowid)

    def finish_session(self, session_id: int, stats: dict, alert_count: int,
                       started: Optional[str] = None, ended: Optional[str] = None) -> None:
        p = stats.get("by_protocol", {})
        self._exec(
            """UPDATE sessions SET ended=?, total_packets=?, total_bytes=?, tcp=?, udp=?, icmp=?, arp=?,
               dns=?, other=?, dropped=?, malformed=?, alert_count=?, started=COALESCE(?, started)
               WHERE id=?""",
            (ended or datetime.now().isoformat(timespec="seconds"), stats.get("total", 0),
             stats.get("bytes", 0), p.get("TCP", 0), p.get("UDP", 0), p.get("ICMP", 0), p.get("ARP", 0),
             p.get("DNS", 0), p.get("OTHER", 0) + p.get("ICMPv6", 0), stats.get("dropped", 0),
             stats.get("malformed", 0), alert_count, started, session_id))

    def session(self, session_id: int) -> Optional[dict]:
        rows = self._rows("SELECT * FROM sessions WHERE id=?", (session_id,))
        return rows[0] if rows else None

    def sessions(self, limit: int = 20) -> list[dict]:
        return self._rows("SELECT * FROM sessions ORDER BY id DESC LIMIT ?", (int(limit),))

    def latest_session(self) -> Optional[dict]:
        rows = self.sessions(1)
        return rows[0] if rows else None

    # ---------------------------------------------------------------- alerts
    def save_alert(self, alert) -> None:
        """Insert or update an Alert (object with to_dict() or a dict)."""
        a = alert.to_dict() if hasattr(alert, "to_dict") else dict(alert)
        self._exec(
            """INSERT INTO alerts (alert_id, session_id, timestamp, source_ip, destination_ip, category,
                   severity, title, description, rule, recommended_action, details, occurrences, last_seen)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(alert_id) DO UPDATE SET details=excluded.details,
                   occurrences=excluded.occurrences, last_seen=excluded.last_seen""",
            (a["alert_id"], a.get("session_id"), a["timestamp"], a.get("source_ip"), a.get("destination_ip"),
             a["category"], a["severity"], a.get("title"), a.get("description"), a.get("rule"),
             a.get("recommended_action"), json.dumps(a.get("details", {}), default=str),
             a.get("occurrences", 1), a.get("last_seen")))

    def recent_alerts(self, limit: int = 20) -> list[dict]:
        return self._rows("SELECT * FROM alerts ORDER BY timestamp DESC, alert_id DESC LIMIT ?", (int(limit),))

    def alerts_for_session(self, session_id: int) -> list[dict]:
        return self._rows("SELECT * FROM alerts WHERE session_id=? ORDER BY timestamp, alert_id", (session_id,))

    def search_by_ip(self, ip: str, limit: int = 200) -> list[dict]:
        ip = str(ipaddress.ip_address(ip.strip()))       # raises ValueError for invalid input
        return self._rows(
            """SELECT * FROM alerts WHERE source_ip=? OR destination_ip=?
               ORDER BY timestamp DESC, alert_id DESC LIMIT ?""", (ip, ip, int(limit)))

    def by_severity(self, severity: str, limit: int = 200) -> list[dict]:
        severity = severity.strip().upper()
        if severity not in SEVERITIES:
            raise ValueError(f"severity must be one of {', '.join(SEVERITIES)}")
        return self._rows("SELECT * FROM alerts WHERE severity=? ORDER BY timestamp DESC, alert_id DESC LIMIT ?",
                          (severity, int(limit)))

    def history(self, limit: int = 50, offset: int = 0, severity: Optional[str] = None) -> list[dict]:
        if severity:
            severity = severity.strip().upper()
            if severity not in SEVERITIES:
                raise ValueError(f"severity must be one of {', '.join(SEVERITIES)}")
            return self._rows("""SELECT * FROM alerts WHERE severity=?
                                 ORDER BY timestamp DESC, alert_id DESC LIMIT ? OFFSET ?""",
                              (severity, int(limit), int(offset)))
        return self._rows("SELECT * FROM alerts ORDER BY timestamp DESC, alert_id DESC LIMIT ? OFFSET ?",
                          (int(limit), int(offset)))

    def count_alerts(self, severity: Optional[str] = None) -> int:
        if severity:
            return self._rows("SELECT COUNT(*) AS n FROM alerts WHERE severity=?", (severity.upper(),))[0]["n"]
        return self._rows("SELECT COUNT(*) AS n FROM alerts")[0]["n"]

    def totals(self) -> dict:
        sev = {r["severity"]: r["n"] for r in
               self._rows("SELECT severity, COUNT(*) AS n FROM alerts GROUP BY severity")}
        cat = {r["category"]: r["n"] for r in
               self._rows("SELECT category, COUNT(*) AS n FROM alerts GROUP BY category ORDER BY n DESC")}
        top = self._rows("""SELECT source_ip, COUNT(*) AS n FROM alerts WHERE source_ip IS NOT NULL
                            GROUP BY source_ip ORDER BY n DESC LIMIT 10""")
        packets = self._rows("SELECT COALESCE(SUM(total_packets),0) AS p, COUNT(*) AS s FROM sessions")[0]
        return {"by_severity": {s: sev.get(s, 0) for s in SEVERITIES}, "by_category": cat,
                "top_sources": top, "total_alerts": sum(sev.values()),
                "total_packets": packets["p"], "sessions": packets["s"]}
