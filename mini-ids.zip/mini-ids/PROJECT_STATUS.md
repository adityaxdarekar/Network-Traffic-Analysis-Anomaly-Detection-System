# Project status — verified vs. still to verify

## ✅ Verified in the build environment (Ubuntu 24.04, Python 3.13, no Scapy, no network)
| Item | Evidence |
|---|---|
| All modules compile and import together | `python3 -m py_compile *.py`; test suite |
| 29 automated tests pass | `python3 -m pytest -q` → 29 passed |
| Config validation | invalid values, bad JSON, partial configs, BPF sanity checks (tests) |
| Packet parsing | TCP/UDP/ICMP/ARP/DNS/IPv6 fields, both Scapy DNS question formats, ICMP errors not counted as TCP — **against a test double of Scapy** |
| Statistics, queue overflow → "dropped", malformed packets do not stop the IDS | tests |
| Blacklist add/remove/save/lookup (IP and CIDR), input validation | tests |
| Alert cool-down, merging of repeats, peak values, recommended actions | tests |
| SQLite sessions + alerts, search by IP, severity filter, injection-style input rejected | tests |
| HTML/JSON report sections, HTML escaping of alert text | tests + visual check (`screenshots/`) |
| Live-capture plumbing (start/stop, BPF passed through, permission and unknown-interface errors) | tests with a fake AsyncSniffer |
| `.pcap` replay path, blacklist alert end-to-end, CLI flags, all 8 menu options | tests; `main.py` run in the sandbox (fails cleanly with "Scapy is not installed") |

## ⚠️ NOT verified — do this in your Kali lab
| Item | Why | How |
|---|---|---|
| **Detection rules: port scan, SYN flood, ARP change, ICMP flood, DNS heuristics, correlation** | no automated tests for these rules are included in this package | rehearse each demo in the isolated lab and check the alert fields (docs/DEMO_GUIDE.md) |
| Real Scapy compatibility | Scapy could not be installed (no package downloads) | `pip install -r requirements.txt`, then `python3 -m pytest -q` and a short live capture |
| Live capture on Kali (permissions, interface, BPF filters) | no Scapy / raw sockets here | `sudo venv/bin/python3 main.py --monitor -i eth1 --duration 60` |
| Performance under heavy traffic | not measured | watch the "Dropped" counter; raise `capture.queue_size` if needed |
| Threshold suitability for your network | depends on your traffic | tune `config.json` |

Known limitation: if monitoring fails to start (for example, no root), an empty session row is still saved in the database.

All files in `sample_output/` and `screenshots/` come from the test stand-in (7 ordinary packets plus 3 packets from the documentation address 203.0.113.50) and are labelled as such.
