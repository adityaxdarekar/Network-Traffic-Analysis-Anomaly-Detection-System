"""
blacklist_manager.py - load, query and edit blacklist.json.

Entries may be single addresses ("203.0.113.50") or networks
("198.51.100.0/24"). Lookups are cached, and all access is protected by a
lock because the menu thread can edit the list while the IDS thread reads it.

The shipped entries are RFC 5737 *documentation* addresses used for testing;
they are not claims about real malicious hosts.
"""
from __future__ import annotations

import ipaddress
import json
import os
import tempfile
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional


class BlacklistError(ValueError):
    pass


def parse_entry(text: str):
    """Return an ip_address or ip_network object, or raise BlacklistError."""
    text = str(text or "").strip()
    if not text:
        raise BlacklistError("empty IP address")
    try:
        if "/" in text:
            net = ipaddress.ip_network(text, strict=False)
            if net.num_addresses > 2 ** 24 and net.version == 4:
                raise BlacklistError(f"network {text} is too large (max /8 for IPv4)")
            return net
        return ipaddress.ip_address(text)
    except ValueError:
        raise BlacklistError(f"not a valid IP address or network: {text!r}") from None


class BlacklistManager:
    MAX_REASON = 200
    CACHE_LIMIT = 20000

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._entries: dict[str, dict] = {}       # canonical text -> entry
        self._addresses: dict[str, str] = {}      # single IP -> canonical key
        self._networks: list[tuple] = []          # (network, canonical key)
        self._cache: dict[str, Optional[dict]] = {}
        self.load()

    # ------------------------------------------------------------------ io
    def load(self) -> None:
        with self._lock:
            self._entries.clear()
            if self.path.exists():
                try:
                    data = json.loads(self.path.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError) as exc:
                    raise BlacklistError(f"cannot read {self.path.name}: {exc}") from None
                raw = data.get("entries", []) if isinstance(data, dict) else data
                if not isinstance(raw, list):
                    raise BlacklistError(f"{self.path.name}: 'entries' must be a list")
                for item in raw:
                    if isinstance(item, str):
                        item = {"ip": item}
                    if not isinstance(item, dict) or "ip" not in item:
                        raise BlacklistError(f"{self.path.name}: invalid entry {item!r}")
                    obj = parse_entry(item["ip"])
                    key = str(obj)
                    self._entries[key] = {"ip": key,
                                          "reason": str(item.get("reason", "No reason given"))[:self.MAX_REASON],
                                          "added": str(item.get("added", ""))}
            self._rebuild()

    def save(self) -> None:
        """Write atomically (temp file + rename) so a crash never leaves half a file."""
        with self._lock:
            payload = {
                "_comment": "Use documentation/lab addresses for testing. Managed by Mini IDS menu option 5.",
                "entries": sorted(self._entries.values(), key=lambda e: e["ip"]),
            }
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".blacklist-", suffix=".json")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump(payload, fh, indent=2)
                os.replace(tmp, self.path)
            except Exception:
                if os.path.exists(tmp):
                    os.unlink(tmp)
                raise

    def _rebuild(self) -> None:
        self._addresses.clear()
        self._networks.clear()
        self._cache.clear()
        for key in self._entries:
            obj = parse_entry(key)
            if isinstance(obj, (ipaddress.IPv4Network, ipaddress.IPv6Network)):
                self._networks.append((obj, key))
            else:
                self._addresses[str(obj)] = key

    # ---------------------------------------------------------------- edit
    def add(self, ip: str, reason: str) -> dict:
        obj = parse_entry(ip)
        reason = " ".join(str(reason or "").split())[:self.MAX_REASON] or "No reason given"
        with self._lock:
            key = str(obj)
            entry = {"ip": key, "reason": reason, "added": datetime.now().isoformat(timespec="seconds")}
            self._entries[key] = entry
            self._rebuild()
            self.save()
            return entry

    def remove(self, ip: str) -> bool:
        key = str(parse_entry(ip))
        with self._lock:
            if key not in self._entries:
                return False
            del self._entries[key]
            self._rebuild()
            self.save()
            return True

    # --------------------------------------------------------------- query
    def entries(self) -> list[dict]:
        with self._lock:
            return [dict(e) for e in sorted(self._entries.values(), key=lambda e: e["ip"])]

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)

    def lookup(self, ip: Optional[str]) -> Optional[dict]:
        """Return the matching blacklist entry for *ip*, or None."""
        if not ip:
            return None
        with self._lock:
            if ip in self._cache:
                return self._cache[ip]
            result = None
            key = self._addresses.get(ip)
            if key is None and self._networks:
                try:
                    addr = ipaddress.ip_address(ip)
                except ValueError:
                    addr = None
                if addr is not None:
                    for net, nkey in self._networks:
                        if addr.version == net.version and addr in net:
                            key = nkey
                            break
            if key is not None:
                result = dict(self._entries[key])
            if len(self._cache) >= self.CACHE_LIMIT:
                self._cache.clear()
            self._cache[ip] = result
            return result
