#!/usr/bin/env python3
"""
main.py - Mini Intrusion Detection System: menu, command-line options and
the live monitoring loop.

Interactive menu:   sudo venv/bin/python3 main.py
Direct monitoring:  sudo venv/bin/python3 main.py --monitor -i eth0 --duration 120 --report
Replay a capture:   python3 main.py --pcap lab_capture.pcap --report

Only monitor networks and devices you own or are explicitly authorised to monitor.
"""
from __future__ import annotations

import argparse
import sys
import time
from typing import Callable, Optional

import ui
from blacklist_manager import BlacklistError, BlacklistManager
from config_loader import (BLACKLIST_PATH, DB_PATH, ConfigError, load_config, valid_interface_name,
                           validate_bpf)
from database import SEVERITIES, AlertDatabase, DatabaseError
from ids_monitor import MonitorSession
from packet_capture import CaptureError, default_interface, has_capture_privileges, list_interfaces
from report_generator import build_report, report_for_session, save_report

AUTH_TEXT = ("Only monitor networks and devices that you own or are explicitly authorised to monitor.\n"
             "Capturing other people's traffic without permission may be illegal.")


class App:
    def __init__(self, config: dict, db: AlertDatabase, blacklist: BlacklistManager,
                 input_fn: Callable[[str], str] = input, out=None):
        self.cfg = config
        self.db = db
        self.blacklist = blacklist
        self.input = input_fn
        self.out = out or sys.stdout
        self.last_session: Optional[MonitorSession] = None

    def say(self, text: str = "") -> None:
        print(text, file=self.out)

    def ask(self, prompt: str, default: str = "") -> str:
        try:
            value = self.input(prompt).strip()
        except EOFError:
            value = ""
        return value or default

    # ------------------------------------------------------------ monitoring
    def monitor(self, *, interface: Optional[str] = None, bpf: Optional[str] = None,
                duration: float = 0, mode: Optional[str] = None, pcap: Optional[str] = None,
                authorized: bool = False, report: bool = False) -> Optional[MonitorSession]:
        mode = mode or self.cfg["display"]["mode"]
        if pcap is None and not authorized:
            self.say(ui.warn(AUTH_TEXT))
            if self.ask("Do you own or have authorisation to monitor this network? (yes/no): ").lower() not in ("y", "yes"):
                self.say(ui.info("Monitoring cancelled."))
                return None
        try:
            if bpf:
                validate_bpf(bpf)
            if pcap:
                session = MonitorSession(self.cfg, self.blacklist, self.db, source="pcap",
                                         pcap_path=pcap, bpf_filter=bpf)
            else:
                session = MonitorSession(self.cfg, self.blacklist, self.db, source="live",
                                         interface=interface, bpf_filter=bpf)
            session.start()
        except (CaptureError, ConfigError) as exc:
            self.say(ui.error(str(exc)))
            return None
        self.last_session = session
        self.say(ui.ok(f"Monitoring {session.interface} (session {session.session_id}). Press Ctrl+C to stop."))
        try:
            self._display_loop(session, duration, mode)
        except KeyboardInterrupt:
            self.say("\n" + ui.info("Stopping capture..."))
        finally:
            session.stop()
        for err in session.errors[:5]:
            self.say(ui.warn(err))
        self._summary(session)
        if report:
            self._save_report(build_report(self.db.session(session.session_id),
                                           self.db.alerts_for_session(session.session_id)))
        return session

    def _display_loop(self, session: MonitorSession, duration: float, mode: str) -> None:
        refresh = self.cfg["display"]["refresh_seconds"]
        max_lines = self.cfg["display"]["max_packet_lines_per_refresh"]
        start, seq = time.monotonic(), 0
        while True:
            if duration and time.monotonic() - start >= duration:
                break
            if session.source_kind == "pcap" and session.source_finished():
                break
            if session.source_kind == "live" and not session.capture.alive():
                session.errors.append("capture stopped unexpectedly")
                break
            if mode == "packets":
                seq, pkts, missed = session.stats.recent_since(seq)
                for p in pkts[-max_lines:]:
                    self.say(p.summary())
                hidden = missed + max(0, len(pkts) - max_lines)
                if hidden:
                    self.say(ui.dim(f"   ... {hidden} more packets not shown"))
                while not session.new_alerts.empty():
                    self.say(ui.alert_block(session.new_alerts.get_nowait()))
            else:
                while not session.new_alerts.empty():
                    session.new_alerts.get_nowait()
                ui.clear_screen()
                self.say(ui.dashboard(session.meta(), session.stats.snapshot(), session.alerts.counts(),
                                      session.alerts.active_alerts(self.cfg["display"]["max_alerts_shown"])))
            time.sleep(refresh)

    def _summary(self, s: MonitorSession) -> None:
        snap, counts = s.stats.snapshot(), s.alerts.counts()
        self.say("")
        self.say(ui.bold("Session summary"))
        self.say(ui.table([[s.session_id, s.interface, snap["total"], counts["total"], counts["CRITICAL"],
                            counts["HIGH"], counts["MEDIUM"], counts["LOW"], snap["dropped"]]],
                          ["Session", "Interface", "Packets", "Alerts", "Crit", "High", "Med", "Low", "Dropped"]))

    # --------------------------------------------------------------- alerts
    def _alert_rows(self, alerts: list) -> list[list]:
        rows = []
        for a in alerts:
            g = a.get if isinstance(a, dict) else (lambda k, d=None, a=a: getattr(a, k, d))
            rows.append([g("alert_id"), g("timestamp"), ui.sev(g("severity")), g("category"),
                         g("source_ip") or "-", g("destination_ip") or "-", ui._short(g("title"), 40)])
        return rows

    HEAD = ["ID", "Time", "Severity", "Category", "Source", "Destination", "Title"]

    def view_active(self) -> None:
        if self.last_session is not None:
            alerts = self.last_session.alerts.active_alerts()
            self.say(ui.info(f"Alerts from session {self.last_session.session_id} ({len(alerts)})"))
        else:
            latest = self.db.latest_session()
            if latest is None:
                self.say(ui.info("No monitoring sessions yet."))
                return
            alerts = self.db.alerts_for_session(latest["id"])
            self.say(ui.info(f"Alerts from the latest stored session {latest['id']} ({len(alerts)})"))
        for a in alerts[-20:]:
            self.say(ui.alert_block(a))
            self.say("")
        if not alerts:
            self.say(ui.ok("No alerts."))

    def view_history(self) -> None:
        sev = self.ask(f"Filter by severity ({'/'.join(SEVERITIES)}, Enter = all): ").upper()
        try:
            rows = self.db.history(limit=50, severity=sev or None)
        except ValueError as exc:
            self.say(ui.error(str(exc)))
            return
        self.say(ui.table(self._alert_rows(rows), self.HEAD))
        self.say(ui.info(f"{len(rows)} shown, {self.db.count_alerts()} alerts stored in total."))

    def search_ip(self, ip: Optional[str] = None) -> None:
        ip = ip or self.ask("IP address to search: ")
        try:
            rows = self.db.search_by_ip(ip)
        except ValueError:
            self.say(ui.error(f"Invalid IP address: {ip!r}"))
            return
        self.say(ui.table(self._alert_rows(rows), self.HEAD))
        self.say(ui.info(f"{len(rows)} alert(s) involve {ip}."))

    # ------------------------------------------------------------- blacklist
    def manage_blacklist(self) -> None:
        while True:
            self.say("")
            self.say(ui.bold("IP blacklist") + f"  ({len(self.blacklist)} entries, {self.blacklist.path.name})")
            self.say("  1. List entries\n  2. Add IP / network\n  3. Remove IP / network\n  4. Back")
            choice = self.ask("Select: ")
            if choice == "1":
                self.say(ui.table([[e["ip"], e["reason"], e["added"]] for e in self.blacklist.entries()],
                                  ["IP / network", "Reason", "Added"]))
            elif choice == "2":
                ip = self.ask("IP or CIDR (use lab/documentation addresses for tests): ")
                reason = self.ask("Reason: ", "Lab test entry")
                try:
                    e = self.blacklist.add(ip, reason)
                    self.say(ui.ok(f"Added {e['ip']}"))
                except (BlacklistError, OSError) as exc:
                    self.say(ui.error(str(exc)))
            elif choice == "3":
                ip = self.ask("IP or CIDR to remove: ")
                try:
                    self.say(ui.ok("Removed.") if self.blacklist.remove(ip) else ui.warn("Not in the blacklist."))
                except (BlacklistError, OSError) as exc:
                    self.say(ui.error(str(exc)))
            elif choice in ("4", "", "b", "q"):
                return
            else:
                self.say(ui.warn("Choose 1-4."))

    # --------------------------------------------------------------- reports
    def generate_report(self, session_id: Optional[int] = None) -> None:
        sessions = self.db.sessions(10)
        if not sessions:
            self.say(ui.info("No monitoring sessions to report on yet."))
            return
        if session_id is None:
            self.say(ui.table([[s["id"], s["source"], s["interface"], s["started"], s["total_packets"],
                                s["alert_count"]] for s in sessions],
                              ["Session", "Source", "Interface", "Started", "Packets", "Alerts"]))
            text = self.ask(f"Session number (Enter = {sessions[0]['id']}): ", str(sessions[0]["id"]))
            if not text.isdigit():
                self.say(ui.error("Please enter a session number."))
                return
            session_id = int(text)
        try:
            self._save_report(report_for_session(self.db, session_id))
        except ValueError as exc:
            self.say(ui.error(str(exc)))

    def _save_report(self, report: dict) -> None:
        try:
            h, j = save_report(report)
        except OSError as exc:
            self.say(ui.error(f"cannot write report: {exc}"))
            return
        self.say(ui.ok(f"HTML report: {h}"))
        self.say(ui.ok(f"JSON export: {j}"))

    # ------------------------------------------------------------ statistics
    def statistics(self) -> None:
        if self.last_session is not None:
            s = self.last_session
            snap = s.stats.snapshot()
            self.say(ui.bold(f"Last session ({s.session_id}, {s.interface}, {s.status})"))
            self.say(ui.table([[k, v] for k, v in snap["by_protocol"].items()] +
                              [["TOTAL", snap["total"]], ["Bytes", snap["bytes"]], ["Dropped", snap["dropped"]],
                               ["Malformed", snap["malformed"]],
                               ["Tracked state entries", s.engine.tracked_sources()]], ["Metric", "Value"]))
            hits = s.engine.rule_hits
            if hits:
                self.say(ui.table([[k, v] for k, v in hits.most_common()], ["Rule", "Raw matches"]))
            if s.engine.suppressed:
                self.say(ui.table([[k, v] for k, v in s.engine.suppressed.items()], ["Safeguard", "Suppressed"]))
        t = self.db.totals()
        self.say(ui.bold("All stored sessions"))
        self.say(ui.table([["Sessions", t["sessions"]], ["Packets analysed", t["total_packets"]],
                           ["Alerts", t["total_alerts"]]] +
                          [[ui.sev(k), v] for k, v in t["by_severity"].items()], ["Metric", "Value"]))
        if t["by_category"]:
            self.say(ui.table([[k, v] for k, v in t["by_category"].items()], ["Category", "Alerts"]))
        if t["top_sources"]:
            self.say(ui.table([[r["source_ip"], r["n"]] for r in t["top_sources"]], ["Top alert sources", "Alerts"]))

    # ------------------------------------------------------------------ menu
    def start_monitoring_interactive(self) -> None:
        names = list_interfaces()
        default = self.cfg["interface"] if self.cfg["interface"] in names else (default_interface() or self.cfg["interface"])
        if names:
            self.say(ui.info("Interfaces: " + ", ".join(names)))
        iface = self.ask(f"Interface (Enter = {default}): ", default)
        if not valid_interface_name(iface):
            self.say(ui.error("Invalid interface name."))
            return
        bpf = self.ask(f"BPF filter, e.g. 'tcp or arp' (Enter = {self.cfg['bpf_filter'] or 'none'}): ",
                       self.cfg["bpf_filter"])
        mode = self.ask("Display: 1 = dashboard, 2 = packet feed (Enter = 1): ", "1")
        dur = self.ask("Duration in seconds (Enter = until Ctrl+C): ", "0")
        try:
            duration = max(0.0, float(dur))
        except ValueError:
            self.say(ui.error("Duration must be a number."))
            return
        if not has_capture_privileges():
            self.say(ui.warn("Not running as root / without CAP_NET_RAW - capture will probably fail."))
        self.monitor(interface=iface, bpf=bpf, duration=duration,
                     mode="packets" if mode == "2" else "dashboard")
        if self.last_session is not None and self.ask("Generate a report for this session? (y/N): ").lower() in ("y", "yes"):
            self.generate_report(self.last_session.session_id)

    def menu(self) -> None:
        self.say(ui.banner())
        actions = {"1": self.start_monitoring_interactive, "2": self.view_active, "3": self.view_history,
                   "4": self.search_ip, "5": self.manage_blacklist, "6": self.generate_report,
                   "7": self.statistics}
        while True:
            status = ui.green("RUNNING") if self.last_session and self.last_session.status == "RUNNING" else ui.yellow("IDLE")
            self.say("")
            self.say(f"{ui.bold('MAIN MENU')}   IDS status: {status}   Stored alerts: {self.db.count_alerts()}")
            self.say("  1. Start Live Network Monitoring\n  2. View Active Security Alerts\n  3. View Alert History\n"
                     "  4. Search Alerts by IP\n  5. Manage IP Blacklist\n  6. Generate Security Report\n"
                     "  7. View IDS Statistics\n  8. Exit")
            try:
                choice = self.input("Select an option (1-8): ").strip()
            except EOFError:
                choice = "8"
            except KeyboardInterrupt:
                self.say("")
                choice = "8"
            if choice == "8":
                self.say(ui.info("Goodbye."))
                return
            action = actions.get(choice)
            if action is None:
                self.say(ui.warn("Please choose a number from 1 to 8."))
                continue
            try:
                action()
            except KeyboardInterrupt:
                self.say("\n" + ui.info("Cancelled."))
            except DatabaseError as exc:
                self.say(ui.error(f"database error: {exc}"))


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Mini Intrusion Detection System (Python + Scapy)",
                                epilog="Only monitor networks you own or are authorised to monitor.")
    p.add_argument("--config", help="path to config.json")
    p.add_argument("--monitor", action="store_true", help="start live monitoring immediately")
    p.add_argument("-i", "--interface", help="network interface (default from config.json)")
    p.add_argument("-f", "--filter", dest="bpf", help="BPF capture filter, e.g. 'tcp or arp or icmp or port 53'")
    p.add_argument("--duration", type=float, default=0, help="stop after N seconds (0 = until Ctrl+C)")
    p.add_argument("--mode", choices=("dashboard", "packets"), help="live display mode")
    p.add_argument("--pcap", help="analyse a saved .pcap/.pcapng file instead of live traffic")
    p.add_argument("--report", action="store_true", help="write HTML + JSON report when monitoring ends")
    p.add_argument("--yes", action="store_true", help="confirm you are authorised (skips the prompt)")
    p.add_argument("--list-interfaces", action="store_true", help="show capture interfaces and exit")
    p.add_argument("--history", action="store_true", help="print recent alerts and exit")
    p.add_argument("--search", metavar="IP", help="print alerts involving IP and exit")
    p.add_argument("--report-session", type=int, metavar="ID", help="write a report for a stored session and exit")
    p.add_argument("--no-color", action="store_true", help="disable coloured output")
    p.add_argument("--db", help=argparse.SUPPRESS)
    p.add_argument("--blacklist", help=argparse.SUPPRESS)
    return p.parse_args(argv)


def main(argv=None, input_fn=input) -> int:
    args = parse_args(argv)
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(ui.error(str(exc)))
        return 2
    ui.set_color(cfg["display"]["color"] and not args.no_color and sys.stdout.isatty())
    if args.interface and not valid_interface_name(args.interface):
        print(ui.error(f"invalid interface name: {args.interface!r}"))
        return 2
    try:
        db = AlertDatabase(args.db or DB_PATH)
        bl = BlacklistManager(args.blacklist or BLACKLIST_PATH)
    except (DatabaseError, BlacklistError) as exc:
        print(ui.error(str(exc)))
        return 2
    app = App(cfg, db, bl, input_fn=input_fn)
    try:
        if args.list_interfaces:
            names = list_interfaces()
            print("\n".join(names) if names else "No interfaces found.")
            return 0
        if args.history:
            app.say(ui.table(app._alert_rows(db.recent_alerts(50)), app.HEAD))
            return 0
        if args.search:
            app.search_ip(args.search)
            return 0
        if args.report_session is not None:
            app.generate_report(args.report_session)
            return 0
        if args.monitor or args.pcap:
            s = app.monitor(interface=args.interface, bpf=args.bpf, duration=args.duration, mode=args.mode,
                            pcap=args.pcap, authorized=args.yes, report=args.report)
            return 0 if s is not None and s.status != "ERROR" else 1
        app.menu()
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
