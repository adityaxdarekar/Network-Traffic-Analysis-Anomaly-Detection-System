"""
report_generator.py - HTML security monitoring report + JSON alert export.

The report is built from a session row and its alerts (from the database or
from a running MonitorSession). Every value inserted into the HTML is
escaped, because alert fields contain attacker-controlled text such as DNS
query names.
"""
from __future__ import annotations

import html
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

from alert_manager import RECOMMENDATIONS
from config_loader import REPORT_HTML_DIR, REPORT_JSON_DIR

TITLE = "Mini Intrusion Detection System (IDS) - Security Monitoring Report"
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
PROTOCOLS = ("TCP", "UDP", "ICMP", "ARP", "DNS", "OTHER")
SEV_COLORS = {"CRITICAL": "#b91c1c", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#2563eb"}


def build_report(session: dict, alerts: list[dict]) -> dict:
    """Combine a session record and its alerts into one report dictionary."""
    protocols = {p: int(session.get(p.lower(), 0) or 0) for p in PROTOCOLS}
    sev = Counter(a["severity"] for a in alerts)
    cats = Counter(a["category"] for a in alerts)
    sources = Counter(a["source_ip"] for a in alerts if a.get("source_ip"))
    source_rows = []
    for ip, n in sources.most_common():
        mine = [a for a in alerts if a.get("source_ip") == ip]
        worst = max(mine, key=lambda a: SEVERITIES[::-1].index(a["severity"]))["severity"]
        source_rows.append({"source_ip": ip, "alerts": n, "highest_severity": worst,
                            "categories": sorted({a["category"] for a in mine})})
    actions = [{"category": c, "action": RECOMMENDATIONS.get(c, "Investigate the activity.")}
               for c in sorted(cats, key=lambda c: -cats[c])]
    return {
        "title": TITLE,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "session": {
            "id": session.get("id"), "interface": session.get("interface"),
            "source": session.get("source"), "bpf_filter": session.get("bpf_filter") or "",
            "start": session.get("started"), "end": session.get("ended"),
        },
        "total_packets": int(session.get("total_packets", 0) or 0),
        "total_bytes": int(session.get("total_bytes", 0) or 0),
        "dropped_packets": int(session.get("dropped", 0) or 0),
        "protocol_distribution": protocols,
        "total_alerts": len(alerts),
        "alerts_by_severity": {s: sev.get(s, 0) for s in SEVERITIES},
        "alerts_by_category": dict(cats.most_common()),
        "alert_sources": source_rows,
        "recommended_actions": actions,
        "alerts": alerts,
        "note": ("Detections are heuristic indicators produced from observed traffic and configured "
                 "thresholds. They require analyst verification and are not proof of an attack."),
    }


def _e(value) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def to_html(report: dict) -> str:
    s = report["session"]
    total = max(report["total_packets"], 1)
    proto_rows = "".join(
        f"<tr><td>{_e(p)}</td><td class='num'>{n}</td><td><div class='bar'><span style='width:"
        f"{n * 100 / total:.1f}%'></span></div></td><td class='num'>{n * 100 / total:.1f}%</td></tr>"
        for p, n in report["protocol_distribution"].items())
    sev_cards = "".join(
        f"<div class='card' style='border-top-color:{SEV_COLORS[k]}'><div class='big'>{v}</div>{k}</div>"
        for k, v in report["alerts_by_severity"].items())
    cat_rows = "".join(f"<tr><td>{_e(c)}</td><td class='num'>{n}</td></tr>"
                       for c, n in report["alerts_by_category"].items()) or \
        "<tr><td colspan='2'>No suspicious activity detected.</td></tr>"
    alert_rows = "".join(
        f"<tr><td>{_e(a['alert_id'])}</td><td>{_e(a['timestamp'])}</td>"
        f"<td><span class='sev' style='background:{SEV_COLORS.get(a['severity'], '#555')}'>{_e(a['severity'])}</span></td>"
        f"<td>{_e(a['category'])}</td><td>{_e(a.get('source_ip') or '-')}</td>"
        f"<td>{_e(a.get('destination_ip') or '-')}</td>"
        f"<td><b>{_e(a.get('title'))}</b><br>{_e(a.get('description'))}"
        f"<div class='muted'>Rule: {_e(a.get('rule'))} &middot; occurrences: {_e(a.get('occurrences', 1))}</div></td></tr>"
        for a in report["alerts"]) or "<tr><td colspan='7'>No alerts were generated.</td></tr>"
    src_rows = "".join(
        f"<tr><td>{_e(r['source_ip'])}</td><td class='num'>{r['alerts']}</td><td>{_e(r['highest_severity'])}</td>"
        f"<td>{_e(', '.join(r['categories']))}</td></tr>" for r in report["alert_sources"]) or \
        "<tr><td colspan='4'>None.</td></tr>"
    act_rows = "".join(f"<li><b>{_e(a['category'])}:</b> {_e(a['action'])}</li>"
                       for a in report["recommended_actions"]) or \
        "<li>No action required. Keep monitoring and review thresholds for your network.</li>"
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mini IDS Report</title>
<style>
body{{font-family:Segoe UI,Helvetica,Arial,sans-serif;margin:0;background:#f4f6f9;color:#1f2937}}
header{{background:#0f172a;color:#fff;padding:24px 32px}} header h1{{margin:0;font-size:22px}}
main{{max-width:1100px;margin:auto;padding:24px}} section{{background:#fff;border-radius:8px;padding:18px 22px;
margin-bottom:18px;box-shadow:0 1px 3px rgba(0,0,0,.08)}} h2{{font-size:17px;margin:0 0 12px}}
table{{width:100%;border-collapse:collapse;font-size:14px}} th,td{{text-align:left;padding:7px 8px;
border-bottom:1px solid #e5e7eb;vertical-align:top}} th{{background:#f9fafb}} .num{{text-align:right}}
.cards{{display:flex;gap:12px;flex-wrap:wrap}} .card{{flex:1;min-width:110px;background:#f9fafb;border-top:4px solid;
border-radius:6px;padding:12px;text-align:center;font-weight:600}} .big{{font-size:28px}}
.bar{{background:#e5e7eb;border-radius:4px;height:12px;min-width:120px}} .bar span{{display:block;height:12px;
background:#2563eb;border-radius:4px}} .sev{{color:#fff;padding:2px 7px;border-radius:4px;font-size:12px;font-weight:700}}
.muted{{color:#6b7280;font-size:12px;margin-top:4px}} .note{{background:#fffbeb;border-left:4px solid #ca8a04}}
</style></head><body>
<header><h1>{_e(report['title'])}</h1><div>Generated {_e(report['generated'])}</div></header>
<main>
<section><h2>1. Monitoring session</h2><table>
<tr><th>Session</th><td>{_e(s['id'])} ({_e(s['source'])})</td></tr>
<tr><th>Network interface</th><td>{_e(s['interface'])}</td></tr>
<tr><th>Capture filter</th><td>{_e(s['bpf_filter'] or 'none')}</td></tr>
<tr><th>Monitoring start</th><td>{_e(s['start'])}</td></tr>
<tr><th>Monitoring end</th><td>{_e(s['end'] or 'still running')}</td></tr>
<tr><th>Total packets captured</th><td>{report['total_packets']} ({report['total_bytes']} bytes,
 {report['dropped_packets']} dropped)</td></tr></table></section>
<section><h2>2. Protocol distribution</h2><table><tr><th>Protocol</th><th class='num'>Packets</th><th></th>
<th class='num'>Share</th></tr>{proto_rows}</table></section>
<section><h2>3. Security alerts by severity (total {report['total_alerts']})</h2><div class='cards'>{sev_cards}</div></section>
<section><h2>4. Detected suspicious activities</h2><table><tr><th>Category</th><th class='num'>Alerts</th></tr>
{cat_rows}</table></section>
<section><h2>5. Source IP addresses associated with alerts</h2><table><tr><th>Source IP</th><th class='num'>Alerts</th>
<th>Highest severity</th><th>Categories</th></tr>{src_rows}</table></section>
<section><h2>6. Alert details</h2><table><tr><th>ID</th><th>Time</th><th>Severity</th><th>Category</th>
<th>Source</th><th>Destination</th><th>Description</th></tr>{alert_rows}</table></section>
<section><h2>7. Recommended security actions</h2><ul>{act_rows}</ul></section>
<section class='note'><b>Note.</b> {_e(report['note'])}</section>
</main></body></html>"""


def to_json(report: dict) -> str:
    return json.dumps(report, indent=2, default=str)


def save_report(report: dict, html_dir: Path = REPORT_HTML_DIR, json_dir: Path = REPORT_JSON_DIR) -> tuple[Path, Path]:
    html_dir, json_dir = Path(html_dir), Path(json_dir)
    html_dir.mkdir(parents=True, exist_ok=True)
    json_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    sid = report["session"].get("id") or 0
    hp = html_dir / f"ids_report_session{sid}_{stamp}.html"
    jp = json_dir / f"ids_alerts_session{sid}_{stamp}.json"
    hp.write_text(to_html(report), encoding="utf-8")
    jp.write_text(to_json(report), encoding="utf-8")
    return hp, jp


def report_for_session(db, session_id: int) -> dict:
    session = db.session(session_id)
    if session is None:
        raise ValueError(f"session {session_id} not found")
    return build_report(session, db.alerts_for_session(session_id))
