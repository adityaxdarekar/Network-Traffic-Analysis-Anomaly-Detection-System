"""
ids_monitor.py - wires one monitoring session together.

    packet source --(callback)--> bounded queue --> processing thread
                                                    |  packet_analyzer.analyze_packet
                                                    |  TrafficStats.update
                                                    |  DetectionEngine.process
                                                    v  AlertManager.submit -> SQLite, display

The capture callback only puts packets in a bounded queue (it never blocks;
if the queue is full the packet is counted as dropped). All analysis runs
in a single processing thread, so the detection engine needs no locks.
"""
from __future__ import annotations

import queue
import threading
import time
from datetime import datetime
from typing import Optional

from alert_manager import Alert, AlertManager
from database import AlertDatabase
from detection_engine import DetectionEngine
from packet_analyzer import PacketInfo, TrafficStats, analyze_packet
from packet_capture import CaptureError, LiveCapture, PcapReplay, safe_label

_STOP = object()


class MonitorSession:
    def __init__(self, config: dict, blacklist, db: Optional[AlertDatabase], *,
                 source: str = "live", interface: Optional[str] = None, bpf_filter: Optional[str] = None,
                 pcap_path: Optional[str] = None):
        self.config = config
        self.db = db
        self.source_kind = source
        self.bpf_filter = config["bpf_filter"] if bpf_filter is None else bpf_filter
        self.stats = TrafficStats()
        self.engine = DetectionEngine(config, blacklist)
        self.queue: queue.Queue = queue.Queue(maxsize=config["capture"]["queue_size"])
        self.status = "STOPPED"
        self.started_at: Optional[datetime] = None
        self.ended_at: Optional[datetime] = None
        self.errors: list[str] = []
        self._worker: Optional[threading.Thread] = None
        self._stopped = threading.Event()
        self.new_alerts: "queue.Queue[Alert]" = queue.Queue()   # for the live display

        if source == "live":
            self.interface = interface or config["interface"]
            self.capture = LiveCapture(self.interface, self.bpf_filter, self._on_packet,
                                       promiscuous=config["capture"]["promiscuous"])
        elif source == "pcap":
            self.capture = PcapReplay(pcap_path, self._on_packet, self.bpf_filter)
            self.interface = self.capture.interface
        else:
            raise ValueError(f"unknown source {source!r}")
        self.interface = safe_label(self.interface)

        self.session_id = db.create_session(self.interface, source, self.bpf_filter) if db else None
        self.alerts = AlertManager(config, session_id=self.session_id)
        if db is not None:
            self.alerts.add_listener(self._save_alert)
        self.alerts.add_listener(lambda a, new: self.new_alerts.put(a) if new else None)

    # ------------------------------------------------------------- callbacks
    def _on_packet(self, pkt) -> None:
        """Called from the capture thread: must be fast and must not raise."""
        try:
            self.queue.put_nowait(pkt)
        except queue.Full:
            self.stats.add_dropped()

    def _save_alert(self, alert: Alert, _is_new: bool) -> None:
        try:
            self.db.save_alert(alert)
        except Exception as exc:
            self.errors.append(f"database: {exc}")

    # ------------------------------------------------------------ processing
    def _process_loop(self) -> None:
        last_flush = time.monotonic()
        while True:
            try:
                item = self.queue.get(timeout=0.5)
            except queue.Empty:
                item = None
            if item is _STOP:
                break
            if item is not None:
                self.process_one(item)
            if time.monotonic() - last_flush >= 2:
                self.alerts.flush()
                last_flush = time.monotonic()
        self.alerts.flush()

    def process_one(self, item) -> None:
        try:
            info = item if isinstance(item, PacketInfo) else analyze_packet(item)
        except Exception:
            self.stats.add_malformed()
            return
        if not info.timestamp:
            info.timestamp = time.time()
        self.stats.update(info)
        try:
            for detection in self.engine.process(info):
                self.alerts.submit(detection)
        except Exception as exc:          # one bad packet must not stop the IDS
            self.errors.append(f"detection error: {exc}")
            self.stats.add_malformed()

    # ------------------------------------------------------------- lifecycle
    def start(self) -> None:
        self.started_at = datetime.now()
        self._worker = threading.Thread(target=self._process_loop, name="ids-processing", daemon=True)
        self._worker.start()
        try:
            self.capture.start()
        except CaptureError:
            self.status = "ERROR"
            self.queue.put(_STOP)
            self._worker.join(timeout=5)
            self._finish()
            raise
        self.status = "RUNNING"

    def source_finished(self) -> bool:
        """True when a pcap replay has delivered all its packets."""
        return self.capture.finished.is_set() and self.queue.empty()

    def stop(self) -> None:
        if self._stopped.is_set():
            return
        self.status = "STOPPING"
        self.capture.stop()
        if self.capture.error:
            self.errors.append(self.capture.error)
        self.queue.put(_STOP)               # processed after any packets still queued
        if self._worker is not None:
            self._worker.join(timeout=30)
        self._finish()

    def _finish(self) -> None:
        self._stopped.set()
        self.ended_at = datetime.now()
        if self.status != "ERROR":
            self.status = "STOPPED"
        if self.db is not None and self.session_id is not None:
            try:
                self.db.finish_session(self.session_id, self.stats.snapshot(), self.alerts.counts()["total"],
                                       ended=self.ended_at.isoformat(timespec="seconds"))
            except Exception as exc:
                self.errors.append(f"database: {exc}")

    def run_until_finished(self, timeout: float = 600) -> None:
        """Blocking helper for pcap replay."""
        self.start()
        deadline = time.monotonic() + timeout
        while not self.source_finished() and time.monotonic() < deadline:
            time.sleep(0.05)
        self.stop()

    # ---------------------------------------------------------------- info
    def meta(self) -> dict:
        snap = self.stats.snapshot()
        def fmt(ts):
            return datetime.fromtimestamp(ts).isoformat(timespec="seconds") if ts else None
        return {"session_id": self.session_id, "interface": self.interface, "source": self.source_kind,
                "bpf_filter": self.bpf_filter, "status": self.status,
                "started": self.started_at.isoformat(timespec="seconds") if self.started_at else None,
                "ended": self.ended_at.isoformat(timespec="seconds") if self.ended_at else None,
                "first_packet": fmt(snap["first_ts"]), "last_packet": fmt(snap["last_ts"])}
