"""
ui.py - terminal presentation: banner, colours, tables and the live SOC dashboard.

colorama and tabulate are used when installed; plain-text fallbacks keep the
program working without them.
"""
from __future__ import annotations

import os
import sys
import textwrap

try:
    from colorama import Fore, Style, init as _colorama_init
    _colorama_init()
    _HAS_COLOR = True
except ImportError:            # pragma: no cover
    _HAS_COLOR = False

try:
    from tabulate import tabulate as _tabulate
except ImportError:            # pragma: no cover
    _tabulate = None

COLOR_ENABLED = _HAS_COLOR and sys.stdout.isatty()

BANNER = r"""
  __  __ _       _   ___ ____  ____
 |  \/  (_)_ __ (_) |_ _|  _ \/ ___|
 | |\/| | | '_ \| |  | || | | \___ \
 | |  | | | | | | |  | || |_| |___) |
 |_|  |_|_|_| |_|_| |___|____/|____/
   MINI INTRUSION DETECTION SYSTEM  -  Python + Scapy
   Monitor only networks you own or are authorised to monitor.
"""


def set_color(enabled: bool) -> None:
    global COLOR_ENABLED
    COLOR_ENABLED = bool(enabled) and _HAS_COLOR


def _c(text: str, color: str) -> str:
    if not COLOR_ENABLED:
        return text
    codes = {"red": Fore.RED, "green": Fore.GREEN, "yellow": Fore.YELLOW, "blue": Fore.BLUE,
             "cyan": Fore.CYAN, "magenta": Fore.MAGENTA, "white": Fore.WHITE,
             "bold": Style.BRIGHT, "dim": Style.DIM}
    return f"{codes.get(color, '')}{text}{Style.RESET_ALL}"


def red(t): return _c(t, "red")
def green(t): return _c(t, "green")
def yellow(t): return _c(t, "yellow")
def cyan(t): return _c(t, "cyan")
def bold(t): return _c(t, "bold")
def dim(t): return _c(t, "dim")


SEV_COLOR = {"CRITICAL": "magenta", "HIGH": "red", "MEDIUM": "yellow", "LOW": "blue"}


def sev(text: str) -> str:
    return _c(text, SEV_COLOR.get(text, "white"))


def banner() -> str:
    return cyan(BANNER)


def info(msg: str) -> str: return f"{cyan('[*]')} {msg}"
def ok(msg: str) -> str: return f"{green('[+]')} {msg}"
def warn(msg: str) -> str: return f"{yellow('[!]')} {msg}"
def error(msg: str) -> str: return f"{red('[x]')} {msg}"


def table(rows: list[list], headers: list[str]) -> str:
    if not rows:
        return dim("(no records)")
    if _tabulate:
        return _tabulate(rows, headers=headers, tablefmt="simple_grid")
    widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) for i, h in enumerate(headers)]
    line = "  ".join(str(h).ljust(w) for h, w in zip(headers, widths))
    body = "\n".join("  ".join(str(c).ljust(w) for c, w in zip(r, widths)) for r in rows)
    return f"{line}\n{'-' * len(line)}\n{body}"


def clear_screen() -> None:
    if sys.stdout.isatty():
        os.system("clear" if os.name != "nt" else "cls")   # fixed command, no user input


def _short(text, n):
    text = "" if text is None else str(text)
    return text if len(text) <= n else text[: n - 3] + "..."


def alert_block(a) -> str:
    """Multi-line alert notification (Alert object or dict)."""
    g = a.get if isinstance(a, dict) else lambda k, d=None: getattr(a, k, d)
    details = g("details") or {}
    lines = [f"{sev('[' + g('severity') + ']')} {bold(g('title') or g('category'))}  {dim(g('alert_id'))}",
             f"   Time: {g('timestamp')}   Source IP: {g('source_ip') or '-'}   Destination: {g('destination_ip') or '-'}"]
    shown = {"unique_ports": "Unique Ports", "time_window_seconds": "Time Window (s)", "syn_packets": "SYN Packets",
             "icmp_packets": "ICMP Packets", "dns_queries": "DNS Queries", "previous_mac": "Previous MAC",
             "new_mac": "New MAC", "domain": "Domain", "reason": "Blacklist Reason", "categories": "Categories",
             "unique_sources": "Unique Sources"}
    extra = [f"{label}: {details[k]}" for k, label in shown.items() if k in details]
    if extra:
        lines.append("   " + "   ".join(_short(x, 70) for x in extra))
    if (g("occurrences") or 1) > 1:
        lines.append(dim(f"   repeated {g('occurrences')} times (merged during cool-down)"))
    return "\n".join(lines)


def dashboard(meta: dict, stats: dict, counts: dict, alerts: list, width: int = 78) -> str:
    """Render the live SOC dashboard as a string."""
    p = stats["by_protocol"]
    status = meta.get("status", "?")
    status_txt = green(status) if status == "RUNNING" else yellow(status)
    out = [cyan("=" * width), bold("  MINI INTRUSION DETECTION SYSTEM - SOC DASHBOARD".center(width)),
           cyan("=" * width),
           f"  IDS Status: {status_txt}    Interface: {bold(str(meta.get('interface')))}    "
           f"Filter: {meta.get('bpf_filter') or 'none'}",
           f"  Started: {meta.get('started')}    Session: {meta.get('session_id')}", ""]
    traffic = [["Packets Captured", stats["total"]], ["TCP", p.get("TCP", 0)], ["UDP", p.get("UDP", 0)],
               ["ICMP", p.get("ICMP", 0)], ["ARP", p.get("ARP", 0)], ["DNS", p.get("DNS", 0)],
               ["Other", p.get("OTHER", 0) + p.get("ICMPv6", 0)], ["Dropped", stats.get("dropped", 0)]]
    alerts_tbl = [["Total Alerts", counts["total"]], [sev("CRITICAL"), counts["CRITICAL"]],
                  [sev("HIGH"), counts["HIGH"]], [sev("MEDIUM"), counts["MEDIUM"]],
                  [sev("LOW"), counts["LOW"]], ["Merged repeats", counts.get("suppressed_duplicates", 0)]]
    left = table(traffic, ["Traffic", "Count"]).splitlines()
    right = table(alerts_tbl, ["Alerts", "Count"]).splitlines()
    lw = max(len(_strip(x)) for x in left)
    for i in range(max(len(left), len(right))):
        l = left[i] if i < len(left) else ""
        r = right[i] if i < len(right) else ""
        out.append("  " + l + " " * (lw - len(_strip(l)) + 4) + r)
    out += ["", bold("  SECURITY ALERTS (latest first):")]
    if not alerts:
        out.append(dim("  No alerts yet."))
    for a in reversed(alerts):
        out.append(textwrap.indent(alert_block(a), "  "))
    out += ["", dim("  Press Ctrl+C to stop monitoring.")]
    return "\n".join(out)


def _strip(s: str) -> str:
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", s)
