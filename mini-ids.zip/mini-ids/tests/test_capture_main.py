"""Capture plumbing, monitoring session and menu - using the Scapy test double
with a handful of ordinary packets (web, DNS, ping, ARP)."""
import io

import pytest

import main as app_main
import packet_capture
from ids_monitor import MonitorSession
from packet_capture import CaptureError


def ordinary_packets(fs, t0=1000.0):
    return [
        fs.make(fs.Ether(), fs.IP(src="192.168.56.103", dst="192.168.56.10"), fs.TCP(dport=80, flags=0x02), time=t0),
        fs.make(fs.Ether(), fs.IP(src="192.168.56.10", dst="192.168.56.103"), fs.TCP(sport=80, flags=0x12), time=t0 + .01),
        fs.make(fs.Ether(), fs.IP(src="192.168.56.103", dst="192.168.56.1"), fs.UDP(dport=53),
                fs.DNS(qr=0, qd=[fs.DNSQR(qname=b"www.example.com.")]), time=t0 + .1),
        fs.make(fs.Ether(), fs.IP(src="192.168.56.103", dst="192.168.56.10"), fs.ICMP(type=8), time=t0 + .2),
        fs.make(fs.Ether(), fs.IP(src="192.168.56.10", dst="192.168.56.103"), fs.ICMP(type=0), time=t0 + .21),
        fs.make(fs.Ether(), fs.ARP(op=2, psrc="192.168.56.1", hwsrc="0a:00:27:00:00:01"), time=t0 + .3),
        fs.make(fs.Ether(), time=t0 + .4),
    ]


def test_pcap_replay_counts_protocols_without_alerts(cfg, blacklist, db, fake_scapy, tmp_path):
    f = tmp_path / "normal.pcap"
    f.write_bytes(b"x")
    fake_scapy.OFFLINE_FILES[str(f)] = ordinary_packets(fake_scapy)
    s = MonitorSession(cfg, blacklist, db, source="pcap", pcap_path=str(f))
    s.run_until_finished(timeout=10)
    snap = s.stats.snapshot()
    assert snap["total"] == 7
    assert snap["by_protocol"] == {"TCP": 2, "UDP": 0, "ICMP": 2, "ARP": 1, "DNS": 1, "ICMPv6": 0, "OTHER": 1}
    assert s.alerts.counts()["total"] == 0
    row = db.session(s.session_id)
    assert row["total_packets"] == 7 and row["source"] == "pcap" and row["ended"]


def test_blacklisted_source_generates_alert(cfg, blacklist, db, fake_scapy, tmp_path):
    fs = fake_scapy
    f = tmp_path / "bl.pcap"
    f.write_bytes(b"x")
    fs.OFFLINE_FILES[str(f)] = [fs.make(fs.IP(src="203.0.113.50", dst="192.168.56.10"), fs.ICMP(type=8),
                                        time=2000 + i) for i in range(3)]
    s = MonitorSession(cfg, blacklist, db, source="pcap", pcap_path=str(f))
    s.run_until_finished(timeout=10)
    alerts = db.alerts_for_session(s.session_id)
    assert len(alerts) == 1                                  # repeats merged by the cool-down
    a = alerts[0]
    assert a["category"] == "Blacklisted IP" and a["severity"] == "HIGH" and a["occurrences"] == 3
    assert "TEST-NET-3" in a["details"]["reason"] and a["recommended_action"]


def test_malformed_packet_is_counted_not_fatal(cfg, blacklist, fake_scapy, tmp_path):
    f = tmp_path / "m.pcap"
    f.write_bytes(b"x")
    fake_scapy.OFFLINE_FILES[str(f)] = [object()] + ordinary_packets(fake_scapy)[:1]
    s = MonitorSession(cfg, blacklist, None, source="pcap", pcap_path=str(f))
    s.run_until_finished(timeout=10)
    snap = s.stats.snapshot()
    assert snap["malformed"] == 1 and snap["total"] == 1


def test_live_capture_start_stop(cfg, blacklist, db, fake_scapy, monkeypatch):
    monkeypatch.setattr(packet_capture, "has_capture_privileges", lambda: True)
    fake_scapy.AsyncSniffer.FEED = ordinary_packets(fake_scapy)
    s = MonitorSession(cfg, blacklist, db, source="live", interface="eth0", bpf_filter="tcp or arp")
    s.start()
    assert s.status == "RUNNING"
    kw = fake_scapy.AsyncSniffer.last.kwargs
    assert kw["iface"] == "eth0" and kw["filter"] == "tcp or arp" and kw["store"] is False
    import time
    for _ in range(100):
        if s.stats.snapshot()["total"] == 7:
            break
        time.sleep(0.02)
    s.stop()
    assert s.status == "STOPPED" and db.session(s.session_id)["total_packets"] == 7


def test_live_capture_errors(cfg, blacklist, fake_scapy, monkeypatch):
    monkeypatch.setattr(packet_capture, "has_capture_privileges", lambda: False)
    with pytest.raises(CaptureError, match="CAP_NET_RAW"):
        MonitorSession(cfg, blacklist, None, source="live", interface="eth0").start()
    monkeypatch.setattr(packet_capture, "has_capture_privileges", lambda: True)
    with pytest.raises(CaptureError, match="not found"):
        MonitorSession(cfg, blacklist, None, source="live", interface="wlan9").start()
    import sys
    sys.modules["scapy.all"].conf.l2listen_error = PermissionError("Operation not permitted")
    with pytest.raises(CaptureError, match="permission denied"):
        MonitorSession(cfg, blacklist, None, source="live", interface="eth0").start()
    sys.modules["scapy.all"].conf.l2listen_error = None


def test_queue_full_counts_dropped(cfg, blacklist):
    cfg["capture"]["queue_size"] = 100
    s = MonitorSession(cfg, blacklist, None, source="pcap", pcap_path="none.pcap")
    for _ in range(105):
        s._on_packet(object())
    assert s.stats.snapshot()["dropped"] == 5


# ---------------------------------------------------------------- main/menu
def scripted(answers):
    it = iter(answers)
    return lambda prompt="": next(it)


def test_cli_pcap_with_report(cfg, fake_scapy, tmp_path, monkeypatch, capsys):
    f = tmp_path / "n.pcap"
    f.write_bytes(b"x")
    fake_scapy.OFFLINE_FILES[str(f)] = ordinary_packets(fake_scapy)
    monkeypatch.setattr("report_generator.REPORT_HTML_DIR", tmp_path / "html")
    import report_generator
    monkeypatch.setattr(report_generator.save_report, "__defaults__", (tmp_path / "html", tmp_path / "json"))
    cfgfile = tmp_path / "c.json"
    cfgfile.write_text('{"display": {"refresh_seconds": 0.2}}')
    bl = tmp_path / "bl.json"
    bl.write_text('{"entries": []}')
    rc = app_main.main(["--config", str(cfgfile), "--pcap", str(f), "--report", "--mode", "packets",
                        "--db", str(tmp_path / "db.sqlite"), "--blacklist", str(bl), "--no-color"])
    out = capsys.readouterr().out
    assert rc == 0 and "Session summary" in out and "HTML report" in out
    assert list((tmp_path / "html").glob("*.html")) and list((tmp_path / "json").glob("*.json"))


def test_menu_walkthrough(cfg, blacklist, db, monkeypatch):
    out = io.StringIO()
    answers = ["2",                      # active alerts (none yet)
               "5", "2", "192.0.2.99", "Lab test entry", "1", "3", "192.0.2.99", "9", "4",
               "4", "999.1.1.1",          # invalid IP search
               "3", "LOW",                # history filtered
               "6",                       # report with no sessions
               "7",                       # statistics
               "x",                       # invalid choice
               "1", "eth0", "", "1", "0", "no",   # start monitoring -> refuse authorisation
               "8"]
    app = app_main.App(cfg, db, blacklist, input_fn=scripted(answers), out=out)
    app.menu()
    text = out.getvalue()
    for expected in ("MAIN MENU", "No monitoring sessions yet", "Added 192.0.2.99", "Removed",
                     "Invalid IP address", "Choose 1-4", "No monitoring sessions to report on",
                     "All stored sessions", "Please choose a number", "Monitoring cancelled", "Goodbye"):
        assert expected in text, expected
    assert blacklist.lookup("192.0.2.99") is None


def test_cli_rejects_bad_config_and_interface(tmp_path, capsys):
    bad = tmp_path / "c.json"
    bad.write_text('{"rules": {"port_scan": {"unique_ports": 0}}}')
    assert app_main.main(["--config", str(bad)]) == 2
    assert app_main.main(["--interface", "eth0;reboot", "--db", str(tmp_path / "d.db")]) == 2
    assert "invalid" in capsys.readouterr().out
