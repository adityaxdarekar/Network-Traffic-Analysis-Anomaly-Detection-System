"""
TEST DOUBLE for the parts of Scapy that the IDS uses.

Scapy could not be installed in the build environment, so the tests install
these small stand-in modules in sys.modules. They copy Scapy's interface as
the IDS uses it: layer stacking with "/", pkt.haslayer(Layer), pkt[Layer],
len(pkt), pkt.time, field names (src, dst, sport, dport, flags, op, psrc,
hwsrc, pdst, qr, qd, qname), AsyncSniffer, sniff(offline=...), conf.L2listen
and get_if_list. Passing tests here does NOT prove compatibility with real
Scapy - see PROJECT_STATUS.md.
"""
from __future__ import annotations

import sys
import threading
import types


class Layer:
    defaults: dict = {}

    def __init__(self, **fields):
        self.fields = {**self.defaults, **fields}
        self.payload = None
        self.time = 0.0
        self._len = 60

    def __getattr__(self, name):
        fields = self.__dict__.get("fields", {})
        if name in fields:
            return fields[name]
        raise AttributeError(name)

    def __truediv__(self, other):
        tail = self
        while tail.payload is not None:
            tail = tail.payload
        tail.payload = other
        return self

    def _walk(self):
        layer = self
        while layer is not None:
            yield layer
            layer = layer.payload

    def haslayer(self, cls):
        return any(isinstance(l, cls) for l in self._walk())

    def __getitem__(self, cls):
        for l in self._walk():
            if isinstance(l, cls):
                return l
        raise IndexError(cls.__name__)

    def __len__(self):
        return self._len


class Ether(Layer): defaults = {"src": "08:00:27:00:00:aa", "dst": "ff:ff:ff:ff:ff:ff"}
class IP(Layer): defaults = {"src": "192.168.56.1", "dst": "192.168.56.10"}
class IPv6(Layer): defaults = {"src": "fe80::1", "dst": "fe80::2", "nh": 6}
class TCP(Layer): defaults = {"sport": 40000, "dport": 80, "flags": 0x02}
class UDP(Layer): defaults = {"sport": 40000, "dport": 53}
class ICMP(Layer): defaults = {"type": 8, "code": 0}
class ARP(Layer): defaults = {"op": 2, "psrc": "192.168.56.1", "hwsrc": "0a:00:27:00:00:01", "pdst": "192.168.56.10"}
class DNS(Layer): defaults = {"qr": 0, "qd": None}
class DNSQR(Layer): defaults = {"qname": b"www.example.com."}


def make(*layers, time=1000.0, length=60):
    pkt = layers[0]
    for l in layers[1:]:
        pkt = pkt / l
    pkt.time = time
    pkt._len = length
    return pkt


class _Conf:
    iface = "eth0"
    l2listen_error: Exception | None = None

    def L2listen(self, **kw):
        if self.l2listen_error is not None:
            raise self.l2listen_error
        return types.SimpleNamespace(close=lambda: None)


class AsyncSniffer:
    """Delivers the packets in FEED to prn from a background thread, then idles until stop()."""
    FEED: list = []
    last = None

    def __init__(self, **kw):
        self.kwargs = kw
        self.thread = None
        self._stop = threading.Event()
        AsyncSniffer.last = self

    def _run(self):
        for p in list(self.FEED):
            self.kwargs["prn"](p)
        self._stop.wait()

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self._stop.set()
        self.thread.join(2)


def install(monkeypatch, interfaces=("lo", "eth0")):
    """Register the fake modules; returns the fake 'scapy.all' module."""
    conf = _Conf()
    offline: dict = {}

    def sniff(offline=None, prn=None, store=False, filter=None, stop_filter=None, **kw):
        for p in OFFLINE_FILES.get(offline, []):
            prn(p)
            if stop_filter and stop_filter(p):
                break

    mods = {
        "scapy": types.ModuleType("scapy"),
        "scapy.layers": types.ModuleType("scapy.layers"),
        "scapy.layers.inet": types.ModuleType("scapy.layers.inet"),
        "scapy.layers.inet6": types.ModuleType("scapy.layers.inet6"),
        "scapy.layers.l2": types.ModuleType("scapy.layers.l2"),
        "scapy.layers.dns": types.ModuleType("scapy.layers.dns"),
        "scapy.all": types.ModuleType("scapy.all"),
    }
    mods["scapy.layers.inet"].__dict__.update(IP=IP, TCP=TCP, UDP=UDP, ICMP=ICMP)
    mods["scapy.layers.inet6"].IPv6 = IPv6
    mods["scapy.layers.l2"].__dict__.update(ARP=ARP, Ether=Ether)
    mods["scapy.layers.dns"].__dict__.update(DNS=DNS, DNSQR=DNSQR)
    mods["scapy.all"].__dict__.update(conf=conf, AsyncSniffer=AsyncSniffer, sniff=sniff,
                                      get_if_list=lambda: list(interfaces))
    for name, mod in mods.items():
        monkeypatch.setitem(sys.modules, name, mod)
    AsyncSniffer.FEED = []
    OFFLINE_FILES.clear()
    import packet_analyzer
    packet_analyzer.reset_layer_cache()
    return mods["scapy.all"]


OFFLINE_FILES: dict = {}       # path -> list of fake packets returned by sniff(offline=path)
