import copy
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config_loader import load_config            # noqa: E402

BASE_CFG = load_config(ROOT / "config.json")


@pytest.fixture
def cfg():
    return copy.deepcopy(BASE_CFG)


@pytest.fixture
def fake_scapy(monkeypatch):
    from tests import fake_scapy as fs
    fs.install(monkeypatch)
    yield fs
    import packet_analyzer
    packet_analyzer.reset_layer_cache()


@pytest.fixture
def blacklist(tmp_path):
    from blacklist_manager import BlacklistManager
    p = tmp_path / "blacklist.json"
    p.write_text((ROOT / "blacklist.json").read_text())
    return BlacklistManager(p)


@pytest.fixture
def db(tmp_path):
    from database import AlertDatabase
    d = AlertDatabase(tmp_path / "ids.db")
    yield d
    d.close()
