import json

import pytest

from alert_manager import AlertManager
from blacklist_manager import BlacklistError, BlacklistManager
from detection_engine import Detection
from report_generator import build_report, report_for_session, save_report, to_html


def det(ts, rule="TEST_RULE", category="Blacklisted IP", sev="HIGH", src="192.168.56.103", value=1):
    return Detection(rule=rule, category=category, severity=sev, title="Test alert", description="unit test",
                     timestamp=ts, src_ip=src, dst_ip="192.168.56.10", details={"value": value},
                     dedupe_key=(rule, src), peak_fields=("value",))


# --------------------------------------------------------------- blacklist
def test_blacklist_lookup_exact_and_network(blacklist):
    assert blacklist.lookup("203.0.113.50")["reason"].startswith("Lab test entry")
    assert blacklist.lookup("198.51.100.77")["ip"] == "198.51.100.0/24"
    assert blacklist.lookup("192.168.56.103") is None
    assert blacklist.lookup("not-an-ip") is None and blacklist.lookup(None) is None


def test_blacklist_add_remove_persist(blacklist):
    blacklist.add("192.0.2.25", "  documentation   address  ")
    again = BlacklistManager(blacklist.path)
    assert again.lookup("192.0.2.25")["reason"] == "documentation address"
    assert again.remove("192.0.2.25") and not again.remove("192.0.2.25")
    assert BlacklistManager(blacklist.path).lookup("192.0.2.25") is None


def test_blacklist_rejects_bad_input(blacklist, tmp_path):
    for bad in ("", "300.1.1.1", "abc", "10.0.0.0/4"):
        with pytest.raises(BlacklistError):
            blacklist.add(bad, "x")
    p = tmp_path / "bad.json"
    p.write_text("{not json")
    with pytest.raises(BlacklistError):
        BlacklistManager(p)


# ------------------------------------------------------------ alert manager
def test_cooldown_merges_repeats_and_flushes(cfg):
    am = AlertManager(cfg, session_id=7)
    seen = []
    am.add_listener(lambda a, new: seen.append((a.alert_id, new, a.occurrences)))
    first = am.submit(det(100, value=3))
    assert first.alert_id == "IDS-0007-00001" and first.recommended_action
    assert am.submit(det(110, value=9)) is None            # inside the 60 s cool-down
    assert first.occurrences == 2 and first.details["value"] == 9
    assert am.flush() == 1 and seen[-1] == (first.alert_id, False, 2)
    assert am.submit(det(200)) is not None                 # after the cool-down
    c = am.counts()
    assert c["total"] == 2 and c["HIGH"] == 2 and c["suppressed_duplicates"] == 1


def test_listener_error_does_not_break_alerting(cfg, capsys):
    am = AlertManager(cfg)
    am.add_listener(lambda a, n: 1 / 0)
    assert am.submit(det(1)) is not None
    assert "listener error" in capsys.readouterr().out


# ------------------------------------------------------- database + reports
def test_database_round_trip(cfg, db):
    sid = db.create_session("eth0", "live", "tcp or arp")
    am = AlertManager(cfg, session_id=sid)
    am.add_listener(lambda a, n: db.save_alert(a))
    am.submit(det(100, sev="HIGH"))
    am.submit(det(100, rule="OTHER", category="Suspicious DNS Activity", sev="MEDIUM", src="192.168.56.104"))
    am.submit(det(105, value=5))
    am.flush()
    db.finish_session(sid, {"total": 10, "bytes": 900, "by_protocol": {"TCP": 6, "DNS": 2, "ARP": 2}},
                      am.counts()["total"])
    s = db.session(sid)
    assert s["total_packets"] == 10 and s["tcp"] == 6 and s["alert_count"] == 2 and s["ended"]
    assert len(db.search_by_ip("192.168.56.104")) == 1
    assert len(db.search_by_ip("192.168.56.10")) == 2          # matches destination too
    assert db.by_severity("medium")[0]["category"] == "Suspicious DNS Activity"
    stored = [a for a in db.alerts_for_session(sid) if a["rule"] == "TEST_RULE"][0]
    assert stored["occurrences"] == 2 and stored["details"]["value"] == 5
    t = db.totals()
    assert t["total_alerts"] == 2 and t["by_severity"]["HIGH"] == 1 and t["sessions"] == 1
    with pytest.raises(ValueError):
        db.search_by_ip("1.2.3.4' OR '1'='1")
    with pytest.raises(ValueError):
        db.history(severity="URGENT")


def test_report_contents_and_escaping(cfg, db, tmp_path):
    sid = db.create_session("eth0", "live")
    am = AlertManager(cfg, session_id=sid)
    am.add_listener(lambda a, n: db.save_alert(a))
    d = det(100)
    d.description = "<script>alert(1)</script>"
    am.submit(d)
    db.finish_session(sid, {"total": 4, "bytes": 400, "by_protocol": {"TCP": 2, "ICMP": 2}}, 1)
    rep = report_for_session(db, sid)
    assert rep["total_packets"] == 4 and rep["alerts_by_severity"]["HIGH"] == 1
    assert rep["protocol_distribution"]["ICMP"] == 2
    assert rep["alert_sources"][0]["source_ip"] == "192.168.56.103"
    assert rep["recommended_actions"][0]["category"] == "Blacklisted IP"
    page = to_html(rep)
    assert "<script>alert(1)</script>" not in page and "&lt;script&gt;" in page
    for heading in ("Monitoring session", "Protocol distribution", "Recommended security actions"):
        assert heading in page
    h, j = save_report(rep, tmp_path / "h", tmp_path / "j")
    assert h.exists() and json.loads(j.read_text())["total_alerts"] == 1


def test_empty_report():
    rep = build_report({"id": 1, "interface": "eth0", "source": "live", "started": "x"}, [])
    assert "No alerts were generated" in to_html(rep)
