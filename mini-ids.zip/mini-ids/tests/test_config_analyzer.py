import json

import pytest

from config_loader import ConfigError, load_config, validate_bpf
from packet_analyzer import PacketInfo, TrafficStats, analyze_packet


# ------------------------------------------------------------------ config
def test_shipped_config_is_valid(cfg):
    assert cfg["rules"]["port_scan"]["unique_ports"] == 15
    assert cfg["rules"]["syn_flood"]["syn_packets"] == 100
    assert cfg["rules"]["icmp_flood"]["severity"] == "MEDIUM"
    assert cfg["rules"]["dns"]["excessive_queries"] == 100


def test_partial_config_is_merged_with_defaults(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"rules": {"port_scan": {"unique_ports": 30}}}))
    c = load_config(p)
    assert c["rules"]["port_scan"]["unique_ports"] == 30
    assert c["rules"]["port_scan"]["window_seconds"] == 10


def test_all_invalid_values_are_reported(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"interface": "eth0; rm -rf /",
                             "rules": {"port_scan": {"unique_ports": -1, "severity": "SEVERE"},
                                       "icmp_flood": {"enabled": "yes"},
                                       "arp_spoof": {"static_mappings": {"999.1.1.1": "zz"}}},
                             "engine": {"trusted_sources": ["not-an-ip"]}}))
    with pytest.raises(ConfigError) as e:
        load_config(p)
    msg = str(e.value)
    for part in ("interface", "unique_ports", "severity", "icmp_flood.enabled", "static_mappings", "trusted_sources"):
        assert part in msg


def test_bad_json_and_bpf(tmp_path):
    p = tmp_path / "c.json"
    p.write_text("{ broken")
    with pytest.raises(ConfigError, match="not valid JSON"):
        load_config(p)
    assert validate_bpf(" tcp or arp ") == "tcp or arp"
    with pytest.raises(ConfigError):
        validate_bpf("tcp\nport 80")
    with pytest.raises(ConfigError):
        validate_bpf("x" * 600)


def test_static_mac_normalised(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"rules": {"arp_spoof": {"static_mappings": {"192.168.56.1": "0A-00-27-00-00-01"}}}}))
    assert load_config(p)["rules"]["arp_spoof"]["static_mappings"] == {"192.168.56.1": "0a:00:27:00:00:01"}


# ---------------------------------------------------------------- analyzer
def test_tcp_packet(fake_scapy):
    fs = fake_scapy
    p = analyze_packet(fs.make(fs.Ether(), fs.IP(src="192.168.56.102", dst="192.168.56.10"),
                               fs.TCP(sport=51000, dport=22, flags=0x02), time=1700.5, length=74))
    assert (p.protocol, p.src_ip, p.dst_ip, p.src_port, p.dst_port, p.length) == \
        ("TCP", "192.168.56.102", "192.168.56.10", 51000, 22, 74)
    assert p.is_syn and p.flag_string() == "S" and p.timestamp == 1700.5
    synack = analyze_packet(fs.make(fs.IP(), fs.TCP(flags=0x12)))
    assert not synack.is_syn


def test_udp_icmp_arp(fake_scapy):
    fs = fake_scapy
    u = analyze_packet(fs.make(fs.IP(), fs.UDP(sport=123, dport=123)))
    assert u.protocol == "UDP" and u.dst_port == 123
    i = analyze_packet(fs.make(fs.IP(src="192.168.56.103"), fs.ICMP(type=8, code=0)))
    assert i.protocol == "ICMP" and i.icmp_type == 8 and i.src_port is None
    a = analyze_packet(fs.make(fs.Ether(src="0A:00:27:00:00:01"),
                               fs.ARP(op=2, psrc="192.168.56.1", hwsrc="0A:00:27:00:00:01", pdst="192.168.56.10")))
    assert a.protocol == "ARP" and a.arp_op == 2 and a.arp_src_mac == "0a:00:27:00:00:01"
    assert a.src_mac == "0a:00:27:00:00:01" and a.arp_dst_ip == "192.168.56.10"


def test_icmp_error_quoting_tcp_is_icmp(fake_scapy):
    fs = fake_scapy
    p = analyze_packet(fs.make(fs.IP(), fs.ICMP(type=3, code=3), fs.TCP()))
    assert p.protocol == "ICMP" and p.tcp_flags is None


def test_dns_new_and_old_scapy_question_format(fake_scapy):
    fs = fake_scapy
    new = analyze_packet(fs.make(fs.IP(), fs.UDP(dport=53),
                                 fs.DNS(qr=0, qd=[fs.DNSQR(qname=b"WWW.Example.COM.")])))
    old = analyze_packet(fs.make(fs.IP(), fs.UDP(dport=53), fs.DNS(qr=1, qd=fs.DNSQR(qname=b"mail.example.org."))))
    assert new.protocol == "DNS" and new.dns_qname == "www.example.com" and new.is_dns_query
    assert old.dns_qname == "mail.example.org" and old.dns_qr == 1 and not old.is_dns_query
    empty = analyze_packet(fs.make(fs.IP(), fs.UDP(dport=53), fs.DNS(qr=0, qd=[])))
    assert empty.protocol == "DNS" and empty.dns_qname is None


def test_ipv6_and_other(fake_scapy):
    fs = fake_scapy
    p = analyze_packet(fs.make(fs.IPv6(src="fe80::a", dst="fe80::b", nh=6), fs.TCP(dport=443)))
    assert p.protocol == "TCP" and p.src_ip == "fe80::a"
    v6icmp = analyze_packet(fs.make(fs.IPv6(nh=58)))
    assert v6icmp.protocol == "ICMPv6"
    other = analyze_packet(fs.make(fs.Ether()))
    assert other.protocol == "OTHER" and other.src_ip is None


def test_summary_lines():
    p = PacketInfo(timestamp=1700000000, length=60, protocol="TCP", transport="TCP", src_ip="10.0.0.1",
                   dst_ip="10.0.0.2", src_port=1, dst_port=2, tcp_flags=0x12)
    assert "10.0.0.1:1 -> 10.0.0.2:2 [SA]" in p.summary()


def test_traffic_stats_counts_and_recent():
    s = TrafficStats()
    for proto in ("TCP", "TCP", "DNS", "ARP", "WEIRD"):
        s.update(PacketInfo(timestamp=10, length=50, protocol=proto))
    snap = s.snapshot()
    assert snap["total"] == 5 and snap["bytes"] == 250
    assert snap["by_protocol"]["TCP"] == 2 and snap["by_protocol"]["OTHER"] == 1
    seq, pkts, missed = s.recent_since(3)
    assert seq == 5 and len(pkts) == 2 and missed == 0
