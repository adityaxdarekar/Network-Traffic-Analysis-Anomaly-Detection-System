# Mini Intrusion Detection System (IDS) Using Python and Scapy
### College project report

## 1. Abstract
This project implements a lightweight network-based intrusion detection system (NIDS) in Python. Packets are captured from a network interface with the Scapy library and converted into compact records. They are then analysed by a rule engine that looks for indicators of port scanning, SYN floods, ARP spoofing, ICMP floods, suspicious DNS activity and traffic from blacklisted addresses. Each match becomes a structured alert with a severity, a description and a recommended action. Alerts appear on a terminal SOC dashboard, are stored in SQLite and are summarised in HTML/JSON reports. The system is designed for demonstration in an isolated virtual lab and uses configurable heuristic thresholds rather than claiming definitive attack identification.

## 2. Introduction
Every networked organisation needs visibility into its traffic. An intrusion detection system watches that traffic and warns analysts about patterns that commonly accompany attacks. Commercial and open-source IDS products (Snort, Suricata, Zeek) are powerful but complex. This project builds a small, readable IDS so that the core ideas can be studied and demonstrated: packet capture, protocol dissection, sliding-window statistics, rule-based detection, alert management and reporting.

## 3. Problem statement
Small labs and students often have no tool that shows, in real time and in plain language, what is happening on their network and which activity looks suspicious. Raw packet captures (Wireshark) show everything but interpret nothing. Full IDS platforms are hard to deploy and explain. A simple, configurable and well-documented IDS is needed that captures traffic, flags common attack indicators with low noise, and keeps records for later review.

## 4. Objectives
1. Capture live packets from a chosen interface, with filtering and start/stop control.
2. Extract source/destination IP, ports, protocol, size and timestamp from each packet.
3. Detect indicators of port scans, SYN floods, ARP spoofing, ICMP floods, suspicious DNS and blacklisted IPs, using configurable thresholds.
4. Produce structured alerts with severity levels, de-duplication and cool-down.
5. Show a real-time colour dashboard and keep alert history in SQLite with search and filters.
6. Generate HTML and JSON monitoring reports.
7. Keep capture and detection separate, memory-bounded and thread-safe.

## 5. Existing system
* **Manual packet inspection** (tcpdump, Wireshark): complete data, but no automatic detection and it needs expert time.
* **Signature IDS** (Snort, Suricata): large rule sets with high accuracy for known attacks. They are complex to install and tune, and heavy for a small lab.
* **Network monitors** (Zeek, ntopng): rich analytics with a steep learning curve.
* **Host firewalls/logs:** they see only one machine and not layer-2 events such as ARP changes.

Limitations: complexity, poor explainability for beginners, and no compact tool focused on teaching the detection logic.

## 6. Proposed system
A modular Python NIDS that:
* captures packets with Scapy's `AsyncSniffer` (or replays a saved `.pcap`);
* normalises packets into `PacketInfo` records;
* applies sliding-window heuristics per source, with safeguards against common false positives;
* manages alerts with cool-down, merging of repeats and cross-category correlation (CRITICAL);
* stores sessions and alerts in SQLite, and provides a menu, a dashboard and HTML/JSON reports;
* keeps every threshold in `config.json`.

## 7. System architecture
```
Interface / pcap ─► Capture (Scapy) ─► bounded queue ─► Processing thread
                                                         ├─ Packet analyzer → PacketInfo
                                                         ├─ Traffic statistics
                                                         ├─ Detection engine (rules)
                                                         └─ Alert manager → SQLite, dashboard
Menu / CLI (main thread) ─► dashboard, history, search, blacklist, reports
```
Layers: **capture** (packet_capture.py) → **analysis** (packet_analyzer.py) → **detection** (detection_engine.py) → **alerting** (alert_manager.py) → **storage/presentation** (database.py, ui.py, report_generator.py). They are coordinated by ids_monitor.py and main.py.

## 8. Hardware and software requirements
| Hardware | Minimum |
|---|---|
| Host PC | 4-core CPU, 8 GB RAM (16 GB recommended for two VMs), 40 GB free disk |
| Network | VirtualBox Host-Only adapter |

| Software | Version |
|---|---|
| OS | Kali Linux 2024+ or Ubuntu 22.04+ (in VirtualBox 7) |
| Python | 3.10 or newer |
| Libraries | Scapy ≥ 2.5, colorama, tabulate, pytest; sqlite3, threading, json, collections (standard library) |
| Tools | libpcap, tcpdump (optional, for saving captures), a web browser for reports |

## 9. Module descriptions
| Module | Responsibility |
|---|---|
| main.py | ASCII banner, 8-option menu, CLI options, authorisation prompt, live display loop, summaries |
| packet_capture.py | interface listing/validation, privilege check, LiveCapture (AsyncSniffer), PcapReplay (sniff offline), clear error messages |
| packet_analyzer.py | converts Scapy packets to PacketInfo; thread-safe TrafficStats with recent-packet buffer |
| detection_engine.py | RateCounter, UniqueTracker, LRU state; port scan, SYN flood, ARP, ICMP, DNS and blacklist rules |
| alert_manager.py | Alert record, IDs, cool-down/de-duplication, correlation, recommended actions, listeners |
| database.py | SQLite schema, sessions, alerts, search by IP, severity filter, history, totals |
| report_generator.py | report data model, HTML (escaped) and JSON output |
| blacklist_manager.py | blacklist.json management, IP/CIDR matching, atomic saves |
| config_loader.py | default config, merge and validation |
| ids_monitor.py | runs one session: queue, worker thread, start/stop, persistence |
| ui.py | colours, tables, alert blocks, dashboard |

## 10. Algorithms and detection logic
**Sliding-window rate counter.** Events are added to fixed time buckets (window/20). The count for "the last N seconds" is the sum of buckets that are still inside the window. Memory is constant even during a flood.

**Unique-value tracker (port scan).** For each source it keeps `port → last seen` plus a time-ordered queue. Entries older than the window are removed, and the number of distinct ports is compared with the threshold. Only TCP packets with SYN set and ACK clear (new connection attempts) are counted.

**SYN flood indicator.** It counts SYNs per source in the window. A second counter watches SYNs per destination together with the number of distinct sources, which spots spoofed sources. If the same source is currently flagged as a port scanner, the SYN-flood alert is suppressed, because the scan alert already explains the traffic.

**ARP mapping conflict.**
```
on ARP reply (ip, mac):
    ignore if ip == 0.0.0.0 or mac is 00:..:00 / ff:..:ff        # probes, placeholders
    if ip not in table: table[ip] = mac (alert if it contradicts a configured static mapping)
    elif table[ip] != mac:
        if old mac idle > stale_after_seconds and first change → LOW (device likely replaced)
        else → HIGH "Suspicious ARP Mapping Change" with previous/new MAC and change count
```

**ICMP flood indicator.** It counts ICMP per source in the window, excluding replies and error types (0, 3, 11).

**DNS heuristics.** These count queries per source per 60 s (excessive) and per 1 s (burst). A name is "unusual" when it is long (> 60 characters), has a label longer than 40 characters, or has a long label with Shannon entropy ≥ 3.8. The same unusual name repeated 5 times in 60 s raises a MEDIUM alert. Reverse-lookup zones are allow-listed.

**Blacklist.** Each source IP (optionally the destination too) is looked up in a cached table of single addresses and CIDR networks.

**Alert management.** Key = (rule, source, …). If the same key fired less than `cooldown_seconds` ago, the occurrence count and peak values of the existing alert are updated and no new alert is created. If one source collects ≥ 3 different categories within 300 s, a CRITICAL correlation alert is created.

## 11. Implementation methodology
Development was incremental:
1. configuration and validation;
2. packet normalisation;
3. detection engine;
4. alert manager;
5. storage and reports;
6. capture threads and the session controller;
7. menu, CLI and dashboard;
8. tests and documentation.

Scapy-dependent code is isolated in two modules, so everything else can be tested without network access. Coding practices:
* type hints and dataclasses;
* parameterised SQL;
* HTML escaping;
* locks around shared state;
* bounded queues and LRU caches;
* graceful handling of Ctrl+C, permission errors and malformed packets.

## 12. Testing and results
**Automated tests (pytest, 29 tests, all passing in the build environment).** They cover:
* configuration validation;
* packet parsing (using a test double that imitates Scapy's packet interface);
* statistics, the blacklist, alert cool-down and the database;
* reports (including HTML escaping);
* the capture/replay plumbing, CLI and menu.

An end-to-end test replays seven ordinary packets and produces zero alerts. A second test replays three packets from the documentation address 203.0.113.50 and produces exactly one HIGH "Blacklisted IP" alert with 3 merged occurrences.

**Not covered by automated tests:** the port-scan, SYN-flood, ARP, ICMP-flood, DNS and correlation rules. Real Scapy and live capture also could not be exercised in the build environment. These are to be demonstrated and recorded in the VirtualBox lab. Insert your own lab screenshots and observed alert counts here.

| Test | Expected | Observed in lab |
|---|---|---|
| Normal traffic | packets counted, 0 alerts | _fill in_ |
| ICMP monitoring | ICMP counted, no alert for 4 pings | _fill in_ |
| Blacklisted IP | 1 HIGH alert with reason | _fill in_ |
| Port scan / SYN / ARP / DNS | per DEMO_GUIDE.md | _fill in_ |

## 13. Advantages and limitations
**Advantages:**
* small and readable;
* every threshold is configurable;
* capture and detection are separate;
* memory is bounded and alert floods are controlled;
* persistent history and reports;
* `.pcap` replay for repeatable analysis.

**Limitations:**
* heuristic, threshold-based detection produces false positives and negatives;
* no payload signatures and no encrypted-traffic insight;
* single machine, and Python speed limits very high packet rates;
* only sees traffic that reaches the monitored interface;
* detection rules are not covered by automated tests in this version.

## 14. Future enhancements
* Signature rules (Snort/Suricata-style) and payload inspection.
* Adaptive baselines (anomaly detection learned per host).
* Web dashboard (Flask) and email/Slack notifications.
* Forwarding alerts to a SIEM (syslog/JSON to Wazuh or ELK).
* GeoIP and threat-intelligence feed integration for the blacklist.
* An optional IPS mode that suggests firewall rules for analyst approval.
* Automated rule tests built from recorded lab captures.

## 15. Conclusion
The project delivers a working, modular network IDS that demonstrates the full monitoring pipeline: capture, analysis, detection, alerting, storage and reporting. It shows how simple time-window statistics can surface suspicious behaviour. It also shows why every alert must be treated as an indicator that needs analyst verification. Its configurable design makes it a practical base for further work in network security monitoring.
