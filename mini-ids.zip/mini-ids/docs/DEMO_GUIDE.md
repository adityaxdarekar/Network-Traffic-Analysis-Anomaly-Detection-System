# Demonstration guide — isolated VirtualBox lab

**Lab:** Kali Linux = IDS machine (host-only IP, e.g. `192.168.56.10`, interface `eth1`). A second VM you own = traffic generator (e.g. `192.168.56.102`). Both are on the same VirtualBox **Host-Only** network and nothing else is connected.

**Before the demo**
```bash
cd mini-ids && source venv/bin/activate
ip -br addr                                   # confirm the host-only interface name
sudo venv/bin/python3 main.py                 # menu → 1, interface eth1, dashboard, duration 0
sudo tcpdump -i eth1 -w demo_backup.pcap      # (second terminal, optional) keep a capture for replay
```
If the live network misbehaves in front of the faculty, run `python3 main.py --pcap demo_backup.pcap --report` to replay what you captured earlier.

---

## Test 1 — Normal traffic (no false alarms)
From the traffic-generator VM:
```bash
ping -c 4 192.168.56.10
curl -s http://192.168.56.10/ -o /dev/null      # works if a web server runs on Kali; a refused connection is fine too
nslookup example.com 192.168.56.10              # a DNS query to Kali (no reply needed)
```
**Expected:** the TCP, ICMP and DNS counters go up and **Total Alerts stays 0**. Four pings are far below the ICMP threshold. A couple of connections are far below the 15-port threshold, and Kali's own echo replies are ignored by design.
**Explain:** the IDS watches every packet, but thresholds and safeguards keep ordinary traffic quiet.
**Screenshot:** the dashboard with packet counts and "No alerts yet."

## Test 5 — ICMP monitoring
Same `ping -c 4` as above, then switch to the packet feed (menu 1 → display 2):
**Expected:** one `ICMP … type=8` line per request and one `type=0` line per reply, each with timestamp, addresses and size.
**Explain:** the ICMP flood rule counts requests per source in a 10-second window (threshold 100, `config.json → rules.icmp_flood`). Replies (type 0) and error messages are excluded, so the host answering pings is never flagged.
**Screenshot:** the packet feed showing the ICMP lines.

## Test 7 — Blacklisted IP
1. Menu **5 → 2**, IP `192.168.56.102` (your lab VM), reason `Lab test entry`.
2. Start monitoring (menu 1) and run `ping -c 3 192.168.56.10` from that VM.

**Expected:**
```
[HIGH] Traffic Involving a Blacklisted IP  IDS-0004-00001
   Time: …   Source IP: 192.168.56.102   Destination: 192.168.56.10
   Blacklist Reason: Lab test entry
   repeated 3 times (merged during cool-down)
```
**Explain:** each source address is checked against `blacklist.json` (single IPs and CIDR networks). Repeats inside the 60 s cool-down are merged into one alert. Remove the entry afterwards (menu 5 → 3).
**Screenshot:** the alert, then menu 4 (search `192.168.56.102`).

## Tests 2, 3, 4 and 6 — port scan, SYN flood, ARP, DNS heuristics
This guide does not include commands for producing those traffic patterns. Run them only with tools and procedures approved by your instructor, against your own isolated lab VMs. For each one, explain the rule using `config.json` and README.md (Phase 1 table). If you capture an alert, show the fields it carries:

| Rule | Alert fields to point out |
|---|---|
| Port scan (HIGH) | source IP, unique ports, time window, sample of ports |
| SYN flood indicator (HIGH) | SYN count, window, target port. Stress that it is a heuristic, not proof of DoS |
| ARP mapping change (HIGH, or LOW if the old entry was stale) | IP, previous MAC, new MAC, number of changes |
| DNS (LOW/MEDIUM) | query count or domain name and the reason it looked unusual |

> These four rules have **no automated tests** in this package (see PROJECT_STATUS.md). Rehearse in your lab before the presentation.

## Finishing the demo
Ctrl+C → session summary. Then menu **6** for the HTML report and **7** for statistics. Open the report in Firefox: `firefox reports/html/ids_report_session*_*.html`.
