# Viva questions and answers

1. **What is an IDS?** An Intrusion Detection System monitors network traffic or host activity and raises alerts when it sees signs of malicious or policy-violating behaviour. It detects and reports; it does not block.

2. **IDS vs IPS?** An IDS is passive: it observes a copy of the traffic and alerts. An IPS sits in-line and can drop or block traffic automatically. An IPS needs very low false-positive rates, because a wrong decision blocks legitimate users. This project is an IDS.

3. **NIDS vs HIDS?** A network IDS analyses packets on a network segment (this project). A host IDS analyses logs, files and processes on one machine (for example Wazuh agents or file-integrity monitoring).

4. **What is Scapy?** A Python library for capturing, dissecting, building and sending packets. Here it is used only to capture and dissect: `AsyncSniffer`/`sniff()` capture, and layers such as `IP`, `TCP`, `ARP` and `DNS` give access to header fields.

5. **What is packet sniffing?** Reading packets that pass a network interface, usually through libpcap and raw sockets. In promiscuous mode the interface also passes frames that are not addressed to it. It needs root or CAP_NET_RAW.

6. **What is TCP?** A connection-oriented transport protocol that provides reliable, ordered delivery using sequence numbers, acknowledgements, retransmission and flow control. Connections start with a three-way handshake.

7. **What is a SYN packet?** The first packet of the TCP handshake (SYN flag set, ACK clear). The server answers SYN-ACK and the client completes with ACK. The IDS counts SYN-without-ACK packets as new connection attempts.

8. **What is a SYN flood?** A denial-of-service technique that sends many SYNs without completing the handshake, filling the server's half-open connection queue. Defences include SYN cookies, rate limiting and upstream filtering. The project reports a high SYN rate only as an indicator.

9. **What is port scanning?** Probing many ports on a host to discover which services are listening. It is often reconnaissance before an attack, but is also done by authorised administrators. The IDS flags one source contacting ≥ 15 distinct ports in 10 seconds.

10. **What is ARP spoofing?** ARP maps IP addresses to MAC addresses and has no authentication. An attacker can send forged ARP replies that claim another host's IP (often the gateway), redirecting traffic through themselves (man-in-the-middle). The IDS watches for one IP being announced with a different MAC.

11. **How do you avoid ARP false positives?** Ignore ARP probes and placeholder MACs; treat a change after long inactivity as LOW (likely a replaced device or DHCP re-use); allow trusted static mappings; and phrase alerts as "possible" with legitimate causes listed (VM cloning, failover, NIC replacement).

12. **What is DNS monitoring?** Watching DNS queries to spot unusual behaviour: very high query volume, bursts, very long or random-looking names (possible tunnelling or generated domains), and repeated look-ups of odd names. It is an indicator only; CDNs and security products also use long names.

13. **What is Shannon entropy and why use it?** A measure of randomness: H = −Σ p·log₂p over character frequencies. Human-chosen domain labels have lower entropy than random strings, so a high value on a long label marks it as "random-looking".

14. **What is signature-based detection?** Matching traffic against known patterns of attacks (byte strings, header combinations). It is accurate for known threats but misses new ones, and the rules need updating.

15. **What is anomaly-based detection?** Learning or defining normal behaviour and alerting on deviations. It can find new attacks but produces more false positives. This project uses threshold-based anomaly heuristics, plus a blacklist (a simple signature).

16. **What are false positives and false negatives?** A false positive is an alert for benign activity (e.g. a backup server triggering the port-scan rule). A false negative is a missed attack (e.g. a slow scan below the threshold). Thresholds trade one against the other.

17. **What is a SIEM?** Security Information and Event Management: a platform that collects logs and alerts from many sources, correlates them, stores them and supports investigation (e.g. Wazuh, Splunk, ELK). This IDS could forward its JSON alerts to a SIEM.

18. **How does this project detect suspicious activities?** Capture → convert each packet to a PacketInfo → update statistics → run every enabled rule using sliding windows keyed by source IP → create alerts with severity and recommended action → de-duplicate with a cool-down → store in SQLite and display.

19. **Why use a queue and a separate processing thread?** Capture must be fast or the kernel drops packets. The capture callback only enqueues; analysis runs in another thread. The queue is bounded, so memory cannot explode; overflow is counted as "dropped".

20. **How is memory kept under control?** A bounded queue, `store=False` in the sniffer, LRU dictionaries limited by `max_tracked_sources`, bucketed rate counters of fixed size, a cap on ports tracked per source, and periodic purging of idle state.

21. **What is alert de-duplication / cool-down?** Each alert has a key (rule + source + …). If the same key fires again within `cooldown_seconds`, the existing alert's occurrence count and peak values are updated instead of creating a new alert. This prevents a flood of identical alerts.

22. **What is correlation in this project?** If one source triggers three or more different categories within 5 minutes, a CRITICAL "Multiple Attack Indicators" alert is raised, because combined behaviour is more significant than any single heuristic.

23. **What is a BPF filter?** A Berkeley Packet Filter expression (e.g. `tcp or arp or port 53`) compiled by libpcap and applied in the kernel, so unwanted packets never reach Python. This improves performance.

24. **Why use packet timestamps instead of the clock?** So that the same rules give the same results for live traffic and for replayed `.pcap` files, and windows are not distorted by processing delays.

25. **What are the limitations of this IDS?** Threshold heuristics (tuning needed, false positives/negatives), no payload signatures, no visibility into encrypted content, single-machine Python performance, it only sees traffic reaching its interface, and the detection rules have no automated tests in this version. They must be verified in the lab.

26. **What ethical/legal rules apply?** Monitor only networks you own or are authorised to monitor, keep tests inside an isolated lab, do not target public or production systems, and protect captured data, because it can contain personal information.
