"""
alert_manager.py - turn Detection objects into structured alerts.

Responsibilities
  * de-duplication + cool-down: one alert per (rule, source, ...) key per
    cool-down period; repeats only update the existing alert (occurrence
    count, last seen, peak values) so the dashboard is not flooded
  * correlation: several different attack categories from one source within
    a time window raise a CRITICAL "Multiple Attack Indicators" alert
  * recommended actions per category
  * thread-safe storage of active alerts and listener callbacks (database,
    live display)
"""
from __future__ import annotations

import threading
from collections import Counter, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Callable, Optional

from detection_engine import (ARP_SPOOF, BLACKLISTED_IP, CORRELATED, DNS_SUSPICIOUS, ICMP_FLOOD,
                              PORT_SCAN, SYN_FLOOD, Detection)

SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

RECOMMENDATIONS = {
    PORT_SCAN: ("Confirm whether the source is an authorised scanner. If not, review firewall rules, "
                "close unused ports and watch the source for follow-up connection attempts."),
    SYN_FLOOD: ("Check service availability and half-open connections (ss -tan state syn-recv). "
                "Consider SYN cookies (net.ipv4.tcp_syncookies=1) and rate limiting at the firewall."),
    ARP_SPOOF: ("Verify the MAC addresses against the switch/router ARP table and the device inventory. "
                "If unexplained, isolate the host using the new MAC and consider static ARP entries "
                "or Dynamic ARP Inspection."),
    ICMP_FLOOD: ("Identify the tool generating the ICMP traffic. If unwanted, rate-limit ICMP echo "
                 "requests at the firewall."),
    DNS_SUSPICIOUS: ("Identify the process that generated the queries (e.g. ss -up, lsof -i :53) and "
                     "review the domains with threat-intelligence sources before blocking."),
    BLACKLISTED_IP: ("Investigate why the host is communicating with a listed address, review the "
                     "blacklist reason and block the address at the firewall if confirmed."),
    CORRELATED: ("Treat the source as high priority: review all its alerts together, isolate it if it "
                 "is not an authorised testing machine and preserve logs/pcaps for investigation."),
}


@dataclass
class Alert:
    alert_id: str
    timestamp: str                 # ISO time of the first packet that triggered it
    epoch: float
    source_ip: Optional[str]
    destination_ip: Optional[str]
    category: str
    severity: str
    title: str
    description: str
    rule: str
    recommended_action: str
    details: dict = field(default_factory=dict)
    occurrences: int = 1           # matches merged into this alert during the cool-down
    last_seen: str = ""
    session_id: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)


def _iso(ts: float) -> str:
    try:
        return datetime.fromtimestamp(ts).isoformat(timespec="seconds")
    except (OverflowError, OSError, ValueError):
        return datetime.now().isoformat(timespec="seconds")


class AlertManager:
    def __init__(self, config: dict, session_id: Optional[int] = None, id_prefix: str = "IDS"):
        a = config["alerts"]
        self.cooldown = float(a["cooldown_seconds"])
        self.corr = a["correlation"]
        self.session_id = session_id
        self.id_prefix = id_prefix
        self._lock = threading.RLock()
        self._active: deque[Alert] = deque(maxlen=a["active_alert_limit"])
        self._all_count = 0
        self._by_severity: Counter = Counter()
        self._by_category: Counter = Counter()
        self._last: dict[tuple, Alert] = {}            # dedupe key -> latest alert
        self._last_epoch: dict[tuple, float] = {}
        self._source_categories: dict[str, dict] = {}  # src -> {category: last epoch}
        self._dirty: dict[str, Alert] = {}              # alerts updated since last flush
        self._listeners: list[Callable[[Alert, bool], None]] = []
        self.suppressed = 0
        self._seq = 0

    # ------------------------------------------------------------- listeners
    def add_listener(self, fn: Callable[[Alert, bool], None]) -> None:
        """fn(alert, is_new) is called for new alerts and on flush() for updated ones."""
        self._listeners.append(fn)

    def _notify(self, alert: Alert, is_new: bool) -> None:
        for fn in list(self._listeners):
            try:
                fn(alert, is_new)
            except Exception as exc:          # a broken listener must not stop detection
                print(f"[alert listener error] {exc}")

    # ------------------------------------------------------------------ core
    def _next_id(self) -> str:
        self._seq += 1
        sid = f"{self.session_id:04d}" if isinstance(self.session_id, int) else "0000"
        return f"{self.id_prefix}-{sid}-{self._seq:05d}"

    def submit(self, d: Detection) -> Optional[Alert]:
        """Register a detection. Returns the new Alert, or None if it was merged/suppressed."""
        new_alerts: list[Alert] = []
        with self._lock:
            key = d.dedupe_key or (d.rule, d.src_ip, d.dst_ip)
            last_time = self._last_epoch.get(key)
            if last_time is not None and d.timestamp - last_time < self.cooldown:
                existing = self._last[key]
                existing.occurrences += 1
                existing.last_seen = _iso(d.timestamp)
                for f in d.peak_fields:
                    if isinstance(d.details.get(f), (int, float)):
                        existing.details[f] = max(existing.details.get(f, 0), d.details[f])
                self._dirty[existing.alert_id] = existing
                self.suppressed += 1
                return None
            alert = self._create(d)
            self._last[key] = alert
            self._last_epoch[key] = d.timestamp
            new_alerts.append(alert)
            corr = self._correlate(alert)
            if corr is not None:
                new_alerts.append(corr)
        for a in new_alerts:
            self._notify(a, True)
        return new_alerts[0]

    def _create(self, d: Detection) -> Alert:
        alert = Alert(alert_id=self._next_id(), timestamp=_iso(d.timestamp), epoch=d.timestamp,
                      source_ip=d.src_ip, destination_ip=d.dst_ip, category=d.category,
                      severity=d.severity, title=d.title, description=d.description, rule=d.rule,
                      recommended_action=RECOMMENDATIONS.get(d.category, "Investigate the activity."),
                      details=dict(d.details), last_seen=_iso(d.timestamp), session_id=self.session_id)
        self._active.append(alert)
        self._all_count += 1
        self._by_severity[alert.severity] += 1
        self._by_category[alert.category] += 1
        return alert

    def _correlate(self, alert: Alert) -> Optional[Alert]:
        """CRITICAL alert when one source triggers several *different* categories."""
        if not self.corr["enabled"] or not alert.source_ip or alert.category == CORRELATED:
            return None
        cats = self._source_categories.setdefault(alert.source_ip, {})
        cats[alert.category] = alert.epoch
        window = self.corr["window_seconds"]
        for c in [c for c, t in cats.items() if alert.epoch - t > window]:
            del cats[c]
        if len(cats) < self.corr["min_categories"]:
            return None
        key = ("CORRELATED", alert.source_ip)
        last = self._last_epoch.get(key)
        if last is not None and alert.epoch - last < max(self.cooldown, window):
            return None
        names = sorted(cats)
        d = Detection(
            rule="CORRELATION", category=CORRELATED, severity="CRITICAL",
            title="Multiple Attack Indicators From One Source",
            description=(f"{alert.source_ip} triggered {len(names)} different detection categories within "
                         f"{window:g} seconds: {', '.join(names)}. Combined behaviour is more significant "
                         "than any single heuristic."),
            timestamp=alert.epoch, src_ip=alert.source_ip, dst_ip=None,
            details={"categories": ", ".join(names), "category_count": len(names),
                     "time_window_seconds": window})
        corr = self._create(d)
        self._last[key] = corr
        self._last_epoch[key] = alert.epoch
        return corr

    def flush(self) -> int:
        """Notify listeners about alerts updated during cool-down (e.g. to update the database)."""
        with self._lock:
            updated = list(self._dirty.values())
            self._dirty.clear()
        for a in updated:
            self._notify(a, False)
        return len(updated)

    # ----------------------------------------------------------------- query
    def active_alerts(self, limit: Optional[int] = None) -> list[Alert]:
        with self._lock:
            items = list(self._active)
        return items[-limit:] if limit else items

    def counts(self) -> dict:
        with self._lock:
            return {"total": self._all_count,
                    **{s: self._by_severity.get(s, 0) for s in SEVERITY_ORDER},
                    "by_category": dict(self._by_category), "suppressed_duplicates": self.suppressed}
