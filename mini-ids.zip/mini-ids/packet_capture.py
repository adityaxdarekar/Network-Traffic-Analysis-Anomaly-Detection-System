"""
packet_capture.py - packet sources that feed the IDS.

  LiveCapture   - live capture from a network interface with Scapy
                  (AsyncSniffer = the background-thread form of sniff())
  PcapReplay    - replays a saved .pcap/.pcapng through sniff(offline=...)

A source only hands raw packets to a callback; it never analyses them.
Analysis and detection run in the processing thread (ids_monitor.py), so a
slow rule can never block the capture socket.
"""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from config_loader import valid_interface_name, validate_bpf


class CaptureError(RuntimeError):
    """Raised with a user-friendly message when capture cannot start."""


# ---------------------------------------------------------------------------
# Environment helpers
# ---------------------------------------------------------------------------
def scapy_available() -> bool:
    try:
        import scapy  # noqa: F401
        return True
    except ImportError:
        return False


def list_interfaces() -> list[str]:
    """Interface names from Scapy, falling back to /sys/class/net on Linux."""
    names: list[str] = []
    try:
        from scapy.all import get_if_list
        names = list(get_if_list())
    except Exception:
        pass
    if not names:
        try:
            names = sorted(os.listdir("/sys/class/net"))
        except OSError:
            names = []
    return names


def default_interface() -> Optional[str]:
    try:
        from scapy.all import conf
        iface = conf.iface
        name = getattr(iface, "name", None) or str(iface)
        if name:
            return name
    except Exception:
        pass
    others = [n for n in list_interfaces() if n != "lo"]
    return others[0] if others else None


def has_capture_privileges() -> bool:
    """True if running as root or the process has CAP_NET_RAW (bit 13)."""
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return True
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            if line.startswith("CapEff:"):
                return bool(int(line.split()[1], 16) & (1 << 13))
    except (OSError, ValueError, IndexError):
        pass
    return False


PRIVILEGE_HELP = ("Packet capture needs root or the CAP_NET_RAW capability.\n"
                  "  Run with:   sudo venv/bin/python3 main.py\n"
                  "  or grant:   sudo setcap cap_net_raw,cap_net_admin=eip \"$(readlink -f venv/bin/python3)\"")


def check_interface(name: str) -> str:
    if not valid_interface_name(name):
        raise CaptureError(f"invalid interface name: {name!r}")
    known = list_interfaces()
    if known and name not in known:
        raise CaptureError(f"interface {name!r} not found. Available: {', '.join(known)}")
    return name


# ---------------------------------------------------------------------------
# Sources
# ---------------------------------------------------------------------------
class LiveCapture:
    """Live capture with Scapy's AsyncSniffer (store=False: nothing kept in memory)."""

    kind = "live"

    def __init__(self, interface: str, bpf_filter: str, on_packet: Callable, promiscuous: bool = True):
        self.interface = interface
        self.bpf_filter = validate_bpf(bpf_filter) if bpf_filter else ""
        self.on_packet = on_packet
        self.promiscuous = promiscuous
        self.sniffer = None
        self.error: Optional[str] = None
        self.finished = threading.Event()

    def _preflight(self) -> None:
        """Open (and close) a capture socket in *this* thread so permission,
        interface and BPF-syntax errors are reported clearly instead of being
        lost inside the sniffer thread."""
        from scapy.all import conf
        try:
            sock = conf.L2listen(iface=self.interface, filter=self.bpf_filter or None,
                                 promisc=self.promiscuous)
            sock.close()
        except PermissionError as exc:
            raise CaptureError(f"permission denied: {exc}\n{PRIVILEGE_HELP}") from exc
        except OSError as exc:
            raise CaptureError(f"cannot open interface {self.interface!r}: {exc}") from exc
        except Exception as exc:          # Scapy_Exception for an invalid BPF filter, etc.
            msg = str(exc) or exc.__class__.__name__
            if "filter" in msg.lower() or self.bpf_filter:
                raise CaptureError(f"capture failed - check the BPF filter {self.bpf_filter!r}: {msg}") from exc
            raise CaptureError(f"capture failed: {msg}") from exc

    def start(self) -> None:
        if not scapy_available():
            raise CaptureError("Scapy is not installed. Activate the venv and run: pip install -r requirements.txt")
        check_interface(self.interface)
        if not has_capture_privileges():
            raise CaptureError(PRIVILEGE_HELP)
        self._preflight()
        from scapy.all import AsyncSniffer
        self.sniffer = AsyncSniffer(iface=self.interface, filter=self.bpf_filter or None,
                                    prn=self.on_packet, store=False, promisc=self.promiscuous)
        self.sniffer.start()
        time.sleep(0.3)
        if not self.alive():
            self.error = "the capture thread stopped immediately (see the error printed above)"
            raise CaptureError(self.error)

    def alive(self) -> bool:
        if self.sniffer is None:
            return False
        thread = getattr(self.sniffer, "thread", None)
        running = getattr(self.sniffer, "running", None)
        if thread is not None:
            return thread.is_alive()
        return bool(running)

    def stop(self) -> None:
        if self.sniffer is not None:
            try:
                if self.alive():
                    self.sniffer.stop()
            except Exception as exc:          # stopping must never crash the program
                self.error = f"error while stopping capture: {exc}"
        self.finished.set()


class PcapReplay:
    """Reads a capture file with sniff(offline=...) in a background thread."""

    kind = "pcap"

    def __init__(self, path: str | Path, on_packet: Callable, bpf_filter: str = ""):
        self.path = Path(path)
        self.on_packet = on_packet
        self.bpf_filter = validate_bpf(bpf_filter) if bpf_filter else ""
        self.interface = f"pcap:{self.path.name}"
        self._stop = threading.Event()
        self.finished = threading.Event()
        self.error: Optional[str] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if not scapy_available():
            raise CaptureError("Scapy is not installed. Run: pip install -r requirements.txt")
        if not self.path.is_file():
            raise CaptureError(f"capture file not found: {self.path}")
        self._thread = threading.Thread(target=self._run, name="pcap-replay", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        from scapy.all import sniff
        try:
            sniff(offline=str(self.path), prn=self.on_packet, store=False,
                  filter=self.bpf_filter or None, stop_filter=lambda _p: self._stop.is_set())
        except Exception as exc:
            self.error = f"cannot read {self.path.name}: {exc}"
        finally:
            self.finished.set()

    def alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self.finished.set()


def safe_label(text: str) -> str:
    """Interface/source label safe for display and the database."""
    return re.sub(r"[^A-Za-z0-9_.:@()/ -]", "_", str(text))[:64]
