"""
packet_analyzer.py - turn a Scapy packet into a small, uniform PacketInfo record.

Only this module (and packet_capture.py) knows about Scapy. Everything after
it - detection, alerts, statistics, reports - works on PacketInfo objects,
which keeps detection logic separate from packet capture and makes it easy
to unit-test the detectors with hand-made packets.

Protocol labels used for statistics (each packet gets exactly one):
    DNS   - UDP/TCP packet carrying a DNS layer (counted as DNS, *not* UDP)
    TCP, UDP, ICMP, ARP
    ICMPv6, OTHER
"""
from __future__ import annotations

import threading
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Optional

# TCP flag bits
FIN, SYN, RST, PSH, ACK, URG = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20
PROTOCOLS = ("TCP", "UDP", "ICMP", "ARP", "DNS", "ICMPv6", "OTHER")


@dataclass(slots=True)
class PacketInfo:
    """Protocol-independent summary of one captured packet."""
    timestamp: float
    length: int
    protocol: str = "OTHER"
    src_ip: Optional[str] = None
    dst_ip: Optional[str] = None
    src_port: Optional[int] = None
    dst_port: Optional[int] = None
    transport: Optional[str] = None          # "TCP" / "UDP" for DNS packets too
    tcp_flags: Optional[int] = None
    icmp_type: Optional[int] = None
    icmp_code: Optional[int] = None
    src_mac: Optional[str] = None
    arp_op: Optional[int] = None             # 1 = who-has (request), 2 = is-at (reply)
    arp_src_ip: Optional[str] = None
    arp_src_mac: Optional[str] = None
    arp_dst_ip: Optional[str] = None
    dns_qr: Optional[int] = None             # 0 = query, 1 = response
    dns_qname: Optional[str] = None

    # -- convenience helpers used by the detection engine ------------------
    @property
    def is_syn(self) -> bool:
        """SYN set and ACK not set = a new connection attempt."""
        return self.tcp_flags is not None and bool(self.tcp_flags & SYN) and not self.tcp_flags & ACK

    @property
    def is_dns_query(self) -> bool:
        return self.dns_qr == 0 and bool(self.dns_qname)

    def flag_string(self) -> str:
        if self.tcp_flags is None:
            return ""
        names = [(FIN, "F"), (SYN, "S"), (RST, "R"), (PSH, "P"), (ACK, "A"), (URG, "U")]
        return "".join(ch for bit, ch in names if self.tcp_flags & bit)

    def time_text(self) -> str:
        return datetime.fromtimestamp(self.timestamp).strftime("%H:%M:%S.%f")[:-3]

    def summary(self) -> str:
        """One line for the live packet view."""
        if self.protocol == "ARP":
            op = {1: "who-has", 2: "is-at"}.get(self.arp_op or 0, f"op={self.arp_op}")
            return (f"{self.time_text()}  ARP   {op:<7} {self.arp_src_ip} ({self.arp_src_mac}) "
                    f"-> {self.arp_dst_ip}  {self.length}B")
        src = f"{self.src_ip}:{self.src_port}" if self.src_port is not None else str(self.src_ip)
        dst = f"{self.dst_ip}:{self.dst_port}" if self.dst_port is not None else str(self.dst_ip)
        extra = ""
        if self.protocol == "TCP":
            extra = f" [{self.flag_string()}]"
        elif self.protocol in ("ICMP", "ICMPv6"):
            extra = f" type={self.icmp_type} code={self.icmp_code}"
        elif self.protocol == "DNS" and self.dns_qname:
            extra = f" {'query' if self.dns_qr == 0 else 'reply'} {self.dns_qname}"
        return f"{self.time_text()}  {self.protocol:<5} {src} -> {dst}{extra}  {self.length}B"

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Scapy layer loading (lazy, so the rest of the project imports without Scapy)
# ---------------------------------------------------------------------------
_LAYERS: Optional[dict] = None


def _layers() -> dict:
    global _LAYERS
    if _LAYERS is None:
        try:
            from scapy.layers.dns import DNS
            from scapy.layers.inet import ICMP, IP, TCP, UDP
            from scapy.layers.inet6 import IPv6
            from scapy.layers.l2 import ARP, Ether
        except ImportError as exc:  # pragma: no cover - message checked in tests
            raise ImportError("Scapy is not installed. Run: pip install scapy") from exc
        _LAYERS = {"IP": IP, "IPv6": IPv6, "TCP": TCP, "UDP": UDP, "ICMP": ICMP,
                   "ARP": ARP, "Ether": Ether, "DNS": DNS}
    return _LAYERS


def reset_layer_cache() -> None:
    """Forget cached Scapy classes (used by the tests)."""
    global _LAYERS
    _LAYERS = None


def _decode_name(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    name = str(value).strip().rstrip(".").lower()
    return name[:255] or None


def _first_question(dns: Any) -> Any:
    """Scapy < 2.6 stores qd as a DNSQR packet, >= 2.6 as a list of DNSQR."""
    qd = getattr(dns, "qd", None)
    if qd is None:
        return None
    if isinstance(qd, (list, tuple)):
        return qd[0] if qd else None
    try:                                     # PacketListField-like objects
        if hasattr(qd, "__len__") and not hasattr(qd, "qname"):
            return qd[0] if len(qd) else None
    except (TypeError, IndexError):
        return None
    return qd


def analyze_packet(pkt: Any) -> PacketInfo:
    """Convert one Scapy packet into a PacketInfo. Never raises on odd packets."""
    L = _layers()
    try:
        ts = float(getattr(pkt, "time", 0) or 0)
    except (TypeError, ValueError):
        ts = 0.0
    try:
        length = int(len(pkt))
    except Exception:
        length = 0
    info = PacketInfo(timestamp=ts, length=length)

    if pkt.haslayer(L["Ether"]):
        info.src_mac = str(pkt[L["Ether"]].src).lower()

    # --- ARP (layer 2, no IP header) ---------------------------------------
    if pkt.haslayer(L["ARP"]):
        arp = pkt[L["ARP"]]
        info.protocol = "ARP"
        info.arp_op = int(arp.op)
        info.arp_src_ip = str(arp.psrc)
        info.arp_src_mac = str(arp.hwsrc).lower()
        info.arp_dst_ip = str(arp.pdst)
        info.src_ip, info.dst_ip = info.arp_src_ip, info.arp_dst_ip
        return info

    # --- IP layer -----------------------------------------------------------
    if pkt.haslayer(L["IP"]):
        ip = pkt[L["IP"]]
        info.src_ip, info.dst_ip = str(ip.src), str(ip.dst)
    elif pkt.haslayer(L["IPv6"]):
        ip6 = pkt[L["IPv6"]]
        info.src_ip, info.dst_ip = str(ip6.src), str(ip6.dst)
        if int(getattr(ip6, "nh", 0) or 0) == 58:          # ICMPv6
            info.protocol = "ICMPv6"
    else:
        return info                                          # OTHER (e.g. STP, LLDP)

    # --- transport ----------------------------------------------------------
    # ICMP is checked first: ICMP error messages quote the original IP/TCP/UDP
    # header (Scapy's IPerror/TCPerror/UDPerror), which must not be counted
    # as a new TCP/UDP packet.
    if pkt.haslayer(L["ICMP"]):
        icmp = pkt[L["ICMP"]]
        info.protocol = "ICMP"
        info.icmp_type, info.icmp_code = int(icmp.type), int(icmp.code)
        return info
    if pkt.haslayer(L["TCP"]):
        tcp = pkt[L["TCP"]]
        info.transport = info.protocol = "TCP"
        info.src_port, info.dst_port = int(tcp.sport), int(tcp.dport)
        info.tcp_flags = int(tcp.flags)
    elif pkt.haslayer(L["UDP"]):
        udp = pkt[L["UDP"]]
        info.transport = info.protocol = "UDP"
        info.src_port, info.dst_port = int(udp.sport), int(udp.dport)

    # --- DNS (inside UDP or TCP) -------------------------------------------
    if info.transport and pkt.haslayer(L["DNS"]):
        dns = pkt[L["DNS"]]
        info.protocol = "DNS"
        info.dns_qr = int(getattr(dns, "qr", 0) or 0)
        q = _first_question(dns)
        if q is not None:
            info.dns_qname = _decode_name(getattr(q, "qname", None))
    return info


# ---------------------------------------------------------------------------
# Thread-safe traffic statistics
# ---------------------------------------------------------------------------
@dataclass
class TrafficStats:
    """Counters shared between the processing thread and the display thread."""
    total: int = 0
    bytes: int = 0
    by_protocol: dict = field(default_factory=lambda: {p: 0 for p in PROTOCOLS})
    malformed: int = 0
    dropped: int = 0
    first_ts: Optional[float] = None
    last_ts: Optional[float] = None

    def __post_init__(self):
        self._lock = threading.Lock()
        self._recent: deque = deque(maxlen=200)     # recent packets for the live view
        self._seq = 0

    def update(self, info: PacketInfo) -> None:
        with self._lock:
            self.total += 1
            self.bytes += info.length
            proto = info.protocol if info.protocol in self.by_protocol else "OTHER"
            self.by_protocol[proto] += 1
            if info.timestamp:
                if self.first_ts is None or info.timestamp < self.first_ts:
                    self.first_ts = info.timestamp
                if self.last_ts is None or info.timestamp > self.last_ts:
                    self.last_ts = info.timestamp
            self._seq += 1
            self._recent.append((self._seq, info))

    def add_malformed(self) -> None:
        with self._lock:
            self.malformed += 1

    def add_dropped(self, n: int = 1) -> None:
        with self._lock:
            self.dropped += n

    def recent_since(self, seq: int) -> tuple[int, list[PacketInfo], int]:
        """Packets newer than *seq*: returns (latest_seq, packets, how_many_were_missed)."""
        with self._lock:
            items = [(s, p) for s, p in self._recent if s > seq]
            missed = max(0, (self._seq - seq) - len(items))
            return self._seq, [p for _, p in items], missed

    def snapshot(self) -> dict:
        with self._lock:
            return {"total": self.total, "bytes": self.bytes, "by_protocol": dict(self.by_protocol),
                    "malformed": self.malformed, "dropped": self.dropped,
                    "first_ts": self.first_ts, "last_ts": self.last_ts}
