# Mini Intrusion Detection System (IDS) — Python + Scapy

A lightweight network IDS for a college cybersecurity lab. It captures packets with Scapy and analyses them in a separate thread. It applies configurable heuristic rules and raises structured alerts with a severity and a recommended action. Alerts are stored in SQLite and shown on a coloured terminal SOC dashboard. Reports are written as HTML and JSON.

> ⚠️ **Only monitor networks and devices you own or are explicitly authorised to monitor.** Use an isolated VirtualBox host-only network for all testing.
>
> Read **PROJECT_STATUS.md** first. It lists exactly what was verified in the build environment and what you must verify in your own lab.

---

## PHASE 1 — Architecture and working method

```
 network interface ─► LiveCapture (Scapy AsyncSniffer, store=False)      .pcap file ─► PcapReplay (sniff(offline=...))
                                  │  callback: put packet in a bounded queue (never blocks; overflow = "dropped")
                                  ▼
                       ids_monitor.MonitorSession  ── processing thread ──────────────────────────────┐
                                  │                                                                    │
         packet_analyzer.analyze_packet()  → PacketInfo (src/dst IP, ports, protocol, flags, ARP, DNS) │
         TrafficStats.update()             → protocol counters (thread-safe)                          │
         DetectionEngine.process()         → Detection objects (heuristic rules)                      │
         AlertManager.submit()             → de-dup / cool-down / correlation → Alert                 │
                                  │                                                                    │
                    ┌─────────────┴────────────┐                                                       │
              database.py (SQLite)      live display (ui.py) ◄── main thread refreshes every second ──┘
                    │
            report_generator.py → reports/html/*.html + reports/json/*.json
```

* **Capture is separated from detection.** The capture callback only queues packets. All analysis runs in one processing thread, so a slow rule can never stall the capture socket.
* **Time windows use packet timestamps.** The same rules therefore work for live traffic and for replayed `.pcap` files.
* **Bounded memory.** The packet queue has a maximum size. Per-source state is kept in LRU dictionaries capped by `max_tracked_sources`. Rate counters use fixed time buckets, and idle state is purged periodically.
* **Alert flood control.** Each alert key (rule + source + …) fires once per `cooldown_seconds`. Repeats only raise the alert's occurrence count and keep peak values.

### Detection rules (all thresholds in `config.json`)

| Rule | Default threshold | Severity | Notes / safeguards |
|---|---|---|---|
| Port scan | 15 unique destination ports from one source in 10 s | HIGH | counts TCP SYN without ACK (new connection attempts); UDP optional |
| SYN flood indicator | 100 SYNs from one source in 10 s; 300 SYNs to one target from >1 source in 10 s | HIGH | not raised while the same source is already flagged as port scanning; heuristic only |
| ARP mapping conflict | same IP announced with a different MAC | HIGH | ignores ARP probes (0.0.0.0) and placeholder MACs; LOW if the old MAC was idle > `stale_after_seconds`; optional trusted `static_mappings` |
| ICMP flood indicator | 100 ICMP packets from one source in 10 s | MEDIUM | echo replies and error messages (types 0, 3, 11) are ignored, so a host that *answers* pings is not flagged |
| Excessive DNS queries | 100 queries from one source in 60 s | MEDIUM | also: burst (20 in 1 s, LOW), unusual name (long / random-looking label, LOW), same unusual name repeated 5× in 60 s (MEDIUM) |
| Blacklisted IP | any packet from a listed address/network | HIGH | reason from `blacklist.json` is included |
| Correlation | one source triggers ≥ 3 different categories in 300 s | CRITICAL | combined behaviour |

Every rule is a **heuristic indicator**, not proof of an attack, and every alert says so in its description.

---

## PHASE 2 — Folder structure

```
mini-ids/
├── main.py               menu (8 options), command-line options, live display loop
├── packet_capture.py     LiveCapture (AsyncSniffer), PcapReplay (sniff offline), interface + privilege checks
├── packet_analyzer.py    Scapy packet → PacketInfo; thread-safe TrafficStats
├── detection_engine.py   all detection rules, sliding-window counters, memory limits
├── alert_manager.py      Alert records, cool-down/de-duplication, correlation, recommended actions
├── database.py           SQLite: sessions + alerts, search by IP, filter by severity, history
├── report_generator.py   HTML report + JSON export
├── ids_monitor.py        wires capture → queue → analysis → detection → alerts for one session
├── blacklist_manager.py  load/add/remove/lookup blacklist.json (IPs and CIDR networks)
├── config_loader.py      loads config.json over defaults and validates every value
├── ui.py                 ASCII banner, colours, tables, SOC dashboard
├── config.json           thresholds and settings
├── blacklist.json        blacklist (ships with RFC 5737 documentation addresses only)
├── requirements.txt
├── PROJECT_STATUS.md     verified vs. not verified
├── reports/html/  reports/json/      generated reports
├── database/ids_alerts.db            created on first run
├── screenshots/          screenshots of the sample report (add your own lab screenshots here)
├── sample_output/        sample report, JSON and dashboard (from the test stand-in, labelled)
├── docs/                 DEMO_GUIDE.md, PROJECT_REPORT.md, VIVA_QUESTIONS.md
└── tests/                pytest suite + Scapy test double
```

---

## PHASE 3 — Installation (Kali Linux / Ubuntu)

```bash
# 1. Python (Kali already has it)
sudo apt update
sudo apt install -y python3 python3-venv python3-pip libpcap0.8 tcpdump

# 2. Virtual environment
cd mini-ids
python3 -m venv venv
source venv/bin/activate

# 3 + 4. Scapy and the other libraries
pip install -r requirements.txt
python3 -c "import scapy; print(scapy.__version__)"

# 5. Capture permissions - choose ONE
sudo venv/bin/python3 main.py                       # a) run as root
sudo setcap cap_net_raw,cap_net_admin=eip "$(readlink -f venv/bin/python3)"   # b) grant capability once
#    (b changes the system python binary the venv points to; undo with: sudo setcap -r <same path>)

# 6. Find your interface
ip -br addr                     # e.g. eth1 with 192.168.56.10 is the host-only adapter
python3 main.py --list-interfaces

# 7. Configuration
nano config.json                # set "interface": "eth1" (your host-only adapter), adjust thresholds
python3 -m pytest -q            # optional: run the automated tests
```

**VirtualBox lab:** File → Tools → Network Manager → create a Host-Only network (default 192.168.56.0/24). Attach Kali and your second authorised VM to it. To see traffic between *other* VMs, set the Kali adapter's *Promiscuous Mode* to *Allow All*. The simplest setup is to send test traffic **to the Kali IDS machine itself**.

---

## PHASE 5 — Running and configuring

```bash
sudo venv/bin/python3 main.py                                   # interactive menu
sudo venv/bin/python3 main.py --monitor -i eth1 --duration 300 --report
sudo venv/bin/python3 main.py --monitor -i eth1 -f "tcp or arp or icmp or port 53" --mode packets
sudo tcpdump -i eth1 -w lab.pcap        # save lab traffic …
python3 main.py --pcap lab.pcap --report                        # … and replay it later (no root needed)
python3 main.py --history | --search 192.168.56.102 | --report-session 3
```

Menu: **1** start monitoring (choose interface, BPF filter, dashboard or packet feed, duration; asks you to confirm authorisation) · **2** active alerts · **3** history (severity filter) · **4** search by IP · **5** manage blacklist · **6** generate report · **7** statistics · **8** exit.

Tuning tips:
* Too many alerts on a busy network? Raise thresholds, or add trusted hosts (backup servers, monitoring) to `engine.trusted_sources`.
* Add your gateway's real MAC to `rules.arp_spoof.static_mappings`. Any ARP reply contradicting it is then flagged, even the first one.
* `alerts.cooldown_seconds` controls how often the same alert may repeat.

## PHASE 6 — Lab demonstrations
See **docs/DEMO_GUIDE.md**.

## PHASE 7 — Sample outputs
`sample_output/sample_report.html`, `sample_alerts.json` and `sample_dashboard.txt`, with screenshots in `screenshots/`. They were produced from the automated-test packet stand-in: 7 ordinary packets plus 3 ICMP packets from the documentation address 203.0.113.50. They are **not** a live capture. Replace them with screenshots from your own lab run.

## PHASE 8 — Documentation
`docs/PROJECT_REPORT.md` (college report, 15 sections) and `docs/VIVA_QUESTIONS.md` (25 questions).

## Tests
```bash
python3 -m pytest -q
```
29 tests cover config validation, packet parsing, statistics, blacklist, alert cool-down, SQLite, reports (including HTML escaping), the capture/replay plumbing, the CLI and the menu. Scapy is replaced by a small test double in `tests/fake_scapy.py`. **The detection rules in `detection_engine.py` have no automated tests in this package.** Verify them in your lab (PROJECT_STATUS.md).
