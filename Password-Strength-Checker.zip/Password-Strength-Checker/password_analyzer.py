"""
Password analysis engine.

How it works (details in README section 8):
    1. Positive points (max 100):
         length (0-30) + character types (10 each, 0-40)
         + entropy bonus (0-20) + "no predictable patterns" bonus (0 or 10)
    2. Penalties for weaknesses: sequences, keyboard runs, repeated characters,
       repeated blocks, common passwords inside, dictionary words,
       "word + digits" shape, years.
    3. Caps: a common password scores at most 10; anything shorter than
       8 characters scores at most 39 (always WEAK).
    4. 0-39 WEAK, 40-69 MEDIUM, 70-100 STRONG.

Important: this is an EDUCATIONAL HEURISTIC. A high score does not guarantee
that a password is safe (it may already be leaked, reused, or guessable from
personal information). The entropy value is a rough character-set estimate,
not a measurement of real-world cracking resistance.

Privacy: the password is never stored, logged, printed or sent anywhere.
AnalysisResult deliberately contains no copy of the password.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import config as C

LEET_MAP = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s",
                          "!": "i", "+": "t"})
KEYBOARD_ROWS = ["qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890", "qazwsxedc", "!@#$%^&*()"]


# ---------------------------------------------------------------------------
# Word lists
# ---------------------------------------------------------------------------
def _load_list(path: Path) -> frozenset[str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return frozenset()
    return frozenset(x.strip().lower() for x in lines if x.strip() and not x.startswith("#"))


BUILTIN_COMMON = frozenset({"password", "password123", "123456", "qwerty", "admin", "welcome", "letmein",
                            "iloveyou", "12345678", "123456789", "abc123", "111111", "passw0rd"})


@lru_cache(maxsize=1)
def common_passwords() -> frozenset[str]:
    """Common passwords from assets/ plus a built-in minimum list (works even if the file is missing)."""
    return _load_list(C.COMMON_PASSWORDS_FILE) | BUILTIN_COMMON


@lru_cache(maxsize=1)
def common_words() -> frozenset[str]:
    return frozenset(w for w in _load_list(C.COMMON_WORDS_FILE) if len(w) >= 4)


# ---------------------------------------------------------------------------
# Result object
# ---------------------------------------------------------------------------
@dataclass
class Finding:
    level: str      # "critical" | "warning" | "info" | "good"
    message: str


@dataclass
class AnalysisResult:
    score: int
    strength: str                       # WEAK | MEDIUM | STRONG
    length: int
    checks: dict[str, bool]             # name -> passed?
    entropy_bits: float
    findings: list[Finding] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    breakdown: list[tuple[str, int]] = field(default_factory=list)   # how the score was calculated
    zxcvbn: dict | None = None          # optional extra opinion, if the zxcvbn library is installed

    def __repr__(self) -> str:          # never shows the password - it is not stored at all
        return f"AnalysisResult(score={self.score}, strength={self.strength}, length={self.length})"


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------
def character_types(password: str) -> dict[str, bool]:
    return {
        "uppercase": any(c.isascii() and c.isupper() for c in password),
        "lowercase": any(c.isascii() and c.islower() for c in password),
        "digits": any(c.isdigit() for c in password),
        "special": any(c in C.SPECIAL_CHARACTERS for c in password),
        "other": any(not c.isascii() for c in password),
    }


def entropy_estimate(password: str) -> float:
    """
    Character-set entropy estimate: length x log2(size of the character pool).
    It assumes every character was chosen RANDOMLY - real passwords rarely are,
    so this over-estimates human-chosen passwords. Use it only for comparison.
    """
    if not password:
        return 0.0
    t = character_types(password)
    pool = (C.POOL_LOWER * t["lowercase"] + C.POOL_UPPER * t["uppercase"] + C.POOL_DIGITS * t["digits"]
            + C.POOL_SPECIAL * t["special"] + C.POOL_OTHER * t["other"])
    return round(len(password) * math.log2(max(pool, 2)), 1)


def find_sequences(password: str, min_run: int = 3) -> list[str]:
    """Runs like abc, 123, xyz or their reverse (cba, 321)."""
    found, low = [], password.lower()
    i = 0
    while i < len(low) - 1:
        j = i
        step = ord(low[i + 1]) - ord(low[i])
        if step in (1, -1) and (low[i].isalnum() and low[i + 1].isalnum()) and \
                low[i].isdigit() == low[i + 1].isdigit():
            while j + 1 < len(low) and ord(low[j + 1]) - ord(low[j]) == step and low[j + 1].isalnum() and \
                    low[j + 1].isdigit() == low[i].isdigit():
                j += 1
        if j - i + 1 >= min_run:
            found.append(password[i:j + 1])
            i = j + 1
        else:
            i += 1
    return found


def find_keyboard_runs(password: str, min_run: int = 4) -> list[str]:
    """Adjacent keys such as qwer, asdf, zxcv (also typed backwards)."""
    low, found = password.lower(), []
    i = 0
    while i <= len(low) - min_run:
        best = 0
        for row in KEYBOARD_ROWS:
            for r in (row, row[::-1]):
                n = min_run
                while i + n <= len(low) and low[i:i + n] in r:
                    best = max(best, n)
                    n += 1
        if best:
            found.append(password[i:i + best])
            i += best
        else:
            i += 1
    return found


def find_repeats(password: str) -> list[str]:
    """Three or more identical characters in a row (aaa, 111, !!!)."""
    return [m.group(0) for m in re.finditer(r"(.)\1{2,}", password)]


def find_repeated_chunks(password: str) -> list[str]:
    """A block of 2+ characters repeated straight after itself (abcabc, 1212, hahaha)."""
    return [m.group(0) for m in re.finditer(r"(.{2,}?)\1+", password) if len(set(m.group(1))) > 1]


def normalise(password: str) -> str:
    """Lowercase, strip trailing digits/symbols and undo common 'leet' substitutions (P@ssw0rd -> password)."""
    core = re.sub(r"[^A-Za-z]+$", "", password) or password
    return core.lower().translate(LEET_MAP)


def common_password_match(password: str) -> tuple[bool, list[str]]:
    """
    Returns (is_common, contained):
        is_common  - the password itself is a common password (exact, case-insensitive,
                     or after stripping trailing numbers/symbols and leet substitutions)
        contained  - common passwords of 6+ characters found inside it
    """
    commons = common_passwords()
    low = password.lower()
    is_common = low in commons or normalise(password) in commons or low.translate(LEET_MAP) in commons
    if is_common:
        return True, []
    variants = {low, low.translate(LEET_MAP)}
    contained = sorted({c for c in commons if len(c) >= 6 and any(c in v for v in variants)}, key=len,
                       reverse=True)
    # keep only the longest non-overlapping ones (e.g. "password123" rather than also "password")
    result = []
    for c in contained:
        if not any(c in r for r in result):
            result.append(c)
    return False, result


def dictionary_words(password: str, exclude: list[str] | None = None) -> list[str]:
    low = password.lower().translate(LEET_MAP)
    words = [w for w in common_words() if w in low]
    words = [w for w in words if not any(w in longer for longer in words if longer != w)]   # drop "star" if "stars"
    if exclude:
        words = [w for w in words if not any(w in e for e in exclude)]
    return sorted(words)


def has_word_digit_shape(password: str) -> bool:
    """Letters followed by digits at the end, e.g. Summer2024, CyberSecure24, john123."""
    return bool(re.fullmatch(r"[A-Za-z]{3,}\d{1,6}[!.?]?", password))


def find_years(password: str) -> list[str]:
    return re.findall(r"(?<!\d)(19[5-9]\d|20[0-3]\d)(?!\d)", password)


# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------
def classify(score: int) -> str:
    if score <= C.WEAK_MAX:
        return "WEAK"
    if score <= C.MEDIUM_MAX:
        return "MEDIUM"
    return "STRONG"


def _zxcvbn_opinion(password: str) -> dict | None:
    """Optional second opinion from a LOCALLY installed zxcvbn library (no network use)."""
    try:
        from zxcvbn import zxcvbn   # type: ignore
    except ImportError:
        return None
    try:
        r = zxcvbn(password[:100])
        return {"score": r.get("score"), "guesses_log10": round(float(r.get("guesses_log10", 0)), 1),
                "warning": (r.get("feedback") or {}).get("warning", "")}
    except Exception:   # noqa: BLE001 - optional library must never break the app
        return None


def analyze_password(password: str, use_zxcvbn: bool = True) -> AnalysisResult:
    """Analyse a password locally. Raises ValueError for empty input."""
    if password is None or password == "":
        raise ValueError("Please enter a password to analyse.")
    if not isinstance(password, str):
        raise ValueError("The password must be text.")
    if len(password) > 1024:
        raise ValueError("Passwords longer than 1024 characters are not analysed.")

    n = len(password)
    types = character_types(password)
    entropy = entropy_estimate(password)
    findings: list[Finding] = []
    recs: list[str] = []
    breakdown: list[tuple[str, int]] = []

    # ---- positive points -----------------------------------------------
    length_pts = min(C.LENGTH_MAX_POINTS, round(n * C.LENGTH_MAX_POINTS / C.LENGTH_FULL_POINTS))
    breakdown.append((f"Length ({n} characters)", length_pts))
    type_names = {"uppercase": "Uppercase letters", "lowercase": "Lowercase letters", "digits": "Numbers",
                  "special": "Special characters"}
    for key, label in type_names.items():
        if types[key]:
            breakdown.append((label, C.CLASS_POINTS))
    if types["other"] and not types["special"]:
        breakdown.append(("Non-ASCII characters (counted as special)", C.CLASS_POINTS))
    span = C.ENTROPY_FULL_BITS - C.ENTROPY_MIN_BITS
    entropy_pts = round(min(1.0, max(0.0, (entropy - C.ENTROPY_MIN_BITS) / span)) * C.ENTROPY_MAX_POINTS)
    breakdown.append((f"Entropy estimate bonus ({entropy:.0f} bits)", entropy_pts))

    # ---- weaknesses ------------------------------------------------------
    sequences = find_sequences(password)
    keyboard = find_keyboard_runs(password)
    repeats = find_repeats(password)
    chunks = find_repeated_chunks(password)
    is_common, contained = common_password_match(password)
    words = dictionary_words(password, exclude=contained)
    word_digits = has_word_digit_shape(password)
    years = find_years(password)

    patterns_found = bool(sequences or keyboard or repeats or chunks)
    if not patterns_found:
        breakdown.append(("No sequences, keyboard runs or repeats", C.NO_PATTERN_POINTS))
    if sequences:
        breakdown.append((f"Sequential characters: {', '.join(sequences)}",
                          -min(C.PENALTY_SEQUENCE * len(sequences), C.PENALTY_SEQUENCE_MAX)))
    if keyboard:
        breakdown.append((f"Keyboard pattern: {', '.join(keyboard)}",
                          -min(C.PENALTY_KEYBOARD * len(keyboard), C.PENALTY_KEYBOARD_MAX)))
    if repeats:
        breakdown.append((f"Repeated characters: {', '.join(repeats)}", -C.PENALTY_REPEAT))
    if chunks:
        breakdown.append((f"Repeated block: {', '.join(chunks)}", -C.PENALTY_REPEATED_CHUNK))
    if contained:
        breakdown.append((f"Contains a common password: {', '.join(contained)}", -C.PENALTY_COMMON_SUBSTRING))
    if words:
        breakdown.append((f"Dictionary words: {', '.join(words)}",
                          -min(C.PENALTY_DICTIONARY_WORD * len(words), C.PENALTY_DICTIONARY_MAX)))
    if word_digits:
        breakdown.append(("Predictable shape: word(s) followed by numbers", -C.PENALTY_WORD_DIGITS))
    if years:
        breakdown.append((f"Contains a year: {', '.join(years)}", -C.PENALTY_YEAR))

    # Final score. Every adjustment is added to the breakdown, so its lines always sum to the score.
    score = sum(points for _, points in breakdown)
    if score > 100:
        breakdown.append(("Maximum score is 100", 100 - score))
        score = 100
    if score < 0:
        breakdown.append(("Score cannot go below 0", -score))
        score = 0
    if is_common and score > C.CAP_COMMON_PASSWORD:
        breakdown.append((f"Cap: common password (score limited to {C.CAP_COMMON_PASSWORD})",
                          C.CAP_COMMON_PASSWORD - score))
        score = C.CAP_COMMON_PASSWORD
    elif n < C.MIN_LENGTH and score > C.CAP_TOO_SHORT:
        breakdown.append((f"Cap: shorter than {C.MIN_LENGTH} characters (score limited to {C.CAP_TOO_SHORT})",
                          C.CAP_TOO_SHORT - score))
        score = C.CAP_TOO_SHORT
    strength = classify(score)

    # ---- findings (what we observed) -------------------------------------
    if is_common:
        findings.append(Finding("critical", "This is a commonly used password (or a simple variation of one). "
                                            "Attackers try these first - it can be guessed almost instantly."))
    if n < C.MIN_LENGTH:
        findings.append(Finding("critical", f"Too short: {n} characters (minimum {C.MIN_LENGTH}, "
                                            f"recommended {C.RECOMMENDED_LENGTH}-{C.IDEAL_LENGTH})."))
    elif n < C.RECOMMENDED_LENGTH:
        findings.append(Finding("warning", f"Length {n} is acceptable but short; "
                                           f"{C.RECOMMENDED_LENGTH}-{C.IDEAL_LENGTH}+ characters is recommended."))
    else:
        findings.append(Finding("good", f"Good length: {n} characters."))
    missing = [type_names[k].lower() for k in type_names if not types[k]]
    if missing:
        findings.append(Finding("warning", "Missing character types: " + ", ".join(missing) + "."))
    else:
        findings.append(Finding("good", "Uses all four character types."))
    for label, items in (("Sequential characters", sequences), ("Keyboard pattern", keyboard),
                         ("Repeated characters", repeats), ("Repeated block", chunks)):
        if items:
            findings.append(Finding("warning", f"{label} detected: {', '.join(items)}."))
    if contained:
        findings.append(Finding("critical", f"Contains a common password: {', '.join(contained)}."))
    if words:
        findings.append(Finding("info", f"Contains dictionary word(s): {', '.join(words)}. Words are tried early "
                                        "in dictionary attacks; several unrelated words plus length help."))
    if word_digits:
        findings.append(Finding("warning", "Predictable structure: letters followed by numbers at the end "
                                           "(e.g. Name2024). Attack tools try this shape very early."))
    if years:
        findings.append(Finding("info", f"Contains a year ({', '.join(years)}) - birth years and dates are easy "
                                        "to guess."))
    if not patterns_found and not is_common:
        findings.append(Finding("good", "No sequences, keyboard runs or repeated characters found."))
    findings.append(Finding("info", f"Entropy estimate: about {entropy:.0f} bits (character-set estimate only - "
                                    "it assumes random characters, so it over-rates human-chosen passwords)."))

    # ---- personalised recommendations -------------------------------------
    if is_common or contained:
        recs.append("Avoid common passwords and simple variations of them (e.g. adding 123 or replacing a with @).")
    if n < C.RECOMMENDED_LENGTH:
        recs.append(f"Increase the length to at least {C.RECOMMENDED_LENGTH}-{C.IDEAL_LENGTH} characters - length "
                    "adds the most strength.")
    if not types["uppercase"]:
        recs.append("Add uppercase letters (A-Z).")
    if not types["lowercase"]:
        recs.append("Add lowercase letters (a-z).")
    if not types["digits"]:
        recs.append("Add numbers (0-9).")
    if not types["special"]:
        recs.append("Add special characters such as ! @ # $ % & *.")
    if sequences or keyboard:
        recs.append("Avoid predictable sequences such as 123, abc, qwerty or asdf.")
    if repeats or chunks:
        recs.append("Avoid repeating the same character or block (aaa, 111, abcabc).")
    if word_digits:
        recs.append("Do not just add numbers to the end of a word - mix symbols and numbers inside the password.")
    if years:
        recs.append("Avoid years, birthdays and other personal dates.")
    if words and n < C.IDEAL_LENGTH:
        recs.append("If you use words, combine three or more unrelated words into a long passphrase.")
    recs.append("Use a unique password for every account, so one leak cannot unlock the others.")
    recs.append("Use a password manager to create and remember strong passwords, and turn on multi-factor "
                "authentication (MFA) where available.")

    checks = {
        f"At least {C.MIN_LENGTH} characters": n >= C.MIN_LENGTH,
        f"{C.RECOMMENDED_LENGTH}+ characters (recommended)": n >= C.RECOMMENDED_LENGTH,
        "Uppercase letters (A-Z)": types["uppercase"],
        "Lowercase letters (a-z)": types["lowercase"],
        "Numbers (0-9)": types["digits"],
        "Special characters (!@#$...)": types["special"],
        "Not a common password": not is_common and not contained,
        "No sequences, keyboard runs or repeats": not patterns_found,
    }
    return AnalysisResult(score=score, strength=strength, length=n, checks=checks, entropy_bits=entropy,
                          findings=findings, recommendations=recs, breakdown=breakdown,
                          zxcvbn=_zxcvbn_opinion(password) if use_zxcvbn else None)


def format_report(result: AnalysisResult) -> str:
    """Plain-text report. It never contains the password itself."""
    lines = [
        f"{C.APP_TITLE} - analysis report",
        "Password: [not stored or shown] (length %d)" % result.length,
        f"Strength: {result.strength}    Score: {result.score}/100    Entropy estimate: ~{result.entropy_bits:.0f} bits",
        "", "Checklist:",
    ]
    lines += [f"  [{'PASS' if ok else 'FAIL'}] {name}" for name, ok in result.checks.items()]
    lines += ["", "How the score was calculated:"]
    lines += [f"  {points:+4d}  {label}" for label, points in result.breakdown]
    lines += [f"  ----  final score {result.score}/100 -> {result.strength}", "", "Findings:"]
    lines += [f"  - [{f.level.upper()}] {f.message}" for f in result.findings]
    lines += ["", "Recommendations:"]
    lines += [f"  {i}. {r}" for i, r in enumerate(result.recommendations, 1)]
    if result.zxcvbn:
        lines += ["", f"zxcvbn (local library) score: {result.zxcvbn['score']}/4, "
                      f"about 10^{result.zxcvbn['guesses_log10']} guesses"]
    lines += ["", "Note: this score is an educational heuristic, not a guarantee of security."]
    return "\n".join(lines)


__all__ = ["analyze_password", "AnalysisResult", "Finding", "classify", "entropy_estimate", "format_report"]
