#!/usr/bin/env bash
# Run every automated test (uses Python's built-in unittest - no extra packages needed).
cd "$(dirname "$0")"
[ -d venv ] && source venv/bin/activate
python3 -m unittest discover -s tests -t . -v
