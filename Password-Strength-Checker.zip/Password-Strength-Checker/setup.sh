#!/usr/bin/env bash
# One-time setup on Kali Linux / Debian / Ubuntu.
set -e
cd "$(dirname "$0")"
echo "== Password Strength Checker setup =="
python3 --version
sudo apt update
sudo apt install -y python3 python3-venv python3-tk
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt
echo "Setup complete. Start the app with:  ./run.sh"
