"""
Terminal version of the Password Strength Checker (fallback when Tkinter is
not available, or when started with ``python3 main.py --cli``).

The password is typed with ``getpass`` so it is not shown on screen, it is
never printed, and it is not accepted as a command-line argument (arguments
end up in the shell history and in process lists).
"""

from __future__ import annotations

import getpass

import config as C
from password_analyzer import analyze_password, format_report
from password_generator import generate_password

GREEN, RED, YELLOW, BOLD, RESET = "\033[92m", "\033[91m", "\033[93m", "\033[1m", "\033[0m"
COLOR = {"WEAK": RED, "MEDIUM": YELLOW, "STRONG": GREEN}


def bar(score: int, width: int = 30) -> str:
    filled = round(score / 100 * width)
    return "[" + "#" * filled + "-" * (width - filled) + "]"


def show_result(result) -> None:
    c = COLOR[result.strength]
    print(f"\n{BOLD}Strength:{RESET} {c}{BOLD}{result.strength}{RESET}   Score: {result.score}/100  "
          f"{c}{bar(result.score)}{RESET}")
    print(format_report(result).split("\n", 3)[3])     # report without the duplicated header lines


def analyze_interactive() -> None:
    try:
        pw = getpass.getpass("Enter password to analyse (input is hidden): ")
    except (EOFError, KeyboardInterrupt):
        print()
        return
    try:
        show_result(analyze_password(pw))
    except ValueError as exc:
        print(f"{RED}{exc}{RESET}")
    finally:
        pw = ""   # drop our reference to the password straight away  # noqa: F841


def generate_interactive() -> None:
    raw = input(f"Length [{C.GEN_DEFAULT_LENGTH}] ({C.GEN_MIN_LENGTH}-{C.GEN_MAX_LENGTH}): ").strip()
    try:
        pw = generate_password(int(raw) if raw else C.GEN_DEFAULT_LENGTH)
    except ValueError as exc:
        print(f"{RED}{exc}{RESET}")
        return
    print(f"\nGenerated password: {BOLD}{pw}{RESET}")
    print("It has not been saved anywhere. Copy it into your password manager now.")
    result = analyze_password(pw)
    print(f"Its score: {result.score}/100 ({result.strength})")


def main() -> int:
    print(f"{GREEN}{BOLD}{C.APP_TITLE}{RESET} - terminal mode (v{C.APP_VERSION})")
    print("All analysis happens locally. Passwords are never stored, logged or sent anywhere.")
    while True:
        print(f"\n  {BOLD}1{RESET}) Analyse a password\n  {BOLD}2{RESET}) Generate a secure password\n"
              f"  {BOLD}q{RESET}) Quit")
        try:
            choice = input("Choose: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if choice == "1":
            analyze_interactive()
        elif choice == "2":
            generate_interactive()
        elif choice in ("q", "quit", "exit"):
            return 0
        else:
            print("Please choose 1, 2 or q.")


if __name__ == "__main__":
    raise SystemExit(main())
