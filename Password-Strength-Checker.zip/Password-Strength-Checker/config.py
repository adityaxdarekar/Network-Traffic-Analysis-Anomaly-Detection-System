"""
Configuration for the Password Strength Checker.

All scoring weights, thresholds and colours live here so the scoring method
is easy to read, explain in a viva, and adjust.
"""

from pathlib import Path

APP_TITLE = "Password Strength Checker"
APP_SUBTITLE = "Python-Based Password Strength Checker and Security Analyzer"
APP_VERSION = "1.0.0"

BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
REPORTS_DIR = BASE_DIR / "reports"
COMMON_PASSWORDS_FILE = ASSETS_DIR / "common_passwords.txt"
COMMON_WORDS_FILE = ASSETS_DIR / "common_words.txt"

# ---------------------------------------------------------------------------
# Scoring (0-100). See README section 8 "Password scoring methodology".
# ---------------------------------------------------------------------------
# Positive points
LENGTH_MAX_POINTS = 30          # 30 points are reached at LENGTH_FULL_POINTS characters
LENGTH_FULL_POINTS = 16
CLASS_POINTS = 10               # per character type present (4 types -> 40 points)
ENTROPY_MAX_POINTS = 20         # entropy bonus, scaled between the two values below
ENTROPY_MIN_BITS = 28           # no bonus at or below this estimate
ENTROPY_FULL_BITS = 80          # full bonus at or above this estimate
NO_PATTERN_POINTS = 10          # awarded when no repeats/sequences/keyboard runs are found

# Penalties
PENALTY_SEQUENCE = 10           # per sequential run (abc, 123, cba ...), max PENALTY_SEQUENCE_MAX
PENALTY_SEQUENCE_MAX = 20
PENALTY_KEYBOARD = 10           # keyboard runs (qwer, asdf ...), max PENALTY_KEYBOARD_MAX
PENALTY_KEYBOARD_MAX = 20
PENALTY_REPEAT = 10             # 3+ identical characters in a row (aaa, 111)
PENALTY_REPEATED_CHUNK = 10     # a repeated block (abcabc, 123123)
PENALTY_COMMON_SUBSTRING = 25   # contains a common password (e.g. "password" inside)
PENALTY_DICTIONARY_WORD = 5     # per common word of 4+ letters, max PENALTY_DICTIONARY_MAX
PENALTY_DICTIONARY_MAX = 10
PENALTY_WORD_DIGITS = 15        # predictable shape: letters followed by digits at the end
PENALTY_YEAR = 5                # contains a year 1950-2039

# Caps (hard limits)
CAP_COMMON_PASSWORD = 10        # the password IS a common password (after simple normalisation)
CAP_TOO_SHORT = 39              # shorter than MIN_LENGTH -> always WEAK
MIN_LENGTH = 8
RECOMMENDED_LENGTH = 12
IDEAL_LENGTH = 16

# Classification
WEAK_MAX = 39                   # 0-39   WEAK
MEDIUM_MAX = 69                 # 40-69  MEDIUM, 70-100 STRONG

# Character pools used for the entropy estimate
SPECIAL_CHARACTERS = r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~ """
POOL_LOWER, POOL_UPPER, POOL_DIGITS, POOL_SPECIAL, POOL_OTHER = 26, 26, 10, len(SPECIAL_CHARACTERS), 100

# Generator limits
GEN_MIN_LENGTH = 8
GEN_MAX_LENGTH = 64
GEN_DEFAULT_LENGTH = 16
GEN_AMBIGUOUS = "Il1O0o|`'\""
CLIPBOARD_CLEAR_SECONDS = 30    # the GUI clears a copied password from the clipboard after this delay

# ---------------------------------------------------------------------------
# GUI theme (dark navy / black with green accents)
# ---------------------------------------------------------------------------
COLORS = {
    "bg": "#0a0f1c",
    "panel": "#111a2e",
    "panel_alt": "#16213a",
    "border": "#1f2d4a",
    "text": "#e5edf7",
    "muted": "#8fa3c0",
    "accent": "#22c55e",       # green
    "accent_dark": "#16a34a",
    "entry_bg": "#0d1526",
    "weak": "#ef4444",
    "medium": "#f59e0b",
    "strong": "#22c55e",
    "pass": "#22c55e",
    "fail": "#ef4444",
}
STRENGTH_COLORS = {"WEAK": COLORS["weak"], "MEDIUM": COLORS["medium"], "STRONG": COLORS["strong"]}
FONT_FAMILY = "DejaVu Sans"      # installed on Kali by default; Tk falls back automatically elsewhere
MONO_FAMILY = "DejaVu Sans Mono"
