"""
A minimal stand-in for tkinter / tkinter.ttk / tkinter.messagebox.

It lets the test-suite build the REAL PasswordCheckerApp and press every
button on machines without a display or without Tk installed. Widgets record
their options; variables store values; Text widgets keep their text; the
clipboard and after() timers are simulated. It is NOT a GUI - the final visual
check is done by running ``python3 main.py`` on Kali.
"""

from __future__ import annotations

import sys
import types


class TclError(Exception):
    pass


class Variable:
    def __init__(self, master=None, value=None):
        self._value = value if value is not None else self._default

    def get(self):
        return self._value

    def set(self, value):
        self._value = value


class StringVar(Variable):
    _default = ""


class BooleanVar(Variable):
    _default = False

    def get(self):
        return bool(self._value)


class IntVar(Variable):
    _default = 0

    def get(self):
        return int(self._value)


class Widget:
    instances: list["Widget"] = []

    def __init__(self, master=None, **options):
        self.master = master
        self.options = dict(options)
        self.bindings = {}
        self.focused = False
        Widget.instances.append(self)

    def configure(self, **options):
        self.options.update(options)

    config = configure

    def cget(self, key):
        return self.options.get(key)

    def __getitem__(self, key):
        return self.options.get(key)

    def pack(self, **kw):
        self.packed = kw

    def grid(self, **kw):
        self.gridded = kw

    def columnconfigure(self, *a, **k):
        pass

    rowconfigure = columnconfigure

    def bind(self, event, func):
        self.bindings[event] = func

    def focus_set(self):
        self.focused = True

    def invoke(self):
        """Simulate a click on a button / checkbutton."""
        cmd = self.options.get("command")
        if "variable" in self.options and isinstance(self.options["variable"], BooleanVar):
            v = self.options["variable"]
            v.set(not v.get())
        if cmd:
            return cmd()


class Text(Widget):
    def __init__(self, master=None, **options):
        super().__init__(master, **options)
        self.content = ""
        self.tags = {}

    def tag_configure(self, name, **kw):
        self.tags[name] = kw

    def insert(self, index, text, *tags):
        if self.options.get("state") == "disabled":
            return                       # like Tk: a disabled Text ignores inserts
        self.content += text

    def delete(self, start, end=None):
        if self.options.get("state") == "disabled":
            return
        self.content = ""

    def get(self, start="1.0", end="end"):
        return self.content


class Tk(Widget):
    def __init__(self):
        super().__init__(None)
        self.clipboard = None
        self.timers = {}
        self._next = 0
        self.destroyed = False

    def title(self, t):
        self.options["title"] = t

    def geometry(self, g):
        self.options["geometry"] = g

    def minsize(self, w, h):
        pass

    def protocol(self, name, func):
        self.bindings[name] = func

    def clipboard_clear(self):
        self.clipboard = None

    def clipboard_append(self, text):
        self.clipboard = (self.clipboard or "") + text

    def clipboard_get(self):
        if self.clipboard is None:
            raise TclError("CLIPBOARD selection doesn't exist")
        return self.clipboard

    def after(self, ms, func):
        self._next += 1
        self.timers[f"after#{self._next}"] = (ms, func)
        return f"after#{self._next}"

    def after_cancel(self, job):
        self.timers.pop(job, None)

    def run_timers(self):
        jobs, self.timers = self.timers, {}
        for _ms, func in jobs.values():
            func()

    def destroy(self):
        self.destroyed = True

    def mainloop(self):
        pass


class Notebook(Widget):
    def __init__(self, master=None, **options):
        super().__init__(master, **options)
        self.tabs = []
        self.selected = None

    def add(self, child, **kw):
        self.tabs.append(child)
        self.selected = self.selected or child

    def select(self, child=None):
        if child is not None:
            self.selected = child
        return self.selected


class Style:
    def __init__(self, master=None):
        self.styles = {}

    def theme_use(self, name=None):
        return "clam"

    def configure(self, name, **kw):
        self.styles.setdefault(name, {}).update(kw)

    def map(self, name, **kw):
        pass


class MessageLog:
    calls: list[tuple[str, str]] = []


def _msg(kind):
    def f(title, message, **kw):
        MessageLog.calls.append((kind, message))
        return "ok"
    return f


def install() -> None:
    tk = types.ModuleType("tkinter")
    for name, obj in {"Tk": Tk, "Text": Text, "Label": Widget, "Frame": Widget, "Entry": Widget,
                      "Button": Widget, "Checkbutton": Widget, "TclError": TclError, "StringVar": StringVar,
                      "BooleanVar": BooleanVar, "IntVar": IntVar}.items():
        setattr(tk, name, obj)
    ttk = types.ModuleType("tkinter.ttk")
    for name in ("Frame", "Label", "Entry", "Button", "Checkbutton", "Progressbar", "Scale", "Separator"):
        setattr(ttk, name, type(name, (Widget,), {}))
    ttk.Notebook, ttk.Style = Notebook, Style
    mb = types.ModuleType("tkinter.messagebox")
    mb.showinfo, mb.showwarning, mb.showerror = _msg("info"), _msg("warning"), _msg("error")
    tk.ttk, tk.messagebox = ttk, mb
    sys.modules.update({"tkinter": tk, "tkinter.ttk": ttk, "tkinter.messagebox": mb})
    sys.modules.pop("gui", None)
