"""
Unit tests for the analysis engine (unittest - run with  python3 -m unittest -v  or  pytest).

Test cases 1-10 are the ones required by the project brief; the expected
scores follow directly from the documented scoring method (README section 8).
"""

import io
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config as C  # noqa: E402
from password_analyzer import (analyze_password, classify, common_password_match, entropy_estimate,  # noqa: E402
                               find_keyboard_runs, find_repeated_chunks, find_repeats, find_sequences,
                               format_report)


def check(test, password, strength, score=None):
    r = analyze_password(password, use_zxcvbn=False)
    test.assertEqual(r.strength, strength, f"{password!r} scored {r.score}")
    if score is not None:
        test.assertEqual(r.score, score, f"{password!r}")
    test.assertEqual(sum(p for _, p in r.breakdown), r.score, "breakdown must add up to the score")
    return r


class RequiredTestCases(unittest.TestCase):
    def test_01_very_short_password(self):
        r = check(self, "Ab1!", "WEAK")
        self.assertLessEqual(r.score, C.CAP_TOO_SHORT)
        self.assertFalse(r.checks["At least 8 characters"])
        self.assertTrue(any("Too short" in f.message for f in r.findings))

    def test_02_common_password(self):
        for pw in ("password", "123456", "qwerty", "admin", "welcome", "letmein", "iloveyou", "Password123"):
            r = check(self, pw, "WEAK")
            self.assertLessEqual(r.score, C.CAP_COMMON_PASSWORD, pw)
            self.assertFalse(r.checks["Not a common password"])

    def test_03_numbers_only(self):
        r = check(self, "84720519", "WEAK")
        self.assertTrue(r.checks["Numbers (0-9)"])
        self.assertFalse(r.checks["Lowercase letters (a-z)"])
        self.assertIn("Add lowercase letters (a-z).", r.recommendations)

    def test_04_lowercase_only(self):
        r = check(self, "bluehouse", "WEAK", 32)
        self.assertEqual([k for k, v in r.checks.items() if not v],
                         ["12+ characters (recommended)", "Uppercase letters (A-Z)", "Numbers (0-9)",
                          "Special characters (!@#$...)"])

    def test_05_upper_and_lower(self):
        r = check(self, "SunnyBeach", "MEDIUM", 55)
        self.assertTrue(r.checks["Uppercase letters (A-Z)"] and r.checks["Lowercase letters (a-z)"])

    def test_06_special_characters(self):
        r = check(self, "Kx9#mQ2$vL7!pR4z", "STRONG", 100)
        self.assertTrue(r.checks["Special characters (!@#$...)"])

    def test_07_repeated_characters(self):
        r = check(self, "Hellooo111", "WEAK")
        self.assertIn(("Repeated characters: ooo, 111", -C.PENALTY_REPEAT), r.breakdown)
        self.assertFalse(r.checks["No sequences, keyboard runs or repeats"])

    def test_08_sequential_characters(self):
        r = check(self, "abcd1234", "WEAK", 0)
        self.assertTrue(any("Sequential characters: abcd, 1234" in label for label, _ in r.breakdown))

    def test_09_medium_password(self):
        check(self, "CyberSecure24", "MEDIUM", 58)

    def test_10_strong_passphrase(self):
        r = check(self, "Violet!River82Moon", "STRONG", 90)
        self.assertTrue(all(r.checks.values()))


class DemonstrationExamples(unittest.TestCase):
    """The three examples used in front of the professor must always classify this way."""

    def test_weak(self):
        r = check(self, "password123", "WEAK", 10)
        self.assertTrue(any(f.level == "critical" and "commonly used" in f.message for f in r.findings))

    def test_medium(self):
        r = check(self, "CyberSecure24", "MEDIUM", 58)
        self.assertIn("Add special characters such as ! @ # $ % & *.", r.recommendations)
        self.assertTrue(any("Predictable shape" in label for label, _ in r.breakdown))

    def test_strong(self):
        r = check(self, "Violet!River82Moon", "STRONG", 90)
        self.assertGreater(r.entropy_bits, 100)


class Detection(unittest.TestCase):
    def test_sequences(self):
        self.assertEqual(find_sequences("xabc9876y"), ["abc", "9876"])
        self.assertEqual(find_sequences("a1b2c3"), [])
        self.assertEqual(find_sequences("zyx"), ["zyx"])

    def test_keyboard(self):
        self.assertEqual(find_keyboard_runs("myqwerty!"), ["qwerty"])
        self.assertEqual(find_keyboard_runs("LKJH"), ["LKJH"])
        self.assertEqual(find_keyboard_runs("asd"), [])       # 3 keys is not enough

    def test_repeats_and_chunks(self):
        self.assertEqual(find_repeats("aa bbb 1111"), ["bbb", "1111"])
        self.assertEqual(find_repeated_chunks("xabcabcx"), ["abcabc"])
        self.assertEqual(find_repeated_chunks("aaaa"), [])     # handled by find_repeats instead

    def test_common_variations(self):
        self.assertTrue(common_password_match("P@ssw0rd!")[0])        # leet + trailing symbol
        self.assertTrue(common_password_match("Summer2024")[0])       # word + digits
        self.assertTrue(common_password_match("QWERTY")[0])           # case-insensitive
        is_common, inside = common_password_match("MyPassword2024!")
        self.assertFalse(is_common)
        self.assertEqual(inside, ["password"])

    def test_classification_boundaries(self):
        self.assertEqual([classify(s) for s in (0, 39, 40, 69, 70, 100)],
                         ["WEAK", "WEAK", "MEDIUM", "MEDIUM", "STRONG", "STRONG"])

    def test_entropy_estimate(self):
        self.assertEqual(entropy_estimate(""), 0.0)
        self.assertAlmostEqual(entropy_estimate("abcdefgh"), 37.6, places=1)       # 8 x log2(26)
        self.assertGreater(entropy_estimate("Aa1!Aa1!"), entropy_estimate("aaaaaaaa"))

    def test_year_and_word_digits(self):
        r = analyze_password("Galaxy1999", use_zxcvbn=False)
        labels = " ".join(label for label, _ in r.breakdown)
        self.assertIn("Contains a year: 1999", labels)
        self.assertIn("Predictable shape", labels)


class Robustness(unittest.TestCase):
    def test_empty_and_invalid_input(self):
        for bad in ("", None, 12345, "x" * 2000):
            with self.assertRaises(ValueError):
                analyze_password(bad)

    def test_unicode_and_spaces(self):
        r = check(self, "Grüße aus Köln 2 Freunde", "STRONG")
        self.assertTrue(r.length == 24 and r.checks["Special characters (!@#$...)"])

    def test_scores_always_in_range(self):
        import secrets
        for _ in range(300):
            pw = "".join(secrets.choice("aA1!qwe123 abcxyz@#ü") for _ in range(secrets.randbelow(40) + 1))
            r = analyze_password(pw, use_zxcvbn=False)
            self.assertTrue(0 <= r.score <= 100)
            self.assertEqual(r.strength, classify(r.score))
            self.assertEqual(sum(p for _, p in r.breakdown), r.score)

    def test_works_without_word_list_files(self):
        import password_analyzer as pa
        pa.common_passwords.cache_clear()
        pa.common_words.cache_clear()
        with mock.patch.object(C, "COMMON_PASSWORDS_FILE", Path("/nonexistent/x.txt")), \
                mock.patch.object(C, "COMMON_WORDS_FILE", Path("/nonexistent/y.txt")):
            self.assertEqual(analyze_password("password123").strength, "WEAK")   # built-in list still works
        pa.common_passwords.cache_clear()
        pa.common_words.cache_clear()


class Privacy(unittest.TestCase):
    SECRET = "Unique!Secret#Value42"

    def test_result_and_report_never_contain_password(self):
        r = analyze_password(self.SECRET)
        self.assertNotIn(self.SECRET, repr(r))
        self.assertNotIn(self.SECRET, str(r.__dict__))
        self.assertNotIn(self.SECRET, format_report(r))
        self.assertIn("[not stored or shown]", format_report(r))

    def test_nothing_printed(self):
        with mock.patch("sys.stdout", new_callable=io.StringIO) as out:
            analyze_password(self.SECRET)
        self.assertEqual(out.getvalue(), "")

    def test_no_network_modules_used(self):
        source = (Path(__file__).resolve().parent.parent / "password_analyzer.py").read_text()
        for module in ("socket", "requests", "urllib", "http.client"):
            self.assertNotIn(f"import {module}", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
