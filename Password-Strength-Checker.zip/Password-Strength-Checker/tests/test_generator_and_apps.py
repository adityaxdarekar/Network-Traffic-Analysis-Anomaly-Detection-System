"""Tests for the generator, the terminal version, main.py and the Tkinter GUI (via tests/tk_stub.py)."""

import io
import string
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config as C  # noqa: E402
from password_analyzer import analyze_password  # noqa: E402
from password_generator import SYMBOLS, generate_password  # noqa: E402


class GeneratorTests(unittest.TestCase):
    def test_length_and_all_types(self):
        for length in (8, 16, 33, 64):
            pw = generate_password(length)
            self.assertEqual(len(pw), length)
            self.assertTrue(any(c.isupper() for c in pw) and any(c.islower() for c in pw))
            self.assertTrue(any(c.isdigit() for c in pw) and any(c in SYMBOLS for c in pw))

    def test_selected_types_only(self):
        pw = generate_password(20, uppercase=False, lowercase=True, digits=True, symbols=False)
        self.assertTrue(set(pw) <= set(string.ascii_lowercase + string.digits))

    def test_exclude_ambiguous(self):
        for _ in range(50):
            self.assertFalse(set(generate_password(40, exclude_ambiguous=True)) & set(C.GEN_AMBIGUOUS))

    def test_invalid_options(self):
        for bad in (7, 65, "abc", None):
            with self.assertRaises(ValueError):
                generate_password(bad)
        with self.assertRaises(ValueError):
            generate_password(16, False, False, False, False)

    def test_randomness_and_strength(self):
        pws = {generate_password(16) for _ in range(200)}
        self.assertEqual(len(pws), 200)                      # no repeats
        strong = sum(analyze_password(p, use_zxcvbn=False).strength == "STRONG" for p in pws)
        self.assertGreaterEqual(strong, 190)                 # random 16-char passwords score STRONG

    def test_uses_secrets_not_random(self):
        src = (Path(__file__).resolve().parent.parent / "password_generator.py").read_text()
        self.assertIn("import secrets", src)
        self.assertNotIn("import random", src)


class CliTests(unittest.TestCase):
    def run_cli(self, inputs, secret=None):
        import cli
        out = io.StringIO()
        with mock.patch("builtins.input", side_effect=inputs), \
                mock.patch("getpass.getpass", return_value=secret or ""), mock.patch("sys.stdout", out):
            code = cli.main()
        return code, out.getvalue()

    def test_analyse_without_echoing_password(self):
        code, out = self.run_cli(["1", "q"], secret="Violet!River82Moon")
        self.assertEqual(code, 0)
        self.assertIn("STRONG", out)
        self.assertIn("90/100", out)
        self.assertNotIn("Violet!River82Moon", out)

    def test_empty_password_and_bad_choice(self):
        _, out = self.run_cli(["x", "1", "q"], secret="")
        self.assertIn("Please choose", out)
        self.assertIn("Please enter a password", out)

    def test_generate(self):
        _, out = self.run_cli(["2", "20", "2", "5", "q"])
        self.assertIn("Generated password", out)
        self.assertIn("between 8 and 64", out)

    def test_eof_exits_cleanly(self):
        import cli
        with mock.patch("builtins.input", side_effect=EOFError), mock.patch("sys.stdout", io.StringIO()):
            self.assertEqual(cli.main(), 0)


class MainTests(unittest.TestCase):
    def test_falls_back_to_cli_without_tkinter(self):
        import main
        with mock.patch.object(main, "gui_available", return_value=(False, "Tkinter is not installed.")), \
                mock.patch("cli.main", return_value=0) as cli_main, mock.patch("sys.stdout", io.StringIO()) as out:
            self.assertEqual(main.main([]), 0)
        cli_main.assert_called_once()
        self.assertIn("Tkinter is not installed", out.getvalue())

    def test_cli_flag(self):
        import main
        with mock.patch("cli.main", return_value=0) as cli_main:
            self.assertEqual(main.main(["--cli"]), 0)
        cli_main.assert_called_once()

    def test_no_password_argument_exists(self):
        import main
        with self.assertRaises(SystemExit), mock.patch("sys.stderr", io.StringIO()):
            main.main(["--password", "secret"])


class GuiTests(unittest.TestCase):
    """Builds the real PasswordCheckerApp on the Tk stand-in and presses every button."""

    def setUp(self):
        from tests import tk_stub
        self.stub = tk_stub
        self._saved = {k: sys.modules.get(k) for k in ("tkinter", "tkinter.ttk", "tkinter.messagebox", "gui")}
        tk_stub.install()
        tk_stub.MessageLog.calls = []
        tk_stub.Widget.instances = []
        import gui
        self.gui = gui
        self.root = tk_stub.Tk()
        self.app = gui.PasswordCheckerApp(self.root)

    def tearDown(self):
        for k, v in self._saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def type_and_analyze(self, pw):
        self.app.password_var.set(pw)
        self.app.analyze_button.invoke()

    def test_window_builds(self):
        self.assertEqual(self.root.options["title"], f"{C.APP_TITLE} v{C.APP_VERSION}")
        self.assertEqual(len(self.app.check_labels), 8)
        self.assertEqual(self.app.password_entry.cget("show"), "•")
        self.assertIn("Type a password", self.app.findings_box.get())

    def test_demo_examples_through_the_gui(self):
        for pw, strength, score in (("password123", "WEAK", 10), ("CyberSecure24", "MEDIUM", 58),
                                    ("Violet!River82Moon", "STRONG", 90)):
            self.type_and_analyze(pw)
            self.assertEqual(self.app.strength_label.cget("text"), strength)
            self.assertEqual(self.app.score_label.cget("text"), f"Score: {score} / 100")
            self.assertEqual(self.app.progress.cget("value"), score)
            self.assertEqual(self.app.progress.cget("style"), f"{strength}.Horizontal.TProgressbar")
            self.assertEqual(self.app.strength_label.cget("foreground"), C.STRENGTH_COLORS[strength])
            self.assertNotIn(pw, self.app.status_var.get())
        self.assertTrue(self.app.check_labels["Special characters (!@#$...)"].cget("text").startswith("✔"))
        self.assertIn("= 90/100", self.app.breakdown_box.get())
        self.assertIn("unique password", self.app.recs_box.get())

    def test_checklist_marks_failures(self):
        self.type_and_analyze("bluehouse")
        self.assertTrue(self.app.check_labels["Uppercase letters (A-Z)"].cget("text").startswith("✘"))
        self.assertEqual(self.app.check_labels["Uppercase letters (A-Z)"].cget("fg"), C.COLORS["fail"])

    def test_empty_input_warns(self):
        self.type_and_analyze("")
        self.assertEqual(self.stub.MessageLog.calls[-1][0], "warning")
        self.assertEqual(self.app.strength_label.cget("text"), "—")

    def test_enter_key_analyzes(self):
        self.app.password_var.set("CyberSecure24")
        self.app.password_entry.bindings["<Return>"](None)
        self.assertEqual(self.app.strength_label.cget("text"), "MEDIUM")

    def test_show_hide_toggle(self):
        cb = next(w for w in self.stub.Widget.instances if w.options.get("text") == "Show password")
        cb.invoke()
        self.assertEqual(self.app.password_entry.cget("show"), "")
        cb.invoke()
        self.assertEqual(self.app.password_entry.cget("show"), "•")

    def test_live_analysis(self):
        self.app.live_var.set(True)
        self.app.password_var.set("abc")
        self.app.password_entry.bindings["<KeyRelease>"](None)
        self.assertEqual(self.app.strength_label.cget("text"), "WEAK")
        self.app.password_var.set("")
        self.app.on_key()
        self.assertEqual(self.app.strength_label.cget("text"), "—")

    def test_reset_clears_everything(self):
        self.app.show_var.set(True)
        self.type_and_analyze("Violet!River82Moon")
        self.app.reset_button.invoke()
        self.assertEqual(self.app.password_var.get(), "")
        self.assertEqual(self.app.password_entry.cget("show"), "•")
        self.assertIsNone(self.app.last_result)
        self.assertEqual(self.app.progress.cget("value"), 0)
        self.assertNotIn("STRONG", self.app.breakdown_box.get())

    def test_save_report_has_no_password(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d, mock.patch.object(C, "REPORTS_DIR", Path(d)):
            self.app.save_button.invoke()
            self.assertEqual(self.stub.MessageLog.calls[-1][0], "info")      # "analyse first"
            self.type_and_analyze("Unique!Secret#Value42")
            self.app.save_button.invoke()
            files = list(Path(d).glob("report_*.txt"))
            self.assertEqual(len(files), 1)
            text = files[0].read_text()
            self.assertNotIn("Unique!Secret#Value42", text)
            self.assertIn("STRONG", text)

    def test_generator_copy_clipboard_clear_and_send(self):
        self.app.on_length_change("24.0")
        self.app.generate_button.invoke()
        pw = self.app.generated_var.get()
        self.assertEqual(len(pw), 24)
        self.assertIn("not saved", self.app.gen_info.cget("text"))
        self.app.copy_button.invoke()
        self.assertEqual(self.root.clipboard, pw)
        self.assertEqual(list(self.root.timers.values())[0][0], C.CLIPBOARD_CLEAR_SECONDS * 1000)
        self.root.run_timers()                                    # 30 seconds later ...
        self.assertIsNone(self.root.clipboard)
        self.app.send_button.invoke()
        self.assertIs(self.app.notebook.select(), self.app.analyzer_tab)
        self.assertEqual(self.app.strength_label.cget("text"), "STRONG")
        self.app.clear_gen_button.invoke()
        self.assertEqual(self.app.generated_var.get(), "")

    def test_clipboard_not_cleared_if_user_copied_something_else(self):
        self.app.generate_button.invoke()
        self.app.copy_button.invoke()
        self.root.clipboard = "something the user copied later"
        self.root.run_timers()
        self.assertEqual(self.root.clipboard, "something the user copied later")

    def test_generator_errors_and_empty_actions(self):
        for b in (self.app.copy_button, self.app.send_button):
            b.invoke()
            self.assertEqual(self.stub.MessageLog.calls[-1][0], "info")
        for var in (self.app.gen_upper, self.app.gen_lower, self.app.gen_digits, self.app.gen_symbols):
            var.set(False)
        self.app.generate_button.invoke()
        self.assertEqual(self.stub.MessageLog.calls[-1], ("error", "Select at least one character type."))

    def test_close_clears_clipboard_and_fields(self):
        self.app.generate_button.invoke()
        self.app.copy_button.invoke()
        self.app.password_var.set("typed")
        self.root.bindings["WM_DELETE_WINDOW"]()
        self.assertIsNone(self.root.clipboard)
        self.assertEqual(self.app.password_var.get(), "")
        self.assertTrue(self.root.destroyed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
