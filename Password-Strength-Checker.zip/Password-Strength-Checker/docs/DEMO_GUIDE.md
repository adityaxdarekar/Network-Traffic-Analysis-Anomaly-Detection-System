# Practical Demonstration Guide

## Before the professor arrives (2 minutes)
```bash
cd ~/projects/Password-Strength-Checker
source venv/bin/activate
./run_tests.sh            # should end with:  Ran 53 tests ... OK
python3 main.py           # opens the GUI
```
Maximise the window. Keep a terminal open next to it for the test run and the `--cli` demo.

---

## Step-by-step demonstration

### 1. Launch the application
Run `python3 main.py`. Point out the title **Password Strength Checker**, the badge
**"100% local · nothing is stored or sent"** and the two tabs (Analyzer, Generator).

### 2. Weak password - `password123`
1. Type `password123` (the field is masked).
2. Tick **Show password** to show the masking toggle, then untick it.
3. Press **Analyze Password** (or Enter).

Expected: **WEAK, 10/100**, red bar. Explain:
* Findings: "This is a commonly used password" (red) - it is in the common-password list.
* Checklist: uppercase ✘, special characters ✘, not a common password ✘.
* Score breakdown: points for length/types, penalties for the sequence `123`, the word `password`, the
  "word + digits" shape, then the **cap at 10** for common passwords.
* "Even though it has 11 characters and numbers, attackers try it in the first second."

### 3. Medium password - `CyberSecure24`
Press **Reset** (show that the field and every result are cleared), type `CyberSecure24`, analyse.

Expected: **MEDIUM, 58/100**, amber bar. Explain:
* Good length (13) and three character types → points.
* Penalties: dictionary words *cyber*, *secure* (−10) and the predictable shape *words followed by
  numbers* (−15).
* Recommendations: add a special character, don't just append numbers.

### 4. Strong password - `Violet!River82Moon`
Reset, type, analyse.

Expected: **STRONG, 90/100**, green bar, every checklist item ✔. Explain:
* 18 characters, all four character types, no sequences or repeats.
* Small −10 for dictionary words: passphrases built from *unrelated* words plus symbols and numbers
  are strong because of their length.
* Entropy estimate ~118 bits - and **why the entropy number is only an estimate**.

### 5. Variations are caught - `P@ssw0rd!` (optional, 30 s)
Result **WEAK 10/100**: the analyser undoes leet substitutions (@→a, 0→o) and trailing symbols, so
the "clever" variant is recognised as `password`.

### 6. Password generator
1. Open the **Password Generator** tab.
2. Move the length slider to 20; keep all character types ticked.
3. Press **Generate Password** → it shows the score (normally 100/100 STRONG) and "not saved anywhere".
4. Press **Copy to clipboard** → the status bar says the clipboard is cleared after 30 seconds.
5. Press **Analyze this password** → the app switches to the Analyzer and shows the full analysis.
6. Untick every type and press Generate → friendly error "Select at least one character type".

### 7. Report without the password (optional)
After an analysis, press **Save report (no password)** and open the file from `reports/` in a terminal:
`cat reports/report_*.txt` - the password line says *[not stored or shown]*.

### 8. Terminal fallback and tests (1 minute)
```bash
python3 main.py --cli       # choose 1 and type a password: input is invisible, the password is never printed
./run_tests.sh              # 53 tests, OK
```

---

## What each feature does (one line each)
| Feature | Purpose |
|---|---|
| Masked field + Show password | Prevents shoulder-surfing; toggle for checking typos |
| Analyze / Enter | Runs the local analysis |
| Strength + score + progress bar | WEAK (0-39), MEDIUM (40-69), STRONG (70-100) |
| Checklist | Length ≥ 8, 12+, upper, lower, digits, symbols, not common, no patterns |
| Security findings | What was detected, colour-coded by severity |
| Recommendations | Personalised fixes + unique passwords / password manager / MFA |
| How the score was calculated | Every point added or removed - the score is fully explainable |
| Reset | Clears the password and all results |
| Generator | `secrets`-based random passwords, copy with auto-clearing clipboard |
| Save report | Text report for documentation, never containing the password |

## Technical concepts to explain
* **Brute force vs. dictionary attacks** - attackers try common passwords, words and patterns first, so
  "complexity rules" alone are misleading.
* **Pattern detection** - sequences, keyboard runs, repeats, leet substitutions, "word + digits".
* **Entropy** - `length × log2(pool size)`; meaningful only for randomly generated passwords.
* **Heuristic scoring** - transparent weights and caps in `config.py`; not a guarantee.
* **`secrets` vs `random`** - `random` is a predictable pseudo-random generator (Mersenne Twister);
  `secrets` uses the operating system's cryptographically secure random source.
* **Privacy by design** - no files, logs, network or command-line arguments containing the password;
  `getpass` in the terminal; clipboard auto-clear.
* **Defence in depth** - a strong password is not enough: unique per account, password manager, MFA.

## Likely viva questions
| Question | Short answer |
|---|---|
| Why is `password123` weak though it has 11 characters? | It is in every attacker wordlist; the app caps common passwords at 10. |
| Why does `CyberSecure24` only get MEDIUM? | Dictionary words plus digits at the end is a shape cracking tools try early; no special character. |
| Is 90/100 "uncrackable"? | No. The score is an educational heuristic; a leaked or reused password is unsafe whatever its score. |
| Why not just use entropy? | It assumes random characters - `Password123!` has ~79 bits by that formula but is cracked instantly. |
| Why `secrets`? | It is cryptographically secure; `random` can be predicted. |
| How is the password protected inside your app? | Never stored, printed, logged or sent; not accepted as an argument; field masked; Reset clears it. |
| How would you improve it? | Offline breach list check, bigger dictionaries, diceware passphrases, crack-time estimates per hash type. |

---

## 3–5 minute presentation script
> **(Introduction - 30 s)** Good morning. My project is a *Python-Based Password Strength Checker and
> Security Analyzer*. Weak and reused passwords are still one of the main ways accounts get compromised,
> and many people believe a password is strong just because it has a capital letter and a number. My tool
> shows why that is not enough.
>
> **(How it works - 60 s)** The application is written in Python with a Tkinter interface. All analysis
> happens locally: the password is never saved, logged or sent anywhere. The analyser checks the length and
> the four character types, then looks for what attackers actually exploit: common passwords - including
> variations like P-at-sign-ss-w-zero-rd - sequences like 123 or abc, keyboard patterns like qwerty,
> repeated characters, dictionary words, and predictable shapes like a word followed by a year. It produces
> a score from 0 to 100: 0 to 39 is weak, 40 to 69 medium, 70 to 100 strong - and every single point is
> shown in the "How the score was calculated" panel.
>
> **(Live demo - 90 s)** Let me type *password123*. It is rated weak with 10 points, because it is one of
> the most common passwords in the world - it is capped no matter how long it is. Next, *CyberSecure24*:
> medium, 58. It is long enough and mixes letters and numbers, but it is two dictionary words with digits at
> the end - exactly the pattern cracking tools try early - and it has no special character. The
> recommendations tell the user exactly what to change. Finally *Violet!River82Moon*: strong, 90. It is 18
> characters long, uses all character types and has no predictable patterns.
>
> **(Generator - 30 s)** The second tab generates passwords with Python's *secrets* module, which is
> cryptographically secure, unlike the normal *random* module. I can copy the password - the app clears it
> from the clipboard after 30 seconds - or analyse it directly.
>
> **(Testing and limitations - 30 s)** The project has 53 automated tests, including the ten required
> test cases and privacy tests that make sure the password never appears in any output. Its limitation is
> that it is a heuristic: it cannot know whether a password was leaked in a breach, and the entropy value is
> only an estimate.
>
> **(Conclusion - 15 s)** The key lesson is that password strength is about unpredictability and length,
> combined with using a unique password for every account, a password manager and multi-factor
> authentication. Thank you - I'm happy to answer questions.
