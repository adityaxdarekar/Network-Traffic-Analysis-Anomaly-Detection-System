# Project status

**Complete:** all source files, GUI, terminal version, analyser, generator, tests and documentation.

## Verified during development
* All Python files compile on Python 3.11, 3.12 and 3.13.
* 53 automated tests pass (unittest and pytest).
* The three demonstration passwords classify as WEAK 10, MEDIUM 58 and STRONG 90.
* The real program was run end-to-end in a terminal: hidden input, analysis and generator work, and the
  password never appears in the output.
* The GUI code was executed with a Tk stand-in: the window builds and every button and checkbox
  (Analyze, Enter key, Show password, Analyze-as-I-type, Reset, Save report, Generate, Copy with clipboard
  auto-clear, Analyze this password, Clear, window close) does what it should.

## To verify on Kali (≈ 5 minutes)
The development machine had no Tkinter/display, so the **visual** appearance of the GUI must be checked once
on Kali: `sudo apt install python3-tk`, then `python3 main.py`, click through docs/DEMO_GUIDE.md and take the
screenshots listed in screenshots/README.md.
