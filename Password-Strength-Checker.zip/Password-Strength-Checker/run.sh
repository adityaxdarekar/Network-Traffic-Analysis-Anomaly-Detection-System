#!/usr/bin/env bash
# Start the Password Strength Checker (GUI; falls back to the terminal version automatically).
cd "$(dirname "$0")"
if [ -d venv ]; then
  # shellcheck disable=SC1091
  source venv/bin/activate
fi
python3 main.py "$@"
