# 🔐 Python-Based Password Strength Checker and Security Analyzer

A desktop cybersecurity tool (Python + Tkinter) that analyses a password **locally**, scores it from 0 to 100,
classifies it as **WEAK**, **MEDIUM** or **STRONG**, explains exactly *why*, and gives personalised advice.
It also includes a secure password generator built on Python's `secrets` module.

> **Educational tool.** The score is a transparent heuristic, not a guarantee. A password that scores
> STRONG can still be unsafe if it has been leaked, reused, or is guessable from your personal life.

---

## Contents
1. [Introduction](#1-introduction) · 2. [Problem statement](#2-problem-statement) · 3. [Objectives](#3-objectives) ·
4. [Technologies](#4-technologies-used) · 5. [System requirements](#5-system-requirements) · 6. [Features](#6-features) ·
7. [How it works](#7-how-the-application-works) · 8. [Scoring methodology](#8-password-scoring-methodology) ·
9. [Installation (Kali)](#9-installation-on-kali-linux) · 10. [Execution](#10-execution) · 11. [Test cases](#11-test-cases) ·
12. [Sample outputs](#12-sample-outputs) · 13. [Limitations](#13-limitations) · 14. [Future improvements](#14-future-improvements) ·
15. [Conclusion](#15-conclusion) · [Troubleshooting](#troubleshooting) · [Project structure](#project-structure)

## 1. Introduction
Weak and reused passwords remain one of the most common causes of account compromise. Attackers rarely
"guess" randomly: they try lists of leaked passwords, dictionary words, keyboard patterns (`qwerty`),
sequences (`123456`) and predictable shapes such as `Name2024`. This project shows, in a clear graphical
interface, how a password measures up against exactly those techniques.

## 2. Problem statement
Users often believe a password is strong because it "has a number and a capital letter". Simple rule
checkers reinforce that belief: `Password123!` passes most of them. Users need a tool that:
* detects common passwords and predictable patterns, not just character types;
* explains the result instead of only showing a coloured bar;
* gives concrete, personalised advice;
* never puts the password at risk while checking it.

## 3. Objectives
1. Analyse length and character complexity and show the result of every check.
2. Detect common passwords (including simple variations) and predictable patterns.
3. Produce a transparent 0-100 score and a WEAK / MEDIUM / STRONG classification.
4. Estimate character-set entropy and explain its limitations.
5. Provide personalised security recommendations.
6. Generate strong random passwords with the `secrets` module.
7. Keep everything local: no storage, no logging, no network.
8. Offer a professional Tkinter GUI plus a terminal fallback, with automated tests.

## 4. Technologies used
| Technology | Use |
|---|---|
| Python 3.10+ | Language (standard library only) |
| Tkinter / ttk | Graphical interface (dark navy theme, green accents) |
| `secrets` | Cryptographically secure password generation |
| `re`, `math` | Pattern detection, entropy estimate |
| `getpass` | Hidden password input in the terminal version |
| `unittest` | Automated tests (pytest also works) |
| Kali Linux | Target platform (also runs on Ubuntu, Debian, Windows, macOS) |
| zxcvbn (optional) | Local second opinion if installed; not required |

## 5. System requirements
* Kali Linux (any recent release) or another OS with Python 3.10 or newer
* `python3-tk` package for the GUI (the terminal version works without it)
* ~10 MB disk space, any CPU, 512 MB RAM

## 6. Features
| Feature | Details |
|---|---|
| **Length analysis** | Flags < 8 characters (always WEAK), recommends 12-16+, length points up to 30 |
| **Complexity checklist** | Uppercase, lowercase, numbers, special characters - each shown with ✔ / ✘ |
| **Common password detection** | 170-entry list (`assets/common_passwords.txt`) + built-in fallback; catches variations: case (`QWERTY`), trailing digits/symbols (`Summer2024`, `password!`) and leet speak (`P@ssw0rd`); also finds common passwords *inside* longer ones (`MyPassword2024!`) |
| **Pattern detection** | Sequences (`abc`, `123`, `cba`), keyboard runs (`qwer`, `asdf`, `zxcv`), repeated characters (`aaa`, `111`), repeated blocks (`abcabc`), dictionary words, "word + digits" shape, years |
| **Score 0-100** | Transparent breakdown - every point shown in the GUI ("How the score was calculated") |
| **Classification** | 0-39 WEAK (red), 40-69 MEDIUM (amber), 70-100 STRONG (green) with a coloured progress bar |
| **Entropy estimate** | Character-set estimate in bits, clearly labelled as an estimate |
| **Recommendations** | Personalised to what the password is missing, plus general advice (unique passwords, password manager, MFA) |
| **Password generator** | `secrets`-based, length 8-64, choose character types, exclude look-alikes, copy, analyse |
| **Clipboard safety** | A copied password is removed from the clipboard after 30 s (only if still there) and when the app closes |
| **Report** | Optional text report saved to `reports/` - **without** the password |
| **Terminal fallback** | Automatic if Tkinter or a display is missing (`python3 main.py --cli`) |

### Security design
* No network code at all; nothing is sent anywhere.
* The password is never written to a file, printed, or logged. The analysis result object holds no copy of it.
* The password cannot be passed as a command-line argument (that would store it in shell history).
* Terminal input uses `getpass` (not echoed). The GUI field is masked by default.
* **Reset** clears the field and all results; closing the window clears fields and the copied password.

## 7. How the application works
```
 GUI (gui.py) or terminal (cli.py)
        │ password (kept only in the input field)
        ▼
 password_analyzer.analyze_password()
   1. character types          → checklist + points
   2. length                   → points
   3. entropy estimate         → bonus points
   4. pattern detectors        → penalties (sequences, keyboard, repeats, blocks, words, word+digits, years)
   5. common-password check    → cap (exact/variation) or penalty (contained)
   6. score → WEAK / MEDIUM / STRONG
   7. findings + recommendations + score breakdown
        │ AnalysisResult (no password inside)
        ▼
 displayed in the GUI / terminal; optional report without the password

 password_generator.generate_password() → secrets.choice + secrets.SystemRandom().shuffle
```

## 8. Password scoring methodology
All values are in `config.py`. The breakdown shown in the app always adds up exactly to the final score.

**Positive points (maximum 100)**
| Component | Points |
|---|---|
| Length | `length × 30 / 16`, rounded, maximum 30 (16+ characters = 30) |
| Character types | +10 each for uppercase, lowercase, numbers, special characters (max 40) |
| Entropy bonus | 0 at ≤ 28 bits, rising linearly to 20 at ≥ 80 bits |
| No sequences, keyboard runs or repeats | +10 |

**Penalties**
| Weakness | Penalty |
|---|---|
| Sequential run of 3+ (`abc`, `123`, `cba`) | −10 each, max −20 |
| Keyboard run of 4+ (`qwer`, `asdf`, `1234`) | −10 each, max −20 |
| 3+ identical characters (`aaa`, `111`) | −10 |
| Repeated block (`abcabc`, `1212`) | −10 |
| Contains a common password (6+ chars, e.g. `password` inside) | −25 |
| Common dictionary words (4+ letters) | −5 each, max −10 |
| Shape "letters followed by digits" (`Summer2024`, `john123`) | −15 |
| Contains a year 1950-2039 | −5 |

**Caps (hard limits)**
* The password **is** a common password (also after removing trailing digits/symbols or undoing leet
  substitutions) → score limited to **10**.
* Shorter than **8** characters → score limited to **39** (always WEAK).
* The score never goes below 0 or above 100.

**Classification:** 0-39 **WEAK** · 40-69 **MEDIUM** · 70-100 **STRONG**

**Entropy estimate:** `length × log2(pool size)`, where the pool is 26 (lowercase) + 26 (uppercase) + 10
(digits) + 33 (special) + 100 (non-ASCII) for the types present. *Limitation:* it assumes every character
was chosen at random. Human passwords are not random - `Password123!` gets ~79 bits but is cracked
instantly from a wordlist - so the estimate is only a rough comparison, never a security measurement.

**Why words are penalised only a little:** dictionary attacks try words first, but several *unrelated*
words plus length and symbols (a passphrase) remain strong - that is why `Violet!River82Moon` scores 90.

## 9. Installation on Kali Linux
Copy-paste the commands one block at a time.

**1. Check Python**
```bash
python3 --version          # must show Python 3.10 or newer
```
**2. Get the project folder**
```bash
mkdir -p ~/projects && cd ~/projects
unzip ~/Downloads/Password-Strength-Checker.zip     # adjust the path to where you saved the ZIP
cd Password-Strength-Checker
```
**3. Install Tkinter and venv support**
```bash
sudo apt update
sudo apt install -y python3-tk python3-venv
python3 -c "import tkinter; print('Tkinter OK, Tk', tkinter.TkVersion)"
```
**4. Create and activate a virtual environment**
```bash
python3 -m venv venv
source venv/bin/activate
```
**5. Install dependencies** (none are required - this step just confirms pip works; optional extras are
listed in `requirements.txt`)
```bash
pip install -r requirements.txt
# optional: pip install zxcvbn
```
Shortcut for steps 3-5: `chmod +x setup.sh run.sh run_tests.sh && ./setup.sh`

## 10. Execution
```bash
cd ~/projects/Password-Strength-Checker
source venv/bin/activate
python3 main.py            # graphical version   (or: ./run.sh)
python3 main.py --cli      # terminal version
python3 -m unittest discover -s tests -t . -v      # run all tests  (or: ./run_tests.sh)
```

## 11. Test cases
Automated tests: **53** (`tests/`), run with `unittest` or `pytest`. They cover the analyser, every detector,
classification boundaries, empty/invalid input, Unicode, 300 random passwords (score always 0-100 and the
breakdown always adds up), privacy (password never in results/reports/output), the generator, the terminal
version, `main.py`'s fallback, and the GUI's buttons (using a Tk stand-in so they also run without a display).

The ten required cases (expected results = what the documented scoring produces):

| # | Case | Password | Score | Class | Main reasons (penalties/caps) |
|---|---|---|---|---|---|
| 1 | Very short | `Ab1!` | 39 | **WEAK** | Shorter than 8 → capped at 39 |
| 2 | Common password | `password` | 10 | **WEAK** | Common password → capped at 10 |
| 3 | Numbers only | `84720519` | 35 | **WEAK** | Only one character type, short |
| 4 | Lowercase only | `bluehouse` | 32 | **WEAK** | One type; dictionary words blue, house |
| 5 | Upper + lowercase | `SunnyBeach` | 55 | **MEDIUM** | No numbers/symbols; word "beach" |
| 6 | Special characters (random) | `Kx9#mQ2$vL7!pR4z` | 100 | **STRONG** | All types, 16 chars, no patterns |
| 7 | Repeated characters | `Hellooo111` | 31 | **WEAK** | `ooo`, `111`; word + digits shape |
| 8 | Sequential characters | `abcd1234` | 0 | **WEAK** | `abcd`, `1234`, keyboard run, common |
| 9 | Medium-strength | `CyberSecure24` | 58 | **MEDIUM** | Words + digits at the end, no symbol |
| 10 | Strong passphrase | `Violet!River82Moon` | 90 | **STRONG** | Long, all types; small word penalty |

Extra checks: `P@ssw0rd!` → 10 WEAK (leet variation of a common password), `Summer2024` → 10 WEAK.

## 12. Sample outputs
**Demonstration examples**
| Password | Result |
|---|---|
| `password123` | **WEAK 10/100** - "This is a commonly used password …" |
| `CyberSecure24` | **MEDIUM 58/100** - missing special characters; predictable word + number shape |
| `Violet!River82Moon` | **STRONG 90/100** - all checks pass |

Score breakdown of `CyberSecure24` (as shown in the app):
```
 +24  Length (13 characters)
 +10  Uppercase letters
 +10  Lowercase letters
 +10  Numbers
 +19  Entropy estimate bonus (77 bits)
 +10  No sequences, keyboard runs or repeats
 -10  Dictionary words: cyber, secure
 -15  Predictable shape: word(s) followed by numbers
 = 58/100 -> MEDIUM
```
Breakdown of `password123`: +21 length, +10 lowercase, +10 numbers, +11 entropy, −10 sequence "123",
−5 word "password", −15 word+digits shape, −12 cap (common password) = **10 → WEAK**.

Terminal version (excerpt; the typed password is hidden and never printed):
```
Enter password to analyse (input is hidden):
Strength: MEDIUM   Score: 58/100  [#################-------------]
  [FAIL] Special characters (!@#$...)
Recommendations:
  1. Add special characters such as ! @ # $ % & *.
  2. Do not just add numbers to the end of a word - mix symbols and numbers inside the password.
```
Screenshots of the GUI: see the `screenshots/` folder (take them on your machine - `screenshots/README.md`).

## 13. Limitations
* Heuristic scoring: it cannot know whether a password appears in real breach data (millions of entries)
  or relates to the user's personal life (names, pets, birthdays).
* The common-password and word lists are small and English-only; obscure leet variants such as
  `Tr0ub4dor&3` still score STRONG although modern cracking rules would find them.
* The entropy figure assumes random characters and over-rates human-chosen passwords.
* It does not measure real cracking time, which depends on how the password is stored (hash algorithm).
* zxcvbn's opinion (if installed) is shown separately and does not change the documented score.

## 14. Future improvements
* Offline check against a large breached-password list (e.g. a downloaded hash list), or the k-anonymity
  "Pwned Passwords" API as an explicit opt-in.
* Larger, multilingual dictionaries and full leet-speak handling.
* Passphrase generator using a diceware word list.
* Estimated crack time for different hash algorithms (bcrypt vs. MD5) as a teaching aid.
* Organisation password-policy profiles (e.g. NIST SP 800-63B-style rules).

## 15. Conclusion
The project delivers a working, local-only password analyser with a professional Tkinter interface, a
transparent and documented scoring system, pattern and common-password detection, personalised advice and a
secure generator. Its main teaching point is that password strength is about *unpredictability* - length and
avoiding patterns matter far more than satisfying "one capital letter and one number" rules - and that any
automated score is a guide, not a guarantee.

## Troubleshooting
| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'tkinter'` | `sudo apt install python3-tk` (the app falls back to the terminal version until then) |
| "No graphical display found" | You are in an SSH/TTY session; use the Kali desktop, or `ssh -X`, or use `--cli` |
| `error: externally-managed-environment` from pip | Activate the venv first: `source venv/bin/activate` |
| `python3 -m venv` fails | `sudo apt install python3-venv` |
| `Permission denied: ./run.sh` | `chmod +x setup.sh run.sh run_tests.sh` |
| Window fonts look different | The app asks for DejaVu (installed on Kali); Tk substitutes another font elsewhere - harmless |
| `_tkinter.TclError: couldn't connect to display` | Run inside the graphical desktop session, not as `sudo`/root from another session |

## Project structure
```
Password-Strength-Checker/
├── main.py                  entry point (GUI, automatic terminal fallback, --cli)
├── gui.py                   Tkinter interface
├── cli.py                   terminal interface
├── password_analyzer.py     analysis engine (scoring, detectors, recommendations, report)
├── password_generator.py    secure generator (secrets)
├── config.py                weights, thresholds, colours
├── requirements.txt         (standard library only; optional extras listed)
├── setup.sh · run.sh · run_tests.sh
├── assets/                  common_passwords.txt, common_words.txt
├── tests/                   test_password_analyzer.py, test_generator_and_apps.py, tk_stub.py
├── reports/                 optional reports (never contain the password)
├── screenshots/             your screenshots for the submission
└── docs/                    DEMO_GUIDE.md (demonstration steps + presentation script)
```
