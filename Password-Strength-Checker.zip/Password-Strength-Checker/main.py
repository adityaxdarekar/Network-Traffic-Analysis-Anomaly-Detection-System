#!/usr/bin/env python3
"""
Password Strength Checker - entry point.

    python3 main.py          start the graphical (Tkinter) application
    python3 main.py --cli    start the terminal version

If Tkinter is not installed, or there is no graphical display (e.g. an SSH
session), the terminal version starts automatically.

For security the program never accepts a password as a command-line argument:
arguments are saved in the shell history and visible to other users.
"""

from __future__ import annotations

import argparse
import os
import sys


def gui_available() -> tuple[bool, str]:
    try:
        import tkinter  # noqa: F401
    except ImportError:
        return False, ("Tkinter is not installed. Install it with:  sudo apt install python3-tk  "
                       "(starting the terminal version instead)")
    if sys.platform.startswith("linux") and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        return False, "No graphical display found (starting the terminal version instead)."
    return True, ""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Password Strength Checker (all analysis is local).")
    parser.add_argument("--cli", action="store_true", help="use the terminal interface")
    args = parser.parse_args(argv)

    if not args.cli:
        ok, reason = gui_available()
        if ok:
            try:
                import gui
                gui.run()
                return 0
            except Exception as exc:  # noqa: BLE001 - e.g. display refused the connection
                print(f"Could not start the graphical interface ({exc.__class__.__name__}: {exc}).")
                print("Starting the terminal version instead.\n")
        else:
            print(reason + "\n")
    import cli
    return cli.main()


if __name__ == "__main__":
    raise SystemExit(main())
