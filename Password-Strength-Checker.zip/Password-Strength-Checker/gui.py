"""
Tkinter graphical interface for the Password Strength Checker.

Layout:
    Header (title, "analysis is 100% local")
    Tab 1 "Password Analyzer":
        left  - password field, show/hide, Analyze / Reset, strength + score + progress bar,
                entropy estimate, character checklist
        right - Security findings, Recommendations, "How the score was calculated", Save report
    Tab 2 "Password Generator":
        length slider, character options, Generate, Copy (auto-cleared from the clipboard),
        "Analyze this password"

Security behaviour:
    * Nothing is written to disk except an optional report WITHOUT the password.
    * Reset clears the password field and every result.
    * A copied password is removed from the clipboard after CLIPBOARD_CLEAR_SECONDS
      (if the clipboard still holds it), and again when the window closes.
    * No print()/logging of passwords anywhere.
"""

from __future__ import annotations

import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

import config as C
from password_analyzer import analyze_password, format_report
from password_generator import generate_password

COL = C.COLORS
F = C.FONT_FAMILY
FONTS = {
    "title": (F, 22, "bold"), "subtitle": (F, 10), "h2": (F, 12, "bold"), "body": (F, 10), "small": (F, 9),
    "strength": (F, 26, "bold"), "score": (F, 14, "bold"), "entry": (C.MONO_FAMILY, 13), "mono": (C.MONO_FAMILY, 10),
    "check": (F, 10),
}
LEVEL_TAGS = {"critical": COL["weak"], "warning": COL["medium"], "info": COL["muted"], "good": COL["strong"]}
LEVEL_ICONS = {"critical": "✖", "warning": "!", "info": "i", "good": "✔"}


class PasswordCheckerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.last_result = None
        self._copied_password: str | None = None
        self._clear_job = None
        root.title(f"{C.APP_TITLE} v{C.APP_VERSION}")
        root.geometry("1120x780")
        root.minsize(980, 700)
        root.configure(bg=COL["bg"])
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self._build_styles()

        self.password_var = tk.StringVar()
        self.show_var = tk.BooleanVar(value=False)
        self.live_var = tk.BooleanVar(value=False)
        self.gen_length = tk.IntVar(value=C.GEN_DEFAULT_LENGTH)
        self.gen_upper = tk.BooleanVar(value=True)
        self.gen_lower = tk.BooleanVar(value=True)
        self.gen_digits = tk.BooleanVar(value=True)
        self.gen_symbols = tk.BooleanVar(value=True)
        self.gen_ambiguous = tk.BooleanVar(value=False)
        self.generated_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Ready. Everything is analysed locally on this computer.")

        self._build_header()
        self.notebook = ttk.Notebook(root, style="Dark.TNotebook")
        self.notebook.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        self.analyzer_tab = ttk.Frame(self.notebook, style="Bg.TFrame", padding=12)
        self.generator_tab = ttk.Frame(self.notebook, style="Bg.TFrame", padding=12)
        self.notebook.add(self.analyzer_tab, text="  Password Analyzer  ")
        self.notebook.add(self.generator_tab, text="  Password Generator  ")
        self._build_analyzer(self.analyzer_tab)
        self._build_generator(self.generator_tab)
        status = ttk.Label(root, textvariable=self.status_var, style="Status.TLabel", anchor="w")
        status.pack(fill="x", padx=16, pady=(0, 10))

        self.password_entry.bind("<Return>", lambda _e: self.analyze())
        self.password_entry.bind("<KeyRelease>", self.on_key)
        self.password_entry.focus_set()
        self._show_empty_state()

    # ------------------------------------------------------------------ styles
    def _build_styles(self) -> None:
        s = ttk.Style(self.root)
        try:
            s.theme_use("clam")          # 'clam' allows custom colours on every platform
        except tk.TclError:
            pass
        s.configure("Bg.TFrame", background=COL["bg"])
        s.configure("Panel.TFrame", background=COL["panel"])
        s.configure("Card.TFrame", background=COL["panel"], relief="flat")
        s.configure("TLabel", background=COL["bg"], foreground=COL["text"], font=FONTS["body"])
        s.configure("Panel.TLabel", background=COL["panel"], foreground=COL["text"], font=FONTS["body"])
        s.configure("Muted.TLabel", background=COL["panel"], foreground=COL["muted"], font=FONTS["small"])
        s.configure("H2.TLabel", background=COL["panel"], foreground=COL["accent"], font=FONTS["h2"])
        s.configure("Title.TLabel", background=COL["bg"], foreground=COL["accent"], font=FONTS["title"])
        s.configure("Subtitle.TLabel", background=COL["bg"], foreground=COL["muted"], font=FONTS["subtitle"])
        s.configure("Badge.TLabel", background=COL["panel_alt"], foreground=COL["accent"], font=FONTS["small"],
                    padding=(10, 4))
        s.configure("Status.TLabel", background=COL["bg"], foreground=COL["muted"], font=FONTS["small"])
        s.configure("Strength.TLabel", background=COL["panel"], foreground=COL["muted"], font=FONTS["strength"])
        s.configure("Score.TLabel", background=COL["panel"], foreground=COL["text"], font=FONTS["score"])
        s.configure("Accent.TButton", background=COL["accent"], foreground="#04110a", font=FONTS["h2"],
                    padding=(14, 8), borderwidth=0)
        s.map("Accent.TButton", background=[("active", COL["accent_dark"]), ("disabled", COL["border"])])
        s.configure("Ghost.TButton", background=COL["panel_alt"], foreground=COL["text"], font=FONTS["body"],
                    padding=(12, 7), borderwidth=1)
        s.map("Ghost.TButton", background=[("active", COL["border"])])
        s.configure("Dark.TCheckbutton", background=COL["panel"], foreground=COL["text"], font=FONTS["body"])
        s.map("Dark.TCheckbutton", background=[("active", COL["panel"])],
              indicatorcolor=[("selected", COL["accent"]), ("!selected", COL["entry_bg"])])
        s.configure("Dark.TEntry", fieldbackground=COL["entry_bg"], foreground=COL["text"],
                    insertcolor=COL["accent"], bordercolor=COL["border"], lightcolor=COL["border"])
        s.configure("Dark.TNotebook", background=COL["bg"], borderwidth=0)
        s.configure("Dark.TNotebook.Tab", background=COL["panel"], foreground=COL["muted"], font=FONTS["body"],
                    padding=(12, 6))
        s.map("Dark.TNotebook.Tab", background=[("selected", COL["panel_alt"])],
              foreground=[("selected", COL["accent"])])
        for name, color in (("Empty", COL["border"]), ("WEAK", COL["weak"]), ("MEDIUM", COL["medium"]),
                            ("STRONG", COL["strong"])):
            s.configure(f"{name}.Horizontal.TProgressbar", troughcolor=COL["entry_bg"], background=color,
                        bordercolor=COL["border"], lightcolor=color, darkcolor=color, thickness=18)
        s.configure("Dark.Horizontal.TScale", background=COL["panel"], troughcolor=COL["entry_bg"])

    # ------------------------------------------------------------------ layout
    def _build_header(self) -> None:
        head = ttk.Frame(self.root, style="Bg.TFrame", padding=(16, 14, 16, 8))
        head.pack(fill="x")
        left = ttk.Frame(head, style="Bg.TFrame")
        left.pack(side="left")
        ttk.Label(left, text=C.APP_TITLE, style="Title.TLabel").pack(anchor="w")
        ttk.Label(left, text=C.APP_SUBTITLE + "  ·  Cybersecurity / Blue Team", style="Subtitle.TLabel").pack(anchor="w")
        ttk.Label(head, text="100% local · nothing is stored or sent", style="Badge.TLabel").pack(side="right")

    def _panel(self, parent, title: str, padding=14):
        frame = ttk.Frame(parent, style="Panel.TFrame", padding=padding)
        ttk.Label(frame, text=title, style="H2.TLabel").pack(anchor="w", pady=(0, 8))
        return frame

    def _text_box(self, parent, height: int) -> tk.Text:
        box = tk.Text(parent, height=height, wrap="word", bg=COL["entry_bg"], fg=COL["text"], font=FONTS["body"],
                      relief="flat", highlightthickness=1, highlightbackground=COL["border"], padx=10, pady=8,
                      insertbackground=COL["accent"], cursor="arrow")
        for level, color in LEVEL_TAGS.items():
            box.tag_configure(level, foreground=color)
        box.tag_configure("muted", foreground=COL["muted"])
        box.tag_configure("bold", font=(F, 10, "bold"))
        box.configure(state="disabled")
        box.pack(fill="both", expand=True)
        return box

    def _build_analyzer(self, tab) -> None:
        tab.columnconfigure(0, weight=0, minsize=400)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(0, weight=1)
        left = ttk.Frame(tab, style="Bg.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        right = ttk.Frame(tab, style="Bg.TFrame")
        right.grid(row=0, column=1, sticky="nsew")

        # Input
        inp = self._panel(left, "Enter a password")
        inp.pack(fill="x")
        self.password_entry = ttk.Entry(inp, textvariable=self.password_var, show="•", font=FONTS["entry"],
                                        style="Dark.TEntry", width=32)
        self.password_entry.pack(fill="x", ipady=6)
        opts = ttk.Frame(inp, style="Panel.TFrame")
        opts.pack(fill="x", pady=(8, 10))
        ttk.Checkbutton(opts, text="Show password", variable=self.show_var, command=self.toggle_visibility,
                        style="Dark.TCheckbutton").pack(side="left")
        ttk.Checkbutton(opts, text="Analyze as I type", variable=self.live_var, style="Dark.TCheckbutton").pack(
            side="right")
        btns = ttk.Frame(inp, style="Panel.TFrame")
        btns.pack(fill="x")
        self.analyze_button = ttk.Button(btns, text="Analyze Password", style="Accent.TButton", command=self.analyze)
        self.analyze_button.pack(side="left", fill="x", expand=True)
        self.reset_button = ttk.Button(btns, text="Reset", style="Ghost.TButton", command=self.reset)
        self.reset_button.pack(side="left", padx=(8, 0))

        # Strength
        card = self._panel(left, "Password strength")
        card.pack(fill="x", pady=12)
        row = ttk.Frame(card, style="Panel.TFrame")
        row.pack(fill="x")
        self.strength_label = ttk.Label(row, text="—", style="Strength.TLabel")
        self.strength_label.pack(side="left")
        self.score_label = ttk.Label(row, text="Score: – / 100", style="Score.TLabel")
        self.score_label.pack(side="right", anchor="s", pady=(0, 6))
        self.progress = ttk.Progressbar(card, orient="horizontal", mode="determinate", maximum=100,
                                        style="Empty.Horizontal.TProgressbar")
        self.progress.pack(fill="x", pady=(6, 6))
        scale = ttk.Frame(card, style="Panel.TFrame")
        scale.pack(fill="x")
        ttk.Label(scale, text="WEAK 0-39", style="Muted.TLabel").pack(side="left")
        ttk.Label(scale, text="STRONG 70-100", style="Muted.TLabel").pack(side="right")
        ttk.Label(scale, text="MEDIUM 40-69", style="Muted.TLabel").pack(side="left", expand=True)
        self.entropy_label = ttk.Label(card, text="Entropy estimate: –", style="Muted.TLabel")
        self.entropy_label.pack(anchor="w", pady=(8, 0))

        # Checklist
        chk = self._panel(left, "Character & complexity checklist")
        chk.pack(fill="both", expand=True)
        self.check_labels: dict[str, ttk.Label] = {}
        names = ["At least 8 characters", "12+ characters (recommended)", "Uppercase letters (A-Z)",
                 "Lowercase letters (a-z)", "Numbers (0-9)", "Special characters (!@#$...)",
                 "Not a common password", "No sequences, keyboard runs or repeats"]
        for name in names:
            lbl = tk.Label(chk, text=f"•  {name}", anchor="w", bg=COL["panel"], fg=COL["muted"], font=FONTS["check"])
            lbl.pack(fill="x", pady=2)
            self.check_labels[name] = lbl

        # Right side
        fpanel = self._panel(right, "Security findings")
        fpanel.pack(fill="both", expand=True)
        self.findings_box = self._text_box(fpanel, 8)
        rpanel = self._panel(right, "Recommendations")
        rpanel.pack(fill="both", expand=True, pady=12)
        self.recs_box = self._text_box(rpanel, 7)
        bpanel = self._panel(right, "How the score was calculated")
        bpanel.pack(fill="both", expand=True)
        self.breakdown_box = self._text_box(bpanel, 7)
        self.breakdown_box.configure(font=FONTS["mono"])
        foot = ttk.Frame(right, style="Bg.TFrame")
        foot.pack(fill="x", pady=(10, 0))
        ttk.Label(foot, text="Educational heuristic - a high score is not a guarantee of security.",
                  style="Status.TLabel").pack(side="left")
        self.save_button = ttk.Button(foot, text="Save report (no password)", style="Ghost.TButton",
                                      command=self.save_report)
        self.save_button.pack(side="right")

    def _build_generator(self, tab) -> None:
        panel = self._panel(tab, "Secure password generator", padding=20)
        panel.pack(fill="x")
        ttk.Label(panel, text="Uses Python's 'secrets' module (cryptographically secure randomness). Generated "
                              "passwords are never saved.", style="Muted.TLabel").pack(anchor="w", pady=(0, 12))
        lrow = ttk.Frame(panel, style="Panel.TFrame")
        lrow.pack(fill="x")
        ttk.Label(lrow, text="Length:", style="Panel.TLabel").pack(side="left")
        self.length_value = ttk.Label(lrow, text=str(C.GEN_DEFAULT_LENGTH), style="Score.TLabel", width=4)
        self.length_value.pack(side="right")
        self.length_scale = ttk.Scale(lrow, from_=C.GEN_MIN_LENGTH, to=C.GEN_MAX_LENGTH, orient="horizontal",
                                      variable=self.gen_length, command=self.on_length_change,
                                      style="Dark.Horizontal.TScale")
        self.length_scale.pack(side="left", fill="x", expand=True, padx=12)
        orow = ttk.Frame(panel, style="Panel.TFrame")
        orow.pack(fill="x", pady=12)
        for text, var in (("Uppercase (A-Z)", self.gen_upper), ("Lowercase (a-z)", self.gen_lower),
                          ("Numbers (0-9)", self.gen_digits), ("Symbols (!@#...)", self.gen_symbols),
                          ("Exclude look-alikes (l, 1, O, 0)", self.gen_ambiguous)):
            ttk.Checkbutton(orow, text=text, variable=var, style="Dark.TCheckbutton").pack(side="left", padx=(0, 16))
        self.generate_button = ttk.Button(panel, text="Generate Password", style="Accent.TButton",
                                          command=self.generate)
        self.generate_button.pack(anchor="w")
        out = self._panel(tab, "Generated password", padding=20)
        out.pack(fill="x", pady=12)
        self.generated_entry = ttk.Entry(out, textvariable=self.generated_var, font=FONTS["entry"],
                                         style="Dark.TEntry", state="readonly")
        self.generated_entry.pack(fill="x", ipady=6)
        brow = ttk.Frame(out, style="Panel.TFrame")
        brow.pack(fill="x", pady=(10, 0))
        self.copy_button = ttk.Button(brow, text="Copy to clipboard", style="Ghost.TButton",
                                      command=self.copy_generated)
        self.copy_button.pack(side="left")
        self.send_button = ttk.Button(brow, text="Analyze this password", style="Ghost.TButton",
                                      command=self.send_to_analyzer)
        self.send_button.pack(side="left", padx=8)
        self.clear_gen_button = ttk.Button(brow, text="Clear", style="Ghost.TButton", command=self.clear_generated)
        self.clear_gen_button.pack(side="left")
        self.gen_info = ttk.Label(out, text="", style="Muted.TLabel")
        self.gen_info.pack(anchor="w", pady=(10, 0))

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _write(box: tk.Text, parts: list[tuple[str, str | None]]) -> None:
        box.configure(state="normal")
        box.delete("1.0", "end")
        for text, tag in parts:
            if tag:
                box.insert("end", text, tag)
            else:
                box.insert("end", text)
        box.configure(state="disabled")

    def _show_empty_state(self) -> None:
        self.strength_label.configure(text="—", foreground=COL["muted"])
        self.score_label.configure(text="Score: – / 100")
        self.progress.configure(value=0, style="Empty.Horizontal.TProgressbar")
        self.entropy_label.configure(text="Entropy estimate: –")
        for name, lbl in self.check_labels.items():
            lbl.configure(text=f"•  {name}", fg=COL["muted"])
        self._write(self.findings_box, [("Type a password and press Analyze Password (or Enter).", "muted")])
        self._write(self.recs_box, [("Personalised recommendations will appear here.", "muted")])
        self._write(self.breakdown_box, [("Each scoring step and its points will be listed here.", "muted")])

    # ------------------------------------------------------------------ actions
    def analyze(self) -> None:
        password = self.password_var.get()
        if not password:
            self._show_empty_state()
            self.status_var.set("Please enter a password first.")
            messagebox.showwarning(C.APP_TITLE, "Please enter a password to analyse.")
            return
        try:
            result = analyze_password(password)
        except ValueError as exc:
            messagebox.showerror(C.APP_TITLE, str(exc))
            return
        except Exception as exc:  # noqa: BLE001 - never crash the GUI
            messagebox.showerror(C.APP_TITLE, f"Unexpected error during analysis: {exc.__class__.__name__}")
            return
        finally:
            password = ""   # noqa: F841 - drop the local reference
        self.display(result)

    def display(self, result) -> None:
        self.last_result = result
        color = C.STRENGTH_COLORS[result.strength]
        self.strength_label.configure(text=result.strength, foreground=color)
        self.score_label.configure(text=f"Score: {result.score} / 100")
        self.progress.configure(value=result.score, style=f"{result.strength}.Horizontal.TProgressbar")
        self.entropy_label.configure(text=f"Entropy estimate: ~{result.entropy_bits:.0f} bits "
                                          f"(character-set estimate, not a real-world guarantee)")
        for name, ok in result.checks.items():
            lbl = self.check_labels.get(name)
            if lbl is not None:
                lbl.configure(text=f"{'✔' if ok else '✘'}  {name}", fg=COL["pass"] if ok else COL["fail"])
        parts: list[tuple[str, str | None]] = []
        for f in result.findings:
            parts += [(f" {LEVEL_ICONS[f.level]}  ", f.level), (f.message + "\n", None)]
        if result.zxcvbn:
            parts.append((f" i  zxcvbn (local library) rates it {result.zxcvbn['score']}/4 "
                          f"(~10^{result.zxcvbn['guesses_log10']} guesses).\n", "info"))
        self._write(self.findings_box, parts)
        self._write(self.recs_box, [(f"{i}. {r}\n", None) for i, r in enumerate(result.recommendations, 1)])
        lines = [(f"{p:+4d}  {label}\n", "good" if p > 0 else "critical" if p < 0 else "muted")
                 for label, p in result.breakdown]
        lines.append((f"\n= {result.score}/100  ->  {result.strength}  "
                       f"(0-{C.WEAK_MAX} WEAK, {C.WEAK_MAX + 1}-{C.MEDIUM_MAX} MEDIUM, "
                       f"{C.MEDIUM_MAX + 1}-100 STRONG)", "bold"))
        self._write(self.breakdown_box, lines)
        self.status_var.set(f"Analysed a {result.length}-character password: {result.strength} "
                            f"({result.score}/100). Nothing was stored.")

    def on_key(self, _event=None) -> None:
        if self.live_var.get():
            if self.password_var.get():
                try:
                    self.display(analyze_password(self.password_var.get()))
                except ValueError:
                    pass
            else:
                self._show_empty_state()

    def toggle_visibility(self) -> None:
        self.password_entry.configure(show="" if self.show_var.get() else "•")

    def reset(self) -> None:
        """Clear the password field and every result."""
        self.password_var.set("")
        self.show_var.set(False)
        self.toggle_visibility()
        self.last_result = None
        self._show_empty_state()
        self.status_var.set("Cleared. The password field and results have been reset.")
        self.password_entry.focus_set()

    def save_report(self) -> None:
        if self.last_result is None:
            messagebox.showinfo(C.APP_TITLE, "Analyse a password first.")
            return
        C.REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        path = C.REPORTS_DIR / f"report_{datetime.now():%Y%m%d_%H%M%S}.txt"
        try:
            path.write_text(format_report(self.last_result) + f"\n\nGenerated {datetime.now():%Y-%m-%d %H:%M:%S}\n",
                            encoding="utf-8")
        except OSError as exc:
            messagebox.showerror(C.APP_TITLE, f"Could not save the report: {exc}")
            return
        self.status_var.set(f"Report saved to {path} (it does not contain the password).")
        messagebox.showinfo(C.APP_TITLE, f"Report saved:\n{path}\n\nThe password itself is not included.")

    # ------------------------------------------------------------------ generator
    def on_length_change(self, value) -> None:
        length = int(float(value))
        self.gen_length.set(length)
        self.length_value.configure(text=str(length))

    def generate(self) -> None:
        try:
            pw = generate_password(self.gen_length.get(), self.gen_upper.get(), self.gen_lower.get(),
                                   self.gen_digits.get(), self.gen_symbols.get(), self.gen_ambiguous.get())
        except ValueError as exc:
            messagebox.showerror(C.APP_TITLE, str(exc))
            return
        self.generated_var.set(pw)
        result = analyze_password(pw, use_zxcvbn=False)
        self.gen_info.configure(text=f"{len(pw)} characters · scores {result.score}/100 ({result.strength}) · "
                                     "not saved anywhere")
        self.status_var.set("New password generated. Copy it into your password manager.")

    def copy_generated(self) -> None:
        pw = self.generated_var.get()
        if not pw:
            messagebox.showinfo(C.APP_TITLE, "Generate a password first.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(pw)
        self._copied_password = pw
        if self._clear_job is not None:
            self.root.after_cancel(self._clear_job)
        self._clear_job = self.root.after(C.CLIPBOARD_CLEAR_SECONDS * 1000, self.clear_clipboard_if_unchanged)
        self.status_var.set(f"Copied. The clipboard will be cleared in {C.CLIPBOARD_CLEAR_SECONDS} seconds.")

    def clear_clipboard_if_unchanged(self) -> None:
        """Remove our password from the clipboard - but only if the user has not copied something else."""
        self._clear_job = None
        try:
            current = self.root.clipboard_get()
        except tk.TclError:
            current = None
        if self._copied_password is not None and current == self._copied_password:
            self.root.clipboard_clear()
            self.status_var.set("Clipboard cleared for safety.")
        self._copied_password = None

    def send_to_analyzer(self) -> None:
        pw = self.generated_var.get()
        if not pw:
            messagebox.showinfo(C.APP_TITLE, "Generate a password first.")
            return
        self.password_var.set(pw)
        self.notebook.select(self.analyzer_tab)
        self.analyze()

    def clear_generated(self) -> None:
        self.generated_var.set("")
        self.gen_info.configure(text="")

    def on_close(self) -> None:
        if self._copied_password is not None:
            self.clear_clipboard_if_unchanged()
        self.password_var.set("")
        self.generated_var.set("")
        self.root.destroy()


def run() -> None:
    root = tk.Tk()
    PasswordCheckerApp(root)
    root.mainloop()
