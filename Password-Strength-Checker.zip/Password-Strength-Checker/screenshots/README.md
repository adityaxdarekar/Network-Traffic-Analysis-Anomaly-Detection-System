# Screenshots

Take these on Kali after running `python3 main.py` (screenshot tool: `Print` key or `gnome-screenshot -a` /
Kali's "Screenshot" app). Save them in this folder:

| File | What to show |
|---|---|
| 01_weak_password123.png | Analyzer with `password123` → WEAK 10/100 |
| 02_medium_cybersecure24.png | `CyberSecure24` → MEDIUM 58/100 |
| 03_strong_violet_river.png | `Violet!River82Moon` → STRONG 90/100, all checks ✔ |
| 04_generator.png | Generator tab after generating a 20-character password |
| 05_cli.png | Terminal version (`python3 main.py --cli`) |
| 06_tests.png | `./run_tests.sh` showing "Ran 53 tests ... OK" |

Tip: keep "Show password" unticked in screenshots of your own real passwords - better still, only use the
demonstration examples.
