"""
Secure random password generator.

Uses Python's ``secrets`` module, which draws from the operating system's
cryptographically secure random source. The ``random`` module must NOT be used
for passwords: its output is predictable once its internal state is known.

Generated passwords are only returned to the caller - never saved or logged.
"""

from __future__ import annotations

import secrets
import string

import config as C

UPPER = string.ascii_uppercase
LOWER = string.ascii_lowercase
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/~"


def generate_password(length: int = C.GEN_DEFAULT_LENGTH, uppercase: bool = True, lowercase: bool = True,
                      digits: bool = True, symbols: bool = True, exclude_ambiguous: bool = False) -> str:
    """
    Return a random password containing at least one character from every selected group.

    Raises ValueError if the length is out of range or no character group is selected.
    """
    try:
        length = int(length)
    except (TypeError, ValueError) as exc:
        raise ValueError("Length must be a whole number.") from exc
    if not C.GEN_MIN_LENGTH <= length <= C.GEN_MAX_LENGTH:
        raise ValueError(f"Length must be between {C.GEN_MIN_LENGTH} and {C.GEN_MAX_LENGTH}.")
    groups = [g for g, on in ((UPPER, uppercase), (LOWER, lowercase), (DIGITS, digits), (SYMBOLS, symbols)) if on]
    if exclude_ambiguous:
        groups = ["".join(ch for ch in g if ch not in C.GEN_AMBIGUOUS) for g in groups]
    if not groups:
        raise ValueError("Select at least one character type.")
    alphabet = "".join(groups)
    # One guaranteed character from each selected group, the rest from the whole alphabet ...
    chars = [secrets.choice(g) for g in groups]
    chars += [secrets.choice(alphabet) for _ in range(length - len(chars))]
    # ... then shuffle with a cryptographically secure shuffle so the guaranteed ones are not at the start.
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)
