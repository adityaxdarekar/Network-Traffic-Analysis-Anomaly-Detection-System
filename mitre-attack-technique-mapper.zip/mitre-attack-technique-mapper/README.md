# MITRE ATT&CK Technique Mapper (Python)

The Mapper reads threat-intelligence text (typed or pasted text, TXT, PDF or JSON), finds attacker behaviours, and suggests the matching **MITRE ATT&CK** techniques and tactics. Every suggestion comes with its evidence sentence and a match score. An analyst can accept, reject, confirm or change each suggestion. Results export as an **ATT&CK Navigator layer** and as reports in HTML, PDF, JSON and CSV.

> **Knowledge source:** the official MITRE ATT&CK Enterprise STIX 2.1 dataset ([attack-stix-data](https://github.com/mitre-attack/attack-stix-data)). The Mapper reads the following from whichever version you load:
> * tactics and their order;
> * techniques and sub-techniques, with their IDs, names, descriptions and platforms;
> * data sources and mitigations;
> * which entries are revoked or deprecated.
>
> No technique list is hard-coded. For example, ATT&CK v20 replaced *Defense Evasion* with **Stealth (TA0005)** and **Defense Impairment (TA0112)**, and the app follows whatever the loaded dataset says.
>
> Read **PROJECT_STATUS.md** to see what was verified and what was not.

---

## PHASE 1 - Architecture and working method

```
 input (text / TXT / PDF / JSON / sample)          official enterprise-attack.json (STIX 2.1)
        │ document_loader.py (validation)                     │ attack_loader.py
        ▼                                                     ▼ parse → cached index → KnowledgeBase
 text_processor.py  normalise, sentences, tokens,        (tactics in matrix order, techniques,
                    keywords, verbs, IOCs                  sub-techniques, revoked/deprecated,
        ▼                                                  mitigations, TF-IDF vectors)
 ttp_extractor.py   ~30 behaviour rules → Behavior               │
   (evidence sentence, keywords, explicit/inferred,              │
    hedged/negated, extraction confidence)                       │
        ▼                                                        │
 technique_mapper.py  rule hints (verified in KB)  +  TF-IDF cosine top-k  ◄─┘
        ▼             confidence_scorer.py → 0-99 match score + band
 tactic_classifier.py   group by tactic (dataset order)
        ▼
 pipeline.py  Analysis  →  database.py (SQLite + review log)  →  analyst review
        ▼
 navigator_exporter.py (layer 4.5)     report_generator.py (HTML / PDF / JSON / CSV)
        ▲                                    ▲
     app.py (Streamlit dashboard)      main.py (CLI)
```

**How a mapping is made:**
1. **Keyword matching.** The keywords tied to a behaviour are looked for in the sentence.
2. **Rule-based matching.** Each extraction rule has technique *hints*, and every hint is checked against the loaded dataset:
   * a revoked ID is replaced by its official successor;
   * a deprecated or unknown ID is dropped, with a warning.
3. **TF-IDF vectorisation.** All active techniques are vectorised from their name and description.
4. **Cosine similarity.** The evidence sentence is compared with every technique, and the top *k* are added as candidates.
5. **Contextual analysis.** The score is adjusted for:
   * whether the behaviour is explicit or inferred;
   * hedging, such as "attempted" or "likely";
   * negation, such as "no evidence of";
   * conditions on a rule, for example T1041 only scores fully when the text mentions a C2 channel.

**Match score.** Each candidate gets a score from 0 to 99, combining the rule, keyword, name-similarity, description-similarity, specificity and context components. The weights are in `config.json`.

| Band | Score |
|---|---|
| HIGH | 90 or more |
| MEDIUM-HIGH | 70–89 |
| MEDIUM | 50–69 |
| LOW | below 50 |

**The score is a ranking heuristic, not a probability.**

**Primary and alternative candidates.** The best candidates for each behaviour are *primary*; weaker ones are *alternatives* the analyst can accept. Summaries, tactic counts and Navigator include only primary suggestions plus anything accepted or confirmed.

**Review status.** Every suggestion starts as **AWAITING_REVIEW**. It becomes **CONFIRMED** only through an explicit analyst action, and every decision is logged.

---

## PHASE 2 - Folder structure and dependencies
```
mitre-attack-technique-mapper/
├── app.py                     Streamlit dashboard (10 sections, dark SOC theme)
├── main.py                    CLI: download, info, analyze, review, export, search, technique, list, samples
├── modules/
│   ├── text_processor.py      normalisation, sentence split, tokenisation, keyword/verb/IOC tagging (spaCy/NLTK/regex)
│   ├── ttp_extractor.py       behaviour rules → Behavior records (evidence, explicit/inferred, hedged/negated)
│   ├── attack_loader.py       STIX bundle parsing, revoked/deprecated, mitigations, cache, download, TF-IDF search
│   ├── technique_mapper.py    rules + TF-IDF/cosine candidates, primary/alternative roles, technique view
│   ├── confidence_scorer.py   weighted match score and bands
│   ├── tactic_classifier.py   grouping by tactic in dataset order
│   ├── navigator_exporter.py  Navigator layer 4.5 + validation
│   ├── report_generator.py    HTML / PDF / JSON / CSV reports
│   ├── document_loader.py     TXT/PDF/JSON/MD input + validation
│   ├── database.py            SQLite: analyses, mappings, review log
│   ├── pipeline.py            Analyzer + Analysis (review actions)
│   └── config.py              config.json loading/validation
├── data/attack-enterprise.json      (downloaded - not shipped)
├── data/sample_reports/             4 fictional reports + 1 JSON example
├── database/mappings.db             (created at first save)
├── reports/                         generated reports
├── tests/                           test_extractor.py, test_mapper.py, test_attack_data.py, test_app_smoke.py
│   └── fixtures/                    labelled STIX TEST FIXTURE + the script that builds it
├── sample_output/  screenshots/     sample results (from the fixture - labelled)
├── docs/  DEMO_GUIDE.md  PROJECT_REPORT.md  VIVA_QUESTIONS.md
├── .streamlit/config.toml           dark theme
├── requirements.txt  config.json  PROJECT_STATUS.md
```

---

## PHASE 3 - Installation and ATT&CK dataset setup (Kali Linux / Ubuntu)

```bash
# 1. Python
sudo apt update && sudo apt install -y python3 python3-venv python3-pip
# 2. Virtual environment
cd ~/projects && unzip mitre-attack-technique-mapper.zip && cd mitre-attack-technique-mapper
python3 -m venv venv && source venv/bin/activate
# 3. Dependencies
pip install --upgrade pip
pip install -r requirements.txt
#    optional NLP backend (otherwise the built-in regex pipeline is used)
pip install spacy && python -m spacy download en_core_web_sm
# 4. Official ATT&CK dataset (≈ 45 MB, parsed once and cached)
python3 main.py download
#    manual alternative: save
#    https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/enterprise-attack/enterprise-attack.json
#    as data/attack-enterprise.json
python3 main.py info              # shows version, counts and the tactic list
# 5. Configuration: edit config.json (thresholds, weights, colours) - optional
# 6. Database: created automatically on the first saved analysis (database/mappings.db)
# 7. Tests (optional)
python3 -m pytest -q
# 8. Run
streamlit run app.py              # dashboard at http://localhost:8501
python3 main.py analyze --sample test1_phishing --save --report html,pdf --navigator layer.json
```
To pin a specific ATT&CK version, download a versioned file such as `enterprise-attack-18.1.json` from the same repository, and point `attack.dataset_path` at it.

---

## PHASE 5 - Running the dashboard
`streamlit run app.py` opens the dashboard. The sidebar has the 10 sections:

1. Home Dashboard
2. Upload Threat Intelligence
3. Manual Text Analysis
4. Extracted TTPs
5. ATT&CK Technique Mapping
6. Tactic Analysis
7. Analyst Review
8. Navigator Export
9. Generate Reports
10. About Project

If the dataset is missing, the sidebar offers a **download** button. You can also tick **demo mode** to try the small, labelled test fixture.

## PHASE 6 - Practical tests
See **docs/DEMO_GUIDE.md**. The three test reports from the brief are in `data/sample_reports/`, with their output in `sample_output/test_runs_terminal.txt`.

## PHASE 7 - Navigator export and reports
```bash
python3 main.py export 1 --navigator layer.json --report html,pdf,json,csv
```
To view the layer, open https://mitre-attack.github.io/attack-navigator/, choose **Open Existing Layer**, then **Upload from local**, and select `layer.json`.

How the layer is built:
* Its `versions.attack` comes from the loaded dataset.
* Each technique entry carries its score, a colour by status or band, a comment, the evidence as metadata, and its tactic.
* Parent techniques are added so mapped sub-techniques are visible.
* Rejected mappings are left out by default.

## PHASE 8 - Documentation
`docs/PROJECT_REPORT.md` contains the 20-section college report. `docs/VIVA_QUESTIONS.md` contains 34 viva questions with answers.
