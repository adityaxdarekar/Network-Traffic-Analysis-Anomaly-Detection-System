#!/usr/bin/env python3
"""
main.py - command-line interface for the MITRE ATT&CK Technique Mapper.

    python3 main.py download                       # fetch the official Enterprise STIX bundle
    python3 main.py info                           # dataset version and counts
    python3 main.py analyze --sample test1_phishing --save --report html,pdf --navigator layer.json
    python3 main.py analyze --file report.pdf --save
    python3 main.py analyze --text "The attacker used PowerShell ..."
    python3 main.py review 1 M2 confirm --comment "seen in EDR telemetry" --analyst alice
    python3 main.py export 1 --report html,json,csv,pdf --navigator layer.json
    python3 main.py search "registry run keys"     # search the knowledge base
    python3 main.py technique T1059.001            # technique details
    python3 main.py list                           # stored analyses

The Streamlit dashboard is started with:  streamlit run app.py
"""
from __future__ import annotations

import argparse
import sys
import textwrap
from pathlib import Path

from modules.attack_loader import AttackDataError, download_dataset, load_knowledge_base, validate_with_stix2
from modules.config import ConfigError, load_config
from modules.database import MappingDatabase
from modules.document_loader import DocumentError, from_text, list_samples, load_file
from modules.navigator_exporter import build_layer, layer_json, validate_layer
from modules.pipeline import ACTIONS, Analysis, Analyzer, ReviewError
from modules.report_generator import build_report_data, save_reports


def _kb(cfg, args):
    dataset = Path(args.dataset) if args.dataset else cfg.path("attack", "dataset_path")
    cache = None if args.dataset else cfg.path("attack", "index_cache_path")
    return load_knowledge_base(dataset, cache, use_cache=cache is not None)


def _print_analysis(a: Analysis, kb, show_alternatives: bool):
    s = a.summary()
    print("=" * 64)
    print("MITRE ATT&CK TECHNIQUE MAPPER")
    print("=" * 64)
    print(f"Input: {a.document_name}    ATT&CK: {a.attack_version}{'  (TEST FIXTURE)' if a.fixture else ''}"
          f"    NLP backend: {a.backend}")
    print("\nANALYSIS SUMMARY:")
    print(f"  Behaviors Extracted: {s['behaviors']} ({s['explicit_behaviors']} explicit, "
          f"{s['inferred_behaviors']} inferred)")
    print(f"  Techniques Suggested: {s['techniques']}")
    print(f"  Tactics Identified: {s['tactics']}")
    print(f"  High / Medium / Low: {s['high']} / {s['medium']} / {s['low']}")
    print("\nMAPPED TECHNIQUES:  (match scores are heuristic, not probabilities)")
    for m in a.mappings:
        if m.role != "primary" and not show_alternatives:
            continue
        tag = "" if m.role == "primary" else "  [alternative]"
        print(f"\n[{m.band} CONFIDENCE]{tag}  {m.id}")
        print(f"  {m.technique_id} - {m.technique_name}")
        print(f"  Tactic: {m.primary_tactic_name}    Score: {m.effective_score}    Origin: {m.origin}")
        print(f"  Behavior: {m.behavior} ({m.mode}{', hedged' if m.hedged else ''}{', NEGATED' if m.negated else ''})")
        print(textwrap.fill(f'Evidence: "{m.evidence}"', 96, initial_indent="  ", subsequent_indent="    "))
        for n in m.notes:
            print(f"  note: {n}")
        print(f"  Status: {m.status.replace('_', ' ').title()}")
    if a.similarity_only:
        print("\nSIMILARITY-ONLY SUGGESTIONS (no rule matched; low confidence):")
        for x in a.similarity_only:
            print(f"  {x['technique_id']} {x['technique_name']} (cosine {x['cosine']}) <- \"{x['sentence'][:90]}\"")
    print("\nTACTICS:")
    for g in a.tactic_groups(kb):
        print(f"  {g.name:<22} {g.count}  {', '.join(g.technique_ids)}")
    for w in a.warnings:
        print(f"[!] {w}")
    if a.analysis_id:
        print(f"\nSaved as analysis {a.analysis_id}. Review with: python3 main.py review {a.analysis_id} <mapping> "
              f"<action>")


def _export(a: Analysis, kb, cfg, report: str | None, navigator: str | None, alternatives: bool):
    if report:
        fmts = [f.strip().lower() for f in report.split(",") if f.strip()]
        paths = save_reports(build_report_data(a, kb), cfg.path("paths", "reports"), fmts)
        for f, p in paths.items():
            print(f"[+] {f.upper()} report: {p}")
    if navigator:
        layer = build_layer(a, kb, cfg, include_alternatives=alternatives)
        problems = validate_layer(layer, kb)
        if problems:
            print("[x] Navigator layer failed validation: " + "; ".join(problems))
            return 1
        Path(navigator).write_text(layer_json(layer), encoding="utf-8")
        print(f"[+] Navigator layer ({len(layer['techniques'])} entries): {navigator}")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="MITRE ATT&CK Technique Mapper")
    p.add_argument("--config")
    p.add_argument("--dataset", help="use this STIX bundle instead of the configured one")
    sub = p.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("download", help="download the official ATT&CK Enterprise dataset")
    d.add_argument("--force", action="store_true")
    sub.add_parser("info", help="show dataset version and counts")
    s = sub.add_parser("search", help="search techniques")
    s.add_argument("query")
    t = sub.add_parser("technique", help="show one technique")
    t.add_argument("technique_id")
    a = sub.add_parser("analyze", help="analyse threat intelligence")
    src = a.add_mutually_exclusive_group(required=True)
    src.add_argument("--file")
    src.add_argument("--text")
    src.add_argument("--sample", help="name of a file in data/sample_reports (without extension)")
    a.add_argument("--save", action="store_true", help="store the analysis in the database")
    a.add_argument("--report", help="comma list: html,pdf,json,csv")
    a.add_argument("--navigator", help="write a Navigator layer JSON to this path")
    a.add_argument("--alternatives", action="store_true", help="also show/export alternative candidates")
    r = sub.add_parser("review", help="record an analyst decision")
    r.add_argument("analysis_id", type=int)
    r.add_argument("mapping_id")
    r.add_argument("action", choices=ACTIONS)
    r.add_argument("--technique")
    r.add_argument("--score", type=int)
    r.add_argument("--comment", default="")
    r.add_argument("--analyst", default="analyst")
    r.add_argument("--behavior")
    e = sub.add_parser("export", help="export a stored analysis")
    e.add_argument("analysis_id", type=int)
    e.add_argument("--report")
    e.add_argument("--navigator")
    e.add_argument("--alternatives", action="store_true")
    sub.add_parser("list", help="list stored analyses")
    sub.add_parser("samples", help="list sample reports")
    args = p.parse_args(argv)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"[x] {exc}")
        return 2

    if args.cmd == "download":
        dest = cfg.path("attack", "dataset_path")
        if dest.exists() and not args.force:
            print(f"[*] {dest} already exists (use --force to re-download)")
        else:
            try:
                print(f"[*] Downloading {cfg['attack']['download_url']} ...")
                download_dataset(cfg["attack"]["download_url"], dest, cfg["attack"]["download_timeout_seconds"])
            except AttackDataError as exc:
                print(f"[x] {exc}")
                return 1
        try:
            kb = load_knowledge_base(dest, cfg.path("attack", "index_cache_path"))
        except AttackDataError as exc:
            print(f"[x] {exc}")
            return 1
        print(f"[+] ATT&CK {kb.version}: {kb.stats()}")
        print(f"[*] {validate_with_stix2(dest)}")
        return 0
    if args.cmd == "samples":
        for f in list_samples(cfg.path("paths", "sample_reports")):
            print(f"  {f.stem:<28} {f.name}")
        return 0

    try:
        kb = _kb(cfg, args)
    except AttackDataError as exc:
        print(f"[x] {exc}")
        return 1

    if args.cmd == "info":
        for k, v in kb.stats().items():
            print(f"  {k:<14} {v}")
        print("  tactics:       " + ", ".join(f"{t.name} ({t.id})" for t in kb.ordered_tactics()))
        return 0
    if args.cmd == "search":
        for tech, score in kb.search(args.query):
            print(f"  {tech.id:<10} {kb.full_name(tech):<60} {', '.join(tech.tactics)}  ({score:.2f})")
        return 0
    if args.cmd == "technique":
        tech = kb.get(args.technique_id)
        if tech is None:
            print(f"[x] {args.technique_id} is not in the loaded dataset")
            return 1
        from modules.text_processor import strip_markup
        print(f"{tech.id} - {kb.full_name(tech)}{'  [REVOKED -> ' + str(tech.revoked_by) + ']' if tech.revoked else ''}"
              f"{'  [DEPRECATED]' if tech.deprecated else ''}")
        print(f"Tactics: {', '.join(kb.tactic_name(x) for x in tech.tactics)}")
        print(f"Platforms: {', '.join(tech.platforms)}")
        print(f"Data sources: {', '.join(tech.data_sources) or '-'}")
        print(f"Mitigations: {', '.join(m['id'] + ' ' + m['name'] for m in tech.mitigations) or '-'}")
        print(f"URL: {tech.url}")
        print(textwrap.fill(strip_markup(tech.description), 100))
        return 0

    db = MappingDatabase(cfg.path("paths", "database"))
    try:
        if args.cmd == "list":
            for row in db.analyses():
                sm = row["summary"]
                print(f"  {row['id']:>4}  {row['created']}  {row['document_name']:<36} techniques={sm.get('techniques')} "
                      f"tactics={sm.get('tactics')} confirmed={sm.get('confirmed')} ATT&CK {row['attack_version']}")
            return 0
        if args.cmd == "analyze":
            try:
                lim = dict(max_mb=cfg["input"]["max_upload_mb"], allowed=tuple(cfg["input"]["allowed_extensions"]),
                           max_chars=cfg["input"]["max_characters"])
                if args.file:
                    doc = load_file(args.file, **lim)
                elif args.text:
                    doc = from_text(args.text, max_chars=lim["max_chars"])
                else:
                    match = [f for f in list_samples(cfg.path("paths", "sample_reports")) if f.stem == args.sample]
                    if not match:
                        print(f"[x] sample {args.sample!r} not found; see: python3 main.py samples")
                        return 1
                    doc = load_file(match[0], **lim)
                    doc.kind = "sample"
            except DocumentError as exc:
                print(f"[x] {exc}")
                return 1
            analysis = Analyzer(cfg, kb).analyze(doc, db=db if args.save else None)
            _print_analysis(analysis, kb, args.alternatives)
            return _export(analysis, kb, cfg, args.report, args.navigator, args.alternatives)
        if args.cmd in ("review", "export"):
            try:
                analysis = Analysis.from_db(db, args.analysis_id)
            except ReviewError as exc:
                print(f"[x] {exc}")
                return 1
            if args.cmd == "review":
                try:
                    m = analysis.review(args.mapping_id, args.action, analyst=args.analyst, comment=args.comment,
                                        technique_id=args.technique, score=args.score, behavior_text=args.behavior,
                                        kb=kb, db=db)
                except ReviewError as exc:
                    print(f"[x] {exc}")
                    return 1
                print(f"[+] {m.id}: {m.technique_id} {m.technique_name} -> {m.status} (score {m.effective_score})")
                return 0
            return _export(analysis, kb, cfg, args.report, args.navigator, args.alternatives)
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
