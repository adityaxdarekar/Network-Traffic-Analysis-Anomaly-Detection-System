# Project status - verified vs. still to verify

## Build environment limits
* The build sandbox had **no internet access from the shell** and **could not install packages**.
* Streamlit, Plotly, spaCy, NLTK and stix2 were not installed. scikit-learn, pandas, pypdf and reportlab were available.
* The official ATT&CK dataset therefore could not be downloaded or tested here. Testing used a **labelled STIX test fixture** (`tests/fixtures/attack_fixture.json`, built by `build_fixture.py`):
  * 15 tactics in v20 matrix order and 39 techniques;
  * IDs, names and tactic placements checked against attack.mitre.org (ATT&CK v20) on 2026-11-07;
  * **descriptions are short paraphrases, not MITRE text**, and the mitigation links are approximate test data.

## ✅ Verified here
| Item | Evidence |
|---|---|
| 34 automated tests pass | `python3 -m pytest -q` |
| STIX parsing: tactic order, sub-techniques, revoked-by replacement, deprecated exclusion, duplicate IDs, mitigations | `test_attack_data.py` (fixture) |
| Cache invalidated by SHA-256; download success, network failure and invalid-content handling (atomic, never destroys the old copy) | tests with mocked HTTP |
| NLP keeps technical terms; abbreviations; re-fanging; IOC tagging | `test_extractor.py` |
| Extraction for the brief's 3 tests, plus explicit/inferred, hedged and negated cases | tests and `sample_output/test_runs_terminal.txt` |
| Every mapping ID exists in the loaded dataset; evidence is a real input sentence; no fabricated IDs | `test_mapper.py` |
| T1041 is held back when no C2 channel is mentioned | test |
| Review actions, refusal of invalid transitions, audit log, reload from DB | tests and the CLI run |
| Navigator layer structure (layer 4.5) validated against the loaded dataset | tests and `sample_output/sample_navigator_layer.json` |
| HTML/PDF/JSON/CSV reports (HTML escaping, PDF text readable) | tests, `sample_output/`, `screenshots/` |
| Dashboard code paths for all 10 sections | `test_app_smoke.py` with a **Streamlit stand-in** |

## ⚠️ Not verified - please check on your machine
| Item | How |
|---|---|
| **Full official dataset** (about 700 techniques) | `python3 main.py download`, then `python3 main.py info`, `python3 -m pytest -q` and the demo guide. Scores and alternatives can differ from the fixture results. |
| **Real Streamlit UI** (layout, widgets, Plotly charts) | `streamlit run app.py` and click through all 10 sections |
| **Import into ATT&CK Navigator** | upload `sample_output/sample_navigator_layer.json` or your own layer at https://mitre-attack.github.io/attack-navigator/. The sample says ATT&CK "20"; Navigator may warn if its loaded version differs. |
| spaCy / NLTK backends | install them; the app switches automatically (the regex backend was used here) |
| stix2 validation | `pip install stix2`, then `python3 main.py download` prints the result |
| TAXII | not implemented (optional in the brief); the GitHub bundle is used instead |

`sample_output/` and `screenshots/` were produced with the fixture, and the report shows a TEST FIXTURE banner.
