"""
text_processor.py - NLP preprocessing for threat-intelligence text.

Uses spaCy (en_core_web_sm) or NLTK when they are installed; otherwise falls
back to a built-in regex pipeline, so the app always works. Whichever backend
runs, technical terms are preserved: file names (cmd.exe), registry paths
(HKCU\\Software\\...), ATT&CK IDs (T1059.001), IPs, hashes and tool names are
never lower-cased away, split or removed as stop words.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

# --- vocabularies used to tag sentences (lower-case) ---------------------------
TOOLS = ["powershell", "cmd.exe", "cmd", "wmic", "wmi", "mimikatz", "psexec", "rundll32", "regsvr32", "certutil",
         "bitsadmin", "mshta", "schtasks", "cobalt strike", "anydesk", "teamviewer", "ngrok", "rclone", "7-zip",
         "winrar", "procdump", "net.exe", "nltest", "whoami", "tasklist", "systeminfo", "bloodhound", "metasploit"]
PROTOCOLS = ["http", "https", "dns", "smb", "rdp", "ssh", "ftp", "sftp", "tls", "ssl", "ldap", "kerberos",
             "smtp", "imap", "icmp", "tcp", "udp", "vpn", "winrm"]
OS_TERMS = ["windows", "linux", "macos", "registry", "active directory", "domain controller", "lsass",
            "event log", "startup folder", "run key", "run keys", "scheduled task", "service", "kernel"]
SECURITY_TERMS = ["phishing", "spearphishing", "attachment", "malicious", "macro", "payload", "malware",
                  "exploit", "vulnerability", "credential", "credentials", "password", "hash", "persistence",
                  "lateral", "exfiltration", "exfiltrate", "command and control", "c2", "beacon", "backdoor",
                  "implant", "ransomware", "encrypt", "obfuscate", "privilege", "escalation", "discovery",
                  "reconnaissance", "dump", "keylogger", "webshell", "web shell"]
ACTION_VERBS = ["gain", "access", "execute", "run", "launch", "invoke", "establish", "modify", "create", "add",
                "delete", "clear", "collect", "gather", "harvest", "dump", "extract", "steal", "transfer",
                "upload", "download", "send", "exfiltrate", "move", "pivot", "enumerate", "discover", "scan",
                "exploit", "deliver", "distribute", "open", "click", "encrypt", "compress", "archive", "inject",
                "disable", "install", "persist", "escalate", "obtain", "connect", "communicate", "copy"]

ABBREVIATIONS = {"e.g", "i.e", "etc", "vs", "inc", "ltd", "corp", "mr", "mrs", "dr", "fig", "no", "approx", "u.s"}

_TECH_TOKEN = re.compile(
    r"(?:[A-Za-z]:\\[^\s,;]+)"                       # Windows path C:\...
    r"|(?:HK(?:LM|CU|CR|U|CC)\\[^\s,;]+)"            # registry path
    r"|(?:\b\d{1,3}(?:\.\d{1,3}){3}\b)"               # IPv4
    r"|(?:\bT\d{4}(?:\.\d{3})?\b)"                    # ATT&CK technique ID
    r"|(?:\b[A-Za-z0-9_\-]+\.(?:exe|dll|ps1|bat|vbs|js|hta|lnk|docm|xlsm|zip|rar|7z|iso)\b)"
    r"|(?:[A-Za-z0-9][A-Za-z0-9_\-\.]*[A-Za-z0-9])"  # words, versions, domains
    r"|(?:[A-Za-z0-9])")
_IP = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
_HASH = re.compile(r"\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{64}\b")
_REG = re.compile(r"\bHK(?:LM|CU|CR|U|CC)\\[^\s,;\"']+", re.I)
_FILE = re.compile(r"\b[\w\-]+\.(?:exe|dll|ps1|bat|vbs|js|hta|lnk|docm|xlsm|zip|rar|7z|iso)\b", re.I)
_CVE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.I)
_DOMAIN = re.compile(r"\b(?:[a-z0-9\-]+\.)+(?:com|net|org|io|ru|cn|info|biz|xyz|top|example|test|local)\b", re.I)


@dataclass
class Sentence:
    index: int
    text: str
    lower: str
    tokens: list = field(default_factory=list)
    keywords: dict = field(default_factory=dict)      # category -> [terms]
    verbs: list = field(default_factory=list)
    entities: dict = field(default_factory=dict)      # ips, hashes, files, registry, cves, domains


@dataclass
class ProcessedDocument:
    name: str
    raw_text: str
    clean_text: str
    sentences: list
    backend: str

    def keyword_summary(self) -> dict:
        out: dict = {}
        for s in self.sentences:
            for cat, terms in s.keywords.items():
                out.setdefault(cat, set()).update(terms)
        return {k: sorted(v) for k, v in out.items()}


# --------------------------------------------------------------- helpers
def strip_markup(text: str) -> str:
    """Remove ATT&CK description markup: (Citation: X), markdown links, HTML tags, code ticks."""
    text = re.sub(r"\(Citation:[^)]*\)", " ", text or "")
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = text.replace("<code>", " ").replace("</code>", " ").replace("`", "")
    return re.sub(r"\s+", " ", text).strip()


def normalize(text: str) -> str:
    """Clean formatting while keeping technical content intact."""
    text = unicodedata.normalize("NFKC", text or "")
    text = text.replace("\u2019", "'").replace("\u2018", "'").replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", " - ").replace("\u00a0", " ")
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)                 # re-join words hyphenated across lines
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", text)  # control characters
    text = re.sub(r"^\s*[-*\u2022]\s+", "", text, flags=re.M)     # bullet markers
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "\n\n", text)
    return text.strip()


def defang(text: str) -> str:
    """Re-fang common defanged indicators (hxxp, [.]) so they are recognised."""
    return text.replace("hxxp", "http").replace("[.]", ".").replace("(.)", ".").replace("[:]", ":")


def simple_stem(word: str) -> str:
    """Tiny suffix stripper used for keyword overlap (Porter stemmer when NLTK exists)."""
    w = word.lower()
    for suf in ("ations", "ation", "ingly", "ings", "ing", "edly", "ed", "ies", "es", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            w = w[: -len(suf)]
            break
    return w


def tokenize(text: str) -> list[str]:
    return [m.group(0) for m in _TECH_TOKEN.finditer(text)]


def _split_regex(text: str) -> list[str]:
    parts: list[str] = []
    buf = ""
    for para in re.split(r"\n\s*\n", text):
        para = " ".join(para.split())
        pieces = re.split(r"(?<=[.!?])\s+(?=[\"'(\[]?[A-Z0-9])", para)
        for piece in pieces:
            candidate = (buf + " " + piece).strip() if buf else piece
            last = candidate.rsplit(" ", 1)[-1].rstrip(".").lower()
            if last in ABBREVIATIONS:
                buf = candidate
                continue
            buf = ""
            if candidate:
                parts.append(candidate)
        if buf:
            parts.append(buf)
            buf = ""
    return [p for p in parts if p.strip()]


class TextProcessor:
    """Sentence splitting + tagging, with an optional spaCy/NLTK backend."""

    def __init__(self, prefer: str = "auto"):
        self.backend = "regex"
        self._nlp = None
        self._stemmer = None
        if prefer in ("auto", "spacy"):
            try:
                import spacy
                self._nlp = spacy.load("en_core_web_sm", disable=["ner"])
                self.backend = "spacy"
            except Exception:
                self._nlp = None
        if self._nlp is None and prefer in ("auto", "nltk"):
            try:
                import nltk
                nltk.data.find("tokenizers/punkt")
                from nltk.stem import PorterStemmer
                self._stemmer = PorterStemmer()
                self.backend = "nltk"
            except Exception:
                self._stemmer = None

    def stem(self, word: str) -> str:
        if self._stemmer is not None:
            return self._stemmer.stem(word.lower())
        return simple_stem(word)

    def split_sentences(self, text: str) -> list[str]:
        if self.backend == "spacy":
            return [s.text.strip() for s in self._nlp(text).sents if s.text.strip()]
        if self.backend == "nltk":
            import nltk
            out = []
            for para in re.split(r"\n\s*\n", text):
                out += [s.strip() for s in nltk.sent_tokenize(" ".join(para.split())) if s.strip()]
            return out
        return _split_regex(text)

    @staticmethod
    def _find_terms(lower: str, vocab: list[str]) -> list[str]:
        found = []
        for term in vocab:
            if re.search(r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])", lower):
                found.append(term)
        return found

    def tag(self, index: int, text: str) -> Sentence:
        lower = text.lower()
        tokens = tokenize(text)
        stems = {self.stem(t) for t in tokens}
        keywords = {cat: terms for cat, terms in (
            ("tools", self._find_terms(lower, TOOLS)), ("protocols", self._find_terms(lower, PROTOCOLS)),
            ("os", self._find_terms(lower, OS_TERMS)), ("security", self._find_terms(lower, SECURITY_TERMS)))
            if terms}
        verbs = sorted({v for v in ACTION_VERBS if self.stem(v) in stems or v in lower.split()})
        entities = {k: sorted(set(rx.findall(text))) for k, rx in (
            ("ips", _IP), ("hashes", _HASH), ("registry", _REG), ("files", _FILE), ("cves", _CVE),
            ("domains", _DOMAIN))}
        entities = {k: v for k, v in entities.items() if v}
        return Sentence(index, text, lower, tokens, keywords, verbs, entities)

    def process(self, text: str, name: str = "manual input") -> ProcessedDocument:
        clean = normalize(defang(text))
        sentences = [self.tag(i, s) for i, s in enumerate(self.split_sentences(clean))]
        return ProcessedDocument(name=name, raw_text=text, clean_text=clean, sentences=sentences,
                                 backend=self.backend)
