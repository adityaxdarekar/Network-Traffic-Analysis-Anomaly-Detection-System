"""
report_generator.py - CTI/SOC-style reports in HTML, PDF, JSON and CSV.

Every report contains: title, analysis date/time, input document name, a short
threat-intelligence summary, extracted behaviours, mapped tactics, technique IDs
and descriptions, evidence sentences, match scores (with the caveat that they
are not probabilities), analyst review status, mapping limitations and
recommended defensive actions (ATT&CK mitigations from the loaded dataset).
"""
from __future__ import annotations

import csv
import html
import io
import json
from datetime import datetime
from pathlib import Path

TITLE = "MITRE ATT&CK Technique Mapping Report"
LIMITATIONS = [
    "Mappings are suggestions produced by rules, keyword matching and TF-IDF cosine similarity. They are not "
    "confirmed findings until an analyst confirms them.",
    "Match scores (0-99) are heuristic rankings, not statistically calibrated probabilities.",
    "The engine reads sentence by sentence; behaviour described across several sentences, or implied only by "
    "context, can be missed or inferred incorrectly.",
    "Hedged ('attempted', 'likely') and negated ('did not') wording is detected with simple patterns and can be "
    "misread.",
    "Only techniques present in the loaded ATT&CK dataset can be suggested; results depend on that version.",
    "Indicators (IPs, hashes, domains) are extracted for context only; they are not enriched or validated.",
]


def _summary_text(analysis, groups) -> str:
    s = analysis.summary()
    chain = " -> ".join(g.name for g in groups if g.count)
    first = ""
    if analysis.doc is not None and analysis.doc.sentences:
        first = " ".join(x.text for x in analysis.doc.sentences[:2])
    elif analysis.text:
        first = analysis.text.strip().split("\n")[0][:400]
    return (f"The document '{analysis.document_name}' describes {s['behaviors']} attacker behaviour(s) "
            f"({s['explicit_behaviors']} explicit, {s['inferred_behaviors']} inferred), suggesting {s['techniques']} "
            f"ATT&CK technique(s) across {s['tactics']} tactic(s){': ' + chain if chain else ''}. "
            f"Opening of the report: \"{first[:400]}\"")


def build_report_data(analysis, kb) -> dict:
    groups = analysis.tactic_groups(kb)
    rows = analysis.technique_rows()
    mitig: dict[str, dict] = {}
    for m in analysis.counted():
        for mi in m.mitigations:
            entry = mitig.setdefault(mi["id"], {"id": mi["id"], "name": mi["name"], "techniques": []})
            if m.technique_id not in entry["techniques"]:
                entry["techniques"].append(m.technique_id)
    actions = sorted(mitig.values(), key=lambda x: (-len(x["techniques"]), x["id"]))
    return {
        "title": TITLE,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "analysis_created": analysis.created,
        "analysis_id": analysis.analysis_id,
        "document_name": analysis.document_name,
        "document_kind": analysis.document_kind,
        "attack_version": analysis.attack_version,
        "dataset_is_test_fixture": analysis.fixture,
        "threat_summary": _summary_text(analysis, groups),
        "summary": analysis.summary(),
        "behaviors": [b.to_dict() for b in analysis.behaviors],
        "tactics": [g.to_dict() for g in groups],
        "techniques": rows,
        "mappings": [m.to_dict() for m in analysis.mappings],
        "similarity_only": analysis.similarity_only,
        "warnings": analysis.warnings,
        "limitations": LIMITATIONS + (["This report was produced with the TEST FIXTURE dataset, not the official "
                                       "ATT&CK data."] if analysis.fixture else []),
        "recommended_actions": actions,
        "score_note": "Match scores are heuristic (0-99) and are not probabilities.",
    }


def _e(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


STATUS_COLOR = {"CONFIRMED": "#22c55e", "ACCEPTED": "#4ade80", "AWAITING_REVIEW": "#facc15", "REJECTED": "#9ca3af"}
BAND_COLOR = {"HIGH": "#38bdf8", "MEDIUM-HIGH": "#2dd4bf", "MEDIUM": "#facc15", "LOW": "#fb923c"}


def to_html(r: dict) -> str:
    s = r["summary"]
    tactic_rows = "".join(
        f"<tr><td>{_e(t['tactic'])}<div class='muted'>{_e(t['tactic_id'])}</div></td>"
        f"<td class='num'>{t['technique_count']}</td><td>{_e(', '.join(t['technique_ids']))}</td>"
        f"<td>{'<br>'.join(_e(x) for x in t['evidence'][:3])}</td></tr>" for t in r["tactics"]) \
        or "<tr><td colspan='4'>No tactics identified.</td></tr>"
    map_rows = "".join(
        f"<tr><td>{_e(m['behavior'])}<div class='muted'>{_e(m['behavior_id'])} &middot; {_e(m['mode'])}"
        f"{' &middot; hedged' if m['hedged'] else ''}{' &middot; NEGATED' if m['negated'] else ''}</div></td>"
        f"<td><a href='{_e(m['url'])}'>{_e(m['technique_id'])}</a></td><td>{_e(m['technique_name'])}"
        f"<div class='muted'>{_e(m['role'])} &middot; {_e(m['origin'])}</div></td>"
        f"<td>{_e(m['primary_tactic_name'])}</td>"
        f"<td><span class='pill' style='background:{BAND_COLOR.get(m['band'], '#888')}'>{m['effective_score']} "
        f"{_e(m['band'])}</span></td>"
        f"<td><span class='pill' style='background:{STATUS_COLOR.get(m['status'], '#888')}'>"
        f"{_e(m['status'].replace('_', ' '))}</span>"
        f"{'<div class=muted>' + _e(m['analyst_comment']) + '</div>' if m['analyst_comment'] else ''}</td></tr>"
        f"<tr class='ev'><td colspan='6'><b>Evidence:</b> &ldquo;{_e(m['evidence'])}&rdquo;"
        f"{'<br><b>Notes:</b> ' + _e('; '.join(m['notes'])) if m['notes'] else ''}</td></tr>"
        for m in r["mappings"]) or "<tr><td colspan='6'>No mappings above the reporting threshold.</td></tr>"
    tech_desc = "".join(
        f"<div class='tech'><h3>{_e(t['technique_id'])} &ndash; {_e(t['technique_name'])}</h3>"
        f"<div class='muted'>Tactics: {_e(', '.join(t['tactics']))} &middot; best score {t['score']} &middot; "
        f"{_e(t['status'].replace('_', ' '))}</div><p>{_e(_desc_for(r, t['technique_id']))}</p></div>"
        for t in r["techniques"])
    beh_rows = "".join(
        f"<tr><td>{_e(b['id'])}</td><td>{_e(b['behavior'])}</td><td>{_e(b['mode'])}"
        f"{' (hedged)' if b['hedged'] else ''}{' (negated)' if b['negated'] else ''}</td>"
        f"<td class='num'>{b['extraction_confidence']}</td><td>{_e(', '.join(b['keywords']))}</td>"
        f"<td>{_e(b['sentence'])}</td></tr>" for b in r["behaviors"]) or "<tr><td colspan='6'>None</td></tr>"
    actions = "".join(f"<li><b>{_e(a['id'])} {_e(a['name'])}</b> &ndash; addresses {_e(', '.join(a['techniques']))}"
                      f"</li>" for a in r["recommended_actions"]) or \
        "<li>No ATT&amp;CK mitigations linked to the mapped techniques in the loaded dataset.</li>"
    lim = "".join(f"<li>{_e(x)}</li>" for x in r["limitations"])
    warn = "".join(f"<li>{_e(w)}</li>" for w in r["warnings"])
    fixture_banner = ("<div class='banner'>TEST FIXTURE DATASET - technique descriptions are paraphrases. "
                      "Re-run with the official ATT&amp;CK dataset for real analysis.</div>"
                      if r["dataset_is_test_fixture"] else "")
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>ATT&amp;CK Mapping Report</title><style>
body{{margin:0;background:#0b1220;color:#e2e8f0;font-family:Segoe UI,Helvetica,Arial,sans-serif}}
header{{background:#020617;padding:26px 34px;border-bottom:3px solid #38bdf8}} h1{{margin:0;font-size:23px}}
main{{max-width:1120px;margin:auto;padding:22px}} section{{background:#111a2e;border:1px solid #1e2a44;
border-radius:10px;padding:18px 22px;margin-bottom:16px}} h2{{font-size:16px;margin:0 0 12px;color:#7dd3fc}}
h3{{font-size:14px;margin:0 0 4px}} table{{width:100%;border-collapse:collapse;font-size:13px}}
th,td{{text-align:left;padding:7px 8px;border-bottom:1px solid #1e2a44;vertical-align:top}}
th{{color:#94a3b8;font-weight:600}} .num{{text-align:right}} .muted{{color:#94a3b8;font-size:12px}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}}
.card{{background:#0b1220;border:1px solid #1e2a44;border-radius:8px;padding:12px}}
.big{{font-size:26px;font-weight:700;color:#38bdf8}} .pill{{color:#0b1220;padding:2px 8px;border-radius:999px;
font-size:12px;font-weight:700;white-space:nowrap}} .ev td{{color:#cbd5e1;font-size:12.5px;background:#0d1628}}
a{{color:#7dd3fc}} .tech{{border-bottom:1px solid #1e2a44;padding:8px 0}} .tech p{{margin:6px 0 0;color:#cbd5e1;
font-size:13px}} .banner{{background:#78350f;color:#fde68a;padding:10px 34px;font-size:13px}}
.note{{border-left:4px solid #facc15}}</style></head><body>
<header><h1>{_e(r['title'])}</h1><div class='muted'>Analysis {_e(r['analysis_id'] or '(unsaved)')} &middot;
analysed {_e(r['analysis_created'])} &middot; report generated {_e(r['generated'])} &middot;
input: {_e(r['document_name'])} ({_e(r['document_kind'])}) &middot; ATT&amp;CK {_e(r['attack_version'])}</div>
</header>{fixture_banner}<main>
<section><h2>Threat intelligence summary</h2><p>{_e(r['threat_summary']).replace(' -&gt; ', ' &rarr; ')}</p>
<div class='cards'>
<div class='card'><div class='big'>{s['behaviors']}</div>behaviours extracted</div>
<div class='card'><div class='big'>{s['techniques']}</div>techniques mapped</div>
<div class='card'><div class='big'>{s['tactics']}</div>tactics</div>
<div class='card'><div class='big'>{s['high']}</div>high-score mappings</div>
<div class='card'><div class='big'>{s['medium']}</div>medium</div>
<div class='card'><div class='big'>{s['low']}</div>low</div>
<div class='card'><div class='big'>{s['confirmed']}</div>analyst-confirmed</div></div>
<p class='muted'>{_e(r['score_note'])} Counts include primary suggestions and analyst-accepted mappings.</p></section>
<section><h2>Mapped ATT&amp;CK tactics</h2><table><tr><th>Tactic</th><th class='num'>Techniques</th>
<th>Technique IDs</th><th>Evidence</th></tr>{tactic_rows}</table></section>
<section><h2>Technique mappings, evidence and review status</h2><table><tr><th>Extracted behaviour</th><th>ID</th>
<th>Technique</th><th>Tactic</th><th>Score</th><th>Review</th></tr>{map_rows}</table></section>
<section><h2>Technique descriptions (from the loaded dataset)</h2>{tech_desc or '<p>None.</p>'}</section>
<section><h2>Extracted behaviours</h2><table><tr><th>ID</th><th>Behaviour</th><th>Type</th>
<th class='num'>Extraction</th><th>Keywords</th><th>Evidence sentence</th></tr>{beh_rows}</table></section>
<section><h2>Recommended defensive actions (ATT&amp;CK mitigations)</h2><ul>{actions}</ul></section>
<section class='note'><h2>Mapping limitations</h2><ul>{lim}</ul>{'<h2>Warnings</h2><ul>' + warn + '</ul>' if warn else ''}
</section></main></body></html>"""


def _desc_for(r: dict, tid: str) -> str:
    for m in r["mappings"]:
        if m["technique_id"] == tid:
            return m["description"]
    return ""


def to_json(r: dict) -> str:
    return json.dumps(r, indent=2, default=str)


CSV_FIELDS = ["mapping_id", "behavior_id", "behavior", "mode", "hedged", "negated", "technique_id", "technique_name",
              "primary_tactic", "all_tactics", "score", "band", "analyst_score", "status", "role", "origin",
              "evidence", "notes", "analyst_comment", "url"]


def to_csv(r: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_FIELDS)
    for m in r["mappings"]:
        w.writerow([m["id"], m["behavior_id"], m["behavior"], m["mode"], m["hedged"], m["negated"],
                    m["technique_id"], m["technique_name"], m["primary_tactic_name"], "; ".join(m["tactics"]),
                    m["score"], m["band"], "" if m["analyst_score"] is None else m["analyst_score"], m["status"],
                    m["role"], m["origin"], m["evidence"], "; ".join(m["notes"]), m["analyst_comment"], m["url"]])
    return buf.getvalue()


def to_pdf(r: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=15 * mm,
                            bottomMargin=15 * mm, title=r["title"])
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=8.5, leading=11)
    small = ParagraphStyle("s", parent=body, fontSize=7.5, leading=9.5, textColor=colors.HexColor("#334155"))
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12, textColor=colors.HexColor("#0c4a6e"),
                        spaceBefore=8, spaceAfter=4)

    def P(t, st=body):
        return Paragraph(html.escape(str(t)), st)

    def grid(data, widths):
        t = Table(data, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0f172a")),
                               ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                               ("FONTSIZE", (0, 0), (-1, -1), 8)]))
        return t

    s = r["summary"]
    story = [Paragraph(html.escape(r["title"]), ss["Title"]),
             P(f"Analysis {r['analysis_id'] or '(unsaved)'} - analysed {r['analysis_created']} - input: "
               f"{r['document_name']} - ATT&CK {r['attack_version']}", small)]
    if r["dataset_is_test_fixture"]:
        story.append(P("TEST FIXTURE DATASET - technique descriptions are paraphrases. Re-run with the official "
                       "ATT&CK dataset for real analysis.", ParagraphStyle("w", parent=body,
                                                                           textColor=colors.HexColor("#b45309"))))
    story += [Paragraph("Threat intelligence summary", h2), P(r["threat_summary"]),
              P(f"Behaviours {s['behaviors']} | techniques {s['techniques']} | tactics {s['tactics']} | high "
                f"{s['high']} | medium {s['medium']} | low {s['low']} | confirmed {s['confirmed']}. "
                + r["score_note"], small),
              Paragraph("Mapped tactics", h2),
              grid([[P("Tactic"), P("Techniques"), P("Evidence")]] +
                   [[P(f"{t['tactic']} ({t['tactic_id']})"), P(", ".join(t["technique_ids"])),
                     P(" | ".join(t["evidence"][:2]), small)] for t in r["tactics"]], [40 * mm, 45 * mm, 95 * mm]),
              Paragraph("Technique mappings", h2),
              grid([[P(x) for x in ("Behaviour", "Technique", "Tactic", "Score", "Status")]] +
                   [[P(f"{m['behavior']} [{m['mode']}{', hedged' if m['hedged'] else ''}]"),
                     P(f"{m['technique_id']} {m['technique_name']}"), P(m["primary_tactic_name"]),
                     P(f"{m['effective_score']} {m['band']}"), P(m["status"].replace("_", " "))]
                    for m in r["mappings"]], [45 * mm, 55 * mm, 30 * mm, 22 * mm, 28 * mm]),
              Paragraph("Evidence", h2)]
    for m in r["mappings"]:
        story.append(P(f"{m['id']} {m['technique_id']}: \"{m['evidence']}\""
                       + (f" Notes: {'; '.join(m['notes'])}" if m["notes"] else ""), small))
    story.append(Paragraph("Technique descriptions (loaded dataset)", h2))
    for t in r["techniques"]:
        story.append(P(f"{t['technique_id']} - {t['technique_name']}: {_desc_for(r, t['technique_id'])[:600]}", small))
    story.append(Paragraph("Recommended defensive actions (ATT&CK mitigations)", h2))
    for a in r["recommended_actions"] or [{"id": "-", "name": "No mitigations linked in the loaded dataset",
                                            "techniques": []}]:
        story.append(P(f"{a['id']} {a['name']} - {', '.join(a['techniques'])}"))
    story.append(Paragraph("Mapping limitations", h2))
    for x in r["limitations"]:
        story.append(P("- " + x, small))
    story.append(Spacer(1, 4))
    doc.build(story)
    return buf.getvalue()


def save_reports(r: dict, out_dir: str | Path, formats=("html", "pdf", "json", "csv")) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"attack_mapping_{r['analysis_id'] or 'unsaved'}_{stamp}"
    paths = {}
    for f in formats:
        p = out / f"{base}.{f}"
        if f == "html":
            p.write_text(to_html(r), encoding="utf-8")
        elif f == "json":
            p.write_text(to_json(r), encoding="utf-8")
        elif f == "csv":
            p.write_text(to_csv(r), encoding="utf-8")
        elif f == "pdf":
            p.write_bytes(to_pdf(r))
        else:
            raise ValueError(f"unknown report format {f}")
        paths[f] = p
    return paths
