"""
ttp_extractor.py - find attacker behaviours in preprocessed text.

Each BehaviorRule is a small, readable pattern for one kind of behaviour
(phishing attachment, PowerShell, Run keys, credential dumping, ...). A rule
carries *hints*: ATT&CK technique IDs an analyst would usually consider for
that behaviour. Hints are only suggestions - technique_mapper.py checks every
hint against the loaded ATT&CK dataset (revoked -> replacement, deprecated or
unknown -> dropped) and adds TF-IDF candidates from the whole dataset.

For every behaviour we keep the evidence sentence, matched keywords, whether
it was stated explicitly or inferred, hedging ("attempted", "likely") and
negation ("did not", "no evidence of"), plus an extraction confidence.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from modules.text_processor import ProcessedDocument, Sentence

HEDGES = [r"\battempt\w*", r"\blikely\b", r"\bpossibl\w*", r"\bmay have\b", r"\bmight have\b", r"\bsuspect\w*",
          r"\bappear\w* to\b", r"\bbelieved to\b", r"\bpotential\w*", r"\bcould have\b", r"\bunconfirmed\b",
          r"\ballegedly\b"]
NEGATIONS = [r"\bdid not\b", r"\bdidn't\b", r"\bno evidence (of|that)\b", r"\bwas not\b", r"\bwere not\b",
             r"\bfailed to\b", r"\bunable to\b", r"\bnever\b", r"\bnot observed\b", r"\bno sign\w* of\b"]


@dataclass
class Hint:
    technique: str
    weight: float                     # 0..1 strength of the rule -> technique association
    requires: Optional[str] = None    # regex the sentence must also match for full weight
    requires_note: str = ""           # explanation when 'requires' is not met
    tactics: tuple = ()               # preferred tactic shortnames for this behaviour


@dataclass
class BehaviorRule:
    key: str
    behavior: str
    category: str
    patterns: list
    keywords: list
    hints: list
    inferred: bool = False
    specificity: float = 0.7
    exclude: list = field(default_factory=list)
    explicit_if: Optional[str] = None      # an "inferred" rule becomes explicit when this also matches

    def match(self, lower: str) -> Optional[re.Match]:
        if any(re.search(x, lower) for x in self.exclude):
            return None
        for p in self.patterns:
            m = re.search(p, lower)
            if m:
                return m
        return None


C2 = r"\bc2\b|command[- ]and[- ]control|beacon|implant|callback|same channel|existing channel"

RULES: list[BehaviorRule] = [
    BehaviorRule("spearphishing_attachment", "Phishing email with a malicious attachment", "Initial Access",
                 [r"phish\w*[^.]{0,80}attach", r"attach\w*[^.]{0,80}(phish|e-?mail)",
                  r"(malicious|weaponi[sz]ed) (e-?mail )?attachments?",
                  r"e-?mails? (containing|with) (a |an )?(malicious )?(attachment|document|macro)"],
                 ["phishing", "email", "attachment", "malicious", "macro"],
                 [Hint("T1566.001", 1.0, tactics=("initial-access",)), Hint("T1566", 0.6)], specificity=0.95),
    BehaviorRule("spearphishing_link", "Phishing email with a malicious link", "Initial Access",
                 [r"phish\w*[^.]{0,80}\b(link|url)s?\b", r"(malicious|embedded) (link|url)s?",
                  r"e-?mails? (containing|with) (a )?(malicious )?(link|url)"],
                 ["phishing", "email", "link", "url"],
                 [Hint("T1566.002", 1.0, tactics=("initial-access",)), Hint("T1566", 0.6)], specificity=0.95),
    BehaviorRule("phishing", "Phishing", "Initial Access", [r"\bspear-?phish\w*", r"\bphish\w*"],
                 ["phishing", "email"], [Hint("T1566", 0.85, tactics=("initial-access",))], specificity=0.6),
    BehaviorRule("exploit_public_facing", "Exploitation of a public-facing application", "Initial Access",
                 [r"exploit\w*[^.]{0,80}(vulnerab|public-facing|internet-facing|web (server|application|app)"
                  r"|\bvpn\b|exchange|cve-\d)", r"(vulnerab\w*|cve-\d{4}-\d+)[^.]{0,60}exploit"],
                 ["exploit", "vulnerability", "web", "public-facing", "cve"],
                 [Hint("T1190", 1.0, tactics=("initial-access",))], specificity=0.9),
    BehaviorRule("user_execution", "User opened or ran a malicious file", "Execution",
                 [r"(victim|user|recipient|employee)s?[^.]{0,40}(open\w*|click\w*|launch\w*|enabl\w* macros?)",
                  r"(after|upon) (opening|clicking|launching|running)[^.]{0,40}(attachment|document|file|link)"],
                 ["opened", "clicked", "attachment", "document", "victim"],
                 [Hint("T1204.002", 0.9, requires=r"attachment|document|file|macro",
                       requires_note="no file or attachment mentioned", tactics=("execution",)),
                  Hint("T1204", 0.6)], specificity=0.8),
    BehaviorRule("powershell", "PowerShell execution", "Execution", [r"powershell"],
                 ["powershell", "script", "command", "executed"],
                 [Hint("T1059.001", 1.0, tactics=("execution",))], specificity=1.0),
    BehaviorRule("windows_command_shell", "Windows command shell execution", "Execution",
                 [r"cmd\.exe", r"command prompt", r"windows command shell", r"\bbatch (file|script)s?"],
                 ["cmd.exe", "command", "batch"], [Hint("T1059.003", 1.0, tactics=("execution",))],
                 specificity=1.0),
    BehaviorRule("command_execution", "Command or script execution", "Execution",
                 [r"(execut\w*|\bran\b|\brun\w*|launch\w*|invok\w*)[^.]{0,50}\b(commands?|scripts?)\b"],
                 ["executed", "command", "script"], [Hint("T1059", 0.75, tactics=("execution",))],
                 specificity=0.6),
    BehaviorRule("wmi", "WMI execution", "Execution", [r"\bwmic?\b", r"windows management instrumentation"],
                 ["wmi", "wmic"], [Hint("T1047", 1.0, tactics=("execution",))], specificity=1.0),
    BehaviorRule("registry_run_keys", "Registry Run key / Startup folder persistence", "Persistence",
                 [r"\brun ?keys?\b", r"currentversion\\+run", r"startup folder"],
                 ["registry", "run key", "startup", "persistence"],
                 [Hint("T1547.001", 1.0, tactics=("persistence",)), Hint("T1547", 0.6, tactics=("persistence",))],
                 specificity=1.0),
    BehaviorRule("registry_modification", "Registry modification", "Defense Evasion / Persistence",
                 [r"(modif\w*|chang\w*|alter\w*|add\w*|creat\w*|writ\w*|edit\w*|tamper\w*)[^.]{0,40}registry",
                  r"registry[^.]{0,30}(modif|chang|edit)"],
                 ["registry", "modified"], [Hint("T1112", 0.8)], specificity=0.7),
    BehaviorRule("scheduled_task", "Scheduled task / job", "Persistence",
                 [r"scheduled tasks?", r"schtasks", r"\bcron( job)?s?\b"], ["scheduled task", "schtasks", "cron"],
                 [Hint("T1053.005", 0.95, requires=r"scheduled task|schtasks",
                       requires_note="Windows scheduled task not mentioned", tactics=("persistence", "execution")),
                  Hint("T1053", 0.7, tactics=("persistence", "execution"))], specificity=0.9),
    BehaviorRule("persistence_generic", "Persistence (mechanism not stated)", "Persistence", [r"\bpersist\w*"],
                 ["persistence"], [Hint("T1547", 0.45, tactics=("persistence",))], inferred=True,
                 specificity=0.4),
    BehaviorRule("credential_dumping", "Credential dumping", "Credential Access",
                 [r"(dump\w*|extract\w*|harvest\w*|steal\w*|obtain\w*|collect\w*|retriev\w*|scrap\w*)"
                  r"[^.]{0,60}(credential|password|hash(es)?\b|ntlm)",
                  r"mimikatz", r"\blsass\b", r"credential dump\w*"],
                 ["credentials", "password", "dump", "extract", "mimikatz", "lsass"],
                 [Hint("T1003", 0.95, tactics=("credential-access",)),
                  Hint("T1003.001", 0.9, requires=r"lsass|mimikatz", requires_note="LSASS memory not mentioned",
                       tactics=("credential-access",))], specificity=0.85,
                 exclude=[r"(browser|keychain|password (manager|store|vault)|credential manager)"]),
    BehaviorRule("password_stores", "Credentials from password stores", "Credential Access",
                 [r"(browser|keychain)s?[^.]{0,40}(password|credential)", r"password (manager|store|vault)s?",
                  r"credential manager"], ["browser", "password", "keychain"],
                 [Hint("T1555", 1.0, tactics=("credential-access",))], specificity=0.9),
    BehaviorRule("valid_accounts", "Use of valid (stolen or compromised) accounts", "Initial Access / Persistence",
                 [r"(stolen|compromised|valid|legitimate|harvested|obtained|dumped) ((user|domain|admin\w*|local|service|"
                  r"privileged) ){0,2}(credential|account|password)s?",
                  r"us\w*[^.]{0,30}credentials? to (log ?in|log on|access|authenticat|connect)"],
                 ["stolen", "credentials", "account", "valid"],
                 [Hint("T1078", 0.9, tactics=("stealth", "defense-evasion", "persistence", "initial-access",
                                              "privilege-escalation"))], specificity=0.75),
    BehaviorRule("lateral_movement", "Lateral movement to another host", "Lateral Movement",
                 [r"lateral(ly)? mov\w*", r"mov\w* laterally",
                  r"(access\w*|connect\w*|log\w* (in|on)to|pivot\w*)[^.]{0,30}(another|other|additional|second|"
                  r"remote) (machine|host|system|server|workstation|computer)s?", r"\bpivot\w*"],
                 ["lateral", "another machine", "remote", "access"],
                 [Hint("T1021", 0.75, tactics=("lateral-movement",)),
                  Hint("T1021.001", 1.0, requires=r"\brdp\b|remote desktop", requires_note="RDP not mentioned",
                       tactics=("lateral-movement",)),
                  Hint("T1021.002", 1.0, requires=r"\bsmb\b|admin\$|c\$|admin shares?|psexec",
                       requires_note="SMB/admin shares not mentioned", tactics=("lateral-movement",))],
                 inferred=True, specificity=0.6, explicit_if=r"lateral"),
    BehaviorRule("remote_desktop", "Remote Desktop Protocol use", "Lateral Movement",
                 [r"\brdp\b", r"remote desktop"], ["rdp", "remote desktop"],
                 [Hint("T1021.001", 1.0, tactics=("lateral-movement",))], specificity=1.0),
    BehaviorRule("smb_admin_shares", "SMB / Windows admin share use", "Lateral Movement",
                 [r"\bsmb\b", r"admin\$|c\$|admin shares?", r"psexec"], ["smb", "admin share", "psexec"],
                 [Hint("T1021.002", 0.95, tactics=("lateral-movement",))], specificity=0.95),
    BehaviorRule("external_remote_services", "External remote services (VPN / remote gateway)", "Initial Access",
                 [r"(\bvpn\b|citrix|remote access gateway|external remote)[^.]{0,40}(access\w*|log\w*|connect\w*|"
                  r"credential)"], ["vpn", "remote", "access"],
                 [Hint("T1133", 0.85, tactics=("initial-access", "persistence"))], specificity=0.85),
    BehaviorRule("file_discovery", "File and directory discovery", "Discovery",
                 [r"(enumerat\w*|search\w*|\blist\w*|discover\w*|brows\w*|look\w* for|locat\w*)[^.]{0,40}"
                  r"\b(files?|director\w*|folders?|documents?|shares?)\b"],
                 ["enumerated", "files", "directories", "search"],
                 [Hint("T1083", 0.85, tactics=("discovery",))], specificity=0.8),
    BehaviorRule("system_information_discovery", "System information discovery", "Discovery",
                 [r"system ?info\w*", r"\b(hostname|os version|system configuration|system details)\b"],
                 ["systeminfo", "hostname", "system information"],
                 [Hint("T1082", 0.9, tactics=("discovery",))], specificity=0.85),
    BehaviorRule("process_discovery", "Process discovery", "Discovery",
                 [r"tasklist", r"process(es)? list\w*", r"(enumerat\w*|\blist\w*)[^.]{0,20}(running )?process\w*"],
                 ["tasklist", "processes"], [Hint("T1057", 0.9, tactics=("discovery",))], specificity=0.85),
    BehaviorRule("local_data_collection", "Collection of data from the local system", "Collection",
                 [r"(collect\w*|gather\w*|stag\w*|cop(y|ied)|harvest\w*|steal\w*|grab\w*)[^.]{0,60}"
                  r"\b(documents?|files?|data|spreadsheets?|emails?)\b"],
                 ["collected", "documents", "files", "data"],
                 [Hint("T1005", 0.85, requires=r"\blocal\b|compromised (machine|host|system|endpoint|computer)|"
                       r"victim'?s? (machine|system|host)|from the (machine|host|system|endpoint|computer)|disk|drive",
                       requires_note="the data source location is not stated", tactics=("collection",))],
                 specificity=0.75, exclude=[r"credential|password"]),
    BehaviorRule("archive_data", "Archiving collected data", "Collection",
                 [r"(compress\w*|archiv\w*|zipp?\w*|\brar\b|7-?zip)[^.]{0,40}(files?|data|documents?)",
                  r"(files?|data|documents?)[^.]{0,40}(compress\w*|archiv\w*|\bzip\b)"],
                 ["compressed", "archive", "zip"], [Hint("T1560", 0.9, tactics=("collection",))], specificity=0.85),
    BehaviorRule("exfiltration", "Data exfiltration to an external location", "Exfiltration",
                 [r"exfiltrat\w*",
                  r"(transfer\w*|upload\w*|sen[dt]\w*|cop(y|ied)|leak\w*)[^.]{0,60}(external|remote|"
                  r"attacker[- ]controlled|outside|offsite|third-party|cloud)"],
                 ["exfiltrated", "transferred", "external", "server", "upload"],
                 [Hint("T1041", 0.75, requires=C2, requires_note="the evidence does not mention a C2 channel",
                       tactics=("exfiltration",)),
                  Hint("T1048", 0.65, requires=r"\bftp\b|\bdns\b|\bsmtp\b|alternative protocol|encrypt\w*|\btls\b|"
                       r"\bssl\b|\bssh\b|sftp|separate (protocol|channel)",
                       requires_note="no non-C2 protocol mentioned", tactics=("exfiltration",)),
                  Hint("T1567", 0.9, requires=r"cloud|dropbox|google drive|onedrive|\bmega\b|web service|pastebin|"
                       r"github", requires_note="no web/cloud service mentioned", tactics=("exfiltration",))],
                 specificity=0.7, exclude=[r"(download\w*|retriev\w*)[^.]{0,30}(tool|payload|malware)"]),
    BehaviorRule("encrypted_channel", "Encrypted network channel", "Command and Control",
                 [r"encrypt\w* (network )?(connection|channel|traffic|communication|tunnel)s?",
                  r"\b(tls|ssl) (tunnel|connection|channel)"], ["encrypted", "connection", "tls"],
                 [Hint("T1573", 0.6, requires=C2, requires_note="encryption is described, but not for a C2 channel",
                       tactics=("command-and-control",))], inferred=True, specificity=0.6),
    BehaviorRule("c2_web", "Command and control over web protocols", "Command and Control",
                 [r"(\bc2\b|command[- ]and[- ]control|beacon\w*|callback)[^.]{0,60}(https?|web)",
                  r"(https?|web)[^.]{0,40}(\bc2\b|command[- ]and[- ]control|beacon)"], ["c2", "http", "beacon"],
                 [Hint("T1071.001", 1.0, tactics=("command-and-control",)),
                  Hint("T1071", 0.6, tactics=("command-and-control",))], specificity=0.95),
    BehaviorRule("c2_generic", "Command and control communication", "Command and Control",
                 [r"\bc2\b", r"command[- ]and[- ]control", r"beacon\w*"], ["c2", "command and control"],
                 [Hint("T1071", 0.7, tactics=("command-and-control",))], specificity=0.5),
    BehaviorRule("ingress_tool_transfer", "Downloading tools or payloads", "Command and Control",
                 [r"(download\w*|retriev\w*|fetch\w*|pull\w*|transferr?\w*)[^.]{0,50}\b(tools?|payloads?|malware|"
                  r"binar\w*|scripts?|second[- ]stage|implant|backdoor)\b", r"certutil|bitsadmin"],
                 ["downloaded", "tool", "payload"], [Hint("T1105", 0.85, tactics=("command-and-control",))],
                 specificity=0.8, exclude=[r"(to|toward) (an? |the )?(external|remote|attacker)"]),
    BehaviorRule("remote_access_tools", "Remote access tool use", "Command and Control",
                 [r"anydesk|teamviewer|screenconnect|remote (access|administration|admin) (tool|software)s?|\brat\b"],
                 ["anydesk", "teamviewer", "remote access"],
                 [Hint("T1219", 0.9, tactics=("command-and-control",))], specificity=0.9),
    BehaviorRule("obfuscation", "Obfuscated or encoded content", "Defense Evasion",
                 [r"obfuscat\w*", r"base64", r"encod\w* (powershell )?(commands?|scripts?|payloads?)"],
                 ["obfuscated", "encoded", "base64"], [Hint("T1027", 0.9)], specificity=0.85),
    BehaviorRule("indicator_removal", "Removal of logs or evidence", "Defense Evasion",
                 [r"(clear\w*|delet\w*|wip\w*|eras\w*|remov\w*)[^.]{0,40}\b(logs?|event logs?|history|evidence|"
                  r"artifacts?|traces?)\b"], ["cleared", "logs", "deleted"], [Hint("T1070", 0.85)],
                 specificity=0.8),
    BehaviorRule("data_encrypted_for_impact", "Encryption of data for impact (ransomware)", "Impact",
                 [r"ransomware", r"encrypt\w*[^.]{0,30}\b(files|data|disks?|drives?|systems)\b",
                  r"ransom (note|demand)"], ["ransomware", "encrypted", "files"],
                 [Hint("T1486", 0.95, tactics=("impact",))], specificity=0.9,
                 exclude=[r"encrypt\w* (network )?(connection|channel|traffic|tunnel)"]),
]


@dataclass
class Behavior:
    id: str
    rule_key: str
    behavior: str
    category: str
    sentence_index: int
    sentence: str
    keywords: list
    mode: str                          # "explicit" or "inferred"
    hedged: bool
    negated: bool
    extraction_confidence: int
    source_document: str
    hints: list = field(default_factory=list)
    specificity: float = 0.7
    matched_text: str = ""

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        d["hints"] = [h.__dict__ for h in self.hints]
        return d


class TTPExtractor:
    def __init__(self, rules: list[BehaviorRule] | None = None):
        self.rules = rules if rules is not None else RULES

    @staticmethod
    def _flags(lower: str) -> tuple[bool, bool]:
        return any(re.search(h, lower) for h in HEDGES), any(re.search(n, lower) for n in NEGATIONS)

    def extract_sentence(self, s: Sentence, doc_name: str, start_id: int = 1) -> list[Behavior]:
        found: list[Behavior] = []
        hedged, negated = self._flags(s.lower)
        for rule in self.rules:
            m = rule.match(s.lower)
            if not m:
                continue
            kws = [k for k in rule.keywords if k in s.lower]
            inferred = rule.inferred and not (rule.explicit_if and re.search(rule.explicit_if, s.lower))
            score = 55 + min(len(kws), 3) * 10 + (10 if not inferred else 0)
            if hedged:
                score *= 0.85
            if negated:
                score = 15
            found.append(Behavior(
                id=f"B{start_id + len(found)}", rule_key=rule.key, behavior=rule.behavior, category=rule.category,
                sentence_index=s.index, sentence=s.text, keywords=kws,
                mode="inferred" if inferred else "explicit", hedged=hedged, negated=negated,
                extraction_confidence=int(min(score, 95)), source_document=doc_name, hints=list(rule.hints),
                specificity=rule.specificity, matched_text=m.group(0)))
        return self._drop_generic_duplicates(found)

    @staticmethod
    def _drop_generic_duplicates(found: list[Behavior]) -> list[Behavior]:
        """If a specific rule fired, drop its generic sibling in the same sentence
        (e.g. 'phishing' when 'spearphishing_attachment' already matched)."""
        keys = {b.rule_key for b in found}
        generic_of = {"phishing": {"spearphishing_attachment", "spearphishing_link"},
                      "command_execution": {"powershell", "windows_command_shell", "wmi"},
                      "persistence_generic": {"registry_run_keys", "scheduled_task"},
                      "c2_generic": {"c2_web"},
                      "registry_modification": {"registry_run_keys"},
                      "lateral_movement": set()}
        return [b for b in found if not (generic_of.get(b.rule_key, set()) & keys)]

    def extract(self, doc: ProcessedDocument) -> list[Behavior]:
        behaviors: list[Behavior] = []
        for s in doc.sentences:
            behaviors.extend(self.extract_sentence(s, doc.name, start_id=len(behaviors) + 1))
        for i, b in enumerate(behaviors, 1):
            b.id = f"B{i}"
        return behaviors
