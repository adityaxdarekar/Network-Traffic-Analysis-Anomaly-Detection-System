"""
config.py - load config.json over built-in defaults, validate it, resolve paths.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "attack": {
        "dataset_path": "data/attack-enterprise.json",
        "index_cache_path": "data/attack-index-cache.json",
        "download_url": "https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/"
                        "enterprise-attack/enterprise-attack.json",
        "download_timeout_seconds": 120,
        "domain": "enterprise-attack",
    },
    "paths": {"database": "database/mappings.db", "reports": "reports", "sample_reports": "data/sample_reports"},
    "input": {"max_upload_mb": 15, "allowed_extensions": [".txt", ".pdf", ".json", ".md"],
              "max_characters": 400000},
    "mapping": {
        "tfidf_top_k": 3, "tfidf_min_similarity": 0.10, "min_score_to_report": 35, "min_score_similarity_only": 45,
        "max_candidates_per_behavior": 4, "unmatched_sentence_suggestions": True,
        "unmatched_sentence_min_similarity": 0.22,
        "weights": {"rule": 0.35, "keyword": 0.15, "name_similarity": 0.15, "description_similarity": 0.15,
                    "specificity": 0.10, "context": 0.10},
        "description_similarity_full_at": 0.35, "hedged_multiplier": 0.85, "negated_multiplier": 0.2,
    },
    "confidence_bands": [{"name": "HIGH", "min": 90}, {"name": "MEDIUM-HIGH", "min": 70},
                         {"name": "MEDIUM", "min": 50}, {"name": "LOW", "min": 0}],
    "navigator": {
        "navigator_version": "5.1.0", "layer_version": "4.5", "include_rejected": False,
        "colors": {"CONFIRMED": "#31a354", "ACCEPTED": "#74c476", "HIGH": "#2c7fb8", "MEDIUM-HIGH": "#7fcdbb",
                   "MEDIUM": "#fee391", "LOW": "#fdae6b", "REJECTED": "#bdbdbd"},
    },
}


class ConfigError(ValueError):
    pass


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _validate(cfg: dict) -> list[str]:
    errs = []
    w = cfg["mapping"]["weights"]
    for k in ("rule", "keyword", "name_similarity", "description_similarity", "specificity", "context"):
        if not isinstance(w.get(k), (int, float)) or isinstance(w.get(k), bool) or w[k] < 0:
            errs.append(f"mapping.weights.{k} must be a non-negative number")
    if all(isinstance(v, (int, float)) for v in w.values()) and abs(sum(w.values()) - 1.0) > 0.01:
        errs.append(f"mapping.weights must add up to 1.0 (got {sum(w.values()):.2f})")
    m = cfg["mapping"]
    for key, lo, hi in (("tfidf_top_k", 0, 50), ("max_candidates_per_behavior", 1, 50)):
        if not isinstance(m.get(key), int) or isinstance(m.get(key), bool) or not lo <= m[key] <= hi:
            errs.append(f"mapping.{key} must be an integer in [{lo}, {hi}]")
    for key in ("tfidf_min_similarity", "unmatched_sentence_min_similarity", "description_similarity_full_at",
                "hedged_multiplier", "negated_multiplier"):
        v = m.get(key)
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not 0 <= v <= 1:
            errs.append(f"mapping.{key} must be a number in [0, 1]")
    for key in ("min_score_to_report", "min_score_similarity_only"):
        if not isinstance(m.get(key), (int, float)) or isinstance(m.get(key), bool) or not 0 <= m[key] <= 100:
            errs.append(f"mapping.{key} must be in [0, 100]")
    bands = cfg["confidence_bands"]
    if not isinstance(bands, list) or not bands or not all(isinstance(b, dict) and "name" in b and "min" in b
                                                            for b in bands):
        errs.append("confidence_bands must be a list of {name, min}")
    elif min(b["min"] for b in bands) != 0:
        errs.append("confidence_bands must include a band with min 0")
    for key in ("dataset_path", "index_cache_path"):
        p = cfg["attack"].get(key, "")
        if not isinstance(p, str) or not p or Path(p).is_absolute() or ".." in Path(p).parts:
            errs.append(f"attack.{key} must be a relative path inside the project")
    if not str(cfg["attack"].get("download_url", "")).startswith("https://"):
        errs.append("attack.download_url must be an https:// URL")
    if not isinstance(cfg["input"].get("max_upload_mb"), (int, float)) or cfg["input"]["max_upload_mb"] <= 0:
        errs.append("input.max_upload_mb must be positive")
    return errs


class Config(dict):
    base_dir: Path = BASE_DIR

    def path(self, section: str, key: str) -> Path:
        return (self.base_dir / self[section][key]).resolve()


def load_config(path: str | Path | None = None, base_dir: Path = BASE_DIR) -> Config:
    path = Path(path) if path else base_dir / "config.json"
    user = {}
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"{path.name} is not valid JSON (line {exc.lineno}): {exc.msg}")
    cfg = _merge(DEFAULTS, user)
    problems = _validate(cfg)
    if problems:
        raise ConfigError("invalid configuration:\n  - " + "\n  - ".join(problems))
    out = Config(cfg)
    out.base_dir = base_dir
    return out
