"""
document_loader.py - read and validate threat-intelligence input.

Supported: manual text, .txt/.md, .pdf (pypdf), .json (common CTI shapes:
{"text": ...}, {"description": ...}, a list of such objects, or a STIX bundle
whose report/note/indicator objects carry descriptions). Uploads are checked
for size, extension, encoding and emptiness before analysis.
"""
from __future__ import annotations

import io
import json
from dataclasses import dataclass
from pathlib import Path


class DocumentError(ValueError):
    pass


@dataclass
class InputDocument:
    name: str
    text: str
    kind: str          # text / txt / pdf / json / sample


def _check_size(data: bytes, max_mb: float):
    if len(data) > max_mb * 1024 * 1024:
        raise DocumentError(f"file is larger than {max_mb} MB")
    if not data.strip():
        raise DocumentError("file is empty")


def _json_text(obj, depth: int = 0) -> list[str]:
    """Pull human-readable text out of common CTI JSON layouts."""
    if depth > 6:
        return []
    out: list[str] = []
    if isinstance(obj, str):
        return [obj]
    if isinstance(obj, list):
        for item in obj:
            out += _json_text(item, depth + 1)
        return out
    if isinstance(obj, dict):
        if obj.get("type") == "bundle" and isinstance(obj.get("objects"), list):
            for o in obj["objects"]:
                if o.get("type") in ("report", "note", "indicator", "malware", "campaign", "intrusion-set",
                                     "observed-data", "incident", "grouping"):
                    for key in ("name", "description", "content", "abstract"):
                        if isinstance(o.get(key), str):
                            out.append(o[key])
            return out
        for key in ("text", "description", "content", "summary", "body", "report", "details", "message", "events"):
            if key in obj:
                out += _json_text(obj[key], depth + 1)
        return out
    return out


def load_bytes(name: str, data: bytes, max_mb: float = 15, allowed=(".txt", ".pdf", ".json", ".md"),
               max_chars: int = 400000) -> InputDocument:
    name = Path(name).name or "upload"
    ext = Path(name).suffix.lower()
    if ext not in allowed:
        raise DocumentError(f"unsupported file type {ext or '(none)'}; allowed: {', '.join(allowed)}")
    _check_size(data, max_mb)
    if ext == ".pdf":
        if not data.startswith(b"%PDF"):
            raise DocumentError("file does not look like a PDF")
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise DocumentError("pypdf is not installed: pip install pypdf") from exc
        try:
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted:
                raise DocumentError("PDF is encrypted; save an unencrypted copy first")
            text = "\n\n".join((p.extract_text() or "") for p in reader.pages)
        except DocumentError:
            raise
        except Exception as exc:
            raise DocumentError(f"could not read PDF: {exc}") from exc
        kind = "pdf"
    elif ext == ".json":
        try:
            obj = json.loads(data.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise DocumentError(f"invalid JSON: {exc}") from exc
        text = "\n\n".join(t.strip() for t in _json_text(obj) if isinstance(t, str) and t.strip())
        kind = "json"
    else:
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = data.decode("latin-1")
        kind = "txt"
    text = text.strip()
    if not text:
        raise DocumentError("no readable text found in the document (scanned PDFs need OCR first)")
    if len(text) > max_chars:
        raise DocumentError(f"document is too long ({len(text)} characters; limit {max_chars})")
    return InputDocument(name, text, kind)


def load_file(path: str | Path, **kw) -> InputDocument:
    p = Path(path)
    if not p.is_file():
        raise DocumentError(f"file not found: {p}")
    return load_bytes(p.name, p.read_bytes(), **kw)


def from_text(text: str, name: str = "manual input", max_chars: int = 400000) -> InputDocument:
    text = (text or "").strip()
    if not text:
        raise DocumentError("no text provided")
    if len(text) > max_chars:
        raise DocumentError(f"text is too long ({len(text)} characters; limit {max_chars})")
    return InputDocument(name, text, "text")


def list_samples(folder: str | Path) -> list[Path]:
    folder = Path(folder)
    return sorted(p for p in folder.glob("*") if p.suffix.lower() in (".txt", ".json", ".md")) if folder.is_dir() \
        else []
