"""
database.py - SQLite storage for analyses, suggested mappings and every
analyst decision (an append-only review log).

An automated suggestion only becomes CONFIRMED through an explicit analyst
action recorded in review_log - never silently.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TEXT NOT NULL,
    document_name TEXT,
    document_kind TEXT,
    attack_version TEXT,
    fixture INTEGER DEFAULT 0,
    text TEXT,
    behaviors_json TEXT,
    summary_json TEXT
);
CREATE TABLE IF NOT EXISTS mappings (
    analysis_id INTEGER REFERENCES analyses(id),
    mapping_id TEXT NOT NULL,
    data_json TEXT NOT NULL,
    status TEXT NOT NULL,
    updated TEXT,
    PRIMARY KEY (analysis_id, mapping_id)
);
CREATE TABLE IF NOT EXISTS review_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_id INTEGER,
    mapping_id TEXT,
    timestamp TEXT NOT NULL,
    analyst TEXT,
    action TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    comment TEXT
);
"""


class MappingDatabase:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10)
        self.conn.row_factory = sqlite3.Row
        with self.conn:
            self.conn.executescript(SCHEMA)

    def close(self):
        self.conn.close()

    def _x(self, sql, params=()):
        with self._lock, self.conn:
            return self.conn.execute(sql, params)

    def _rows(self, sql, params=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    # ------------------------------------------------------------- analyses
    def save_analysis(self, analysis) -> int:
        cur = self._x(
            """INSERT INTO analyses (created, document_name, document_kind, attack_version, fixture, text,
               behaviors_json, summary_json) VALUES (?,?,?,?,?,?,?,?)""",
            (analysis.created, analysis.document_name, analysis.document_kind, analysis.attack_version,
             1 if analysis.fixture else 0, analysis.text, json.dumps([b.to_dict() for b in analysis.behaviors]),
             json.dumps(analysis.summary())))
        aid = int(cur.lastrowid)
        for m in analysis.mappings:
            self.save_mapping(aid, m)
        return aid

    def save_mapping(self, analysis_id: int, m) -> None:
        self._x("""INSERT INTO mappings (analysis_id, mapping_id, data_json, status, updated) VALUES (?,?,?,?,?)
                   ON CONFLICT(analysis_id, mapping_id) DO UPDATE SET data_json=excluded.data_json,
                   status=excluded.status, updated=excluded.updated""",
                (analysis_id, m.id, json.dumps(m.to_dict()), m.status, datetime.now().isoformat(timespec="seconds")))

    def update_summary(self, analysis_id: int, summary: dict) -> None:
        self._x("UPDATE analyses SET summary_json=? WHERE id=?", (json.dumps(summary), analysis_id))

    def analyses(self, limit: int = 50) -> list[dict]:
        rows = self._rows("SELECT id, created, document_name, document_kind, attack_version, fixture, summary_json "
                          "FROM analyses ORDER BY id DESC LIMIT ?", (int(limit),))
        for r in rows:
            r["summary"] = json.loads(r.pop("summary_json") or "{}")
        return rows

    def analysis_row(self, analysis_id: int) -> Optional[dict]:
        rows = self._rows("SELECT * FROM analyses WHERE id=?", (analysis_id,))
        return rows[0] if rows else None

    def mapping_rows(self, analysis_id: int) -> list[dict]:
        return [json.loads(r["data_json"]) for r in
                self._rows("SELECT data_json FROM mappings WHERE analysis_id=? ORDER BY rowid", (analysis_id,))]

    # ---------------------------------------------------------- review log
    def log_review(self, analysis_id: int, mapping_id: str, analyst: str, action: str,
                   old_value: str, new_value: str, comment: str = "") -> None:
        self._x("""INSERT INTO review_log (analysis_id, mapping_id, timestamp, analyst, action, old_value, new_value,
                   comment) VALUES (?,?,?,?,?,?,?,?)""",
                (analysis_id, mapping_id, datetime.now().isoformat(timespec="seconds"), analyst or "analyst",
                 action, old_value, new_value, comment))

    def review_log(self, analysis_id: int) -> list[dict]:
        return self._rows("SELECT * FROM review_log WHERE analysis_id=? ORDER BY id", (analysis_id,))
