"""
tactic_classifier.py - group mapped techniques by ATT&CK tactic.

Tactic names and order come from the loaded dataset's matrix, so the grouping
follows whatever ATT&CK version is loaded (e.g. v20's Stealth and Defense
Impairment columns). Each mapping is counted under its primary tactic (the one
that fits the behaviour), and its other tactics are listed for reference.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from modules.attack_loader import KnowledgeBase
from modules.technique_mapper import REJECTED, Mapping, counts_in_summary


@dataclass
class TacticGroup:
    shortname: str
    tactic_id: str
    name: str
    order: int
    technique_ids: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    mapping_ids: list = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.technique_ids)

    def to_dict(self) -> dict:
        return {"tactic": self.name, "tactic_id": self.tactic_id, "shortname": self.shortname,
                "technique_count": self.count, "technique_ids": self.technique_ids,
                "evidence": self.evidence, "mapping_ids": self.mapping_ids}


def classify(mappings: list[Mapping], kb: KnowledgeBase, include_empty: bool = False,
             include_rejected: bool = False) -> list[TacticGroup]:
    groups: dict[str, TacticGroup] = {}
    if include_empty:
        for t in kb.ordered_tactics():
            groups[t.shortname] = TacticGroup(t.shortname, t.id, t.name, t.order)
    for m in mappings:
        if m.status == REJECTED and not include_rejected:
            continue
        if m.status != REJECTED and not counts_in_summary(m):
            continue                     # unreviewed alternatives are not counted
        short = m.primary_tactic
        if not short:
            continue
        t = kb.tactics.get(short)
        g = groups.setdefault(short, TacticGroup(short, t.id if t else "", kb.tactic_name(short),
                                                 kb.tactic_order(short)))
        if m.technique_id not in g.technique_ids:
            g.technique_ids.append(m.technique_id)
        if m.evidence not in g.evidence:
            g.evidence.append(m.evidence)
        g.mapping_ids.append(m.id)
    for g in groups.values():
        g.technique_ids.sort()
    return sorted(groups.values(), key=lambda g: (g.order, g.name))
