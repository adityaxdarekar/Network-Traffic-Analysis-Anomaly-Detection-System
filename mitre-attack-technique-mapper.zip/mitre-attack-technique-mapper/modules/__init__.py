"""MITRE ATT&CK Technique Mapper - application modules."""
