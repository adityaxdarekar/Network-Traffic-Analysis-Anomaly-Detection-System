"""
confidence_scorer.py - combine evidence signals into a 0-99 MATCH SCORE.

IMPORTANT: the score is a weighted heuristic for ranking suggestions. It is NOT
a calibrated probability, and the app labels it that way everywhere.

Components (each 0..1, weights in config.json -> mapping.weights):
  rule                    rule-based association between behaviour and technique
                          (halved when the rule's extra condition, e.g. "mentions C2",
                          is not met)
  keyword                 how many behaviour keywords were found in the sentence
  name_similarity         share of the technique-name words present in the sentence
  description_similarity  TF-IDF cosine similarity, sentence vs technique text
  specificity             how specific the extracted action is (sub-technique-level
                          detail like "Run keys" scores higher than "persistence")
  context                 explicitly stated (1.0) vs inferred (0.6)
Multipliers: hedged wording ("attempted", "likely") x0.85, negated x0.2.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from modules.text_processor import simple_stem

NAME_STOPWORDS = {"or", "and", "the", "of", "from", "over", "for", "to", "a", "an", "via", "with", "in", "on",
                  "by", "data", "information"}
SYNONYMS = [(r"operating system", " os "), (r"command[- ]and[- ]control", " c2 "), (r"e-mail", " email "),
            (r"\bspear-?phish\w*", " spearphishing phishing "), (r"\bphish\w*", " phishing "),
            (r"\brun key", " run keys registry "), (r"remote desktop", " rdp remote desktop protocol "),
            (r"admin\$|c\$", " admin shares smb "), (r"scheduled task", " scheduled task job "),
            (r"\bwmic\b", " windows management instrumentation wmi "),
            (r"\bcmd(\.exe)?\b", " windows command shell "), (r"\bcredentials?\b", " credential "),
            (r"\bdocuments?\b|\bfiles?\b", " data files "),
            (r"\bexternal server\b", " external server exfiltration ")]


def expand(text: str) -> str:
    out = " " + text.lower() + " "
    for pat, add in SYNONYMS:
        if re.search(pat, out):
            out += add
    return out


def stems(text: str) -> set[str]:
    return {simple_stem(w) for w in re.findall(r"[a-z0-9][a-z0-9\-]*", text.lower()) if w not in NAME_STOPWORDS}


def name_similarity(sentence: str, technique_name: str) -> float:
    """Share of the technique name's content words that appear in the sentence."""
    name_words = [w for w in re.findall(r"[a-z0-9][a-z0-9\-]*", technique_name.lower().replace("/", " "))
                  if w not in NAME_STOPWORDS]
    if not name_words:
        return 0.0
    sent = stems(expand(sentence))
    hits = sum(1 for w in name_words if simple_stem(w) in sent)
    return hits / len(name_words)


@dataclass
class ScoreResult:
    score: int
    band: str
    components: dict
    multiplier: float


class ConfidenceScorer:
    def __init__(self, mapping_cfg: dict, bands: list[dict]):
        self.w = mapping_cfg["weights"]
        self.full_at = mapping_cfg["description_similarity_full_at"]
        self.hedged_mult = mapping_cfg["hedged_multiplier"]
        self.negated_mult = mapping_cfg["negated_multiplier"]
        self.bands = sorted(bands, key=lambda b: b["min"], reverse=True)

    def band(self, score: float) -> str:
        for b in self.bands:
            if score >= b["min"]:
                return b["name"]
        return self.bands[-1]["name"]

    def score(self, *, rule: float, keyword: float, name_sim: float, desc_cosine: float, specificity: float,
              explicit: bool, hedged: bool, negated: bool) -> ScoreResult:
        comps = {
            "rule": round(max(0.0, min(rule, 1.0)), 3),
            "keyword": round(max(0.0, min(keyword, 1.0)), 3),
            "name_similarity": round(max(0.0, min(name_sim, 1.0)), 3),
            "description_similarity": round(max(0.0, min(desc_cosine / self.full_at if self.full_at else 0, 1.0)), 3),
            "specificity": round(max(0.0, min(specificity, 1.0)), 3),
            "context": 1.0 if explicit else 0.6,
        }
        comps["tfidf_cosine_raw"] = round(desc_cosine, 4)
        base = sum(self.w[k] * comps[k] for k in self.w)
        mult = self.negated_mult if negated else (self.hedged_mult if hedged else 1.0)
        value = max(0, min(99, round(100 * base * mult)))
        return ScoreResult(value, self.band(value), comps, mult)
