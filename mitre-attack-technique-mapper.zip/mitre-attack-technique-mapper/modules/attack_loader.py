"""
attack_loader.py - load the official MITRE ATT&CK Enterprise STIX 2.1 bundle
and build a local, searchable knowledge base.

Nothing about ATT&CK is hard-coded here: tactics (and their order), techniques,
sub-techniques, platforms, data sources, mitigations, and revoked/deprecated
status all come from the loaded dataset. Whatever version you load (v15, v18,
v20...) is what the app uses - including tactic changes such as the v20 split
of Defense Evasion into Stealth and Defense Impairment.

Download:  official bundle from github.com/mitre-attack/attack-stix-data
Cache:     a compact JSON index (data/attack-index-cache.json) keyed by the
           dataset's size + SHA-256, so the 40+ MB bundle is parsed only once.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

INDEX_FORMAT = 2


class AttackDataError(RuntimeError):
    """Friendly error for missing, corrupt or undownloadable ATT&CK data."""


@dataclass
class Tactic:
    id: str              # TA0002
    shortname: str       # execution
    name: str            # Execution
    description: str = ""
    order: int = 999


@dataclass
class Technique:
    id: str                       # T1059.001
    stix_id: str
    name: str
    description: str = ""
    tactics: list = field(default_factory=list)       # tactic shortnames
    platforms: list = field(default_factory=list)
    data_sources: list = field(default_factory=list)
    is_subtechnique: bool = False
    parent_id: Optional[str] = None
    revoked: bool = False
    deprecated: bool = False
    revoked_by: Optional[str] = None                  # ATT&CK ID of the replacement
    url: str = ""
    version: str = ""
    modified: str = ""
    detection: str = ""
    mitigations: list = field(default_factory=list)   # [{"id": "M1038", "name": "..."}]

    @property
    def active(self) -> bool:
        return not (self.revoked or self.deprecated)


def _attack_id(obj: dict) -> tuple[Optional[str], str]:
    for ref in obj.get("external_references", []) or []:
        if ref.get("source_name") in ("mitre-attack", "mitre-mobile-attack", "mitre-ics-attack") \
                and ref.get("external_id"):
            return ref["external_id"], ref.get("url", "")
    return None, ""


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def parse_bundle(bundle: dict) -> dict:
    """Parse a STIX 2.1 bundle (already json-decoded) into plain dicts."""
    if not isinstance(bundle, dict) or bundle.get("type") != "bundle" or not isinstance(bundle.get("objects"), list):
        raise AttackDataError("file is not a STIX bundle (expected {'type': 'bundle', 'objects': [...]})")
    objs = bundle["objects"]
    by_stix: dict[str, dict] = {o["id"]: o for o in objs if isinstance(o, dict) and "id" in o}

    # --- tactics + matrix order -----------------------------------------------
    tactics: dict[str, Tactic] = {}
    tactic_by_stix: dict[str, str] = {}
    for o in objs:
        if o.get("type") == "x-mitre-tactic" and not o.get("revoked") and not o.get("x_mitre_deprecated"):
            tid, _ = _attack_id(o)
            short = o.get("x_mitre_shortname")
            if tid and short:
                tactics[short] = Tactic(tid, short, o.get("name", short), o.get("description", ""))
                tactic_by_stix[o["id"]] = short
    for o in objs:
        if o.get("type") == "x-mitre-matrix" and not o.get("revoked"):
            for i, ref in enumerate(o.get("tactic_refs", [])):
                short = tactic_by_stix.get(ref)
                if short:
                    tactics[short].order = min(tactics[short].order, i)

    # --- techniques -------------------------------------------------------------
    techniques: dict[str, Technique] = {}
    stix_to_attack: dict[str, str] = {}
    for o in objs:
        if o.get("type") != "attack-pattern":
            continue
        aid, url = _attack_id(o)
        if not aid:
            continue
        t = Technique(
            id=aid, stix_id=o["id"], name=o.get("name", ""), description=o.get("description", "") or "",
            tactics=[p["phase_name"] for p in o.get("kill_chain_phases", []) or []
                     if p.get("kill_chain_name") in ("mitre-attack",)],
            platforms=list(o.get("x_mitre_platforms", []) or []),
            data_sources=list(o.get("x_mitre_data_sources", []) or []),
            is_subtechnique=bool(o.get("x_mitre_is_subtechnique")) or "." in aid,
            parent_id=aid.split(".")[0] if "." in aid else None,
            revoked=bool(o.get("revoked")), deprecated=bool(o.get("x_mitre_deprecated")),
            url=url, version=str(o.get("x_mitre_version", "")), modified=str(o.get("modified", "")),
            detection=o.get("x_mitre_detection", "") or "",
        )
        stix_to_attack[o["id"]] = aid
        existing = techniques.get(aid)
        # Two objects can share an ATT&CK ID (an old revoked one and a live one): keep the live one.
        if existing is None or (not existing.active and t.active):
            techniques[aid] = t

    # --- relationships: revoked-by, mitigations, data components ---------------
    mitigation_names: dict[str, tuple[str, str]] = {}
    for o in objs:
        if o.get("type") == "course-of-action" and not o.get("revoked") and not o.get("x_mitre_deprecated"):
            mid, _ = _attack_id(o)
            if mid:
                mitigation_names[o["id"]] = (mid, o.get("name", ""))
    component_names = {o["id"]: o.get("name", "") for o in objs if o.get("type") == "x-mitre-data-component"}
    for o in objs:
        if o.get("type") != "relationship" or o.get("revoked") or o.get("x_mitre_deprecated"):
            continue
        rel, src, tgt = o.get("relationship_type"), o.get("source_ref"), o.get("target_ref")
        if rel == "revoked-by" and src in stix_to_attack and tgt in stix_to_attack:
            src_id = stix_to_attack[src]
            t = techniques.get(src_id)
            if t is not None and t.stix_id == src:
                t.revoked_by = stix_to_attack[tgt]
        elif rel == "mitigates" and src in mitigation_names and tgt in stix_to_attack:
            t = techniques.get(stix_to_attack[tgt])
            if t is not None and t.stix_id == tgt:
                mid, mname = mitigation_names[src]
                if not any(m["id"] == mid for m in t.mitigations):
                    t.mitigations.append({"id": mid, "name": mname})
        elif rel == "detects" and src in component_names and tgt in stix_to_attack:
            t = techniques.get(stix_to_attack[tgt])
            if t is not None and t.stix_id == tgt and component_names[src] not in t.data_sources:
                t.data_sources.append(component_names[src])
    for t in techniques.values():
        t.mitigations.sort(key=lambda m: m["id"])

    version = ""
    for o in objs:
        if o.get("type") == "x-mitre-collection":
            version = str(o.get("x_mitre_version", "")) or version
    if not version:
        versions = [o.get("x_mitre_attack_spec_version") for o in objs if o.get("x_mitre_attack_spec_version")]
        version = f"spec {max(versions)}" if versions else "unknown"
    if not tactics or not techniques:
        raise AttackDataError("the bundle contains no ATT&CK tactics/techniques - is this the Enterprise dataset?")
    return {"format": INDEX_FORMAT, "version": version,
            "tactics": {k: asdict(v) for k, v in tactics.items()},
            "techniques": {k: asdict(v) for k, v in techniques.items()}}


class KnowledgeBase:
    """Searchable in-memory ATT&CK knowledge base."""

    def __init__(self, index: dict, source: str = ""):
        self.source = source
        self.version = index.get("version", "unknown")
        self.tactics: dict[str, Tactic] = {k: Tactic(**v) for k, v in index["tactics"].items()}
        self.techniques: dict[str, Technique] = {k: Technique(**v) for k, v in index["techniques"].items()}
        self.is_fixture = bool(index.get("fixture"))
        self._vectorizer = None
        self._matrix = None
        self._ids: list[str] = []

    # ------------------------------------------------------------- lookups
    def ordered_tactics(self) -> list[Tactic]:
        return sorted(self.tactics.values(), key=lambda t: (t.order, t.id))

    def tactic_name(self, shortname: str) -> str:
        t = self.tactics.get(shortname)
        return t.name if t else shortname.replace("-", " ").title()

    def tactic_order(self, shortname: str) -> int:
        t = self.tactics.get(shortname)
        return t.order if t else 999

    def get(self, attack_id: str) -> Optional[Technique]:
        return self.techniques.get(attack_id.strip().upper()) if attack_id else None

    def resolve(self, attack_id: str, _depth: int = 0) -> tuple[Optional[Technique], str]:
        """Return (active technique or None, note). Follows revoked-by chains;
        deprecated or unknown IDs return None with an explanation."""
        t = self.get(attack_id)
        if t is None:
            return None, f"{attack_id} is not in the loaded ATT&CK dataset ({self.version})"
        if t.revoked:
            if t.revoked_by and _depth < 5:
                repl, note = self.resolve(t.revoked_by, _depth + 1)
                if repl is not None:
                    return repl, f"{attack_id} is revoked; replaced by {repl.id} {repl.name}"
                return None, f"{attack_id} is revoked; replacement unavailable ({note})"
            return None, f"{attack_id} is revoked in ATT&CK {self.version}"
        if t.deprecated:
            return None, f"{attack_id} ({t.name}) is deprecated in ATT&CK {self.version}"
        return t, ""

    def active(self) -> list[Technique]:
        return [t for t in self.techniques.values() if t.active]

    def stats(self) -> dict:
        tech = list(self.techniques.values())
        return {"version": self.version, "tactics": len(self.tactics),
                "techniques": len([t for t in tech if t.active and not t.is_subtechnique]),
                "subtechniques": len([t for t in tech if t.active and t.is_subtechnique]),
                "revoked": len([t for t in tech if t.revoked]),
                "deprecated": len([t for t in tech if t.deprecated and not t.revoked]),
                "fixture": self.is_fixture, "source": self.source}

    def full_name(self, t: Technique) -> str:
        if t.is_subtechnique and t.parent_id and self.get(t.parent_id):
            return f"{self.get(t.parent_id).name}: {t.name}"
        return t.name

    # ------------------------------------------------------------- TF-IDF
    def _build_vectors(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        from modules.text_processor import strip_markup
        actives = sorted(self.active(), key=lambda t: t.id)
        self._ids = [t.id for t in actives]
        docs = []
        for t in actives:
            parent = self.get(t.parent_id).name if t.parent_id and self.get(t.parent_id) else ""
            # Name repeated so it outweighs long descriptions.
            docs.append(" ".join([t.name] * 3 + [parent, strip_markup(t.description)]))
        self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True,
                                           min_df=1, token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z0-9_\-]+\b")
        self._matrix = self._vectorizer.fit_transform(docs)

    def similarity(self, text: str) -> dict[str, float]:
        """Cosine similarity between *text* and every active technique."""
        from sklearn.metrics.pairwise import cosine_similarity
        if self._vectorizer is None:
            self._build_vectors()
        vec = self._vectorizer.transform([text])
        sims = cosine_similarity(vec, self._matrix)[0]
        return {tid: float(s) for tid, s in zip(self._ids, sims)}

    def description_similarity(self, text: str, attack_id: str) -> float:
        return self.similarity(text).get(attack_id, 0.0)

    def search(self, query: str, limit: int = 10) -> list[tuple[Technique, float]]:
        q = query.strip()
        if not q:
            return []
        exact = self.get(q)
        if exact is not None:
            return [(exact, 1.0)]
        sims = self.similarity(q)
        ql = q.lower()
        for tid in sims:
            if ql in self.techniques[tid].name.lower():
                sims[tid] += 0.5
        ranked = sorted(sims.items(), key=lambda kv: kv[1], reverse=True)[:limit]
        return [(self.techniques[tid], s) for tid, s in ranked if s > 0]


# -------------------------------------------------------------------- loading
def download_dataset(url: str, dest: Path, timeout: int = 120, session=None) -> Path:
    """Download the official bundle atomically. Raises AttackDataError on failure."""
    import requests
    http = session or requests
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        resp = http.get(url, timeout=timeout, stream=True)
        resp.raise_for_status()
    except Exception as exc:
        raise AttackDataError(f"download failed ({exc}). Check your internet connection, or download "
                              f"{url} manually and save it as {dest}") from exc
    fd, tmp = tempfile.mkstemp(dir=dest.parent, prefix=".attack-", suffix=".json")
    try:
        with os.fdopen(fd, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                if chunk:
                    fh.write(chunk)
        with open(tmp, "rb") as fh:
            parse_bundle(json.load(fh))            # validate before replacing the old copy
        os.replace(tmp, dest)
    except (json.JSONDecodeError, AttackDataError) as exc:
        raise AttackDataError(f"downloaded file is not a valid ATT&CK STIX bundle: {exc}") from exc
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return dest


def load_knowledge_base(dataset_path: str | Path, cache_path: str | Path | None = None,
                        use_cache: bool = True) -> KnowledgeBase:
    """Load the ATT&CK knowledge base, using the cached index when it matches the dataset."""
    dataset_path = Path(dataset_path)
    if not dataset_path.is_file():
        raise AttackDataError(
            f"ATT&CK dataset not found at {dataset_path}.\n"
            "Download it with:  python3 main.py download\n"
            "or manually from https://github.com/mitre-attack/attack-stix-data "
            "(enterprise-attack/enterprise-attack.json).")
    stat = dataset_path.stat()
    cache_path = Path(cache_path) if cache_path else None
    if use_cache and cache_path and cache_path.is_file():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if cached.get("format") == INDEX_FORMAT and cached.get("source_size") == stat.st_size \
                    and cached.get("source_sha256") == _sha256(dataset_path):
                return KnowledgeBase(cached, source=str(dataset_path))
        except (json.JSONDecodeError, OSError, KeyError, TypeError):
            pass                                    # stale or corrupt cache: rebuild below
    try:
        with open(dataset_path, "rb") as fh:
            bundle = json.load(fh)
    except json.JSONDecodeError as exc:
        raise AttackDataError(f"{dataset_path.name} is not valid JSON ({exc.msg}); download it again") from exc
    index = parse_bundle(bundle)
    index["fixture"] = bool(bundle.get("x_test_fixture"))
    if use_cache and cache_path:
        index["source_size"] = stat.st_size
        index["source_sha256"] = _sha256(dataset_path)
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(index), encoding="utf-8")
        except OSError:
            pass                                    # caching is an optimisation only
    return KnowledgeBase(index, source=str(dataset_path))


def validate_with_stix2(dataset_path: str | Path, sample: int = 50) -> str:
    """Optional: parse a sample of objects with the official stix2 library (if installed)."""
    try:
        import stix2
    except ImportError:
        return "stix2 library not installed - skipped (pip install stix2)"
    with open(dataset_path, "rb") as fh:
        bundle = json.load(fh)
    count = 0
    for o in bundle.get("objects", [])[:sample]:
        stix2.parse(o, allow_custom=True)
        count += 1
    return f"stix2 parsed {count} objects without errors"
