"""
technique_mapper.py - map extracted behaviours to ATT&CK techniques.

For each behaviour the mapper combines:
  1. keyword matching      (behaviour keywords found in the sentence)
  2. rule-based matching   (the extractor rule's technique hints)
  3. TF-IDF vectorisation  (sentence vs every active technique in the dataset)
  4. cosine similarity     (ranking the TF-IDF candidates)
  5. contextual analysis   (explicit vs inferred, hedging, negation, rule conditions)

Every technique ID is resolved against the LOADED dataset: revoked IDs are
replaced by their official replacement, deprecated or unknown IDs are dropped
with a warning. The mapper never creates an ID that is not in the dataset.
Every mapping keeps its evidence sentence and starts as AWAITING_REVIEW.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Optional

from modules.attack_loader import KnowledgeBase, Technique
from modules.confidence_scorer import ConfidenceScorer, name_similarity
from modules.text_processor import ProcessedDocument, strip_markup
from modules.ttp_extractor import Behavior

AWAITING = "AWAITING_REVIEW"
ACCEPTED = "ACCEPTED"
REJECTED = "REJECTED"
CONFIRMED = "CONFIRMED"
STATUSES = (AWAITING, ACCEPTED, REJECTED, CONFIRMED)


@dataclass
class Mapping:
    id: str
    behavior_id: str
    behavior: str
    technique_id: str
    technique_name: str
    is_subtechnique: bool
    tactics: list
    primary_tactic: str
    primary_tactic_name: str
    score: int
    band: str
    components: dict
    evidence: str
    sentence_index: int
    source_document: str
    mode: str
    hedged: bool
    negated: bool
    origin: str                        # rule / similarity / rule+similarity
    description: str = ""
    url: str = ""
    platforms: list = field(default_factory=list)
    mitigations: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    status: str = AWAITING
    analyst_score: Optional[int] = None
    analyst_comment: str = ""
    analyst_modified: bool = False
    role: str = "primary"              # primary = best supported; alternative = weaker candidate for review

    @property
    def effective_score(self) -> int:
        return self.analyst_score if self.analyst_score is not None else self.score

    def to_dict(self) -> dict:
        d = asdict(self)
        d["effective_score"] = self.effective_score
        return d


@dataclass
class MappingResult:
    mappings: list
    similarity_only: list
    warnings: list


class TechniqueMapper:
    def __init__(self, kb: KnowledgeBase, config: dict):
        self.kb = kb
        self.cfg = config["mapping"]
        self.scorer = ConfidenceScorer(self.cfg, config["confidence_bands"])

    # ------------------------------------------------------------- helpers
    def _primary_tactic(self, tech: Technique, preferred: tuple) -> str:
        for t in preferred:
            if t in tech.tactics:
                return t
        ordered = sorted(tech.tactics, key=self.kb.tactic_order)
        return ordered[0] if ordered else ""

    def _keyword_component(self, b: Behavior, tech: Technique, hinted: bool) -> float:
        if hinted:
            return min(len(b.keywords) / 3.0, 1.0)
        text = (tech.name + " " + strip_markup(tech.description)).lower()
        if not b.keywords:
            return 0.0
        return sum(1 for k in b.keywords if k in text) / len(b.keywords)

    def _build(self, b: Behavior, tech: Technique, *, rule: float, cosine: float, origin: str,
               preferred: tuple, notes: list, idx: int, query_text: str) -> Mapping:
        name_sim = name_similarity(query_text, tech.name)
        hinted = rule > 0
        spec = b.specificity if hinted else 0.5
        if tech.is_subtechnique and name_sim >= 0.5:
            spec = min(1.0, spec + 0.1)
        res = self.scorer.score(rule=rule, keyword=self._keyword_component(b, tech, hinted), name_sim=name_sim,
                                desc_cosine=cosine, specificity=spec, explicit=(b.mode == "explicit"),
                                hedged=b.hedged, negated=b.negated)
        prim = self._primary_tactic(tech, preferred)
        ctx_notes = list(notes)
        if b.hedged:
            ctx_notes.append("hedged wording in evidence (e.g. 'attempted'/'likely') - score reduced")
        if b.negated:
            ctx_notes.append("evidence appears NEGATED (e.g. 'did not') - verify before use")
        if b.mode == "inferred":
            ctx_notes.append("behaviour is inferred from context, not stated explicitly")
        return Mapping(
            id=f"M{idx}", behavior_id=b.id, behavior=b.behavior, technique_id=tech.id,
            technique_name=self.kb.full_name(tech), is_subtechnique=tech.is_subtechnique,
            tactics=sorted(tech.tactics, key=self.kb.tactic_order), primary_tactic=prim,
            primary_tactic_name=self.kb.tactic_name(prim) if prim else "", score=res.score, band=res.band,
            components=res.components, evidence=b.sentence, sentence_index=b.sentence_index,
            source_document=b.source_document, mode=b.mode, hedged=b.hedged, negated=b.negated, origin=origin,
            description=strip_markup(tech.description)[:900], url=tech.url, platforms=list(tech.platforms),
            mitigations=list(tech.mitigations), notes=ctx_notes)

    # ---------------------------------------------------------------- main
    def map_behaviors(self, behaviors: list[Behavior], doc: Optional[ProcessedDocument] = None) -> MappingResult:
        mappings: list[Mapping] = []
        warnings: list[str] = []
        for b in behaviors:
            query = f"{b.sentence} {b.behavior}"
            sims = self.kb.similarity(query)
            cands: dict[str, dict] = {}
            for h in b.hints:
                tech, note = self.kb.resolve(h.technique)
                if tech is None:
                    warnings.append(f"{b.id} hint dropped: {note}")
                    continue
                notes = [note] if note else []
                weight = h.weight
                met = True
                if h.requires and not re.search(h.requires, b.sentence.lower()):
                    weight *= 0.5
                    met = False
                    notes.append(f"weaker match: {h.requires_note}")
                prev = cands.get(tech.id)
                if prev is None or weight > prev["rule"]:
                    cands[tech.id] = {"tech": tech, "rule": weight, "notes": notes, "preferred": h.tactics,
                                      "origin": "rule", "met": met}
            ranked = sorted(sims.items(), key=lambda kv: kv[1], reverse=True)[: self.cfg["tfidf_top_k"]]
            for tid, s in ranked:
                if s < self.cfg["tfidf_min_similarity"]:
                    continue
                if tid in cands:
                    cands[tid]["origin"] = "rule+similarity"
                else:
                    cands[tid] = {"tech": self.kb.get(tid), "rule": 0.0, "notes": ["similarity-only suggestion"],
                                  "preferred": (), "origin": "similarity", "met": False}
            built = []
            unmet: set[str] = set()
            for tid, c in cands.items():
                built.append(self._build(b, c["tech"], rule=c["rule"], cosine=sims.get(tid, 0.0), origin=c["origin"],
                                         preferred=c["preferred"], notes=c["notes"], idx=0, query_text=b.sentence))
                if not c["met"]:
                    unmet.add(tid)
            # Prefer the sub-technique: drop a parent that scores lower than one of its sub-techniques.
            best_sub = {}
            for m in built:
                if m.is_subtechnique:
                    parent = m.technique_id.split(".")[0]
                    best_sub[parent] = max(best_sub.get(parent, 0), m.score)
            built = [m for m in built if not (not m.is_subtechnique and m.technique_id in best_sub
                                              and best_sub[m.technique_id] >= m.score)]
            built.sort(key=lambda m: m.score, reverse=True)
            kept = [m for m in built[: self.cfg["max_candidates_per_behavior"]]
                    if m.score >= self.cfg["min_score_to_report"]
                    and (m.origin != "similarity" or m.score >= self.cfg["min_score_similarity_only"])]
            if kept:
                top = kept[0].score
                low_band = self.scorer.bands[-1]["name"]
                for i, m in enumerate(kept):
                    strong = (m.score >= top - 10 and m.band != low_band and m.origin != "similarity"
                              and m.technique_id not in unmet)      # a rule condition that failed -> alternative
                    m.role = "primary" if i == 0 or strong else "alternative"
                mappings.extend(kept)
        for i, m in enumerate(mappings, 1):
            m.id = f"M{i}"
        similarity_only = self._unmatched_suggestions(behaviors, doc) if doc is not None else []
        return MappingResult(mappings, similarity_only, warnings)

    def _unmatched_suggestions(self, behaviors: list[Behavior], doc: ProcessedDocument) -> list[dict]:
        """Sentences no rule matched: show the closest technique by TF-IDF only, clearly labelled."""
        if not self.cfg["unmatched_sentence_suggestions"]:
            return []
        covered = {b.sentence_index for b in behaviors}
        out = []
        for s in doc.sentences:
            if s.index in covered or len(s.text.split()) < 5:
                continue
            sims = self.kb.similarity(s.text)
            tid, best = max(sims.items(), key=lambda kv: kv[1]) if sims else (None, 0)
            if tid and best >= self.cfg["unmatched_sentence_min_similarity"]:
                t = self.kb.get(tid)
                out.append({"sentence_index": s.index, "sentence": s.text, "technique_id": t.id,
                            "technique_name": self.kb.full_name(t), "cosine": round(best, 3),
                            "note": "similarity only - no extraction rule matched; low confidence, review needed"})
        return out[:10]


def counts_in_summary(m: Mapping) -> bool:
    """Primary suggestions and anything an analyst accepted/confirmed; never rejected ones."""
    return m.status != REJECTED and (m.role == "primary" or m.status in (ACCEPTED, CONFIRMED))


def technique_view(mappings: list[Mapping], include_rejected: bool = False,
                   include_alternatives: bool = False) -> list[dict]:
    """One row per technique: best score and all evidence (used by tables, Navigator, reports)."""
    rows: dict[str, dict] = {}
    for m in mappings:
        if m.status == REJECTED and not include_rejected:
            continue
        if not include_alternatives and m.status != REJECTED and not counts_in_summary(m):
            continue
        r = rows.setdefault(m.technique_id, {"technique_id": m.technique_id, "technique_name": m.technique_name,
                                             "tactics": m.tactics, "primary_tactics": set(), "score": 0,
                                             "band": m.band, "evidence": [], "behaviors": [], "statuses": set(),
                                             "mapping_ids": [], "url": m.url, "comments": []})
        r["primary_tactics"].add(m.primary_tactic)
        if m.effective_score > r["score"]:
            r["score"], r["band"] = m.effective_score, m.band
        if m.evidence not in r["evidence"]:
            r["evidence"].append(m.evidence)
        r["behaviors"].append(m.behavior)
        r["statuses"].add(m.status)
        r["mapping_ids"].append(m.id)
        if m.analyst_comment:
            r["comments"].append(m.analyst_comment)
    out = []
    for r in rows.values():
        st = r.pop("statuses")
        r["status"] = (CONFIRMED if CONFIRMED in st else ACCEPTED if ACCEPTED in st
                       else AWAITING if AWAITING in st else REJECTED)
        r["primary_tactics"] = sorted(r["primary_tactics"])
        out.append(r)
    return sorted(out, key=lambda r: r["score"], reverse=True)
