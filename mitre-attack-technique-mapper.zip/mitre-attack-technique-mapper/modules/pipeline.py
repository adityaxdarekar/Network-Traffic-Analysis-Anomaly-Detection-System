"""
pipeline.py - the end-to-end analysis and the analyst-review operations.

    InputDocument -> TextProcessor -> TTPExtractor -> TechniqueMapper
                  -> tactic_classifier -> Analysis (+ optional save to SQLite)

Review actions never happen implicitly: every change goes through
Analysis.review(), which records it in the review log when a database is given.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from modules.attack_loader import KnowledgeBase
from modules.document_loader import InputDocument
from modules.tactic_classifier import classify
from modules.technique_mapper import (ACCEPTED, AWAITING, CONFIRMED, REJECTED, Mapping, TechniqueMapper,
                                      counts_in_summary, technique_view)
from modules.text_processor import ProcessedDocument, TextProcessor, strip_markup
from modules.ttp_extractor import Behavior, Hint, TTPExtractor

ACTIONS = ("accept", "reject", "confirm", "unconfirm", "alternative", "edit_behavior", "comment", "set_score",
           "reset")


class ReviewError(ValueError):
    pass


@dataclass
class Analysis:
    document_name: str
    document_kind: str
    text: str
    attack_version: str
    fixture: bool
    doc: Optional[ProcessedDocument]
    behaviors: list
    mappings: list
    similarity_only: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    backend: str = "regex"
    created: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    analysis_id: Optional[int] = None

    # ------------------------------------------------------------- views
    def counted(self) -> list[Mapping]:
        return [m for m in self.mappings if counts_in_summary(m)]

    def summary(self) -> dict:
        counted = self.counted()
        bands = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for m in counted:
            key = "HIGH" if m.band == "HIGH" else "LOW" if m.band == "LOW" else "MEDIUM"
            bands[key] += 1
        return {"behaviors": len(self.behaviors),
                "explicit_behaviors": len([b for b in self.behaviors if b.mode == "explicit"]),
                "inferred_behaviors": len([b for b in self.behaviors if b.mode == "inferred"]),
                "techniques": len({m.technique_id for m in counted}),
                "tactics": len({m.primary_tactic for m in counted if m.primary_tactic}),
                "mappings_total": len(self.mappings), "mappings_counted": len(counted),
                "high": bands["HIGH"], "medium": bands["MEDIUM"], "low": bands["LOW"],
                "awaiting_review": len([m for m in self.mappings if m.status == AWAITING]),
                "accepted": len([m for m in self.mappings if m.status == ACCEPTED]),
                "confirmed": len([m for m in self.mappings if m.status == CONFIRMED]),
                "rejected": len([m for m in self.mappings if m.status == REJECTED])}

    def tactic_groups(self, kb: KnowledgeBase, include_empty: bool = False):
        return classify(self.mappings, kb, include_empty=include_empty)

    def technique_rows(self, include_alternatives: bool = False):
        return technique_view(self.mappings, include_alternatives=include_alternatives)

    def get(self, mapping_id: str) -> Mapping:
        for m in self.mappings:
            if m.id == mapping_id:
                return m
        raise ReviewError(f"no mapping with id {mapping_id}")

    # ------------------------------------------------------------ review
    def review(self, mapping_id: str, action: str, *, analyst: str = "analyst", comment: str = "",
               technique_id: Optional[str] = None, score: Optional[int] = None, behavior_text: Optional[str] = None,
               kb: Optional[KnowledgeBase] = None, db=None) -> Mapping:
        if action not in ACTIONS:
            raise ReviewError(f"unknown action {action!r}; use one of {', '.join(ACTIONS)}")
        m = self.get(mapping_id)
        old = f"{m.status} {m.technique_id} score={m.effective_score}"
        if action == "accept":
            m.status = ACCEPTED
        elif action == "reject":
            m.status = REJECTED
        elif action == "confirm":
            if m.status == REJECTED:
                raise ReviewError("a rejected mapping cannot be confirmed; accept it first")
            m.status = CONFIRMED
        elif action == "unconfirm":
            if m.status != CONFIRMED:
                raise ReviewError("only a confirmed mapping can be unconfirmed")
            m.status = ACCEPTED
        elif action == "alternative":
            if kb is None or not technique_id:
                raise ReviewError("choosing an alternative needs a technique ID and the knowledge base")
            tech, note = kb.resolve(technique_id)
            if tech is None:
                raise ReviewError(note)
            m.technique_id, m.technique_name = tech.id, kb.full_name(tech)
            m.is_subtechnique = tech.is_subtechnique
            m.tactics = sorted(tech.tactics, key=kb.tactic_order)
            if m.primary_tactic not in tech.tactics:
                m.primary_tactic = m.tactics[0] if m.tactics else ""
            m.primary_tactic_name = kb.tactic_name(m.primary_tactic) if m.primary_tactic else ""
            m.description, m.url = strip_markup(tech.description)[:900], tech.url
            m.platforms, m.mitigations = list(tech.platforms), list(tech.mitigations)
            m.analyst_modified = True
            m.status = ACCEPTED
            m.notes.append(f"technique changed by analyst{(' (' + note + ')') if note else ''}")
        elif action == "edit_behavior":
            if not behavior_text or not behavior_text.strip():
                raise ReviewError("behavior text cannot be empty")
            m.behavior = behavior_text.strip()[:200]
            m.analyst_modified = True
        elif action == "set_score":
            if score is None or not 0 <= int(score) <= 100:
                raise ReviewError("analyst score must be between 0 and 100")
            m.analyst_score = int(score)
        elif action == "reset":
            m.status, m.analyst_score = AWAITING, None
        if comment:
            m.analyst_comment = comment.strip()[:1000]
        new = f"{m.status} {m.technique_id} score={m.effective_score}"
        if db is not None and self.analysis_id is not None:
            db.log_review(self.analysis_id, m.id, analyst, action, old, new, comment)
            db.save_mapping(self.analysis_id, m)
            db.update_summary(self.analysis_id, self.summary())
        return m

    # --------------------------------------------------------- persistence
    @classmethod
    def from_db(cls, db, analysis_id: int) -> "Analysis":
        import json
        row = db.analysis_row(analysis_id)
        if row is None:
            raise ReviewError(f"analysis {analysis_id} not found")
        behaviors = []
        for d in json.loads(row["behaviors_json"] or "[]"):
            d = dict(d)
            d["hints"] = [Hint(**h) for h in d.get("hints", [])]
            behaviors.append(Behavior(**d))
        maps = []
        for d in db.mapping_rows(analysis_id):
            d = dict(d)
            d.pop("effective_score", None)
            maps.append(Mapping(**d))
        return cls(document_name=row["document_name"], document_kind=row["document_kind"], text=row["text"],
                   attack_version=row["attack_version"], fixture=bool(row["fixture"]), doc=None,
                   behaviors=behaviors, mappings=maps, created=row["created"], analysis_id=analysis_id)


class Analyzer:
    def __init__(self, config: dict, kb: KnowledgeBase, processor: Optional[TextProcessor] = None):
        self.cfg = config
        self.kb = kb
        self.processor = processor or TextProcessor()
        self.extractor = TTPExtractor()
        self.mapper = TechniqueMapper(kb, config)

    def analyze(self, document: InputDocument, db=None) -> Analysis:
        doc = self.processor.process(document.text, document.name)
        behaviors = self.extractor.extract(doc)
        result = self.mapper.map_behaviors(behaviors, doc)
        analysis = Analysis(document_name=document.name, document_kind=document.kind, text=document.text,
                            attack_version=self.kb.version, fixture=self.kb.is_fixture, doc=doc,
                            behaviors=behaviors, mappings=result.mappings, similarity_only=result.similarity_only,
                            warnings=result.warnings, backend=doc.backend)
        if self.kb.is_fixture:
            analysis.warnings.insert(0, "ATT&CK TEST FIXTURE loaded - descriptions are paraphrases; load the official "
                                        "dataset for real analysis (python3 main.py download)")
        if db is not None:
            analysis.analysis_id = db.save_analysis(analysis)
        return analysis
