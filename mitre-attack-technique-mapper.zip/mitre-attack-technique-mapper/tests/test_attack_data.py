"""Knowledge-base loading and integrity (runs against the labelled STIX test fixture)."""
import json

import pytest

from modules.attack_loader import AttackDataError, download_dataset, load_knowledge_base, parse_bundle
from conftest import FIXTURE


def test_fixture_is_labelled(kb):
    assert kb.is_fixture
    assert "fixture" in kb.version
    assert all(t.description.startswith("[TEST FIXTURE paraphrase") for t in kb.techniques.values())


def test_tactics_come_from_dataset_in_matrix_order(kb):
    names = [t.name for t in kb.ordered_tactics()]
    assert names[:4] == ["Reconnaissance", "Resource Development", "Initial Access", "Execution"]
    assert "Stealth" in names and "Defense Impairment" in names and "Defense Evasion" not in names
    assert kb.tactics["defense-impairment"].id == "TA0112"
    assert len(names) == 15


def test_technique_fields(kb):
    t = kb.get("t1059.001")
    assert t.name == "PowerShell" and t.is_subtechnique and t.parent_id == "T1059"
    assert t.tactics == ["execution"] and "Windows" in t.platforms
    assert kb.full_name(t) == "Command and Scripting Interpreter: PowerShell"
    assert t.url == "https://attack.mitre.org/techniques/T1059/001"
    assert {m["id"] for m in kb.get("T1003").mitigations} == {"M1026", "M1043"}
    assert set(kb.get("T1078").tactics) == {"initial-access", "persistence", "privilege-escalation", "stealth"}


def test_revoked_deprecated_and_unknown(kb):
    tech, note = kb.resolve("T9001")
    assert tech.id == "T1059.001" and "revoked" in note
    tech, note = kb.resolve("T9002")
    assert tech is None and "deprecated" in note
    tech, note = kb.resolve("T1234")
    assert tech is None and "not in the loaded" in note
    assert all(t.id not in ("T9001", "T9002") for t in kb.active())
    s = kb.stats()
    assert s["revoked"] == 1 and s["deprecated"] == 1


def test_search_and_similarity(kb):
    assert kb.search("T1547.001")[0][0].name == "Registry Run Keys / Startup Folder"
    top = [t.id for t, _ in kb.search("registry run keys startup")[:3]]
    assert "T1547.001" in top
    sims = kb.similarity("dump credentials from lsass memory with mimikatz")
    assert max(sims, key=sims.get) == "T1003.001"
    assert "T9002" not in sims                          # deprecated never offered


def test_missing_and_corrupt_dataset(tmp_path):
    with pytest.raises(AttackDataError, match="main.py download"):
        load_knowledge_base(tmp_path / "nope.json")
    bad = tmp_path / "bad.json"
    bad.write_text("{not json")
    with pytest.raises(AttackDataError, match="not valid JSON"):
        load_knowledge_base(bad)
    with pytest.raises(AttackDataError, match="not a STIX bundle"):
        parse_bundle({"hello": 1})
    with pytest.raises(AttackDataError, match="no ATT&CK"):
        parse_bundle({"type": "bundle", "objects": []})


def test_index_cache_is_used_and_invalidated(tmp_path):
    data = tmp_path / "attack.json"
    data.write_bytes(FIXTURE.read_bytes())
    cache = tmp_path / "cache.json"
    kb1 = load_knowledge_base(data, cache)
    assert cache.exists()
    cached = json.loads(cache.read_text())
    cached["version"] = "from-cache"
    cache.write_text(json.dumps(cached))
    assert load_knowledge_base(data, cache).version == "from-cache"      # cache hit
    bundle = json.loads(data.read_text())
    bundle["objects"][0]["x_mitre_version"] = "changed"
    data.write_text(json.dumps(bundle))
    assert load_knowledge_base(data, cache).version == "changed"         # hash changed -> rebuilt
    assert kb1.stats()["techniques"] > 0


def test_duplicate_id_prefers_live_object():
    bundle = json.loads(FIXTURE.read_text())
    clone = dict(next(o for o in bundle["objects"] if o.get("name") == "PowerShell"))
    clone.update(id="attack-pattern--00000000-0000-4000-8000-000000000001", revoked=True, name="Old PowerShell")
    bundle["objects"].insert(0, clone)
    idx = parse_bundle(bundle)
    assert idx["techniques"]["T1059.001"]["name"] == "PowerShell"


class _Resp:
    def __init__(self, body: bytes, fail=False):
        self.body, self.fail = body, fail

    def raise_for_status(self):
        if self.fail:
            raise RuntimeError("HTTP 503")

    def iter_content(self, chunk_size=1):
        yield self.body


class _Session:
    def __init__(self, resp):
        self.resp = resp

    def get(self, url, timeout, stream):
        if isinstance(self.resp, Exception):
            raise self.resp
        return self.resp


def test_download_success_and_failures(tmp_path):
    dest = tmp_path / "d" / "attack.json"
    download_dataset("https://x", dest, session=_Session(_Resp(FIXTURE.read_bytes())))
    assert load_knowledge_base(dest).stats()["tactics"] == 15
    old = dest.read_bytes()
    with pytest.raises(AttackDataError, match="download failed"):
        download_dataset("https://x", dest, session=_Session(ConnectionError("offline")))
    with pytest.raises(AttackDataError, match="not a valid ATT&CK"):
        download_dataset("https://x", dest, session=_Session(_Resp(b"<html>rate limited</html>")))
    assert dest.read_bytes() == old                     # a failed download never destroys the cached copy
    assert not [p for p in dest.parent.iterdir() if p.name.startswith(".attack-")]
