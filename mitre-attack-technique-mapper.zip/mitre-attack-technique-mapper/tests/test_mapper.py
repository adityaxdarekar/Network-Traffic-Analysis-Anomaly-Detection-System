"""Mapping, scoring, tactics, review, Navigator export, reports and CLI."""
import csv
import io
import json

import pytest

import main as cli
from conftest import FIXTURE, TEST1, TEST2, TEST3
from modules.document_loader import from_text
from modules.navigator_exporter import build_layer, validate_layer
from modules.pipeline import Analysis, ReviewError
from modules.report_generator import build_report_data, save_reports, to_csv, to_html


def primary(a):
    return {m.technique_id: m for m in a.mappings if m.role == "primary"}


def test_test1_expected_mappings(analyzer):
    a = analyzer.analyze(from_text(TEST1, "test1"))
    p = primary(a)
    for tid, tactic in (("T1566.001", "Initial Access"), ("T1059.001", "Execution"),
                        ("T1547.001", "Persistence")):
        assert tid in p and p[tid].primary_tactic_name == tactic and p[tid].band == "HIGH"
    assert p["T1547.001"].technique_name == "Boot or Logon Autostart Execution: Registry Run Keys / Startup Folder"
    assert all(m.status == "AWAITING_REVIEW" for m in a.mappings)         # never auto-confirmed
    assert {g.name for g in a.tactic_groups(analyzer.kb)} == {"Initial Access", "Execution", "Persistence"}


def test_test2_credential_theft(analyzer):
    a = analyzer.analyze(from_text(TEST2))
    p = primary(a)
    assert "T1003" in p and p["T1003"].hedged and p["T1003"].band != "HIGH"
    assert "T1078" in p
    lateral = [m for m in a.mappings if m.technique_id.startswith("T1021")]
    assert lateral and all(m.mode == "inferred" for m in lateral)
    rdp = next(m for m in a.mappings if m.technique_id == "T1021.001")
    assert any("RDP not mentioned" in n for n in rdp.notes)


def test_test3_c2_only_with_evidence(analyzer):
    a = analyzer.analyze(from_text(TEST3))
    assert "T1005" in primary(a)
    t1041 = next(m for m in a.mappings if m.technique_id == "T1041")
    assert any("C2 channel" in n for n in t1041.notes) and t1041.band != "HIGH"
    with_c2 = analyzer.analyze(from_text("The attacker exfiltrated the archive over the existing C2 channel."))
    better = max(m.score for m in with_c2.mappings if m.technique_id == "T1041")
    assert better > t1041.score


def test_every_mapping_exists_in_dataset_and_keeps_evidence(analyzer, kb):
    text = (FIXTURE.parent.parent.parent / "data" / "sample_reports" / "test4_full_intrusion_fictional.txt").read_text()
    a = analyzer.analyze(from_text(text))
    assert len(a.mappings) >= 15
    sentences = {s.text for s in a.doc.sentences}
    for m in a.mappings:
        tech, note = kb.resolve(m.technique_id)
        assert tech is not None and tech.name in m.technique_name and note == ""
        assert m.evidence in sentences                         # evidence is a real sentence of the input
        assert 0 <= m.score <= 99 and set(m.tactics) <= set(kb.tactics)
    ids = {m.technique_id for m in a.mappings}
    assert {"T1003.001", "T1053.005", "T1567", "T1070", "T1071.001", "T1105"} <= ids
    assert "T1486" not in ids                                         # "no evidence that files were encrypted"


def test_scores_are_bounded_and_banded(analyzer):
    a = analyzer.analyze(from_text(TEST1))
    for m in a.mappings:
        exp = "HIGH" if m.score >= 90 else "MEDIUM-HIGH" if m.score >= 70 else "MEDIUM" if m.score >= 50 else "LOW"
        assert m.band == exp
        assert set(m.components) >= {"rule", "keyword", "name_similarity", "description_similarity",
                                     "specificity", "context"}


def test_negated_behaviour_is_not_reported(analyzer):
    a = analyzer.analyze(from_text("There was no evidence of PowerShell execution on any host."))
    assert not [m for m in a.mappings if m.technique_id == "T1059.001" and m.band != "LOW"]


def test_revoked_hint_is_replaced(analyzer, monkeypatch):
    from modules import ttp_extractor
    rule = next(r for r in ttp_extractor.RULES if r.key == "powershell")
    monkeypatch.setattr(rule, "hints", [ttp_extractor.Hint("T9001", 1.0), ttp_extractor.Hint("T9002", 1.0),
                                        ttp_extractor.Hint("T0000", 1.0)])
    a = analyzer.analyze(from_text("The attacker used PowerShell."))
    m = next(m for m in a.mappings if m.technique_id == "T1059.001")
    assert any("T9001 is revoked; replaced by T1059.001" in n for n in m.notes)
    assert any("T9002" in w and "deprecated" in w for w in a.warnings)
    assert any("T0000" in w for w in a.warnings)
    assert not any(m.technique_id in ("T9001", "T9002", "T0000") for m in a.mappings)


def test_review_workflow_and_log(analyzer, db, kb):
    a = analyzer.analyze(from_text(TEST1, "t1"), db=db)
    m = next(x for x in a.mappings if x.technique_id == "T1059.001")
    a.review(m.id, "confirm", analyst="alice", comment="EDR shows powershell.exe", kb=kb, db=db)
    assert m.status == "CONFIRMED" and m.analyst_comment
    a.review(m.id, "unconfirm", kb=kb, db=db)
    assert m.status == "ACCEPTED"
    a.review(m.id, "set_score", score=60, kb=kb, db=db)
    assert m.effective_score == 60 and m.score != 60                     # automatic score preserved
    other = a.mappings[0]
    a.review(other.id, "reject", kb=kb, db=db)
    with pytest.raises(ReviewError, match="cannot be confirmed"):
        a.review(other.id, "confirm", kb=kb, db=db)
    with pytest.raises(ReviewError, match="not in the loaded"):
        a.review(m.id, "alternative", technique_id="T4242", kb=kb, db=db)
    a.review(m.id, "alternative", technique_id="T1059.003", kb=kb, db=db)
    assert m.technique_id == "T1059.003" and m.analyst_modified and m.status == "ACCEPTED"
    a.review(m.id, "edit_behavior", behavior_text="cmd launched script", kb=kb, db=db)
    log = db.review_log(a.analysis_id)
    assert [r["action"] for r in log] == ["confirm", "unconfirm", "set_score", "reject", "alternative",
                                          "edit_behavior"]
    assert log[0]["analyst"] == "alice" and "CONFIRMED" in log[0]["new_value"]
    again = Analysis.from_db(db, a.analysis_id)
    assert next(x for x in again.mappings if x.id == m.id).technique_id == "T1059.003"
    assert db.analyses()[0]["summary"]["rejected"] == 1


def test_navigator_layer(analyzer, db, kb, cfg):
    a = analyzer.analyze(from_text(TEST1), db=db)
    rej = next(m for m in a.mappings if m.technique_id == "T1547.001")
    a.review(rej.id, "reject", kb=kb, db=db)
    conf = next(m for m in a.mappings if m.technique_id == "T1059.001")
    a.review(conf.id, "confirm", kb=kb, db=db, comment="verified")
    layer = build_layer(a, kb, cfg)
    assert validate_layer(layer, kb) == []
    assert layer["versions"] == {"attack": "20", "navigator": "5.1.0", "layer": "4.5"}
    assert layer["domain"] == "enterprise-attack"
    entries = {(t["techniqueID"], t["tactic"]): t for t in layer["techniques"]}
    assert ("T1547.001", "persistence") not in entries                     # rejected excluded
    ps = entries[("T1059.001", "execution")]
    assert ps["color"] == cfg["navigator"]["colors"]["CONFIRMED"] and "verified" in ps["comment"]
    assert entries[("T1059", "execution")]["showSubtechniques"] is True   # parent added for visibility
    assert any(md["name"] == "Evidence" for md in ps["metadata"])
    json.dumps(layer)
    bad = dict(layer, techniques=[{"techniqueID": "X1", "tactic": "nope"}])
    assert len(validate_layer(bad, kb)) >= 2


def test_reports_all_formats(analyzer, kb, cfg):
    a = analyzer.analyze(from_text(TEST1 + " <script>alert(1)</script>", "doc<1>"))
    data = build_report_data(a, kb)
    for key in ("title", "analysis_created", "document_name", "threat_summary", "behaviors", "tactics",
                "techniques", "mappings", "limitations", "recommended_actions"):
        assert data[key]
    assert {"M1038", "M1017"} <= {x["id"] for x in data["recommended_actions"]}
    page = to_html(data)
    assert "<script>alert(1)</script>" not in page and "&lt;script&gt;" in page
    assert "TEST FIXTURE" in page and "not probabilities" in page
    rows = list(csv.DictReader(io.StringIO(to_csv(data))))
    assert rows and rows[0]["technique_id"].startswith("T") and "status" in rows[0]
    paths = save_reports(data, cfg.path("paths", "reports"))
    from pypdf import PdfReader
    pdf_text = "".join(p.extract_text() for p in PdfReader(str(paths["pdf"])).pages)
    assert "T1059.001" in pdf_text and "Mapping limitations" in pdf_text
    assert json.loads(paths["json"].read_text())["summary"]["techniques"] >= 3


def test_cli_end_to_end(tmp_path, cfg, capsys):
    base = ["--config", str(cfg.base_dir / "config.json"), "--dataset", str(FIXTURE)]
    cfg_file = cfg.base_dir / "config.json"
    c = json.loads(cfg_file.read_text())
    c["paths"]["database"] = str(tmp_path / "cli.db")
    c["paths"]["reports"] = str(tmp_path / "rep")
    cfg_file.write_text(json.dumps(c))
    assert cli.main(base + ["info"]) == 0
    assert cli.main(base + ["analyze", "--sample", "test1_phishing", "--save", "--report", "html,csv",
                            "--navigator", str(tmp_path / "layer.json")]) == 0
    out = capsys.readouterr().out
    assert "T1059.001" in out and "Awaiting Review" in out and "TEST FIXTURE" in out
    assert json.loads((tmp_path / "layer.json").read_text())["techniques"]
    assert cli.main(base + ["review", "1", "M1", "confirm", "--analyst", "bob"]) == 0
    assert cli.main(base + ["review", "1", "M1", "alternative", "--technique", "T9999"]) == 1
    assert cli.main(base + ["technique", "T1003"]) == 0
    assert cli.main(base + ["search", "scheduled task"]) == 0
    assert cli.main(base + ["analyze", "--sample", "missing"]) == 1
    assert cli.main(base + ["analyze", "--file", str(tmp_path / "nofile.txt")]) == 1
    assert cli.main(["--config", str(cfg_file), "--dataset", str(tmp_path / "absent.json"), "info"]) == 1
    out = capsys.readouterr().out
    assert "CONFIRMED" in out and "T9999 is not in the loaded" in out and "main.py download" in out
