"""NLP preprocessing, document loading and TTP extraction."""
import json

import pytest

from conftest import SAMPLES, TEST1, TEST2, TEST3
from modules.document_loader import DocumentError, from_text, load_bytes, load_file
from modules.text_processor import TextProcessor, normalize, strip_markup, tokenize
from modules.ttp_extractor import TTPExtractor

tp = TextProcessor(prefer="regex")
ex = TTPExtractor()


def rules_for(text):
    return {b.rule_key: b for b in ex.extract(tp.process(text, "t"))}


def test_preprocessing_keeps_technical_terms():
    text = ("The actor ran cmd.exe and wrote HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run (see T1547.001), "
            "then contacted 203.0.113.7 e.g. via hxxps://bad[.]example. Next step.")
    doc = tp.process(text)
    assert len(doc.sentences) == 2                               # "e.g." does not split
    toks = tokenize(doc.sentences[0].text)
    assert "cmd.exe" in toks and "T1547.001" in toks and "203.0.113.7" in toks
    ents = doc.sentences[0].entities
    assert ents["files"] == ["cmd.exe"] and ents["ips"] == ["203.0.113.7"]
    assert ents["registry"][0].startswith("HKCU\\Software")
    assert "bad.example" in doc.clean_text                       # re-fanged
    assert "cmd.exe" in doc.sentences[0].keywords["tools"]


def test_normalize_and_markup():
    assert normalize("Power-\nShell “quoted”") == 'PowerShell "quoted"'
    assert strip_markup("Uses [PowerShell](https://x) (Citation: Foo 2020) <code>x</code>") == "Uses PowerShell x"


def test_sentence_tagging_verbs_and_categories():
    s = tp.process("The attacker used PowerShell over HTTPS to exfiltrate data from Windows hosts.").sentences[0]
    assert "powershell" in s.keywords["tools"] and "https" in s.keywords["protocols"]
    assert "windows" in s.keywords["os"] and "exfiltrate" in s.verbs


def test_test1_behaviors():
    r = rules_for(TEST1)
    assert {"spearphishing_attachment", "powershell", "registry_run_keys", "user_execution"} <= set(r)
    assert "phishing" not in r                                    # generic sibling dropped
    assert all(b.mode == "explicit" for b in r.values())
    assert r["powershell"].sentence.startswith("After opening")
    assert r["spearphishing_attachment"].source_document == "t"


def test_test2_hedged_and_inferred():
    r = rules_for(TEST2)
    assert r["credential_dumping"].hedged                          # "attempted to extract"
    assert r["credential_dumping"].extraction_confidence < 80
    assert r["valid_accounts"].mode == "explicit"
    assert r["lateral_movement"].mode == "inferred"                # "access another machine"
    assert rules_for("They moved laterally to the database server.")["lateral_movement"].mode == "explicit"


def test_test3_behaviors():
    r = rules_for(TEST3)
    assert {"local_data_collection", "exfiltration", "encrypted_channel"} <= set(r)
    assert r["encrypted_channel"].mode == "inferred"


def test_negation_is_flagged():
    r = rules_for("The investigation found no evidence of PowerShell execution on the server.")
    assert r["powershell"].negated and r["powershell"].extraction_confidence <= 20


def test_unrelated_text_gives_no_behaviors():
    assert rules_for("The quarterly meeting covered budgets and the office move.") == {}


def test_document_loader_txt_json_pdf(tmp_path):
    d = load_file(SAMPLES / "test1_phishing.txt")
    assert d.kind == "txt" and "PowerShell" in d.text
    j = load_file(SAMPLES / "sample_cti.json")
    assert "VPN" in j.text and "Registry Run key" in j.text and "C2 channel" in j.text
    stix = {"type": "bundle", "objects": [{"type": "report", "name": "R", "description": "Actor used WMI."}]}
    assert "used WMI" in load_bytes("r.json", json.dumps(stix).encode()).text
    from reportlab.pdfgen import canvas
    pdf = tmp_path / "r.pdf"
    c = canvas.Canvas(str(pdf))
    c.drawString(72, 720, "The attacker executed PowerShell commands.")
    c.save()
    assert "PowerShell" in load_file(pdf).text


def test_document_validation():
    with pytest.raises(DocumentError, match="unsupported"):
        load_bytes("x.exe", b"MZ...")
    with pytest.raises(DocumentError, match="empty"):
        load_bytes("x.txt", b"   ")
    with pytest.raises(DocumentError, match="PDF"):
        load_bytes("x.pdf", b"not a pdf")
    with pytest.raises(DocumentError, match="invalid JSON"):
        load_bytes("x.json", b"{bad")
    with pytest.raises(DocumentError, match="larger"):
        load_bytes("x.txt", b"a" * 2_000_000, max_mb=1)
    with pytest.raises(DocumentError, match="no text"):
        from_text("  ")
