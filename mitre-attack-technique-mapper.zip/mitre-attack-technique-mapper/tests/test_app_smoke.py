"""
Smoke test for app.py using a STAND-IN for Streamlit (Streamlit is not installed
in the build environment). It runs every page function and the main() entry
point so wiring mistakes (wrong names, bad arguments to our own modules) are
caught. It does NOT prove the real Streamlit UI renders correctly - see
PROJECT_STATUS.md.
"""
import importlib
import sys
import types

import pytest

from conftest import FIXTURE, TEST1


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeSt(types.ModuleType):
    current = None

    def __init__(self, clicks=()):
        super().__init__("streamlit")
        self.session_state = {}
        self.calls = []
        self.clicks = set(clicks)
        self.sidebar = _Ctx()
        FakeSt.current = self

    # decorators -------------------------------------------------------------
    def cache_resource(self, fn=None, **kw):
        def wrap(f):
            f.clear = lambda: None
            return f
        return wrap(fn) if fn else wrap

    # layout -----------------------------------------------------------------
    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def expander(self, *a, **kw):
        return _Ctx()

    def spinner(self, *a, **kw):
        return _Ctx()

    # widgets ----------------------------------------------------------------
    def radio(self, label, options, **kw):
        return self.session_state.get("_page", options[0]) if label == "Section" else options[0]

    def selectbox(self, label, options, **kw):
        return options[0]

    def button(self, label, **kw):
        return label in self.clicks

    def checkbox(self, label, value=False, **kw):
        return value

    def text_area(self, label, value="", **kw):
        return self.session_state.get("_text", value)

    def text_input(self, label, value="", **kw):
        return value

    def number_input(self, label, value=0, **kw):
        return value

    def slider(self, label, lo, hi, value, **kw):
        return value

    def file_uploader(self, *a, **kw):
        return None

    def download_button(self, label, data, **kw):
        assert data, f"empty download for {label}"
        self.calls.append(("download", label))
        return False

    def __getattr__(self, name):               # markdown, write, metric, dataframe, error, ...
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


@pytest.fixture
def app_module(monkeypatch, tmp_path):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    sys.modules.pop("app", None)
    app = importlib.import_module("app")
    return app, fake


def test_every_page_renders_with_an_analysis(app_module, cfg, kb, db):
    app, fake = app_module
    from modules.document_loader import from_text
    from modules.pipeline import Analyzer
    fake.session_state["analysis"] = Analyzer(cfg, kb).analyze(from_text(TEST1), db=db)
    for page in app.PAGES:
        app.RENDER[page](cfg, kb, db)
    names = [c[0] for c in fake.calls]
    assert "error" not in names, [c for c in fake.calls if c[0] == "error"]
    assert ("download", "Download Navigator layer (.json)") in fake.calls
    downloads = {c[1] for c in fake.calls if c[0] == "download"}
    assert {"HTML report", "PDF report", "JSON", "CSV"} <= downloads
    assert any(c[0] == "success" and "Layer valid" in str(c[1]) for c in fake.calls)


def test_pages_without_analysis_prompt_user(app_module, cfg, kb, db):
    app, fake = app_module
    for page in ("Extracted TTPs", "ATT&CK Technique Mapping", "Analyst Review", "Generate Reports"):
        app.RENDER[page](cfg, kb, db)
    assert sum(1 for c in fake.calls if c[0] == "info") == 4


def test_manual_analysis_and_review_buttons(app_module, cfg, kb, db):
    app, fake = app_module
    fake.session_state["_text"] = TEST1
    fake.clicks = {"Analyze text"}
    app.page_manual(cfg, kb, db)
    a = fake.session_state["analysis"]
    assert a.analysis_id and a.mappings
    fake.clicks = {"Confirm"}
    app.page_review(cfg, kb, db)
    assert a.mappings[0].status == "CONFIRMED"
    assert db.review_log(a.analysis_id)[0]["action"] == "confirm"


def test_main_with_fixture_demo_mode(app_module, monkeypatch):
    app, fake = app_module
    fake.session_state["use_fixture"] = True
    fake.session_state["_page"] = "About Project"
    app.main()
    assert not [c for c in fake.calls if c[0] == "error"]
