"""
Builds tests/fixtures/attack_fixture.json - a SMALL TEST FIXTURE in the official
STIX 2.1 shape, used only by the automated tests.

* Technique IDs, names and tactic placements were checked against the live
  attack.mitre.org Enterprise matrix (ATT&CK v20) on 2026-11-07.
* Descriptions are SHORT PARAPHRASES written for testing - they are NOT the
  official MITRE text. Mitigation links are approximate test data.
* T9001 (revoked) and T9002 (deprecated) are FAKE test IDs used to exercise the
  revoked/deprecated handling.

The real application loads the full official dataset
(github.com/mitre-attack/attack-stix-data). Never ship this fixture as ATT&CK data.
"""
import json
import uuid
from pathlib import Path

NS = uuid.UUID("6f1a2b3c-0000-4000-8000-000000000000")
P = "[TEST FIXTURE paraphrase - not official MITRE text] "


def sid(kind, key):
    return f"{kind}--{uuid.uuid5(NS, kind + key)}"


TACTICS = [  # (shortname, TA id, name) in v20 matrix order
    ("reconnaissance", "TA0043", "Reconnaissance"), ("resource-development", "TA0042", "Resource Development"),
    ("initial-access", "TA0001", "Initial Access"), ("execution", "TA0002", "Execution"),
    ("persistence", "TA0003", "Persistence"), ("privilege-escalation", "TA0004", "Privilege Escalation"),
    ("stealth", "TA0005", "Stealth"), ("defense-impairment", "TA0112", "Defense Impairment"),
    ("credential-access", "TA0006", "Credential Access"), ("discovery", "TA0007", "Discovery"),
    ("lateral-movement", "TA0008", "Lateral Movement"), ("collection", "TA0009", "Collection"),
    ("command-and-control", "TA0011", "Command and Control"), ("exfiltration", "TA0010", "Exfiltration"),
    ("impact", "TA0040", "Impact")]

TECH = [  # (id, name, tactics, platforms, description paraphrase)
    ("T1566", "Phishing", ["initial-access"], ["Windows", "Linux", "macOS"],
     "Adversaries send phishing messages, often email, to gain access to victim systems."),
    ("T1566.001", "Spearphishing Attachment", ["initial-access"], ["Windows", "Linux", "macOS"],
     "Adversaries send spearphishing emails with a malicious attachment such as a document or archive "
     "that the victim is lured into opening."),
    ("T1566.002", "Spearphishing Link", ["initial-access"], ["Windows", "Linux", "macOS"],
     "Adversaries send emails containing a malicious link that leads the victim to a malicious site or download."),
    ("T1190", "Exploit Public-Facing Application", ["initial-access"], ["Windows", "Linux", "Network"],
     "Adversaries exploit a vulnerability in an internet-facing application such as a web server or VPN."),
    ("T1133", "External Remote Services", ["initial-access", "persistence"], ["Windows", "Linux"],
     "Adversaries use external remote services such as VPN or remote gateways to access a network."),
    ("T1059", "Command and Scripting Interpreter", ["execution"], ["Windows", "Linux", "macOS"],
     "Adversaries abuse command and script interpreters to execute commands and scripts."),
    ("T1059.001", "PowerShell", ["execution"], ["Windows"],
     "Adversaries abuse PowerShell commands and scripts for execution, including running code in memory."),
    ("T1059.003", "Windows Command Shell", ["execution"], ["Windows"],
     "Adversaries abuse the Windows command shell cmd.exe and batch files to execute commands."),
    ("T1047", "Windows Management Instrumentation", ["execution"], ["Windows"],
     "Adversaries abuse WMI to execute commands and payloads locally or remotely."),
    ("T1204", "User Execution", ["execution"], ["Windows", "Linux", "macOS"],
     "Adversaries rely on a user opening a file or clicking a link to execute malicious code."),
    ("T1204.002", "Malicious File", ["execution"], ["Windows", "Linux", "macOS"],
     "A user opens a malicious file, such as a document attachment, which executes malicious code."),
    ("T1053", "Scheduled Task/Job", ["execution", "persistence", "privilege-escalation"], ["Windows", "Linux"],
     "Adversaries abuse task scheduling to execute malicious code at system startup or on a schedule."),
    ("T1053.005", "Scheduled Task", ["execution", "persistence", "privilege-escalation"], ["Windows"],
     "Adversaries create Windows scheduled tasks with schtasks to run malicious code repeatedly."),
    ("T1547", "Boot or Logon Autostart Execution", ["persistence", "privilege-escalation"], ["Windows", "macOS"],
     "Adversaries configure settings so a program runs automatically at boot or logon to maintain persistence."),
    ("T1547.001", "Registry Run Keys / Startup Folder", ["persistence", "privilege-escalation"], ["Windows"],
     "Adversaries add a program to Windows Registry Run keys or the startup folder so it runs at logon, "
     "establishing persistence."),
    ("T1112", "Modify Registry", ["persistence", "defense-impairment"], ["Windows"],
     "Adversaries modify the Windows Registry to hide configuration, weaken defenses or persist."),
    ("T1078", "Valid Accounts", ["initial-access", "persistence", "privilege-escalation", "stealth"],
     ["Windows", "Linux", "macOS"],
     "Adversaries obtain and use credentials of existing valid accounts to log in, access systems and "
     "blend in with normal activity."),
    ("T1070", "Indicator Removal", ["stealth"], ["Windows", "Linux"],
     "Adversaries delete or modify artifacts such as logs and command history to remove evidence."),
    ("T1027", "Obfuscated Files or Information", ["stealth"], ["Windows", "Linux"],
     "Adversaries encode, encrypt or obfuscate files and commands, for example with base64, to hide content."),
    ("T1003", "OS Credential Dumping", ["credential-access"], ["Windows", "Linux"],
     "Adversaries dump credentials, password hashes or clear-text passwords from the operating system."),
    ("T1003.001", "LSASS Memory", ["credential-access"], ["Windows"],
     "Adversaries access LSASS process memory, for example with Mimikatz, to dump credentials."),
    ("T1555", "Credentials from Password Stores", ["credential-access"], ["Windows", "macOS"],
     "Adversaries search password stores such as browsers and keychains for saved credentials."),
    ("T1083", "File and Directory Discovery", ["discovery"], ["Windows", "Linux", "macOS"],
     "Adversaries enumerate files and directories to find information of interest."),
    ("T1082", "System Information Discovery", ["discovery"], ["Windows", "Linux", "macOS"],
     "Adversaries gather system information such as hostname, OS version and configuration."),
    ("T1057", "Process Discovery", ["discovery"], ["Windows", "Linux", "macOS"],
     "Adversaries list running processes, for example with tasklist, to understand the system."),
    ("T1021", "Remote Services", ["lateral-movement"], ["Windows", "Linux", "macOS"],
     "Adversaries use valid accounts to log into remote services and move laterally to other machines."),
    ("T1021.001", "Remote Desktop Protocol", ["lateral-movement"], ["Windows"],
     "Adversaries use RDP remote desktop sessions with valid accounts to move laterally."),
    ("T1021.002", "SMB/Windows Admin Shares", ["lateral-movement"], ["Windows"],
     "Adversaries use SMB and Windows admin shares such as C$ and ADMIN$, for example with PsExec, to move "
     "laterally."),
    ("T1005", "Data from Local System", ["collection"], ["Windows", "Linux", "macOS"],
     "Adversaries search the local system and collect sensitive files and documents before exfiltration."),
    ("T1560", "Archive Collected Data", ["collection"], ["Windows", "Linux", "macOS"],
     "Adversaries compress or archive collected data, for example into zip or rar files, before exfiltration."),
    ("T1071", "Application Layer Protocol", ["command-and-control"], ["Windows", "Linux", "macOS"],
     "Adversaries communicate with command and control servers using application layer protocols."),
    ("T1071.001", "Web Protocols", ["command-and-control"], ["Windows", "Linux", "macOS"],
     "Adversaries use HTTP and HTTPS web traffic for command and control beaconing."),
    ("T1105", "Ingress Tool Transfer", ["command-and-control"], ["Windows", "Linux", "macOS"],
     "Adversaries download tools or payloads from an external system into the compromised environment."),
    ("T1219", "Remote Access Tools", ["command-and-control"], ["Windows", "Linux", "macOS"],
     "Adversaries use legitimate remote access software such as AnyDesk or TeamViewer for interactive control."),
    ("T1573", "Encrypted Channel", ["command-and-control"], ["Windows", "Linux", "macOS"],
     "Adversaries encrypt command and control traffic using encryption algorithms or TLS."),
    ("T1041", "Exfiltration Over C2 Channel", ["exfiltration"], ["Windows", "Linux", "macOS"],
     "Adversaries steal data by sending it over the existing command and control channel."),
    ("T1048", "Exfiltration Over Alternative Protocol", ["exfiltration"], ["Windows", "Linux", "macOS"],
     "Adversaries exfiltrate data over a protocol different from the C2 channel, such as FTP, SMTP or DNS, "
     "possibly encrypted."),
    ("T1567", "Exfiltration Over Web Service", ["exfiltration"], ["Windows", "Linux", "macOS"],
     "Adversaries exfiltrate data to an external web service or cloud storage such as Dropbox or Google Drive."),
    ("T1486", "Data Encrypted for Impact", ["impact"], ["Windows", "Linux", "macOS"],
     "Adversaries encrypt files and data on target systems to disrupt availability, as ransomware does."),
]

MITIGATIONS = {  # approximate TEST links only
    ("M1017", "User Training"): ["T1566", "T1566.001", "T1566.002", "T1204", "T1204.002"],
    ("M1049", "Antivirus/Antimalware"): ["T1566", "T1566.001", "T1059.001"],
    ("M1038", "Execution Prevention"): ["T1059", "T1059.001", "T1204.002"],
    ("M1042", "Disable or Remove Feature or Program"): ["T1059.001"],
    ("M1024", "Restrict Registry Permissions"): ["T1112", "T1547.001"],
    ("M1043", "Credential Access Protection"): ["T1003", "T1003.001"],
    ("M1026", "Privileged Account Management"): ["T1003", "T1078", "T1021"],
    ("M1032", "Multi-factor Authentication"): ["T1078", "T1021", "T1133"],
    ("M1057", "Data Loss Prevention"): ["T1005", "T1041", "T1048", "T1567"],
    ("M1031", "Network Intrusion Prevention"): ["T1041", "T1071", "T1071.001", "T1105", "T1573"],
    ("M1030", "Network Segmentation"): ["T1021.002", "T1048"],
    ("M1053", "Data Backup"): ["T1486"],
}


def ext(aid, kind="techniques"):
    return [{"source_name": "mitre-attack", "external_id": aid,
             "url": f"https://attack.mitre.org/{kind}/{aid.replace('.', '/')}"}]


def build() -> dict:
    objs = [{"type": "x-mitre-collection", "id": sid("x-mitre-collection", "c"), "name": "Fixture subset",
             "x_mitre_version": "fixture-v20-subset", "spec_version": "2.1"}]
    tactic_ids = []
    for short, ta, name in TACTICS:
        tid = sid("x-mitre-tactic", short)
        tactic_ids.append(tid)
        objs.append({"type": "x-mitre-tactic", "id": tid, "name": name, "x_mitre_shortname": short,
                     "description": P + f"The {name} tactic.", "external_references": ext(ta, "tactics"),
                     "spec_version": "2.1"})
    objs.append({"type": "x-mitre-matrix", "id": sid("x-mitre-matrix", "enterprise"), "name": "Enterprise ATT&CK",
                 "tactic_refs": tactic_ids, "spec_version": "2.1"})
    for aid, name, tactics, platforms, desc in TECH:
        objs.append({"type": "attack-pattern", "id": sid("attack-pattern", aid), "name": name,
                     "description": P + desc, "external_references": ext(aid),
                     "kill_chain_phases": [{"kill_chain_name": "mitre-attack", "phase_name": t} for t in tactics],
                     "x_mitre_platforms": platforms, "x_mitre_is_subtechnique": "." in aid,
                     "x_mitre_version": "1.0", "spec_version": "2.1"})
    # Fake revoked + deprecated objects (test IDs only).
    objs.append({"type": "attack-pattern", "id": sid("attack-pattern", "T9001"), "name": "FIXTURE Revoked Technique",
                 "description": P + "Revoked test object.", "revoked": True, "external_references": ext("T9001"),
                 "kill_chain_phases": [{"kill_chain_name": "mitre-attack", "phase_name": "execution"}],
                 "spec_version": "2.1"})
    objs.append({"type": "relationship", "id": sid("relationship", "rev"), "relationship_type": "revoked-by",
                 "source_ref": sid("attack-pattern", "T9001"), "target_ref": sid("attack-pattern", "T1059.001"),
                 "spec_version": "2.1"})
    objs.append({"type": "attack-pattern", "id": sid("attack-pattern", "T9002"),
                 "name": "FIXTURE Deprecated Technique", "description": P + "Deprecated test object about PowerShell.",
                 "x_mitre_deprecated": True, "external_references": ext("T9002"),
                 "kill_chain_phases": [{"kill_chain_name": "mitre-attack", "phase_name": "execution"}],
                 "spec_version": "2.1"})
    for (mid, mname), targets in MITIGATIONS.items():
        cid = sid("course-of-action", mid)
        objs.append({"type": "course-of-action", "id": cid, "name": mname, "description": P + mname,
                     "external_references": ext(mid, "mitigations"), "spec_version": "2.1"})
        for t in targets:
            objs.append({"type": "relationship", "id": sid("relationship", mid + t),
                         "relationship_type": "mitigates", "source_ref": cid,
                         "target_ref": sid("attack-pattern", t), "spec_version": "2.1"})
    return {"type": "bundle", "id": sid("bundle", "fixture"), "x_test_fixture": True,
            "x_fixture_note": "TEST FIXTURE ONLY - paraphrased descriptions; not official MITRE data",
            "objects": objs}


if __name__ == "__main__":
    out = Path(__file__).with_name("attack_fixture.json")
    out.write_text(json.dumps(build(), indent=1))
    print(f"wrote {out} ({len(TECH)} techniques)")
