import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from modules.attack_loader import load_knowledge_base  # noqa: E402
from modules.config import load_config                  # noqa: E402

FIXTURE = ROOT / "tests" / "fixtures" / "attack_fixture.json"
SAMPLES = ROOT / "data" / "sample_reports"

TEST1 = ("A threat actor distributed phishing emails containing malicious attachments. After opening the attachment, "
         "the victim executed a malicious script through PowerShell. The attacker then established persistence using "
         "Windows Registry Run keys.")
TEST2 = ("The attacker accessed a compromised Windows system and attempted to extract stored credentials from the "
         "operating system. The attacker then used the stolen credentials to access another machine.")
TEST3 = ("The attacker collected sensitive documents from the compromised machine and transferred them to an external "
         "server over an encrypted network connection.")


@pytest.fixture(scope="session")
def kb():
    return load_knowledge_base(FIXTURE, use_cache=False)


@pytest.fixture
def cfg(tmp_path):
    """Config whose database/reports live in tmp_path."""
    c = json.loads((ROOT / "config.json").read_text())
    c["paths"]["database"] = "db/mappings.db"
    c["paths"]["reports"] = "out"
    c["paths"]["sample_reports"] = str(SAMPLES)
    (tmp_path / "config.json").write_text(json.dumps(c))
    return load_config(tmp_path / "config.json", base_dir=tmp_path)


@pytest.fixture
def analyzer(cfg, kb):
    from modules.pipeline import Analyzer
    return Analyzer(cfg, kb)


@pytest.fixture
def db(cfg):
    from modules.database import MappingDatabase
    d = MappingDatabase(cfg.path("paths", "database"))
    yield d
    d.close()
