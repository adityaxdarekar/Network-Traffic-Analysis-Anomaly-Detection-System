"""
app.py - Streamlit dashboard for the MITRE ATT&CK Technique Mapper.

Run:  streamlit run app.py

Sections: Home Dashboard, Upload Threat Intelligence, Manual Text Analysis,
Extracted TTPs, ATT&CK Technique Mapping, Tactic Analysis, Analyst Review,
Navigator Export, Generate Reports, About Project.
"""
from __future__ import annotations

import html
from pathlib import Path

import pandas as pd
import streamlit as st

from modules.attack_loader import AttackDataError, download_dataset, load_knowledge_base
from modules.config import BASE_DIR, ConfigError, load_config
from modules.database import MappingDatabase
from modules.document_loader import DocumentError, from_text, list_samples, load_bytes, load_file
from modules.navigator_exporter import build_layer, layer_json, validate_layer
from modules.pipeline import Analysis, Analyzer, ReviewError
from modules.report_generator import build_report_data, to_csv, to_html, to_json, to_pdf
from modules.technique_mapper import ACCEPTED, AWAITING, CONFIRMED, REJECTED

try:
    import plotly.express as px
except ImportError:          # charts fall back to Streamlit's built-in charts
    px = None

PAGES = ["Home Dashboard", "Upload Threat Intelligence", "Manual Text Analysis", "Extracted TTPs",
         "ATT&CK Technique Mapping", "Tactic Analysis", "Analyst Review", "Navigator Export", "Generate Reports",
         "About Project"]
FIXTURE = BASE_DIR / "tests" / "fixtures" / "attack_fixture.json"
CSS = """<style>
.block-container{padding-top:1.4rem}
div[data-testid="stMetric"]{background:#111a2e;border:1px solid #1e2a44;border-radius:10px;padding:10px 14px}
.evidence{background:#0d1628;border-left:3px solid #38bdf8;padding:8px 12px;border-radius:4px;margin:4px 0;
font-size:0.92rem}
.warnbox{background:#3b2306;border:1px solid #b45309;color:#fde68a;padding:8px 12px;border-radius:6px}
</style>"""


# ------------------------------------------------------------------ resources
@st.cache_resource(show_spinner="Loading the ATT&CK knowledge base...")
def get_kb(path: str, cache: str | None, mtime: float):
    return load_knowledge_base(path, cache, use_cache=cache is not None)


@st.cache_resource
def get_db(path: str):
    return MappingDatabase(path)


def context():
    cfg = load_config()
    ss = st.session_state
    dataset = cfg.path("attack", "dataset_path")
    use_fixture = ss.get("use_fixture", False)
    kb, kb_error = None, ""
    try:
        if use_fixture:
            kb = get_kb(str(FIXTURE), None, FIXTURE.stat().st_mtime)
        elif dataset.exists():
            kb = get_kb(str(dataset), str(cfg.path("attack", "index_cache_path")), dataset.stat().st_mtime)
        else:
            kb_error = "Official ATT&CK dataset not downloaded yet."
    except AttackDataError as exc:
        kb_error = str(exc)
    return cfg, kb, kb_error, get_db(str(cfg.path("paths", "database")))


def analysis() -> Analysis | None:
    return st.session_state.get("analysis")


def need_analysis() -> Analysis | None:
    a = analysis()
    if a is None:
        st.info("No analysis yet - use **Upload Threat Intelligence** or **Manual Text Analysis** first.")
    return a


def run_analysis(cfg, kb, db, doc):
    with st.spinner("Extracting behaviours and mapping to ATT&CK..."):
        a = Analyzer(cfg, kb).analyze(doc, db=db)
    st.session_state["analysis"] = a
    st.success(f"Analysis {a.analysis_id} complete: {a.summary()['behaviors']} behaviours, "
               f"{a.summary()['techniques']} techniques suggested. Review them under **Analyst Review**.")


def evidence_box(text: str):
    """Evidence comes from untrusted documents: escape it before rendering as HTML."""
    st.markdown(f"<div class='evidence'>{html.escape(str(text))}</div>", unsafe_allow_html=True)


def mapping_frame(a: Analysis, include_alternatives: bool) -> pd.DataFrame:
    rows = []
    for m in a.mappings:
        if m.role != "primary" and not include_alternatives and m.status not in (ACCEPTED, CONFIRMED):
            continue
        rows.append({"Mapping": m.id, "Extracted Behavior": m.behavior, "Technique ID": m.technique_id,
                     "Technique Name": m.technique_name, "Tactic": m.primary_tactic_name,
                     "Score": m.effective_score, "Band": m.band, "Type": m.mode + (" (hedged)" if m.hedged else ""),
                     "Role": m.role, "Status": m.status.replace("_", " ").title(), "Origin": m.origin})
    return pd.DataFrame(rows)


def bar(df: pd.DataFrame, x: str, y: str, title: str, color: str | None = None):
    if df.empty:
        st.caption("Nothing to chart yet.")
        return
    if px is not None:
        fig = px.bar(df, x=x, y=y, color=color, title=title, template="plotly_dark",
                     color_discrete_sequence=["#38bdf8", "#2dd4bf", "#facc15", "#fb923c"])
        fig.update_layout(paper_bgcolor="#0b1220", plot_bgcolor="#0b1220", margin=dict(t=50, l=10, r=10, b=10))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.caption(title)
        st.bar_chart(df.set_index(x)[y])


# ---------------------------------------------------------------------- pages
def page_home(cfg, kb, db):
    st.title("MITRE ATT&CK Technique Mapper")
    st.caption("Turns threat-intelligence text into ATT&CK techniques, with evidence, match scores and analyst review.")
    if kb is not None:
        s = kb.stats()
        c = st.columns(4)
        c[0].metric("ATT&CK version", s["version"])
        c[1].metric("Techniques", s["techniques"])
        c[2].metric("Sub-techniques", s["subtechniques"])
        c[3].metric("Tactics", s["tactics"])
    a = analysis()
    if a is None:
        st.info("Start with **Upload Threat Intelligence** or **Manual Text Analysis**.")
        return
    s = a.summary()
    st.subheader(f"Current analysis: {a.document_name}")
    c = st.columns(6)
    for col, (label, val) in zip(c, [("Behaviors extracted", s["behaviors"]), ("Techniques mapped", s["techniques"]),
                                     ("Tactics identified", s["tactics"]), ("High", s["high"]),
                                     ("Medium", s["medium"]), ("Low", s["low"])]):
        col.metric(label, val)
    groups = a.tactic_groups(kb, include_empty=True)
    bar(pd.DataFrame([{"Tactic": g.name, "Techniques": g.count} for g in groups]), "Tactic", "Techniques",
        "Techniques per ATT&CK tactic")
    st.caption("Counts include primary suggestions and analyst-accepted mappings. Match scores are heuristic, "
               "not probabilities.")


def page_upload(cfg, kb, db):
    st.header("Upload Threat Intelligence")
    up = st.file_uploader("TXT, PDF, JSON or Markdown report", type=["txt", "pdf", "json", "md"])
    if up is not None and st.button("Analyze uploaded report", type="primary"):
        try:
            doc = load_bytes(up.name, up.getvalue(), max_mb=cfg["input"]["max_upload_mb"],
                             allowed=tuple(cfg["input"]["allowed_extensions"]), max_chars=cfg["input"]["max_characters"])
            run_analysis(cfg, kb, db, doc)
        except DocumentError as exc:
            st.error(f"Could not read the document: {exc}")
    st.divider()
    st.subheader("Sample threat intelligence reports")
    samples = list_samples(cfg.path("paths", "sample_reports"))
    if samples:
        choice = st.selectbox("Sample", [p.name for p in samples])
        path = next(p for p in samples if p.name == choice)
        st.code(path.read_text(encoding="utf-8")[:3000], language=None)
        if st.button("Analyze sample"):
            doc = load_file(path)
            doc.kind = "sample"
            run_analysis(cfg, kb, db, doc)
    st.divider()
    st.subheader("Previous analyses")
    rows = db.analyses(20)
    if rows:
        st.dataframe(pd.DataFrame([{"ID": r["id"], "Created": r["created"], "Document": r["document_name"],
                                    "Techniques": r["summary"].get("techniques"), "Confirmed": r["summary"].get("confirmed"),
                                    "ATT&CK": r["attack_version"]} for r in rows]), hide_index=True)
        pick = st.number_input("Open analysis ID", min_value=1, step=1, value=int(rows[0]["id"]))
        if st.button("Open"):
            try:
                st.session_state["analysis"] = Analysis.from_db(db, int(pick))
                st.success(f"Loaded analysis {pick}.")
            except ReviewError as exc:
                st.error(str(exc))


def page_manual(cfg, kb, db):
    st.header("Manual Text Analysis")
    text = st.text_area("Paste threat intelligence", height=220,
                        placeholder="A threat actor gained initial access through a phishing email containing a "
                                    "malicious attachment...")
    name = st.text_input("Document name", value="manual input")
    if st.button("Analyze text", type="primary"):
        try:
            run_analysis(cfg, kb, db, from_text(text, name or "manual input", cfg["input"]["max_characters"]))
        except DocumentError as exc:
            st.error(str(exc))


def page_ttps(cfg, kb, db):
    st.header("Extracted TTPs")
    a = need_analysis()
    if a is None:
        return
    mode = st.radio("Show", ["All", "Explicit only", "Inferred only"], horizontal=True)
    rows = [{"ID": b.id, "Behavior": b.behavior, "Type": b.mode, "Hedged": b.hedged, "Negated": b.negated,
             "Extraction confidence": b.extraction_confidence, "Keywords": ", ".join(b.keywords),
             "Source": b.source_document} for b in a.behaviors
            if mode == "All" or (mode == "Explicit only") == (b.mode == "explicit")]
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    st.subheader("Evidence viewer")
    for b in a.behaviors:
        with st.expander(f"{b.id} - {b.behavior} ({b.mode})"):
            evidence_box(b.sentence)
            st.write(f"Matched text: `{b.matched_text}` - keywords: {', '.join(b.keywords) or '-'}")
    if a.similarity_only:
        st.subheader("Similarity-only suggestions (no rule matched)")
        st.dataframe(pd.DataFrame(a.similarity_only), hide_index=True)


def page_mapping(cfg, kb, db):
    st.header("ATT&CK Technique Mapping")
    a = need_analysis()
    if a is None:
        return
    alt = st.checkbox("Include alternative candidates", value=False)
    df = mapping_frame(a, alt)
    st.dataframe(df, hide_index=True, use_container_width=True)
    if not df.empty:
        bands = df.groupby("Band").size().reset_index(name="Mappings")
        bar(bands, "Band", "Mappings", "Mappings by match-score band")
    st.caption("Scores combine rule, keyword, name/description similarity, specificity and context. "
               "They are heuristic rankings, not calibrated probabilities.")
    for m in a.mappings:
        if m.role != "primary" and not alt:
            continue
        with st.expander(f"{m.id} {m.technique_id} {m.technique_name} - {m.effective_score} ({m.band})"):
            st.markdown(f"**Behaviour:** {m.behavior} ({m.mode})  \n**Tactic:** {m.primary_tactic_name} "
                        f"(all: {', '.join(kb.tactic_name(t) for t in m.tactics) if kb else ', '.join(m.tactics)})")
            evidence_box(m.evidence)
            st.write({k: v for k, v in m.components.items()})
            for n in m.notes:
                st.caption(f"note: {n}")
            st.write(m.description[:600])
            if m.url:
                st.markdown(f"[Open on attack.mitre.org]({m.url})")


def page_tactics(cfg, kb, db):
    st.header("Tactic Analysis")
    a = need_analysis()
    if a is None:
        return
    groups = a.tactic_groups(kb, include_empty=True)
    bar(pd.DataFrame([{"Tactic": g.name, "Techniques": g.count} for g in groups]), "Tactic", "Techniques",
        "Distribution of techniques across ATT&CK tactics")
    for g in groups:
        if not g.count:
            continue
        with st.expander(f"{g.name} ({g.tactic_id}) - {g.count} technique(s): {', '.join(g.technique_ids)}"):
            for e in g.evidence:
                evidence_box(e)


def page_review(cfg, kb, db):
    st.header("Analyst Review")
    a = need_analysis()
    if a is None:
        return
    st.markdown("<div class='warnbox'>Suggestions stay <b>Awaiting review</b> until you act. Only an explicit "
                "<b>Confirm</b> marks a technique as a confirmed finding. Every decision is logged.</div>",
                unsafe_allow_html=True)
    analyst = st.text_input("Analyst name", value=st.session_state.get("analyst", "analyst"))
    st.session_state["analyst"] = analyst
    options = [f"{m.id} | {m.technique_id} {m.technique_name} | {m.status} | {m.role}" for m in a.mappings]
    if not options:
        st.info("No mappings to review.")
        return
    pick = st.selectbox("Mapping", options)
    m = a.get(pick.split(" | ")[0])
    st.markdown(f"**{m.technique_id} - {m.technique_name}** - score {m.effective_score} ({m.band}), status "
                f"**{m.status.replace('_', ' ')}**")
    evidence_box(m.evidence)
    comment = st.text_area("Analyst comment", value=m.analyst_comment, height=80)
    c = st.columns(5)
    actions = [("Accept", "accept"), ("Reject", "reject"), ("Confirm", "confirm"), ("Unconfirm", "unconfirm"),
               ("Reset", "reset")]
    for col, (label, act) in zip(c, actions):
        if col.button(label, key=f"btn_{act}"):
            try:
                a.review(m.id, act, analyst=analyst, comment=comment, kb=kb, db=db)
                st.success(f"{label}: {m.id} is now {m.status}")
            except ReviewError as exc:
                st.error(str(exc))
    st.subheader("Change technique / behaviour / score")
    query = st.text_input("Search alternative technique (ID or words)")
    if query and kb is not None:
        hits = kb.search(query, limit=8)
        if hits:
            alt = st.selectbox("Alternative", [f"{t.id} | {kb.full_name(t)}" for t, _ in hits])
            if st.button("Use this technique"):
                try:
                    a.review(m.id, "alternative", analyst=analyst, comment=comment,
                             technique_id=alt.split(" | ")[0], kb=kb, db=db)
                    st.success(f"{m.id} now maps to {m.technique_id} (ACCEPTED, analyst-modified)")
                except ReviewError as exc:
                    st.error(str(exc))
    new_behavior = st.text_input("Edit extracted behaviour", value=m.behavior)
    if new_behavior != m.behavior and st.button("Save behaviour text"):
        a.review(m.id, "edit_behavior", analyst=analyst, behavior_text=new_behavior, kb=kb, db=db)
        st.success("Behaviour updated.")
    score = st.slider("Analyst-adjusted score", 0, 100, int(m.effective_score))
    if score != m.effective_score and st.button("Save score"):
        a.review(m.id, "set_score", analyst=analyst, score=score, comment=comment, kb=kb, db=db)
        st.success("Score updated (automatic score kept for reference).")
    if a.analysis_id:
        st.subheader("Review log")
        log = db.review_log(a.analysis_id)
        st.dataframe(pd.DataFrame(log), hide_index=True) if log else st.caption("No decisions recorded yet.")


def page_navigator(cfg, kb, db):
    st.header("ATT&CK Navigator Export")
    a = need_analysis()
    if a is None:
        return
    alt = st.checkbox("Include unreviewed alternative candidates", value=False)
    layer = build_layer(a, kb, cfg, include_alternatives=alt)
    problems = validate_layer(layer, kb)
    if problems:
        st.error("Layer validation problems: " + "; ".join(problems))
    else:
        st.success(f"Layer valid: {len(layer['techniques'])} entries, ATT&CK v{layer['versions']['attack']}, "
                   f"layer format {layer['versions']['layer']}.")
    st.download_button("Download Navigator layer (.json)", layer_json(layer), file_name="attack_mapping_layer.json",
                       mime="application/json")
    st.markdown("Import it at https://mitre-attack.github.io/attack-navigator/ -> *Open Existing Layer* -> "
                "*Upload from local*.")
    st.json(layer, expanded=False)


def page_reports(cfg, kb, db):
    st.header("Generate Reports")
    a = need_analysis()
    if a is None:
        return
    data = build_report_data(a, kb)
    base = f"attack_mapping_{a.analysis_id or 'unsaved'}"
    c = st.columns(4)
    c[0].download_button("HTML report", to_html(data), file_name=f"{base}.html", mime="text/html")
    c[1].download_button("PDF report", to_pdf(data), file_name=f"{base}.pdf", mime="application/pdf")
    c[2].download_button("JSON", to_json(data), file_name=f"{base}.json", mime="application/json")
    c[3].download_button("CSV", to_csv(data), file_name=f"{base}.csv", mime="text/csv")
    st.subheader("Preview")
    st.write(data["threat_summary"])
    st.dataframe(pd.DataFrame(data["recommended_actions"]), hide_index=True)


def page_about(cfg, kb, db):
    st.header("About Project")
    st.markdown("""
**MITRE ATT&CK Technique Mapper** - a CTI analysis aid.

* Knowledge source: the official MITRE ATT&CK Enterprise STIX 2.1 dataset (github.com/mitre-attack/attack-stix-data).
  Techniques, tactics, revoked/deprecated status and mitigations are read from the loaded dataset - nothing is invented.
* Pipeline: NLP preprocessing -> rule-based TTP extraction -> TF-IDF + cosine similarity -> heuristic match score ->
  analyst review -> ATT&CK Navigator layer and reports.
* Scores rank suggestions; they are not probabilities. Suggestions are never confirmed automatically.
""")
    if kb is not None:
        st.json(kb.stats())


RENDER = {"Home Dashboard": page_home, "Upload Threat Intelligence": page_upload,
          "Manual Text Analysis": page_manual, "Extracted TTPs": page_ttps,
          "ATT&CK Technique Mapping": page_mapping, "Tactic Analysis": page_tactics, "Analyst Review": page_review,
          "Navigator Export": page_navigator, "Generate Reports": page_reports, "About Project": page_about}


def sidebar(cfg, kb, kb_error):
    with st.sidebar:
        st.markdown("### ATT&CK Technique Mapper")
        page = st.radio("Section", PAGES)
        st.divider()
        if kb is not None:
            st.caption(f"Dataset: ATT&CK {kb.version}" + (" - TEST FIXTURE" if kb.is_fixture else ""))
        if kb_error:
            st.warning(kb_error)
        if st.button("Download / update official dataset"):
            try:
                with st.spinner("Downloading the official ATT&CK Enterprise bundle..."):
                    download_dataset(cfg["attack"]["download_url"], cfg.path("attack", "dataset_path"),
                                     cfg["attack"]["download_timeout_seconds"])
                st.session_state["use_fixture"] = False
                get_kb.clear()
                st.success("Downloaded. Reload the page.")
            except AttackDataError as exc:
                st.error(str(exc))
        st.session_state["use_fixture"] = st.checkbox(
            "Demo mode: use the small TEST FIXTURE (not official data)", value=st.session_state.get("use_fixture",
                                                                                                    False))
    return page


def main():
    st.set_page_config(page_title="ATT&CK Technique Mapper", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    try:
        cfg, kb, kb_error, db = context()
    except ConfigError as exc:
        st.error(str(exc))
        return
    page = sidebar(cfg, kb, kb_error)
    if kb is None and page not in ("About Project",):
        st.error("No ATT&CK knowledge base loaded. Use the sidebar to download the official dataset "
                 "(or tick demo mode to try the test fixture).")
        return
    RENDER[page](cfg, kb, db)


if __name__ == "__main__":
    main()
