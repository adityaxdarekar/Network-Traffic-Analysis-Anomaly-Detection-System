# MITRE ATT&CK Technique Mapper Using Python
### College project report

## 1. Abstract
Threat-intelligence reports describe attacker behaviour in free text, while defenders need it as structured ATT&CK techniques to measure coverage, hunt and share findings. This project builds a Python application that:
* reads threat-intelligence text, TXT, PDF or JSON;
* preprocesses it with NLP and extracts attacker behaviours with explainable rules;
* maps each behaviour to techniques in the **official MITRE ATT&CK Enterprise STIX 2.1 dataset**, combining rule hints with TF-IDF and cosine similarity;
* ranks every suggestion with a transparent match score.

Analysts accept, reject, confirm or change each suggestion through a Streamlit dashboard or a CLI, and every decision is logged. The results export as an ATT&CK Navigator layer and as HTML, PDF, JSON and CSV reports.

## 2. Introduction
MITRE ATT&CK is a globally used knowledge base of adversary tactics and techniques built from real-world observations. Mapping reports to ATT&CK is routine CTI and SOC work, but it is slow and depends on the individual analyst. Automated suggestions with evidence speed it up. The analyst stays in control, because automated mapping makes mistakes.

## 3. Problem statement
Manual ATT&CK mapping:
* takes time;
* varies between analysts;
* is error-prone with roughly 700 techniques and sub-techniques that change between versions (v20, for example, split Defense Evasion into Stealth and Defense Impairment).

Simple keyword tools often hard-code outdated IDs and hide their reasoning. A tool is needed that:
* uses the official, current dataset;
* shows the evidence for every suggestion;
* separates explicit from inferred behaviour;
* never presents an automated guess as a confirmed finding.

## 4. Project objectives
1. Accept text, TXT, PDF and JSON input, with validation.
2. Preprocess the text with NLP while preserving technical terms.
3. Extract attacker behaviours, recording evidence, keywords, explicit/inferred status, hedging and negation.
4. Load and cache the official ATT&CK STIX data, including tactics, techniques, sub-techniques, revoked and deprecated entries, platforms, data sources and mitigations.
5. Map behaviours to techniques using keyword matching, rules, TF-IDF, cosine similarity and context.
6. Score and band each suggestion, without presenting the scores as probabilities.
7. Group the results by tactic, support analyst review with an audit log, and export Navigator layers and reports.

## 5. Existing system
* **Manual mapping** in spreadsheets: accurate when done by experts, but slow and inconsistent.
* **MITRE's TRAM** (Threat Report ATT&CK Mapper): machine-learning sentence classification, which needs training data and setup.
* **Commercial CTI platforms**: powerful but closed and costly.
* **Simple scripts** with hard-coded keyword-to-ID tables: they go stale when ATT&CK changes, and they give no evidence or confidence.

## 6. Proposed system
A modular, transparent pipeline over the official dataset:
* **Explainable rules** for common behaviours. Their technique hints are always checked against the loaded data.
* **TF-IDF and cosine similarity** across all active techniques, to surface further candidates.
* **A weighted match score** with visible components.
* **Primary and alternative roles** for candidates.
* **A mandatory analyst review**, recorded in an audit log.
* **Standard outputs**: Navigator layers and HTML, PDF, JSON and CSV reports.

## 7. System architecture
```
Input -> document_loader -> text_processor -> ttp_extractor -> technique_mapper (+confidence_scorer)
      -> tactic_classifier -> Analysis -> database (+review log) -> navigator_exporter / report_generator
attack_loader: official STIX bundle -> parsed index (cached) -> KnowledgeBase (lookups, revoked/deprecated
               resolution, TF-IDF matrix)
Interfaces: app.py (Streamlit) and main.py (CLI)
```

## 8. Hardware and software requirements
| Item | Requirement |
|---|---|
| CPU / RAM / disk | dual-core, 4 GB RAM (8 GB recommended), 500 MB free |
| OS | Kali Linux, Ubuntu 22.04+ (also runs on Windows/macOS) |
| Software | Python 3.10+, requests, pandas, scikit-learn, numpy, streamlit, plotly, pypdf, reportlab, stix2 (optional), spaCy or NLTK (optional), pytest |
| Data | the official enterprise-attack.json (about 45 MB) |
| Network | needed once, to download the dataset |

## 9. Module descriptions
| Module | Responsibility |
|---|---|
| text_processor | normalisation, re-fanging, sentence splitting, tokenisation of technical terms, keyword, verb and IOC tagging |
| ttp_extractor | around 30 behaviour rules; evidence, keywords, explicit/inferred, hedging and negation, extraction confidence |
| attack_loader | STIX parsing, matrix tactic order, revoked-by chains, deprecation, mitigations, data sources, caching, download, TF-IDF index, search |
| technique_mapper | candidate generation (rules plus TF-IDF), scoring, preferring sub-techniques, primary/alternative roles, technique view |
| confidence_scorer | weighted components, hedging and negation multipliers, bands |
| tactic_classifier | grouping by primary tactic in dataset order, with evidence |
| navigator_exporter | Navigator layer 4.5 (scores, colours, comments, metadata, tactic, parent entries) and validation |
| report_generator | HTML, PDF, JSON and CSV with all required sections |
| document_loader | TXT, PDF, JSON and Markdown parsing; size, type, encoding and emptiness checks |
| database | SQLite analyses, mappings and the append-only review log |
| pipeline | the end-to-end Analyzer; Analysis object with review actions |
| app.py / main.py | the dashboard and the command-line interface |

## 10. NLP methodology
* **Normalisation**: Unicode, quotes, hyphenation, bullets and control characters are cleaned. Defanged indicators such as `hxxp` and `[.]` are re-fanged.
* **Sentence splitting**: spaCy or NLTK when installed; otherwise a regex splitter that knows common abbreviations (for example "e.g." and "vs.").
* **Tokenisation**: a token pattern keeps `cmd.exe`, `HKCU\...` paths, IP addresses, ATT&CK IDs and CVE IDs whole.
* **Tagging**: tools, protocols, OS terms and security terms, plus action verbs (matched by stem) and IOCs (IPs, hashes, files, registry keys, CVEs, domains).
* **No stop-word removal before extraction**, so technical words are never lost. English stop words are removed only inside the TF-IDF vectoriser.

## 11. TTP extraction methodology
Each rule has regex patterns, keywords, technique hints (an ID, a weight, an optional *required context* and the preferred tactics), a specificity value and an explicit/inferred flag.
* **Within a sentence**, matches are collected, and generic rules are dropped when a more specific rule also matched (for example "phishing" when "phishing attachment" matched).
* **Hedging** is detected with words such as attempted, likely and possibly.
* **Negation** is detected with phrases such as did not, no evidence of and failed to.
* **Inferred behaviours** (for example "used stolen credentials to access another machine" implying lateral movement) are labelled as inferred, and the specific protocol is never invented.

## 12. MITRE ATT&CK integration
* **Parsing**: the STIX bundle is parsed directly, as JSON objects:
  * `x-mitre-tactic` gives the tactics, and `x-mitre-matrix` `tactic_refs` gives their order;
  * `attack-pattern` gives the techniques, with `kill_chain_phases`, `x_mitre_platforms`, `x_mitre_is_subtechnique`, `revoked` and `x_mitre_deprecated`;
  * `relationship` objects give revoked-by links, mitigations (`mitigates`) and data components (`detects`).
* **Duplicate IDs**: when two objects share an ID, the live one is kept.
* **Cache**: a compact index is cached, keyed by the file's SHA-256.
* **Check**: the optional `stix2` library can parse a sample of objects as a check.
* **Download**: the file is downloaded atomically and validated before it replaces a working copy.

## 13. TF-IDF implementation
`TfidfVectorizer` from scikit-learn is used with these settings:
* English stop words removed;
* unigrams and bigrams;
* sublinear term frequency.

It is fitted on one document per active technique: the name (repeated three times so it outweighs long descriptions), the parent technique's name, and the description with markup removed. Each evidence sentence, plus its behaviour label, is transformed with the same vocabulary.

## 14. Cosine similarity explanation
Cosine similarity = (A·B) / (|A||B|), the cosine of the angle between two TF-IDF vectors. A value of 1 means the same term profile and 0 means no shared weighted terms. The top *k* techniques by cosine (k = 3, minimum 0.10) become candidates. The raw cosine is scaled (reaching 1.0 at 0.35) to give the description-similarity component.

## 15. Confidence scoring methodology
Score = 100 × (0.35·rule + 0.15·keyword + 0.15·name_similarity + 0.15·description_similarity + 0.10·specificity + 0.10·context), multiplied by 0.85 if hedged or 0.2 if negated, and capped at 99.

| Band | Score |
|---|---|
| HIGH | 90 or more |
| MEDIUM-HIGH | 70–89 |
| MEDIUM | 50–69 |
| LOW | below 50 |

A rule hint whose required context is missing (for example T1041 without any mention of C2) has its rule weight halved, and it can only be an *alternative*. The score is a ranking heuristic, **not a calibrated probability**. Analysts can override it, and the automatic score is kept.

## 16. Testing and results
**Automated tests (pytest): 34 tests, all passing in the build environment.** They cover:
* dataset parsing, tactic order, revoked/deprecated handling, the cache, and download failure handling;
* NLP and document loading;
* extraction, including the explicit/inferred, hedged and negated cases;
* the three test scenarios from the brief;
* a check that every mapping exists in the dataset and that its evidence is a real sentence from the input;
* review actions and the audit log;
* Navigator layer validation;
* all four report formats;
* the CLI;
* a dashboard smoke test against a Streamlit stand-in.

The tests ran against a **labelled STIX test fixture** of 39 techniques, whose IDs, names and tactics were checked against attack.mitre.org (v20). Primary results:

| Test | Primary suggestions (score) |
|---|---|
| 1 Phishing | T1566.001 (91), T1204.002 (83), T1059.001 (99), T1547.001 (94) |
| 2 Credential theft | T1003 (74, hedged), T1078 (74), T1021 (48, inferred) |
| 3 Exfiltration | T1005 (72), T1048 (65), T1573 (49, inferred); T1041 (54) is only an alternative because no C2 is mentioned |

Re-run the tests with the full official dataset and record your results here; scores can differ when TF-IDF compares against the full set of techniques.

## 17. Advantages
* Uses official, current ATT&CK data and follows version changes automatically.
* Every suggestion carries its evidence and a score broken into components.
* Explicit and inferred behaviour are kept separate, and hedging and negation are detected.
* Suggestions are never confirmed automatically, and there is a full audit log.
* Standard outputs: Navigator layers and HTML, PDF, JSON and CSV reports.
* Works offline once the dataset has been downloaded.

## 18. Limitations
* Rules cover common behaviours only; unusual wording can be missed.
* The analysis works sentence by sentence; behaviour spread across several sentences, and pronouns referring back to earlier sentences, are not linked.
* Negation and hedging detection is pattern-based.
* TF-IDF matches words, not meaning (no embeddings), and it needs no training data but learns nothing from feedback.
* Scores are uncalibrated.
* Indicators are extracted but not enriched.
* The full official dataset and the real Streamlit UI were not exercised in the build environment (see PROJECT_STATUS.md).

## 19. Future enhancements
* Sentence-embedding similarity (for example sentence-transformers) alongside TF-IDF.
* Learning from analyst decisions to tune weights.
* Coreference resolution across sentences.
* A TAXII 2.1 client for automatic dataset updates.
* Groups and software from ATT&CK, and procedure examples as extra matching text.
* Mobile and ICS domains.
* Export to MISP or OpenCTI.
* Multi-analyst workflows with roles.

## 20. Conclusion
The Mapper turns unstructured threat intelligence into structured ATT&CK knowledge using the official dataset, with an evidence trail and an analyst in control. It shows how classic NLP, rule engineering and vector similarity can make CTI work faster and more consistent while staying explainable.
