# Viva questions and answers

1. **What is MITRE ATT&CK?** A free, globally used knowledge base of adversary tactics, techniques and procedures, built from real-world observations and maintained by MITRE. It has Enterprise, Mobile and ICS domains.

2. **What are TTPs?** Tactics, Techniques and Procedures: *why* an adversary acts (tactic), *how* (technique), and the *specific implementation* (procedure).

3. **What is a tactic?** The adversary's goal at a stage of an attack, such as Initial Access, Execution, Persistence or Exfiltration. Tactic IDs look like TA0002.

4. **What is a technique?** A way of achieving a tactic, for example T1059 Command and Scripting Interpreter. One technique can serve several tactics; T1078 Valid Accounts is an example.

5. **What is a sub-technique?** A more specific variant of a technique, written with a dot, for example T1059.001 PowerShell under T1059.

6. **What is a procedure?** A specific, observed implementation of a technique by a group or piece of software, for example "APT-X used `powershell -enc` to download a payload".

7. **What is STIX?** Structured Threat Information eXpression, an OASIS JSON standard for CTI objects (attack-pattern, malware, indicator, relationship, ...). ATT&CK is published as a STIX 2.1 bundle.

8. **What is TAXII?** Trusted Automated eXchange of Intelligence Information, an HTTPS protocol for sharing STIX content (collections and channels). MITRE ran a TAXII server for ATT&CK. This project downloads the official GitHub bundle and could add a TAXII client.

9. **What is threat intelligence / CTI?** Evidence-based knowledge about threats (actors, tools, behaviours, indicators) that supports decisions. It is strategic, operational, tactical or technical.

10. **What is NLP?** Natural Language Processing: techniques that let computers process human language, such as tokenisation, sentence splitting, tagging and vectorisation.

11. **What is tokenisation?** Splitting text into units (tokens). Here a custom pattern keeps technical tokens like `cmd.exe`, `HKCU\...\Run`, `T1059.001` and IP addresses whole.

12. **What is stemming/lemmatisation?** Reducing words to a base form (dumped → dump) so variants match. The project uses Porter stemming (NLTK) or a simple suffix stripper.

13. **What is TF-IDF?** Term Frequency × Inverse Document Frequency. A word is weighted highly when it is frequent in a document but rare across all documents, so distinctive terms dominate.

14. **What is cosine similarity?** The cosine of the angle between two vectors, (A·B)/(|A||B|). For TF-IDF it ranges from 0 (no shared weighted terms) to 1 (the same profile), and it ignores document length.

15. **Why combine rules with TF-IDF?** Rules capture strong, known patterns precisely and explain themselves. TF-IDF covers the whole dataset and finds candidates no rule anticipated. Together they balance precision and coverage.

16. **What is confidence scoring here?** A weighted combination of rule, keyword, name-similarity, description-similarity, specificity and context components (0–99), reduced for hedged or negated text and grouped into bands.

17. **Is the score a probability?** No. It is an uncalibrated ranking heuristic. Calibration would need labelled data and statistical fitting, which is why the app labels scores as heuristic.

18. **What is ATT&CK Navigator?** MITRE's web app for viewing and annotating ATT&CK matrices with *layers* (JSON files containing technique IDs, scores, colours and comments).

19. **What does your Navigator export contain?** Layer format 4.5 with:
    * the ATT&CK version taken from the dataset;
    * one entry per technique and tactic, with score, colour (by status or band), analyst comment, evidence metadata and link;
    * parent entries so sub-techniques show;
    * a legend.

    Rejected mappings are left out by default.

20. **How are revoked and deprecated techniques handled?**
    * **Revoked**: the "revoked-by" relationship is followed to the replacement, and the change is noted.
    * **Deprecated**: the technique is dropped with a warning.
    * **Unknown IDs**: rejected.

    None of these are ever offered as suggestions.

21. **What changed in ATT&CK v20 and how does the app cope?** Defense Evasion was replaced by Stealth (TA0005) and Defense Impairment (TA0112). Tactics are read from the dataset's matrix, so the app shows whatever the loaded version contains.

22. **What is a false positive in automated mapping?** Suggesting a technique the evidence does not support, for example T1041 when there is no C2 channel. The project reduces this with required-context checks, primary and alternative roles, and analyst review.

23. **What is a false negative?** Missing a technique that is present, for example an unusual phrasing no rule covers and TF-IDF misses.

24. **What is threat hunting?** Proactively searching telemetry for adversary activity that evaded detection, often driven by ATT&CK techniques taken from CTI.

25. **What is a SOC?** A Security Operations Centre: the team, processes and tools that monitor, detect, investigate and respond to security events.

26. **IOC vs TTP?** IOCs (hashes, IPs, domains) are specific artefacts that attackers change easily. TTPs describe behaviour, which is costlier for attackers to change, so they are more durable for detection (see the Pyramid of Pain).

27. **What is the Pyramid of Pain?** David Bianco's model: blocking hashes, IPs and domains costs attackers little, while disrupting tools and TTPs costs them the most.

28. **How does automated ATT&CK mapping work in your project?**
    1. Preprocess the text.
    2. Extract behaviours with rules, keeping their evidence.
    3. Generate candidates from the rule hints (checked against the dataset) and from TF-IDF.
    4. Score each candidate and assign roles.
    5. Group by tactic.
    6. The analyst reviews.
    7. Export.

29. **What are the limitations of automated mapping?** It depends on wording, the analysis is sentence by sentence, it cannot check whether the source is true, it works on lexical rather than semantic similarity, scores are uncalibrated, and it needs human validation.

30. **Explicit vs inferred behaviour?** Explicit behaviour is stated directly ("used PowerShell"). Inferred behaviour is implied ("used stolen credentials to access another machine" implies lateral movement, but the method is not stated). Inferred mappings score lower and are labelled.

31. **How do you handle hedging and negation?** Hedging words ("attempted", "likely") multiply the score by 0.85. Negation ("no evidence of", "did not") multiplies it by 0.2, which normally keeps the mapping out of the report while the behaviour stays visible.

32. **Why must an analyst confirm mappings?** Automated suggestions can be wrong, and the brief requires that a suggestion is never silently turned into a confirmed incident finding. Every decision is stored with the analyst's name, time, old value and new value.

33. **Why cache the dataset?** The bundle is about 45 MB. Parsing it once into a compact index keyed by the file's SHA-256 makes later start-ups fast and avoids repeated network calls.

34. **How would you improve accuracy?** Add sentence-embedding similarity, use ATT&CK procedure examples as matching text, resolve coreference across sentences, learn weights from analyst decisions, and evaluate precision and recall on a labelled report set.
