# Practical demonstration guide

Before the demo, run `python3 main.py download` once. Then use either the dashboard (`streamlit run app.py`) or the CLI below.
The outputs quoted here come from the build environment, which used the **labelled test fixture** (see PROJECT_STATUS.md). With the full official dataset, the TF-IDF stage compares against about 700 techniques instead of 39, so scores and alternative candidates can differ. Re-run the tests and use your own output and screenshots for the presentation.

---

## Test 1 - Phishing-based attack
```bash
python3 main.py analyze --sample test1_phishing --save --alternatives
```
**Input:** "A threat actor distributed phishing emails containing malicious attachments. After opening the attachment, the victim executed a malicious script through PowerShell. The attacker then established persistence using Windows Registry Run keys."

**Extracted behaviours:** all explicit.
* phishing email with a malicious attachment
* user opened a malicious file
* PowerShell execution
* Registry Run key persistence

**Primary suggestions (build-environment run):**

| Technique | Tactic | Score |
|---|---|---|
| T1566.001 Spearphishing Attachment | Initial Access | 91 HIGH |
| T1204.002 Malicious File | Execution | 83 MEDIUM-HIGH |
| T1059.001 PowerShell | Execution | 99 HIGH |
| T1547.001 Registry Run Keys / Startup Folder | Persistence | 94 HIGH |

**Explain:**
* The rule hint and the TF-IDF similarity agree on each technique (origin `rule+similarity`).
* Each ID was looked up in the loaded dataset before being shown.
* T1204.002 was not in the brief's expected list, but the text supports it ("After opening the attachment, the victim executed...").

**Screenshots:**
* Extracted TTPs page
* the mapping table
* the Tactic Analysis chart

## Test 2 - Credential theft
```bash
python3 main.py analyze --sample test2_credential_theft --save --alternatives
```
| Behaviour | Suggestion | Note |
|---|---|---|
| Credential dumping (explicit, **hedged**: "attempted") | T1003 OS Credential Dumping, 74 | The score was multiplied by 0.85 for hedging. T1003.001 appears only as a weak alternative, because LSASS is not mentioned. |
| Valid accounts (explicit) | T1078 Valid Accounts, 74 | Primary tactic: Stealth (v20); its other tactics are also listed. |
| Lateral movement (**inferred**) | T1021 Remote Services, 48 | RDP and SMB sub-techniques appear as alternatives with "RDP not mentioned" / "SMB not mentioned". |

**Explain:** this is how the tool separates *explicit* evidence from *inferred* behaviour. It does not invent a specific lateral-movement protocol.

## Test 3 - Data exfiltration
```bash
python3 main.py analyze --sample test3_exfiltration --save --alternatives
```
| Suggestion | Score | Why |
|---|---|---|
| T1005 Data from Local System | 72 | "collected sensitive documents from the compromised machine" |
| T1048 Exfiltration Over Alternative Protocol | 65 | "external server over an encrypted network connection" |
| T1567 Exfiltration Over Web Service | 59 | **alternative**: its condition failed ("no web/cloud service mentioned") |
| T1041 Exfiltration Over C2 Channel | 54 | **reduced**, noted as "the evidence does not mention a C2 channel" |
| T1573 Encrypted Channel | 49 | inferred; the encryption is not stated to be for C2 |

**Explain:** T1041 scores high only when the text supports a C2 channel, as the brief requires. Try changing the text to "exfiltrated over the existing C2 channel" and re-run: T1041 rises to 73.

## Analyst review demonstration
```bash
python3 main.py review 1 M1 confirm --analyst you --comment "Mail gateway log shows delivery"
python3 main.py review 1 M2 reject --comment "No user execution evidence in EDR"
python3 main.py review 1 M4 alternative --technique T1059.003 --comment "It was cmd.exe, not PowerShell"
python3 main.py review 1 M4 alternative --technique T9999        # refused: not in the dataset
python3 main.py export 1 --navigator layer.json --report html,pdf
```
In the dashboard, the same actions are on the **Analyst Review** page, which also shows the review log.

**Screenshot:** the review log after confirming one mapping and rejecting another.

## Navigator import
1. Open https://mitre-attack.github.io/attack-navigator/.
2. Choose **Open Existing Layer**, then **Upload from local**, and select `layer.json`.
3. Show the colours: green means confirmed, blue means HIGH, and so on. Hover over a technique to show its comment and evidence metadata.

## Larger example
`python3 main.py analyze --sample test4_full_intrusion_fictional --save` runs a fictional multi-stage intrusion. In the build environment it produced 18 techniques across 10 tactics.

The last sentence, "There was no evidence that the attackers encrypted files for ransom", is extracted as *Encryption of data for impact*, but it is flagged **negated**. That multiplies its score by 0.2, so **no** T1486 mapping is reported. You can see it under *Extracted TTPs* with Negated = true.
