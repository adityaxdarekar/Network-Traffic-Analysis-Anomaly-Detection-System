import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from modules.settings import load_config  # noqa: E402

SAMPLES = ROOT / "data" / "offline_samples"
FAKE_KEY = "0123456789abcdef" * 4          # 64 hex chars, obviously fake - used only in tests


def sample(name: str) -> dict:
    return json.loads((SAMPLES / name).read_text())


class FakeResponse:
    def __init__(self, status, body=None, raw=None):
        self.status_code = status
        self._body = body
        self.content = raw if raw is not None else (json.dumps(body).encode() if body is not None else b"")

    def json(self):
        if self._body is None:
            return json.loads(self.content.decode())
        return self._body


class FakeSession:
    """Plays back a list of responses (or exceptions) and records requests."""

    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def get(self, url, headers=None, timeout=None):
        self.calls.append({"url": url, "headers": headers, "timeout": timeout})
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


@pytest.fixture
def cfg(tmp_path):
    c = json.loads((ROOT / "config.json").read_text())
    c["paths"] = {"database": str(tmp_path / "t.db"), "reports": str(tmp_path / "reports"),
                  "logs": str(tmp_path / "app.log"), "offline_samples": str(SAMPLES)}
    (tmp_path / "config.json").write_text(json.dumps(c))
    return load_config(tmp_path / "config.json", base_dir=ROOT)


@pytest.fixture
def db(cfg):
    from modules.database import Database
    d = Database(cfg.path("database"))
    yield d
    d.close()
