import copy
from datetime import datetime, timezone

import pytest

from conftest import sample
from modules.ioc_analyzer import UNAVAILABLE, analyze, fmt, url_characteristics
from modules.ioc_validator import validate
from modules.risk_classifier import classify

NOW = datetime(2026, 11, 7, tzinfo=timezone.utc)


def run(value, body, found=True, source="virustotal-live"):
    return analyze(validate(value), {"found": found, "source": source, "response": body, "fetched_at": "t"}, NOW)


def test_ip_fields_and_zero_vs_unavailable():
    a = run("198.51.100.23", sample("ip_198.51.100.23.json"))
    assert a.detections == 12 and a.suspicious == 2 and a.total_engines == 94 and a.detection_ratio == "12/94"
    assert a.metadata["ASN"] == 64500 and a.metadata["Country"] == "ZZ" and a.reputation == -25
    assert a.analysis_age_days == 4 and a.last_analysis_date.startswith("2026-11-02")
    assert len(a.flagged_vendors) == 14 and a.vendors[0]["category"] == "malicious"
    assert a.permalink == "https://www.virustotal.com/gui/ip-address/198.51.100.23"
    body = copy.deepcopy(sample("ip_192.0.2.10.json"))
    del body["data"]["attributes"]["asn"]
    z = run("192.0.2.10", body)
    assert z.detections == 0 and fmt(z.detections) == "0"            # a real zero stays 0
    assert z.metadata["ASN"] is None and fmt(z.metadata["ASN"]) == UNAVAILABLE
    del body["data"]["attributes"]["last_analysis_stats"]
    assert run("192.0.2.10", body).detection_ratio == UNAVAILABLE


def test_domain_url_and_file_fields():
    d = run("malware-test.example", sample("domain_malware-test.example.json"))
    assert d.metadata["Registrar"].startswith("Example Registrar")
    assert {"type": "ip", "value": "198.51.100.23", "relation": "DNS A record"} in d.related
    u = run("http://phishing-test.example/login", sample("url_phishing-test.example.json"))
    assert u.metadata["Page title"] == "Sign in (sample page)"
    assert any("login" in c for c in u.url_characteristics)
    assert u.permalink.startswith("https://www.virustotal.com/gui/url/")
    f = run("57be2e02f11fbc2bfabddf97af7556d514f4145bac5ee310ba4bd6345510d8d5", sample("file_fictional_sample.json"))
    assert f.metadata["File type"] == "Win32 EXE" and f.metadata["File size (bytes)"] == 245760
    assert f.metadata["Malware classification"] == "trojan.samplefamily/fictional"
    assert f.metadata["Malware family names"] == ["samplefamily"]


def test_not_found():
    a = run("unknown-host.example", sample("domain_unknown-host.example.json"), found=False)
    assert not a.found and a.detection_ratio == UNAVAILABLE and "not found" in a.not_found_message


def test_url_heuristics():
    c = url_characteristics("http://user@203.0.113.9:8081/a/b/update.exe")
    text = " ".join(c)
    for part in ("unencrypted", "raw IP", "'@'", "non-standard port", "executable"):
        assert part in text
    assert url_characteristics("https://example.com/") == []


def with_stats(mal, sus=0, harmless=60, undetected=20, rep=0, votes=(0, 0), ts=1793620800):
    body = copy.deepcopy(sample("ip_192.0.2.10.json"))
    at = body["data"]["attributes"]
    at["last_analysis_stats"] = {"malicious": mal, "suspicious": sus, "harmless": harmless, "undetected": undetected}
    at["reputation"], at["total_votes"], at["last_analysis_date"] = rep, {"harmless": votes[0], "malicious": votes[1]}, ts
    return run("192.0.2.10", body)


@pytest.mark.parametrize("mal,level", [(0, "NO_DETECTIONS"), (1, "LOW"), (3, "LOW"), (4, "MEDIUM"), (9, "MEDIUM"),
                                       (10, "HIGH"), (19, "HIGH"), (20, "CRITICAL"), (55, "CRITICAL")])
def test_threshold_boundaries(cfg, mal, level):
    assert classify(with_stats(mal), cfg).level == level


def test_zero_detections_is_not_called_safe(cfg):
    r = classify(with_stats(0), cfg)
    assert r.label == "No detections reported" and "not proof" in r.summary
    assert "safe" not in r.label.lower()
    assert classify(with_stats(0, rep=-30), cfg).level == "LOW"            # negative reputation raises it
    assert classify(with_stats(0, sus=2), cfg).level == "LOW"
    assert classify(with_stats(0, votes=(1, 5)), cfg).level == "LOW"


def test_not_found_and_confidence(cfg):
    nf = classify(run("unknown-host.example", sample("domain_unknown-host.example.json"), found=False), cfg)
    assert nf.level == "NOT_FOUND" and nf.confidence == "NONE" and "not the same as safe" in nf.summary
    assert classify(with_stats(12, harmless=60, undetected=30), cfg).confidence == "HIGH"
    assert classify(with_stats(2, harmless=10, undetected=5), cfg).confidence == "LOW"
    old = classify(with_stats(2, ts=1700000000), cfg)
    assert old.confidence == "LOW" and any("old" in f for f in old.factors)


def test_offline_sample_summary_is_labelled(cfg):
    a = run("198.51.100.23", sample("ip_198.51.100.23.json"), source="offline-sample")
    assert classify(a, cfg).summary.startswith("[OFFLINE SAMPLE]")
