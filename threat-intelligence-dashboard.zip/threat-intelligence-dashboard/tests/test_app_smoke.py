"""
Smoke test for app.py with a STAND-IN for Streamlit (not installed in the build
environment). It runs every page so wiring mistakes are caught; it does NOT
prove the real UI renders correctly (see PROJECT_STATUS.md).
"""
import importlib
import sys
import types

import pytest

from conftest import FAKE_KEY


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeSt(types.ModuleType):
    current = None

    def __init__(self):
        super().__init__("streamlit")
        self.session_state, self.calls, self.clicks, self.inputs = {}, [], set(), {}
        self.sidebar = _Ctx()
        FakeSt.current = self

    def cache_resource(self, fn=None, **kw):
        return fn if fn else (lambda f: f)

    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def tabs(self, names):
        return [_Ctx() for _ in names]

    def spinner(self, *a, **kw):
        return _Ctx()

    def progress(self, *a, **kw):
        return types.SimpleNamespace(progress=lambda *a, **k: None)

    def radio(self, label, options, **kw):
        return self.session_state.get("_page", options[0])

    def selectbox(self, label, options, index=0, **kw):
        return self.inputs.get(label, options[index] if options else None)

    def multiselect(self, label, options, default=None, **kw):
        return default or []

    def button(self, label, **kw):
        return label in self.clicks

    def checkbox(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    def text_input(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def text_area(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def file_uploader(self, *a, **kw):
        return None

    def download_button(self, label, data, *a, **kw):
        assert data, label
        self.calls.append(("download", label, data))
        return False

    def __getattr__(self, name):
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


@pytest.fixture
def app(monkeypatch, cfg):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    sys.modules.pop("app", None)
    mod = importlib.import_module("app")
    monkeypatch.setattr(mod, "load_config", lambda: cfg)
    return mod, fake


def errors(fake):
    return [c for c in fake.calls if c[0] == "error"]


def test_investigate_every_type_offline_and_all_pages(app, cfg, db):
    mod, fake = app
    fake.session_state["offline_mode"] = True
    for t, value in (("ip", "198.51.100.23"), ("domain", "malware-test.example"),
                     ("url", "http://phishing-test.example/login"),
                     ("hash", "57be2e02f11fbc2bfabddf97af7556d514f4145bac5ee310ba4bd6345510d8d5")):
        title = {"ip": "IP Address", "domain": "Domain", "url": "URL", "hash": "File Hash"}[t]
        fake.inputs[f"{title} to investigate"] = value
        fake.clicks = {"Investigate"}
        mod.page_investigate(cfg, db, t)
        assert fake.session_state["current_investigation"]
    assert not errors(fake), errors(fake)
    assert any(c[0] == "markdown" and "OFFLINE SAMPLE" in str(c[1]) for c in fake.calls)
    downloads = [c for c in fake.calls if c[0] == "download"]
    assert {c[1] for c in downloads} >= {"HTML report", "PDF report", "JSON", "CSV"}
    fake.clicks = {"Run batch analysis"}
    mod.page_batch(cfg, db)
    assert fake.session_state["last_batch"].summary()["rows"] == 15
    hm = mod.HistoryManager(db)
    for fn in (mod.page_home, mod.page_history, mod.page_analytics, mod.page_reports):
        fn(cfg, db, hm)
    mod.page_settings(cfg, db)
    assert not errors(fake), errors(fake)


def test_invalid_input_and_missing_sample_messages(app, cfg, db):
    mod, fake = app
    fake.session_state["offline_mode"] = True
    fake.inputs["IP Address to investigate"] = "999.1.1.1"
    fake.clicks = {"Investigate"}
    mod.page_investigate(cfg, db, "ip")
    assert any("Invalid ip address" in str(c[1]) for c in errors(fake))
    fake.inputs["IP Address to investigate"] = "8.8.8.8"
    mod.page_investigate(cfg, db, "ip")
    assert any(c[0] == "warning" and "No offline sample" in str(c[1]) for c in fake.calls)


def test_settings_masks_key_and_main_runs(app, cfg, db, monkeypatch):
    mod, fake = app
    monkeypatch.setenv("VIRUSTOTAL_API_KEY", FAKE_KEY)
    mod.page_settings(cfg, db)
    shown = " ".join(str(c[1]) for c in fake.calls)
    assert FAKE_KEY not in shown and "cdef" in shown
    fake.session_state["_page"] = "Home Dashboard"
    monkeypatch.setattr(mod, "get_db", lambda p: db)
    mod.main()
    assert not errors(fake)
