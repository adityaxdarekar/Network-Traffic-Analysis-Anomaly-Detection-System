import pytest

from modules.ioc_validator import IOCValidationError, detect_type, refang, validate


@pytest.mark.parametrize("value,t,sub,norm", [
    ("8.8.8.8", "ip", "ipv4", "8.8.8.8"),
    ("2001:4860:4860:0000:0000:0000:0000:8888", "ip", "ipv6", "2001:4860:4860::8888"),
    ("Example.COM", "domain", "domain", "example.com"),
    ("sub.domain.example.org.", "domain", "domain", "sub.domain.example.org"),
    ("bücher.example", "domain", "domain", "xn--bcher-kva.example"),
    ("https://example.com/", "url", "url", "https://example.com/"),
    ("hxxp://phishing-test[.]example/login", "url", "url", "http://phishing-test.example/login"),
    ("44D88612FEA8A8F36DE82E1278ABB02F", "hash", "md5", "44d88612fea8a8f36de82e1278abb02f"),
    ("3395856ce81f2b7382dee72602f798b642f14140", "hash", "sha1", "3395856ce81f2b7382dee72602f798b642f14140"),
    ("275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f", "hash", "sha256",
     "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"),
])
def test_valid_indicators(value, t, sub, norm):
    ioc = validate(value)
    assert (ioc.type, ioc.subtype, ioc.value) == (t, sub, norm)


@pytest.mark.parametrize("value,t", [
    ("999.1.1.1", None), ("10.0.0", "ip"), ("-bad-.example", "domain"), ("exa mple.com", None),
    ("example", "domain"), ("ftp://example.com/x", "url"), ("https://", "url"), ("http://-x-.example", "url"),
    ("12345", "hash"), ("zz" * 16, "hash"), ("", None), ("8.8.8.8", "domain"), ("example.com", "potato"),
])
def test_invalid_indicators_rejected(value, t):
    with pytest.raises(IOCValidationError):
        validate(value, t)


def test_detect_and_refang():
    assert detect_type("1.1.1.1") == "ip" and detect_type("a.example") == "domain"
    assert detect_type("https://a.example/x") == "url" and detect_type("a" * 64) == "hash"
    assert detect_type("hello") is None
    assert refang(" hxxps://evil[.]example[:]8080/ ") == "https://evil.example:8080/"
    assert validate("8.8.8.8", "ipv4").type == "ip" and validate("A" * 32, "md5").subtype == "md5"


def test_error_messages_are_helpful():
    with pytest.raises(IOCValidationError, match="32 \\(MD5\\), 40 \\(SHA-1\\) or 64 \\(SHA-256\\)"):
        validate("abc", "hash")
    with pytest.raises(IOCValidationError, match="http:// or https://"):
        validate("example.com/path", "url")
