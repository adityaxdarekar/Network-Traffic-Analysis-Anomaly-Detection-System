"""VirusTotal client against a mocked HTTP session (no network, no real key)."""
import logging

import pytest
import requests

from conftest import FAKE_KEY, FakeResponse, FakeSession, sample
from modules.ioc_validator import validate
from modules.settings import mask_key, redact, remember_key_for_redaction, setup_logging
from modules.virustotal_client import (AuthError, InvalidResponseError, NetworkError, NotAvailableOffline,
                                       OfflineClient, QuotaError, RateLimiter, RateLimitError, VirusTotalClient,
                                       VTError, endpoint_for, url_identifier)


class Clock:
    def __init__(self, t=1_800_000_000.0):
        self.t, self.slept = t, []

    def __call__(self):
        return self.t

    def sleep(self, s):
        self.slept.append(s)
        self.t += s


def client(cfg, db, *responses, clock=None):
    clock = clock or Clock()
    lim = RateLimiter(cfg["virustotal"]["requests_per_minute"], cfg["virustotal"]["requests_per_day"],
                      clock=clock, sleep=clock.sleep)
    return VirusTotalClient(FAKE_KEY, cfg, cache=db, session=FakeSession(*responses), limiter=lim,
                            sleep=clock.sleep), clock


def err(code, msg="x"):
    return {"error": {"code": code, "message": msg}}


def test_url_identifier_and_endpoints():
    assert url_identifier("http://www.virustotal.com/") == "aHR0cDovL3d3dy52aXJ1c3RvdGFsLmNvbS8"
    assert "=" not in url_identifier("https://example.com/a")
    assert endpoint_for(validate("8.8.8.8")) == "/ip_addresses/8.8.8.8"
    assert endpoint_for(validate("example.com")) == "/domains/example.com"
    assert endpoint_for(validate("a" * 64)) == "/files/" + "a" * 64
    assert endpoint_for(validate("https://example.com/")).startswith("/urls/aHR0cHM6Ly9leGFtcGxlLmNvbS8")


def test_successful_lookup_sends_key_header_and_timeout(cfg, db):
    c, _ = client(cfg, db, FakeResponse(200, sample("ip_198.51.100.23.json")))
    r = c.get_report(validate("198.51.100.23"))
    call = c.http.calls[0]
    assert call["url"] == "https://www.virustotal.com/api/v3/ip_addresses/198.51.100.23"
    assert call["headers"]["x-apikey"] == FAKE_KEY and call["timeout"] == 20
    assert r["found"] and r["source"] == "virustotal-live"
    assert db.api_calls_today() == 1


def test_not_found_is_a_result_not_an_error(cfg, db):
    c, _ = client(cfg, db, FakeResponse(404, err("NotFoundError", "not found")))
    r = c.get_report(validate("unknown.example"))
    assert r["found"] is False


@pytest.mark.parametrize("status,code,exc", [
    (401, "WrongCredentialsError", AuthError), (401, "AuthenticationRequiredError", AuthError),
    (403, "ForbiddenError", VTError), (400, "InvalidArgumentError", VTError),
    (429, "QuotaExceededError", QuotaError), (503, "TransientError", VTError),
])
def test_api_errors_raise_friendly_errors(cfg, db, status, code, exc):
    c, _ = client(cfg, db, FakeResponse(status, err(code)))
    with pytest.raises(exc) as e:
        c.get_report(validate("example.com"))
    assert e.value.code == code and FAKE_KEY not in str(e.value)


def test_too_many_requests_waits_then_retries_once(cfg, db):
    c, clock = client(cfg, db, FakeResponse(429, err("TooManyRequestsError")),
                      FakeResponse(200, sample("domain_clean-site.example.json")))
    assert c.get_report(validate("clean-site.example"))["found"]
    assert 60 in clock.slept
    c2, _ = client(cfg, db, FakeResponse(429, err("TooManyRequestsError")),
                   FakeResponse(429, err("TooManyRequestsError")))
    with pytest.raises(RateLimitError):
        c2.get_report(validate("clean-site.example"), use_cache=False)


def test_quota_exceeded_is_not_retried(cfg, db):
    c, clock = client(cfg, db, FakeResponse(429, err("QuotaExceededError")))
    with pytest.raises(QuotaError):
        c.get_report(validate("example.com"))
    assert len(c.http.calls) == 1 and 60 not in clock.slept


def test_network_and_response_problems(cfg, db):
    for exc in (requests.exceptions.Timeout("t"), requests.exceptions.ConnectionError("c")):
        c, _ = client(cfg, db, exc)
        with pytest.raises(NetworkError):
            c.get_report(validate("example.com"), use_cache=False)
    c, _ = client(cfg, db, FakeResponse(200, None, raw=b"<html>proxy error</html>"))
    with pytest.raises(InvalidResponseError):
        c.get_report(validate("example.com"), use_cache=False)
    c, _ = client(cfg, db, FakeResponse(200, {"unexpected": True}))
    with pytest.raises(InvalidResponseError):
        c.get_report(validate("example.com"), use_cache=False)


def test_cache_avoids_repeat_calls(cfg, db):
    c, _ = client(cfg, db, FakeResponse(200, sample("domain_clean-site.example.json")),
                  FakeResponse(200, sample("domain_clean-site.example.json")))
    c.get_report(validate("clean-site.example"))
    second = c.get_report(validate("clean-site.example"))
    assert second["source"] == "virustotal-cache" and len(c.http.calls) == 1
    c.get_report(validate("clean-site.example"), use_cache=False)       # explicit refresh
    assert len(c.http.calls) == 2


def test_rate_limiter_window_and_daily_limit():
    clock = Clock()
    lim = RateLimiter(4, 6, clock=clock, sleep=clock.sleep)
    for _ in range(4):
        lim.acquire()
    assert clock.slept == []
    waits = []
    lim.acquire(on_wait=waits.append)                   # 5th call in the same minute must wait
    assert waits and 59 < waits[0] <= 60.1
    lim.acquire()
    with pytest.raises(QuotaError, match="daily limit"):
        lim.acquire()
    clock.t += 86400                                    # next UTC day resets the counter
    lim.acquire()


def test_no_key_and_key_never_exposed(cfg, db, tmp_path):
    with pytest.raises(AuthError, match="No VirusTotal API key"):
        VirusTotalClient("", cfg)
    c, _ = client(cfg, db, FakeResponse(200, sample("ip_192.0.2.10.json")))
    assert FAKE_KEY not in repr(c)
    assert mask_key(FAKE_KEY) == "********cdef" and FAKE_KEY not in mask_key(FAKE_KEY)
    log_path = tmp_path / "keylog.log"
    logger = setup_logging(log_path)
    remember_key_for_redaction(FAKE_KEY)
    logger.info("debug dump headers={'x-apikey': '%s'} key=%s", FAKE_KEY, FAKE_KEY)
    c.get_report(validate("192.0.2.10"))
    for h in logger.handlers:
        h.flush()
    text = log_path.read_text()
    assert FAKE_KEY not in text and "[REDACTED]" in text
    assert redact(f"x-apikey: {FAKE_KEY}", None) == "x-apikey: [REDACTED]"


def test_offline_client(cfg):
    off = OfflineClient(cfg.path("offline_samples"))
    r = off.get_report(validate("198.51.100.23"))
    assert r["found"] and r["source"] == "offline-sample"
    assert "OFFLINE SAMPLE" in r["response"]["x_offline_sample"]
    assert off.get_report(validate("unknown-host.example"))["found"] is False
    with pytest.raises(NotAvailableOffline):           # never invents data for real indicators
        off.get_report(validate("8.8.8.8"))
