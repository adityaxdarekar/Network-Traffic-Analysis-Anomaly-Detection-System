import csv
import io
import json

import pytest

import main as cli
from conftest import FAKE_KEY, ROOT, FakeResponse, FakeSession, sample
from modules.batch_analyzer import BatchError, parse_csv, run_batch
from modules.history_manager import HistoryManager, Investigator, make_client
from modules.report_generator import (build_report_data, save_batch_reports, save_investigation_reports, to_csv,
                                      to_html, to_json)
from modules.settings import remember_key_for_redaction
from modules.virustotal_client import RateLimiter, VirusTotalClient


def offline(cfg, db):
    return Investigator(cfg, db, make_client(cfg, db, offline=True))


def test_parse_csv_validation():
    rows = parse_csv("indicator,type\n8.8.8.8,ip\n\nexample.com,\n")
    assert [r["indicator"] for r in rows] == ["8.8.8.8", "example.com"] and rows[1]["row"] == 4
    for bad, msg in (("value\n1.1.1.1", "indicator"), ("indicator\n", "no indicators"),
                     ("indicator\n" + "1.1.1.1\n" * 5, "limit")):
        with pytest.raises(BatchError, match=msg):
            parse_csv(bad, max_rows=3)
    with pytest.raises(BatchError, match="UTF-8"):
        parse_csv(b"\xff\xfe\x00bad")


def test_batch_offline_sample_csv(cfg, db):
    rows = parse_csv((ROOT / "data" / "sample_iocs.csv").read_bytes())
    res = run_batch(offline(cfg, db), rows, "sample_iocs.csv")
    st = res.summary()["status"]
    assert st == {"NO_OFFLINE_SAMPLE": 4, "OK": 6, "NOT_FOUND": 2, "DUPLICATE": 1, "INVALID": 2}
    risks = {r.indicator: r.risk for r in res.rows if r.risk}
    assert risks["198.51.100.23"] == "HIGH" and risks["http://phishing-test.example/login"] == "CRITICAL"
    assert risks["192.0.2.10"] == "NO_DETECTIONS" and risks["unknown-host.example"] == "NOT_FOUND"
    out = list(csv.DictReader(io.StringIO(res.to_csv())))
    assert len(out) == 15 and json.loads(res.to_json())["summary"]["offline_samples"] is True
    assert db.batches()[0]["total"] == 15


def test_batch_stops_cleanly_on_quota(cfg, db):
    clock_t = [1_800_000_000.0]
    lim = RateLimiter(100, 100, clock=lambda: clock_t[0], sleep=lambda s: None)
    sess = FakeSession(FakeResponse(200, sample("ip_192.0.2.10.json")),
                       FakeResponse(429, {"error": {"code": "QuotaExceededError", "message": "q"}}))
    client = VirusTotalClient(FAKE_KEY, cfg, cache=db, session=sess, limiter=lim)
    res = run_batch(Investigator(cfg, db, client),
                    parse_csv("indicator\n192.0.2.10\n192.0.2.11\n192.0.2.12\n"))
    assert [r.status for r in res.rows] == ["OK", "SKIPPED", "SKIPPED"]
    assert "quota" in res.stopped_reason.lower() and len(sess.calls) == 2


def test_history_filters_compare_stats(cfg, db):
    inv = offline(cfg, db)
    for v in ("198.51.100.23", "malware-test.example", "198.51.100.23", "192.0.2.10"):
        inv.investigate(v)
    hm = HistoryManager(db)
    assert len(hm.list(ioc_type="ip")) == 3 and len(hm.list(search="malware")) == 1
    assert len(hm.list(risk="HIGH")) == 2
    with pytest.raises(ValueError):
        hm.list(risk="SEVERE")
    comp = hm.compare("198.51.100.23")
    assert len(comp) == 2 and comp[1]["change"] == 0
    s = hm.stats()
    assert s["total_iocs"] == 3 and s["total_investigations"] == 4
    assert s["by_type"]["ip"] == 2 and s["by_risk"]["MEDIUM"] == 1 and s["offline_samples_included"]


def test_notes_and_status(cfg, db):
    res = offline(cfg, db).investigate("198.51.100.23")
    db.add_note(res.id, "alice", "Seen in proxy logs")
    db.update_status(res.id, "FURTHER_INVESTIGATION", "alice", "asked network team", "pending flow data")
    inv = db.investigation(res.id)
    assert inv["status"] == "FURTHER_INVESTIGATION" and inv["conclusion"] == "pending flow data"
    assert [n["new_status"] for n in db.notes(res.id)] == ["COMPLETED", "FURTHER_INVESTIGATION"]
    with pytest.raises(ValueError):
        db.update_status(res.id, "BLOCKED", "alice")
    with pytest.raises(ValueError):
        db.add_note(res.id, "alice", "  ")


def test_reports_contain_required_sections_and_never_the_key(cfg, db):
    remember_key_for_redaction(FAKE_KEY)
    res = offline(cfg, db).investigate("http://phishing-test.example/login")
    db.add_note(res.id, "bob", f"<script>alert(1)</script> accidentally pasted {FAKE_KEY}")
    data = build_report_data(db.investigation(res.id), db.notes(res.id))
    for k in ("title", "investigation_id", "investigation_timestamp", "ioc", "ioc_type", "detection_statistics",
              "vendor_results", "risk", "metadata", "analyst_assessment", "recommended_actions", "limitations"):
        assert data[k] not in (None, "", [])
    paths = save_investigation_reports(data, cfg.path("reports"))
    assert set(paths) == {"html", "pdf", "json", "csv"}
    from pypdf import PdfReader
    pdf_text = "".join(p.extract_text() for p in PdfReader(str(paths["pdf"])).pages)
    for text in (paths["html"].read_text(), paths["json"].read_text(), paths["csv"].read_text(), pdf_text):
        assert FAKE_KEY not in text                                     # key redacted everywhere
    for text in (paths["html"].read_text(), paths["json"].read_text(), pdf_text):
        assert "OFFLINE SAMPLE" in text                                 # sample data always labelled
    assert "offline-sample" in paths["csv"].read_text()
    page = to_html(data)
    assert "<script>alert(1)</script>" not in page and "&lt;script&gt;" in page
    assert "NOT a live VirusTotal result" in page and "24/94" in page
    assert "not official VirusTotal ratings" in page
    rows = list(csv.DictReader(io.StringIO(to_csv(data))))
    assert len(rows) == 94 and rows[0]["risk"] == "CRITICAL"
    assert FAKE_KEY not in to_json(data)
    remember_key_for_redaction(None)


def test_batch_report_files(cfg, db):
    res = run_batch(offline(cfg, db), parse_csv("indicator\n198.51.100.23\n8.8.8.8\n"))
    paths = save_batch_reports(res, cfg.path("reports"))
    html = paths["html"].read_text()
    assert "Consolidated IOC Batch Report" in html and "OFFLINE SAMPLE" in html and "NO_OFFLINE_SAMPLE" in html


def test_cli_flow(cfg, tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("VIRUSTOTAL_API_KEY", raising=False)
    monkeypatch.setattr("modules.settings.BASE_DIR", tmp_path)            # no .env picked up
    base = ["--config", str(tmp_path / "config.json"), "--db", str(tmp_path / "cli.db")]
    assert cli.main(base + ["check-key"]) == 1
    assert cli.main(base + ["investigate", "8.8.8.8"]) == 1               # no key, no fake result
    assert cli.main(base + ["investigate", "198.51.100.23", "--offline", "--report", "html,json"]) == 0
    assert cli.main(base + ["investigate", "999.1.1.1", "--offline"]) == 1
    assert cli.main(base + ["batch", str(ROOT / "data" / "sample_iocs.csv"), "--offline", "--report"]) == 0
    assert cli.main(base + ["status", "1", "SUSPICIOUS", "--note", "demo", "--analyst", "eve"]) == 0
    assert cli.main(base + ["note", "1", "follow-up"]) == 0
    assert cli.main(base + ["history", "--type", "ip"]) == 0
    assert cli.main(base + ["compare", "198.51.100.23"]) == 0
    assert cli.main(base + ["stats"]) == 0
    assert cli.main(base + ["report", "1", "--formats", "pdf,csv"]) == 0
    assert cli.main(base + ["show", "99"]) == 1
    out = capsys.readouterr().out
    assert "not configured" in out and "OFFLINE SAMPLE" in out and "No offline sample exists for 8.8.8.8" in out
    assert "Invalid indicator" in out and "SUSPICIOUS" in out and "PDF report" in out
    monkeypatch.setenv("VIRUSTOTAL_API_KEY", FAKE_KEY)
    assert cli.main(base + ["check-key"]) == 0
    assert FAKE_KEY not in capsys.readouterr().out
