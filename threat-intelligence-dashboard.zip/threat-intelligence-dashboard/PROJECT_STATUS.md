# Project status - verified vs. still to verify

## Build environment
* The build sandbox had **no internet access** and **no VirusTotal API key**, so no live API call was made.
* Streamlit and Plotly were not installed. requests, python-dotenv, pandas, reportlab and pypdf were.
* The API details were checked against VirusTotal's documentation on 2026-11-07:
  * the error codes and their JSON format;
  * the public quota of 4 requests per minute and 500 per day.

## ✅ Verified here
| Item | Evidence |
|---|---|
| 68 automated tests pass | `python3 -m pytest -q` |
| IOC validation: IPv4/IPv6, domains (IDN), URLs, MD5/SHA-1/SHA-256, re-fanging, rejection before any call | `test_validator.py` |
| Client builds the documented endpoints, sends the `x-apikey` header and timeout, and computes the URL identifier (base64url, no padding) | `test_virustotal_client.py`, mocked HTTP |
| Error handling: 401/403/400/503, 404 shown as "no report", 429 TooManyRequests (wait and retry once), QuotaExceeded (no retry), timeout, connection error, non-JSON body, missing `data` | tests |
| Rate limiter: per-minute window, daily limit, reset at the next UTC day | tests with a fake clock |
| 24-hour cache avoids repeat calls; refresh bypasses it | tests |
| **API key never exposed**: masked display, `repr`, error messages, log file (redaction filter), HTML/PDF/JSON/CSV reports (a key planted in a note is redacted) | tests |
| Zero vs "not available" kept apart; zero detections never called safe; no report means unknown | tests |
| Risk thresholds at every boundary; confidence; stale analysis | tests |
| Batch: CSV validation, true line numbers, duplicates, invalid rows, clean stop when quota is exhausted | tests and `sample_output/` |
| History search, filters, comparison, stats; notes and status audit trail | tests |
| Reports contain all 12 required items; HTML escaping; offline banner | tests, `sample_output/`, `screenshots/` |
| Dashboard code paths (all 10 sections, every IOC type) | `test_app_smoke.py` with a **Streamlit stand-in** |
| Offline mode never fabricates results for real indicators | test (`8.8.8.8` → "No offline sample") |

## ⚠️ Not verified - do this with your own key
| Item | How |
|---|---|
| **Live VirusTotal responses** (field names in current responses, real detection data) | `python3 main.py investigate 8.8.8.8`, then the demo guide Tests 1–5 |
| Real 429 behaviour and quota counters on your account | run the batch demo; watch the waits |
| **Real Streamlit UI and Plotly charts** | `streamlit run app.py` and click through all 10 sections |
| Domain resolutions relationship | set `fetch_domain_resolutions: true` and look up a domain |

All values in `sample_output/` and `screenshots/` are **synthetic offline samples**, clearly labelled. They are not VirusTotal results.
