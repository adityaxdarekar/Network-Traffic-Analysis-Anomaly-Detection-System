"""
Builds the OFFLINE DEMONSTRATION samples in this folder.

Every file is SYNTHETIC: it copies the *shape* of VirusTotal API v3 responses so
the dashboard can be demonstrated without an API key, but the values are made up.
  * Indicators are documentation-only: TEST-NET IPs (RFC 5737), ".example"
    domains (RFC 2606), documentation ASNs (RFC 5398).
  * Engine names are generic ("SampleEngine07"), not real antivirus vendors.
  * Hashes are hashes of strings, not of real malware.
The app labels every offline result "OFFLINE SAMPLE - not live VirusTotal data".
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).parent
NOTE = "OFFLINE SAMPLE - synthetic data in VirusTotal API v3 format, NOT a live VirusTotal result"
T_ANALYSIS = 1793620800   # 2026-11-02 12:00 UTC (fixed so output is reproducible)
T_OLD = 1730000000


def results(mal, sus, harmless, undetected, label="Sample.Generic"):
    out, n = {}, 0
    for cat, count in (("malicious", mal), ("suspicious", sus), ("harmless", harmless), ("undetected", undetected)):
        for _ in range(count):
            n += 1
            name = f"SampleEngine{n:02d}"
            out[name] = {"engine_name": name, "category": cat, "method": "blacklist",
                         "result": label if cat in ("malicious", "suspicious") else ("clean" if cat == "harmless"
                                                                                      else "unrated")}
    return out


def stats(mal, sus, harmless, undetected):
    return {"malicious": mal, "suspicious": sus, "harmless": harmless, "undetected": undetected, "timeout": 0}


def obj(kind, oid, attrs):
    return {"x_offline_sample": NOTE,
            "data": {"id": oid, "type": kind, "links": {"self": f"https://www.virustotal.com/api/v3/{kind}s/{oid}"},
                     "attributes": attrs}}


def build():
    files = {}
    files["ip:198.51.100.23"] = ("ip_198.51.100.23.json", obj("ip_address", "198.51.100.23", {
        "country": "ZZ", "asn": 64500, "as_owner": "EXAMPLE-NET (sample)", "network": "198.51.100.0/24",
        "regional_internet_registry": "SAMPLE-RIR", "reputation": -25,
        "total_votes": {"harmless": 0, "malicious": 3}, "tags": ["sample"],
        "last_analysis_date": T_ANALYSIS, "last_analysis_stats": stats(12, 2, 55, 25),
        "last_analysis_results": results(12, 2, 55, 25, "malware (sample)")}))
    files["ip:192.0.2.10"] = ("ip_192.0.2.10.json", obj("ip_address", "192.0.2.10", {
        "country": "ZZ", "asn": 64501, "as_owner": "DOC-EXAMPLE (sample)", "network": "192.0.2.0/24",
        "reputation": 0, "total_votes": {"harmless": 0, "malicious": 0},
        "last_analysis_date": T_ANALYSIS, "last_analysis_stats": stats(0, 0, 60, 34),
        "last_analysis_results": results(0, 0, 60, 34)}))
    files["domain:malware-test.example"] = ("domain_malware-test.example.json", obj("domain", "malware-test.example", {
        "registrar": "Example Registrar (sample)", "creation_date": 1790000000, "reputation": -8,
        "total_votes": {"harmless": 1, "malicious": 2}, "categories": {"SampleEngine01": "malware sites"},
        "last_dns_records": [{"type": "A", "value": "198.51.100.23", "ttl": 300},
                             {"type": "NS", "value": "ns1.example", "ttl": 3600}],
        "last_analysis_date": T_ANALYSIS, "last_analysis_stats": stats(5, 1, 60, 28),
        "last_analysis_results": results(5, 1, 60, 28, "malicious site (sample)")}))
    files["domain:clean-site.example"] = ("domain_clean-site.example.json", obj("domain", "clean-site.example", {
        "registrar": "Example Registrar (sample)", "reputation": 0, "total_votes": {"harmless": 0, "malicious": 0},
        "last_dns_records": [{"type": "A", "value": "192.0.2.10", "ttl": 300}],
        "last_analysis_date": T_OLD, "last_analysis_stats": stats(0, 0, 65, 29),
        "last_analysis_results": results(0, 0, 65, 29)}))
    files["domain:unknown-host.example"] = ("domain_unknown-host.example.json", {
        "x_offline_sample": NOTE,
        "error": {"code": "NotFoundError", "message": "Domain \"unknown-host.example\" not found (sample)"}})
    url = "http://phishing-test.example/login"
    files[f"url:{url}"] = ("url_phishing-test.example.json", obj("url", hashlib.sha256(url.encode()).hexdigest(), {
        "url": url, "last_final_url": url, "title": "Sign in (sample page)", "last_http_response_code": 200,
        "reputation": -40, "total_votes": {"harmless": 0, "malicious": 5}, "categories": {"SampleEngine02": "phishing"},
        "tags": ["sample"], "last_analysis_date": T_ANALYSIS, "last_analysis_stats": stats(24, 3, 50, 17),
        "last_analysis_results": results(24, 3, 50, 17, "phishing (sample)")}))
    fake = b"fictional-malware-sample-for-offline-demo"
    sha256, sha1, md5 = (hashlib.sha256(fake).hexdigest(), hashlib.sha1(fake).hexdigest(), hashlib.md5(fake).hexdigest())
    file_obj = obj("file", sha256, {
        "md5": md5, "sha1": sha1, "sha256": sha256, "meaningful_name": "invoice_update.exe (sample)",
        "names": ["invoice_update.exe (sample)"], "type_description": "Win32 EXE", "type_tag": "peexe",
        "size": 245760, "reputation": -60, "total_votes": {"harmless": 0, "malicious": 4},
        "popular_threat_classification": {"suggested_threat_label": "trojan.samplefamily/fictional",
                                          "popular_threat_category": [{"value": "trojan", "count": 20}],
                                          "popular_threat_name": [{"value": "samplefamily", "count": 12}]},
        "last_analysis_date": T_ANALYSIS, "last_analysis_stats": stats(31, 0, 0, 40),
        "last_analysis_results": results(31, 0, 0, 40, "Trojan.SampleFamily (sample)")})
    for h in (sha256, sha1, md5):
        files[f"hash:{h}"] = ("file_fictional_sample.json", file_obj)
    harmless = (HERE.parent / "test_files" / "harmless_test_file.txt").read_bytes()
    hh = hashlib.sha256(harmless).hexdigest()
    files[f"hash:{hh}"] = ("file_harmless_test_file.json", {
        "x_offline_sample": NOTE,
        "error": {"code": "NotFoundError", "message": f"File \"{hh}\" not found (sample)"}})

    index = {}
    for key, (name, content) in files.items():
        (HERE / name).write_text(json.dumps(content, indent=1), encoding="utf-8")
        index[key] = name
    (HERE / "index.json").write_text(json.dumps(index, indent=1), encoding="utf-8")
    print(f"wrote {len(set(n for n, _ in files.values()))} sample files, {len(index)} indicators")
    print("fictional sample hashes:", sha256, sha1, md5)
    print("harmless test file sha256:", hh)


if __name__ == "__main__":
    build()
