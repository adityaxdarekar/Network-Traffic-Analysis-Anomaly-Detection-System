"""
ioc_validator.py - validate and normalise indicators before any API call.

Types:  ip (ipv4/ipv6), domain, url, hash (md5/sha1/sha256).
Invalid input never reaches VirusTotal. Defanged forms (hxxp, [.], (.)) are
re-fanged first so analysts can paste indicators from reports.
"""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from urllib.parse import urlsplit

TYPES = ("ip", "domain", "url", "hash")
HASH_LEN = {32: "md5", 40: "sha1", 64: "sha256"}
_LABEL = re.compile(r"^(?!-)[a-z0-9-]{1,63}(?<!-)$")
_TLD = re.compile(r"^(?:[a-z]{2,63}|xn--[a-z0-9-]{1,59})$")


class IOCValidationError(ValueError):
    pass


@dataclass(frozen=True)
class IOC:
    value: str          # normalised value used for the lookup
    type: str           # ip / domain / url / hash
    subtype: str        # ipv4 / ipv6 / domain / url / md5 / sha1 / sha256
    original: str = ""

    @property
    def label(self) -> str:
        return {"ip": "IP address", "domain": "Domain", "url": "URL", "hash": "File hash"}[self.type]


def refang(text: str) -> str:
    t = (text or "").strip().strip('"').strip("'")
    t = re.sub(r"^hxxp", "http", t, flags=re.I)
    return t.replace("[.]", ".").replace("(.)", ".").replace("[:]", ":").replace("[dot]", ".")


def _ip(value: str):
    try:
        ip = ipaddress.ip_address(value.strip("[]"))
    except ValueError:
        return None
    return IOC(str(ip), "ip", f"ipv{ip.version}")


def _domain(value: str):
    v = value.lower().rstrip(".")
    if len(v) > 253 or "." not in v or any(c in v for c in "/:@ ?#"):
        return None
    labels = v.split(".")
    try:
        v_idna = v.encode("idna").decode("ascii")
    except UnicodeError:
        return None
    labels = v_idna.split(".")
    if not all(_LABEL.match(l) for l in labels) or not _TLD.match(labels[-1]):
        return None
    if _ip(v) is not None:
        return None
    return IOC(v_idna, "domain", "domain")


def _url(value: str):
    v = value.strip()
    if not re.match(r"^https?://", v, re.I):
        return None
    try:
        parts = urlsplit(v)
    except ValueError:
        return None
    host = parts.hostname or ""
    if not host or len(v) > 2048 or any(c.isspace() for c in v):
        return None
    if _ip(host) is None and _domain(host) is None:
        return None
    return IOC(v, "url", "url")


def _hash(value: str):
    v = value.strip().lower()
    if re.fullmatch(r"[0-9a-f]+", v) and len(v) in HASH_LEN:
        return IOC(v, "hash", HASH_LEN[len(v)])
    return None


CHECKS = {"ip": _ip, "domain": _domain, "url": _url, "hash": _hash}


def detect_type(value: str) -> str | None:
    v = refang(value)
    for t in ("url", "hash", "ip", "domain"):
        if CHECKS[t](v) is not None:
            return t
    return None


def validate(value: str, ioc_type: str | None = None) -> IOC:
    """Validate *value* (optionally as a specific type) and return a normalised IOC."""
    raw = value if isinstance(value, str) else ""
    v = refang(raw)
    if not v:
        raise IOCValidationError("empty indicator")
    if len(v) > 2048:
        raise IOCValidationError("indicator is too long")
    t = (ioc_type or "").strip().lower() or None
    aliases = {"ipv4": "ip", "ipv6": "ip", "ip_address": "ip", "file": "hash", "md5": "hash", "sha1": "hash",
               "sha256": "hash", "sha-1": "hash", "sha-256": "hash", "auto": None, "": None}
    t = aliases.get(t, t)
    if t is not None and t not in TYPES:
        raise IOCValidationError(f"unknown indicator type {ioc_type!r}; use ip, domain, url or hash")
    if t is None:
        t = detect_type(v)
        if t is None:
            raise IOCValidationError(f"{raw!r} is not a valid IP address, domain, URL or MD5/SHA-1/SHA-256 hash")
    ioc = CHECKS[t](v)
    if ioc is None:
        hint = {"hash": "a hash must be 32 (MD5), 40 (SHA-1) or 64 (SHA-256) hexadecimal characters",
                "url": "a URL must start with http:// or https:// and contain a valid host",
                "ip": "not a valid IPv4 or IPv6 address", "domain": "not a valid domain name"}[t]
        raise IOCValidationError(f"{raw!r} is not a valid {t}: {hint}")
    return IOC(ioc.value, ioc.type, ioc.subtype, raw)
