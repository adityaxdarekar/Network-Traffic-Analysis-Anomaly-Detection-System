"""
risk_classifier.py - demonstration risk levels from VirusTotal statistics.

Primary signal: number of engines reporting "malicious" (thresholds in
config.json -> risk_thresholds). These are DEMONSTRATION thresholds chosen for
this project, NOT official VirusTotal ratings.

Levels:
  CRITICAL / HIGH / MEDIUM / LOW
  NO_DETECTIONS  - VT has a report but no engine flagged it. This is NOT proof
                   the indicator is safe (new, targeted or unscanned threats
                   often show zero detections).
  NOT_FOUND      - VT has no report at all: unknown, not "clean".
Supporting factors (community reputation, votes, suspicious verdicts, analysis
age) are listed and can raise NO_DETECTIONS to LOW, and set a confidence value
that describes how much intelligence was available.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from modules.ioc_analyzer import IOCAnalysis

LEVELS = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "NO_DETECTIONS", "NOT_FOUND")
LEVEL_LABEL = {"CRITICAL": "Critical", "HIGH": "High", "MEDIUM": "Medium", "LOW": "Low",
               "NO_DETECTIONS": "No detections reported", "NOT_FOUND": "No VirusTotal report"}
LEVEL_ORDER = {lvl: i for i, lvl in enumerate(LEVELS)}

ACTIONS = {
    "CRITICAL": ["Treat as a likely malicious indicator: open an incident ticket and notify the SOC lead.",
                 "Search proxy, DNS, firewall and EDR logs for any contact with this indicator (last 30-90 days).",
                 "Identify and contain affected hosts after analyst confirmation; preserve evidence.",
                 "Propose a block in the relevant control (firewall, proxy, EDR) through change management."],
    "HIGH": ["Prioritise investigation: hunt for the indicator in DNS, proxy, firewall and EDR telemetry.",
             "Review the vendor detection names and related indicators for context.",
             "Consider a block or watch-list entry after analyst review."],
    "MEDIUM": ["Investigate in context: who/what contacted it, when, and whether it was expected.",
               "Add to a watch list and re-check later; detections can change over time."],
    "LOW": ["Few engines flag this indicator - verify with other sources before acting (false positives happen).",
            "Monitor for related activity and re-query later."],
    "NO_DETECTIONS": ["No engine flagged it at the last analysis - this does not prove it is safe.",
                      "Judge it by context (business need, reputation of the owner, first-seen date).",
                      "Re-query later or use additional intelligence sources if suspicion remains."],
    "NOT_FOUND": ["VirusTotal has no report - the indicator is unknown, not clean.",
                  "For files, consider safe sandbox analysis in an approved environment (this tool never uploads).",
                  "Use other intelligence sources and internal telemetry."],
}

IMPLICATIONS = {
    "ip": "Hosts communicating with a malicious IP may be infected (C2, scanning, malware download).",
    "domain": "A malicious domain can host phishing, malware or command-and-control infrastructure.",
    "url": "A malicious URL can deliver phishing pages or malware downloads to users.",
    "hash": "A malicious file hash indicates a known malware sample; hosts holding it may be compromised.",
}


@dataclass
class RiskAssessment:
    level: str
    label: str
    confidence: str
    factors: list = field(default_factory=list)
    summary: str = ""
    implications: str = ""
    actions: list = field(default_factory=list)
    note: str = ("Risk levels use configurable demonstration thresholds; they are not official VirusTotal "
                 "ratings. Zero detections do not prove an indicator is harmless.")

    def to_dict(self) -> dict:
        return asdict(self)


def classify(a: IOCAnalysis, cfg: dict) -> RiskAssessment:
    t, c = cfg["risk_thresholds"], cfg["confidence"]
    factors: list[str] = []
    if not a.found:
        return RiskAssessment("NOT_FOUND", LEVEL_LABEL["NOT_FOUND"], "NONE",
                              ["VirusTotal returned no report for this indicator"],
                              f"VirusTotal has no report for this {a.ioc_type}. Unknown is not the same as safe.",
                              IMPLICATIONS[a.ioc_type], ACTIONS["NOT_FOUND"])
    mal = a.detections
    if mal is None:
        level = "NO_DETECTIONS"
        factors.append("detection statistics not available in the response")
    elif mal >= t["critical"]:
        level = "CRITICAL"
    elif mal >= t["high"]:
        level = "HIGH"
    elif mal >= t["medium"]:
        level = "MEDIUM"
    elif mal >= t["low"]:
        level = "LOW"
    else:
        level = "NO_DETECTIONS"
    if mal is not None:
        factors.append(f"{mal} of {a.total_engines} engines reported malicious")
    if a.suspicious:
        factors.append(f"{a.suspicious} engine(s) reported suspicious")
    if a.reputation is not None:
        factors.append(f"community reputation score {a.reputation}")
    if a.votes:
        factors.append(f"community votes: {a.votes.get('malicious', 0)} malicious / {a.votes.get('harmless', 0)} harmless")
    if level == "NO_DETECTIONS":
        signals = []
        if a.suspicious and t["suspicious_only_is_low"]:
            signals.append("suspicious verdicts")
        if a.reputation is not None and a.reputation <= t["negative_reputation_threshold"]:
            signals.append("negative community reputation")
        if a.votes and a.votes.get("malicious", 0) > a.votes.get("harmless", 0):
            signals.append("more malicious than harmless community votes")
        if signals:
            level = "LOW"
            factors.append("raised to LOW because of " + " and ".join(signals))
    if a.url_characteristics:
        factors.append(f"{len(a.url_characteristics)} local URL warning sign(s) (not VirusTotal data)")

    engines = a.total_engines or 0
    age = a.analysis_age_days
    if age is not None:
        factors.append(f"last analysed {age} day(s) ago")
    if engines >= c["high_min_engines"] and age is not None and age <= c["fresh_days"]:
        confidence = "HIGH"
    elif engines >= c["medium_min_engines"] and (age is None or age <= c["stale_days"]):
        confidence = "MEDIUM"
    else:
        confidence = "LOW"
        if age is not None and age > c["stale_days"]:
            factors.append("analysis is old - re-analysis on VirusTotal may change the result")

    label = LEVEL_LABEL[level]
    if level == "NO_DETECTIONS":
        summary = (f"No security engine flagged this {a.ioc_type} at the last analysis "
                   f"({a.detection_ratio}). This is not proof that it is harmless.")
    else:
        summary = (f"{label} risk: {a.detection_ratio} engines flag this {a.ioc_type} as malicious"
                   + (f"; detection names include {', '.join(a.detection_names[:3])}" if a.detection_names else "")
                   + ".")
    if a.is_sample:
        summary = "[OFFLINE SAMPLE] " + summary
    return RiskAssessment(level, label, confidence, factors, summary, IMPLICATIONS[a.ioc_type], ACTIONS[level])
