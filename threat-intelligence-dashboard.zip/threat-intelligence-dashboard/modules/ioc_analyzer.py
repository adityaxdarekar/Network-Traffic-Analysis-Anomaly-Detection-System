"""
ioc_analyzer.py - turn a VirusTotal v3 JSON response into a structured analysis.

Rule: a field that is missing from the response is None ("Not available"); a
field the response reports as 0 stays 0. The two are never confused.

Also runs local, offline URL heuristics (IP host, '@', punycode, many
subdomains, login keywords ...) - clearly labelled as local checks, not VT data.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from urllib.parse import urlsplit

from modules.ioc_validator import IOC

UNAVAILABLE = "Not available"
VT_GUI = "https://www.virustotal.com/gui"


def fmt(value: Any) -> str:
    """Display helper: None -> 'Not available'; 0 stays '0'."""
    if value is None or value == "" or value == [] or value == {}:
        return UNAVAILABLE
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value)
    if isinstance(value, dict):
        return ", ".join(f"{k}: {v}" for k, v in value.items())
    return str(value)


def ts_to_iso(ts) -> Optional[str]:
    if isinstance(ts, (int, float)) and ts > 0:
        return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    return None


@dataclass
class IOCAnalysis:
    ioc: str
    ioc_type: str
    ioc_subtype: str
    found: bool
    source: str
    fetched_at: str
    permalink: Optional[str] = None
    stats: Optional[dict] = None
    detections: Optional[int] = None          # engines with category "malicious"
    suspicious: Optional[int] = None
    total_engines: Optional[int] = None
    reputation: Optional[int] = None
    votes: Optional[dict] = None
    last_analysis_date: Optional[str] = None
    analysis_age_days: Optional[int] = None
    vendors: list = field(default_factory=list)          # every engine result
    detection_names: list = field(default_factory=list)  # distinct names from flagging engines
    metadata: dict = field(default_factory=dict)         # ordered label -> value (None = unavailable)
    related: list = field(default_factory=list)          # [{"type", "value", "relation"}]
    url_characteristics: list = field(default_factory=list)
    not_found_message: str = ""

    @property
    def detection_ratio(self) -> str:
        if self.detections is None or self.total_engines is None:
            return UNAVAILABLE
        return f"{self.detections}/{self.total_engines}"

    @property
    def flagged_vendors(self) -> list:
        return [v for v in self.vendors if v["category"] in ("malicious", "suspicious")]

    @property
    def is_sample(self) -> bool:
        return self.source == "offline-sample"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["detection_ratio"] = self.detection_ratio
        d["flagged_vendor_count"] = len(self.flagged_vendors)
        return d


def url_characteristics(url: str) -> list[str]:
    """Local heuristics - indicators worth a look, not verdicts."""
    out = []
    try:
        p = urlsplit(url)
    except ValueError:
        return ["URL could not be parsed"]
    host = (p.hostname or "").lower()
    if p.scheme == "http":
        out.append("uses unencrypted HTTP")
    if re.fullmatch(r"[0-9.]+|[0-9a-f:]+", host):
        out.append("host is a raw IP address")
    if "@" in p.netloc:
        out.append("contains '@' in the authority part (can hide the real host)")
    if host.startswith("xn--") or ".xn--" in host:
        out.append("internationalised (punycode) host name - check for look-alike characters")
    if host.count(".") >= 4:
        out.append(f"many subdomain levels ({host.count('.') + 1})")
    if p.port and p.port not in (80, 443):
        out.append(f"non-standard port {p.port}")
    if len(url) > 120:
        out.append(f"very long URL ({len(url)} characters)")
    words = [w for w in ("login", "signin", "verify", "account", "update", "secure", "password", "wallet", "invoice")
             if w in url.lower()]
    if words:
        out.append("contains credential/lure keywords: " + ", ".join(words))
    if re.search(r"\.(exe|scr|js|vbs|hta|iso|zip|rar)(\?|$)", p.path.lower()):
        out.append("path ends with an executable or archive extension")
    return out


def _gui_link(ioc: IOC, data_id: Optional[str]) -> str:
    kind = {"ip": "ip-address", "domain": "domain", "url": "url", "hash": "file"}[ioc.type]
    ident = data_id or (hashlib.sha256(ioc.value.encode()).hexdigest() if ioc.type == "url" else ioc.value)
    return f"{VT_GUI}/{kind}/{ident}"


def analyze(ioc: IOC, result: dict, now: Optional[datetime] = None) -> IOCAnalysis:
    """result is what a client's get_report() returns."""
    now = now or datetime.now(timezone.utc)
    a = IOCAnalysis(ioc=ioc.value, ioc_type=ioc.type, ioc_subtype=ioc.subtype, found=bool(result.get("found")),
                    source=result.get("source", ""), fetched_at=result.get("fetched_at", ""))
    if ioc.type == "url":
        a.url_characteristics = url_characteristics(ioc.value)
    if not a.found:
        err = (result.get("response") or {}).get("error", {})
        a.not_found_message = err.get("message") or "VirusTotal has no report for this indicator."
        a.permalink = _gui_link(ioc, None)
        return a
    data = result["response"]["data"]
    attrs = data.get("attributes", {}) or {}
    a.permalink = _gui_link(ioc, data.get("id"))

    st = attrs.get("last_analysis_stats")
    if isinstance(st, dict):
        a.stats = {k: int(v) for k, v in st.items() if isinstance(v, (int, float))}
        a.detections = a.stats.get("malicious")
        a.suspicious = a.stats.get("suspicious")
        a.total_engines = sum(a.stats.values())
    if isinstance(attrs.get("reputation"), (int, float)):
        a.reputation = int(attrs["reputation"])
    if isinstance(attrs.get("total_votes"), dict):
        a.votes = attrs["total_votes"]
    a.last_analysis_date = ts_to_iso(attrs.get("last_analysis_date"))
    if a.last_analysis_date:
        a.analysis_age_days = max(0, (now - datetime.fromtimestamp(attrs["last_analysis_date"], timezone.utc)).days)

    res = attrs.get("last_analysis_results")
    if isinstance(res, dict):
        order = {"malicious": 0, "suspicious": 1, "harmless": 2, "undetected": 3}
        for name, r in res.items():
            if isinstance(r, dict):
                a.vendors.append({"engine": r.get("engine_name") or name, "category": r.get("category", "unknown"),
                                  "result": r.get("result"), "method": r.get("method")})
        a.vendors.sort(key=lambda v: (order.get(v["category"], 9), v["engine"].lower()))
        a.detection_names = sorted({v["result"] for v in a.flagged_vendors if v["result"]})

    m: dict = {}
    if ioc.type == "ip":
        m["IP version"] = ioc.subtype.upper()
        m["Country"] = attrs.get("country")
        m["ASN"] = attrs.get("asn")
        m["AS owner"] = attrs.get("as_owner")
        m["Network"] = attrs.get("network")
        m["Regional Internet Registry"] = attrs.get("regional_internet_registry")
    elif ioc.type == "domain":
        m["Registrar"] = attrs.get("registrar")
        m["Creation date"] = ts_to_iso(attrs.get("creation_date"))
        dns = attrs.get("last_dns_records")
        m["DNS records"] = [f"{r.get('type')} {r.get('value')}" for r in dns] if isinstance(dns, list) else None
        m["Categories"] = sorted(set((attrs.get("categories") or {}).values())) or None
        if isinstance(dns, list):
            for r in dns:
                if r.get("type") in ("A", "AAAA") and r.get("value"):
                    a.related.append({"type": "ip", "value": r["value"], "relation": f"DNS {r['type']} record"})
        rel = (result.get("related") or {}).get("resolutions", {})
        for item in rel.get("data", []) if isinstance(rel, dict) else []:
            ip = (item.get("attributes") or {}).get("ip_address")
            if ip and not any(x["value"] == ip for x in a.related):
                a.related.append({"type": "ip", "value": ip, "relation": "historical resolution"})
    elif ioc.type == "url":
        m["URL"] = attrs.get("url")
        m["Final URL"] = attrs.get("last_final_url")
        m["Page title"] = attrs.get("title")
        m["HTTP response code"] = attrs.get("last_http_response_code")
        m["Categories"] = sorted(set((attrs.get("categories") or {}).values())) or None
        final = attrs.get("last_final_url")
        if final and final != attrs.get("url"):
            a.related.append({"type": "url", "value": final, "relation": "final URL after redirects"})
    elif ioc.type == "hash":
        m["File name"] = attrs.get("meaningful_name") or ((attrs.get("names") or [None])[0])
        m["File type"] = attrs.get("type_description")
        m["File size (bytes)"] = attrs.get("size")
        m["MD5"] = attrs.get("md5")
        m["SHA-1"] = attrs.get("sha1")
        m["SHA-256"] = attrs.get("sha256")
        ptc = attrs.get("popular_threat_classification") or {}
        m["Malware classification"] = ptc.get("suggested_threat_label")
        fam = [x.get("value") for x in ptc.get("popular_threat_name", []) if isinstance(x, dict)]
        m["Malware family names"] = fam or None
        cats = [x.get("value") for x in ptc.get("popular_threat_category", []) if isinstance(x, dict)]
        m["Threat categories"] = cats or None
    m["Tags"] = attrs.get("tags") or None
    a.metadata = m
    return a
