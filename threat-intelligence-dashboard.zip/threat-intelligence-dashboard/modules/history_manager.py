"""
history_manager.py - run an investigation end to end and query history.

Investigator.investigate():  validate -> VirusTotal (or offline sample) ->
analyse -> classify -> save to SQLite.  Nothing is blocked or quarantined.

HistoryManager: list/search/filter investigations, compare an IOC's past
results, and compute dashboard statistics.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Optional

from modules.database import Database
from modules.ioc_analyzer import IOCAnalysis, analyze
from modules.ioc_validator import IOC, validate
from modules.risk_classifier import LEVEL_ORDER, LEVELS, RiskAssessment, classify
from modules.settings import load_api_key, remember_key_for_redaction
from modules.virustotal_client import OfflineClient, VirusTotalClient


@dataclass
class InvestigationResult:
    id: Optional[int]
    ioc: IOC
    analysis: IOCAnalysis
    assessment: RiskAssessment


def make_client(cfg, db: Optional[Database], api_key: Optional[str] = None, offline: bool = False, session=None):
    """Live client when a key is available and offline mode is off; otherwise the labelled offline client."""
    if offline:
        return OfflineClient(cfg.path("offline_samples"))
    key = api_key or load_api_key()
    remember_key_for_redaction(key)
    return VirusTotalClient(key, cfg, cache=db, session=session)


class Investigator:
    def __init__(self, cfg, db: Optional[Database], client):
        self.cfg, self.db, self.client = cfg, db, client

    def investigate(self, value: str, ioc_type: Optional[str] = None, refresh: bool = False,
                    batch_id: Optional[int] = None, on_wait=None, save: bool = True) -> InvestigationResult:
        ioc = validate(value, ioc_type)                    # rejects invalid input before any API call
        raw = self.client.get_report(ioc, use_cache=not refresh, on_wait=on_wait)
        analysis = analyze(ioc, raw)
        assessment = classify(analysis, self.cfg)
        inv_id = self.db.add_investigation(analysis, assessment, batch_id) if (save and self.db) else None
        return InvestigationResult(inv_id, ioc, analysis, assessment)


class HistoryManager:
    def __init__(self, db: Database):
        self.db = db

    def list(self, search: str = "", ioc_type: str = "", risk: str = "", status: str = "", limit: int = 200) -> list:
        sql, p = "SELECT id, ioc, ioc_type, created, source, detection_ratio, detections, total_engines, risk, " \
                 "confidence, status, report_path FROM investigations WHERE 1=1", []
        if search:
            sql += " AND ioc LIKE ?"
            p.append(f"%{search.strip()}%")
        if ioc_type:
            sql += " AND ioc_type=?"
            p.append(ioc_type)
        if risk:
            if risk not in LEVELS:
                raise ValueError(f"risk must be one of {', '.join(LEVELS)}")
            sql += " AND risk=?"
            p.append(risk)
        if status:
            sql += " AND status=?"
            p.append(status)
        sql += " ORDER BY id DESC LIMIT ?"
        p.append(int(limit))
        return self.db.rows(sql, tuple(p))

    def compare(self, ioc_value: str) -> list:
        """All investigations of one IOC, oldest first, with the change in detections."""
        try:
            value = validate(ioc_value).value
        except ValueError:
            value = ioc_value.strip()
        rows = self.db.rows("SELECT id, created, source, detections, total_engines, detection_ratio, risk, status "
                            "FROM investigations WHERE ioc=? ORDER BY id", (value,))
        prev = None
        for r in rows:
            r["change"] = None if prev is None or r["detections"] is None or prev is None \
                else r["detections"] - prev
            if r["detections"] is not None:
                prev = r["detections"]
        return rows

    def latest_per_ioc(self) -> list:
        return self.db.rows("""SELECT i.* FROM investigations i JOIN
                               (SELECT ioc, MAX(id) AS mid FROM investigations GROUP BY ioc) l ON i.id = l.mid
                               ORDER BY i.id DESC""")

    def stats(self) -> dict:
        latest = self.latest_per_ioc()
        by_type = Counter(r["ioc_type"] for r in latest)
        by_risk = Counter(r["risk"] for r in latest)
        timeline = self.db.rows("SELECT substr(created,1,10) AS day, COUNT(*) AS n FROM investigations "
                                "GROUP BY day ORDER BY day")
        live = self.db.rows("SELECT COUNT(*) AS n FROM investigations WHERE source != 'offline-sample'")[0]["n"]
        return {
            "total_iocs": len(latest),
            "total_investigations": self.db.rows("SELECT COUNT(*) AS n FROM investigations")[0]["n"],
            "live_investigations": live,
            "by_type": {t: by_type.get(t, 0) for t in ("ip", "domain", "url", "hash")},
            "by_risk": {lvl: by_risk.get(lvl, 0) for lvl in LEVELS},
            "timeline": timeline,
            "detections": [{"ioc": r["ioc"], "type": r["ioc_type"], "detections": r["detections"],
                            "total": r["total_engines"], "risk": r["risk"], "source": r["source"]}
                           for r in sorted(latest, key=lambda r: LEVEL_ORDER.get(r["risk"], 9))
                           if r["detections"] is not None],
            "offline_samples_included": any(r["source"] == "offline-sample" for r in latest),
        }
