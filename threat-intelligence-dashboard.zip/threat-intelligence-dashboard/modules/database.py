"""
database.py - SQLite storage: investigations, analyst notes, batches, the
VirusTotal response cache and an API-call log (type + HTTP status only).

Nothing here stores the API key.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS investigations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ioc TEXT NOT NULL,
    ioc_type TEXT NOT NULL,
    ioc_subtype TEXT,
    created TEXT NOT NULL,
    source TEXT NOT NULL,
    found INTEGER,
    detections INTEGER,
    suspicious INTEGER,
    total_engines INTEGER,
    detection_ratio TEXT,
    risk TEXT,
    confidence TEXT,
    status TEXT NOT NULL DEFAULT 'COMPLETED',
    conclusion TEXT DEFAULT '',
    analysis_json TEXT,
    assessment_json TEXT,
    report_path TEXT DEFAULT '',
    batch_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_inv_ioc ON investigations(ioc);
CREATE INDEX IF NOT EXISTS idx_inv_type ON investigations(ioc_type);
CREATE INDEX IF NOT EXISTS idx_inv_risk ON investigations(risk);
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investigation_id INTEGER REFERENCES investigations(id),
    timestamp TEXT NOT NULL,
    analyst TEXT,
    note TEXT,
    old_status TEXT,
    new_status TEXT
);
CREATE TABLE IF NOT EXISTS batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TEXT NOT NULL,
    filename TEXT,
    total INTEGER,
    summary_json TEXT
);
CREATE TABLE IF NOT EXISTS vt_cache (
    ioc_type TEXT NOT NULL,
    ioc TEXT NOT NULL,
    fetched_at TEXT NOT NULL,
    result_json TEXT NOT NULL,
    PRIMARY KEY (ioc_type, ioc)
);
CREATE TABLE IF NOT EXISTS api_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    ioc_type TEXT,
    http_status INTEGER
);
"""

STATUSES = ("COMPLETED", "UNDER_REVIEW", "SUSPICIOUS", "FURTHER_INVESTIGATION", "CONCLUDED")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10)
        self.conn.row_factory = sqlite3.Row
        with self.conn:
            self.conn.executescript(SCHEMA)

    def close(self):
        self.conn.close()

    def _x(self, sql, p=()):
        with self._lock, self.conn:
            return self.conn.execute(sql, p)

    def rows(self, sql, p=()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, p).fetchall()]

    # --------------------------------------------------------- investigations
    def add_investigation(self, analysis, assessment, batch_id: Optional[int] = None) -> int:
        a = analysis
        cur = self._x(
            """INSERT INTO investigations (ioc, ioc_type, ioc_subtype, created, source, found, detections, suspicious,
               total_engines, detection_ratio, risk, confidence, analysis_json, assessment_json, batch_id)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (a.ioc, a.ioc_type, a.ioc_subtype, _now(), a.source, 1 if a.found else 0, a.detections, a.suspicious,
             a.total_engines, a.detection_ratio, assessment.level, assessment.confidence,
             json.dumps(a.to_dict()), json.dumps(assessment.to_dict()), batch_id))
        return int(cur.lastrowid)

    def investigation(self, inv_id: int) -> Optional[dict]:
        r = self.rows("SELECT * FROM investigations WHERE id=?", (inv_id,))
        if not r:
            return None
        d = r[0]
        d["analysis"] = json.loads(d.pop("analysis_json") or "{}")
        d["assessment"] = json.loads(d.pop("assessment_json") or "{}")
        return d

    def set_report_path(self, inv_id: int, path: str):
        self._x("UPDATE investigations SET report_path=? WHERE id=?", (path, inv_id))

    def update_status(self, inv_id: int, status: str, analyst: str, note: str = "", conclusion: Optional[str] = None):
        if status not in STATUSES:
            raise ValueError(f"status must be one of {', '.join(STATUSES)}")
        cur = self.investigation(inv_id)
        if cur is None:
            raise ValueError(f"investigation {inv_id} not found")
        self._x("UPDATE investigations SET status=?, conclusion=COALESCE(?, conclusion) WHERE id=?",
                (status, conclusion, inv_id))
        self._x("INSERT INTO notes (investigation_id, timestamp, analyst, note, old_status, new_status) "
                "VALUES (?,?,?,?,?,?)", (inv_id, _now(), analyst or "analyst", note, cur["status"], status))

    def add_note(self, inv_id: int, analyst: str, note: str):
        if not note.strip():
            raise ValueError("note is empty")
        cur = self.investigation(inv_id)
        if cur is None:
            raise ValueError(f"investigation {inv_id} not found")
        self._x("INSERT INTO notes (investigation_id, timestamp, analyst, note, old_status, new_status) "
                "VALUES (?,?,?,?,?,?)", (inv_id, _now(), analyst or "analyst", note.strip()[:4000],
                                         cur["status"], cur["status"]))

    def notes(self, inv_id: int) -> list[dict]:
        return self.rows("SELECT * FROM notes WHERE investigation_id=? ORDER BY id", (inv_id,))

    # ---------------------------------------------------------------- batches
    def add_batch(self, filename: str, total: int) -> int:
        return int(self._x("INSERT INTO batches (created, filename, total) VALUES (?,?,?)",
                           (_now(), filename, total)).lastrowid)

    def finish_batch(self, batch_id: int, summary: dict):
        self._x("UPDATE batches SET summary_json=? WHERE id=?", (json.dumps(summary), batch_id))

    def batches(self, limit=20) -> list[dict]:
        return self.rows("SELECT * FROM batches ORDER BY id DESC LIMIT ?", (limit,))

    # ------------------------------------------------------------------ cache
    def cache_get(self, ioc_type: str, ioc: str, ttl_hours: float) -> Optional[dict]:
        if ttl_hours <= 0:
            return None
        r = self.rows("SELECT fetched_at, result_json FROM vt_cache WHERE ioc_type=? AND ioc=?", (ioc_type, ioc))
        if not r:
            return None
        fetched = datetime.fromisoformat(r[0]["fetched_at"])
        if datetime.now(timezone.utc) - fetched > timedelta(hours=ttl_hours):
            return None
        return json.loads(r[0]["result_json"])

    def cache_put(self, ioc_type: str, ioc: str, result: dict):
        self._x("INSERT OR REPLACE INTO vt_cache (ioc_type, ioc, fetched_at, result_json) VALUES (?,?,?,?)",
                (ioc_type, ioc, _now(), json.dumps(result)))

    def clear_cache(self) -> int:
        return self._x("DELETE FROM vt_cache").rowcount

    # --------------------------------------------------------------- API log
    def log_api_call(self, ioc_type: str, status: int):
        self._x("INSERT INTO api_calls (timestamp, ioc_type, http_status) VALUES (?,?,?)", (_now(), ioc_type, status))

    def api_calls_today(self) -> int:
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        return self.rows("SELECT COUNT(*) AS n FROM api_calls WHERE timestamp >= ?", (day,))[0]["n"]
