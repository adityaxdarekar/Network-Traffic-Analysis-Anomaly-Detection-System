"""
settings.py - configuration, API-key handling and log redaction.

API-key rules enforced here:
  * the key is read only from the environment / .env (python-dotenv) or typed
    into the dashboard for the current session - never from config.json;
  * it is never printed in full: mask_key() shows only the last 4 characters;
  * every log record passes through RedactingFilter, which removes the key
    and any "x-apikey" header value before anything is written;
  * report writers call redact() as a last safety net.
"""
from __future__ import annotations

import copy
import json
import logging
import os
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_VAR = "VIRUSTOTAL_API_KEY"
PLACEHOLDERS = {"", "YOUR_API_KEY_HERE", "changeme", "xxx"}

DEFAULTS = {
    "virustotal": {"base_url": "https://www.virustotal.com/api/v3", "gui_url": "https://www.virustotal.com/gui",
                   "timeout_seconds": 20, "requests_per_minute": 4, "requests_per_day": 500,
                   "retry_on_too_many_requests": 1, "too_many_requests_wait_seconds": 60,
                   "fetch_domain_resolutions": False, "cache_ttl_hours": 24},
    "risk_thresholds": {"low": 1, "medium": 4, "high": 10, "critical": 20, "suspicious_only_is_low": True,
                        "negative_reputation_threshold": -10},
    "confidence": {"high_min_engines": 50, "medium_min_engines": 20, "fresh_days": 30, "stale_days": 180},
    "batch": {"max_indicators": 100, "max_upload_mb": 2},
    "paths": {"database": "database/threat_intelligence.db", "reports": "reports", "logs": "logs/app.log",
              "offline_samples": "data/offline_samples"},
}


class ConfigError(ValueError):
    pass


class Config(dict):
    base_dir: Path = BASE_DIR

    def path(self, key: str) -> Path:
        p = Path(self["paths"][key])
        return p if p.is_absolute() else (self.base_dir / p)


def _merge(base, over):
    out = copy.deepcopy(base)
    for k, v in over.items():
        if k.startswith("_"):
            continue
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _validate(cfg) -> list[str]:
    e = []
    vt = cfg["virustotal"]
    if not str(vt["base_url"]).startswith("https://"):
        e.append("virustotal.base_url must use https://")
    for k, lo in (("timeout_seconds", 1), ("requests_per_minute", 1), ("requests_per_day", 1),
                  ("too_many_requests_wait_seconds", 0), ("cache_ttl_hours", 0), ("retry_on_too_many_requests", 0)):
        if not isinstance(vt.get(k), (int, float)) or isinstance(vt.get(k), bool) or vt[k] < lo:
            e.append(f"virustotal.{k} must be a number >= {lo}")
    t = cfg["risk_thresholds"]
    vals = [t.get(k) for k in ("low", "medium", "high", "critical")]
    if not all(isinstance(v, int) and not isinstance(v, bool) and v >= 1 for v in vals):
        e.append("risk_thresholds low/medium/high/critical must be integers >= 1")
    elif not vals[0] < vals[1] < vals[2] < vals[3]:
        e.append("risk_thresholds must increase: low < medium < high < critical")
    if any(k.lower().find("key") >= 0 and k != "_comment" for k in cfg.get("virustotal", {})):
        e.append("do not store API keys in config.json - use .env")
    if not isinstance(cfg["batch"].get("max_indicators"), int) or cfg["batch"]["max_indicators"] < 1:
        e.append("batch.max_indicators must be a positive integer")
    return e


def load_config(path: str | Path | None = None, base_dir: Path = BASE_DIR) -> Config:
    path = Path(path) if path else base_dir / "config.json"
    user = {}
    if path.exists():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"{path.name} is not valid JSON (line {exc.lineno}): {exc.msg}")
    cfg = _merge(DEFAULTS, user)
    problems = _validate(cfg)
    if problems:
        raise ConfigError("invalid configuration:\n  - " + "\n  - ".join(problems))
    out = Config(cfg)
    out.base_dir = base_dir
    return out


# ------------------------------------------------------------------ API key
def load_api_key(env_file: str | Path | None = None) -> str | None:
    """Return the key from the environment / .env, or None if missing or a placeholder."""
    env_file = Path(env_file) if env_file else BASE_DIR / ".env"
    try:
        from dotenv import load_dotenv
        load_dotenv(env_file, override=False)
    except ImportError:                       # tiny fallback parser
        if env_file.is_file():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith(ENV_VAR + "="):
                    os.environ.setdefault(ENV_VAR, line.split("=", 1)[1].strip().strip('"').strip("'"))
    key = (os.environ.get(ENV_VAR) or "").strip()
    return None if key in PLACEHOLDERS else key


def key_looks_valid(key: str | None) -> bool:
    """VirusTotal keys are 64 hexadecimal characters."""
    return bool(key) and re.fullmatch(r"[0-9a-fA-F]{64}", key) is not None


def mask_key(key: str | None) -> str:
    if not key:
        return "(not configured)"
    return "*" * 8 + key[-4:] if len(key) > 8 else "*" * len(key)


def redact(text: str, *secrets: str | None) -> str:
    """Remove secrets and any x-apikey header value from text."""
    out = str(text)
    for s in secrets:
        if s and len(s) >= 8:
            out = out.replace(s, "[REDACTED]")
    return re.sub(r"(x-apikey['\"]?\s*[:=]\s*['\"]?)[^'\"\s,}]+", r"\1[REDACTED]", out, flags=re.I)


class RedactingFilter(logging.Filter):
    def __init__(self, get_secret):
        super().__init__()
        self.get_secret = get_secret

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        record.msg, record.args = redact(msg, self.get_secret()), ()
        return True


_KEY_FOR_LOGS: dict = {"key": None}


def remember_key_for_redaction(key: str | None):
    _KEY_FOR_LOGS["key"] = key


def setup_logging(log_path: Path) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("tid")
    if not any(isinstance(h, logging.FileHandler) and Path(h.baseFilename) == log_path.resolve()
               for h in logger.handlers):
        h = logging.FileHandler(log_path, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        h.addFilter(RedactingFilter(lambda: _KEY_FOR_LOGS["key"]))
        logger.addHandler(h)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger
