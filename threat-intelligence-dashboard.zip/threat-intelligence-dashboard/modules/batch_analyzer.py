"""
batch_analyzer.py - investigate many IOCs from a CSV file.

CSV format (header required):  indicator,type      (type optional: ip/domain/url/hash/auto)

* every row is validated first; invalid rows are reported and never sent;
* duplicates are looked up once;
* lookups go through the client's rate limiter (4/minute on the public API) and
  the 24-hour cache, and the batch stops cleanly if the daily quota is reached;
* files are never uploaded - hashes are looked up only.
"""
from __future__ import annotations

import csv
import io
import json
from dataclasses import asdict, dataclass, field
from typing import Callable, Optional

from modules.ioc_validator import IOCValidationError, validate
from modules.virustotal_client import AuthError, NotAvailableOffline, QuotaError, VTError


class BatchError(ValueError):
    pass


@dataclass
class BatchRow:
    row: int
    indicator: str
    requested_type: str
    status: str                       # OK / NOT_FOUND / INVALID / DUPLICATE / NO_OFFLINE_SAMPLE / ERROR / SKIPPED
    ioc_type: str = ""
    investigation_id: Optional[int] = None
    detection_ratio: str = ""
    risk: str = ""
    source: str = ""
    message: str = ""


@dataclass
class BatchResult:
    batch_id: Optional[int]
    filename: str
    rows: list = field(default_factory=list)
    stopped_reason: str = ""

    def summary(self) -> dict:
        st = {}
        for r in self.rows:
            st[r.status] = st.get(r.status, 0) + 1
        risks = {}
        for r in self.rows:
            if r.risk:
                risks[r.risk] = risks.get(r.risk, 0) + 1
        return {"rows": len(self.rows), "status": st, "risk": risks, "stopped_reason": self.stopped_reason,
                "offline_samples": any(r.source == "offline-sample" for r in self.rows)}

    def to_csv(self) -> str:
        buf = io.StringIO()
        fields = list(BatchRow.__dataclass_fields__)
        w = csv.DictWriter(buf, fieldnames=fields)
        w.writeheader()
        for r in self.rows:
            w.writerow(asdict(r))
        return buf.getvalue()

    def to_json(self) -> str:
        return json.dumps({"batch_id": self.batch_id, "filename": self.filename, "summary": self.summary(),
                           "rows": [asdict(r) for r in self.rows]}, indent=2)


def parse_csv(data: bytes | str, max_rows: int = 100, max_mb: float = 2) -> list[dict]:
    raw = data.encode() if isinstance(data, str) else data
    if len(raw) > max_mb * 1024 * 1024:
        raise BatchError(f"CSV is larger than {max_mb} MB")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise BatchError("CSV must be UTF-8 text") from None
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or "indicator" not in [f.strip().lower() for f in reader.fieldnames]:
        raise BatchError("CSV needs a header row with an 'indicator' column (and optional 'type')")
    rows = []
    for r in reader:
        line = reader.line_num                    # real line number in the file (blank lines included)
        r = {(k or "").strip().lower(): (v or "").strip() for k, v in r.items()}
        if not r.get("indicator"):
            continue
        rows.append({"row": line, "indicator": r["indicator"], "type": r.get("type", "")})
    if not rows:
        raise BatchError("CSV contains no indicators")
    if len(rows) > max_rows:
        raise BatchError(f"CSV has {len(rows)} indicators; the limit is {max_rows} per batch")
    return rows


def run_batch(investigator, rows: list[dict], filename: str = "batch.csv",
              progress: Optional[Callable[[int, int, str], None]] = None, on_wait=None) -> BatchResult:
    db = investigator.db
    batch_id = db.add_batch(filename, len(rows)) if db is not None else None
    result = BatchResult(batch_id, filename)
    seen: dict[tuple, BatchRow] = {}
    stop = ""
    for n, r in enumerate(rows, 1):
        if progress:
            progress(n, len(rows), r["indicator"])
        try:
            ioc = validate(r["indicator"], r["type"] or None)
        except IOCValidationError as exc:
            result.rows.append(BatchRow(r["row"], r["indicator"], r["type"], "INVALID", message=str(exc)))
            continue
        key = (ioc.type, ioc.value)
        if key in seen:
            first = seen[key]
            result.rows.append(BatchRow(r["row"], r["indicator"], r["type"], "DUPLICATE", ioc.type,
                                        first.investigation_id, first.detection_ratio, first.risk, first.source,
                                        f"same as row {first.row}"))
            continue
        if stop:
            result.rows.append(BatchRow(r["row"], r["indicator"], r["type"], "SKIPPED", ioc.type, message=stop))
            continue
        try:
            inv = investigator.investigate(ioc.value, ioc.type, batch_id=batch_id, on_wait=on_wait)
            br = BatchRow(r["row"], r["indicator"], r["type"], "OK" if inv.analysis.found else "NOT_FOUND",
                          ioc.type, inv.id, inv.analysis.detection_ratio, inv.assessment.level, inv.analysis.source)
        except (QuotaError, AuthError) as exc:
            stop = str(exc)
            br = BatchRow(r["row"], r["indicator"], r["type"], "SKIPPED", ioc.type, message=stop)
        except NotAvailableOffline as exc:
            br = BatchRow(r["row"], r["indicator"], r["type"], "NO_OFFLINE_SAMPLE", ioc.type, message=str(exc))
        except VTError as exc:
            br = BatchRow(r["row"], r["indicator"], r["type"], "ERROR", ioc.type, message=str(exc))
        seen[key] = br
        result.rows.append(br)
    result.stopped_reason = stop
    if db is not None:
        db.finish_batch(batch_id, result.summary())
    return result
