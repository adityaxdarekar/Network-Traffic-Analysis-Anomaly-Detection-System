"""
dashboard.py - Streamlit presentation helpers (theme, risk badges, cards,
Plotly charts with a built-in fallback). All untrusted text (indicators, VT
fields) is HTML-escaped before it is rendered with unsafe_allow_html.
"""
from __future__ import annotations

import html

import pandas as pd

try:
    import plotly.express as px
except ImportError:
    px = None

from modules.risk_classifier import LEVEL_LABEL, LEVELS

RISK_COLOR = {"CRITICAL": "#ef4444", "HIGH": "#f97316", "MEDIUM": "#eab308", "LOW": "#3b82f6",
              "NO_DETECTIONS": "#64748b", "NOT_FOUND": "#94a3b8"}
CSS = """<style>
.block-container{padding-top:1.3rem}
div[data-testid="stMetric"]{background:#111827;border:1px solid #1f2937;border-radius:10px;padding:10px 14px}
.tid-badge{display:inline-block;padding:4px 12px;border-radius:999px;font-weight:700;color:#0a0f1c}
.tid-card{background:#111827;border:1px solid #1f2937;border-radius:10px;padding:12px 16px;margin:6px 0}
.tid-sample{background:#78350f;color:#fde68a;border-radius:8px;padding:8px 12px;font-weight:600;margin:6px 0}
.tid-muted{color:#9ca3af;font-size:0.9rem}
</style>"""


def esc(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def badge(level: str) -> str:
    return (f"<span class='tid-badge' style='background:{RISK_COLOR.get(level, '#64748b')}'>"
            f"{esc(LEVEL_LABEL.get(level, level))}</span>")


def sample_banner(st):
    st.markdown("<div class='tid-sample'>OFFLINE SAMPLE - synthetic demonstration data in VirusTotal format. "
                "This is NOT a live VirusTotal result.</div>", unsafe_allow_html=True)


def chart(st, df: pd.DataFrame, x: str, y: str, title: str, kind: str = "bar", color=None, color_map=None):
    if df is None or df.empty:
        st.caption(f"{title}: nothing to show yet.")
        return
    if px is None:
        st.caption(title)
        (st.line_chart if kind == "line" else st.bar_chart)(df.set_index(x)[y])
        return
    if kind == "pie":
        fig = px.pie(df, names=x, values=y, title=title, color=x, color_discrete_map=color_map or {}, hole=0.45)
    elif kind == "line":
        fig = px.line(df, x=x, y=y, title=title, markers=True)
    else:
        fig = px.bar(df, x=x, y=y, title=title, color=color, color_discrete_map=color_map or {})
    fig.update_layout(template="plotly_dark", paper_bgcolor="#0a0f1c", plot_bgcolor="#0a0f1c",
                      margin=dict(t=50, l=10, r=10, b=10))
    st.plotly_chart(fig, use_container_width=True)


def risk_frame(by_risk: dict) -> pd.DataFrame:
    return pd.DataFrame([{"Risk": LEVEL_LABEL[l], "Level": l, "IOCs": by_risk.get(l, 0)} for l in LEVELS])


def risk_color_map() -> dict:
    return {LEVEL_LABEL[l]: c for l, c in RISK_COLOR.items()}
