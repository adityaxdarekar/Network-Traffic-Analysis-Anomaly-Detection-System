"""
report_generator.py - SOC-style investigation reports (HTML, PDF, JSON, CSV)
and consolidated batch reports.

Each investigation report contains: title, investigation ID and timestamp, IOC
value and type, VirusTotal detection statistics, security-vendor results, risk
classification, threat-intelligence metadata, analyst assessment (with notes,
status and conclusion), recommended defensive actions and limitations.

Every file passes through settings.redact() before it is written, so an API key
can never end up in a report even by accident.
"""
from __future__ import annotations

import csv
import html
import io
import json
from datetime import datetime, timezone
from pathlib import Path

from modules.ioc_analyzer import UNAVAILABLE, fmt
from modules.settings import _KEY_FOR_LOGS, redact

TITLE = "Threat Intelligence Investigation Report"
LIMITATIONS = [
    "Results reflect VirusTotal's data at the time of the lookup; detections change as engines update.",
    "Risk levels use configurable demonstration thresholds, not official VirusTotal ratings.",
    "Zero detections do not prove an indicator is safe; 'no report' means unknown, not clean.",
    "Engine verdicts can include false positives and false negatives; corroborate with other sources and internal "
    "telemetry before acting.",
    "This tool performs lookups only: it never uploads files and never blocks or quarantines indicators.",
    "Public API keys are rate-limited (4 lookups/minute, 500/day), so large batches take time.",
]
RISK_COLOR = {"CRITICAL": "#ef4444", "HIGH": "#f97316", "MEDIUM": "#eab308", "LOW": "#3b82f6",
              "NO_DETECTIONS": "#64748b", "NOT_FOUND": "#94a3b8"}


def _e(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def build_report_data(inv: dict, notes: list[dict]) -> dict:
    a, r = inv["analysis"], inv["assessment"]
    return {
        "title": TITLE,
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "investigation_id": inv["id"],
        "investigation_timestamp": inv["created"],
        "ioc": inv["ioc"], "ioc_type": inv["ioc_type"], "ioc_subtype": inv.get("ioc_subtype"),
        "data_source": a["source"],
        "is_offline_sample": a["source"] == "offline-sample",
        "virustotal_link": a.get("permalink"),
        "found_in_virustotal": a["found"],
        "detection_statistics": {"detection_ratio": a["detection_ratio"], "malicious": a["detections"],
                                 "suspicious": a["suspicious"], "total_engines": a["total_engines"],
                                 "raw_stats": a["stats"], "last_analysis_date": a["last_analysis_date"]},
        "vendor_results": a["vendors"],
        "detection_names": a["detection_names"],
        "risk": {"level": r["level"], "label": r["label"], "confidence": r["confidence"], "factors": r["factors"],
                 "note": r["note"]},
        "metadata": {**a["metadata"], "Reputation": a["reputation"], "Community votes": a["votes"]},
        "related_indicators": a["related"],
        "url_characteristics": a["url_characteristics"],
        "analyst_assessment": {"threat_summary": r["summary"], "implications": r["implications"],
                               "status": inv["status"], "conclusion": inv.get("conclusion") or "",
                               "notes": [{"time": n["timestamp"], "analyst": n["analyst"], "note": n["note"],
                                          "status_change": f"{n['old_status']} -> {n['new_status']}"
                                          if n["old_status"] != n["new_status"] else ""} for n in notes]},
        "recommended_actions": r["actions"],
        "limitations": LIMITATIONS,
    }


def _banner(d) -> str:
    if d["is_offline_sample"]:
        return ("<div class='banner'>OFFLINE SAMPLE - synthetic demonstration data in VirusTotal format. "
                "This is NOT a live VirusTotal result.</div>")
    return ""


def to_html(d: dict) -> str:
    s, r = d["detection_statistics"], d["risk"]
    color = RISK_COLOR.get(r["level"], "#64748b")
    flagged = [v for v in d["vendor_results"] if v["category"] in ("malicious", "suspicious")]
    vend_rows = "".join(f"<tr><td>{_e(v['engine'])}</td><td>{_e(v['category'])}</td><td>{_e(v['result'] or '-')}"
                        f"</td></tr>" for v in flagged) or "<tr><td colspan='3'>No engine flagged this indicator.</td></tr>"
    meta_rows = "".join(f"<tr><th>{_e(k)}</th><td>{_e(fmt(v))}</td></tr>" for k, v in d["metadata"].items())
    rel = "".join(f"<li>{_e(x['value'])} <span class='muted'>({_e(x['relation'])})</span></li>"
                  for x in d["related_indicators"]) or "<li>None reported.</li>"
    urlc = "".join(f"<li>{_e(x)}</li>" for x in d["url_characteristics"])
    notes = "".join(f"<li><b>{_e(n['time'])} - {_e(n['analyst'])}</b>: {_e(n['note'])}"
                    f"{' <i>(' + _e(n['status_change']) + ')</i>' if n['status_change'] else ''}</li>"
                    for n in d["analyst_assessment"]["notes"]) or "<li>No analyst notes yet.</li>"
    acts = "".join(f"<li>{_e(x)}</li>" for x in d["recommended_actions"])
    lims = "".join(f"<li>{_e(x)}</li>" for x in d["limitations"])
    factors = "".join(f"<li>{_e(x)}</li>" for x in r["factors"])
    link = (f"<a href='{_e(d['virustotal_link'])}'>{_e(d['virustotal_link'])}</a>"
            if d["virustotal_link"] and not d["is_offline_sample"] else _e("not applicable (offline sample)")
            if d["is_offline_sample"] else UNAVAILABLE)
    stats_raw = ", ".join(f"{k}: {v}" for k, v in (s["raw_stats"] or {}).items()) or UNAVAILABLE
    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>TI Report {_e(d['investigation_id'])}</title><style>
body{{margin:0;background:#0a0f1c;color:#e5e7eb;font-family:Segoe UI,Helvetica,Arial,sans-serif}}
header{{background:#020617;padding:24px 32px;border-bottom:3px solid #22d3ee}} h1{{margin:0;font-size:22px}}
main{{max-width:1050px;margin:auto;padding:22px}} section{{background:#111827;border:1px solid #1f2937;border-radius:10px;
padding:16px 20px;margin-bottom:14px}} h2{{font-size:15px;color:#67e8f9;margin:0 0 10px}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{text-align:left;padding:6px 8px;
border-bottom:1px solid #1f2937;vertical-align:top}} th{{color:#9ca3af;font-weight:600;width:32%}}
.muted{{color:#9ca3af;font-size:12px}} .risk{{display:inline-block;padding:6px 14px;border-radius:999px;
font-weight:700;color:#0a0f1c;background:{color}}} .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}}
.card{{background:#0a0f1c;border:1px solid #1f2937;border-radius:8px;padding:10px 12px}} .big{{font-size:22px;font-weight:700}}
.banner{{background:#78350f;color:#fde68a;padding:10px 32px;font-weight:600}} a{{color:#67e8f9;word-break:break-all}}
</style></head><body>
<header><h1>{_e(d['title'])}</h1><div class='muted'>Investigation #{_e(d['investigation_id'])} &middot;
{_e(d['investigation_timestamp'])} &middot; report generated {_e(d['generated'])} &middot; source: {_e(d['data_source'])}</div></header>
{_banner(d)}<main>
<section><h2>Investigation summary</h2><div class='grid'>
<div class='card'><div class='muted'>Indicator</div><div class='big' style='font-size:15px;word-break:break-all'>{_e(d['ioc'])}</div></div>
<div class='card'><div class='muted'>Type</div><div class='big'>{_e(d['ioc_type'].upper())}</div><div class='muted'>{_e(d['ioc_subtype'])}</div></div>
<div class='card'><div class='muted'>Detection ratio</div><div class='big'>{_e(s['detection_ratio'])}</div></div>
<div class='card'><div class='muted'>Risk classification</div><div><span class='risk'>{_e(r['label'])}</span></div>
<div class='muted'>confidence: {_e(r['confidence'])}</div></div></div>
<p class='muted'>{_e(r['note'])}</p></section>
<section><h2>VirusTotal detection statistics</h2><table>
<tr><th>Engines reporting malicious</th><td>{_e(fmt(s['malicious']))}</td></tr>
<tr><th>Engines reporting suspicious</th><td>{_e(fmt(s['suspicious']))}</td></tr>
<tr><th>Total engines</th><td>{_e(fmt(s['total_engines']))}</td></tr>
<tr><th>All categories</th><td>{_e(stats_raw)}</td></tr>
<tr><th>Last analysis</th><td>{_e(fmt(s['last_analysis_date']))}</td></tr>
<tr><th>VirusTotal report</th><td>{link}</td></tr></table></section>
<section><h2>Security vendor results (engines that flagged it)</h2><table><tr><th>Engine</th><th>Category</th>
<th>Detection name</th></tr>{vend_rows}</table>
<p class='muted'>{len(d['vendor_results'])} engine results in total; engines reporting harmless/undetected are listed in
the JSON/CSV exports.</p></section>
<section><h2>Threat intelligence metadata</h2><table>{meta_rows}</table>
<h2 style='margin-top:12px'>Related indicators</h2><ul>{rel}</ul>
{'<h2>Local URL checks (not VirusTotal data)</h2><ul>' + urlc + '</ul>' if urlc else ''}</section>
<section><h2>Analyst assessment</h2><p><b>Threat summary:</b> {_e(d['analyst_assessment']['threat_summary'])}</p>
<p><b>Potential security implications:</b> {_e(d['analyst_assessment']['implications'])}</p>
<p><b>Investigation status:</b> {_e(d['analyst_assessment']['status'])}
{(' &middot; <b>Conclusion:</b> ' + _e(d['analyst_assessment']['conclusion'])) if d['analyst_assessment']['conclusion'] else ''}</p>
<p><b>Risk factors:</b></p><ul>{factors}</ul><p><b>Analyst notes:</b></p><ul>{notes}</ul></section>
<section><h2>Recommended defensive actions</h2><ul>{acts}</ul>
<p class='muted'>Recommendations only - this tool does not block or quarantine anything.</p></section>
<section><h2>Investigation limitations</h2><ul>{lims}</ul></section>
</main></body></html>"""
    return redact(page, _KEY_FOR_LOGS["key"])


def to_json(d: dict) -> str:
    return redact(json.dumps(d, indent=2, default=str), _KEY_FOR_LOGS["key"])


def to_csv(d: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["investigation_id", "timestamp", "ioc", "ioc_type", "source", "detection_ratio", "malicious",
                "suspicious", "total_engines", "risk", "confidence", "status", "engine", "category", "result"])
    s, r = d["detection_statistics"], d["risk"]
    base = [d["investigation_id"], d["investigation_timestamp"], d["ioc"], d["ioc_type"], d["data_source"],
            s["detection_ratio"], fmt(s["malicious"]), fmt(s["suspicious"]), fmt(s["total_engines"]), r["level"],
            r["confidence"], d["analyst_assessment"]["status"]]
    vendors = d["vendor_results"] or [{"engine": "", "category": "", "result": ""}]
    for v in vendors:
        w.writerow(base + [v["engine"], v["category"], v["result"] or ""])
    return redact(buf.getvalue(), _KEY_FOR_LOGS["key"])


def to_pdf(d: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Table, TableStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=15 * mm,
                            bottomMargin=15 * mm, title=TITLE)
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10, textColor=colors.HexColor("#334155"))
    h2 = ParagraphStyle("h", parent=ss["Heading2"], fontSize=12, textColor=colors.HexColor("#0e7490"), spaceBefore=8)

    def P(t, st=body):
        return Paragraph(html.escape(redact(str(t), _KEY_FOR_LOGS["key"])), st)

    def grid(rows, widths):
        t = Table(rows, colWidths=widths)
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
                               ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f1f5f9"))]))
        return t

    s, r, aa = d["detection_statistics"], d["risk"], d["analyst_assessment"]
    story = [Paragraph(TITLE, ss["Title"]),
             P(f"Investigation #{d['investigation_id']} - {d['investigation_timestamp']} - source: {d['data_source']}", small)]
    if d["is_offline_sample"]:
        story.append(P("OFFLINE SAMPLE - synthetic demonstration data in VirusTotal format. NOT a live VirusTotal "
                       "result.", ParagraphStyle("w", parent=body, textColor=colors.HexColor("#b45309"))))
    story += [Paragraph("Investigation summary", h2),
              grid([[P("Indicator"), P(d["ioc"])], [P("Type"), P(f"{d['ioc_type']} ({d['ioc_subtype']})")],
                    [P("Detection ratio"), P(s["detection_ratio"])],
                    [P("Risk classification"), P(f"{r['label']} (confidence {r['confidence']})")],
                    [P("Last analysis"), P(fmt(s["last_analysis_date"]))],
                    [P("VirusTotal report"), P(d["virustotal_link"] if not d["is_offline_sample"] else "n/a (sample)")]],
                   [45 * mm, 130 * mm]),
              P(r["note"], small),
              Paragraph("Detection statistics", h2),
              P(", ".join(f"{k}: {v}" for k, v in (s["raw_stats"] or {}).items()) or UNAVAILABLE),
              Paragraph("Security vendor results (flagging engines)", h2)]
    flagged = [v for v in d["vendor_results"] if v["category"] in ("malicious", "suspicious")]
    story.append(grid([[P("Engine"), P("Category"), P("Detection name")]] +
                      [[P(v["engine"]), P(v["category"]), P(v["result"] or "-")] for v in flagged]
                      if flagged else [[P("No engine flagged this indicator."), P(""), P("")]],
                      [55 * mm, 30 * mm, 90 * mm]))
    story += [Paragraph("Threat intelligence metadata", h2),
              grid([[P(k), P(fmt(v))] for k, v in d["metadata"].items()], [45 * mm, 130 * mm]),
              Paragraph("Analyst assessment", h2), P("Threat summary: " + aa["threat_summary"]),
              P("Implications: " + aa["implications"]),
              P(f"Status: {aa['status']}" + (f" - Conclusion: {aa['conclusion']}" if aa["conclusion"] else ""))]
    for n in aa["notes"]:
        story.append(P(f"{n['time']} {n['analyst']}: {n['note']} {n['status_change']}", small))
    story.append(Paragraph("Recommended defensive actions", h2))
    story += [P("- " + x) for x in d["recommended_actions"]]
    story.append(Paragraph("Investigation limitations", h2))
    story += [P("- " + x, small) for x in d["limitations"]]
    doc.build(story)
    return buf.getvalue()


def save_investigation_reports(d: dict, reports_dir: Path, formats=("html", "pdf", "json", "csv")) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"investigation_{d['investigation_id']}_{d['ioc_type']}_{stamp}"
    out = {}
    for f in formats:
        folder = Path(reports_dir) / f
        folder.mkdir(parents=True, exist_ok=True)
        p = folder / f"{base}.{f}"
        if f == "html":
            p.write_text(to_html(d), encoding="utf-8")
        elif f == "json":
            p.write_text(to_json(d), encoding="utf-8")
        elif f == "csv":
            p.write_text(to_csv(d), encoding="utf-8")
        elif f == "pdf":
            p.write_bytes(to_pdf(d))
        else:
            raise ValueError(f"unknown format {f}")
        out[f] = p
    return out


def batch_html(batch, investigations: dict) -> str:
    s = batch.summary()
    rows = "".join(
        f"<tr><td>{r.row}</td><td style='word-break:break-all'>{_e(r.indicator)}</td><td>{_e(r.ioc_type)}</td>"
        f"<td>{_e(r.status)}</td><td>{_e(r.detection_ratio)}</td>"
        f"<td>{('<b style=color:' + RISK_COLOR.get(r.risk, '#e5e7eb') + '>' + _e(r.risk) + '</b>') if r.risk else ''}</td>"
        f"<td>{_e(r.source)}</td><td class='muted'>{_e(r.message)}</td></tr>" for r in batch.rows)
    banner = ("<div class='banner'>Contains OFFLINE SAMPLE results (synthetic, not live VirusTotal data). "
              "Rows whose source is 'offline-sample' are demonstration data.</div>") if s["offline_samples"] else ""
    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Batch report</title><style>
body{{margin:0;background:#0a0f1c;color:#e5e7eb;font-family:Segoe UI,Helvetica,Arial,sans-serif}}
header{{background:#020617;padding:22px 30px;border-bottom:3px solid #22d3ee}} main{{max-width:1150px;margin:auto;padding:20px}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{text-align:left;padding:6px;border-bottom:1px solid #1f2937}}
th{{color:#9ca3af}} .muted{{color:#9ca3af;font-size:12px}} .banner{{background:#78350f;color:#fde68a;padding:10px 30px}}
</style></head><body><header><h1 style='margin:0;font-size:21px'>Consolidated IOC Batch Report</h1>
<div class='muted'>Batch #{_e(batch.batch_id)} &middot; file {_e(batch.filename)} &middot;
generated {_e(datetime.now(timezone.utc).isoformat(timespec='seconds'))}</div></header>{banner}<main>
<p>Rows: {s['rows']} &middot; status: {_e(', '.join(f'{k} {v}' for k, v in s['status'].items()))} &middot;
risk: {_e(', '.join(f'{k} {v}' for k, v in s['risk'].items()) or 'none')}</p>
{('<p><b>Stopped early:</b> ' + _e(s['stopped_reason']) + '</p>') if s['stopped_reason'] else ''}
<table><tr><th>Row</th><th>Indicator</th><th>Type</th><th>Status</th><th>Ratio</th><th>Risk</th><th>Source</th>
<th>Message</th></tr>{rows}</table>
<h3>Limitations</h3><ul>{''.join('<li>' + _e(x) + '</li>' for x in LIMITATIONS)}</ul></main></body></html>"""
    return redact(page, _KEY_FOR_LOGS["key"])


def save_batch_reports(batch, reports_dir: Path) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"batch_{batch.batch_id}_{stamp}"
    out = {}
    for f, content in (("html", batch_html(batch, {})), ("csv", batch.to_csv()), ("json", batch.to_json())):
        folder = Path(reports_dir) / f
        folder.mkdir(parents=True, exist_ok=True)
        p = folder / f"{base}.{f}"
        p.write_text(redact(content, _KEY_FOR_LOGS["key"]), encoding="utf-8")
        out[f] = p
    return out
