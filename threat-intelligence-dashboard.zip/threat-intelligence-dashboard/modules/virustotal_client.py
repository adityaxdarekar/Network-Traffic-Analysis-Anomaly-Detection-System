"""
virustotal_client.py - VirusTotal API v3 client (lookups only).

Endpoints (https://docs.virustotal.com/reference/overview):
    GET /ip_addresses/{ip}            IP address report
    GET /domains/{domain}             domain report
    GET /domains/{domain}/resolutions associated IPs (optional, costs quota)
    GET /urls/{id}                    URL report, id = base64url(url) without "=" padding
    GET /files/{md5|sha1|sha256}      file report (hash lookup - files are NEVER uploaded)

Authentication: header "x-apikey". The key is never logged or returned.

Rate limits: the public API allows 4 requests/minute and 500/day. A local
limiter waits for the per-minute window and stops at the daily limit; on HTTP
429 TooManyRequestsError the client waits (default 60 s) and retries once;
QuotaExceededError stops immediately. Limits are never bypassed.

Caching: successful responses (and "not found") are cached in SQLite for
cache_ttl_hours to avoid unnecessary calls.

OfflineClient serves clearly-labelled SAMPLE responses from data/offline_samples
for demonstrations without a key. It never invents data for other indicators.
"""
from __future__ import annotations

import base64
import json
import logging
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

from modules.ioc_validator import IOC

log = logging.getLogger("tid")

LIVE = "virustotal-live"
CACHE = "virustotal-cache"
OFFLINE = "offline-sample"


# --------------------------------------------------------------------- errors
class VTError(Exception):
    """Base error with a user-friendly message."""
    code = "VTError"

    def __init__(self, message: str, code: str = "", status: int = 0):
        super().__init__(message)
        self.code = code or self.code
        self.status = status


class AuthError(VTError):
    code = "AuthenticationError"


class QuotaError(VTError):
    code = "QuotaExceededError"


class RateLimitError(VTError):
    code = "TooManyRequestsError"


class NetworkError(VTError):
    code = "NetworkError"


class InvalidResponseError(VTError):
    code = "InvalidResponse"


class NotAvailableOffline(VTError):
    code = "NotAvailableOffline"


FRIENDLY = {
    "WrongCredentialsError": "The VirusTotal API key was rejected. Check VIRUSTOTAL_API_KEY in your .env file.",
    "AuthenticationRequiredError": "No API key was sent. Configure VIRUSTOTAL_API_KEY in .env.",
    "UserNotActiveError": "The VirusTotal account is not active.",
    "ForbiddenError": "This key is not allowed to use that endpoint (premium-only or restricted).",
    "QuotaExceededError": "Your VirusTotal API quota is used up. Wait for it to reset (daily quotas reset at 00:00 UTC).",
    "TooManyRequestsError": "Too many requests in a short time. The public API allows 4 lookups per minute.",
    "InvalidArgumentError": "VirusTotal rejected the indicator as invalid.",
    "BadRequestError": "VirusTotal rejected the request.",
    "NotAvailableYet": "VirusTotal has not finished analysing this item yet. Try again later.",
    "TransientError": "VirusTotal had a temporary problem. Try again in a moment.",
    "DeadlineExceededError": "VirusTotal took too long to answer. Try again in a moment.",
}


def url_identifier(url: str) -> str:
    """VirusTotal URL identifier: URL-safe base64 of the URL, without padding."""
    return base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")


def endpoint_for(ioc: IOC) -> str:
    if ioc.type == "ip":
        return f"/ip_addresses/{ioc.value}"
    if ioc.type == "domain":
        return f"/domains/{ioc.value}"
    if ioc.type == "url":
        return f"/urls/{url_identifier(ioc.value)}"
    if ioc.type == "hash":
        return f"/files/{ioc.value}"
    raise ValueError(f"unsupported IOC type {ioc.type}")


# --------------------------------------------------------------- rate limiter
class RateLimiter:
    """Sliding one-minute window plus a daily counter (UTC day)."""

    def __init__(self, per_minute: int, per_day: int, clock: Callable[[], float] = time.time,
                 sleep: Callable[[float], None] = time.sleep, used_today: int = 0):
        self.per_minute, self.per_day = per_minute, per_day
        self.clock, self.sleep = clock, sleep
        self._window: deque = deque()
        self._day = self._utc_day()
        self.used_today = used_today

    def _utc_day(self) -> str:
        return datetime.fromtimestamp(self.clock(), timezone.utc).strftime("%Y-%m-%d")

    def remaining_today(self) -> int:
        if self._utc_day() != self._day:
            self._day, self.used_today = self._utc_day(), 0
        return max(0, self.per_day - self.used_today)

    def wait_time(self) -> float:
        now = self.clock()
        while self._window and now - self._window[0] >= 60:
            self._window.popleft()
        if len(self._window) < self.per_minute:
            return 0.0
        return 60 - (now - self._window[0]) + 0.05

    def acquire(self, on_wait: Optional[Callable[[float], None]] = None) -> None:
        if self.remaining_today() <= 0:
            raise QuotaError(f"Local daily limit of {self.per_day} requests reached. Wait until 00:00 UTC.")
        w = self.wait_time()
        if w > 0:
            if on_wait:
                on_wait(w)
            log.info("rate limit: waiting %.1f s before the next VirusTotal request", w)
            self.sleep(w)
            self.wait_time()
        self._window.append(self.clock())
        self.used_today += 1


# --------------------------------------------------------------------- client
class VirusTotalClient:
    source = LIVE

    def __init__(self, api_key: str, config: dict, cache=None, session=None, limiter: Optional[RateLimiter] = None,
                 sleep: Callable[[float], None] = time.sleep):
        if not api_key:
            raise AuthError("No VirusTotal API key configured. Add VIRUSTOTAL_API_KEY to .env "
                            "or use offline demonstration mode.")
        import requests
        self._key = api_key                      # kept private; never logged or returned
        self.cfg = config["virustotal"]
        self.cache = cache
        self.http = session or requests.Session()
        self.sleep = sleep
        used = cache.api_calls_today() if cache is not None else 0
        self.limiter = limiter or RateLimiter(self.cfg["requests_per_minute"], self.cfg["requests_per_day"],
                                              sleep=sleep, used_today=used)
        self._requests_exc = requests.exceptions

    def __repr__(self):                          # never show the key
        return "VirusTotalClient(key=****)"

    def _get(self, path: str, ioc_type: str, on_wait=None) -> tuple[int, dict]:
        url = self.cfg["base_url"].rstrip("/") + path
        retries = int(self.cfg["retry_on_too_many_requests"])
        for attempt in range(retries + 1):
            self.limiter.acquire(on_wait)
            try:
                resp = self.http.get(url, headers={"x-apikey": self._key, "accept": "application/json"},
                                     timeout=self.cfg["timeout_seconds"])
            except self._requests_exc.Timeout as exc:
                raise NetworkError(f"VirusTotal did not respond within {self.cfg['timeout_seconds']} s.") from None
            except self._requests_exc.RequestException as exc:
                raise NetworkError("Could not connect to VirusTotal. Check your internet connection.") from None
            status = resp.status_code
            if self.cache is not None:
                self.cache.log_api_call(ioc_type, status)
            log.info("VirusTotal %s lookup -> HTTP %s", ioc_type, status)
            try:
                body = resp.json() if resp.content else {}
            except ValueError:
                raise InvalidResponseError(f"VirusTotal returned a non-JSON response (HTTP {status}).") from None
            if status == 200:
                if not isinstance(body, dict) or not isinstance(body.get("data"), dict):
                    raise InvalidResponseError("VirusTotal response is missing the 'data' object.")
                return status, body
            err = body.get("error", {}) if isinstance(body, dict) else {}
            code, message = err.get("code", ""), err.get("message", "")
            if status == 404 or code == "NotFoundError":
                return 404, body
            if status == 429 and code != "QuotaExceededError" and attempt < retries:
                wait = float(self.cfg["too_many_requests_wait_seconds"])
                if on_wait:
                    on_wait(wait)
                log.info("HTTP 429 TooManyRequests: waiting %.0f s, then one retry", wait)
                self.sleep(wait)
                continue
            friendly = FRIENDLY.get(code, f"VirusTotal error HTTP {status}: {code or 'unknown'}")
            if status == 401 or code in ("WrongCredentialsError", "AuthenticationRequiredError", "UserNotActiveError"):
                raise AuthError(friendly, code, status)
            if code == "QuotaExceededError":
                raise QuotaError(friendly, code, status)
            if status == 429:
                raise RateLimitError(friendly, code or "TooManyRequestsError", status)
            raise VTError(friendly + (f" ({message})" if message and len(message) < 200 else ""), code, status)
        raise RateLimitError(FRIENDLY["TooManyRequestsError"], "TooManyRequestsError", 429)

    def get_report(self, ioc: IOC, use_cache: bool = True, on_wait=None) -> dict:
        """Return {"found": bool, "source": ..., "response": dict, "related": dict, "fetched_at": iso}."""
        if use_cache and self.cache is not None:
            hit = self.cache.cache_get(ioc.type, ioc.value, self.cfg["cache_ttl_hours"])
            if hit is not None:
                hit["source"] = CACHE
                return hit
        status, body = self._get(endpoint_for(ioc), ioc.type, on_wait)
        related = {}
        if status == 200 and ioc.type == "domain" and self.cfg.get("fetch_domain_resolutions"):
            try:
                rs, rb = self._get(f"/domains/{ioc.value}/resolutions?limit=10", "domain-resolutions", on_wait)
                if rs == 200:
                    related["resolutions"] = rb
            except (RateLimitError, QuotaError, NetworkError) as exc:
                related["resolutions_error"] = str(exc)
        result = {"found": status == 200, "source": LIVE, "response": body, "related": related,
                  "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        if self.cache is not None:
            self.cache.cache_put(ioc.type, ioc.value, result)
        return result

    def remaining_today(self) -> int:
        return self.limiter.remaining_today()


class OfflineClient:
    """Serves SAMPLE responses for demonstrations. Never claims to be live data."""
    source = OFFLINE

    def __init__(self, samples_dir: str | Path):
        self.dir = Path(samples_dir)
        index = self.dir / "index.json"
        self.index = json.loads(index.read_text(encoding="utf-8")) if index.is_file() else {}

    def available(self) -> list[dict]:
        return [{"type": k.split(":", 1)[0], "value": k.split(":", 1)[1], "file": v} for k, v in self.index.items()]

    def get_report(self, ioc: IOC, use_cache: bool = True, on_wait=None) -> dict:
        name = self.index.get(f"{ioc.type}:{ioc.value}")
        if name is None:
            raise NotAvailableOffline(
                f"No offline sample exists for {ioc.value}. Offline mode only covers the bundled sample "
                "indicators; configure an API key for a real VirusTotal lookup.")
        data = json.loads((self.dir / name).read_text(encoding="utf-8"))
        found = "error" not in data
        return {"found": found, "source": OFFLINE, "response": data, "related": {},
                "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}

    def remaining_today(self) -> int:
        return 10 ** 6
