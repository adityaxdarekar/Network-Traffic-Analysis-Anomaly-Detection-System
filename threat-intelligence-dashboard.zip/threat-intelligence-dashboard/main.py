#!/usr/bin/env python3
"""
main.py - command-line interface for the Threat Intelligence Dashboard.

    python3 main.py check-key                          # is VIRUSTOTAL_API_KEY configured? (masked)
    python3 main.py init-db
    python3 main.py investigate 8.8.8.8 --report html,pdf
    python3 main.py investigate example.com --type domain
    python3 main.py investigate 198.51.100.23 --offline        # labelled offline sample
    python3 main.py batch data/sample_iocs.csv --report
    python3 main.py history --type ip --risk HIGH
    python3 main.py show 3 | compare 8.8.8.8 | stats | samples
    python3 main.py status 3 SUSPICIOUS --note "seen in proxy logs" --analyst alice
    python3 main.py note 3 "asked network team for flow data"
    python3 main.py report 3 --formats html,pdf,json,csv

Dashboard:  streamlit run app.py
"""
from __future__ import annotations

import argparse
import sys
import textwrap

from modules.batch_analyzer import BatchError, parse_csv, run_batch
from modules.database import STATUSES, Database
from modules.history_manager import HistoryManager, Investigator, make_client
from modules.ioc_analyzer import fmt
from modules.ioc_validator import IOCValidationError
from modules.report_generator import build_report_data, save_batch_reports, save_investigation_reports
from modules.settings import ConfigError, key_looks_valid, load_api_key, load_config, mask_key, setup_logging
from modules.virustotal_client import VTError

OFFLINE_BANNER = "*** OFFLINE SAMPLE - synthetic demonstration data, NOT a live VirusTotal result ***"


def print_result(res):
    a, r = res.analysis, res.assessment
    print("=" * 66)
    print("THREAT INTELLIGENCE DASHBOARD")
    print("=" * 66)
    print(f"Data Source: {'VirusTotal API v3' if a.source != 'offline-sample' else 'OFFLINE SAMPLE'}"
          f" ({a.source})")
    if a.is_sample:
        print(OFFLINE_BANNER)
    print(f"\nIndicator: {a.ioc}\nType: {a.ioc_type.upper()} ({a.ioc_subtype})")
    if res.id:
        print(f"Investigation ID: {res.id}")
    if not a.found:
        print(f"\nVirusTotal report: not found - {a.not_found_message}")
    else:
        print("\nDetection Statistics:")
        print(f"  Detections (malicious): {fmt(a.detections)}")
        print(f"  Suspicious:             {fmt(a.suspicious)}")
        print(f"  Total Engines:          {fmt(a.total_engines)}")
        print(f"  Detection ratio:        {a.detection_ratio}")
        print(f"  Reputation:             {fmt(a.reputation)}")
        print(f"  Last analysis:          {fmt(a.last_analysis_date)}")
        for k, v in a.metadata.items():
            print(f"  {k + ':':<24}{fmt(v)}")
        if a.detection_names:
            print("  Detection names:        " + ", ".join(a.detection_names[:8]))
        flagged = a.flagged_vendors
        if flagged:
            print(f"\nSecurity vendors flagging it ({len(flagged)}):")
            for v in flagged[:15]:
                print(f"  {v['engine']:<22} {v['category']:<11} {v['result'] or '-'}")
        for x in a.related:
            print(f"  related: {x['value']} ({x['relation']})")
    for c in a.url_characteristics:
        print(f"  local URL check: {c}")
    print(f"\nRisk Classification: {r.label}   (confidence: {r.confidence})")
    print(textwrap.fill(r.summary, 90, initial_indent="  ", subsequent_indent="  "))
    print("  " + r.note)
    print("\nRecommended actions:")
    for x in r.actions:
        print(textwrap.fill(x, 90, initial_indent="  - ", subsequent_indent="    "))
    if a.permalink and not a.is_sample:
        print(f"\nVirusTotal report: {a.permalink}")
    print("\nInvestigation Status: COMPLETED (awaiting analyst review)")


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Threat Intelligence Dashboard (VirusTotal API v3)")
    p.add_argument("--config")
    p.add_argument("--db", help=argparse.SUPPRESS)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check-key")
    sub.add_parser("init-db")
    sub.add_parser("samples", help="list indicators available in offline mode")
    sub.add_parser("stats")
    sub.add_parser("clear-cache")
    i = sub.add_parser("investigate")
    i.add_argument("indicator")
    i.add_argument("--type", choices=["ip", "domain", "url", "hash", "auto"], default="auto")
    i.add_argument("--offline", action="store_true", help="use labelled offline sample data")
    i.add_argument("--refresh", action="store_true", help="ignore the 24h cache")
    i.add_argument("--report", help="html,pdf,json,csv")
    b = sub.add_parser("batch")
    b.add_argument("csv")
    b.add_argument("--offline", action="store_true")
    b.add_argument("--report", action="store_true")
    h = sub.add_parser("history")
    h.add_argument("--search", default="")
    h.add_argument("--type", default="")
    h.add_argument("--risk", default="")
    h.add_argument("--status", default="")
    s = sub.add_parser("show")
    s.add_argument("id", type=int)
    c = sub.add_parser("compare")
    c.add_argument("indicator")
    n = sub.add_parser("note")
    n.add_argument("id", type=int)
    n.add_argument("text")
    n.add_argument("--analyst", default="analyst")
    st = sub.add_parser("status")
    st.add_argument("id", type=int)
    st.add_argument("status", choices=STATUSES)
    st.add_argument("--note", default="")
    st.add_argument("--conclusion")
    st.add_argument("--analyst", default="analyst")
    r = sub.add_parser("report")
    r.add_argument("id", type=int)
    r.add_argument("--formats", default="html,pdf,json,csv")
    args = p.parse_args(argv)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"[x] {exc}")
        return 2
    setup_logging(cfg.path("logs"))

    if args.cmd == "check-key":
        key = load_api_key()
        if not key:
            print("[x] VIRUSTOTAL_API_KEY is not configured. Copy .env.example to .env and add your key.")
            return 1
        print(f"[+] API key configured: {mask_key(key)}" +
              ("" if key_looks_valid(key) else "  [!] unusual format - VirusTotal keys are 64 hex characters"))
        return 0

    db = Database(args.db or cfg.path("database"))
    try:
        if args.cmd == "init-db":
            print(f"[+] Database ready: {db.path}")
            return 0
        if args.cmd == "clear-cache":
            print(f"[+] Removed {db.clear_cache()} cached responses")
            return 0
        if args.cmd == "samples":
            from modules.virustotal_client import OfflineClient
            for s_ in OfflineClient(cfg.path("offline_samples")).available():
                print(f"  {s_['type']:<7} {s_['value']}")
            print("  (synthetic demonstration data - not live VirusTotal results)")
            return 0
        hm = HistoryManager(db)
        if args.cmd in ("investigate", "batch"):
            try:
                client = make_client(cfg, db, offline=args.offline)
            except VTError as exc:
                print(f"[x] {exc}")
                return 1
            inv = Investigator(cfg, db, client)
            wait_msg = lambda s: print(f"[*] Rate limit: waiting {s:.0f} s (public API = 4 lookups/minute)...")
            if args.cmd == "investigate":
                try:
                    res = inv.investigate(args.indicator, None if args.type == "auto" else args.type, args.refresh,
                                          on_wait=wait_msg)
                except IOCValidationError as exc:
                    print(f"[x] Invalid indicator: {exc}")
                    return 1
                except VTError as exc:
                    print(f"[x] {exc}")
                    return 1
                print_result(res)
                if args.report:
                    paths = save_investigation_reports(build_report_data(db.investigation(res.id), db.notes(res.id)),
                                                       cfg.path("reports"), [f.strip() for f in args.report.split(",")])
                    db.set_report_path(res.id, str(paths.get("html") or next(iter(paths.values()))))
                    for f, path in paths.items():
                        print(f"[+] {f.upper()} report: {path}")
                return 0
            try:
                with open(args.csv, "rb") as fh:
                    rows = parse_csv(fh.read(), cfg["batch"]["max_indicators"], cfg["batch"]["max_upload_mb"])
            except (OSError, BatchError) as exc:
                print(f"[x] {exc}")
                return 1
            if not args.offline:
                print(f"[*] {len(rows)} indicators; public API allows 4 lookups/minute - cached results are reused.")
            result = run_batch(inv, rows, args.csv, progress=lambda k, t, v: print(f"  [{k}/{t}] {v}"),
                               on_wait=wait_msg)
            print(f"\n{'ROW':>4} {'INDICATOR':<46} {'STATUS':<18} {'RATIO':<14} RISK")
            for row in result.rows:
                print(f"{row.row:>4} {row.indicator[:46]:<46} {row.status:<18} {row.detection_ratio:<14} {row.risk}")
                if row.message and row.status != "DUPLICATE":
                    print(f"{'':>5}  -> {row.message[:110]}")
            print(f"\nSummary: {result.summary()}")
            if result.summary()["offline_samples"]:
                print(OFFLINE_BANNER)
            if args.report:
                for f, path in save_batch_reports(result, cfg.path("reports")).items():
                    print(f"[+] {f.upper()}: {path}")
            return 0
        if args.cmd == "history":
            try:
                rows = hm.list(args.search, args.type, args.risk.upper(), args.status.upper())
            except ValueError as exc:
                print(f"[x] {exc}")
                return 1
            for row in rows:
                print(f"  #{row['id']:<4} {row['created']}  {row['ioc_type']:<6} {row['ioc'][:48]:<48} "
                      f"{row['detection_ratio']:<14} {row['risk']:<14} {row['status']}"
                      f"{'  [offline sample]' if row['source'] == 'offline-sample' else ''}")
            print(f"  {len(rows)} investigation(s)")
            return 0
        if args.cmd == "compare":
            rows = hm.compare(args.indicator)
            for row in rows:
                ch = "" if row["change"] is None else f"  change {row['change']:+d}"
                print(f"  #{row['id']:<4} {row['created']}  {row['detection_ratio']:<12} {row['risk']:<14} "
                      f"{row['source']}{ch}")
            if not rows:
                print("  no investigations of this indicator yet")
            return 0
        if args.cmd == "stats":
            s_ = hm.stats()
            print(f"Total IOCs investigated: {s_['total_iocs']} ({s_['total_investigations']} investigations, "
                  f"{s_['live_investigations']} live)")
            for k, v in s_["by_type"].items():
                print(f"  {k:<7} {v}")
            for k, v in s_["by_risk"].items():
                print(f"  {k:<14} {v}")
            if s_["offline_samples_included"]:
                print("  (includes offline sample data)")
            return 0
        inv_row = db.investigation(args.id)
        if inv_row is None:
            print(f"[x] investigation {args.id} not found")
            return 1
        if args.cmd == "show":
            a = inv_row["analysis"]
            print(f"#{inv_row['id']} {inv_row['ioc']} ({inv_row['ioc_type']}) {inv_row['detection_ratio']} "
                  f"{inv_row['risk']} status={inv_row['status']} source={a['source']}")
            for note in db.notes(args.id):
                print(f"  {note['timestamp']} {note['analyst']}: {note['note']} [{note['old_status']}->{note['new_status']}]")
            return 0
        if args.cmd == "note":
            db.add_note(args.id, args.analyst, args.text)
            print("[+] note added")
            return 0
        if args.cmd == "status":
            db.update_status(args.id, args.status, args.analyst, args.note, args.conclusion)
            print(f"[+] investigation {args.id} -> {args.status}")
            return 0
        if args.cmd == "report":
            paths = save_investigation_reports(build_report_data(inv_row, db.notes(args.id)), cfg.path("reports"),
                                               [f.strip() for f in args.formats.split(",")])
            db.set_report_path(args.id, str(paths.get("html") or next(iter(paths.values()))))
            for f, path in paths.items():
                print(f"[+] {f.upper()} report: {path}")
            return 0
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
