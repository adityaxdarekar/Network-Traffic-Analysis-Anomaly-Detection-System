"""
app.py - Streamlit Threat Intelligence Dashboard (VirusTotal API v3).

Run:  streamlit run app.py

Navigation: Home Dashboard, Investigate IP Address, Investigate Domain,
Investigate URL, Investigate File Hash, Batch IOC Analysis, Investigation
History, Threat Analytics, Generate Reports, Settings.

The API key comes from .env (VIRUSTOTAL_API_KEY) or is typed in Settings for
the current session only. It is never shown in full, logged or written to reports.
"""
from __future__ import annotations

import hashlib

import pandas as pd
import streamlit as st

from modules.batch_analyzer import BatchError, parse_csv, run_batch
from modules.dashboard import CSS, badge, chart, esc, risk_color_map, risk_frame, sample_banner
from modules.database import STATUSES, Database
from modules.history_manager import HistoryManager, Investigator, make_client
from modules.ioc_analyzer import UNAVAILABLE, fmt
from modules.ioc_validator import IOCValidationError
from modules.report_generator import (build_report_data, save_batch_reports, save_investigation_reports, to_csv,
                                      to_html, to_json, to_pdf)
from modules.risk_classifier import LEVEL_LABEL, LEVELS
from modules.settings import (ConfigError, key_looks_valid, load_api_key, load_config, mask_key,
                              remember_key_for_redaction, setup_logging)
from modules.virustotal_client import NotAvailableOffline, VTError

PAGES = ["Home Dashboard", "Investigate IP Address", "Investigate Domain", "Investigate URL", "Investigate File Hash",
         "Batch IOC Analysis", "Investigation History", "Threat Analytics", "Generate Reports", "Settings"]
EXAMPLES = {"ip": "8.8.8.8", "domain": "example.com", "url": "https://example.com/",
            "hash": "44d88612fea8a8f36de82e1278abb02f"}


@st.cache_resource
def get_db(path: str):
    return Database(path)


def session_key():
    key = st.session_state.get("session_api_key") or load_api_key()
    remember_key_for_redaction(key)
    return key


def get_investigator(cfg, db):
    offline = st.session_state.get("offline_mode", False)
    try:
        client = make_client(cfg, db, api_key=session_key(), offline=offline)
    except VTError as exc:
        st.warning(f"{exc} You can switch on offline demonstration mode in **Settings**.")
        return None
    return Investigator(cfg, db, client)


# ---------------------------------------------------------------- rendering
def render_investigation(cfg, db, inv_id: int):
    inv = db.investigation(inv_id)
    if inv is None:
        st.error("Investigation not found.")
        return
    a, r = inv["analysis"], inv["assessment"]
    if a["source"] == "offline-sample":
        sample_banner(st)
    st.subheader("Investigation summary")
    c = st.columns(4)
    c[0].metric("Indicator type", f"{inv['ioc_type'].upper()} ({inv['ioc_subtype']})")
    c[1].metric("Detection ratio", a["detection_ratio"])
    c[2].metric("Reputation", fmt(a["reputation"]))
    c[3].metric("Last analysis", fmt(a["last_analysis_date"]))
    st.markdown(f"<div class='tid-card'><b>{esc(inv['ioc'])}</b><br>Investigation #{inv['id']} &middot; "
                f"{esc(inv['created'])} &middot; source: {esc(a['source'])}<br>Risk: {badge(r['level'])} "
                f"&nbsp; confidence {esc(r['confidence'])}<br><span class='tid-muted'>{esc(r['note'])}</span></div>",
                unsafe_allow_html=True)
    if not a["found"]:
        st.info(f"VirusTotal has no report for this indicator: {a['not_found_message']} "
                "Unknown is not the same as safe.")
    tabs = st.tabs(["VirusTotal analysis", "Analyst assessment", "Notes & status"])
    with tabs[0]:
        if a["stats"]:
            sdf = pd.DataFrame([{"Category": k, "Engines": v} for k, v in a["stats"].items()])
            chart(st, sdf, "Category", "Engines", "Engine verdicts")
        flagged = [v for v in a["vendors"] if v["category"] in ("malicious", "suspicious")]
        st.markdown(f"**Security vendors flagging it:** {len(flagged)} of {fmt(a['total_engines'])}")
        if a["vendors"]:
            show_all = st.checkbox("Show all engine results", value=False, key=f"all_{inv_id}")
            st.dataframe(pd.DataFrame(a["vendors"] if show_all else flagged or [{"engine": "none", "category": "",
                                                                                   "result": "", "method": ""}]),
                         hide_index=True, use_container_width=True)
        st.markdown("**Threat intelligence metadata** (\"Not available\" = not in the response; 0 is a real zero)")
        st.dataframe(pd.DataFrame([{"Field": k, "Value": fmt(v)} for k, v in a["metadata"].items()]),
                     hide_index=True, use_container_width=True)
        if a["detection_names"]:
            st.markdown("**Detection names:** " + esc(", ".join(a["detection_names"][:12])))
        if a["related"]:
            st.markdown("**Related indicators**")
            st.dataframe(pd.DataFrame(a["related"]), hide_index=True)
        if a["url_characteristics"]:
            st.markdown("**Local URL checks** (not VirusTotal data)")
            for x in a["url_characteristics"]:
                st.write("- " + x)
        if a["permalink"] and a["source"] != "offline-sample":
            st.markdown(f"[Open the VirusTotal report]({a['permalink']})")
    with tabs[1]:
        st.markdown(f"**Threat summary:** {esc(r['summary'])}")
        st.markdown(f"**Potential security implications:** {esc(r['implications'])}")
        st.markdown("**Risk factors**")
        for f in r["factors"]:
            st.write("- " + f)
        st.markdown("**Recommended defensive actions** (recommendations only - nothing is blocked automatically)")
        for x in r["actions"]:
            st.write("- " + x)
    with tabs[2]:
        st.write(f"Current status: **{inv['status']}**" + (f" - conclusion: {inv['conclusion']}"
                                                          if inv.get("conclusion") else ""))
        analyst = st.text_input("Analyst name", value=st.session_state.get("analyst", "analyst"), key=f"an_{inv_id}")
        st.session_state["analyst"] = analyst
        note = st.text_area("Investigation note", key=f"note_{inv_id}")
        new_status = st.selectbox("Status", STATUSES, index=STATUSES.index(inv["status"]), key=f"st_{inv_id}")
        conclusion = st.text_input("Analyst conclusion", value=inv.get("conclusion") or "", key=f"co_{inv_id}")
        if st.button("Save note / status", key=f"save_{inv_id}"):
            try:
                if new_status != inv["status"] or conclusion != (inv.get("conclusion") or ""):
                    db.update_status(inv_id, new_status, analyst, note, conclusion)
                elif note.strip():
                    db.add_note(inv_id, analyst, note)
                st.success("Saved.")
            except ValueError as exc:
                st.error(str(exc))
        notes = db.notes(inv_id)
        if notes:
            st.dataframe(pd.DataFrame(notes)[["timestamp", "analyst", "note", "old_status", "new_status"]],
                         hide_index=True)
    data = build_report_data(db.investigation(inv_id), db.notes(inv_id))
    c = st.columns(4)
    c[0].download_button("HTML report", to_html(data), f"investigation_{inv_id}.html", "text/html", key=f"h{inv_id}")
    c[1].download_button("PDF report", to_pdf(data), f"investigation_{inv_id}.pdf", "application/pdf", key=f"p{inv_id}")
    c[2].download_button("JSON", to_json(data), f"investigation_{inv_id}.json", "application/json", key=f"j{inv_id}")
    c[3].download_button("CSV", to_csv(data), f"investigation_{inv_id}.csv", "text/csv", key=f"c{inv_id}")


def page_investigate(cfg, db, ioc_type: str):
    title = {"ip": "IP Address", "domain": "Domain", "url": "URL", "hash": "File Hash"}[ioc_type]
    st.header(f"Investigate {title}")
    if ioc_type == "hash":
        st.caption("Hash lookup only - files are never uploaded to VirusTotal.")
        up = st.file_uploader("Or compute the SHA-256 of a local file (stays on this machine)", key="hashfile")
        if up is not None:
            st.session_state["hash_input"] = hashlib.sha256(up.getvalue()).hexdigest()
            st.code(st.session_state["hash_input"])
    value = st.text_input(f"{title} to investigate", value=st.session_state.get("hash_input", "")
                          if ioc_type == "hash" else "", placeholder=EXAMPLES[ioc_type], key=f"in_{ioc_type}")
    refresh = st.checkbox("Ignore the 24-hour cache (uses API quota)", value=False, key=f"rf_{ioc_type}")
    if st.button("Investigate", type="primary", key=f"go_{ioc_type}"):
        inv = get_investigator(cfg, db)
        if inv is not None:
            try:
                with st.spinner("Querying VirusTotal..."):
                    res = inv.investigate(value, ioc_type, refresh,
                                          on_wait=lambda s: st.info(f"Rate limit: waiting {s:.0f} s..."))
                st.session_state["current_investigation"] = res.id
            except IOCValidationError as exc:
                st.error(f"Invalid {title.lower()}: {exc}")
            except NotAvailableOffline as exc:
                st.warning(str(exc))
            except VTError as exc:
                st.error(str(exc))
    cur = st.session_state.get("current_investigation")
    if cur:
        row = db.investigation(cur)
        if row and row["ioc_type"] == ioc_type:
            render_investigation(cfg, db, cur)


def page_home(cfg, db, hm):
    st.title("Threat Intelligence Dashboard")
    st.caption("Data source: VirusTotal API v3 - IOC enrichment for SOC analysts")
    s = hm.stats()
    if s["offline_samples_included"]:
        st.caption("Statistics include OFFLINE SAMPLE investigations (synthetic data).")
    c = st.columns(5)
    c[0].metric("Total IOCs investigated", s["total_iocs"])
    for col, (t, label) in zip(c[1:], [("ip", "IP addresses"), ("domain", "Domains"), ("url", "URLs"),
                                       ("hash", "File hashes")]):
        col.metric(label, s["by_type"][t])
    c = st.columns(6)
    for col, lvl in zip(c, LEVELS):
        col.metric(LEVEL_LABEL[lvl], s["by_risk"][lvl])
    c = st.columns(2)
    with c[0]:
        chart(st, pd.DataFrame([{"Type": k, "IOCs": v} for k, v in s["by_type"].items()]), "Type", "IOCs",
              "IOC type distribution", kind="pie")
    with c[1]:
        chart(st, risk_frame(s["by_risk"]), "Risk", "IOCs", "Threat severity distribution", color="Risk",
              color_map=risk_color_map())
    recent = hm.list(limit=10)
    if recent:
        st.subheader("Recent investigations")
        st.dataframe(pd.DataFrame(recent)[["id", "created", "ioc_type", "ioc", "detection_ratio", "risk", "status",
                                           "source"]], hide_index=True, use_container_width=True)


def page_batch(cfg, db):
    st.header("Batch IOC Analysis")
    st.markdown("CSV with a header row: `indicator,type` (type optional: ip, domain, url, hash or auto). "
                f"Up to {cfg['batch']['max_indicators']} indicators. The public API allows 4 lookups per minute; "
                "cached results (24 h) are reused.")
    up = st.file_uploader("IOC CSV", type=["csv"], key="batchcsv")
    use_sample = st.checkbox("Use data/sample_iocs.csv", value=up is None)
    if st.button("Run batch analysis", type="primary"):
        inv = get_investigator(cfg, db)
        if inv is None:
            return
        try:
            raw = up.getvalue() if up is not None and not use_sample else cfg.base_dir.joinpath(
                "data", "sample_iocs.csv").read_bytes()
            rows = parse_csv(raw, cfg["batch"]["max_indicators"], cfg["batch"]["max_upload_mb"])
        except BatchError as exc:
            st.error(str(exc))
            return
        bar = st.progress(0.0)
        result = run_batch(inv, rows, up.name if up is not None and not use_sample else "sample_iocs.csv",
                           progress=lambda k, t, v: bar.progress(k / t, text=f"{k}/{t}: {v[:60]}"),
                           on_wait=lambda s: st.info(f"Rate limit: waiting {s:.0f} s before the next lookup..."))
        st.session_state["last_batch"] = result
    result = st.session_state.get("last_batch")
    if result is not None:
        sm = result.summary()
        if sm["offline_samples"]:
            sample_banner(st)
        if sm["stopped_reason"]:
            st.warning("Batch stopped early: " + sm["stopped_reason"])
        st.write(sm)
        df = pd.DataFrame([r.__dict__ for r in result.rows])
        st.dataframe(df, hide_index=True, use_container_width=True)
        c = st.columns(3)
        c[0].download_button("Batch CSV", result.to_csv(), "batch_results.csv", "text/csv")
        c[1].download_button("Batch JSON", result.to_json(), "batch_results.json", "application/json")
        if c[2].button("Save consolidated report"):
            paths = save_batch_reports(result, cfg.path("reports"))
            st.success("Saved: " + ", ".join(str(p) for p in paths.values()))


def page_history(cfg, db, hm):
    st.header("Investigation History")
    c = st.columns(4)
    search = c[0].text_input("Search IOC")
    t = c[1].selectbox("Type", ["", "ip", "domain", "url", "hash"])
    risk = c[2].selectbox("Risk", [""] + list(LEVELS))
    status = c[3].selectbox("Status", [""] + list(STATUSES))
    rows = hm.list(search, t, risk, status)
    if not rows:
        st.info("No investigations match.")
        return
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    pick = st.selectbox("Open investigation", [f"#{r['id']} {r['ioc'][:60]}" for r in rows])
    inv_id = int(pick.split()[0][1:])
    comp = hm.compare(db.investigation(inv_id)["ioc"])
    if len(comp) > 1:
        st.subheader("Historical comparison")
        cdf = pd.DataFrame(comp)
        st.dataframe(cdf, hide_index=True)
        chart(st, cdf.dropna(subset=["detections"]), "created", "detections", "Detections over time", kind="line")
    render_investigation(cfg, db, inv_id)


def page_analytics(cfg, db, hm):
    st.header("Threat Analytics")
    s = hm.stats()
    chart(st, risk_frame(s["by_risk"]), "Risk", "IOCs", "Threat severity distribution", color="Risk",
          color_map=risk_color_map())
    det = pd.DataFrame(s["detections"])
    if not det.empty:
        det["label"] = det["ioc"].str.slice(0, 40)
        chart(st, det, "label", "detections", "Detections per indicator (latest investigation)", color="risk")
    chart(st, pd.DataFrame(s["timeline"]).rename(columns={"day": "Day", "n": "Investigations"}), "Day",
          "Investigations", "Investigation history", kind="line")
    chart(st, pd.DataFrame([{"Type": k, "IOCs": v} for k, v in s["by_type"].items()]), "Type", "IOCs",
          "IOC type distribution")


def page_reports(cfg, db, hm):
    st.header("Generate Reports")
    rows = hm.list(limit=200)
    if not rows:
        st.info("No investigations yet.")
        return
    pick = st.selectbox("Investigation", [f"#{r['id']} {r['ioc_type']} {r['ioc'][:60]} ({r['risk']})" for r in rows])
    inv_id = int(pick.split()[0][1:])
    formats = st.multiselect("Formats", ["html", "pdf", "json", "csv"], default=["html", "pdf", "json"])
    if st.button("Generate and save", type="primary") and formats:
        paths = save_investigation_reports(build_report_data(db.investigation(inv_id), db.notes(inv_id)),
                                           cfg.path("reports"), formats)
        db.set_report_path(inv_id, str(paths.get("html") or next(iter(paths.values()))))
        for f, p in paths.items():
            st.success(f"{f.upper()}: {p}")
    render_investigation(cfg, db, inv_id)


def page_settings(cfg, db):
    st.header("Settings - API configuration")
    key = session_key()
    st.markdown(f"**API key:** `{mask_key(key)}`" + ("" if not key or key_looks_valid(key)
                                                     else " - unusual format (VirusTotal keys are 64 hex characters)"))
    st.markdown("Recommended: put `VIRUSTOTAL_API_KEY=...` in the `.env` file (see `.env.example`). "
                "Get a free key from your VirusTotal account profile (API key).")
    typed = st.text_input("Or enter a key for this session only (not saved anywhere)", type="password")
    if st.button("Use this key for this session") and typed.strip():
        st.session_state["session_api_key"] = typed.strip()
        st.success(f"Session key set: {mask_key(typed.strip())}")
    st.session_state["offline_mode"] = st.checkbox(
        "Offline demonstration mode (labelled synthetic samples, no API calls)",
        value=st.session_state.get("offline_mode", key is None))
    st.caption("Offline mode only knows the bundled sample indicators (python3 main.py samples).")
    st.markdown(f"Rate limit: {cfg['virustotal']['requests_per_minute']}/minute, "
                f"{cfg['virustotal']['requests_per_day']}/day - calls logged today: {db.api_calls_today()}  \n"
                f"Cache: {cfg['virustotal']['cache_ttl_hours']} h")
    if st.button("Clear response cache"):
        st.success(f"Removed {db.clear_cache()} cached responses")


def main():
    st.set_page_config(page_title="Threat Intelligence Dashboard", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    try:
        cfg = load_config()
    except ConfigError as exc:
        st.error(str(exc))
        return
    setup_logging(cfg.path("logs"))
    db = get_db(str(cfg.path("database")))
    hm = HistoryManager(db)
    with st.sidebar:
        st.markdown("### Threat Intelligence Dashboard")
        page = st.radio("Navigation", PAGES)
        mode = "OFFLINE SAMPLES" if st.session_state.get("offline_mode") else (
            "VirusTotal API v3" if session_key() else "no API key")
        st.caption(f"Data source: {mode}")
    if page == "Home Dashboard":
        page_home(cfg, db, hm)
    elif page.startswith("Investigate"):
        page_investigate(cfg, db, {"Investigate IP Address": "ip", "Investigate Domain": "domain",
                                   "Investigate URL": "url", "Investigate File Hash": "hash"}[page])
    elif page == "Batch IOC Analysis":
        page_batch(cfg, db)
    elif page == "Investigation History":
        page_history(cfg, db, hm)
    elif page == "Threat Analytics":
        page_analytics(cfg, db, hm)
    elif page == "Generate Reports":
        page_reports(cfg, db, hm)
    else:
        page_settings(cfg, db)


if __name__ == "__main__":
    main()
