# Threat Intelligence Dashboard (Python + VirusTotal API v3)

A lightweight CTI investigation platform for SOC analysts. You enter an **IP address, domain, URL or file hash** (MD5, SHA-1 or SHA-256), or upload a CSV of them. The app:
* validates each indicator;
* queries **VirusTotal API v3** with your own API key;
* extracts detection statistics, vendor verdicts and metadata;
* assigns a demonstration risk level;
* stores the investigation history in SQLite;
* charts the results in a dark Streamlit dashboard;
* writes HTML, PDF, JSON and CSV reports.

> **Ground rules built into the code**
> * Lookups only. Files are **never uploaded** to VirusTotal, and nothing is ever blocked or quarantined.
> * The API key lives in `.env`. It is never hard-coded, never printed in full, and is redacted from logs and reports.
> * Rate limits are respected, never bypassed (public API: 4 lookups per minute, 500 per day). A 24-hour cache saves quota.
> * **Zero detections ≠ safe**, and **no report ≠ clean**. Both are reported as such.
> * Risk thresholds are configurable *demonstration* values, not official VirusTotal ratings.
> * **Offline demonstration mode** uses clearly labelled **synthetic** samples, and only for documentation-only indicators. It never fakes results for real indicators such as 8.8.8.8.
>
> See **PROJECT_STATUS.md** for what was verified and what was not.

---

## PHASE 1 - Architecture and workflow
```
 Streamlit app.py / CLI main.py
      │ 1. analyst enters an IOC (or a CSV)
      ▼
 ioc_validator ── invalid? → error message, NO API call
      │ 2. normalised IOC (type + subtype)
      ▼
 virustotal_client ── cache hit (24 h)? → reuse
      │ 3. GET /ip_addresses | /domains | /urls/{base64url} | /files/{hash}   header: x-apikey
      │    rate limiter (4/min, 500/day) · 429 → wait 60 s, retry once · quota → stop
      ▼
 ioc_analyzer  → detection ratio, vendors, names, reputation, country/ASN, file type, family, related IOCs
      ▼          (missing field = "Not available", real 0 stays 0) + local URL checks
 risk_classifier → CRITICAL / HIGH / MEDIUM / LOW / NO_DETECTIONS / NOT_FOUND + confidence + actions
      ▼
 database (SQLite) ← history_manager (search, filters, compare, stats) ← analyst notes & status
      ▼
 report_generator → HTML / PDF / JSON / CSV (key redacted)        dashboard.py → Plotly charts
```

## PHASE 2 - Files and dependencies
| File | Purpose |
|---|---|
| `app.py` | Streamlit dashboard (10 sections, dark SOC theme) |
| `main.py` | CLI: check-key, init-db, investigate, batch, history, show, compare, note, status, report, stats, samples, clear-cache |
| `modules/virustotal_client.py` | VirusTotal v3 client: endpoints, auth, errors, rate limiter, cache, offline client |
| `modules/ioc_validator.py` | validates and normalises IPv4/IPv6, domains (including IDN), URLs and MD5/SHA-1/SHA-256; re-fangs indicators |
| `modules/ioc_analyzer.py` | parses VirusTotal JSON into a structured analysis; local URL heuristics |
| `modules/risk_classifier.py` | demonstration risk levels, confidence, implications, recommended actions |
| `modules/batch_analyzer.py` | CSV parsing and validation, rate-limited batch runs, CSV/JSON export |
| `modules/database.py` | SQLite: investigations, notes, batches, response cache, API-call log (no key) |
| `modules/history_manager.py` | runs investigations end to end; history search, filters, comparison, statistics |
| `modules/report_generator.py` | investigation and batch reports (HTML/PDF/JSON/CSV) with redaction |
| `modules/dashboard.py` | Streamlit helpers: theme, risk badges, Plotly charts (with fallback) |
| `modules/settings.py` | config loading and validation, `.env` key loading, masking, log redaction |
| `config.json` | timeouts, rate limits, cache TTL, risk thresholds, paths (never the key) |
| `.env.example` / `.gitignore` | key template / keeps `.env`, the database, logs and reports out of git |
| `data/sample_iocs.csv` | batch demonstration file |
| `data/offline_samples/` | **synthetic** VT-format responses and the script that builds them |
| `data/test_files/harmless_test_file.txt` | harmless file to hash for the file-hash demonstration |
| `database/threat_intelligence.db` | created on first run |
| `reports/html, pdf, json, csv/` | generated reports |
| `logs/app.log` | activity log (redacted) |
| `tests/` | 68 pytest tests (no network, no real key) |
| `docs/` | DEMO_GUIDE.md, PROJECT_REPORT.md, VIVA_QUESTIONS.md |
| `sample_output/`, `screenshots/` | offline-mode sample outputs (labelled) |

Dependencies are requests, python-dotenv, pandas, streamlit, plotly, reportlab and pytest. The standard library supplies sqlite3, ipaddress, json, csv, logging and urllib.

## PHASE 3 - Installation and VirusTotal API setup (Kali Linux / Ubuntu)
```bash
# 1. Python
sudo apt update && sudo apt install -y python3 python3-venv python3-pip
# 2. Project + virtual environment
cd ~/projects && unzip threat-intelligence-dashboard.zip && cd threat-intelligence-dashboard
python3 -m venv venv && source venv/bin/activate
# 3. Dependencies (includes Streamlit, step 7)
pip install --upgrade pip && pip install -r requirements.txt
# 4. VirusTotal account: sign up at https://www.virustotal.com/ (free community account),
#    open your profile menu -> "API key", and copy the key.
# 5. Configure the key - NEVER put it in code, config.json, screenshots or chat
cp .env.example .env
nano .env                         # VIRUSTOTAL_API_KEY=<your 64-character key>
chmod 600 .env
python3 main.py check-key         # prints only ********abcd
# 6. Database
python3 main.py init-db
# 7. Tests (optional)
python3 -m pytest -q
# 8. Run
streamlit run app.py              # http://localhost:8501
python3 main.py investigate 8.8.8.8
```
**No key yet?** Turn on offline mode (Settings → *Offline demonstration mode*, or `--offline` in the CLI) to try the labelled synthetic samples. Run `python3 main.py samples` to list them.

## PHASE 5 - Dashboard
The dashboard has these sections:
1. Home Dashboard (totals by type and risk, charts)
2. Investigate IP Address
3. Investigate Domain
4. Investigate URL
5. Investigate File Hash (hash lookup; a local file can be hashed in the browser session and is never uploaded)
6. Batch IOC Analysis
7. Investigation History (search, filters, historical comparison)
8. Threat Analytics (severity, detections, timeline, type charts)
9. Generate Reports
10. Settings (masked key, session-only key, offline mode, cache, rate-limit counters)

Each investigation page has three tabs: VirusTotal analysis, analyst assessment, and notes & status.

## PHASE 6 - Demonstrations
See **docs/DEMO_GUIDE.md**. It covers Tests 1–5, using the safe indicators from the brief with your own key, plus the offline alternative.

## PHASE 7 - Reports and history
```bash
python3 main.py report 3 --formats html,pdf,json,csv
python3 main.py batch data/sample_iocs.csv --report
python3 main.py history --type url --risk CRITICAL
python3 main.py compare 8.8.8.8
python3 main.py status 3 SUSPICIOUS --note "seen in proxy logs" --conclusion "..." --analyst you
```
The investigation statuses are COMPLETED, UNDER_REVIEW, SUSPICIOUS, FURTHER_INVESTIGATION and CONCLUDED.

## PHASE 8 - Documentation
`docs/PROJECT_REPORT.md` contains the 20-section college report. `docs/VIVA_QUESTIONS.md` contains 35 viva questions with answers.
