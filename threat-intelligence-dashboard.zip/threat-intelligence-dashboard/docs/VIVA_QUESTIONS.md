# Viva questions and answers

1. **What is threat intelligence?** Evidence-based knowledge about threats (actors, tools, infrastructure, behaviours) that helps an organisation make security decisions.

2. **What is CTI?** Cyber Threat Intelligence. It is usually grouped as:
   * **strategic**: trends and risks, for leadership;
   * **operational**: campaigns and actors;
   * **tactical**: TTPs;
   * **technical**: IOCs.

3. **What is an IOC?** An Indicator of Compromise: an observable artefact that suggests malicious activity, such as an IP, domain, URL, file hash, registry key or mutex.

4. **IOC vs TTP?** IOCs are specific and easy for attackers to change. TTPs describe behaviour and are harder to change, so they are more durable for detection (see the Pyramid of Pain).

5. **What is IOC enrichment?** Adding context to an indicator (reputation, detections, owner, geolocation, related infrastructure) so an analyst can judge it quickly.

6. **What is VirusTotal?** A Google-owned service that aggregates many antivirus engines, URL/domain blocklists and sandboxes, plus community votes and comments, to analyse files, URLs, domains and IPs.

7. **What is an API?** An Application Programming Interface: a defined way for programs to request data or actions from another system.

8. **What is a REST API?** An HTTP-based API built around resources (URLs) and standard methods (GET, POST, ...), usually exchanging JSON. VirusTotal v3 is RESTful.

9. **What is API authentication?** Proving the caller's identity. VirusTotal uses an API key sent in the `x-apikey` HTTP header.

10. **What is an API key?** A secret token that identifies the account, controls its quota and authorises requests. It is treated like a password.

11. **Why is API key security important?** A leaked key lets others use up your quota, act under your identity, and possibly see private data or break the terms of service. Keys must never appear in code, git, logs, reports or screenshots.

12. **How does your project protect the key?**
    * It is kept in `.env`, loaded with python-dotenv; `.env` is in `.gitignore` and only `.env.example` is shipped.
    * The display shows only the last 4 characters.
    * A redaction filter cleans the logs, and `redact()` cleans every report.
    * It is never stored in SQLite.
    * The Settings page can take a key for the current session only.

13. **What is API rate limiting?** A cap on requests per time window that protects the service. The VirusTotal public API allows 4 per minute and 500 per day. Going over returns HTTP 429.

14. **How does the project handle rate limits?**
    * A local limiter waits for the one-minute window and stops at the daily limit.
    * On TooManyRequests it waits 60 seconds and retries once; on QuotaExceeded it stops.
    * The 24-hour cache avoids repeat calls.
    * Batches stop cleanly when the quota runs out. Limits are never bypassed.

15. **What is IP reputation?** An assessment of how trustworthy an IP is, based on engine verdicts, blocklists and community votes. VirusTotal also gives a numeric community reputation score.

16. **What is domain reputation?** The same idea for domains, with extra context such as registrar, creation date, categories and DNS records.

17. **What is a file hash?** A fixed-length fingerprint of a file's contents produced by a hash function. The same file always gives the same hash, so hashes identify files without sharing them.

18. **What is SHA-256?** A SHA-2 hash function producing a 256-bit (64 hex character) digest. It is collision-resistant and is the standard for file identification. MD5 (32 hex) and SHA-1 (40 hex) are older and broken for collision resistance, but still used as identifiers.

19. **Why look up hashes instead of uploading files?** Uploading can expose sensitive or confidential files to a third party, because uploaded samples can be shared with VirusTotal's partners. A hash lookup reveals nothing about content that VirusTotal does not already know.

20. **What is malware detection?** Identifying malicious software by signatures, heuristics, behaviour or machine learning. VirusTotal shows how many engines detect an item and what names they give it.

21. **What is a false positive?** A benign item flagged as malicious, for example one obscure engine flagging a legitimate installer.

22. **What is a false negative?** A malicious item not flagged, for example a new or targeted sample with 0 detections. This is why zero detections is not treated as "safe".

23. **Zero detections vs no report?** Zero detections means VirusTotal analysed the item and no engine flagged it then. No report means VirusTotal has never seen it. Both mean "unknown risk", not "safe".

24. **How does the risk classification work?**
    * The level comes from the number of engines reporting malicious: 0 → none, 1–3 → Low, 4–9 → Medium, 10–19 → High, 20+ → Critical. These are configurable demonstration thresholds.
    * Suspicious verdicts, negative reputation or malicious votes can raise zero detections to Low.
    * Confidence depends on the number of engines and the age of the analysis.

25. **Why distinguish "Not available" from 0?** Because "the response had no ASN" and "the ASN count is zero" are different facts. Mixing them up leads to wrong conclusions.

26. **How is a URL looked up in VirusTotal v3?** The id is the URL encoded as URL-safe base64 with the padding removed: `GET /urls/{id}`. VirusTotal also accepts the SHA-256 of the URL as an id.

27. **What is JSON?** JavaScript Object Notation: a text format of key/value objects and arrays, used by most web APIs, including VirusTotal's responses.

28. **What is Streamlit?** A Python framework for building data web apps from scripts. Widgets re-run the script, which makes dashboards quick to build.

29. **What is SQLite?** A serverless, file-based SQL database included with Python. It is ideal for a local investigation history.

30. **What is threat hunting?** Proactively searching your environment for threats that evaded detection, often starting from intelligence such as IOCs from this dashboard.

31. **What is a SOC?** A Security Operations Centre: the team, processes and tools that monitor, detect, investigate and respond to security incidents.

32. **What are the limitations of VirusTotal?**
    * Coverage and freshness vary.
    * Engine verdicts disagree and include false positives and false negatives.
    * Public-API quotas are small, and the public API is for non-commercial use.
    * New or targeted threats may have no data.
    * Detection counts are not a risk model.
    * Uploaded content may be shared with partners.

33. **How does this project support SOC analysts?**
    * Fast validated lookups.
    * Consistent interpretation and risk labels.
    * Evidence (vendors, names, metadata) in one view.
    * Batch triage.
    * History and comparison over time.
    * Notes, status and conclusions.
    * Ready-to-share reports.

34. **Why an offline mode, and how is it kept honest?** For teaching without a key. It serves only synthetic samples for documentation-only indicators, labels every output "OFFLINE SAMPLE - NOT a live VirusTotal result", and refuses to produce data for real indicators.

35. **Why doesn't the tool block IOCs automatically?** Detections can be false positives, and blocking can disrupt business. Containment decisions belong to an analyst following change management, so the tool only recommends actions.
