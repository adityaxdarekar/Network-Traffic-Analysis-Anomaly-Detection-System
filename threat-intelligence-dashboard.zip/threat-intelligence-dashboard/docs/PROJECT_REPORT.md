# Threat Intelligence Dashboard Using Python and VirusTotal API
### College project report

## 1. Abstract
SOC analysts constantly need to answer one question about a suspicious IP address, domain, URL or file hash: what is known about it? This project builds a Python threat-intelligence dashboard that:
* validates indicators of compromise (IOCs);
* enriches them through the **VirusTotal API v3**;
* extracts detection statistics, vendor verdicts and metadata;
* assigns a transparent, configurable risk level;
* records each investigation, with analyst notes and status, in SQLite.

Results are visualised in a dark Streamlit dashboard with Plotly charts and exported as HTML, PDF, JSON and CSV reports. Security is built in:
* the API key lives only in `.env` and is redacted everywhere else;
* rate limits are respected, with a cache;
* the tool only looks things up, never uploads files, and never blocks anything automatically;
* a labelled offline mode allows demonstrations without a key.

## 2. Introduction
Threat intelligence turns raw data about threats into knowledge that supports decisions. IOC enrichment, which means adding context to an IP, domain, URL or hash, is one of the most frequent SOC tasks. VirusTotal aggregates verdicts from dozens of security engines plus community input, which makes it a common first stop. Doing this by hand in a browser is slow and leaves no structured record. This project automates it and keeps the analyst in control.

## 3. Problem statement
Manual lookups:
* are repetitive;
* are inconsistently documented;
* are easy to misinterpret (for example, treating zero detections as "safe");
* make it hard to track indicators over time.

Scripts often hard-code API keys or ignore rate limits. A tool is needed that validates input, queries VirusTotal correctly and politely, interprets the results carefully, keeps a history, and produces reports, all without exposing credentials.

## 4. Project objectives
1. Validate IPv4/IPv6 addresses, domains, URLs and MD5/SHA-1/SHA-256 hashes before any API call.
2. Implement a VirusTotal v3 client with authentication, error handling, timeouts, rate limiting and caching.
3. Extract detection ratio, vendor results and names, reputation, country/ASN, file type, malware classification, last analysis date and related indicators.
4. Classify risk with configurable thresholds, kept distinct from "no detections" and "no report".
5. Support CSV batch analysis that respects quotas.
6. Store the investigation history with search, filters, comparison, notes and status.
7. Provide a Streamlit dashboard with charts, and HTML/PDF/JSON/CSV reports.
8. Protect the API key throughout.

## 5. Existing system
* **The VirusTotal web interface**: excellent for a single lookup, but manual, with no local history, batch reports or custom risk policy.
* **Commercial TIPs** (MISP, OpenCTI, ThreatConnect): powerful but heavy to deploy for a student lab.
* **Ad-hoc scripts**: often hard-code keys, ignore 429 responses, and print raw JSON without interpretation.

## 6. Proposed system
A modular Python application with:
* input validation;
* a careful API client (rate limiter, retry on 429, cache, friendly errors);
* an analysis engine that separates "zero" from "unavailable";
* a demonstration risk classifier with confidence;
* SQLite history with an analyst audit trail;
* a dashboard with charts, and multi-format reports;
* a CLI for scripting;
* a labelled offline mode.

## 7. System architecture
```
UI (app.py / main.py) -> ioc_validator -> virustotal_client (limiter, cache, offline client)
   -> ioc_analyzer -> risk_classifier -> database/history_manager -> report_generator / dashboard charts
settings.py: config, .env key, masking, log redaction
```

## 8. Hardware requirements
| Item | Minimum |
|---|---|
| CPU / RAM | dual-core, 4 GB |
| Disk | 300 MB, plus the database and reports |
| Network | internet access to www.virustotal.com (HTTPS) for live lookups |

## 9. Software requirements
| Item | Version |
|---|---|
| OS | Kali Linux / Ubuntu 22.04+ (also Windows/macOS) |
| Python | 3.10+ |
| Libraries | requests, python-dotenv, pandas, streamlit, plotly, reportlab, pytest |
| Service | VirusTotal account and API key (free community tier works) |
| Browser | for the dashboard and the HTML reports |

## 10. Module descriptions
| Module | Description |
|---|---|
| settings | config validation, `.env` key loading, `mask_key`, `redact`, redacting log filter |
| ioc_validator | `ipaddress`-based IP checks, IDN-aware domain rules, URL parsing, hash length/hex checks, re-fanging, auto-detection |
| virustotal_client | endpoints, `x-apikey` header, timeout, friendly error mapping, `RateLimiter`, 429 retry, cache, `OfflineClient` |
| ioc_analyzer | the `IOCAnalysis` dataclass; per-type metadata; vendor list; detection names; related IOCs; local URL heuristics |
| risk_classifier | thresholds, NO_DETECTIONS / NOT_FOUND, supporting factors, confidence, implications, actions |
| batch_analyzer | CSV parsing and limits, deduplication, rate-limited loop, quota stop, exports |
| database | SQLite schema (investigations, notes, batches, vt_cache, api_calls) |
| history_manager | the Investigator pipeline, search/filter, compare, statistics |
| report_generator | HTML/PDF/JSON/CSV investigation and batch reports, redaction |
| dashboard | Streamlit theme, badges, Plotly helpers |
| app.py / main.py | dashboard and CLI |

## 11. VirusTotal API integration
* **Base URL:** `https://www.virustotal.com/api/v3`. **Header:** `x-apikey: <key>`.
* **Endpoints:**
  * `/ip_addresses/{ip}`
  * `/domains/{domain}` (optionally `/domains/{domain}/resolutions`)
  * `/urls/{id}`, where the id is the URL encoded as URL-safe base64 with the `=` padding removed
  * `/files/{hash}`
* **Errors** arrive as JSON `{"error": {"code", "message"}}`:
  * 404 NotFoundError is shown as "no report";
  * 401 WrongCredentials / AuthenticationRequired and 403 Forbidden are reported clearly;
  * 429 TooManyRequests waits 60 s and retries once;
  * 429 QuotaExceeded stops without retrying;
  * 503 Transient and 504 DeadlineExceeded are reported as temporary problems.
* **Network problems:** timeouts and connection failures become friendly messages.
* **Validation:** responses that are not JSON, or lack `data`, are rejected.
* **Quota:** a local limiter enforces 4 requests per minute and 500 per day (configurable), and successful lookups are cached for 24 hours.

## 12. IOC analysis methodology
From `data.attributes` the analyzer reads:
* `last_analysis_stats`: detections = malicious; total = the sum of all categories;
* `last_analysis_results`: per-engine category and result;
* `reputation` and `total_votes`;
* `last_analysis_date`, converted to UTC and to an age in days;
* type-specific fields:
  * **IP:** country, asn, as_owner, network, regional internet registry;
  * **domain:** registrar, creation_date, last_dns_records, categories;
  * **URL:** url, last_final_url, title, last_http_response_code;
  * **file:** meaningful_name, type_description, size, the hashes, popular_threat_classification.

Missing values become `None` and are displayed as "Not available"; real zeros stay zero. URLs also get local heuristic checks, labelled as not coming from VirusTotal: HTTP, IP host, `@`, punycode, many subdomains, non-standard port, length, lure keywords and executable extensions.

## 13. Risk classification methodology
The level is set by the number of engines reporting malicious:

| Engines reporting malicious | Level |
|---|---|
| 0 | No detections reported |
| 1–3 | Low |
| 4–9 | Medium |
| 10–19 | High |
| 20+ | Critical |

These are demonstration thresholds, set in `config.json`.
* **Raising zero to Low:** when there are zero detections but suspicious verdicts, a reputation of -10 or lower, or more malicious than harmless votes, the level becomes LOW, and the reason is listed.
* **No report:** gives NOT_FOUND, which means unknown.
* **Confidence:** HIGH needs 50 or more engines and an analysis no older than 30 days. MEDIUM needs 20 or more engines and an analysis no older than 180 days. Anything else is LOW.

Every result includes its factors, potential implications and recommended actions. The tool never acts on them automatically.

## 14. Database design
| Table | Contents |
|---|---|
| investigations | id, ioc, ioc_type/subtype, created, source, found, detections, suspicious, total_engines, detection_ratio, risk, confidence, status, conclusion, analysis_json, assessment_json, report_path, batch_id |
| notes | id, investigation_id, timestamp, analyst, note, old_status, new_status (audit trail) |
| batches | id, created, filename, total, summary_json |
| vt_cache | ioc_type, ioc, fetched_at, result_json (cache, 24 h TTL) |
| api_calls | timestamp, ioc_type, http_status (quota tracking, no key or indicator) |

No table stores the API key.

## 15. Implementation
* Python 3 with dataclasses.
* requests with timeouts.
* SQLite with parameterised queries.
* Streamlit with `st.cache_resource` for the database connection.
* Plotly charts, with Streamlit's built-in charts as a fallback.
* ReportLab for the PDFs.
* All HTML output escaped.
* `redact()` applied to every report and log line.
* A CLI built with argparse.
* A labelled offline client fed by a reproducible sample generator.

## 16. Testing and results
**68 automated tests pass in the build environment.** They cover:
* the validator;
* the client against a **mocked HTTP session**: endpoints, header, timeout, every error class, 429 retry, quota stop, cache, network failures;
* the rate limiter with a fake clock;
* API-key protection in the masked display, `repr`, errors, logs and all report formats;
* the analyzer, including zero versus unavailable;
* the risk boundaries;
* batch processing, including a clean stop when the quota runs out;
* history and notes;
* the reports;
* the CLI;
* a dashboard smoke test against a Streamlit stand-in.

An offline demonstration run is in `sample_output/` (synthetic data, labelled). **Live VirusTotal results were not obtainable in the build environment**, which had no network and no key. Add your live results from Tests 1–5 here.

| Test | Indicator | Live result (fill in) |
|---|---|---|
| 1 | 8.8.8.8 | |
| 2 | example.com | |
| 3 | https://example.com/ | |
| 4 | EICAR MD5 / local file SHA-256 | |
| 5 | sample_iocs.csv | |

## 17. Advantages
* Validates input before using quota.
* Interprets results carefully: zero is not called safe, and "no report" is shown as unknown.
* Protects the API key everywhere.
* Respects rate limits and caches results.
* Keeps a full history and an analyst audit trail.
* Exports reports in four formats.
* Works offline for teaching.

## 18. Limitations
* It depends on VirusTotal's coverage and freshness.
* The free tier is slow for large batches and is for non-commercial use.
* Thresholds are not a calibrated risk model.
* Engine verdicts include false positives and false negatives.
* It has only one intelligence source.
* It does not submit unknown URLs or files for analysis, by design.
* The live API and the real Streamlit UI were not exercised in the build environment.

## 19. Future scope
* More sources (AbuseIPDB, Shodan, AlienVault OTX, URLhaus) with weighted scoring.
* MISP / OpenCTI export as STIX.
* Scheduled re-checks with change alerts.
* User accounts and roles.
* Optional, explicit URL submission for scanning.
* Integration with SIEM alerts.

## 20. Conclusion
The dashboard turns VirusTotal's raw API output into structured, recorded and reportable intelligence while handling credentials and quotas responsibly. It shows the core habits of CTI work: validate first, enrich carefully, label uncertainty honestly, and keep the analyst in the loop.
