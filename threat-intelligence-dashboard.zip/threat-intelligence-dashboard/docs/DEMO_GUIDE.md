# Practical demonstration guide

**Preparation:** set `VIRUSTOTAL_API_KEY` in `.env`, run `python3 main.py check-key`, then `streamlit run app.py`.
The public API allows **4 lookups per minute**, so pause between tests or let the app wait for you. Repeat lookups within 24 hours come from the cache.

> Live results depend on VirusTotal at the moment you run each lookup. This guide does **not** predict detection counts or reputations; it describes the *structure* of the output. Use your own live results and screenshots.
> **Before taking a screenshot, check that no API key is visible.** The app only ever shows `********abcd`.

---

## Test 1 - IP investigation: `8.8.8.8`
**Steps:** open *Investigate IP Address*, enter `8.8.8.8`, and click *Investigate* (CLI: `python3 main.py investigate 8.8.8.8`).

**Shows:**
* validation (IPv4);
* the lookup `GET /ip_addresses/8.8.8.8`;
* the detection ratio and engine verdict chart;
* reputation;
* country, ASN, AS owner and network;
* the last analysis date;
* the risk level and confidence;
* a link to the VirusTotal report.

**Explain:**
* The risk level comes from the number of engines reporting *malicious*, compared against configurable demonstration thresholds.
* If the result is **0 detections**, the label reads *No detections reported* and states that this is not proof of safety.

**Also try:** `999.1.1.1`. It is rejected before any API call.

**Screenshots:** the summary cards, the engine verdict chart and the metadata table.

## Test 2 - Domain investigation: `example.com`
**Steps:** *Investigate Domain* → `example.com`.

**Shows:** reputation, detection statistics, registrar, DNS records (when present), categories, and related IPs from A/AAAA records.

**Explain:**
* Fields missing from the response show "Not available". A real 0 is shown as 0.
* Associated historical IPs need `fetch_domain_resolutions: true` in `config.json`, which uses extra quota.

## Test 3 - URL investigation: `https://example.com/`
**Steps:** *Investigate URL* → `https://example.com/`.

**Shows:**
* the URL identifier, built as URL-safe base64 without padding (`/urls/aHR0cHM6Ly9leGFtcGxlLmNvbS8`);
* analysis statistics, final URL, title and HTTP code;
* the **local URL checks**, which are not VirusTotal data.

**Notes:**
* If VirusTotal has never scanned a URL, the app reports **No VirusTotal report**, meaning unknown rather than clean. It does **not** submit the URL for scanning automatically.
* Defanged input such as `hxxps://example[.]com/` is accepted and re-fanged.

## Test 4 - File-hash investigation
Use one of these:
* **The EICAR antivirus test file's MD5** `44d88612fea8a8f36de82e1278abb02f`. This is a publicly documented, harmless test string that antivirus products detect on purpose. Look up the hash only; you don't need the file.
* **A local harmless file:** `sha256sum data/test_files/harmless_test_file.txt`. You can also use the file picker on the hash page, which computes the SHA-256 in your browser session and never uploads the file.

**Shows:**
* hash validation (MD5, SHA-1 or SHA-256 by length);
* the lookup `GET /files/{hash}`;
* detection statistics, file name, type and size;
* the malware classification and family when present.

The harmless local file will usually return **No VirusTotal report**. **Explain** that unknown does not mean clean, and that the tool never uploads files.

## Test 5 - Batch IOC analysis
**Steps:** *Batch IOC Analysis* → upload `data/sample_iocs.csv`, or tick "use the sample". CLI: `python3 main.py batch data/sample_iocs.csv --report`.

**Shows:**
* row-by-row validation (`999.1.1.1` and `not a hash` are INVALID);
* automatic type detection for rows with no type;
* a defanged duplicate detected (DUPLICATE);
* the rate-limit waits ("waiting 60 s...");
* consolidated results with the CSV/JSON export and the batch HTML report.

**Explain:**
* With 12 valid, unique indicators and a limit of 4 per minute, the batch takes about 2–3 minutes: 4 lookups, a wait, 4 more, a wait, then the last 4.
* If the daily quota runs out, the remaining rows are marked SKIPPED and the batch stops cleanly.
* The `.example` / TEST-NET rows are documentation-only indicators. In **live** mode VirusTotal will usually return no report for them; in **offline** mode they return the labelled synthetic samples.

## Offline demonstration (no API key)
```bash
python3 main.py samples
python3 main.py investigate 198.51.100.23 --offline
python3 main.py investigate http://phishing-test.example/login --offline --report html,pdf
python3 main.py batch data/sample_iocs.csv --offline --report
```
Every output carries **OFFLINE SAMPLE - NOT a live VirusTotal result**. Real indicators (8.8.8.8, example.com, EICAR) return "No offline sample exists". This is deliberate, so that offline results can never be mistaken for real ones. The full offline run is in `sample_output/offline_demo_terminal.txt`.

## Analyst workflow
1. Open an investigation, add a note, and set the status (for example FURTHER_INVESTIGATION) with a conclusion.
2. Open *Investigation History* and compare re-lookups of the same IOC over time.
3. Export the report.

Recommended actions are advice only; the tool never blocks anything.
