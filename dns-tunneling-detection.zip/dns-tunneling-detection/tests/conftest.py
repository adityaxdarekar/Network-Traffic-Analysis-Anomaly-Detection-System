import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import DetectionConfig                         # noqa: E402
from database.db_manager import DBManager                  # noqa: E402
from detector.dns_extractor import DNSRecord, build_dns    # noqa: E402
from detector.pcap_io import udp_frame, write_pcap         # noqa: E402

T0 = 1762596000.0


@pytest.fixture
def cfg():
    return DetectionConfig()


@pytest.fixture
def db(tmp_path):
    d = DBManager(tmp_path / "incidents.db")
    yield d
    d.close()


def q(ts, name, qtype="A", src="10.0.0.5", response=False, rcode="NOERROR", txt=0, answers=None):
    """A DNSRecord built directly (for rule tests)."""
    return DNSRecord(T0 + ts, src if not response else "10.0.0.53", "10.0.0.53" if not response else src, 40000, 53,
                     "UDP", 1, response, name, qtype, rcode, answers or [], len(answers or []), txt, 80, int(ts))


@pytest.fixture
def make_q():
    return q


@pytest.fixture
def write_capture(tmp_path):
    def _w(exchanges, name="t.pcap"):
        """exchanges: list of (ts, qname, qtype)."""
        frames = []
        for k, (ts, qname, qtype) in enumerate(exchanges):
            frames.append((T0 + ts, udp_frame("10.0.0.5", "10.0.0.53", 40000 + k, 53, build_dns(k, qname, qtype))))
        p = tmp_path / name
        write_pcap(p, frames)
        return p
    return _w
