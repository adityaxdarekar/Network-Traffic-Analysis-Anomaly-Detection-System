"""Frequency analysis, TXT detection, unique subdomain counting and the other pattern rules."""
import pandas as pd

from config import DetectionConfig
from detector.engine import analyze_records
from detector.frequency_detector import FrequencyAnalyzer, sliding_max
from detector.pattern_detector import PatternDetector, build_query_table, build_response_table
from detector.pcap_analyzer import CaptureResult


def run(records, cfg=None):
    cfg = cfg or DetectionConfig()
    q = build_query_table(records, cfg)
    return PatternDetector(cfg).run(q, build_response_table(records))


def rules(dets, parent=None):
    return {d.rule for d in dets if parent is None or d.parent == parent}


def test_sliding_max():
    assert sliding_max([0, 10, 20, 61, 62], 60) == (4, 10)      # 10..62 within 60 s
    assert sliding_max([0, 30, 60], 60) == (3, 0)          # inclusive window
    assert sliding_max([], 60) == (0, None)


def test_frequency_threshold(make_q):
    over = [make_q(i * 1.0, "status.busy.test") for i in range(51)]
    assert "excessive_frequency" in rules(run(over)[0])
    exactly = [make_q(i * 1.0, "status.busy.test") for i in range(50)]
    assert "excessive_frequency" not in rules(run(exactly)[0])


def test_frequency_uses_time_window(make_q):
    spread = [make_q(i * 2.0, "status.busy.test") for i in range(80)]     # 80 queries over 160 s = 30/min
    assert "excessive_frequency" not in rules(run(spread)[0])
    cfg = DetectionConfig(max_queries_per_source_domain=60)
    assert "excessive_frequency" in rules(run(spread, cfg)[0])


def test_queries_per_source_and_domain(make_q):
    recs = [make_q(i, "a.x.test", src="10.0.0.1") for i in range(3)] + [make_q(i, "b.y.test", src="10.0.0.2")
                                                                       for i in range(5)]
    q = build_query_table(recs, DetectionConfig())
    f = FrequencyAnalyzer(DetectionConfig()).analyze(q)
    assert f["per_source"]["10.0.0.1"] == {"x.test": 3}
    assert f["per_parent"]["y.test"]["queries"] == 5
    top = FrequencyAnalyzer(DetectionConfig()).top_sources(q)
    assert top.iloc[0]["src_ip"] == "10.0.0.2"


def test_txt_detection_per_source(make_q):
    recs = [make_q(i * 5, f"c{i}.txt.test", "TXT") for i in range(10)]
    assert "repeated_txt" in rules(run(recs)[0])
    split = [make_q(i * 5, f"c{i}.txt.test", "TXT", src=f"10.0.0.{i % 2}") for i in range(10)]   # 5 each
    assert "repeated_txt" not in rules(run(split)[0])


def test_unique_subdomain_counting(make_q):
    recs = [make_q(i * 3, f"s{i}.many.test") for i in range(30)] + [make_q(100, "s1.many.test")]
    dets = run(recs)[0]
    d = [x for x in dets if x.rule == "many_unique_subdomains"][0]
    assert "30 distinct subdomains" in d.reason
    assert "many_unique_subdomains" not in rules(run(recs[:29])[0])


def test_long_query_rule(make_q):
    name = "a" * 45 + "." + "b" * 20 + ".long.test"
    dets = run([make_q(0, name)])[0]
    assert "long_query" in rules(dets)
    assert "long_query" not in rules(run([make_q(0, "www.example.com")])[0])


def test_entropy_rule_requires_threshold(make_q):
    rnd = "k3x9q2m7z4w8p1r6t5y0"            # 20 chars, high entropy
    assert "high_entropy" in rules(run([make_q(0, f"{rnd}.e.test")])[0])
    assert "high_entropy" not in rules(run([make_q(0, "documentation.example.com")])[0])


def test_encoded_labels_need_repetition(make_q):
    hexes = [make_q(i, f"{i:02d}4f3a9c0b1e2d7f6a8b9c0d1e2f.enc.test") for i in range(5)]
    assert "encoded_labels" in rules(run(hexes)[0])
    assert "encoded_labels" not in rules(run(hexes[:4])[0])


def test_qtype_distribution(make_q):
    recs = [make_q(i, f"n{i}.example.com") for i in range(7)] + [make_q(10 + i, f"t{i}.odd.test", "TXT")
                                                                  for i in range(3)]
    dets = run(recs)[0]
    assert "unusual_qtype_distribution" in rules(dets, "odd.test")
    assert "unusual_qtype_distribution" not in rules(run(recs[:9])[0])     # only 2/9 unusual


def test_unusual_responses_nxdomain(make_q):
    recs = []
    for i in range(10):
        recs.append(make_q(i, f"x{i}.nx.test"))
        recs.append(make_q(i + 0.01, f"x{i}.nx.test", response=True, rcode="NXDOMAIN" if i < 6 else "NOERROR"))
    dets = run(recs)[0]
    d = [x for x in dets if x.rule == "unusual_responses"][0]
    assert "60% of 10 responses are NXDOMAIN" in d.reason and d.src_ips == ["10.0.0.5"]


def test_allowlist_suppresses(make_q):
    recs = [make_q(i * 0.5, f"s{i}.cdn-hash.test") for i in range(60)]
    assert rules(run(recs)[0])
    assert not run(recs, DetectionConfig(allowlist=["cdn-hash.test"]))[0]


def test_normal_traffic_no_detections(make_q):
    names = ["www.example.com", "mail.example.org", "cdn.example.net", "api.example.com"]
    recs = [make_q(i * 7, names[i % 4], "A" if i % 3 else "AAAA") for i in range(60)]
    res = analyze_records(CaptureResult("n.pcap", "0" * 64, "pcap", "builtin", 60, records=recs), DetectionConfig())
    assert res.detections == [] and res.incidents == []
    assert isinstance(res.domains, pd.DataFrame) and len(res.domains) == 3
