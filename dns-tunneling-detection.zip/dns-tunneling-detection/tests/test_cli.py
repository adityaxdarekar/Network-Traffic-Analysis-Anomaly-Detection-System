"""Terminal tool analyze_pcap.py."""
import analyze_pcap as cli
from config import SAMPLE_DIR


def test_analyze_save_reports(tmp_path, capsys):
    db = str(tmp_path / "i.db")
    assert cli.main([str(SAMPLE_DIR / "sample_dns_traffic.pcap"), "--db", db, "--save", "--pdf",
                     str(tmp_path / "r.pdf"), "--csv", str(tmp_path / "csv")]) == 0
    out = capsys.readouterr().out
    assert "SYNTHETIC" in out and "c2-demo.test" in out and "Critical" in out
    assert (tmp_path / "r.pdf").read_bytes()[:4] == b"%PDF"
    assert {p.name for p in (tmp_path / "csv").iterdir()} == {"dns_queries.csv", "suspicious_domains.csv",
                                                              "incidents.csv"}
    assert cli.main(["--incidents", "--db", db]) == 0
    iid = [ln.split()[0] for ln in capsys.readouterr().out.splitlines() if ln.startswith("DNS-")][0]
    assert cli.main(["--set-status", iid, "Resolved", "--note", "lab test", "--db", db]) == 0


def test_thresholds_and_allowlist(tmp_path, capsys):
    db = str(tmp_path / "i.db")
    cli.main([str(SAMPLE_DIR / "demo_repeated.pcap"), "--db", db, "--max-qpm", "100"])
    assert "No suspicious DNS patterns" in capsys.readouterr().out
    cli.main([str(SAMPLE_DIR / "demo_combined.pcap"), "--db", db, "--allow", "c2-demo.test"])
    assert "No suspicious DNS patterns" in capsys.readouterr().out


def test_bad_input(tmp_path, capsys):
    p = tmp_path / "x.pcap"
    p.write_text("not a capture at all - plain text content")
    assert cli.main([str(p), "--db", str(tmp_path / "i.db")]) == 2
    assert "Error" in capsys.readouterr().out
    assert cli.main([str(SAMPLE_DIR / "demo_txt.pcap"), "--entropy", "50", "--db", str(tmp_path / "i.db")]) == 2
