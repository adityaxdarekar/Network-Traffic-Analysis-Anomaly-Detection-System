"""
Smoke test for app.py with STAND-INS for Streamlit and Plotly (not installable in the
build environment). Every page runs against real analysis of the synthetic captures.
It does not verify the visual layout.
"""
import importlib
import io
import sys
import types

import pytest

from config import SAMPLE_DIR


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeUpload(io.BytesIO):
    def __init__(self, name, data):
        super().__init__(data)
        self.name = name


class FakeSt(types.ModuleType):
    current = None

    def __init__(self):
        super().__init__("streamlit")
        self.session_state, self.calls, self.clicks, self.inputs = {}, [], set(), {}
        self.sidebar = _Ctx()
        self.upload = None
        FakeSt.current = self

    def cache_resource(self, fn=None, **kw):
        return fn if fn else (lambda f: f)

    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def expander(self, *a, **kw):
        return _Ctx()

    def spinner(self, *a, **kw):
        return _Ctx()

    def form(self, *a, **kw):
        return _Ctx()

    def form_submit_button(self, label, **kw):
        return label in self.clicks

    def progress(self, *a, **kw):
        return _Ctx()

    def number_input(self, label, lo=None, hi=None, value=None, **kw):
        return self.inputs.get(label, value)

    def text_area(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def radio(self, label, options, index=0, **kw):
        return self.inputs.get(label, options[index])

    def selectbox(self, label, options, index=0, format_func=None, **kw):
        options = list(options)
        if format_func and options:
            format_func(options[0])
        return self.inputs.get(label, options[index] if options else None)

    def multiselect(self, label, options, default=None, **kw):
        return self.inputs.get(label, default or [])

    def text_input(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def checkbox(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    def date_input(self, label, value=None, **kw):
        return self.inputs.get(label, value)

    def button(self, label, disabled=False, **kw):
        return label in self.clicks and not disabled

    def file_uploader(self, *a, **kw):
        return self.upload

    def download_button(self, label, data, *a, **kw):
        assert data, label
        self.calls.append(("download", label, data))

    def __getattr__(self, name):
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


def fake_plotly():
    calls = []

    class Fig:
        def update_layout(self, **kw):
            pass

    def mk(n):
        def f(*a, **kw):
            calls.append(n)
            return Fig()
        return f
    px = types.ModuleType("plotly.express")
    for n in ("bar", "pie", "line", "histogram", "scatter"):
        setattr(px, n, mk(n))
    pl = types.ModuleType("plotly")
    pl.express = px
    return pl, px, calls


@pytest.fixture(params=["plotly", "no-plotly"])
def app(request, monkeypatch, tmp_path):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    calls = []
    if request.param == "plotly":
        pl, px, calls = fake_plotly()
        monkeypatch.setitem(sys.modules, "plotly", pl)
        monkeypatch.setitem(sys.modules, "plotly.express", px)
    else:
        monkeypatch.setitem(sys.modules, "plotly", None)
        monkeypatch.setitem(sys.modules, "plotly.express", None)
    sys.modules.pop("app", None)
    mod = importlib.import_module("app")
    from database.db_manager import DBManager
    holder = {}

    def get_db(path=None):
        if "db" not in holder:
            holder["db"] = DBManager(tmp_path / "i.db")
        return holder["db"]
    monkeypatch.setattr(mod, "get_db", get_db)
    yield mod, fake, request.param, calls, holder
    if "db" in holder:
        holder["db"].close()


def errors(fake):
    return [c for c in fake.calls if c[0] in ("error", "exception")]


def go(mod, fake, page):
    fake.inputs["Navigation"] = page
    mod.main()


def load_sample(mod, fake, name="sample_dns_traffic.pcap"):
    fake.inputs["Sample capture"] = name
    fake.clicks = {"Analyse sample"}
    go(mod, fake, "PCAP Upload and Analysis")
    fake.clicks = set()


def test_all_pages_without_capture(app):
    mod, fake, *_ = app
    for p in mod.PAGES:
        go(mod, fake, p)
    assert not errors(fake), errors(fake)


def test_all_pages_with_sample(app):
    mod, fake, mode, calls, holder = app
    load_sample(mod, fake)
    assert fake.session_state["result"].stats["incidents"] == 6
    for p in mod.PAGES:
        go(mod, fake, p)
    assert not errors(fake), errors(fake)
    assert any(c[0] == "markdown" and "SYNTHETIC CAPTURE" in str(c[1]) for c in fake.calls)
    if mode == "plotly":
        assert {"bar", "pie", "line", "histogram", "scatter"} <= set(calls)
    assert len(holder["db"].list_incidents()) == 6


def test_upload_valid_and_invalid(app):
    mod, fake, *_ = app
    fake.upload = FakeUpload("lab.pcapng", (SAMPLE_DIR / "demo_combined.pcap").read_bytes())
    fake.clicks = {"Analyse uploaded capture"}
    go(mod, fake, "PCAP Upload and Analysis")
    assert fake.session_state["result"].capture.file_name == "lab.pcapng"
    fake.upload = FakeUpload("notes.txt", b"hello")
    fake.calls.clear()
    go(mod, fake, "PCAP Upload and Analysis")
    assert any(c[0] == "error" and "Upload rejected" in str(c[1]) for c in fake.calls)
    fake.upload = FakeUpload("fake.pcap", b"this is not a capture at all, just text....")
    fake.calls.clear()
    go(mod, fake, "PCAP Upload and Analysis")
    assert any(c[0] == "error" for c in fake.calls)


def test_config_rescoring_and_validation(app):
    mod, fake, *_ = app
    load_sample(mod, fake)
    fake.inputs["Allowlisted parent domains (comma-separated, never flagged)"] = "c2-demo.test"
    fake.clicks = {"Apply"}
    go(mod, fake, "Detection Configuration")
    go(mod, fake, "Security Overview")
    assert fake.session_state["result"].stats["incidents"] == 5
    fake.inputs["Entropy threshold (bits/char)"] = 99.0
    fake.calls.clear()
    go(mod, fake, "Detection Configuration")
    assert any(c[0] == "error" for c in fake.calls)


def test_incident_status_persists(app):
    mod, fake, _, _, holder = app
    load_sample(mod, fake)
    iid = holder["db"].list_incidents()[0]["incident_id"]
    fake.inputs.update({"Open incident": iid, "Set status": "Investigating", "Analyst note": "Demo 7"})
    fake.clicks = {"Save status and note"}
    go(mod, fake, "Incident Management")
    holder["db"].close()
    holder.clear()
    fake.session_state.clear()
    fake.clicks, fake.inputs = set(), {}
    load_sample(mod, fake)
    inc = holder["db"].get_incident(iid)
    assert inc["status"] == "Investigating" and inc["analyst_notes"] == "Demo 7"


def test_reports_downloads(app):
    mod, fake, *_ = app
    load_sample(mod, fake)
    fake.clicks = {"Build PDF report"}
    go(mod, fake, "Reports and Downloads")
    labels = {c[1] for c in fake.calls if c[0] == "download"}
    assert {"DNS query records (CSV)", "Suspicious domains (CSV)", "Incidents (CSV)",
            "Download PDF investigation report"} <= labels
