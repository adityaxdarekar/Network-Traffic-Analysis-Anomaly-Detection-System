"""Shannon entropy, domain splitting, label lengths and encoding classification."""
import math
import random

import pytest

from detector.entropy_analyzer import analyze_name, encoding_class, shannon_entropy, split_domain


@pytest.mark.parametrize("s,h", [("", 0.0), ("aaaa", 0.0), ("ab", 1.0), ("abcd", 2.0), ("aabb", 1.0),
                                 ("0123456789abcdef", 4.0)])
def test_entropy_exact(s, h):
    assert shannon_entropy(s) == pytest.approx(h)


def test_entropy_formula_manual():
    s = "google"           # g:2 o:2 l:1 e:1
    expected = -(2 * (2 / 6) * math.log2(2 / 6) + 2 * (1 / 6) * math.log2(1 / 6))
    assert shannon_entropy(s) == pytest.approx(expected)


def test_random_higher_than_words():
    r = random.Random(1)
    rnd = "".join(r.choice("abcdefghijklmnopqrstuvwxyz234567") for _ in range(50))
    assert shannon_entropy(rnd) > 4.0 > shannon_entropy("documentation")


@pytest.mark.parametrize("name,parent,subs", [
    ("www.example.com", "example.com", ["www"]), ("example.com", "example.com", []),
    ("a.b.c.example.org", "example.org", ["a", "b", "c"]), ("www.bbc.co.uk", "bbc.co.uk", ["www"]),
    ("Ab.Example.COM", "example.com", ["Ab"]), ("10.1.168.192.in-addr.arpa", "in-addr.arpa", ["10", "1", "168", "192"]),
    ("", "", [])])
def test_split_domain(name, parent, subs):
    assert split_domain(name) == (parent, subs)


def test_length_features():
    long_label = "a" * 50
    a = analyze_name(f"{long_label}.x.tunnel.test", 12, 16)
    assert a["parent"] == "tunnel.test" and a["label_count"] == 2
    assert a["total_length"] == len(f"{long_label}.x.tunnel.test")
    assert a["subdomain_length"] == 52 and a["max_label_length"] == 50
    assert a["label_entropies"] == {long_label: 0.0}            # 'x' too short to score


@pytest.mark.parametrize("label,kind", [
    ("4f3a9c0b1e2d7f6a8b9c0d1e2f3a4b5c", "hex"), ("mzxw6ytboi3tqmrsgu4dsnjvgy2q", "base32"),
    ("aGVsbG8gV29ybGQhIFRlc3Q1", "base64-like"), ("x7k2p9q4z8w3r5t1", "random-alnum"),
    ("documentation-portal", None), ("mail", None), ("deadbeef", None)])
def test_encoding_class(label, kind):
    assert encoding_class(label, 16) == kind
