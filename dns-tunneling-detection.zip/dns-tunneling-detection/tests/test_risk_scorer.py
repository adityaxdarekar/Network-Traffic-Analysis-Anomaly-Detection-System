"""Risk scoring, duplicate-indicator handling, SQLite incident persistence, reports."""
import csv
import io

import pytest

from config import DEFAULT_WEIGHTS, SAMPLE_DIR, DetectionConfig
from database.db_manager import DBManager
from detector.engine import analyze_records, run_analysis
from detector.pattern_detector import Detection
from detector.pcap_analyzer import CaptureResult
from detector.risk_scorer import build_incidents, category, score_rules
from utils.report_generator import dns_records_csv, incidents_csv, pdf_report, suspicious_domains_csv


@pytest.mark.parametrize("s,c", [(0, "Low"), (24, "Low"), (25, "Medium"), (49, "Medium"), (50, "High"), (74, "High"),
                                 (75, "Critical"), (100, "Critical")])
def test_categories(s, c):
    assert category(s) == c


def test_brief_weights():
    w = DEFAULT_WEIGHTS
    assert (w["long_query"], w["high_entropy"], w["excessive_frequency"], w["many_unique_subdomains"],
            w["repeated_txt"], w["encoded_labels"]) == (15, 20, 20, 20, 10, 15)
    assert score_rules({"long_query", "high_entropy"}, w)[0] == 35
    assert score_rules(set(w), w)[0] == 100                       # 130 capped


def det(rule, parent="t.test", ts=0.0):
    return Detection(rule, rule, parent, ["10.0.0.5"], ts, "r", "t", 1, [])


def test_duplicate_indicators_count_once(make_q):
    from detector.pattern_detector import build_query_table
    cfg = DetectionConfig()
    q = build_query_table([make_q(0, "a.t.test")], cfg)
    incs = build_incidents([det("high_entropy"), det("high_entropy", ts=5), det("high_entropy", ts=9),
                            det("long_query")], q, cfg, "f" * 64)
    assert len(incs) == 1 and incs[0].score == 35
    assert len(incs[0].detections) == 4                           # evidence kept, points not repeated


def test_incident_per_parent_and_explanation(make_q):
    from detector.pattern_detector import build_query_table
    cfg = DetectionConfig()
    q = build_query_table([make_q(0, "a.one.test"), make_q(1, "b.two.test")], cfg)
    incs = build_incidents([det("repeated_txt", "one.test"), det("excessive_frequency", "two.test"),
                            det("encoded_labels", "two.test")], q, cfg, "f" * 64)
    assert [i.parent for i in incs] == ["two.test", "one.test"]
    assert incs[0].explanation.endswith("= 35")
    assert incs[0].level == "Medium" and incs[1].level == "Low"


def test_custom_weights(make_q):
    from detector.pattern_detector import build_query_table
    cfg = DetectionConfig(weights={**DEFAULT_WEIGHTS, "repeated_txt": 60})
    q = build_query_table([make_q(0, "a.one.test")], cfg)
    assert build_incidents([det("repeated_txt", "one.test")], q, cfg, "f" * 64)[0].level == "High"


def test_incident_id_stable(make_q):
    from detector.pattern_detector import build_query_table
    cfg = DetectionConfig()
    q = build_query_table([make_q(0, "a.t.test")], cfg)
    a = build_incidents([det("long_query")], q, cfg, "a" * 64)[0].incident_id
    assert a == build_incidents([det("high_entropy")], q, cfg, "a" * 64)[0].incident_id
    assert a != build_incidents([det("long_query")], q, cfg, "b" * 64)[0].incident_id


def test_sample_capture_levels():
    res = run_analysis(SAMPLE_DIR / "sample_dns_traffic.pcap", DetectionConfig())
    lv = {i.parent: (i.level, i.score) for i in res.incidents}
    assert lv["c2-demo.test"] == ("Critical", 100)
    assert lv["unique-demo.test"] == ("High", 65)
    assert lv["long-demo.test"][0] == "Medium" and lv["repeat-demo.test"][0] == "Low"
    assert not any(p.endswith(("example.com", "example.org", "example.net")) for p in lv)


def test_invalid_config_rejected():
    with pytest.raises(ValueError):
        run_analysis(SAMPLE_DIR / "demo_normal.pcap", DetectionConfig(entropy_threshold=50))


# ------------------------------------------------------------------ SQLite persistence
def test_incident_persistence_across_restart(tmp_path):
    path = tmp_path / "inc.db"
    db = DBManager(path)
    res = run_analysis(SAMPLE_DIR / "sample_dns_traffic.pcap", DetectionConfig())
    db.save_analysis(res)
    iid = res.incidents[0].incident_id
    assert db.update_status(iid, "Investigating", "host .21 sends 60 TXT queries per minute", "ana")
    db.close()
    db2 = DBManager(path)                                        # restart
    res2 = run_analysis(SAMPLE_DIR / "sample_dns_traffic.pcap", DetectionConfig())
    db2.save_analysis(res2)                                      # re-analysis must not reset status
    inc = db2.get_incident(iid)
    assert inc["status"] == "Investigating" and inc["analyst_notes"].startswith("host .21")
    assert inc["times_detected"] == 2 and inc["notes"][0]["analyst"] == "ana"
    assert {m["incident_id"]: m["status"] for m in db2.merged(res2)}[iid] == "Investigating"
    assert len(db2.analyses()) == 2
    db2.close()


def test_db_filters_and_validation(db):
    res = run_analysis(SAMPLE_DIR / "sample_dns_traffic.pcap", DetectionConfig())
    db.save_analysis(res)
    assert [r["risk_level"] for r in db.list_incidents(levels=["Critical"])] == ["Critical"]
    assert len(db.list_incidents(search="c2-demo")) == 1
    assert len(db.list_incidents(search="192.168.56.20")) == 5
    assert db.list_incidents(search="'; DROP TABLE incidents; --") == []
    with pytest.raises(ValueError):
        db.update_status(res.incidents[0].incident_id, "Deleted")
    assert not db.update_status("DNS-NOPE", "Resolved")


# ------------------------------------------------------------------ reports
def test_reports():
    res = run_analysis(SAMPLE_DIR / "sample_dns_traffic.pcap", DetectionConfig())
    rows = list(csv.reader(io.StringIO(dns_records_csv(res).decode())))
    assert len(rows) == res.stats["dns_packets"] + 1 and rows[0][0] == "frame_no"
    sd = list(csv.reader(io.StringIO(suspicious_domains_csv(res).decode())))
    assert len(sd) == 1 + len(res.incidents)
    inc = list(csv.reader(io.StringIO(incidents_csv([i.to_dict() for i in res.incidents]).decode())))
    assert inc[1][1] == "c2-demo.test"
    pdf = pdf_report(res)
    assert pdf[:4] == b"%PDF" and len(pdf) > 5000


def test_pdf_without_incidents():
    res = analyze_records(CaptureResult("e.pcap", "0" * 64, "pcap", "builtin"), DetectionConfig())
    assert pdf_report(res)[:4] == b"%PDF"
