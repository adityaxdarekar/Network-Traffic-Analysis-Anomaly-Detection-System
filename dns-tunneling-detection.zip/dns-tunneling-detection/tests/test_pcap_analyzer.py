"""PCAP/PCAPNG loading, DNS extraction and parsing, malformed and invalid input."""
import struct

import pytest

from config import SAMPLE_DIR
from detector.dns_extractor import DNSParseError, build_dns, decode_frame, parse_dns, read_name
from detector.pcap_analyzer import analyze_capture
from detector.pcap_io import (CaptureFormatError, checksum_ok, ether, ipv4, tcp_frame, udp, udp_frame, write_pcap,
                              write_pcapng)
from conftest import T0


def test_load_pcap_and_extract_fields(tmp_path):
    qm = build_dns(0x1A2B, "www.example.com", "A")
    rm = build_dns(0x1A2B, "www.example.com", "A", True, 0, [("A", "192.0.2.10")])
    p = tmp_path / "x.pcap"
    write_pcap(p, [(T0, udp_frame("10.0.0.5", "10.0.0.53", 40000, 53, qm)),
                   (T0 + 0.01, udp_frame("10.0.0.53", "10.0.0.5", 53, 40000, rm))])
    res = analyze_capture(p)
    assert res.file_format == "pcap" and res.backend in ("builtin", "scapy")
    assert res.total_packets == 2 and len(res.records) == 2
    q, r = res.records
    assert (q.src_ip, q.dst_ip, q.src_port, q.dst_port, q.protocol) == ("10.0.0.5", "10.0.0.53", 40000, 53, "UDP")
    assert (q.transaction_id, q.qname, q.qtype, q.is_response) == (0x1A2B, "www.example.com", "A", False)
    assert r.is_response and r.rcode == "NOERROR" and r.answers == ["A 192.0.2.10"]
    assert abs(q.timestamp - T0) < 1e-6 and q.packet_size == len(udp_frame("10.0.0.5", "10.0.0.53", 40000, 53, qm))
    s = res.stats()
    assert (s["dns_queries"], s["dns_responses"], s["unique_domains"]) == (1, 1, 1)


def test_pcapng_equals_pcap(tmp_path):
    frames = [(T0 + k, udp_frame("10.0.0.5", "10.0.0.53", 40000, 53, build_dns(k, f"h{k}.example.com", "A")))
              for k in range(5)]
    write_pcap(tmp_path / "a.pcap", frames)
    write_pcapng(tmp_path / "a.pcapng", frames, comment="SYNTHETIC")
    a, b = analyze_capture(tmp_path / "a.pcap"), analyze_capture(tmp_path / "a.pcapng")
    assert [r.qname for r in a.records] == [r.qname for r in b.records]
    assert [r.timestamp for r in a.records] == pytest.approx([r.timestamp for r in b.records])
    assert b.file_format == "pcapng" and b.synthetic


def test_dns_over_tcp(tmp_path):
    p = tmp_path / "t.pcap"
    write_pcap(p, [(T0, tcp_frame("10.0.0.5", "10.0.0.53", 40000, 53, build_dns(9, "big.example.com", "TXT")))])
    r = analyze_capture(p).records[0]
    assert r.protocol == "TCP" and r.qtype == "TXT"


def test_non_dns_and_malformed_counted(tmp_path):
    good = udp_frame("10.0.0.5", "10.0.0.53", 40000, 53, build_dns(1, "ok.example.com", "A"))
    not_dns = udp_frame("10.0.0.5", "10.0.0.9", 40000, 123, b"ntp")
    bad_label = udp_frame("10.0.0.5", "10.0.0.53", 40001, 53, b"\x00\x01\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x3fab")
    short = udp_frame("10.0.0.5", "10.0.0.53", 40002, 53, b"\x00\x01")
    p = tmp_path / "m.pcap"
    write_pcap(p, [(T0, good), (T0 + 1, not_dns), (T0 + 2, bad_label), (T0 + 3, short), (T0 + 4, good[:20])])
    res = analyze_capture(p)
    assert res.total_packets == 5 and len(res.records) == 1 and res.non_dns_packets == 1
    assert res.malformed_packets == 3
    assert {why for _, why in res.malformed_examples} >= {"label runs past end of message",
                                                         "shorter than the 12-byte DNS header"}


def test_truncated_file_stops_cleanly(tmp_path):
    frames = [(T0 + k, udp_frame("10.0.0.5", "10.0.0.53", 40000, 53, build_dns(k, "a.example.com", "A")))
              for k in range(3)]
    p = tmp_path / "trunc.pcap"
    write_pcap(p, frames)
    p.write_bytes(p.read_bytes()[:-10])
    res = analyze_capture(p)
    assert len(res.records) == 2 and res.warnings


@pytest.mark.parametrize("content,msg", [(b"hello world, definitely not a capture file", "magic"),
                                         (b"\xd4\xc3\xb2\xa1", "too small")])
def test_invalid_files(tmp_path, content, msg):
    p = tmp_path / "bad.pcap"
    p.write_bytes(content)
    with pytest.raises(CaptureFormatError) as e:
        analyze_capture(p)
    assert msg in str(e.value)


def test_missing_file(tmp_path):
    with pytest.raises(CaptureFormatError):
        analyze_capture(tmp_path / "nope.pcap")


def test_compression_and_answers():
    m = build_dns(5, "www.example.com", "A", True, 0, [("CNAME", "cdn.example.net"), ("A", "192.0.2.5"),
                                                        ("AAAA", "2001:db8::5"), ("TXT", "v=demo")])
    d = parse_dns(m)
    assert d["answers"] == ["CNAME cdn.example.net", "A 192.0.2.5", "AAAA 2001:db8::5", "TXT 'v=demo'"]
    assert d["txt_bytes"] == 6 and d["answer_count"] == 4


def test_compression_loop_rejected():
    msg = struct.pack("!HHHHHH", 1, 0, 1, 0, 0, 0) + b"\xc0\x0c" + b"\x00\x01\x00\x01"
    with pytest.raises(DNSParseError):
        read_name(msg, 12)


def test_case_preserved_and_rcode():
    d = parse_dns(build_dns(1, "AbCdEf.Example.COM", "TXT", True, 3))
    assert d["qname"] == "AbCdEf.Example.COM" and d["rcode"] == "NXDOMAIN"


def test_ipv6_raw_and_vlan():
    import ipaddress
    dns = build_dns(3, "v6.example.com", "AAAA")
    udp_seg = struct.pack("!HHHH", 40000, 53, 8 + len(dns), 0) + dns
    v6 = struct.pack("!IHBB", 6 << 28, len(udp_seg), 17, 64) + ipaddress.IPv6Address("2001:db8::5").packed + \
        ipaddress.IPv6Address("2001:db8::53").packed + udp_seg
    recs, status = decode_frame(v6, 101, T0, 1)
    assert status == "dns" and recs[0].src_ip == "2001:db8::5"
    inner = ipv4("10.0.0.5", "10.0.0.53", 17, udp("10.0.0.5", "10.0.0.53", 40000, 53, build_dns(4, "vl.example.com")))
    vlan = b"\x02" * 6 + b"\x02" * 6 + b"\x81\x00\x00\x0a\x08\x00" + inner
    recs, status = decode_frame(vlan, 1, T0, 1)
    assert status == "dns" and recs[0].qname == "vl.example.com"


def test_checksums_valid():
    assert checksum_ok(udp_frame("192.168.56.10", "192.168.56.2", 40000, 53, build_dns(1, "x.example.com")))
    assert checksum_ok(tcp_frame("192.168.56.10", "192.168.56.2", 40000, 53, build_dns(1, "x.example.com")))


def test_ethernet_non_ip_ignored():
    recs, status = decode_frame(ether(b"\x00" * 28, etype=0x0806), 1, T0, 1)   # ARP
    assert status == "non-dns" and recs == []


def test_bundled_sample_has_100_plus_dns_packets():
    res = analyze_capture(SAMPLE_DIR / "sample_dns_traffic.pcap")
    s = res.stats()
    assert res.synthetic and s["dns_packets"] >= 100 and s["malformed_packets"] == 2 and s["non_dns_packets"] == 6
    assert s["tcp"] == 2
