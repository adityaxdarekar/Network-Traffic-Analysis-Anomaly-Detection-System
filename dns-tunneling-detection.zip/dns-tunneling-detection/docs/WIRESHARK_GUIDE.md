# Wireshark and TShark Practical Guide (Demo 1)

> Capture only on networks and machines you own or are explicitly authorised to monitor, for example your own lab VM. Capturing other people's traffic without permission is illegal in most countries.

## 1. Install (Kali Linux / Ubuntu)

```bash
sudo apt update
sudo apt install -y wireshark tshark      # answer "Yes" to "Should non-superusers be able to capture packets?"
sudo usermod -aG wireshark $USER          # log out and in again; then capturing needs no sudo
wireshark --version && tshark --version
```

Reading an existing PCAP needs **no** special rights. Only live capture needs the `wireshark` group.

## 2. Capture DNS traffic in your lab

1. **Open Wireshark** from the applications menu or with `wireshark &`.
2. **Select an interface.** The start page lists interfaces with live sparklines. Pick the one carrying your lab traffic, for example `eth0` on a VM, or `enp0s3`. Optional capture filter: `port 53` (BPF syntax), which keeps the file small.
3. **Start capturing** with the blue shark-fin button.
4. **Generate normal DNS traffic** in the lab:
   ```bash
   nslookup example.com
   dig example.org AAAA
   dig example.net TXT
   ```
5. **Stop** with the red square button.

## 3. Display filters

Type a filter into the display-filter bar and press Enter.

| Filter | What it shows |
|---|---|
| `dns` | All packets Wireshark dissects as DNS, on any port Wireshark associates with DNS |
| `dns.qry.name` | Packets that contain a query name. Use it as a column, or match it: `dns.qry.name contains "example"` |
| `dns.qry.type == 16` | Packets whose question type is **16 = TXT** (1 = A, 28 = AAAA, 15 = MX, 10 = NULL, 255 = ANY) |
| `dns.flags.response == 0` | **Queries** only (the QR bit is 0) |
| `dns.flags.response == 1` | **Responses** only (the QR bit is 1) |
| `udp.port == 53` | UDP traffic to or from port 53, the normal DNS transport |
| `tcp.port == 53` | DNS over TCP: zone transfers, large responses, truncated (TC) retries |

These combinations are useful when hunting for tunnelling:

```
dns.flags.response == 0 && len(dns.qry.name) > 50          long query names
dns.qry.type == 16 && dns.flags.response == 0              TXT queries
dns.flags.rcode == 3                                       NXDOMAIN answers
dns && !(ip.dst == 192.168.56.2 || ip.src == 192.168.56.2) DNS not using your resolver
```

## 4. Identify queries and responses

- Click a packet. In the details pane, expand **Domain Name System**. The **Flags** line shows `Response: Message is a query` or `... is a response`, and **Queries** shows the name and type.
- Responses link back to their query (`[Request In: N]`), and Wireshark shows the response time (`[Time: 0.012 s]`).
- **Statistics → DNS** gives counts per query type and response code.
- **Statistics → Conversations / Endpoints** shows which hosts talk the most.

## 5. Inspect suspicious packets

- Right-click the **Name** field and choose **Apply as Column**. Then sort by length or scan for random-looking labels.
- Use **Statistics → Resolved Addresses** (only for names already in the capture), and look at the packet bytes pane for TXT answers.
- Look for these signs:
  - many unique subdomains under one domain;
  - labels close to 63 characters;
  - hexadecimal or Base32 alphabets;
  - steady high query rates from a single host;
  - TXT or NULL types from workstations;
  - lots of NXDOMAIN answers.

## 6. Export the capture

- **File → Save As** and choose **Wireshark/… pcapng** (default) or **pcap**.
- To keep only DNS, apply the `dns` filter, then **File → Export Specified Packets → All packets: Displayed** and save as pcap or pcapng.

## 7. Import into the application

```bash
streamlit run app.py      # PCAP Upload and Analysis -> upload the .pcap/.pcapng -> "Analyse uploaded capture"
python analyze_pcap.py my_lab_capture.pcapng --save --pdf reports/lab.pdf
```

Uploaded captures are analysed in a temporary file, which is deleted after the analysis. Only the results and the file's SHA-256 are stored in the incident database.

## 8. TShark (command line)

```bash
# capture 200 DNS packets on eth0 into a file (needs the wireshark group)
tshark -i eth0 -f "port 53" -c 200 -w lab_dns.pcapng

# read a file, show only queries: time, source, name, type
tshark -r sample_data/sample_dns_traffic.pcap -Y "dns.flags.response == 0" \
       -T fields -e frame.time_relative -e ip.src -e dns.qry.name -e dns.qry.type

# TXT queries only
tshark -r sample_data/sample_dns_traffic.pcap -Y "dns.qry.type == 16 && dns.flags.response == 0" -T fields -e dns.qry.name

# count queries per name (top 10)
tshark -r sample_data/sample_dns_traffic.pcap -Y "dns.flags.response == 0" -T fields -e dns.qry.name \
       | sort | uniq -c | sort -rn | head

# built-in statistics
tshark -r sample_data/sample_dns_traffic.pcap -q -z dns,tree
capinfos sample_data/sample_dns_traffic.pcap
```

## 9. Opening the synthetic sample

Open `sample_data/sample_dns_traffic.pcap` (or `.pcapng`, which carries a "SYNTHETIC" capture comment, shown under **Statistics → Capture File Properties**).

`python run_demos.py` prints the packet counts **predicted by this project's parser** for each filter above:

| Filter | Predicted packets |
|---|---|
| (no filter) | 550 |
| `dns` | 544 |
| `dns.flags.response == 0` | 271 |
| `dns.qry.type == 16` | 170 |
| `tcp.port == 53` | 2 |

These predictions were **not** verified in Wireshark in the build environment, because Wireshark is not installed there. Comparing them during your demo is a good validation step, so note any difference you see.
