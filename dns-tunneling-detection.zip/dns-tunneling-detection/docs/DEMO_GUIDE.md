# Practical Demonstration Guide (Kali Linux / Ubuntu)

- **Demo 1** (Wireshark) is done by hand, following `docs/WIRESHARK_GUIDE.md`.
- **Demos 2–8** use the **SYNTHETIC** captures in `sample_data/`. You can run them in the dashboard (`streamlit run app.py`) or all at once with `python run_demos.py`.
- The output below is the real output of `run_demos.py` from the build environment (`sample_output/demo_results.txt`). The generator is seeded, so you will get the same numbers.
- Do not use unauthorised networks, and do not attempt any real data exfiltration.

---

## Demo 1 — Wireshark DNS capture

1. Follow the Wireshark guide, sections 2–6: capture lab DNS, apply `dns`, then use `dns.flags.response == 0` and `== 1` to identify queries and responses.
2. Export the capture as `lab_dns.pcapng`.
3. Also open `sample_data/sample_dns_traffic.pcap` in Wireshark and compare its counts with the predicted ones:

```
(no filter)                        ->  550 packets
dns                                ->  544 packets
dns.flags.response == 0            ->  271 packets
dns.flags.response == 1            ->  271 packets
dns.qry.type == 16                 ->  170 packets
udp.port == 53                     ->  542 packets
tcp.port == 53                     ->    2 packets
dns.qry.name contains "c2-demo"    ->  120 packets
```

These counts are predicted by this tool's parser and were not checked in Wireshark in the build environment. Note any difference you see.

## Demo 2 — PCAP analysis

**Dashboard:** *PCAP Upload and Analysis*. Upload `lab_dns.pcapng`, or choose `sample_dns_traffic.pcap` and click **Analyse sample**. Then open *DNS Traffic Explorer*.

```
packets 550 | DNS 542 | queries 271 | responses 271 | malformed 2 | non-DNS 6
unique names 171 | parent domains 10 | sources 4 | 2025-11-08 10:00:06 UTC -> 2025-11-08 10:14:10 UTC
top sources: {'192.168.56.20': 167, '192.168.56.21': 60, '192.168.56.10': 23, '192.168.56.11': 21}
query types: {'A': 174, 'AAAA': 10, 'MX': 1, 'PTR': 1, 'TXT': 85}
```

**Explain:**
- Totals are shown separately for packets, DNS packets, queries and responses.
- The two malformed packets are skipped with a reason, such as "label runs past end of message". They don't crash the analysis.
- Use the source-IP and domain filters in the explorer.

## Demo 3 — Long domain detection

**Dashboard:** load `demo_long.pcap`, then open *Suspicious Domain Detection*.

```
Unusually long DNS query: long-demo.test from 192.168.56.20
  reason: 12 queries with long names (max total 122, subdomain 107, label 55, 2 labels)
  threshold: total > 60 or subdomain > 45 or label > 40 or labels > 6
```

**Explain:**
- A normal name like `www.example.com` has 15 characters.
- Tunnels fill labels close to the 63-character DNS limit to carry as much data as possible.
- Long names alone are only 15 points (Low), because some legitimate services use long names too.

## Demo 4 — Entropy analysis

**Dashboard:** *Entropy Analysis*. Try the calculator with `documentation`, then with a random label. Then look at the histogram and the per-domain averages.

```
www                              len  3  entropy 0.00 bits/char
documentation                    len 13  entropy 3.24 bits/char
static-images                    len 13  entropy 3.09 bits/char
607ar1cqzrfnskxi2fguq937foe3uk   len 30  entropy 4.35 bits/char  >= threshold 3.6  random-alnum
incidents: [('entropy-demo.test', 'Medium', 35)] - the normal example.* names in the same capture are not flagged
```

**Explain:**
- The formula is H = −Σ p(c) log₂ p(c).
- Random characters spread probability evenly, so the entropy is close to log₂(alphabet size). Words repeat letters, so their entropy is lower.
- Hex has at most 4 bits per character, so the separate encoded-label rule complements entropy.
- CDN hashes also score high, so entropy alone is never a verdict.

## Demo 5 — Frequency detection

**Dashboard:** load `demo_repeated.pcap`. Check the *Security Overview* charts 7 (frequency by domain) and 8 (timeline).

```
repeat-demo.test: 70 queries, peak 70 within 60 s (threshold 50) starting 2025-11-08 10:06:40 UTC
suspicious activity timeline (whole sample):
  10:06:40  repeat-demo.test   Excessive DNS query frequency
  10:08:20  long-demo.test     Unusually long DNS query
  ...
  10:13:20  c2-demo.test       Excessive DNS query frequency
```

**Explain:**
- A sliding 60-second window is used rather than clock minutes, so a burst that straddles two minutes is still counted in one window.
- Thresholds are configurable, because a busy server or a monitoring script can be normal.

## Demo 6 — Risk scoring

**Dashboard:** *Suspicious Domain Detection*. Select each domain and read the score line.

```
[CRITICAL 100] c2-demo.test       ... 8 rules ... = 100 (capped at 100)
[HIGH      65] unique-demo.test   High-entropy subdomain (20) + Many unique subdomains (20) + Encoded-looking labels (15) + Unusual DNS response pattern (10) = 65
[MEDIUM    35] long-demo.test     High-entropy subdomain (20) + Unusually long DNS query (15) = 35
[LOW       20] repeat-demo.test   Excessive DNS query frequency (20) = 20
```

**Explain:**
- Each rule counts once per domain, so 60 high-entropy queries still add 20 points, not 1,200.
- More *independent* behaviours mean a higher risk.
- The bands are 0–24 Low, 25–49 Medium, 50–74 High and 75–100 Critical.
- The score is heuristic and needs analyst validation.

## Demo 7 — Incident management and persistence

**Dashboard:** *Incident Management* → open the Critical incident (`c2-demo.test`) → **Set status** = Investigating, add a note, click **Save** → stop Streamlit (Ctrl+C) and start it again → load the same sample → open *Incident Management*. The status, note and history are all still there.

```
DNS-D486CF017C (c2-demo.test) set to Investigating; database closed (simulated restart)
after restart + re-analysis: status=Investigating, note='Demo 7: host 192.168.56.21 sends ~70 TXT queries/min ...', detected 2x
```

The incident ID is a hash of the capture's SHA-256 and the domain. Re-analysing the same capture therefore updates the same record and never resets its status.

## Demo 8 — Reports

**Dashboard:** *Reports and Downloads* → **Build PDF report**, then download the PDF and the **Suspicious domains (CSV)** file.

The files are `sample_output/dns_investigation_report.pdf` (5 pages), `suspicious_domains.csv` and `incidents.csv`. The PDF contains:

- the capture name and SHA-256, with the SYNTHETIC banner;
- packet and DNS statistics;
- the risk breakdown;
- suspicious domains and every detected pattern;
- incident details with evidence (example names), analyst notes and recommendations.

**Explain the findings:**
- `c2-demo.test` shows every behaviour of a tunnel: about 70 TXT queries per minute from one host, 101-character Base32-alphabet subdomains (60 of them, all unique), and large TXT answers. The next step is to check the host and process.
- `repeat-demo.test` is only frequent. This is probably a polling script, which is a likely false positive.

## Screenshots to take (dashboard)

1. Overview with all charts.
2. Upload page after the analysis.
3. Traffic explorer with a filter.
4. Entropy page.
5. Domain investigation of `c2-demo.test`.
6. Incident after the restart.
7. Reports page.
8. Configuration page.

The dashboard could not be rendered in the build environment. Terminal and PDF screenshots are in `screenshots/`.
