# Viva Questions and Answers (30)

**1. What is DNS, and what does it do?**
The Domain Name System is a distributed, hierarchical database that translates names into data, such as `www.example.com` → 93.184.x.x. Clients ask a recursive resolver, which queries root servers, then TLD servers, then authoritative servers, and caches the answers.

**2. What is in a DNS query and in a DNS response?**
Both share a 12-byte header:
- a 16-bit transaction ID;
- flags: QR (query or response), opcode, AA, TC, RD, RA and RCODE;
- four section counts.

The query carries the question section (name, type, class). The response repeats the question and adds answer, authority and additional records. The transaction ID matches a response to its query.

**3. Why does DNS use UDP port 53, and when TCP port 53?**
UDP is fast and connectionless, which suits small request/response exchanges. TCP is used for zone transfers (AXFR/IXFR) and when an answer doesn't fit in UDP: the server sets the TC (truncated) bit and the client retries over TCP. RFC 7766 requires TCP support. Over TCP, each message is preceded by a 2-byte length.

**4. Name some DNS record types and their numbers.**

| Type | Number | Content |
|---|---|---|
| A | 1 | IPv4 address |
| NS | 2 | Name server |
| CNAME | 5 | Alias |
| SOA | 6 | Start of authority |
| NULL | 10 | Raw data |
| PTR | 12 | Reverse lookup |
| MX | 15 | Mail server |
| TXT | 16 | Text |
| AAAA | 28 | IPv6 address |
| SRV | 33 | Service location |
| ANY | 255 | All records |

**5. What are TXT records used for legitimately, and why do attackers like them?**
Legitimate uses include SPF, DKIM and DMARC email policies and domain-ownership verification. Attackers like them because TXT answers can carry long arbitrary text, up to 255 bytes per string and several strings per record. That makes them the most efficient way to send commands or data back to a tunnelling client.

**6. What is DNS tunnelling?**
Encapsulating other data in DNS messages:
- **Client to server:** data is encoded in subdomain labels of a domain the attacker controls.
- **Server to client:** data comes back in answers (TXT, NULL, CNAME).

Because resolvers forward unknown names to the authoritative server, the traffic passes through firewalls that allow DNS.

**7. How is DNS tunnelling used for data exfiltration and command-and-control?**
- **Exfiltration:** stolen data is split into chunks, encoded (for example with Base32), and sent as queries such as `chunk42.<data>.evil.example`.
- **Command-and-control (C2):** malware polls with queries and receives commands in TXT answers. Both map to MITRE ATT&CK T1071.004 and T1048.

**8. What are domain labels, and what limits apply?**
Labels are the dot-separated parts of a name: `www`, `example`, `com`. Each label holds 1–63 octets, and the whole name at most 255 octets on the wire (253 characters as text). Hostname labels traditionally use letters, digits and hyphens. These limits force tunnels to use many long labels and many queries.

**9. Why are Base32, Base64 and hexadecimal significant in DNS traffic?**
They turn arbitrary bytes into characters allowed in names:
- **Hex** is safe but doubles the size.
- **Base32** (`a–z`, `2–7`) is case-insensitive, which suits DNS.
- **Base64** needs case and `+` and `/`, so tunnels use modified variants and risk resolvers changing the case.

Long labels in these alphabets, with digits and few vowels, are a strong sign of encoded data.

**10. What is Shannon entropy, and how do you calculate it?**
H = −Σ p(x)·log₂ p(x), summed over the distinct characters, where p(x) is the character's relative frequency. It gives the average bits of "surprise" per character. Examples: "aaaa" has 0, "abcd" has 2, and "documentation" has 3.24 bits per character.

**11. Why can high entropy indicate tunnelling, and why is it not enough?**
Encoded and encrypted data spreads character probabilities evenly, which gives high entropy. But legitimate names are also random-looking: CDN object IDs, DGA-like load-balancer names, anti-virus reputation lookups (hash.domain), DKIM selectors. Short labels also cannot reach high entropy. So entropy is one weighted indicator and never a verdict.

**12. What is a PCAP, and how does PCAPNG differ?**
PCAP (libpcap format) has a 24-byte global header (magic number, version, link type) followed by records, each with a timestamp, captured length, original length and the bytes.

PCAPNG is a block-based format:
- section header and interface description blocks;
- enhanced packet blocks;
- support for multiple interfaces, per-interface timestamp resolution and comments.

Wireshark saves pcapng by default.

**13. What is Wireshark, and what does a display filter do?**
Wireshark is a GUI protocol analyser. It captures packets (through libpcap/Npcap) and dissects every protocol layer. Display filters such as `dns.flags.response == 0` hide non-matching packets without discarding them. They differ from capture filters in BPF syntax (`port 53`), which decide what is recorded at all.

**14. What is TShark?**
Wireshark's command-line version, which uses the same dissectors. Examples:
- `tshark -r file.pcap -Y "dns.qry.type == 16" -T fields -e dns.qry.name` prints the names of TXT packets;
- `-q -z dns,tree` prints DNS statistics.

It is useful for scripting and on servers without a GUI.

**15. What is Scapy, and how does the project use it?**
Scapy is a Python library for reading, building and sending packets. The project uses Scapy's `PcapReader` to read PCAP/PCAPNG when it is installed, and passes the raw frames to its own tested DNS decoder. Without Scapy, a built-in pure-Python reader handles the same formats, so the results are identical either way.

**16. How does the project parse a DNS packet?**
1. Strip the link layer (Ethernet, VLAN or Linux SLL) and the IP header (IPv4 header length, or IPv6 extension headers).
2. Check that the UDP or TCP port is 53 (over TCP, read the 2-byte length prefix).
3. Read the 12-byte header, then decode names label by label, following `0xC0` compression pointers with a jump limit to stop loops.
4. Read the type, class and answers. Every bounds error raises `DNSParseError`, which is counted as a malformed packet.

**17. How is query frequency analysed?**
For each parent domain, the timestamps are sorted and a two-pointer sliding window finds the largest number of queries inside any 60 seconds. The default threshold is more than 50. Per-source totals and short bursts are also measured. Sliding windows don't split a burst at minute boundaries.

**18. Why count unique subdomains per parent domain?**
Every tunnelled chunk must be a new name, otherwise resolvers answer from cache and the data never reaches the attacker. Hundreds of distinct subdomains under one parent within minutes is therefore characteristic of tunnelling. Normal sites use a handful of hostnames.

**19. What is a false positive in this project? Give examples.**
A benign domain flagged as suspicious. Examples:
- anti-virus or reputation services that query hashes as subdomains;
- CDN object names;
- a monitoring script polling one name every second (frequency rule);
- SPF/DKIM TXT lookups by mail servers.

The allowlist, the thresholds and analyst validation handle these cases.

**20. What is a false negative?**
A real tunnel that isn't flagged. For example, a slow tunnel that keeps under the rate thresholds, uses short labels, uses A records, or spreads its traffic over many domains. DNS over HTTPS hides everything from packet captures.

**21. How does the risk score work, and how do you avoid double counting?**
Detections are grouped by parent domain. Only the **set of distinct rules** contributes points: long 15, entropy 20, frequency 20, unique subdomains 20, TXT 10, encoded 15, query-type mix 10, responses 10. The total is capped at 100. Sixty high-entropy queries still give 20 points once, and all sixty remain as evidence.

**22. What do Low, Medium, High and Critical mean?**

| Score | Level | Meaning |
|---|---|---|
| 0–24 | Low | One weak behaviour |
| 25–49 | Medium | Two behaviours |
| 50–74 | High | Several behaviours |
| 75–100 | Critical | Most behaviours together, typical of an active tunnel |

These are priorities for investigation, not probabilities of malice.

**23. Why does the tool never resolve or contact suspicious domains?**
Contacting attacker infrastructure can:
- alert the attacker;
- deliver further commands or payloads;
- leak your organisation's IP address;
- violate policy or law.

Investigation should rely on the captured evidence and on passive intelligence.

**24. How does an analyst investigate an incident in a SOC?**
1. Triage the score and evidence.
2. Identify the internal host and the process that generated the queries (EDR, Sysmon event 22, resolver logs).
3. Estimate how much data could have been carried.
4. Check the domain's age and ownership passively.
5. Decide: contain (block the domain, isolate the host) or close as benign (allowlist it).
6. Document every step in the incident notes.

**25. What is Streamlit, and why is it suitable here?**
A Python framework that turns scripts into web apps with widgets, file upload and charts. The script re-runs on each interaction, and `st.session_state` keeps the loaded analysis. The project re-scores instantly when thresholds change, without re-reading the capture.

**26. How are incidents stored, and why do they survive a restart?**
They are stored in SQLite (`database/incidents.db`). The incident ID is a hash of the capture's SHA-256 and the domain, so re-analysing the same capture produces the same ID. The upsert refreshes the detection data but never overwrites the status or notes, and a notes table keeps the history.

**27. How does the project handle malformed or invalid captures?**
- **Unknown magic number, too small or too large:** a clear error message.
- **Truncated file:** reading stops at the last good packet, with a warning.
- **Malformed packets:** skipped and counted, with reasons such as "label runs past end of message".

The sample capture deliberately includes two malformed packets.

**28. How was the synthetic capture created, and why is it safe?**
A seeded generator builds Ethernet, IPv4, UDP or TCP and DNS bytes, with correct checksums, and writes them to pcap or pcapng **files only**. It uses reserved names (`*.test`, `example.*`), lab and documentation IP ranges, and random strings that carry no data. Nothing is transmitted, and every file is marked SYNTHETIC.

**29. What is the parent domain, and why is extracting it tricky?**
The parent domain is the registrable domain under which the subdomains vary, for example `example.co.uk`, not `co.uk`. Real extraction needs the Public Suffix List. The project uses the last two labels, or three for common multi-part suffixes, which is documented as a limitation.

**30. How would you improve detection further?**
- Per-network baselines and Public Suffix List support.
- Data-volume estimation per host.
- Zeek `dns.log` ingestion.
- Machine-learning models on character n-grams, trained on labelled datasets.
- TCP reassembly.
- Correlation with EDR process data.
- Monitoring for DNS over HTTPS through TLS metadata.
