# DNS Tunneling Detection and Network Traffic Analysis Using Python and Wireshark
### College Project Report

---

## 1. Abstract

DNS is allowed through almost every firewall, which makes it an attractive covert channel. DNS tunnelling encodes data into query names and hides replies in DNS answers, enabling command-and-control (C2) and data exfiltration.

This project implements a defensive analysis system that:

- reads Wireshark captures (PCAP/PCAPNG);
- decodes every DNS query and response, over UDP and TCP;
- evaluates eight heuristics: query length, Shannon entropy, query frequency in sliding windows, unique-subdomain counts, TXT usage, query-type mix, encoded-label patterns and response patterns;
- combines them into an explainable 0–100 risk score per domain, in which each indicator counts only once.

Incidents are stored in SQLite with an analyst workflow. Results are presented on an eight-page Streamlit dashboard and exported to CSV and PDF.

A seeded generator produces a synthetic capture with normal and suspicious scenarios. On it the system separates normal browsing (no alerts) from six suspicious domains across all four risk levels. 85 automated tests pass.

## 2. Problem Statement

Security teams log DNS but rarely analyse it in depth. Tunnelling traffic looks like ordinary DNS at the protocol level, so signature-based tools often miss it, and manual inspection in Wireshark doesn't scale to thousands of queries.

Simple indicators such as "long name" or "random-looking label" also fire on legitimate services: CDNs, anti-virus reputation lookups and telemetry.

The problem is to analyse captured DNS traffic automatically, combine several weak indicators into an explainable assessment, avoid over-counting, and support analysts in validating and documenting suspicious activity, without ever interacting with suspicious infrastructure.

## 3. Project Objectives

1. Parse PCAP and PCAPNG captures and extract all DNS fields (time, IPs, ports, transaction ID, name, type, rcode, answers, size, query/response), robustly handling malformed data.
2. Analyse domain structure: total, subdomain and label lengths, and label counts.
3. Implement Shannon entropy and encoding-pattern detection for subdomain labels.
4. Analyse query frequency with sliding time windows per domain and per source.
5. Implement eight configurable detection rules and support several indicators per incident.
6. Score incidents transparently, with de-duplicated indicators and categories from Low to Critical.
7. Provide a SOC dashboard, domain investigation, incident management with persistence, and reports.
8. Provide a synthetic, Wireshark-compatible sample capture and a practical Wireshark/TShark guide.

## 4. Existing System

| Approach | Limitation |
|---|---|
| Manual Wireshark inspection | Accurate but slow; no scoring, history or reports |
| IDS signatures (Snort/Suricata) | Match known tools; miss custom encodings; rules need expert tuning |
| Passive DNS / SIEM dashboards | Volume statistics only, unless analytics are added; expensive |
| Single-indicator scripts (e.g. "label > 50") | Many false positives (CDNs, AV lookups); no context |
| Commercial DNS security services | Costly, opaque, need traffic redirection |

## 5. Proposed System

The proposed system is an offline, explainable analyser:

- It reads any standard capture without root rights.
- It computes per-query features and per-domain aggregates.
- It applies eight independent heuristics with configurable thresholds and an allowlist.
- It scores each **parent domain** by the number and weight of distinct behaviours.
- It keeps every piece of evidence: the triggering threshold, reason, time and example names.

Analysts validate, annotate and close incidents, and export reports. The tool never contacts suspicious domains.

## 6. Hardware and Software Requirements

| Hardware | Minimum | Recommended |
|---|---|---|
| CPU | Dual-core | Quad-core |
| RAM | 4 GB | 8 GB (large captures) |
| Disk | 500 MB | 2 GB+ for captures |
| Network adapter | Only for live capture in the lab | — |

| Software | Version |
|---|---|
| OS | Kali Linux 2024+, Ubuntu 22.04/24.04 (Windows works for analysis) |
| Python | 3.11+ (tested on 3.13) |
| Wireshark / TShark | 4.x |
| Scapy | 2.5+ (optional; built-in reader otherwise) |
| pandas, NumPy | current |
| Streamlit, Plotly | 1.32+ / 5.18+ |
| ReportLab | 4.x |
| SQLite | bundled with Python |
| pytest | 7+ |

## 7. System Architecture

| Layer | Components |
|---|---|
| Capture | Wireshark/TShark (manual), synthetic generator |
| Ingestion | `pcap_io.py` (PCAP/PCAPNG readers, optional Scapy reader), `pcap_analyzer.py` (limits, hashing, statistics) |
| Decoding | `dns_extractor.py` (link layer → IP → UDP/TCP → DNS) |
| Analysis | `entropy_analyzer.py`, `frequency_detector.py`, `pattern_detector.py` |
| Scoring | `risk_scorer.py` |
| Orchestration | `engine.py` |
| Persistence | `db_manager.py` (SQLite) |
| Presentation | `app.py` (Streamlit/Plotly), `analyze_pcap.py`, `report_generator.py` |

## 8. Data Flow Diagram

**Level 0:**

```
 Lab network ──(Wireshark capture, authorised)──► .pcap/.pcapng ──► [ DNS Tunneling Detection System ]
                                                                         │      ▲
                                                Analyst ◄──(dashboard, reports)  └── thresholds, status, notes
```

**Level 1:**

```
 capture ─► 1 Validate & read ─► frames ─► 2 Decode DNS ─► records ─► 3 Feature extraction ─► query table
                │ warnings              │ malformed count                                     │
                ▼                       ▼                                                     ▼
            statistics ◄────────────────┘                 4 Frequency analysis ─► 5 Rules 1-8 ─► detections
                                                                                               │
                                       D1 incidents (SQLite) ◄── 7 Save ◄── 6 Score per domain ◄┘
                                                │
                                   8 Dashboard / CSV / PDF ◄── analyst status & notes
```

## 9. Use-Case Diagram

```
             ┌──────────────────────── DNS Tunneling Detection System ─────────────────────────┐
             │ (UC1) Load sample capture        (UC2) Upload Wireshark capture                 │
 ┌────────┐  │ (UC3) View overview & charts     (UC4) Explore/filter DNS traffic               │
 │Analyst │──│ (UC5) Analyse entropy            (UC6) Investigate suspicious domain            │
 └────────┘  │ (UC7) Manage incident (status, notes)  (UC8) Download CSV / PDF                 │
             │ (UC9) Configure thresholds, weights, allowlist                                   │
             └──────────────────────────────────────────────────────────────────────────────────┘
 Wireshark/TShark (external) ──► produces the capture used by UC2;  UC1-UC2 «include» Validate capture
```

## 10. Detection Algorithm Flowchart

```
START
 → read capture (reject unknown magic, too small/large) → for each frame:
      decode link → IP (skip non-first fragments) → UDP/TCP port 53? no → count non-DNS
      parse DNS (compression, bounds checks) → error? → count malformed (reason) → next
 → build query table: parent domain, subdomain, lengths, label entropies, encoding classes
 → drop allowlisted parent domains
 → per parent domain:
      R1 long?  R2 entropy ≥ T?  R3 peak 60-s count > N or source total > M?
      R4 unique subdomains ≥ U?  R5 TXT from one source ≥ X?  R7 encoded queries ≥ E?
 → per source: R6 share of TXT/NULL/ANY ≥ r among ≥ n queries? → attach to the parents involved
 → per parent (responses): R8 NXDOMAIN share ≥ p or many large TXT answers?
 → group detections by parent → distinct rules → Σ weights → cap 100 → Low/Medium/High/Critical
 → save incidents (keep analyst status) → display / report
END
```

## 11. Module Descriptions

| Module | Responsibility |
|---|---|
| `pcap_io.py` | Reads pcap (µs/ns, both byte orders) and pcapng (SHB/IDB/EPB/SPB, timestamp resolution option). Uses the Scapy reader when installed. Writes pcap and pcapng. Builds Ethernet/IPv4/UDP/TCP frames with correct checksums. |
| `pcap_analyzer.py` | File checks (exists, size, magic), SHA-256, backend choice, packet limit, statistics (totals, queries/responses, UDP/TCP, types, rcodes, time range), synthetic-marker detection. |
| `dns_extractor.py` | Link types Ethernet/VLAN/SLL/SLL2/raw/loopback; IPv4 (header length, fragments) and IPv6 (extension headers); UDP and TCP (length-prefixed messages); DNS header, questions and answers with compression-loop protection; builders for tests and samples. |
| `entropy_analyzer.py` | Shannon entropy, parent/subdomain split (common multi-part suffixes), encoding classes (hex, Base32, Base64-like, random alphanumeric), per-name feature dictionary. |
| `frequency_detector.py` | Sliding-window maximum, per-parent peak per 60 s, per-source/per-domain counts, bursts, repeated identical names, per-minute time series. |
| `pattern_detector.py` | Query and response tables; the eight rules; `Detection` records with reason, threshold, count and examples. |
| `risk_scorer.py` | Incidents per parent domain, distinct-rule scoring, cap, categories, explanation, recommendations, stable incident IDs. |
| `engine.py` | Runs the complete analysis and builds the domain investigation table. |
| `db_manager.py` | Analyses, incidents (upsert that never overwrites status or notes), notes history, filters. |
| `report_generator.py` | Three CSV files and the PDF. |
| `sample_pcap_generator.py` | Seeded synthetic scenarios 1–7. |
| `app.py` / `analyze_pcap.py` / `run_demos.py` | User interfaces and the demonstration script. |

## 12. Shannon Entropy Explanation

Entropy measures the average information per character:

**H(X) = −Σ p(x) · log₂ p(x)**, where p(x) is the relative frequency of character x in the label.

| Label | H (bits/char) |
|---|---|
| `aaaa` | 0 |
| `mail` | 2.00 |
| `documentation` | 3.24 |
| 30 random letters and digits | ~4.2–4.4 |
| 50 random Base32 characters | ~4.4–4.8 |

The maximum is log₂ of the number of distinct symbols available: 4 for hex, 5 for Base32, about 5.2 for 36 alphanumerics. Short strings cannot reach high values, so only labels of 12 or more characters are scored.

**Why encodings look suspicious.** Hostnames allow only letters, digits and hyphens (case-insensitive), with at most 63 characters per label and 253 per name. Arbitrary bytes must therefore be encoded:

- hexadecimal (16 symbols, 50 % overhead);
- Base32 (32 symbols, `a–z2–7`);
- Base64-like (case-sensitive; DNS may not preserve case).

Encoded or encrypted data is nearly uniformly distributed, so it shows high entropy, few vowels and many digits. Because CDNs, DKIM, anti-virus and telemetry services also use hashes in names, entropy alone is never a verdict.

## 13. DNS Protocol Explanation

DNS translates names into data such as addresses. A **query** from a client (stub resolver) goes to a recursive resolver, usually over UDP port 53. TCP port 53 is used for responses over 512 bytes (traditionally), for TC-bit retries and for zone transfers.

**Message layout:** a 12-byte header (ID, flags QR/OPCODE/AA/TC/RD/RA/RCODE, four counts), then the question (QNAME as length-prefixed labels, QTYPE, QCLASS), then the answer, authority and additional records. Compression pointers (`0xC0xx`) reuse earlier names.

**Common types:**

| Type | Number | Content |
|---|---|---|
| A | 1 | IPv4 address |
| AAAA | 28 | IPv6 address |
| CNAME | 5 | Alias |
| MX | 15 | Mail server |
| TXT | 16 | Arbitrary text |
| NULL | 10 | Raw data |
| PTR | 12 | Reverse lookup |
| ANY | 255 | All records |

**Common response codes:** NOERROR, NXDOMAIN (name does not exist), SERVFAIL, REFUSED.

**How tunnels abuse DNS.** The attacker controls the authoritative server for a domain. Every unique subdomain query is forwarded to that server, and data returns in TXT, NULL or CNAME answers.

## 14. PCAP Analysis Methodology

1. **Validate.** Check existence, size (≤ 200 MB) and magic number (pcap µs/ns in either byte order, or pcapng). Hash the file with SHA-256.
2. **Read** record by record. Implausible lengths or truncation stop reading at the last good packet, with a warning.
3. **Decode** each frame: link layer → IP → transport on port 53 → DNS. Errors are classified ("label runs past end of message", "truncated IPv4 header", …) and counted.
4. **Normalise** into `DNSRecord` objects, then into pandas tables (queries and responses).
5. **Extract features** for each query: parent domain, lengths, label entropies, encoding classes.
6. **Aggregate** per parent domain and per source, using sliding windows.
7. **Detect, score and store.**

No root privileges are required, and no network access happens.

## 15. Risk-Scoring Methodology

| Rule | Weight |
|---|---|
| Long query | 15 |
| High entropy | 20 |
| Excessive frequency | 20 |
| Many unique subdomains | 20 |
| Repeated TXT | 10 |
| Encoded labels | 15 |
| Query-type mix | 10 |
| Unusual responses | 10 |

- **Score** = Σ weights of the **distinct** rules triggered for a parent domain, capped at 100. Repetitions don't add points, but every occurrence stays in the evidence.
- **Bands:** 0–24 Low · 25–49 Medium · 50–74 High · 75–100 Critical.
- **Rationale:** a single indicator has many benign explanations, but several independent indicators on the same domain rarely co-occur by chance.
- **Configurable:** thresholds, weights and the allowlist can all be changed.
- **Limitation:** this is a heuristic, not a probability. It requires analyst validation.

**Sample results:**

| Domain | Score | Level | Rules triggered |
|---|---|---|---|
| `c2-demo.test` | 100 | Critical | all 8 rules |
| `unique-demo.test` | 65 | High | entropy + unique + encoded + responses |
| `long-demo.test` | 35 | Medium | entropy + long |
| `entropy-demo.test` | 35 | Medium | entropy + encoded |
| `repeat-demo.test` | 20 | Low | frequency |
| `txt-demo.test` | 20 | Low | TXT + responses |

## 16. Database Schema

| Table | Columns |
|---|---|
| analyses | id PK, analysed_at, file_name, file_sha256, synthetic, total_packets, dns_packets, dns_queries, incidents, settings JSON |
| incidents | incident_id PK (SHA-1 of capture hash + domain), parent_domain, file_name, file_sha256, synthetic, risk_score, risk_level, rules JSON, src_ips JSON, query_count, unique_subdomains, first_seen, last_seen, details JSON, status CHECK(Open/Investigating/Resolved), analyst_notes, created_at, updated_at, times_detected |
| incident_notes | id PK, incident_id FK (cascade), noted_at, analyst, status, note |

All queries are parameterised. Notes are stripped of control characters and limited to 2,000 characters.

## 17. Testing Methodology

85 pytest tests, run with `python -m pytest -q`. The expected result is `85 passed` in about 3 seconds.

| File | Coverage |
|---|---|
| `test_pcap_analyzer.py` | PCAP loading and field extraction, pcap = pcapng results, DNS over TCP, non-DNS and malformed counting, truncated file, invalid and too-small files, compression and answers, compression loop, case and rcode, IPv6 raw and VLAN, checksums, ARP ignored, sample ≥ 100 DNS packets |
| `test_entropy.py` | Exact entropy values, manual formula, random > words, domain splitting (incl. co.uk, in-addr.arpa), length features, encoding classes |
| `test_frequency_detector.py` | Sliding window, threshold boundary (50 vs 51), time-window vs total, per-source counts, TXT per source, unique-subdomain counting, long, entropy, encoded repetition, query-type mix, NXDOMAIN, allowlist, normal traffic gives no detections |
| `test_risk_scorer.py` | Bands, brief weights, cap, duplicate indicators counted once, one incident per domain, custom weights, stable IDs, sample levels, invalid config, **SQLite persistence across restart and re-analysis**, filters, SQL-injection input, reports |
| `test_cli.py` | Analyse, save, PDF, CSV, incidents, status, thresholds, allowlist, bad input |
| `test_app_smoke.py` | All 8 pages with and without a capture, upload valid/invalid, re-scoring, status persistence, downloads; with Streamlit and Plotly stand-ins |

Demonstration testing: `python run_demos.py` runs Demos 1–8 and reports PASS/FAIL.

## 18. Sample Output Descriptions

| File | Content |
|---|---|
| `sample_output/demo_results.txt` | The full run of all demonstrations: statistics, detections, timeline, scores, persistence |
| `sample_output/cli_analyze_sample.txt` | Incident and detection tables for the mixed sample |
| `sample_output/cli_analyze_normal.txt` | The normal capture: 88 DNS packets, 0 incidents |
| `sample_output/dns_investigation_report.pdf` | 5 pages: statistics, risk breakdown, suspicious domains, 19 detections, 6 incident sections with evidence and recommendations, SYNTHETIC banner |
| `sample_output/suspicious_domains.csv`, `incidents.csv` | The CSV exports |
| `screenshots/` | Terminal outputs and PDF pages |

## 19. Advantages and Limitations

**Advantages**

- Multiple independent indicators, with transparent, de-duplicated scoring.
- Every alert explains its reason, threshold and evidence.
- Configurable thresholds, weights and allowlist.
- Offline and safe: no root rights, no network access, no contact with suspicious domains.
- Works without Scapy (a built-in parser) and uses Scapy when available.
- Persistent incident workflow and professional reports.

**Limitations**

- **Heuristic.** Legitimate services (CDN hashes, anti-virus lookups such as `*.avqs.*`, DKIM, telemetry) can trigger rules. Use the allowlist.
- **Evasion.** Slow, low-volume tunnels with short labels can stay under the thresholds.
- **No TCP stream reassembly.** DNS messages split across TCP segments are reported as incomplete.
- **Encrypted DNS** (DNS over HTTPS/TLS/QUIC) is invisible in packet captures.
- **Heuristic parent domain.** It uses a small list of multi-part suffixes, not the full Public Suffix List.
- **Memory.** The whole capture is processed in memory, up to 200 MB and 2 million packets.
- **Not verified in the build environment:**
  - Wireshark and TShark were not available, so the synthetic capture was validated with the project's own reader and the `file` utility, and the Wireshark filter counts are predictions.
  - Scapy was not available, so only the built-in reader was executed.
  - The Streamlit UI was smoke-tested with stand-in modules but not rendered.

## 20. Future Enhancements

- Live capture mode (Scapy `sniff` or `tshark -l`) with rolling windows.
- Zeek `dns.log` and passive-DNS ingestion; SIEM export (JSON lines, syslog).
- The Public Suffix List for exact registered domains, and per-network baselines.
- Machine-learning models (e.g. character n-gram or isolation forest) with labelled public datasets, combined with the heuristics.
- Byte-volume estimation per domain and per host, and domain-age or reputation enrichment (opt-in, never contacting the domain).
- TCP stream reassembly; DoH detection via TLS SNI or JA3 heuristics.

## 21. Conclusion

The project shows that DNS tunnelling leaves several measurable traces: long, random-looking, encoded and ever-changing names; high query rates; TXT-heavy behaviour; and unusual answers. Combining these traces gives far more reliable leads than any single indicator.

The system parses real Wireshark captures, explains every finding, avoids over-counting, and supports the analyst from detection to documented resolution. On the synthetic lab capture it raised no alert for normal browsing and ranked the suspicious domains sensibly from Low to Critical. The limitations above make clear that it is a triage and teaching tool, whose results always need human validation.

## 22. References

1. RFC 1034 / RFC 1035, *Domain Names — Concepts and Facilities / Implementation and Specification*, 1987.
2. RFC 7766, *DNS Transport over TCP — Implementation Requirements*, 2016.
3. RFC 4648, *The Base16, Base32, and Base64 Data Encodings*, 2006.
4. RFC 2606 / RFC 6761, *Reserved Top Level DNS Names* / *Special-Use Domain Names*.
5. RFC 5737, *IPv4 Address Blocks Reserved for Documentation*.
6. C. E. Shannon, "A Mathematical Theory of Communication", *Bell System Technical Journal*, 1948.
7. MITRE ATT&CK T1071.004 *Application Layer Protocol: DNS*, and T1048 *Exfiltration Over Alternative Protocol*.
8. Wireshark User's Guide and Display Filter Reference (DNS); TShark manual page.
9. libpcap file format (pcap) and *PCAP Next Generation (pcapng) Capture File Format* (IETF draft).
10. Scapy documentation; pandas and NumPy documentation; Streamlit and Plotly documentation; ReportLab user guide.
11. SANS Institute, *Detecting DNS Tunneling* (whitepaper).
12. NIST SP 800-61 Rev. 2, *Computer Security Incident Handling Guide*.
