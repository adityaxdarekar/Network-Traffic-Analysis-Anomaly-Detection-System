"""
pcap_analyzer.py - load a PCAP/PCAPNG capture and extract every DNS message.

    result = analyze_capture("sample_data/sample_dns_traffic.pcap")
    result.records      -> list[DNSRecord]
    result.frame()      -> pandas DataFrame (one row per DNS message)
    result.stats()      -> totals for the dashboard

Backends: Scapy is used to read the capture when it is installed ("scapy");
otherwise the built-in pure-Python reader ("builtin") is used. Both feed the
same DNS decoder. No root/administrator rights are needed: files are only read.

Robustness: an invalid file raises CaptureFormatError with a readable
message; truncated files stop at the last good packet with a warning;
malformed packets are counted with their reason and never stop the analysis.
"""
from __future__ import annotations

import hashlib
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from config import MAX_PACKETS, MAX_UPLOAD_MB
from detector.dns_extractor import decode_frame
from detector.pcap_io import CaptureFormatError, detect_format, iter_packets, iter_packets_scapy

COLUMNS = ["frame_no", "time", "timestamp", "src_ip", "dst_ip", "src_port", "dst_port", "protocol", "direction",
           "transaction_id", "qname", "qtype", "rcode", "answers", "answer_count", "txt_answer_bytes", "packet_size"]


def scapy_available() -> bool:
    try:
        import scapy.utils  # noqa: F401
        return True
    except Exception:
        return False


@dataclass
class CaptureResult:
    file_name: str
    file_sha256: str
    file_format: str
    backend: str
    total_packets: int = 0
    non_dns_packets: int = 0
    malformed_packets: int = 0
    records: list = field(default_factory=list)
    malformed_examples: list = field(default_factory=list)     # (frame_no, reason)
    warnings: list = field(default_factory=list)
    synthetic: bool = False

    def frame(self) -> pd.DataFrame:
        if not self.records:
            return pd.DataFrame(columns=COLUMNS)
        df = pd.DataFrame([r.to_dict() for r in self.records])
        df["time"] = pd.to_datetime(df["timestamp"], unit="s", utc=True).dt.tz_convert(None)
        return df[COLUMNS]

    def stats(self) -> dict:
        q = [r for r in self.records if not r.is_response]
        resp = [r for r in self.records if r.is_response]
        ts = [r.timestamp for r in self.records]
        return {"total_packets": self.total_packets, "dns_packets": len(self.records), "dns_queries": len(q),
                "dns_responses": len(resp), "malformed_packets": self.malformed_packets,
                "non_dns_packets": self.non_dns_packets, "unique_domains": len({r.qname for r in q if r.qname}),
                "unique_sources": len({r.src_ip for r in q}), "qtype_counts": dict(Counter(r.qtype for r in q)),
                "rcode_counts": dict(Counter(r.rcode for r in resp)),
                "udp": sum(1 for r in self.records if r.protocol == "UDP"),
                "tcp": sum(1 for r in self.records if r.protocol == "TCP"),
                "first_ts": min(ts) if ts else None, "last_ts": max(ts) if ts else None}


def analyze_capture(path, dns_ports=(53,), backend: str = "auto", display_name: str | None = None,
                    max_packets: int = MAX_PACKETS) -> CaptureResult:
    p = Path(path)
    if not p.is_file():
        raise CaptureFormatError(f"file not found: {p.name}")
    size = p.stat().st_size
    if size > MAX_UPLOAD_MB * 1024 * 1024:
        raise CaptureFormatError(f"capture is larger than {MAX_UPLOAD_MB} MB")
    if size < 24:
        raise CaptureFormatError("file is too small to be a capture")
    with p.open("rb") as fh:
        head = fh.read(4)
        fmt = detect_format(head)
        h = hashlib.sha256(head)
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    use_scapy = backend == "scapy" or (backend == "auto" and scapy_available())
    res = CaptureResult(display_name or p.name, h.hexdigest(), fmt, "scapy" if use_scapy else "builtin")
    reader = iter_packets_scapy if use_scapy else iter_packets
    ports = tuple(dns_ports)
    try:
        for n, (ts, lt, data) in enumerate(reader(p, res.warnings), 1):
            if n > max_packets:
                res.warnings.append(f"stopped after {max_packets} packets (limit)")
                break
            res.total_packets += 1
            recs, status = decode_frame(data, lt, ts, n, ports)
            if status == "dns":
                res.records.extend(recs)
            elif status == "non-dns":
                res.non_dns_packets += 1
            else:
                res.malformed_packets += 1
                if len(res.malformed_examples) < 50:
                    res.malformed_examples.append((n, status.split(":", 1)[1]))
    except CaptureFormatError:
        raise
    except Exception as exc:          # a broken file must never crash the app
        res.warnings.append(f"reading stopped: {type(exc).__name__}: {exc}")
    res.synthetic = _is_synthetic(p)
    return res


def _is_synthetic(p: Path) -> bool:
    """Synthetic captures made by utils/sample_pcap_generator.py carry a SYNTHETIC marker (pcapng comment or a
    sidecar .synthetic file next to the .pcap)."""
    if p.with_suffix(p.suffix + ".synthetic").exists():
        return True
    with p.open("rb") as fh:
        return b"SYNTHETIC" in fh.read(4096)


def fmt_ts(ts) -> str:
    if ts is None:
        return "-"
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
