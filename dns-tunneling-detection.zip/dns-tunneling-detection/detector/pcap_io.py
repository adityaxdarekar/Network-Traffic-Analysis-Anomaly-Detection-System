"""
pcap_io.py - read and write classic PCAP and PCAPNG files without external tools.

Readers yield (timestamp_seconds, linktype, frame_bytes). They validate block
lengths and stop cleanly (recording a warning) at a truncated or corrupt
record instead of crashing. Writers produce standard files that Wireshark,
TShark and Scapy open (libpcap 2.4 / pcapng 1.0, Ethernet link type).

Frame builders create Ethernet/IPv4/UDP and Ethernet/IPv4/TCP frames with
correct IPv4 header and UDP/TCP checksums for the synthetic sample capture.
"""
from __future__ import annotations

import struct
from pathlib import Path

PCAP_MAGICS = {b"\xd4\xc3\xb2\xa1": ("<", 1e-6), b"\xa1\xb2\xc3\xd4": (">", 1e-6),
               b"\x4d\x3c\xb2\xa1": ("<", 1e-9), b"\xa1\xb2\x3c\x4d": (">", 1e-9)}
PCAPNG_SHB = b"\x0a\x0d\x0d\x0a"


class CaptureFormatError(ValueError):
    pass


def detect_format(head: bytes) -> str:
    if head[:4] in PCAP_MAGICS:
        return "pcap"
    if head[:4] == PCAPNG_SHB:
        return "pcapng"
    raise CaptureFormatError("not a PCAP or PCAPNG file (unknown magic number)")


def iter_pcap(fh, warnings: list):
    hdr = fh.read(24)
    if len(hdr) < 24:
        raise CaptureFormatError("PCAP global header is truncated")
    endian, unit = PCAP_MAGICS[hdr[:4]]
    linktype = struct.unpack(endian + "I", hdr[20:24])[0] & 0x0FFFFFFF
    n = 0
    while True:
        rh = fh.read(16)
        if not rh:
            return
        if len(rh) < 16:
            warnings.append(f"record header truncated after {n} packets - stopped reading")
            return
        sec, frac, incl, _orig = struct.unpack(endian + "IIII", rh)
        if incl > 262_144:
            warnings.append(f"implausible packet length {incl} after {n} packets - stopped reading")
            return
        data = fh.read(incl)
        if len(data) < incl:
            warnings.append(f"packet {n + 1} is truncated - stopped reading")
            return
        n += 1
        yield sec + frac * unit, linktype, data


def iter_pcapng(fh, warnings: list):
    endian = "<"
    interfaces = []          # [(linktype, timestamp divisor)]
    n = 0
    while True:
        head = fh.read(8)
        if not head:
            return
        if len(head) < 8:
            warnings.append("block header truncated - stopped reading")
            return
        btype_raw = head[:4]
        if btype_raw == PCAPNG_SHB:
            bom = fh.read(4)
            if bom == b"\x4d\x3c\x2b\x1a":
                endian = "<"
            elif bom == b"\x1a\x2b\x3c\x4d":
                endian = ">"
            else:
                raise CaptureFormatError("bad PCAPNG byte-order magic")
            blen = struct.unpack(endian + "I", head[4:8])[0]
            if blen < 28 or blen % 4:
                raise CaptureFormatError("bad PCAPNG section header length")
            fh.read(blen - 12)
            interfaces = []
            continue
        btype, blen = struct.unpack(endian + "II", head)
        if blen < 12 or blen % 4 or blen > 16_777_216:
            warnings.append(f"invalid block length {blen} - stopped reading")
            return
        body = fh.read(blen - 8)
        if len(body) < blen - 8:
            warnings.append("block truncated - stopped reading")
            return
        body = body[:-4]                     # trailing block length
        if btype == 1:                       # Interface Description Block
            linktype = struct.unpack(endian + "H", body[:2])[0]
            divisor = 10 ** 6                # default: microseconds
            opt = body[8:]
            i = 0
            while i + 4 <= len(opt):
                code, olen = struct.unpack(endian + "HH", opt[i:i + 4])
                if code == 0:
                    break
                if code == 9 and olen >= 1:  # if_tsresol
                    r = opt[i + 4]
                    divisor = 2 ** (r & 0x7F) if r & 0x80 else 10 ** r
                i += 4 + olen + ((4 - olen % 4) % 4)
            interfaces.append((linktype, divisor))
        elif btype == 6:                     # Enhanced Packet Block
            if len(body) < 20:
                warnings.append("EPB too short - skipped")
                continue
            iface, th, tl, cap, _orig = struct.unpack(endian + "IIIII", body[:20])
            if iface >= len(interfaces):
                warnings.append("EPB references an unknown interface - skipped")
                continue
            lt, divisor = interfaces[iface]
            data = body[20:20 + cap]
            n += 1
            yield ((th << 32) | tl) / divisor, lt, data
        elif btype == 3:                     # Simple Packet Block (no timestamp)
            if interfaces:
                orig = struct.unpack(endian + "I", body[:4])[0]
                n += 1
                yield 0.0, interfaces[0][0], body[4:4 + orig]
        # other block types (statistics, name resolution, custom) are ignored


def iter_packets(path, warnings: list):
    """Yield (timestamp, linktype, bytes) from a PCAP or PCAPNG file using the built-in reader."""
    fh = open(path, "rb")
    try:
        head = fh.read(4)
        fmt = detect_format(head)
        fh.seek(0)
        yield from (iter_pcap(fh, warnings) if fmt == "pcap" else iter_pcapng(fh, warnings))
    finally:
        fh.close()


def iter_packets_scapy(path, warnings: list):
    """Read with Scapy (if installed): Scapy handles the container formats, the raw frame bytes then go through
    the same DNS decoder as the built-in reader, so results are identical."""
    from scapy.utils import PcapReader            # PcapReader opens both pcap and pcapng
    from scapy.layers.l2 import CookedLinux, Ether
    from scapy.layers.inet import IP
    from scapy.layers.inet6 import IPv6
    with PcapReader(str(path)) as rd:
        for pkt in rd:
            if isinstance(pkt, Ether):
                lt = 1
            elif isinstance(pkt, CookedLinux):
                lt = 113
            elif isinstance(pkt, (IP, IPv6)):
                lt = 101
            else:
                warnings.append(f"unsupported link layer {type(pkt).__name__} - skipped")
                continue
            yield float(pkt.time), lt, bytes(pkt)


# ---------------------------------------------------------------- writers
def write_pcap(path, frames, linktype: int = 1) -> int:
    """frames: iterable of (timestamp, bytes)."""
    n = 0
    with open(path, "wb") as fh:
        fh.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 262144, linktype))
        for ts, data in frames:
            sec = int(ts)
            usec = int(round((ts - sec) * 1e6))
            if usec >= 1_000_000:
                sec, usec = sec + 1, usec - 1_000_000
            fh.write(struct.pack("<IIII", sec, usec, len(data), len(data)) + data)
            n += 1
    return n


def _pad4(b: bytes) -> bytes:
    return b + b"\x00" * ((4 - len(b) % 4) % 4)


def write_pcapng(path, frames, linktype: int = 1, comment: str = "") -> int:
    def block(btype, body):
        body = _pad4(body)
        ln = 12 + len(body)
        return struct.pack("<II", btype, ln) + body + struct.pack("<I", ln)

    opts = b""
    if comment:
        c = comment.encode("utf-8")
        opts = struct.pack("<HH", 1, len(c)) + _pad4(c) + struct.pack("<HH", 0, 0)
    shb = struct.pack("<IHHq", 0x1A2B3C4D, 1, 0, -1) + opts
    idb = struct.pack("<HHI", linktype, 0, 262144) + struct.pack("<HHB", 9, 1, 6) + b"\x00\x00\x00" + \
        struct.pack("<HH", 0, 0)
    n = 0
    with open(path, "wb") as fh:
        fh.write(block(0x0A0D0D0A, shb))
        fh.write(block(1, idb))
        for ts, data in frames:
            t = int(round(ts * 1e6))
            fh.write(block(6, struct.pack("<IIIII", 0, t >> 32, t & 0xFFFFFFFF, len(data), len(data)) + data))
            n += 1
    return n


# ---------------------------------------------------------------- frame builders
def _csum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    s = sum(struct.unpack(f"!{len(data) // 2}H", data))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF


def _ip_bytes(ip: str) -> bytes:
    return bytes(int(x) for x in ip.split("."))


def ipv4(src: str, dst: str, proto: int, payload: bytes, ident: int = 0) -> bytes:
    hdr = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(payload), ident & 0xFFFF, 0x4000, 64, proto, 0,
                      _ip_bytes(src), _ip_bytes(dst))
    return hdr[:10] + struct.pack("!H", _csum(hdr)) + hdr[12:] + payload


def udp(src: str, dst: str, sport: int, dport: int, payload: bytes) -> bytes:
    ln = 8 + len(payload)
    pseudo = _ip_bytes(src) + _ip_bytes(dst) + struct.pack("!BBH", 0, 17, ln)
    seg = struct.pack("!HHHH", sport, dport, ln, 0) + payload
    c = _csum(pseudo + seg) or 0xFFFF
    return seg[:6] + struct.pack("!H", c) + seg[8:]


def tcp(src: str, dst: str, sport: int, dport: int, payload: bytes, seq: int = 1, ack: int = 1,
        flags: int = 0x18) -> bytes:
    seg = struct.pack("!HHIIBBHHH", sport, dport, seq, ack, 5 << 4, flags, 64240, 0, 0) + payload
    pseudo = _ip_bytes(src) + _ip_bytes(dst) + struct.pack("!BBH", 0, 6, len(seg))
    c = _csum(pseudo + seg)
    return seg[:16] + struct.pack("!H", c) + seg[18:]


def ether(payload: bytes, src_mac: bytes = b"\x02\x00\x00\x00\x00\x01", dst_mac: bytes = b"\x02\x00\x00\x00\x00\x02",
          etype: int = 0x0800) -> bytes:
    return dst_mac + src_mac + struct.pack("!H", etype) + payload


def udp_frame(src, dst, sport, dport, dns: bytes, ident=0) -> bytes:
    return ether(ipv4(src, dst, 17, udp(src, dst, sport, dport, dns), ident))


def tcp_frame(src, dst, sport, dport, dns: bytes, ident=0, seq=1, ack=1) -> bytes:
    return ether(ipv4(src, dst, 6, tcp(src, dst, sport, dport, struct.pack("!H", len(dns)) + dns, seq, ack), ident))


def checksum_ok(frame: bytes) -> bool:
    """Verify IPv4 header and UDP/TCP checksums of an Ethernet/IPv4 frame (used by tests)."""
    ip = frame[14:]
    ihl = (ip[0] & 0xF) * 4
    if _csum(ip[:ihl]) != 0:
        return False
    proto, src, dst = ip[9], ip[12:16], ip[16:20]
    seg = ip[ihl:struct.unpack("!H", ip[2:4])[0]]
    pseudo = src + dst + struct.pack("!BBH", 0, proto, len(seg))
    return _csum(pseudo + seg) == 0


__all__ = ["CaptureFormatError", "detect_format", "iter_packets", "iter_packets_scapy", "write_pcap", "write_pcapng",
           "udp_frame", "tcp_frame", "checksum_ok", "Path"]
