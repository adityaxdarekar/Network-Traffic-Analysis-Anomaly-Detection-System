"""
pattern_detector.py - the eight DNS tunnelling heuristics.

  1 long_query                 query name / subdomain / label longer than the thresholds
  2 high_entropy               a subdomain label with Shannon entropy >= threshold
  3 excessive_frequency        > N queries to one parent domain within 60 s, or > M from one
                               source to one parent, or a burst from one source
  4 many_unique_subdomains     >= N distinct subdomains under one parent domain
  5 repeated_txt               >= N TXT queries from one source to one parent
  6 unusual_qtype_distribution a source whose queries are mostly TXT/NULL/ANY/... types
  7 encoded_labels             repeated hex / Base32 / Base64-like labels under one parent
  8 unusual_responses          many NXDOMAIN answers or many large TXT answers for one parent

Each Detection names the rule, parent domain, source IP(s), first timestamp,
reason, triggered threshold and example evidence. Detections are evidence
of SUSPICIOUS behaviour, never proof of DNS tunnelling.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass, field

import pandas as pd

from detector.entropy_analyzer import analyze_name
from detector.frequency_detector import FrequencyAnalyzer

RULE_NAMES = {
    "long_query": "Unusually long DNS query",
    "high_entropy": "High-entropy subdomain",
    "excessive_frequency": "Excessive DNS query frequency",
    "many_unique_subdomains": "Many unique subdomains under one domain",
    "repeated_txt": "Repeated TXT record queries",
    "unusual_qtype_distribution": "Unusual DNS query type distribution",
    "encoded_labels": "Encoded-looking subdomain labels",
    "unusual_responses": "Unusual DNS response pattern",
}
UNUSUAL_QTYPES = {"TXT", "NULL", "ANY", "AXFR", "HINFO", "PRIVATE"}


@dataclass
class Detection:
    rule: str
    name: str
    parent: str
    src_ips: list
    timestamp: float
    reason: str
    threshold: str
    count: int
    examples: list = field(default_factory=list)

    def to_dict(self):
        d = asdict(self)
        d["src_ips"] = ", ".join(self.src_ips)
        d["examples"] = " | ".join(self.examples)
        return d


def build_query_table(records, cfg) -> pd.DataFrame:
    """One row per DNS QUERY with structural features."""
    rows = []
    for r in records:
        if r.is_response or not r.qname:
            continue
        a = analyze_name(r.qname, cfg.entropy_min_label_length, cfg.encoded_min_label_length)
        rows.append({"timestamp": r.timestamp, "src_ip": r.src_ip, "dst_ip": r.dst_ip, "qname": r.qname,
                     "qname_l": r.qname.lower(), "qtype": r.qtype, "parent": a["parent"],
                     "subdomain": a["subdomain"].lower(), "total_length": a["total_length"],
                     "subdomain_length": a["subdomain_length"], "label_count": a["label_count"],
                     "max_label_length": a["max_label_length"], "max_entropy": a["max_entropy"],
                     "subdomain_entropy": a["subdomain_entropy"], "label_entropies": a["label_entropies"],
                     "encoded": ", ".join(sorted(set(a["encoded_labels"].values()))),
                     "encoded_count": len(a["encoded_labels"]), "protocol": r.protocol, "frame_no": r.frame_no})
    df = pd.DataFrame(rows)
    if not df.empty:
        df["time"] = pd.to_datetime(df["timestamp"], unit="s", utc=True).dt.tz_convert(None)
        df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def build_response_table(records) -> pd.DataFrame:
    rows = [{"timestamp": r.timestamp, "src_ip": r.src_ip, "dst_ip": r.dst_ip, "qname_l": r.qname.lower(),
             "qtype": r.qtype, "rcode": r.rcode, "txt_bytes": r.txt_answer_bytes, "answer_count": r.answer_count}
            for r in records if r.is_response and r.qname]
    df = pd.DataFrame(rows)
    if not df.empty:
        from detector.entropy_analyzer import split_domain
        df["parent"] = [split_domain(q)[0] for q in df["qname_l"]]
    return df


class PatternDetector:
    def __init__(self, cfg):
        self.cfg = cfg
        self.freq = FrequencyAnalyzer(cfg)

    def run(self, q: pd.DataFrame, resp: pd.DataFrame) -> tuple[list[Detection], dict]:
        c = self.cfg
        dets: list[Detection] = []
        if q.empty:
            return dets, {}
        allow = {a.lower().strip(".") for a in c.allowlist}
        qq = q[~q["parent"].isin(allow)]
        freq = self.freq.analyze(qq)

        def add(rule, parent, sub: pd.DataFrame, reason, threshold, examples=None):
            dets.append(Detection(rule, RULE_NAMES[rule], parent, sorted(sub["src_ip"].unique().tolist()),
                                  float(sub["timestamp"].min()), reason, threshold, int(len(sub)),
                                  (examples if examples is not None else
                                   sub["qname"].drop_duplicates().head(3).tolist())))

        for parent, g in qq.groupby("parent"):
            # 1 long queries
            long_mask = ((g["total_length"] > c.max_domain_length) | (g["subdomain_length"] > c.max_subdomain_length) |
                         (g["max_label_length"] > c.max_label_length) | (g["label_count"] > c.max_labels))
            if long_mask.any():
                lg = g[long_mask]
                add("long_query", parent, lg,
                    f"{len(lg)} quer{'y' if len(lg) == 1 else 'ies'} with long names (max total "
                    f"{lg['total_length'].max()}, subdomain {lg['subdomain_length'].max()}, label "
                    f"{lg['max_label_length'].max()}, {lg['label_count'].max()} labels)",
                    f"total > {c.max_domain_length} or subdomain > {c.max_subdomain_length} or label > "
                    f"{c.max_label_length} or labels > {c.max_labels}")
            # 2 entropy
            ent = g[g["max_entropy"] >= c.entropy_threshold]
            if not ent.empty:
                add("high_entropy", parent, ent,
                    f"{len(ent)} quer{'y' if len(ent) == 1 else 'ies'} with a label of entropy >= "
                    f"{c.entropy_threshold} (max {ent['max_entropy'].max():.2f} bits/char)",
                    f"label entropy >= {c.entropy_threshold} for labels >= {c.entropy_min_label_length} chars")
            # 3 frequency (per parent)
            fp = freq["per_parent"].get(parent, {})
            src_counts = {s: d.get(parent, 0) for s, d in freq["per_source"].items()}
            top_src, top_n = max(src_counts.items(), key=lambda kv: kv[1])
            if fp.get("peak_per_minute", 0) > c.max_queries_per_minute or top_n > c.max_queries_per_source_domain:
                why = []
                if fp["peak_per_minute"] > c.max_queries_per_minute:
                    why.append(f"{fp['peak_per_minute']} queries within 60 s")
                if top_n > c.max_queries_per_source_domain:
                    why.append(f"{top_n} queries from {top_src}")
                add("excessive_frequency", parent, g, "; ".join(why) + f" ({len(g)} in total)",
                    f"> {c.max_queries_per_minute} per 60 s to one domain or > {c.max_queries_per_source_domain} "
                    f"from one source")
                dets[-1].timestamp = float(fp.get("peak_start") or dets[-1].timestamp)
            # 4 unique subdomains
            uniq = g.loc[g["subdomain"] != "", "subdomain"].nunique()
            if uniq >= c.max_unique_subdomains:
                add("many_unique_subdomains", parent, g, f"{uniq} distinct subdomains under {parent}",
                    f">= {c.max_unique_subdomains} unique subdomains")
            # 5 TXT
            txt = g[g["qtype"] == "TXT"]
            if not txt.empty:
                per_src = txt["src_ip"].value_counts()
                hot = per_src[per_src >= c.txt_query_threshold]
                if not hot.empty:
                    add("repeated_txt", parent, txt[txt["src_ip"].isin(hot.index)],
                        "; ".join(f"{n} TXT queries from {s}" for s, n in hot.items()),
                        f">= {c.txt_query_threshold} TXT queries from one source to one domain")
            # 7 encoded labels
            enc = g[g["encoded_count"] > 0]
            if len(enc) >= c.encoded_min_queries:
                kinds = ", ".join(sorted({k for v in enc["encoded"] for k in v.split(", ") if k}))
                add("encoded_labels", parent, enc, f"{len(enc)} queries with encoded-looking labels ({kinds})",
                    f">= {c.encoded_min_queries} queries with hex/Base32/Base64-like labels of >= "
                    f"{c.encoded_min_label_length} chars")
        # 6 query-type distribution per source
        for src, g in qq.groupby("src_ip"):
            unusual = g[g["qtype"].isin(UNUSUAL_QTYPES) | g["qtype"].str.startswith("TYPE")]
            if len(g) >= c.unusual_qtype_min_queries and len(unusual) / len(g) >= c.unusual_qtype_ratio:
                for parent, ug in unusual.groupby("parent"):
                    add("unusual_qtype_distribution", parent, ug,
                        f"{len(unusual)} of {len(g)} queries from {src} ({len(unusual) / len(g):.0%}) use unusual "
                        f"types ({', '.join(sorted(unusual['qtype'].unique()))})",
                        f">= {c.unusual_qtype_ratio:.0%} unusual types among >= {c.unusual_qtype_min_queries} "
                        f"queries from one source")
        # 8 responses
        if resp is not None and not resp.empty:
            for parent, g in resp[~resp["parent"].isin(allow)].groupby("parent"):
                if len(g) < c.response_min_count:
                    continue
                nx = (g["rcode"] == "NXDOMAIN").mean()
                big = int((g["txt_bytes"] >= c.large_txt_answer_bytes).sum())
                why = []
                if nx >= c.nxdomain_ratio:
                    why.append(f"{nx:.0%} of {len(g)} responses are NXDOMAIN")
                if big >= max(3, c.response_min_count // 2):
                    why.append(f"{big} responses carry TXT answers >= {c.large_txt_answer_bytes} bytes")
                if why:
                    # the client of a response is its destination address
                    clients = sorted(g["dst_ip"].unique().tolist())
                    dets.append(Detection("unusual_responses", RULE_NAMES["unusual_responses"], parent, clients,
                                          float(g["timestamp"].min()), "; ".join(why),
                                          f"NXDOMAIN >= {c.nxdomain_ratio:.0%} or many TXT answers >= "
                                          f"{c.large_txt_answer_bytes} B (min {c.response_min_count} responses)",
                                          int(len(g)), g["qname_l"].drop_duplicates().head(3).tolist()))
        return dets, freq
