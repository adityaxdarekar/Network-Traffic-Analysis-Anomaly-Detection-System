"""
dns_extractor.py - decode link/IP/UDP/TCP headers and the DNS wire format.

Pure Python (struct only), so it works without Scapy and is fully testable.
Every parser is defensive: truncated or malformed data raises DNSParseError
(caught by the analyzer and counted), never an unhandled exception.

Supported
  link types : 1 Ethernet (incl. 802.1Q VLAN), 113 Linux cooked (SLL), 276 SLL2,
               101/228/229 raw IPv4/IPv6, 0 BSD loopback
  network    : IPv4 (non-first fragments skipped), IPv6 (common extension headers)
  transport  : UDP and TCP on the configured DNS ports (TCP: 2-byte length prefix,
               several messages per segment; a message split across segments is
               reported as incomplete because the analyzer does not reassemble streams)
  DNS        : header, questions, answers with name compression (loop-protected);
               A, AAAA, CNAME, NS, PTR, MX, TXT, SOA decoded, others shown by length
"""
from __future__ import annotations

import ipaddress
import struct
from dataclasses import asdict, dataclass, field

QTYPES = {1: "A", 2: "NS", 5: "CNAME", 6: "SOA", 10: "NULL", 12: "PTR", 13: "HINFO", 15: "MX", 16: "TXT", 28: "AAAA",
          33: "SRV", 35: "NAPTR", 43: "DS", 46: "RRSIG", 47: "NSEC", 48: "DNSKEY", 52: "TLSA", 64: "SVCB",
          65: "HTTPS", 99: "SPF", 252: "AXFR", 255: "ANY", 257: "CAA"}
QTYPE_CODES = {v: k for k, v in QTYPES.items()}
RCODES = {0: "NOERROR", 1: "FORMERR", 2: "SERVFAIL", 3: "NXDOMAIN", 4: "NOTIMP", 5: "REFUSED", 6: "YXDOMAIN",
          7: "YXRRSET", 8: "NXRRSET", 9: "NOTAUTH", 10: "NOTZONE"}


class DNSParseError(ValueError):
    pass


@dataclass
class DNSRecord:
    timestamp: float
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str                 # UDP | TCP
    transaction_id: int
    is_response: bool
    qname: str
    qtype: str
    rcode: str
    answers: list = field(default_factory=list)       # ["A 192.0.2.1", "TXT 'abc'", ...]
    answer_count: int = 0
    txt_answer_bytes: int = 0
    packet_size: int = 0
    frame_no: int = 0
    note: str = ""

    def to_dict(self):
        d = asdict(self)
        d["answers"] = "; ".join(self.answers)
        d["direction"] = "response" if self.is_response else "query"
        return d


# ---------------------------------------------------------------- DNS wire format
def read_name(msg: bytes, off: int, max_jumps: int = 20) -> tuple[str, int]:
    """Decode a (possibly compressed) domain name. Returns (name, offset after the name in the original position)."""
    labels, jumps, end, total = [], 0, None, 0
    while True:
        if off >= len(msg):
            raise DNSParseError("name runs past end of message")
        ln = msg[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            if off + 1 >= len(msg):
                raise DNSParseError("truncated compression pointer")
            ptr = ((ln & 0x3F) << 8) | msg[off + 1]
            if end is None:
                end = off + 2
            jumps += 1
            if jumps > max_jumps or ptr >= len(msg):
                raise DNSParseError("compression loop or bad pointer")
            off = ptr
            continue
        if ln & 0xC0:
            raise DNSParseError("unsupported label type")
        off += 1
        if off + ln > len(msg):
            raise DNSParseError("label runs past end of message")
        raw = msg[off:off + ln]
        labels.append(raw.decode("ascii", errors="replace").replace("�", "?"))
        total += ln + 1
        if total > 255:
            raise DNSParseError("name longer than 255 bytes")
        off += ln
    return ".".join(labels), (end if end is not None else off)       # case preserved (0x20 / Base64 use case)


def _rdata(msg: bytes, rtype: int, off: int, rdlen: int) -> tuple[str, int]:
    """Returns (text, txt_bytes)."""
    data = msg[off:off + rdlen]
    if len(data) < rdlen:
        raise DNSParseError("rdata truncated")
    t = QTYPES.get(rtype, f"TYPE{rtype}")
    if rtype == 1 and rdlen == 4:
        return f"A {ipaddress.IPv4Address(data)}", 0
    if rtype == 28 and rdlen == 16:
        return f"AAAA {ipaddress.IPv6Address(data)}", 0
    if rtype in (2, 5, 12):
        return f"{t} {read_name(msg, off)[0]}", 0
    if rtype == 15 and rdlen >= 3:
        return f"MX {struct.unpack('!H', data[:2])[0]} {read_name(msg, off + 2)[0]}", 0
    if rtype == 16:
        parts, i = [], 0
        while i < len(data):
            n = data[i]
            parts.append(data[i + 1:i + 1 + n].decode("ascii", errors="replace"))
            i += 1 + n
        txt = "".join(parts)
        return f"TXT '{txt[:120]}{'...' if len(txt) > 120 else ''}'", len(txt)
    if rtype == 6:
        return f"SOA {read_name(msg, off)[0]}", 0
    return f"{t} ({rdlen} bytes)", 0


def parse_dns(msg: bytes) -> dict:
    """Parse a DNS message. Returns dict with id, is_response, rcode, qname, qtype, answers, answer_count, txt_bytes."""
    if len(msg) < 12:
        raise DNSParseError("shorter than the 12-byte DNS header")
    tid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", msg[:12])
    if qd > 50 or an > 500:
        raise DNSParseError("implausible record counts")
    out = {"id": tid, "is_response": bool(flags & 0x8000), "rcode": RCODES.get(flags & 0xF, str(flags & 0xF)),
           "qname": "", "qtype": "", "answers": [], "answer_count": an, "txt_bytes": 0, "opcode": (flags >> 11) & 0xF}
    off = 12
    for i in range(qd):
        name, off = read_name(msg, off)
        if off + 4 > len(msg):
            raise DNSParseError("question truncated")
        qt, _qc = struct.unpack("!HH", msg[off:off + 4])
        off += 4
        if i == 0:
            out["qname"], out["qtype"] = name, QTYPES.get(qt, f"TYPE{qt}")
    for _ in range(an):
        _name, off = read_name(msg, off)
        if off + 10 > len(msg):
            raise DNSParseError("answer truncated")
        rtype, _rc, _ttl, rdlen = struct.unpack("!HHIH", msg[off:off + 10])
        off += 10
        text, tb = _rdata(msg, rtype, off, rdlen)
        out["answers"].append(text)
        out["txt_bytes"] += tb
        off += rdlen
    return out


# ---------------------------------------------------------------- link / IP / transport
def _ip_payload(data: bytes, linktype: int) -> tuple[int, bytes]:
    """Returns (ip_version, ip_packet) or raises DNSParseError / returns (0, b'') if not IP."""
    if linktype == 1:                                   # Ethernet
        if len(data) < 14:
            raise DNSParseError("truncated Ethernet header")
        etype, off = struct.unpack("!H", data[12:14])[0], 14
        while etype in (0x8100, 0x88A8):                # VLAN tags
            if len(data) < off + 4:
                raise DNSParseError("truncated VLAN tag")
            etype, off = struct.unpack("!H", data[off + 2:off + 4])[0], off + 4
        payload = data[off:]
    elif linktype == 113:                               # Linux cooked v1
        if len(data) < 16:
            raise DNSParseError("truncated SLL header")
        etype, payload = struct.unpack("!H", data[14:16])[0], data[16:]
    elif linktype == 276:                               # Linux cooked v2
        if len(data) < 20:
            raise DNSParseError("truncated SLL2 header")
        etype, payload = struct.unpack("!H", data[0:2])[0], data[20:]
    elif linktype in (101, 228, 229, 12, 14):           # raw IP
        if not data:
            raise DNSParseError("empty packet")
        v = data[0] >> 4
        return v, data
    elif linktype == 0:                                 # BSD loopback: 4-byte family in host order
        if len(data) < 4:
            raise DNSParseError("truncated loopback header")
        fam = int.from_bytes(data[:4], "little") if data[0] else int.from_bytes(data[:4], "big")
        v = 4 if fam == 2 else 6 if fam in (24, 28, 30) else 0
        return v, data[4:]
    else:
        raise DNSParseError(f"unsupported link type {linktype}")
    return (4 if etype == 0x0800 else 6 if etype == 0x86DD else 0), payload


def decode_frame(data: bytes, linktype: int, ts: float, frame_no: int, dns_ports=(53,)) -> tuple[list, str]:
    """Return ([DNSRecord, ...], status) where status is 'dns', 'non-dns' or 'malformed:<reason>'."""
    try:
        ver, ip = _ip_payload(data, linktype)
        if ver == 4:
            if len(ip) < 20:
                raise DNSParseError("truncated IPv4 header")
            ihl = (ip[0] & 0x0F) * 4
            if ihl < 20 or len(ip) < ihl:
                raise DNSParseError("bad IPv4 header length")
            frag = struct.unpack("!H", ip[6:8])[0]
            if frag & 0x1FFF:
                return [], "non-dns"                     # non-first fragment: no transport header
            proto = ip[9]
            src, dst = str(ipaddress.IPv4Address(ip[12:16])), str(ipaddress.IPv4Address(ip[16:20]))
            total = struct.unpack("!H", ip[2:4])[0]
            seg = ip[ihl:total] if ihl <= total <= len(ip) else ip[ihl:]
        elif ver == 6:
            if len(ip) < 40:
                raise DNSParseError("truncated IPv6 header")
            proto, off = ip[6], 40
            src, dst = str(ipaddress.IPv6Address(ip[8:24])), str(ipaddress.IPv6Address(ip[24:40]))
            hops = 0
            while proto in (0, 43, 60, 44) and hops < 8:
                if len(ip) < off + 8:
                    raise DNSParseError("truncated IPv6 extension header")
                nxt = ip[off]
                if proto == 44:
                    if struct.unpack("!H", ip[off + 2:off + 4])[0] & 0xFFF8:
                        return [], "non-dns"             # non-first fragment
                    off += 8
                else:
                    off += (ip[off + 1] + 1) * 8
                proto, hops = nxt, hops + 1
            seg = ip[off:]
        else:
            return [], "non-dns"
        if proto == 17:
            if len(seg) < 8:
                raise DNSParseError("truncated UDP header")
            sp, dp, ulen = struct.unpack("!HHH", seg[:6])
            if sp not in dns_ports and dp not in dns_ports:
                return [], "non-dns"
            payload = seg[8:ulen] if 8 <= ulen <= len(seg) else seg[8:]
            msgs, transport = [payload], "UDP"
        elif proto == 6:
            if len(seg) < 20:
                raise DNSParseError("truncated TCP header")
            sp, dp = struct.unpack("!HH", seg[:4])
            if sp not in dns_ports and dp not in dns_ports:
                return [], "non-dns"
            doff = (seg[12] >> 4) * 4
            payload = seg[doff:]
            if not payload:
                return [], "non-dns"                     # handshake / ACK only
            msgs, i, transport = [], 0, "TCP"
            while i + 2 <= len(payload):
                n = struct.unpack("!H", payload[i:i + 2])[0]
                if i + 2 + n > len(payload):
                    raise DNSParseError("TCP DNS message continues in another segment (not reassembled)")
                msgs.append(payload[i + 2:i + 2 + n])
                i += 2 + n
            if not msgs:
                raise DNSParseError("TCP payload without a complete DNS message")
        else:
            return [], "non-dns"
        out = []
        for m in msgs:
            d = parse_dns(m)
            out.append(DNSRecord(ts, src, dst, sp, dp, transport, d["id"], d["is_response"], d["qname"], d["qtype"],
                                 d["rcode"], d["answers"], d["answer_count"], d["txt_bytes"], len(data), frame_no))
        return out, "dns"
    except DNSParseError as exc:
        return [], f"malformed:{exc}"
    except (struct.error, ValueError, IndexError) as exc:      # belt and braces
        return [], f"malformed:{type(exc).__name__}"


# ---------------------------------------------------------------- builders (used by the sample generator and tests)
def encode_name(name: str) -> bytes:
    out = b""
    for label in name.strip(".").split("."):
        b = label.encode("ascii")
        if not 0 < len(b) <= 63:
            raise ValueError(f"invalid label length {len(b)} in {name!r}")
        out += bytes([len(b)]) + b
    if len(out) + 1 > 255:
        raise ValueError("name longer than 255 bytes")
    return out + b"\x00"


def build_dns(tid: int, qname: str, qtype: str = "A", response: bool = False, rcode: int = 0,
              answers: list | None = None) -> bytes:
    """answers: [("A", "192.0.2.1") | ("AAAA", "2001:db8::1") | ("TXT", "text") | ("CNAME", "x.example")]."""
    answers = answers or []
    flags = 0x0100 | (0x8080 if response else 0) | (rcode & 0xF)   # RD (+QR, RA)
    msg = struct.pack("!HHHHHH", tid, flags, 1, len(answers), 0, 0)
    msg += encode_name(qname) + struct.pack("!HH", QTYPE_CODES[qtype], 1)
    for rtype, value in answers:
        if rtype == "A":
            rdata = ipaddress.IPv4Address(value).packed
        elif rtype == "AAAA":
            rdata = ipaddress.IPv6Address(value).packed
        elif rtype == "TXT":
            raw = value.encode("ascii")
            rdata = b"".join(bytes([len(raw[i:i + 255])]) + raw[i:i + 255] for i in range(0, len(raw), 255)) or b"\x00"
        elif rtype == "CNAME":
            rdata = encode_name(value)
        else:
            raise ValueError(rtype)
        msg += b"\xc0\x0c" + struct.pack("!HHIH", QTYPE_CODES[rtype], 1, 300, len(rdata)) + rdata
    return msg
