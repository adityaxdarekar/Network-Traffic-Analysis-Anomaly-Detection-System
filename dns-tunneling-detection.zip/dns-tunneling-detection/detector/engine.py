"""
engine.py - one complete analysis: capture -> DNS records -> features -> rules -> incidents.

Used by app.py, analyze_pcap.py and run_demos.py so every interface shows
exactly the same results.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from detector.pattern_detector import PatternDetector, build_query_table, build_response_table
from detector.pcap_analyzer import CaptureResult, analyze_capture
from detector.risk_scorer import build_incidents


@dataclass
class AnalysisResult:
    capture: CaptureResult
    queries: pd.DataFrame
    responses: pd.DataFrame
    detections: list
    incidents: list
    frequency: dict
    config: dict
    domains: pd.DataFrame = field(default_factory=pd.DataFrame)

    @property
    def stats(self) -> dict:
        s = self.capture.stats()
        s["suspicious_domains"] = len(self.incidents)
        s["incidents"] = len(self.incidents)
        s["critical"] = sum(1 for i in self.incidents if i.level == "Critical")
        s["high"] = sum(1 for i in self.incidents if i.level == "High")
        s["medium"] = sum(1 for i in self.incidents if i.level == "Medium")
        s["low"] = sum(1 for i in self.incidents if i.level == "Low")
        s["unique_parents"] = int(self.queries["parent"].nunique()) if not self.queries.empty else 0
        return s


def domain_table(queries: pd.DataFrame, incidents) -> pd.DataFrame:
    cols = ["parent", "query_count", "unique_subdomains", "source_ips", "avg_length", "max_length", "avg_entropy",
            "max_entropy", "record_types", "first_seen", "last_seen", "risk_score", "risk_level", "rules"]
    if queries.empty:
        return pd.DataFrame(columns=cols)
    inc = {i.parent: i for i in incidents}
    rows = []
    for parent, g in queries.groupby("parent"):
        i = inc.get(parent)
        rows.append({"parent": parent, "query_count": len(g),
                     "unique_subdomains": int(g.loc[g["subdomain"] != "", "subdomain"].nunique()),
                     "source_ips": ", ".join(sorted(g["src_ip"].unique())),
                     "avg_length": round(float(g["total_length"].mean()), 1), "max_length": int(g["total_length"].max()),
                     "avg_entropy": round(float(g["max_entropy"].mean()), 2),
                     "max_entropy": round(float(g["max_entropy"].max()), 2),
                     "record_types": ", ".join(f"{k}:{v}" for k, v in g["qtype"].value_counts().items()),
                     "first_seen": g["time"].min(), "last_seen": g["time"].max(),
                     "risk_score": i.score if i else 0, "risk_level": i.level if i else "-",
                     "rules": ", ".join(i.rules) if i else ""})
    return pd.DataFrame(rows, columns=cols).sort_values(["risk_score", "query_count"], ascending=False) \
        .reset_index(drop=True)


def analyze_records(capture: CaptureResult, cfg) -> AnalysisResult:
    q = build_query_table(capture.records, cfg)
    r = build_response_table(capture.records)
    dets, freq = PatternDetector(cfg).run(q, r)
    incs = build_incidents(dets, q, cfg, capture.file_sha256)
    res = AnalysisResult(capture, q, r, dets, incs, freq, cfg.to_dict())
    res.domains = domain_table(q, incs)
    return res


def run_analysis(path, cfg, display_name: str | None = None, backend: str = "auto") -> AnalysisResult:
    problems = cfg.validate()
    if problems:
        raise ValueError("invalid configuration: " + "; ".join(problems))
    cap = analyze_capture(path, tuple(cfg.dns_ports), backend=backend, display_name=display_name)
    return analyze_records(cap, cfg)
