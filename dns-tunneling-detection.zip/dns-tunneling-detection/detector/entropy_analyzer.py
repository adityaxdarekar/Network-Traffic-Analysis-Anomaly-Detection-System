"""
entropy_analyzer.py - domain structure and Shannon entropy.

Shannon entropy of a string s over its characters:

    H(s) = - Σ p(c) · log2 p(c)      p(c) = count(c) / len(s)

It measures how unpredictable the characters are, in bits per character:
    "aaaaaaaa"            -> 0.00   (one symbol)
    "mail"                -> 2.00
    "documentation"       -> 3.24   (English-like)
    32 random hex chars   -> ~3.3-3.9 (max 4.0 for 16 symbols - hex can stay under
                             the default threshold, which is why the separate
                             encoded-label rule exists)
    40 random base32      -> ~4.3-4.6 (max 5.0 for 32 symbols)
Maximum possible entropy is log2(min(len(s), alphabet size)), so short
labels can never score high - entropy is only computed for labels of at
least `entropy_min_label_length` characters.

Why encoded data looks suspicious in DNS: tunnelling tools must squeeze
arbitrary bytes into hostname labels (letters, digits, hyphen, max 63 chars
each), so they use hexadecimal, Base32 or Base64-like alphabets. Encoded
bytes look random -> high entropy, unusual length, few vowels, many digits.
Legitimate services do this too (CDN hashes, anti-virus reputation lookups,
DKIM/telemetry), so entropy alone never classifies a domain as malicious.
"""
from __future__ import annotations

import math
import re
from collections import Counter

# Common multi-part public suffixes (a full Public Suffix List is not bundled: see README limitations)
MULTI_SUFFIXES = {"co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.in", "co.jp", "co.nz",
                  "com.br", "com.cn", "com.mx", "com.tr", "co.za", "com.sg", "com.hk", "co.kr", "or.jp", "ne.jp"}

HEX_RE = re.compile(r"^[0-9a-f]+$")
BASE32_RE = re.compile(r"^[a-z2-7]+=*$")
BASE64ISH_RE = re.compile(r"^[A-Za-z0-9_\-+/]+=*$")
VOWELS = set("aeiou")


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    n = len(s)
    return abs(-sum((c / n) * math.log2(c / n) for c in Counter(s).values())) + 0.0


def split_domain(qname: str) -> tuple[str, list[str]]:
    """Return (parent/registered domain in lower case, subdomain labels with their original case).
    Heuristic, without the Public Suffix List."""
    orig = (qname or "").strip(".")
    if not orig:
        return "", []
    labels = orig.split(".")
    low = [x.lower() for x in labels]
    if len(labels) <= 2:
        return ".".join(low), []
    if orig.lower().endswith((".in-addr.arpa", ".ip6.arpa")):
        return ".".join(low[-2:]), labels[:-2]
    keep = 3 if ".".join(low[-2:]) in MULTI_SUFFIXES else 2
    return ".".join(low[-keep:]), labels[:-keep]


def encoding_class(label: str, min_len: int) -> str | None:
    """Return 'hex', 'base32', 'base64-like' or 'random-alnum' for encoded-looking labels, else None."""
    if len(label) < min_len:
        return None
    low = label.lower()
    digits = sum(ch.isdigit() for ch in low)
    vowels = sum(ch in VOWELS for ch in low)
    if HEX_RE.match(low) and digits >= 3 and any(c in "abcdef" for c in low):
        return "hex"
    if BASE32_RE.match(low) and digits >= 2 and vowels / len(low) < 0.30:
        return "base32"
    if BASE64ISH_RE.match(label) and any(c.isupper() for c in label) and any(c.islower() for c in label) and digits:
        return "base64-like"
    if re.match(r"^[a-z0-9]+$", low) and digits / len(low) >= 0.25 and vowels / len(low) < 0.25:
        return "random-alnum"
    return None


def analyze_name(qname: str, min_entropy_len: int = 12, encoded_min_len: int = 16) -> dict:
    parent, subs = split_domain(qname)
    sub = ".".join(subs)
    ent = {lab: round(shannon_entropy(lab), 3) for lab in subs if len(lab) >= min_entropy_len}
    enc = {lab: encoding_class(lab, encoded_min_len) for lab in subs}
    enc = {k: v for k, v in enc.items() if v}
    return {"qname": qname, "parent": parent, "subdomain": sub, "total_length": len(qname or ""),
            "subdomain_length": len(sub), "label_count": len(subs),
            "max_label_length": max((len(x) for x in subs), default=0),
            "label_entropies": ent, "max_entropy": max(ent.values(), default=0.0),
            "subdomain_entropy": round(shannon_entropy(sub.replace(".", "")), 3) if sub else 0.0,
            "encoded_labels": enc}
