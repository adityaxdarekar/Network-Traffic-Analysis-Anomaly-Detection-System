"""
frequency_detector.py - DNS query frequency analysis with sliding time windows.

  * queries per source IP and per parent domain (whole capture)
  * queries per minute (time series for the dashboard)
  * peak number of queries to one parent domain inside ANY 60-second window
  * repeated identical queries (same full name)
  * bursts: many queries from one source inside `burst_window_seconds`

Sliding windows (two pointers over sorted timestamps) are used instead of
fixed clock minutes, so a burst that straddles 10:00:59 / 10:01:00 is not
split in half.
"""
from __future__ import annotations

from collections import Counter, defaultdict

import pandas as pd


def sliding_max(times: list[float], window: float) -> tuple[int, float | None]:
    """Largest number of events within `window` seconds (inclusive) and the start time of that window."""
    times = sorted(times)
    best, start, j = 0, None, 0
    for i in range(len(times)):
        if j < i:
            j = i
        while j < len(times) and times[j] - times[i] <= window:
            j += 1
        if j - i > best:
            best, start = j - i, times[i]
    return best, start


def per_minute_series(queries: pd.DataFrame) -> pd.DataFrame:
    if queries.empty:
        return pd.DataFrame(columns=["minute", "queries"])
    s = queries.set_index("time").resample("1min").size().reset_index()
    s.columns = ["minute", "queries"]
    return s


class FrequencyAnalyzer:
    def __init__(self, cfg):
        self.cfg = cfg

    def analyze(self, queries: pd.DataFrame) -> dict:
        """queries: DataFrame with timestamp, src_ip, qname_l, parent. Returns per-parent / per-source findings."""
        c = self.cfg
        out = {"per_parent": {}, "per_source": {}, "bursts": {}, "repeated_names": {}}
        if queries.empty:
            return out
        by_parent = defaultdict(list)
        by_src_parent = Counter()
        by_src = defaultdict(list)
        for ts, src, parent in zip(queries["timestamp"], queries["src_ip"], queries["parent"]):
            by_parent[parent].append(ts)
            by_src_parent[(src, parent)] += 1
            by_src[src].append(ts)
        for parent, ts in by_parent.items():
            peak, start = sliding_max(ts, 60.0)
            out["per_parent"][parent] = {"queries": len(ts), "peak_per_minute": peak, "peak_start": start}
        for (src, parent), n in by_src_parent.items():
            out["per_source"].setdefault(src, {})[parent] = n
        for src, ts in by_src.items():
            peak, start = sliding_max(ts, c.burst_window_seconds)
            out["bursts"][src] = {"queries": len(ts), "peak": peak, "start": start}
        rep = queries.groupby(["src_ip", "qname_l"]).agg(count=("timestamp", "size"), first=("timestamp", "min"),
                                                        parent=("parent", "first")).reset_index()
        out["repeated_names"] = rep.sort_values("count", ascending=False)
        return out

    def top_sources(self, queries: pd.DataFrame, n: int = 10) -> pd.DataFrame:
        if queries.empty:
            return pd.DataFrame(columns=["src_ip", "queries"])
        return queries["src_ip"].value_counts().head(n).rename_axis("src_ip").reset_index(name="queries")

    def top_domains(self, queries: pd.DataFrame, n: int = 10, column: str = "parent") -> pd.DataFrame:
        if queries.empty:
            return pd.DataFrame(columns=[column, "queries"])
        return queries[column].value_counts().head(n).rename_axis(column).reset_index(name="queries")
