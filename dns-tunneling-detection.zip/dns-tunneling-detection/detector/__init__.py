"""detector package."""
