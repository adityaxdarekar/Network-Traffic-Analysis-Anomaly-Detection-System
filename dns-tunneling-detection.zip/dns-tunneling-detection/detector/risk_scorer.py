"""
risk_scorer.py - turn detections into incidents with a transparent heuristic score.

One incident per parent domain. Each RULE counts once per incident however
many queries triggered it (no double counting), using these default weights:

    long_query 15 · high_entropy 20 · excessive_frequency 20 ·
    many_unique_subdomains 20 · repeated_txt 10 · encoded_labels 15 ·
    unusual_qtype_distribution 10 · unusual_responses 10

Score = sum of the weights of the distinct rules, capped at 100.
Category: 0-24 Low · 25-49 Medium · 50-74 High · 75-100 Critical.

The model is heuristic. It shows which behaviours co-occur; an analyst must
validate an incident (who owns the domain, what the host was doing, whether
the data volume makes sense) before calling it DNS tunnelling.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict
from dataclasses import asdict, dataclass, field

import pandas as pd

BANDS = [(75, "Critical"), (50, "High"), (25, "Medium"), (0, "Low")]
DISCLAIMER = ("Heuristic assessment: the score reflects how many independent suspicious DNS behaviours were observed "
              "for a domain. It is not proof of DNS tunnelling and must be validated by an analyst.")


def category(score: int) -> str:
    for lo, name in BANDS:
        if score >= lo:
            return name
    return "Low"


@dataclass
class Incident:
    incident_id: str
    parent: str
    score: int
    level: str
    rules: list
    breakdown: list                 # [(rule name, points)]
    detections: list                # Detection.to_dict()
    src_ips: list
    query_count: int
    unique_subdomains: int
    avg_length: float
    max_length: int
    avg_entropy: float
    max_entropy: float
    qtypes: dict
    first_seen: float
    last_seen: float
    recommendations: list = field(default_factory=list)
    explanation: str = ""

    def to_dict(self):
        return asdict(self)


def score_rules(rules: set, weights: dict) -> tuple[int, list]:
    breakdown = sorted(((r, int(weights.get(r, 0))) for r in rules), key=lambda x: -x[1])
    return min(100, sum(p for _, p in breakdown)), breakdown


def recommendations(rules: set) -> list[str]:
    recs = ["Identify the owner of the parent domain (WHOIS / internal asset lists) without contacting it from "
            "production systems.",
            "Identify the internal host(s) that sent the queries and what process generated them (EDR, Sysmon "
            "event ID 22 DNSQuery, resolver logs)."]
    if rules & {"high_entropy", "encoded_labels", "long_query", "many_unique_subdomains"}:
        recs.append("Look at the subdomain labels: consistent hex/Base32 chunks with sequence-like variation suggest "
                    "data being carried; CDN or anti-virus lookups look random but come from known products.")
    if rules & {"excessive_frequency", "many_unique_subdomains"}:
        recs.append("Estimate the volume of data the queries could carry (sum of subdomain lengths) and compare it "
                    "with the host's normal DNS behaviour.")
    if "repeated_txt" in rules or "unusual_responses" in rules:
        recs.append("Review TXT answers: large or changing TXT records to a host that normally makes none can carry "
                    "commands or data (command-and-control).")
    recs += ["If confirmed: block the domain at the DNS resolver / firewall, isolate the host and start incident "
             "response. Force clients to use internal resolvers (block direct port 53 egress).",
             "If benign: add the parent domain to the allowlist in Detection Configuration to suppress it."]
    return recs


def build_incidents(detections, queries: pd.DataFrame, cfg, capture_sha256: str) -> list[Incident]:
    by_parent = defaultdict(list)
    for d in detections:
        by_parent[d.parent].append(d)
    out = []
    for parent, dets in by_parent.items():
        rules = {d.rule for d in dets}
        score, breakdown = score_rules(rules, cfg.weights)
        g = queries[queries["parent"] == parent] if not queries.empty else queries
        srcs = sorted(set(g["src_ip"]) | {s for d in dets for s in d.src_ips}) if not g.empty else \
            sorted({s for d in dets for s in d.src_ips})
        first = float(g["timestamp"].min()) if not g.empty else min(d.timestamp for d in dets)
        last = float(g["timestamp"].max()) if not g.empty else max(d.timestamp for d in dets)
        iid = "DNS-" + hashlib.sha1(f"{capture_sha256}|{parent}".encode()).hexdigest()[:10].upper()
        lvl = category(score)
        out.append(Incident(
            iid, parent, score, lvl, sorted(rules), [(d_name(r), p) for r, p in breakdown],
            [d.to_dict() for d in sorted(dets, key=lambda x: x.timestamp)], srcs, int(len(g)),
            int(g.loc[g["subdomain"] != "", "subdomain"].nunique()) if not g.empty else 0,
            round(float(g["total_length"].mean()), 1) if not g.empty else 0.0,
            int(g["total_length"].max()) if not g.empty else 0,
            round(float(g["max_entropy"].mean()), 2) if not g.empty else 0.0,
            round(float(g["max_entropy"].max()), 2) if not g.empty else 0.0,
            g["qtype"].value_counts().to_dict() if not g.empty else {}, first, last, recommendations(rules),
            " + ".join(f"{d_name(r)} ({p})" for r, p in breakdown) + f" = {score}" +
            (" (capped at 100)" if sum(p for _, p in breakdown) > 100 else "")))
    return sorted(out, key=lambda i: (-i.score, i.first_seen))


def d_name(rule: str) -> str:
    from detector.pattern_detector import RULE_NAMES
    return RULE_NAMES.get(rule, rule)
