"""helpers.py - logging, formatting and upload validation."""
from __future__ import annotations

import html
import logging
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import LOG_FILE, MAX_UPLOAD_MB, RISK_COLORS


class UploadError(ValueError):
    pass


def validate_upload(name: str, data: bytes) -> None:
    suffix = Path(name or "").suffix.lower()
    if suffix not in (".pcap", ".pcapng", ".cap"):
        raise UploadError("only .pcap, .pcapng (or .cap) captures are accepted")
    if not data:
        raise UploadError("the file is empty")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise UploadError(f"the file is larger than {MAX_UPLOAD_MB} MB")
    if data[:4] not in (b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\xc3\xd4", b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d",
                        b"\x0a\x0d\x0d\x0a"):
        raise UploadError("not a PCAP/PCAPNG file (wrong magic number). In Wireshark use File > Save As / Export "
                          "Specified Packets and choose pcap or pcapng.")


def fmt_ts(ts) -> str:
    if ts is None:
        return "-"
    try:
        return datetime.fromtimestamp(float(ts), timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (TypeError, ValueError, OSError):
        return str(ts)


def esc(v) -> str:
    return html.escape("" if v is None else str(v))


def badge(level: str) -> str:
    return f'<span class="risk-badge" style="background:{RISK_COLORS.get(level, "#64748b")}">{esc(level)}</span>'


def get_logger() -> logging.Logger:
    log = logging.getLogger("dnstd")
    if not log.handlers:
        Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        h = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log


def csv_safe(v) -> str:
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s
