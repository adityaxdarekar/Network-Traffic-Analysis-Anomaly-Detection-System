# Project Status: what was verified, and what was not

Build environment: Ubuntu 24.04 container, Python 3.13, pandas 3, NumPy 2.5, reportlab 4. **Not available: Scapy, Wireshark, TShark, Streamlit and Plotly** (no network access, so nothing could be installed).

## Verified by running it

| Item | Evidence |
|---|---|
| 85 automated tests pass | `python -m pytest -q` (`sample_output/test_results.txt`) |
| PCAP and PCAPNG reading/writing, DNS decoding (UDP, TCP, IPv4, IPv6, VLAN, compression, answers) | `tests/test_pcap_analyzer.py` |
| Malformed packets, truncated files and invalid files handled without crashing | Tests, plus the 2 deliberately malformed packets in the sample |
| Valid IPv4/UDP/TCP checksums in generated frames | `test_checksums_valid` |
| Generated files have standard headers | `file` reports "pcap capture file, microsecond ts (little-endian) - version 2.4 (Ethernet…)" and "pcapng capture file - version 1.0" |
| Entropy, frequency, all 8 rules, scoring, de-duplication | `test_entropy.py`, `test_frequency_detector.py`, `test_risk_scorer.py` |
| Normal traffic produces no alerts; the sample gives Critical/High/Medium/Low | `run_demos.py` (`sample_output/demo_results.txt`), `cli_analyze_normal.txt` |
| Incident status and notes persist after restart and re-analysis | Demo 7 and `test_incident_persistence_across_restart` |
| CSV and PDF reports | `sample_output/` (PDF: 5 pages), `screenshots/07_*` |

## Not verified (honest gaps)

| Item | Status |
|---|---|
| **Opening the synthetic capture in Wireshark** | Wireshark and TShark are not installed here. The files use the standard libpcap and pcapng layouts, the `file` utility recognises them, the checksums are verified, and the project's own reader parses them. Whether Wireshark shows exactly the predicted filter counts (`run_demos.py`, Demo 1) has **not** been confirmed. Please check it during your demo. |
| **Scapy backend** | `iter_packets_scapy` (reading) and `--engine scapy` (writing) are written against Scapy's public API but were **never executed**. If Scapy is installed it is used automatically. If it misbehaves, force the tested reader with `python analyze_pcap.py file.pcap --backend builtin`. |
| **Streamlit dashboard in a browser** | It was run with stand-in Streamlit and Plotly modules on all 8 pages, with and without Plotly (`tests/test_app_smoke.py`). That checks the logic and wiring, **not** the visual layout. There are no dashboard screenshots: take them after `pip install -r requirements.txt`. |
| Real (non-synthetic) captures | Only synthetic captures and hand-built test frames were analysed. Thresholds will need tuning on real traffic. |
| Live capture | Not part of the application. Capture is done with Wireshark or TShark (see `docs/WIRESHARK_GUIDE.md`). |

## Data honesty

- All sample captures are **SYNTHETIC**:
  - files only, seeded random strings, no data encoded;
  - reserved `.test` and `example.*` names, lab and documentation IP addresses;
  - marked by `.synthetic` sidecar files and a pcapng comment;
  - labelled in the dashboard, the CLI and the PDF.
- The sample timestamps are fixed to 8 Nov 2025 10:00 UTC by the generator.
- `database/incidents.db` in the ZIP contains only the synthetic demo run. Delete it to start empty.
