#!/usr/bin/env python3
"""
analyze_pcap.py - terminal version of the analysis (same engine as the dashboard).

    python analyze_pcap.py sample_data/sample_dns_traffic.pcap
    python analyze_pcap.py capture.pcapng --save --pdf reports/report.pdf --csv reports/
    python analyze_pcap.py capture.pcap --entropy 3.4 --max-qpm 30 --allow example-cdn.com
    python analyze_pcap.py --incidents
    python analyze_pcap.py --set-status DNS-XXXXXXXXXX Investigating --note "checking host 192.168.56.21"

Offline analysis only: the file is read, nothing is sent, no domain is resolved.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from tabulate import tabulate

from config import DB_PATH, DetectionConfig
from database.db_manager import DBManager
from detector.engine import run_analysis
from detector.pcap_io import CaptureFormatError
from detector.risk_scorer import DISCLAIMER
from utils.helpers import fmt_ts
from utils.report_generator import dns_records_csv, incidents_csv, pdf_report, suspicious_domains_csv


def main(argv=None):
    ap = argparse.ArgumentParser(description="DNS tunnelling detection on PCAP/PCAPNG files (offline)")
    ap.add_argument("capture", nargs="?")
    ap.add_argument("--backend", choices=["auto", "builtin", "scapy"], default="auto")
    ap.add_argument("--entropy", type=float)
    ap.add_argument("--max-qpm", type=int, help="max queries per minute to one domain")
    ap.add_argument("--max-length", type=int)
    ap.add_argument("--unique", type=int, help="max unique subdomains per domain")
    ap.add_argument("--allow", nargs="*", default=[], help="parent domains to ignore")
    ap.add_argument("--save", action="store_true")
    ap.add_argument("--db", default=str(DB_PATH))
    ap.add_argument("--pdf")
    ap.add_argument("--csv")
    ap.add_argument("--incidents", action="store_true")
    ap.add_argument("--set-status", nargs=2, metavar=("INCIDENT_ID", "STATUS"))
    ap.add_argument("--note", default="")
    a = ap.parse_args(argv)
    db = DBManager(a.db)
    try:
        if a.set_status:
            ok = db.update_status(a.set_status[0], a.set_status[1], a.note)
            print("updated" if ok else "incident not found")
            return 0 if ok else 1
        if a.incidents:
            rows = db.list_incidents()
            print(tabulate([[r["incident_id"], r["risk_level"], r["risk_score"], r["parent_domain"],
                             ", ".join(r["src_ips"]), r["status"], (r["analyst_notes"] or "")[:40], r["file_name"]]
                            for r in rows], ["Incident", "Level", "Score", "Domain", "Sources", "Status", "Notes",
                                             "Capture"], tablefmt="simple") if rows else "no stored incidents")
            return 0
        if not a.capture:
            ap.error("give a capture file, --incidents or --set-status")
        cfg = DetectionConfig(allowlist=a.allow)
        if a.entropy is not None:
            cfg.entropy_threshold = a.entropy
        if a.max_qpm is not None:
            cfg.max_queries_per_minute = a.max_qpm
        if a.max_length is not None:
            cfg.max_domain_length = a.max_length
        if a.unique is not None:
            cfg.max_unique_subdomains = a.unique
        try:
            res = run_analysis(a.capture, cfg, backend=a.backend)
        except (CaptureFormatError, ValueError) as exc:
            print(f"Error: {exc}")
            return 2
        s, cap = res.stats, res.capture
        if cap.synthetic:
            print("*** SYNTHETIC CAPTURE (generated sample, not real traffic) ***")
        print(f"File {cap.file_name} [{cap.file_format}, {cap.backend} reader]  SHA-256 {cap.file_sha256[:16]}...")
        print(f"packets {s['total_packets']} | DNS {s['dns_packets']} (queries {s['dns_queries']}, responses "
              f"{s['dns_responses']}, UDP {s['udp']}, TCP {s['tcp']}) | malformed {s['malformed_packets']} | non-DNS "
              f"{s['non_dns_packets']} | unique names {s['unique_domains']} | parents {s['unique_parents']}")
        for fr, why in cap.malformed_examples[:5]:
            print(f"  malformed frame {fr}: {why}")
        for w in cap.warnings:
            print(f"  warning: {w}")
        print(f"query types: {s['qtype_counts']}  response codes: {s['rcode_counts']}")
        if a.save:
            db.save_analysis(res)
        merged = db.merged(res)
        print(f"\nIncidents: {s['incidents']} (critical {s['critical']}, high {s['high']}, medium {s['medium']}, "
              f"low {s['low']})")
        if merged:
            print(tabulate([[i["incident_id"], i["level"], i["score"], i["parent"], ", ".join(i["src_ips"]),
                             i["query_count"], i["unique_subdomains"], i["max_length"], i["max_entropy"], i["status"]]
                            for i in merged], ["Incident", "Level", "Score", "Domain", "Sources", "Queries", "Uniq",
                                               "MaxLen", "MaxEnt", "Status"], tablefmt="simple"))
            print("\nDetections:")
            print(tabulate([[d.name, d.parent, ", ".join(d.src_ips), fmt_ts(d.timestamp)[11:19], d.reason[:70]]
                            for d in sorted(res.detections, key=lambda x: (x.parent, x.timestamp))],
                           ["Rule", "Domain", "Source", "First", "Reason"], tablefmt="simple"))
            for i in merged:
                print(f"\n[{i['level'].upper()} {i['score']}] {i['parent']}: {i['explanation']}")
        else:
            print("No suspicious DNS patterns crossed the thresholds.")
        print(f"\n{DISCLAIMER}")
        if a.csv:
            d = Path(a.csv)
            d.mkdir(parents=True, exist_ok=True)
            (d / "dns_queries.csv").write_bytes(dns_records_csv(res))
            (d / "suspicious_domains.csv").write_bytes(suspicious_domains_csv(res))
            (d / "incidents.csv").write_bytes(incidents_csv(merged))
            print(f"CSV written to {d}/")
        if a.pdf:
            Path(a.pdf).parent.mkdir(parents=True, exist_ok=True)
            Path(a.pdf).write_bytes(pdf_report(res, merged))
            print(f"PDF written to {a.pdf}")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
