"""
config.py - detection thresholds (all configurable in the dashboard), paths and limits.

Every threshold is a starting point for a lab, not a universal truth: tune
them to your network's normal DNS behaviour before trusting the results.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "database" / "incidents.db"
SAMPLE_DIR = BASE_DIR / "sample_data"
REPORT_DIR = BASE_DIR / "reports"
LOG_FILE = BASE_DIR / "logs" / "app.log"
CSS_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "DNS Tunneling Detection and Network Traffic Analysis"
MAX_UPLOAD_MB = 200
MAX_PACKETS = 2_000_000
RISK_LEVELS = ["Low", "Medium", "High", "Critical"]
RISK_COLORS = {"Low": "#22c55e", "Medium": "#eab308", "High": "#f97316", "Critical": "#ef4444"}
INCIDENT_STATUSES = ["Open", "Investigating", "Resolved"]

DEFAULT_WEIGHTS = {
    "long_query": 15,               # the brief's example weights ...
    "high_entropy": 20,
    "excessive_frequency": 20,
    "many_unique_subdomains": 20,
    "repeated_txt": 10,
    "encoded_labels": 15,
    "unusual_qtype_distribution": 10,   # ... plus two for rules 6 and 8
    "unusual_responses": 10,
}


@dataclass
class DetectionConfig:
    # rule 1 - long queries
    max_domain_length: int = 60          # characters in the full query name
    max_subdomain_length: int = 45       # characters left of the parent domain
    max_label_length: int = 40           # longest single label (DNS allows 63)
    max_labels: int = 6                  # labels left of the parent domain
    # rule 2 - entropy
    entropy_threshold: float = 3.6       # bits per character
    entropy_min_label_length: int = 12   # entropy of short strings is meaningless
    # rule 3 - frequency
    max_queries_per_minute: int = 50     # to one parent domain within any 60 s window
    max_queries_per_source_domain: int = 100   # one source -> one parent, whole capture
    burst_window_seconds: float = 10.0
    burst_threshold: int = 30            # queries from one source within the burst window
    # rule 4 - unique subdomains
    max_unique_subdomains: int = 30      # distinct subdomains under one parent
    # rule 5 - TXT
    txt_query_threshold: int = 10        # TXT queries from one source to one parent
    # rule 6 - query types
    unusual_qtype_ratio: float = 0.30    # share of TXT/NULL/ANY/... among a source's queries
    unusual_qtype_min_queries: int = 10
    # rule 7 - encoded-looking labels
    encoded_min_label_length: int = 16
    encoded_min_queries: int = 5         # encoded-looking names to one parent before flagging
    # rule 8 - responses
    nxdomain_ratio: float = 0.50
    response_min_count: int = 10
    large_txt_answer_bytes: int = 100
    # scoring
    weights: dict = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    allowlist: list = field(default_factory=list)        # parent domains never flagged
    dns_ports: list = field(default_factory=lambda: [53])

    def validate(self) -> list[str]:
        e = []
        ints = {"max_domain_length": (10, 255), "max_subdomain_length": (5, 255), "max_label_length": (5, 63),
                "max_labels": (1, 127), "entropy_min_label_length": (2, 63), "max_queries_per_minute": (2, 10**6),
                "max_queries_per_source_domain": (2, 10**7), "burst_threshold": (2, 10**6),
                "max_unique_subdomains": (2, 10**6), "txt_query_threshold": (2, 10**6),
                "unusual_qtype_min_queries": (1, 10**6), "encoded_min_label_length": (4, 63),
                "encoded_min_queries": (1, 10**6), "response_min_count": (1, 10**6),
                "large_txt_answer_bytes": (10, 65535)}
        for k, (lo, hi) in ints.items():
            v = getattr(self, k)
            if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi:
                e.append(f"{k} must be an integer between {lo} and {hi}")
        floats = {"entropy_threshold": (0.5, 8.0), "burst_window_seconds": (0.1, 3600), "unusual_qtype_ratio": (0.01, 1),
                  "nxdomain_ratio": (0.01, 1)}
        for k, (lo, hi) in floats.items():
            v = getattr(self, k)
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
                e.append(f"{k} must be a number between {lo} and {hi}")
        for k, v in self.weights.items():
            if k not in DEFAULT_WEIGHTS:
                e.append(f"unknown weight {k}")
            elif isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 <= v <= 100:
                e.append(f"weight {k} must be between 0 and 100")
        if not self.dns_ports or not all(isinstance(p, int) and 0 < p < 65536 for p in self.dns_ports):
            e.append("dns_ports must be a list of ports")
        return e

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "DetectionConfig":
        names = {f.name for f in fields(cls)}
        c = cls(**{k: v for k, v in (d or {}).items() if k in names})
        c.weights = {**DEFAULT_WEIGHTS, **(c.weights or {})}
        return c
