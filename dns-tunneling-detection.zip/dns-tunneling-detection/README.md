# DNS Tunneling Detection and Network Traffic Analysis

**Python · Wireshark/TShark · Scapy · Pandas · NumPy · Streamlit · Plotly · Regex · SQLite · ReportLab · Pytest**

This is a defensive tool that reads DNS traffic from Wireshark captures (`.pcap` / `.pcapng`). It extracts every DNS query and response, applies **eight heuristic rules** for DNS-tunnelling behaviour, and combines them into an explainable **0–100 risk score per domain**. Incidents are tracked in SQLite, and everything is shown on an 8-page Streamlit SOC dashboard with CSV and PDF reports.

> **Defensive only.**
> - The project contains no tunnelling client or server.
> - It sends no packets and never resolves or contacts a suspicious domain.
> - The sample traffic is **synthetic**: random strings written to a file by a generator, using reserved `.test` and `example.*` names and lab or documentation IP ranges.
> - Every detection is an indicator for an analyst to validate. None of them is proof of DNS tunnelling.

---

## 1. Working principle

DNS tunnelling hides data in DNS. A client encodes bytes into subdomain labels (`<data>.attacker.example`), and the attacker's authoritative server answers with data in TXT, NULL or CNAME records. This leaves measurable traces:

| Trace | Why it happens | Rule |
|---|---|---|
| Very long names and labels | Each query carries up to ~250 bytes of encoded data | 1 long_query |
| Random-looking labels | Encoded or encrypted bytes have high Shannon entropy | 2 high_entropy |
| Many queries per minute | Data must be sent in many small chunks | 3 excessive_frequency |
| Many unique subdomains under one domain | Every chunk is a new name, so caching can't help | 4 many_unique_subdomains |
| Many TXT queries | TXT answers carry the most data back | 5 repeated_txt |
| Odd query-type mix | Workstations rarely ask for TXT, NULL or ANY | 6 unusual_qtype_distribution |
| Hex / Base32 / Base64-like labels | These are the alphabets that fit in hostnames | 7 encoded_labels |
| Many NXDOMAIN or large TXT answers | Typical answer patterns of tunnel servers | 8 unusual_responses |

## 2. Architecture

```
 Wireshark / TShark ──► .pcap / .pcapng
                             │  (upload or sample)
                             ▼
 pcap_analyzer ── Scapy reader (if installed) or built-in reader (pcap_io) ──► raw frames
       │
 dns_extractor ── Ethernet/VLAN/SLL/raw → IPv4/IPv6 → UDP/TCP 53 → DNS wire format (compression, answers)
       │                                       malformed packets counted, never fatal
       ▼
 pattern_detector ── build_query_table (entropy_analyzer: length, labels, entropy, encoding)
       │           ── frequency_detector (sliding 60 s windows, bursts)
       │           ── rules 1-8 → Detection(rule, domain, source, time, reason, threshold, evidence)
       ▼
 risk_scorer ── one incident per parent domain, each rule counted once, capped at 100, explanation
       ▼
 db_manager (SQLite) ◄──► app.py (8 pages) · analyze_pcap.py (CLI) · report_generator (CSV, PDF)
```

## 3. Folder structure

```
dns-tunneling-detection/
├── app.py                     Streamlit SOC dashboard (8 pages)
├── analyze_pcap.py            terminal analysis, incidents, status updates
├── run_demos.py               Demos 1-8 on the synthetic captures (prints PASS/FAIL)
├── config.py                  DetectionConfig: every threshold + weights + allowlist, validation
├── requirements.txt  pytest.ini  .gitignore  .streamlit/config.toml
├── detector/
│   ├── pcap_io.py             PCAP/PCAPNG readers & writers, Scapy reader, frame builders (checksums)
│   ├── pcap_analyzer.py       load capture, choose backend, statistics, synthetic marker
│   ├── dns_extractor.py       link/IP/UDP/TCP decoding + DNS wire-format parser
│   ├── entropy_analyzer.py    Shannon entropy, parent/subdomain split, encoding classes
│   ├── frequency_detector.py  sliding-window frequency, bursts, per-source/per-domain counts
│   ├── pattern_detector.py    the eight detection rules
│   ├── risk_scorer.py         incidents, de-duplicated weighted score, recommendations
│   └── engine.py              one full analysis (used by every interface)
├── database/
│   ├── db_manager.py          analyses, incidents, incident_notes
│   └── incidents.db           created on first run (sample from the demo run included)
├── utils/
│   ├── report_generator.py    CSV (records, suspicious domains, incidents) + PDF
│   ├── sample_pcap_generator.py   SYNTHETIC captures (7 scenarios)
│   └── helpers.py             upload validation, formatting, logging
├── sample_data/               sample_dns_traffic.pcap/.pcapng (550 packets, 542 DNS) + 7 demo captures
├── assets/style.css           dark SOC theme
├── tests/                     85 pytest tests
├── docs/                      WIRESHARK_GUIDE.md, DEMO_GUIDE.md, PROJECT_REPORT.md, VIVA.md
├── sample_output/             real output of run_demos.py / analyze_pcap.py, PDF + CSV
└── screenshots/               terminal and PDF screenshots
```

## 4. Installation (Kali Linux / Ubuntu)

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip wireshark tshark
cd dns-tunneling-detection
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q                      # expected: 85 passed
streamlit run app.py                     # http://localhost:8501
```

- **Windows:** use `py -m venv .venv`, then `.\.venv\Scripts\Activate.ps1`, then the same pip and streamlit commands. Install Wireshark from wireshark.org.
- **Rights:** offline PCAP analysis needs no administrator or root rights. Only live capture in Wireshark does (see the Wireshark guide).

## 5. Generating the synthetic sample captures

```bash
python -m utils.sample_pcap_generator                  # built-in writer (default)
python -m utils.sample_pcap_generator --engine scapy   # same frames written with Scapy's wrpcap
```

| File | Scenario |
|---|---|
| `sample_dns_traffic.pcap` / `.pcapng` | All scenarios, plus 2 malformed and 6 non-DNS packets: 550 packets, 542 DNS |
| `demo_normal.pcap` | 1. Normal browsing (A/AAAA/MX/PTR, one NXDOMAIN typo, 1 DNS over TCP exchange) |
| `demo_repeated.pcap` | 2. 70 queries to one name in 55 s |
| `demo_long.pcap` | 3. Long subdomains (two labels of 44–55 characters) |
| `demo_entropy.pcap` | 4. Random 30-character labels, mixed with normal traffic |
| `demo_unique.pcap` | 5. 40 unique Base32-alphabet subdomains with NXDOMAIN answers |
| `demo_txt.pcap` | 6. 25 TXT queries with 150-byte TXT answers |
| `demo_combined.pcap` | 7. Many indicators on one domain, which is expected to be Critical |

Every file is marked as synthetic: a `.synthetic` sidecar file, plus a capture comment in the pcapng file. The dashboard, CLI and PDF all show a **SYNTHETIC** banner.

## 6. Detection rules and thresholds

All thresholds can be changed on the **Detection Configuration** page, or with `analyze_pcap.py` flags.

| # | Rule | Default trigger | Weight |
|---|---|---|---|
| 1 | Long query | name > 60, subdomain > 45, label > 40 characters, or > 6 labels | 15 |
| 2 | High entropy | a label of ≥ 12 characters with entropy ≥ 3.6 bits per character | 20 |
| 3 | Frequency | > 50 queries to one domain within any 60 s, or > 100 from one source | 20 |
| 4 | Unique subdomains | ≥ 30 distinct subdomains under one parent domain | 20 |
| 5 | Repeated TXT | ≥ 10 TXT queries from one source to one domain | 10 |
| 6 | Query-type mix | ≥ 30 % TXT/NULL/ANY/… among ≥ 10 queries from a source | 10 |
| 7 | Encoded labels | ≥ 5 queries with hex/Base32/Base64-like labels of ≥ 16 characters | 15 |
| 8 | Responses | ≥ 50 % NXDOMAIN, or many TXT answers of ≥ 100 bytes (needs ≥ 10 responses) | 10 |

**Score per parent domain** = the sum of the weights of the *distinct* rules triggered, capped at 100. Each rule counts once, however many queries match it.

| Score | Risk |
|---|---|
| 0–24 | Low |
| 25–49 | Medium |
| 50–74 | High |
| 75–100 | Critical |

Use the **allowlist** for known-benign domains such as CDNs, anti-virus reputation services and telemetry.

## 7. Dashboard pages

1. **Security Overview**: 7 cards and the 8 required charts.
2. **PCAP Upload and Analysis**: samples, upload with validation and progress, statistics, malformed packets.
3. **DNS Traffic Explorer**: every DNS message, with filters for source IP, domain, direction and type, plus CSV export.
4. **Entropy Analysis**: a calculator, the distribution, the median and 95th percentile (NumPy), entropy per domain, and a label table.
5. **Suspicious Domain Detection**: the domain investigation table, detections, and drill-down into one domain.
6. **Incident Management**: severity, status and search filters, evidence, Open → Investigating → Resolved, notes and history.
7. **Reports and Downloads**: 3 CSV files, the PDF, and the analysis history.
8. **Detection Configuration**: all thresholds, weights and the allowlist, a reset button, and a confirmed database clear.

## 8. Terminal use

```bash
python analyze_pcap.py sample_data/sample_dns_traffic.pcap --save --pdf reports/report.pdf --csv reports/
python analyze_pcap.py capture.pcapng --entropy 3.4 --max-qpm 30 --allow cdn.example.net
python analyze_pcap.py --incidents
python analyze_pcap.py --set-status DNS-XXXXXXXXXX Investigating --note "checking host"
python run_demos.py
```

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| "not a PCAP or PCAPNG file" | Save from Wireshark as pcap or pcapng. A `.cap` file from other tools may be a different format. Convert it with `editcap -F pcap in.cap out.pcap`. |
| "file is truncated" warning | The capture stopped mid-write. The packets before the cut are still analysed. |
| Malformed packets listed | Expected for broken or partial packets. They are skipped and counted. |
| DNS over TCP shown as incomplete | Messages split across TCP segments are not reassembled. Wireshark can export the reassembled stream. |
| No DNS found | DNS on a non-standard port: add the port to `dns_ports` in `config.py`. DoH and DoT are encrypted and cannot be seen. |
| Too many alerts on real traffic | Raise the thresholds or allowlist benign domains (CDN hashes and AV lookups have high entropy). |
| `ModuleNotFoundError: scapy` | Optional: the built-in reader is used automatically. `pip install scapy` to use Scapy. |
| Streamlit upload limit | 200 MB (`.streamlit/config.toml` and `MAX_UPLOAD_MB`). |

See **docs/WIRESHARK_GUIDE.md** for Demo 1 and **docs/DEMO_GUIDE.md** for Demos 2–8.
