"""Loading and field extraction of exported Wazuh alerts."""

import json

import pytest

import analyze_wazuh_alerts as A
from conftest import SAMPLES, alert


def test_json_lines(jsonl):
    res = A.load_alerts(jsonl([alert(), alert(rule_id="5715", level=3, groups=["authentication_success"])]))
    assert res.source_format == "json-lines" and len(res.alerts) == 2 and res.skipped_lines == 0


def test_json_array(tmp_path):
    p = tmp_path / "a.json"
    p.write_text(json.dumps([alert(), alert()]))
    res = A.load_alerts(p)
    assert res.source_format == "json-array" and len(res.alerts) == 2


def test_single_object(tmp_path):
    p = tmp_path / "one.json"
    p.write_text(json.dumps(alert()))
    assert len(A.load_alerts(p).alerts) == 1


def test_opensearch_response(tmp_path):
    p = tmp_path / "hits.json"
    p.write_text(json.dumps({"hits": {"total": {"value": 2}, "hits": [{"_source": alert()}, {"_source": alert()}]}}))
    res = A.load_alerts(p)
    assert res.source_format == "opensearch" and len(res.alerts) == 2


def test_malformed_lines_are_skipped_not_fatal(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text(json.dumps(alert()) + "\n{not json\n42\n\n" + json.dumps(alert()) + "\n")
    res = A.load_alerts(p)
    assert len(res.alerts) == 2 and res.skipped_lines == 2


def test_empty_file(tmp_path):
    p = tmp_path / "empty.json"
    p.write_text("   \n")
    res = A.load_alerts(p)
    assert res.alerts == [] and res.source_format == "empty"


@pytest.mark.parametrize("groups,kind", [
    (["syslog", "sshd", "authentication_failed"], "failure"),                 # 5760
    (["syslog", "sshd", "invalid_login", "authentication_failed"], "failure"),  # 5710
    (["syslog", "sshd", "authentication_failures"], "failure"),               # 5763 / 5712 (Nth failure)
    (["mini_siem", "ssh_brute_force", "ssh_root_login_attempt"], "failure"),  # custom correlation
    (["syslog", "sshd", "authentication_success"], "success"),                # 5715
    (["mini_siem", "ssh_success_after_failures"], "success"),                 # 100110
    (["syscheck", "syscheck_entry_modified"], None),                          # FIM - not authentication
    ([], None),
])
def test_event_kind(groups, kind):
    assert A.event_kind(alert(groups=groups)) == kind


def test_username_from_dstuser_or_srcuser():
    assert A.username(alert(user="alice", user_field="dstuser")) == "alice"
    assert A.username(alert(user="admin", user_field="srcuser")) == "admin"      # invalid user -> srcuser
    assert A.username(alert(user=None)) == ""


def test_missing_fields_do_not_crash():
    rec = A.to_record({"rule": {"groups": ["authentication_failed"], "level": "x"}})
    assert rec["rule_level"] == 0 and rec["srcip"] == "" and rec["ip_class"] == "missing"


@pytest.mark.parametrize("ip,version,cls", [
    ("192.168.56.30", "IPv4", "private"),
    ("10.0.2.2", "IPv4", "private"),
    ("172.20.1.5", "IPv4", "private"),
    ("127.0.0.1", "IPv4", "loopback"),
    ("::1", "IPv6", "loopback"),
    ("fe80::1", "IPv6", "link-local"),
    ("fd12:3456::1", "IPv6", "private"),
    ("203.0.113.7", "IPv4", "documentation"),
    ("2001:db8::25", "IPv6", "documentation"),
    ("::ffff:192.168.1.5", "IPv4", "private"),
    ("8.8.8.8", "IPv4", "public"),          # only a classification test value - no traffic is sent
    ("2606:4700::1111", "IPv6", "public"),
    ("100.64.0.1", "IPv4", "reserved"),
    ("not-an-ip", "", "invalid"),
    ("", "", "missing"),
])
def test_classify_ip(ip, version, cls):
    assert A.classify_ip(ip) == (version, cls)


@pytest.mark.parametrize("level,label", [(0, "Informational"), (3, "Informational"), (5, "Low"), (8, "Medium"),
                                         (9, "Medium"), (10, "High"), (12, "High"), (13, "Critical"), (16, "Critical")])
def test_severity_label(level, label):
    assert A.severity_label(level) == label


def test_sample_files_are_synthetic_and_parse():
    for name in ("normal_authentication.json", "failed_login_events.json", "brute_force_events.json"):
        res = A.load_alerts(SAMPLES / name)
        assert res.alerts and res.skipped_lines == 0
        assert all(a.get("mini_siem_synthetic") is True for a in res.alerts)
        assert all(a["location"] == "/var/log/mini-siem/synthetic_auth.log" for a in res.alerts)
