"""Grouping, counting, severity summary and CSV / report export."""

import csv

import analyze_wazuh_alerts as A
import export_alert_summary as E
from conftest import SAMPLES, alert


def _failures(n, ip="192.168.56.31", user="alice", start=0):
    return [alert(srcip=ip, user=user, ts=f"2026-11-06T10:00:{start + i:02d}.000+0000") for i in range(n)]


def test_group_by_ip_counts_first_last(jsonl):
    alerts = _failures(4) + _failures(2, ip="192.168.56.40", start=30)
    a = A.analyse(jsonl(alerts))
    row = a.by_ip.set_index("srcip").loc["192.168.56.31"]
    assert row.failed_events == 4 and row.successful_logins == 0
    assert row.first_seen == "2026-11-06 10:00:00 UTC" and row.last_seen == "2026-11-06 10:00:03 UTC"
    assert a.by_ip.set_index("srcip").loc["192.168.56.40"].failed_events == 2


def test_correlation_alert_counts_as_the_failed_event_it_replaced(jsonl):
    alerts = _failures(4) + [alert(rule_id="100101", level=8, srcip="192.168.56.31", user="alice",
                                   groups=["mini_siem", "ssh_brute_force", "ssh_failed_login"],
                                   desc="Mini-SIEM: Repeated failed SSH logins", ts="2026-11-06T10:00:09.000+0000")]
    row = A.analyse(jsonl(alerts)).by_ip.iloc[0]
    assert row.failed_events == 5 and row.max_level == 8 and row.max_severity == "Medium"
    assert "100101" in row.correlation_rules


def test_targeted_usernames_and_distinct_count(jsonl):
    alerts = ([alert(srcip="192.168.56.32", user=u, user_field="srcuser",
                     groups=["sshd", "invalid_login", "authentication_failed"]) for u in ["admin", "test", "admin"]]
              + [alert(srcip="192.168.56.32", user="oracle", user_field="srcuser",
                       groups=["sshd", "invalid_login", "authentication_failed"])])
    a = A.analyse(jsonl(alerts))
    row = a.by_ip.iloc[0]
    assert row.distinct_usernames == 3
    assert row.targeted_usernames.startswith("admin (2)")
    assert "3 different usernames" in row.review_note
    assert a.by_user.iloc[0].username == "admin" and a.by_user.iloc[0].failed_events == 2


def test_success_after_failures_is_prioritised(jsonl):
    alerts = _failures(5, ip="192.168.56.36") + [
        alert(rule_id="100101", level=8, srcip="192.168.56.36", user="alice", groups=["ssh_brute_force"]),
        alert(rule_id="100110", level=14, srcip="192.168.56.36", user="alice",
              groups=["mini_siem", "ssh_success_after_failures"], ts="2026-11-06T10:01:00.000+0000"),
        alert(rule_id="5715", level=3, srcip="192.168.56.1", user="bob", groups=["authentication_success"])]
    a = A.analyse(jsonl(alerts))
    top = a.by_ip.iloc[0]
    assert top.srcip == "192.168.56.36" and top.successful_logins == 1 and top.max_severity == "Critical"
    assert "successful login after brute-force indicators" in top.review_note
    normal = a.by_ip.set_index("srcip").loc["192.168.56.1"]
    assert normal.review_note == "normal authentication activity"


def test_failures_and_success_without_correlation(jsonl):
    alerts = _failures(1, ip="192.168.56.50") + [
        alert(rule_id="5715", level=3, srcip="192.168.56.50", user="alice", groups=["authentication_success"])]
    row = A.analyse(jsonl(alerts)).by_ip.iloc[0]
    assert "check whether it is the same user" in row.review_note


def test_non_auth_alerts_ignored(jsonl):
    alerts = _failures(2) + [alert(rule_id="550", level=7, groups=["ossec", "syscheck"], srcip=None)]
    a = A.analyse(jsonl(alerts))
    assert a.total_alerts == 3 and a.auth_alerts == 2


def test_severity_summary_and_rule_summary(jsonl):
    alerts = _failures(3) + [alert(rule_id="5763", level=10, groups=["authentication_failures"]),
                             alert(rule_id="5715", level=3, groups=["authentication_success"])]
    a = A.analyse(jsonl(alerts))
    assert a.severity == {"Informational": 1, "Low": 3, "Medium": 0, "High": 1, "Critical": 0}
    assert list(a.by_rule.rule_id)[:1] == ["5763"]
    assert a.by_rule.set_index("rule_id").loc["5760"].alerts == 3


def test_rule_summary_groups_descriptions_with_ip(jsonl):
    alerts = [alert(rule_id="100101", level=8, srcip=ip, groups=["ssh_brute_force"], desc=f"Repeated from {ip}")
              for ip in ("192.168.56.31", "192.168.56.35")]
    by_rule = A.analyse(jsonl(alerts)).by_rule
    assert len(by_rule) == 1 and by_rule.iloc[0].alerts == 2


def test_empty_input(tmp_path, capsys):
    p = tmp_path / "e.json"
    p.write_text("")
    a = A.analyse(p)
    assert a.by_ip.empty and a.by_user.empty and a.by_rule.empty
    A.print_report(a)
    assert "No authentication alerts found" in capsys.readouterr().out


def test_never_says_malicious(jsonl, capsys):
    a = A.analyse(jsonl(_failures(20)))
    A.print_report(a)
    text = capsys.readouterr().out + " ".join(a.by_ip.review_note)
    assert "malicious" not in text.lower().replace("not proven attacks", "")


def test_csv_export(jsonl, tmp_path):
    a = A.analyse(jsonl(_failures(3)))
    path = A.write_csv(a.by_ip, tmp_path / "out" / "ip.csv")
    rows = list(csv.DictReader(path.open()))
    assert rows[0]["srcip"] == "192.168.56.31" and rows[0]["failed_events"] == "3"
    assert {"ip_class", "targeted_usernames", "first_seen", "last_seen", "max_severity"} <= set(rows[0])


def test_cli(jsonl, tmp_path, capsys):
    out = tmp_path / "s.csv"
    assert A.main([str(jsonl(_failures(2))), "--csv", str(out)]) == 0
    assert out.exists() and "192.168.56.31" in capsys.readouterr().out
    assert A.main([str(tmp_path / "missing.json")]) == 2


def test_samples_expected_numbers():
    a = A.analyse(SAMPLES / "brute_force_events.json")
    by = a.by_ip.set_index("srcip")
    assert by.loc["192.168.56.31"].failed_events == 8 and by.loc["192.168.56.31"].max_level == 10
    assert by.loc["192.168.56.35"].failed_events == 15 and by.loc["192.168.56.35"].max_level == 12
    assert by.loc["192.168.56.36"].max_severity == "Critical"
    normal = A.analyse(SAMPLES / "normal_authentication.json")
    assert set(normal.by_ip.ip_class) == {"private", "loopback", "documentation"}
    assert normal.by_ip.failed_events.sum() == 0


def test_export_package(tmp_path):
    files = E.export(str(SAMPLES / "failed_login_events.json"), tmp_path / "case", "Student", "CASE-7")
    for key in ("ip_summary", "username_summary", "rule_summary", "auth_events", "report"):
        assert files[key].exists()
    report = files["report"].read_text()
    assert "CASE-7" in report and "192.168.56.32" in report and "not proof of an attack" in report
    assert "## 6. Recommended investigation steps" in report
    events = list(csv.DictReader(files["auth_events"].open()))
    assert len(events) == 12 and "ts" not in events[0]


def test_export_cli(tmp_path, capsys):
    assert E.main([str(SAMPLES / "normal_authentication.json"), "--out", str(tmp_path / "r")]) == 0
    assert (tmp_path / "r" / "investigation_report.md").exists()
    assert E.main([str(tmp_path / "nope.json")]) == 2
