"""Offline checks of the Wazuh rule file, the scenarios, the replay script's safety and the logtest runner."""

import io
import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import pytest

import logtest_api_runner as L
import replay_synthetic_events as R
import scenarios as S
import validate_rules as V
from conftest import ROOT, SAMPLES

RULES = ROOT / "wazuh" / "manager" / "custom_rules.xml"


# ---------------------------------------------------------------------------------- rule file
def test_rule_file_passes_validator():
    errors, summary = V.validate_rules(RULES)
    assert errors == []
    assert {s["id"] for s in summary} == {"100101", "100102", "100103", "100104", "100105", "100110"}


def test_agent_example_passes_validator():
    assert V.validate_agent_conf() == []


def _rules():
    root = V.parse_multi_root(RULES)
    return {r.get("id"): r for r in root.iter("rule")}


def test_rule_details_match_design():
    r = _rules()
    assert r["100101"].get("frequency") == "5" and r["100101"].get("timeframe") == "120"
    assert r["100101"].findtext("if_matched_sid") == "5760" and r["100101"].find("same_srcip") is not None
    assert r["100102"].findtext("if_matched_sid") == "5710" and r["100102"].find("different_srcuser") is not None
    assert r["100103"].find("different_user") is not None
    assert r["100104"].findtext("user") == "^root$" and r["100104"].find("same_user") is not None
    assert r["100105"].get("frequency") == "15"
    assert r["100110"].findtext("if_sid") == "5715" and r["100110"].findtext("if_matched_group") == "ssh_brute_force"


def test_severity_scale():
    levels = {rid: int(x.get("level")) for rid, x in _rules().items()}
    assert 7 <= levels["100101"] <= 9 and 7 <= levels["100104"] <= 9          # Medium
    assert all(10 <= levels[i] <= 12 for i in ("100102", "100103", "100105"))  # High
    assert levels["100110"] >= 13                                                # Critical


def test_specific_rules_are_ordered_before_generic_siblings():
    order = [r.get("id") for r in V.parse_multi_root(RULES).iter("rule")]
    assert order.index("100105") < order.index("100101")
    assert order.index("100104") < order.index("100101") and order.index("100103") < order.index("100101")


def test_correlation_group_present_on_all_failure_rules():
    for rid in ("100101", "100102", "100103", "100104", "100105"):
        assert "ssh_brute_force" in (_rules()[rid].findtext("group") or "")
    assert "ssh_brute_force" not in (_rules()["100110"].findtext("group") or "")   # no self-trigger


@pytest.mark.parametrize("mutation,needle", [
    (lambda t: t.replace('id="100101"', 'id="5000"'), "outside the custom range"),
    (lambda t: t.replace('id="100102"', 'id="100101"'), "duplicate id"),
    (lambda t: t.replace('level="8"', 'level="17"'), "outside 0-16"),
    (lambda t: t.replace('timeframe="120" ', ''), "frequency without timeframe"),
    (lambda t: t.replace("<if_matched_sid>5710</if_matched_sid>", "<if_matched_sid>9999</if_matched_sid>"), "neither built-in"),
    (lambda t: t.replace("<same_srcip />", "<same_srcipp />", 1), "unknown option"),
    (lambda t: t.replace("potential brute-force activity</description>", "confirmed attacker</description>", 1), "verdict word"),
    (lambda t: t.replace("<description>", "<description", 1), "not well-formed"),
    (lambda t: t.replace("<if_matched_group>ssh_brute_force</if_matched_group>", "<if_matched_group>nope</if_matched_group>"), "not defined"),
])
def test_validator_catches_mistakes(tmp_path, mutation, needle):
    p = tmp_path / "rules.xml"
    p.write_text(mutation(RULES.read_text()))
    errors, _ = V.validate_rules(p)
    assert any(needle in e for e in errors), errors


def test_agent_validator_catches_duplicate_and_system_fim(tmp_path):
    p = tmp_path / "agent.xml"
    p.write_text("<ossec_config><localfile><location>/var/log/auth.log</location><log_format>syslog</log_format>"
                 "</localfile><localfile><location>/var/log/auth.log</location><log_format>syslog</log_format>"
                 "</localfile><syscheck><directories>/etc</directories></syscheck></ossec_config>")
    errors = V.validate_agent_conf(p)
    assert any("twice" in e for e in errors) and any("synthetic directory" in e for e in errors)


def test_no_secrets_in_project():
    pattern = re.compile(r"""(password\s*[:=]\s*["'][^"'${}<]{6,}["']|BEGIN (RSA|OPENSSH) PRIVATE KEY|api[_-]?key\s*[:=]\s*["']\w)""", re.I)
    for f in ROOT.rglob("*"):
        if f.is_file() and f.suffix in {".xml", ".example", ".md", ".py", ".sh", ".json", ".txt", ".log"} \
                and "tests" not in f.parts:
            assert not pattern.search(f.read_text(errors="ignore")), f


# ---------------------------------------------------------------------------------- scenarios
def test_scenarios_reference_existing_rules():
    custom = set(_rules())
    builtin = {"5710", "5715", "5760", "5763"}
    for s in S.SCENARIOS:
        for st in s.steps:
            assert st.expect_rule in custom | builtin, (s.key, st.expect_rule)
            if st.expect_rule in custom:
                assert int(_rules()[st.expect_rule].get("level")) == st.expect_level


def test_scenarios_use_only_private_lab_addresses():
    for s in S.SCENARIOS:
        for st in s.steps:
            ip = st.message.split(" from ")[1].split()[0]
            assert ip.startswith("192.168.56."), ip


def test_frequency_positions_match_rule_thresholds():
    r = _rules()
    t3 = S.by_key("test3_repeated_failed_logins").steps
    assert [st.expect_rule for st in t3].index("100101") + 1 == int(r["100101"].get("frequency"))
    t5 = S.by_key("test5_root_login_attempts").steps
    assert len(t5) == int(r["100104"].get("frequency")) and t5[-1].expect_rule == "100104"
    t5b = S.by_key("test5b_high_volume_failures").steps
    assert len(t5b) == int(r["100105"].get("frequency")) and t5b[-1].expect_rule == "100105"
    assert [st.expect_rule for st in t5b].index("5763") == 7                     # built-in: 8th event


def test_log_samples_match_scenarios():
    for s in S.SCENARIOS:
        lines = (SAMPLES / "logs" / f"{s.key}.log").read_text().splitlines()
        assert len(lines) == len(s.steps)
        for line, st in zip(lines, s.steps):
            assert re.match(r"^[A-Z][a-z]{2} [ \d]\d \d\d:\d\d:\d\d lab-ubuntu-agent sshd\[\d+\]: ", line)
            assert line.endswith(st.message)


def test_syslog_line_pads_day():
    assert S.syslog_line("x", datetime(2026, 11, 6, 8, 1, 2)) == "Nov  6 08:01:02 lab-ubuntu-agent sshd[4242]: x"


def test_unknown_scenario():
    with pytest.raises(KeyError):
        S.by_key("nope")


# ---------------------------------------------------------------------------------- replay safety
@pytest.mark.parametrize("target", ["/var/log/auth.log", "/var/log/secure", "/var/log/syslog", "/tmp/x.log",
                                    "/var/log/mini-siem/../auth.log"])
def test_replay_refuses_real_logs_and_outside_paths(target):
    with pytest.raises(R.UnsafeOutput):
        R.check_output(Path(target))


def test_replay_appends_only(tmp_path):
    allowed = tmp_path / "mini-siem"
    target = R.check_output(allowed / "synthetic_auth.log", allowed)
    allowed.mkdir()
    target.write_text("existing line\n")
    rc = R.main(["--scenario", "test5_root_login_attempts", "--output", str(target),
                 "--allowed-dir", str(allowed), "--delay", "0"])
    lines = target.read_text().splitlines()
    assert rc == 0 and lines[0] == "existing line" and len(lines) == 4
    assert all("Failed password for root from 192.168.56.34" in ln for ln in lines[1:])


def test_replay_refuses_symlink(tmp_path):
    allowed = tmp_path / "mini-siem"
    allowed.mkdir()
    (tmp_path / "real.log").write_text("")
    (allowed / "link.log").symlink_to(tmp_path / "real.log")
    with pytest.raises(R.UnsafeOutput):
        R.check_output(allowed / "link.log", allowed)


def test_replay_dry_run_and_list(capsys):
    assert R.main(["--list"]) == 0
    assert "test5c_success_after_failures" in capsys.readouterr().out
    assert R.main(["--scenario", "test1_normal_login", "--dry-run"]) == 0
    assert "Accepted password for alice" in capsys.readouterr().out
    assert R.main(["--scenario", "bogus", "--dry-run"]) == 2
    assert R.main(["--scenario", "test1_normal_login", "--output", "/var/log/auth.log"]) == 2


# ---------------------------------------------------------------------------------- logtest runner (fake API)
class FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeWazuh:
    """Mimics PUT /logtest: returns the rule a real session would, based on the scenario expectations."""

    def __init__(self, wrong_at=None):
        self.requests = []
        self.sessions = {}
        self.wrong_at = wrong_at

    def __call__(self, req):
        self.requests.append(req)
        path = req.full_url.split("55000")[1]
        if path == "/security/user/authenticate":
            assert req.get_header("Authorization").startswith("Basic ")
            return FakeResponse(json.dumps({"data": {"token": "jwt"}}).encode())
        if req.get_method() == "DELETE":
            return FakeResponse(b'{"data": {}}')
        body = json.loads(req.data)
        assert req.get_header("Authorization") == "Bearer jwt" and body["log_format"] == "syslog"
        token = body.get("token") or f"s{len(self.sessions)}"
        n = self.sessions[token] = self.sessions.get(token, 0) + 1
        steps = next(s.steps for s in S.SCENARIOS if s.steps[0].message.split(" port ")[0] in body["event"])
        exp = steps[n - 1]
        rid = "5760" if (self.wrong_at == n) else exp.expect_rule
        return FakeResponse(json.dumps({"data": {"token": token, "alert": True,
                                                 "output": {"rule": {"id": rid, "level": exp.expect_level,
                                                                     "description": "fake"}}}}).encode())


def test_runner_uses_session_token_and_reports_ok():
    fake = FakeWazuh()
    api = L.WazuhAPI("https://localhost:55000", None, opener=fake)
    api.login("wazuh", "pw")
    rows = L.run_scenario(api, S.by_key("test3_repeated_failed_logins"), out=io.StringIO())
    assert all(r["ok"] for r in rows) and len(rows) == 8
    bodies = [json.loads(r.data) for r in fake.requests if r.get_method() == "PUT"]
    assert "token" not in bodies[0] and all(b["token"] == "s0" for b in bodies[1:])   # same session
    assert fake.requests[-1].get_method() == "DELETE"                                    # session closed


def test_runner_reports_differences():
    api = L.WazuhAPI("https://localhost:55000", None, opener=FakeWazuh(wrong_at=5))
    api.login("wazuh", "pw")
    rows = L.run_scenario(api, S.by_key("test3_repeated_failed_logins"), out=io.StringIO())
    assert [r["n"] for r in rows if not r["ok"]] == [5]


def test_parse_result_without_rule():
    assert L.parse_result({"data": {"token": "t", "output": {}}}) == ("t", "-", None, "(no rule matched)")


def test_xml_files_parse():
    for f in (ROOT / "wazuh").rglob("*"):
        if f.suffix in {".xml", ".example"} and "local_internal" not in f.name:
            ET.fromstring(f"<r>{f.read_text()}</r>")
