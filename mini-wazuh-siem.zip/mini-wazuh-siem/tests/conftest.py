import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
SAMPLES = ROOT / "samples"


def alert(rule_id="5760", level=5, groups=("syslog", "sshd", "authentication_failed"), srcip="192.168.56.30",
          user=None, user_field="dstuser", ts="2026-11-06T10:00:00.000+0000", desc="sshd: authentication failed."):
    data = {"srcip": srcip} if srcip is not None else {}
    if user:
        data[user_field] = user
    return {"timestamp": ts, "rule": {"id": rule_id, "level": level, "groups": list(groups), "description": desc},
            "agent": {"name": "lab-ubuntu-agent"}, "data": data, "location": "/var/log/auth.log",
            "full_log": f"sshd: test line for {user}"}


def write_jsonl(path: Path, alerts) -> Path:
    path.write_text("".join(json.dumps(a) + "\n" for a in alerts), encoding="utf-8")
    return path


@pytest.fixture
def make_alert():
    return alert


@pytest.fixture
def jsonl(tmp_path):
    return lambda alerts, name="alerts.json": write_jsonl(tmp_path / name, alerts)
