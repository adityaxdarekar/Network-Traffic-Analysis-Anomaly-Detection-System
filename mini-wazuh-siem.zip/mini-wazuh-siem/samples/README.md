# Sample data - ALL SYNTHETIC

Created by `scripts/generate_samples.py` from the scenarios in `scripts/scenarios.py`.
- Addresses are private lab addresses (192.168.56.0/24, VirtualBox host-only), plus `10.0.2.2`, `::1` and
  `2001:db8:56::25` (IPv6 documentation range) in the normal-login sample.
- Usernames are fictional.

| File | Content | Use |
|---|---|---|
| `logs/test*.log` | raw sshd lines (classic syslog format) per test scenario | paste into `wazuh-logtest`; same lines as the replay script |
| `normal_authentication.json` | 5 successful-login alerts (5715) | Python helper input / tests |
| `failed_login_events.json` | 12 alerts: one failure, invalid usernames, several accounts, root attempts | Python helper input / tests |
| `brute_force_events.json` | 29 alerts: repeated failures, high volume, success after failures | Python helper input / tests |

The `.json` files use the JSON Lines layout of the manager's `/var/ossec/logs/alerts/alerts.json`, with the
documented alert fields (`rule`, `agent`, `manager`, `data`, `full_log`, `location`, ...). They are **not output of
a real Wazuh manager**. They contain the rule IDs that the scenarios are *expected* to produce. Every alert has
`"mini_siem_synthetic": true` and `location` = `/var/log/mini-siem/synthetic_auth.log`. Real alerts carry extra
fields (e.g. compliance groups) that the helpers ignore.

After your lab run, replace them with (or add next to them) a real export, and re-run the helpers on it.
