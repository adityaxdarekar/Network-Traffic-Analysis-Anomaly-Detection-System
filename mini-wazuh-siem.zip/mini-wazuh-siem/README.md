# Mini SIEM Using Wazuh for Linux Log Monitoring and Brute-Force Detection

A small but real Security Information and Event Management (SIEM) lab built on **Wazuh 4.14**. A Wazuh agent on
an Ubuntu machine collects SSH authentication logs. The Wazuh manager detects failed logins, repeated failures,
username enumeration, root attempts, high-volume failures and successful logins after failures. The Wazuh
indexer and dashboard let an analyst investigate and report.

> **Wazuh is the SIEM.** The Python scripts in this project are optional helpers: alert analysis, synthetic event
> replay, rule testing. They do not detect anything themselves.
>
> **Status:** configuration, rules, documentation and helpers are complete and tested offline (91 automated
> tests, static rule validation). The Wazuh deployment itself must be done by you in VirtualBox: this package was
> built in an environment without virtualization. See `PROJECT_STATUS.md`.

## Contents
1 Introduction · 2 Problem · 3 Objectives · 4 What is SIEM? · 5 What is Wazuh? · 6 Wazuh architecture ·
7 Technology stack · 8 Lab environment · 9 Requirements · 10 Network topology · 11 Installation · 12 Server setup ·
13 Agent setup · 14 Auth-log collection · 15 Custom rules · 16 Dashboard · 17 Testing · 18 Sample results ·
19 Troubleshooting · 20 Limitations · 21 Future enhancements · 22 Conclusion

## 1. Project introduction
Every Linux server with SSH receives login attempts, most of them harmless and some automated guessing. A SOC
analyst cannot read `/var/log/auth.log` on every machine. A SIEM collects these logs centrally, applies detection
rules, raises prioritised alerts and gives the analyst search and reporting tools. This project builds that
pipeline with Wazuh and adds custom detection rules for SSH brute-force behaviour.

## 2. Problem statement
- Authentication logs are scattered across hosts and too large to review by hand.
- A single failed login is normal. The **pattern** matters: many failures, many usernames, root as the target,
  or a success right after failures. Patterns span many log lines and need correlation over time.
- Alerts must be prioritised and explainable, without calling every failure an attack.

## 3. Objectives
1. Deploy Wazuh (manager, indexer, dashboard) and an agent in a private lab.
2. Collect Linux authentication logs (`/var/log/auth.log`, `/var/log/secure` on RHEL).
3. Detect failed, invalid-user and successful SSH logins (built-in rules).
4. Detect repeated failures, multiple usernames, repeated root attempts, high volume and success-after-failures
   (custom rules).
5. Identify and analyse suspicious source IP addresses without blocking them automatically.
6. Visualise alerts on the Wazuh dashboard and produce investigation reports.
7. Optional: File Integrity Monitoring of a synthetic test directory.

## 4. What is SIEM?
A SIEM **collects** security events from many systems, **normalises** them into fields (IP, user, time),
**correlates** them with rules (e.g. "5 failures from one IP in 2 minutes"), **alerts** with a severity, and
supports **investigation and reporting**. It turns raw logs into decisions.

## 5. What is Wazuh?
Wazuh is a free, open-source security platform (XDR/SIEM). It provides agents for endpoints, a manager with a
large ruleset of decoders and rules (including SSH, PAM and File Integrity Monitoring), an OpenSearch-based
indexer, and a web dashboard. Official documentation: https://documentation.wazuh.com/

## 6. Wazuh architecture
Agent → manager (decoding + rules) → Filebeat → indexer → dashboard. See `PROJECT_ARCHITECTURE.md` for the
diagram and the life of one event.

## 7. Technology stack
| Layer | Technology |
|---|---|
| SIEM | Wazuh 4.14.10: manager, indexer, dashboard, agent |
| OS | Ubuntu Server 24.04 LTS (server and monitored machine) |
| Logs | OpenSSH 9.6 → rsyslog → `/var/log/auth.log` |
| Detection | Wazuh built-in sshd rules + custom XML rules (`wazuh/manager/custom_rules.xml`) |
| Virtualisation | VirtualBox, host-only network 192.168.56.0/24 |
| Optional helpers | Python 3 (json, collections, pandas), pytest |

## 8. Lab environment
**Option A (recommended, used throughout):**
- VM 1 `wazuh-server` (192.168.56.10): Wazuh all-in-one.
- VM 2 `lab-ubuntu-agent` (192.168.56.20): Wazuh agent and sshd.

**Option B (smaller PC):** one VM with the all-in-one server, which also acts as the monitored machine. The
manager monitors its own `/var/log/auth.log` through its built-in local agent (agent ID 000). The same rules
apply, and alerts show agent `000`.

## 9. Hardware and software requirements
| | Server VM (from the Wazuh Quickstart table, 1-25 agents) | Agent VM | Host PC |
|---|---|---|---|
| CPU | 4 vCPU | 1-2 vCPU | 6+ cores recommended |
| RAM | 8 GiB | 2 GiB | 16 GB (8 + 2 + host) |
| Disk | 50 GB (90 days of alerts) | 20 GB | ~80 GB free |
| Software | Ubuntu Server 24.04 | Ubuntu Server 24.04 + OpenSSH server | VirtualBox 7, a modern browser |

## 10. Network topology
NAT adapter for downloads, plus a host-only network for all lab traffic. Ports: 1514/TCP (events), 1515/TCP
(enrollment), 443/TCP (dashboard), 55000/TCP (API, local), 9200/TCP (indexer, local). Nothing is forwarded or
exposed publicly. Details and firewall commands: `deployment/network_requirements.md`.

## 11. Installation instructions (overview)
1. Create the two VMs with static host-only IPs → `deployment/network_requirements.md`
2. Install the Wazuh server → `deployment/server_setup.md`
3. Install and enroll the agent → `deployment/agent_setup.md`
4. Configure log collection on the agent → `wazuh/agent/ossec.conf.example`
5. Install and test the custom rules → `deployment/server_setup.md` step 7, `documentation/TESTING_GUIDE.md`
6. Build the dashboard views → `wazuh/dashboards/dashboard_setup.md`

## 12. Server setup
```bash
curl -sO https://packages.wazuh.com/4.14/wazuh-install.sh && sudo bash ./wazuh-install.sh -a
sudo sed -i "s/^deb /#deb /" /etc/apt/sources.list.d/wazuh.list && sudo apt update     # stop accidental upgrades
sudo systemctl status wazuh-manager wazuh-indexer wazuh-dashboard filebeat --no-pager | grep -E "●|Active:"
```
Dashboard: `https://192.168.56.10`, user `admin`, password printed by the installer.

## 13. Agent setup
```bash
sudo apt-get install -y gnupg apt-transport-https curl
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | sudo gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg --import && sudo chmod 644 /usr/share/keyrings/wazuh.gpg
echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" | sudo tee -a /etc/apt/sources.list.d/wazuh.list
sudo apt-get update && apt-cache policy wazuh-agent        # must not be newer than the manager
sudo WAZUH_MANAGER="192.168.56.10" apt-get install -y wazuh-agent
sudo systemctl daemon-reload && sudo systemctl enable --now wazuh-agent
sudo /var/ossec/bin/agent_control -l                       # on the MANAGER: agent listed as Active
```

## 14. Authentication log collection
Agent `ossec.conf` (only add what's missing; the installer usually adds auth.log already):
```xml
<localfile>
  <location>/var/log/auth.log</location>      <!-- RHEL/CentOS: /var/log/secure -->
  <log_format>syslog</log_format>
</localfile>
```
A second `localfile` collects `/var/log/mini-siem/synthetic_auth.log`, used for safe, repeatable demos.
A journald alternative and every option are explained in `wazuh/agent/ossec.conf.example`.

**Important:** use Ubuntu 24.04 (OpenSSH 9.6) for the monitored machine. OpenSSH ≥ 9.8 logs failures as
`sshd-session`, which the default Wazuh sshd decoders don't parse yet (Wazuh issue #39954).

## 15. Custom detection rules
| ID | Name | Logic | Level |
|---|---|---|---|
| 100101 | Repeated failed logins | 5 × 5760 from one IP in 120 s | 8 Medium |
| 100102 | Several non-existent usernames | 4 × 5710 from one IP in 300 s, `different_srcuser` | 10 High |
| 100103 | Several existing accounts | 4 × 5760 from one IP in 300 s, `different_user` | 10 High |
| 100104 | Repeated root failures | 3 × 5760 for root from one IP in 300 s | 9 Medium |
| 100105 | High-volume failures | 15 × 5760 from one IP in 300 s | 12 High |
| 100110 | Success after brute-force indicators | 5715 after any of the above from the same IP within 600 s | 14 Critical |

Built-in rules used unchanged: 5710, 5715, 5760 (single events), 5712, 5763 (built-in brute force).
Full explanation, limits and safe installation: `wazuh/manager/CUSTOM_RULES_README.md`.
Methodology: `detection/`.

## 16. Dashboard configuration
Ten documented visualizations: total alerts, authentication alerts, failed logins, successful logins, top source
IPs, most targeted usernames, severity distribution, brute-force detections, activity over time and recent
events. There are also saved searches, DQL queries and time ranges, all in `wazuh/dashboards/dashboard_setup.md`.
Example queries:
`rule.groups:"mini_siem"` · `data.srcip:"192.168.56.31"` · `rule.level >= 10` ·
`location:"/var/log/mini-siem/synthetic_auth.log"`.

## 17. Testing procedures
| Test | Scenario | Expected (to verify on your manager) |
|---|---|---|
| 1 Normal successful login | `test1_normal_login` | 5715 (level 3) |
| 2 One failed login | `test2_one_failed_login` | 5760 (level 5) |
| 3 Repeated failed logins | `test3_repeated_failed_logins` | 5th line 100101, 8th line 5763 |
| 4 Multiple usernames | `test4a_…` / `test4b_…` | 4th line 100102 / 100103 |
| 5 Root login attempts | `test5_root_login_attempts` | 3rd line 100104 |
| 5b High volume | `test5b_high_volume_failures` | 15th line 100105 |
| 5c Success after failures | `test5c_success_after_failures` | 6th line 100110 |
| 6 File modification (FIM) | `/opt/mini-siem-fim-test` | 554 / 550 / 553 |

Commands:
- `python3 -m pytest -v` (offline)
- `sudo /var/ossec/bin/wazuh-logtest` with `samples/logs/*.log`
- `python3 scripts/logtest_api_runner.py --insecure` (manager)
- `sudo python3 replay_synthetic_events.py --scenario <name>` (agent)

Full guide with per-line expectations: `documentation/TESTING_GUIDE.md`.

## 18. Sample results
- **Verified offline:** the analysis helper on the synthetic sample alerts (`samples/*.json`, 46 alerts) produces
  this per-IP summary (`python3 scripts/analyze_wazuh_alerts.py` on all three files):

| Source IP | Class | Failed | Success | Usernames | Highest | Note |
|---|---|---|---|---|---|---|
| 192.168.56.36 | private | 5 | 1 | 1 | 14 Critical | successful login after brute-force indicators |
| 192.168.56.35 | private | 15 | 0 | 1 | 12 High | correlation rule fired |
| 192.168.56.31 | private | 8 | 0 | 1 | 10 High | correlation rule fired |
| 192.168.56.32 | private | 4 | 0 | 4 | 10 High | 4 different usernames |
| 192.168.56.33 | private | 4 | 0 | 4 | 10 High | 4 different usernames |
| 192.168.56.34 | private | 3 | 0 | 1 | 9 Medium | correlation rule fired (root) |
| 192.168.56.30 | private | 1 | 0 | 1 | 5 Low | no correlation rule fired |

  Severity of the 46 sample alerts: Informational 5, Low 31, Medium 4, High 5, Critical 1.
- **To be recorded by you:** real Wazuh results (logtest, dashboard, screenshots) in
  `documentation/VERIFIED_RESULTS.md`. These numbers come from synthetic alerts that contain the *expected* rule
  IDs. They demonstrate the analysis, not Wazuh's detection.

## 19. Troubleshooting
XML errors, rule conflicts, wrong field names, a disconnected agent, logs not collected, no alerts, the dashboard
not loading and time problems are covered step by step in `documentation/TROUBLESHOOTING.md`.

## 20. Limitations
- **Not deployed in the build environment:** rule IDs per scenario are expectations to confirm with
  wazuh-logtest.
- **Correlation is by source IP:** NAT, VPNs and shared hosts merge users. Success-after-failures can't prove that
  the same person guessed the password.
- **Evasion:** slow attacks (below the time windows) and distributed attacks (many IPs) evade `same_srcip`
  frequency rules.
- **Counting:** Wazuh counts log events, and one SSH attempt can write several lines. Rule `ignore` timers apply
  per rule, not per IP.
- **OpenSSH ≥ 9.8** (`sshd-session`) is not decoded by the default sshd decoders yet.
- **No enrichment:** no threat-intelligence or geo enrichment, and no automatic response, by design for this
  version.
- **Single-node lab:** no high availability and no long-term retention planning.

## 21. Future enhancements
- Active response (e.g. temporary firewall block) **after** false-positive tuning, with an allow-list.
- Threat-intelligence (CDB lists) and GeoIP enrichment of `data.srcip`.
- Email/Slack notifications for level ≥ 12.
- Custom decoders for `sshd-session` once the format is confirmed in your lab, or the official fix when Wazuh
  releases it.
- More sources: sudo, web server logs, Windows agents (RDP brute force).
- Multi-node indexer and retention policies; MITRE ATT&CK dashboard views.

## 22. Conclusion
The project shows the full SOC workflow on a real SIEM platform:
- **collect:** agent and authentication logs
- **detect:** built-in plus custom correlation rules with a clear severity scale
- **investigate:** dashboard searches and per-IP analysis
- **report:** investigation template and export

The design focuses on correct use of Wazuh features (parent rules, frequency, `same_srcip`, field names), safe
testing with synthetic data in a private lab, and honest wording: suspicious behaviour, not confirmed attacks.

---
**Folder overview:** `deployment/` (install guides) · `wazuh/` (rules, agent config, dashboard guide) ·
`detection/` (methodology) · `scripts/` (helpers) · `samples/` (synthetic data) · `tests/` (pytest) ·
`reports/` (template) · `documentation/` (testing, demo, troubleshooting, verified results) ·
`COLLEGE_PROJECT_REPORT.md` · `PROJECT_ARCHITECTURE.md` · `PROJECT_STATUS.md`.
