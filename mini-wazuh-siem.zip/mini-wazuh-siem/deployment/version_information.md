# Version information

| Item | Value used by this project | Source |
|---|---|---|
| Wazuh release | **4.14.10** (latest 4.x release at the time of writing, published 5 November 2026) | Wazuh release notes |
| Installation assistant | `https://packages.wazuh.com/4.14/wazuh-install.sh` | Wazuh Quickstart |
| Agent package repository | `https://packages.wazuh.com/4.x/apt/ stable main` | "Deploying Wazuh agents on Linux endpoints" (4.14) |
| Server OS | Ubuntu 24.04 LTS (on the Quickstart's supported list) | Wazuh Quickstart |
| Agent OS | Ubuntu 24.04 LTS | see the OpenSSH note below |
| OpenSSH on Ubuntu 24.04 | 9.6p1 (logs as `sshd[pid]`) | Ubuntu package archive |

> A 5.0 release-candidate documentation branch exists. This project uses the stable 4.14 line only. Do not mix
> 4.x and 5.x components.

## Compatibility rules
- **Manager, indexer and dashboard** come from the same installation assistant run, so they always match.
- **Agent ≤ manager.** Wazuh guarantees agent/manager compatibility only when the manager is the same version or
  newer than the agent. The agent repository (`4.x`) always offers the newest 4.x agent, so:
  1. install the server first and note its version: `/var/ossec/bin/wazuh-control info` on the manager;
  2. on the agent, check the offered version before installing: `apt-cache policy wazuh-agent`;
  3. after installing, stop automatic upgrades (commands in `agent_setup.md`), as the documentation recommends.
- After installing the server, the Quickstart also recommends disabling the Wazuh repository on the server so an
  unattended `apt upgrade` cannot upgrade single components (commands in `server_setup.md`).

## Why Ubuntu 24.04 for the monitored machine (important)
OpenSSH 9.8 and newer split the SSH daemon into `sshd` and `sshd-session`. Failed-login lines then come from
`sshd-session[pid]`, and the default Wazuh sshd decoders do not extract the source IP and username from them.
In that case the brute-force rules (5763 and the custom rules here) never fire, and nothing reports an error.
Wazuh GitHub issue #39954 (opened 4 October 2026, still open) confirms this on Ubuntu 26.04 with OpenSSH 10.2.

Ubuntu 24.04 ships OpenSSH 9.6, so its logs use the classic `sshd[pid]` format that the built-in rules handle.
Check on the agent:
```bash
ssh -V                                         # OpenSSH_9.6p1 on Ubuntu 24.04
sudo grep -c "sshd-session\[" /var/log/auth.log  # 0 = classic format
```
If you must use a newer distribution, follow issue #39954 for a fix. Until then, use the synthetic log file in
this project, which is always written in the classic format.

## Record your installed versions here (fill in during the lab)
| Component | Version shown | Command |
|---|---|---|
| Wazuh manager | | `/var/ossec/bin/wazuh-control info` |
| Wazuh agent | | `/var/ossec/bin/wazuh-control info` (on the agent) |
| Wazuh dashboard | | dashboard → menu → About / Server API page |
| OpenSSH on agent | | `ssh -V` |
