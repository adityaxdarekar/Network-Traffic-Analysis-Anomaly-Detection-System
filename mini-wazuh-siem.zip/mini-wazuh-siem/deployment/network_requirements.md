# Network requirements (private VirtualBox lab)

## Topology (Option A - recommended)
```
                  Host PC (VirtualBox, browser for the dashboard: https://192.168.56.10)
                         | 192.168.56.1
   ======================+============================ Host-only network vboxnet0 192.168.56.0/24
         |                                     |
  +------+-----------------+         +---------+--------------+
  | wazuh-server           |         | lab-ubuntu-agent       |
  | Ubuntu 24.04           |         | Ubuntu 24.04           |
  | 192.168.56.10          |  1514   | 192.168.56.20          |
  | manager + indexer +    |<--------| Wazuh agent            |
  | dashboard (all-in-one) |  1515   | sshd, /var/log/auth.log|
  +------+-----------------+         +---------+--------------+
         | adapter 1: NAT (internet for package downloads only)
```
- **Adapter 1: NAT.** Gives each VM internet access for `apt` and the Wazuh packages. VirtualBox NAT does not
  accept connections from outside, so nothing is exposed.
- **Adapter 2: Host-only (`vboxnet0`, 192.168.56.0/24).** Carries all lab traffic: agent ↔ manager and the
  browser on your PC → dashboard. It is reachable only from your own PC.
- Do **not** use "Bridged Adapter" for the server. That would put the dashboard on your home or college network.

## Static addresses (netplan, both VMs)
Find the host-only interface name with `ip -br link` (often `enp0s8`). Then create
`/etc/netplan/60-lab.yaml` on the server:
```yaml
network:
  version: 2
  ethernets:
    enp0s8:
      dhcp4: false
      addresses: [192.168.56.10/24]
```
On the agent, use `192.168.56.20/24`. Then apply it:
```bash
sudo chmod 600 /etc/netplan/60-lab.yaml
sudo netplan apply
ip -br addr
```

## Ports
From the Wazuh architecture documentation:

| Component | Port | Protocol | Purpose | Who needs access in this lab |
|---|---|---|---|---|
| Wazuh server | 1514 | TCP | Agent connection service | agent VM → server |
| Wazuh server | 1515 | TCP | Agent enrollment service | agent VM → server (enrollment) |
| Wazuh server | 55000 | TCP | Wazuh server RESTful API | dashboard (local); `logtest_api_runner.py` on the server |
| Wazuh indexer | 9200 | TCP | Indexer RESTful API | local only (Filebeat, dashboard) |
| Wazuh indexer | 9300-9400 | TCP | Indexer cluster communication | not used (single node) |
| Wazuh dashboard | 443 | TCP | Web user interface | your PC (host-only network) |
| Wazuh server | 1516 | TCP | Cluster daemon | not used (single node) |
| Wazuh server | 514 | UDP/TCP | Syslog collector (disabled by default) | not used |

## Optional host firewall on the server (UFW)
This allows only the lab subnet to reach the dashboard and agent ports. Don't remove an existing SSH rule you
still need.
```bash
sudo ufw allow from 192.168.56.0/24 to any port 22 proto tcp     # your own admin SSH, if used
sudo ufw allow from 192.168.56.0/24 to any port 443 proto tcp
sudo ufw allow from 192.168.56.0/24 to any port 1514 proto tcp
sudo ufw allow from 192.168.56.0/24 to any port 1515 proto tcp
sudo ufw enable
sudo ufw status numbered
```
Ports 9200 and 55000 need no rule: the dashboard reaches them on the same machine.

## Rules for this lab
- Never forward ports 443, 1514, 1515, 9200 or 55000 from your router or a cloud firewall.
- All test traffic stays inside 192.168.56.0/24. No public IP addresses and no third-party systems.
- Time: keep both VMs in sync (`timedatectl` should show "System clock synchronized: yes").
  Unsynchronised clocks put events at the wrong place on the dashboard timeline.
