# Wazuh agent installation, enrollment and verification (Ubuntu 24.04 monitored machine)

## 1. Create the VM
| Setting | Value |
|---|---|
| OS | Ubuntu Server 24.04 LTS |
| vCPU / RAM / disk | 1-2 vCPU, 2 GiB RAM, 20 GB (enough for an agent and sshd) |
| Network | Adapter 1 NAT, adapter 2 Host-only `vboxnet0` |
| Hostname | `lab-ubuntu-agent` |
| Static IP | 192.168.56.20/24 (see `network_requirements.md`) |
| Software | OpenSSH Server (select it in the installer, or `sudo apt install openssh-server`) |

Check that the server is reachable:
```bash
ping -c 2 192.168.56.10
nc -zv 192.168.56.10 1514; nc -zv 192.168.56.10 1515
```

## 2. Check the version before installing
The agent must not be newer than the manager. Note the manager version
(`/var/ossec/bin/wazuh-control info` on the server).

## 3. Add the Wazuh repository
Commands from the Wazuh 4.14 documentation, "Deploying Wazuh agents on Linux endpoints":
```bash
sudo apt-get install -y gnupg apt-transport-https curl
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | sudo gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg --import && sudo chmod 644 /usr/share/keyrings/wazuh.gpg
echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" | sudo tee -a /etc/apt/sources.list.d/wazuh.list
sudo apt-get update
apt-cache policy wazuh-agent           # "Candidate:" must not be newer than your manager
```

## 4. Install, connect to the manager and start
`WAZUH_MANAGER` writes the manager address into the agent configuration. The agent then enrolls itself through
port 1515 the first time it starts.
```bash
sudo WAZUH_MANAGER="192.168.56.10" apt-get install -y wazuh-agent
# If the candidate is newer than the manager, install the manager's version instead, e.g.:
#   sudo WAZUH_MANAGER="192.168.56.10" apt-get install -y wazuh-agent=<manager version>-1
sudo systemctl daemon-reload
sudo systemctl enable wazuh-agent
sudo systemctl start wazuh-agent
```

## 5. Stop automatic agent upgrades (recommended)
```bash
sudo sed -i "s/^deb /#deb /" /etc/apt/sources.list.d/wazuh.list
sudo apt-get update
# or keep the repository and only hold the package:
# echo "wazuh-agent hold" | sudo dpkg --set-selections
```

## 6. Verify communication
On the **agent**:
```bash
sudo systemctl status wazuh-agent --no-pager | grep Active
sudo grep -E "Connected to the server|ERROR" /var/ossec/logs/ossec.log | tail -n 5
```
On the **manager**:
```bash
sudo /var/ossec/bin/agent_control -l     # lists agents and their status
sudo /var/ossec/bin/agent_control -lc    # only connected agents
```
In the dashboard: **Agents** (Endpoints summary) → `lab-ubuntu-agent` should show **Active**.

## 7. Configure authentication-log collection
See `wazuh/agent/ossec.conf.example` for the blocks and an explanation of each option.
```bash
sudo cp /var/ossec/etc/ossec.conf /var/ossec/etc/ossec.conf.bak
sudo grep -n "<location>" /var/ossec/etc/ossec.conf     # is /var/log/auth.log already listed?
sudo nano /var/ossec/etc/ossec.conf                     # append only the missing blocks at the end
sudo mkdir -p /var/log/mini-siem && sudo touch /var/log/mini-siem/synthetic_auth.log
sudo chmod 750 /var/log/mini-siem && sudo chmod 640 /var/log/mini-siem/synthetic_auth.log
sudo mkdir -p /opt/mini-siem-fim-test                   # only if you use the optional FIM demo
sudo systemctl restart wazuh-agent
sudo grep -E "Analyzing file|ERROR" /var/ossec/logs/ossec.log | tail -n 10
```
The last command should list `Analyzing file: '/var/log/auth.log'` and
`'/var/log/mini-siem/synthetic_auth.log'`.

Also confirm the real log is being written, and in which format:
```bash
sudo tail -n 3 /var/log/auth.log
ssh -V                 # Ubuntu 24.04: OpenSSH_9.6p1 (classic "sshd[pid]" lines)
```
Paste one real `sshd` line from `auth.log` into `wazuh-logtest` on the manager. Phase 1 must show
`program_name: 'sshd'`. If Ubuntu writes ISO-format timestamps, this check confirms that Wazuh pre-decodes them.

## 8. CentOS / RHEL agents (optional)
Use the RPM instructions on the same Wazuh documentation page, and collect `/var/log/secure` instead of
`/var/log/auth.log` (block 1b in `ossec.conf.example`). The SSH unit there is `sshd.service`.
