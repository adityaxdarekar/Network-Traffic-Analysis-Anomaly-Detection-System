# Wazuh server installation (all-in-one: manager + indexer + dashboard)

Official method: the **Wazuh installation assistant** from the Quickstart guide (Wazuh 4.14).

## 1. Create the VM (VirtualBox)
| Setting | Value | Basis |
|---|---|---|
| OS | Ubuntu Server 24.04 LTS (64-bit) | listed as supported in the Quickstart |
| vCPU | **4** | Quickstart hardware table, 1-25 agents |
| RAM | **8 GiB** | Quickstart hardware table, 1-25 agents |
| Disk | **50 GB** (dynamically allocated is fine) | Quickstart: 50 GB for 90 days of alerts, 1-25 agents |
| Network | Adapter 1 NAT, adapter 2 Host-only `vboxnet0` | `network_requirements.md` |
| Hostname | `wazuh-server` | |
| Static IP | 192.168.56.10/24 on the host-only adapter | |

During Ubuntu setup, create your own admin user with a strong password, and install OpenSSH Server if you want
to administer the VM over SSH.

## 2. Prepare the system
```bash
sudo apt update && sudo apt -y full-upgrade
sudo timedatectl set-timezone <Your/Timezone>   # e.g. Asia/Kolkata, Europe/Berlin
timedatectl                                     # "System clock synchronized: yes"
free -g; nproc; df -h /                         # 8 GiB RAM, 4 CPUs, 50 GB disk
```

## 3. Install (single command from the Quickstart)
```bash
curl -sO https://packages.wazuh.com/4.14/wazuh-install.sh && sudo bash ./wazuh-install.sh -a
```
This installs and configures the manager, indexer, dashboard and Filebeat, and generates certificates. It takes
5-15 minutes. At the end, the assistant prints the dashboard URL, the `admin` user and its **password**. Copy the
password into a password manager. Don't put it in this project folder or in your report.

To show the passwords again later (indexer users and the Wazuh API user `wazuh`, which the logtest runner needs):
```bash
sudo tar -O -xvf wazuh-install-files.tar wazuh-install-files/wazuh-passwords.txt
```
`wazuh-install-files.tar` contains all certificates and passwords. Keep it in the admin user's home directory
with `chmod 600 wazuh-install-files.tar`, and never copy it into a repository.

## 4. Stop accidental upgrades (recommended by the Quickstart)
```bash
sudo sed -i "s/^deb /#deb /" /etc/apt/sources.list.d/wazuh.list
sudo apt update
```

## 5. Verify the services
```bash
sudo systemctl status wazuh-manager wazuh-indexer wazuh-dashboard filebeat --no-pager | grep -E "●|Active:"
sudo /var/ossec/bin/wazuh-control info          # installed Wazuh version (record it)
sudo /var/ossec/bin/wazuh-control status        # manager daemons, should show "... is running"
sudo ss -tlnp | grep -E ":(443|1514|1515|9200|55000) "
```
All four services should be `active (running)`, and the five ports should be listening.

## 6. Dashboard access
Open the dashboard on your PC (not from the internet): `https://192.168.56.10`
- User `admin`, with the password from step 3.
- The browser warns that the certificate "was not issued by a trusted authority". That's expected for the
  self-signed lab certificate. Accept the exception for this lab address only.

## 7. Install the custom rules
Copy the project to the server (e.g. `scp -r mini-wazuh-siem <you>@192.168.56.10:~`). Then run:
```bash
cd ~/mini-wazuh-siem
python3 scripts/validate_rules.py                       # offline checks (should end with OK)
sudo bash scripts/verify_installed_ruleset.sh           # read-only: parent rules exist, IDs are free
sudo cp wazuh/manager/custom_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo chown --reference=/var/ossec/etc/rules/local_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo chmod --reference=/var/ossec/etc/rules/local_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo /var/ossec/bin/wazuh-analysisd -t && echo "RULES OK"   # exit 0 = configuration and rules load
sudo systemctl restart wazuh-manager
sudo systemctl status wazuh-manager --no-pager | grep Active
sudo grep -iE "error|warning" /var/ossec/logs/ossec.log | tail -n 20
```
- `wazuh-analysisd -t` checks the configuration and rules without restarting the manager. Run it **before**
  every restart. A rule error can stop the manager from starting.
- Don't edit files in `/var/ossec/ruleset/rules/`. Upgrades overwrite them. Custom rules belong in
  `/var/ossec/etc/rules/`.
- To roll back: `sudo rm /var/ossec/etc/rules/custom_rules.xml && sudo systemctl restart wazuh-manager`.

## 8. Test the rules (no agent needed yet)
See `documentation/TESTING_GUIDE.md`, part A: wazuh-logtest, plus the automated API runner:
```bash
python3 scripts/logtest_api_runner.py --user wazuh --insecure      # password from wazuh-passwords.txt
```

## Alternative: Docker (official repository only)
Wazuh also publishes a Docker deployment, the `wazuh/wazuh-docker` repository, with a single-node configuration.
If you use it, check out the tag that matches your Wazuh version and follow that repository's README for that tag.
This project's documentation uses the package installation above, because the paths (`/var/ossec/...`) and
`systemctl` commands differ inside containers.
