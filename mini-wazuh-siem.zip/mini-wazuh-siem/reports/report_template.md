# Security Investigation Report - SSH Authentication Activity

> Template. `scripts/export_alert_summary.py` fills in sections 1-5 automatically from exported alerts.
> Complete sections 6-8 by hand. Classification: **internal / sensitive** (contains IPs and usernames).

| Field | Value |
|---|---|
| Case ID | CASE-____ |
| Analyst | |
| Date / time (UTC) | |
| Monitored system(s) | `agent.name` = |
| Time range investigated | from ____ to ____ |
| Data source | Wazuh dashboard saved searches / exported alerts file |

## 1. Summary
_One paragraph: what was detected, by which rule, from which source, and the current status._

## 2. Findings requiring review
| Source IP | Class | Failed events | Successful logins | Usernames | First seen | Last seen | Highest rule / level |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## 3. Timeline
| Time (UTC) | Rule ID | Level | Description | Source IP | User |
|---|---|---|---|---|---|
| | | | | | |

## 4. Targeted usernames
| Username | Exists on system? | Failed events | Successful logins |
|---|---|---|---|

## 5. Detection rules involved
| Rule ID | Level | Description | Alerts |
|---|---|---|---|

## 6. Analysis
- Is the source known (admin, scanner, NAT gateway)?
- Pattern: one account vs many usernames; root involved?
- Any successful login from the source? Same user as the failures?
- Is the activity ongoing?

## 7. Conclusion
☐ False positive (reason: ____)  ☐ Policy issue (e.g. password auth enabled)  ☐ Security incident → escalated to ____

Wording: describe "potential brute-force activity" / "suspicious authentication behaviour" unless evidence
confirms an incident.

## 8. Actions and recommendations
| Action | Owner | Status |
|---|---|---|
| Confirm activity with account owner | | |
| Reset password / review authorized_keys (if a success is unexplained) | | |
| SSH hardening (key-only, PermitRootLogin no, AllowUsers) | | |
| Firewall decision (manual; no automatic blocking) | | |

Attachments: dashboard screenshots, `ip_summary.csv`, `auth_events.csv`.
