# Wazuh dashboard - views, filters and visualizations for the demo

> **Status:** these are step-by-step instructions. No visualization or screenshot was created by the author of
> this package, because no Wazuh dashboard was available in the build environment. Create them in your lab and
> add your own screenshots to `documentation/screenshots/`.

Wazuh 4.14's dashboard is based on OpenSearch Dashboards. Menu labels can differ slightly between 4.x releases.
If a label isn't found, use the search box in the main menu (☰).

## 1. Built-in views to use first (nothing to create)
| View | Where | What to show |
|---|---|---|
| Overview | ☰ → Overview | total alerts, alerts by level, agents |
| Threat Hunting | ☰ → Threat intelligence → Threat Hunting | event list + charts; supports DQL queries |
| File Integrity Monitoring | ☰ → Endpoint security → File Integrity Monitoring | FIM test (optional) |
| Agents | ☰ → Agents management → Summary | agent status Active / Disconnected |
| Ruleset test | ☰ → Server management → Ruleset test (or Tools) | wazuh-logtest in the browser |
| Discover | ☰ → Explore → Discover | raw alert documents, index pattern `wazuh-alerts-*` |

## 2. Fields used in this project
| Field | Meaning |
|---|---|
| `timestamp` | when the manager generated the alert |
| `rule.id`, `rule.level`, `rule.description`, `rule.groups` | which rule fired and how severe |
| `rule.firedtimes` | how often this rule fired since the manager started |
| `data.srcip`, `data.srcport` | source address and port of the SSH client |
| `data.dstuser` | username of an **existing** account (Failed/Accepted password) |
| `data.srcuser` | username that **does not exist** (Invalid user) |
| `agent.name`, `agent.ip` | monitored machine |
| `location` | source file (`/var/log/auth.log` or the synthetic file) |
| `full_log` | original log line |
| `syscheck.path`, `syscheck.event` | FIM file path and event (optional extension) |

Check the field names in your installation: open one SSH alert in Discover and expand it.

## 3. Saved searches (Discover → query → Save)
| Name | DQL query | Time range |
|---|---|---|
| Mini-SIEM - all SSH authentication | `rule.groups:"sshd" and (rule.groups:"authentication_failed" or rule.groups:"authentication_success" or rule.groups:"authentication_failures")` | Last 24 hours |
| Mini-SIEM - failed SSH logins | `rule.groups:"authentication_failed" and rule.groups:"sshd"` | Last 24 hours |
| Mini-SIEM - successful SSH logins | `rule.id:5715` | Last 7 days |
| Mini-SIEM - brute-force detections | `rule.groups:"ssh_brute_force" or rule.id:(5712 or 5763)` | Last 24 hours |
| Mini-SIEM - custom detections | `rule.groups:"mini_siem"` | Last 24 hours |
| Mini-SIEM - critical: success after failures | `rule.id:100110 or rule.id:40112` | Last 7 days |
| Mini-SIEM - synthetic demo events | `location:"/var/log/mini-siem/synthetic_auth.log"` | Last 1 hour |

Useful columns: `timestamp, rule.id, rule.level, rule.description, data.srcip, data.dstuser, data.srcuser,
agent.name`.

## 4. Visualizations (☰ → Explore → Visualize → Create visualization)
Use the index pattern `wazuh-alerts-*` for all of them. Apply the saved search or query shown in the table.

| # | Visualization | Type | Configuration |
|---|---|---|---|
| 1 | Total security alerts | Metric | Metric: Count. No query. |
| 2 | Authentication-related alerts | Metric | Count; query `rule.groups:"authentication_failed" or rule.groups:"authentication_success" or rule.groups:"authentication_failures"` |
| 3 | Failed SSH login attempts | Metric | Count; saved search "failed SSH logins" |
| 4 | Successful SSH logins | Metric | Count; query `rule.id:5715` |
| 5 | Top source IP addresses | Horizontal bar (or Data table) | Y: Count; buckets: Terms `data.srcip`, size 10, order by Count; query: failed SSH logins |
| 6 | Most targeted usernames | Data table | Split rows: Terms `data.dstuser` size 10 **and** a second table (or sub-bucket) for `data.srcuser`; query: failed SSH logins |
| 7 | Alert severity distribution | Pie (donut) | Split slices: Range on `rule.level`: 0-4, 4-7, 7-10, 10-13, 13-16 (labels Low…Critical) |
| 8 | SSH brute-force detection events | Data table | Rows: Terms `rule.description` + Terms `data.srcip`; query: saved search "brute-force detections" |
| 9 | Authentication activity over time | Line / vertical bar | X: Date histogram `timestamp` (auto interval); split series: Filters `rule.groups:"authentication_failed"` / `rule.id:5715` |
| 10 | Recent security events | Saved search (Discover) | "all SSH authentication", sorted by `timestamp` descending, columns as above |

Save each visualization with the prefix `Mini-SIEM -`.

> Note on Range buckets: a range "from 10 to 13" includes 10 and excludes 13. The ranges above map to the
> project severity scale: Low 4-6, Medium 7-9, High 10-12, Critical 13-15. Levels 0-3 are informational.

## 5. Assemble the dashboard
☰ → Explore → Dashboards → Create new dashboard → **Add** → select the ten `Mini-SIEM -` items. Arrange them in
three rows:
1. Metrics: 1, 2, 3, 4.
2. Charts: 5, 6, 7.
3. Timeline 9, then tables 8 and 10.

Set the time picker to "Last 24 hours", and **Save** as `Mini-SIEM - SSH Security Monitoring`. Tick "Store time
with dashboard" if you want it to open on that range.

## 6. Useful time ranges
| Situation | Range |
|---|---|
| Live demo right after replaying synthetic events | Last 15 minutes (auto-refresh 10 s) |
| Daily review | Last 24 hours |
| Slow attacks / trends | Last 7 days |
| Report for a specific incident | Absolute range from first to last event of the IP |

## 7. Export data for the Python helpers and reports
- Discover: open a saved search → **Share/Reporting → Download CSV**, or generate a report. Options vary by
  version. The Python helper expects **JSON** alerts, so the simplest source is the manager's alert file:
  ```bash
  # on the manager - copy today's alerts (JSON Lines) for analysis, readable only by you
  sudo cp /var/ossec/logs/alerts/alerts.json ~/alerts-$(date +%F).json
  sudo chown $USER: ~/alerts-$(date +%F).json && chmod 600 ~/alerts-$(date +%F).json
  ```
- The Wazuh dashboard can also generate PDF reports from module views (e.g. Threat Hunting → "Generate report").
  Use them as attachments to `reports/report_template.md`.
