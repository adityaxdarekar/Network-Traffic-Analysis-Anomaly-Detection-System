# Custom Wazuh rules - explained one by one

File: `wazuh/manager/custom_rules.xml` → install as `/var/ossec/etc/rules/custom_rules.xml` on the manager.

## How Wazuh rules work (short version)
1. The **agent** reads a log line (e.g. from `/var/log/auth.log`) and sends it to the manager.
2. **Pre-decoding** takes the syslog header apart: timestamp, hostname and program name (`sshd`).
3. **Decoders** extract fields. For sshd: `srcip`, `srcport`, and the username as `srcuser` (non-existent user)
   or `dstuser` (existing user; `user` is an alias of `dstuser`).
4. **Rules** form a tree. A child rule (`<if_sid>`) is tested only after its parent matched, and the deepest
   matching rule wins. A **frequency rule** (`frequency` + `timeframe` + `<if_matched_sid>`) fires when its parent
   has matched N times within T seconds, on the Nth event. `<same_srcip/>` makes the count per source IP.
5. An alert is written (level ≥ 3 by default), indexed, and shown on the dashboard.

## Built-in rules this project relies on (not modified)
| ID | Level | Description (Wazuh ruleset) | Role here |
|---|---|---|---|
| 5700 | 0 | SSHD messages grouped | parent of all sshd rules |
| 5710 | 5 | sshd: Attempt to login using a non-existent user | single invalid-user event; parent of R2 |
| 5712 | 10 | sshd: brute force trying to get access to the system. Non existent user. | built-in: 8 × 5710 per IP in 120 s |
| 5715 | 3 | sshd: authentication success. | successful login; parent of R5 |
| 5716 | 5 | sshd: authentication failed. | generic failure parent |
| 5760 | 5 | sshd: authentication failed. (`Failed password`, `Failed keyboard`, `authentication error`) | single password failure; parent of R1, R2b, R3, R4 |
| 5763 | 10 | sshd: brute force trying to get access to the system. Authentication failed. | built-in: 8 × 5760 per IP in 120 s |

Run `sudo bash scripts/verify_installed_ruleset.sh` on the manager to print these rules from **your**
installation (ID, level, file and description) before relying on them.

Why not just copy these rules? The brief asks for no unnecessary duplication. The custom rules add what the
built-ins don't have: a lower early-warning threshold, username-diversity checks, a root-specific indicator, a
high-volume tier and a success-after-failures correlation.

## Severity scale
| Project severity | Wazuh levels | Meaning in Wazuh's classification |
|---|---|---|
| Informational | 0-3 | level 3 = successful/authorized events |
| Low | 4-6 | level 5 = user generated error (e.g. a mistyped password) |
| Medium | 7-9 | level 8 = first time seen, level 9 = error from invalid source |
| High | 10-12 | level 10 = multiple user generated errors, level 12 = high importance event |
| Critical | 13-15 | level 14 = high importance security event, usually correlated events |

## The rules
The order in the file matters. Siblings are tested top-down, so specific or severe rules come before the
generic one.

### R1 - 100101 Repeated failed logins (Medium, level 8)
```xml
<rule id="100101" level="8" frequency="5" timeframe="120" ignore="60">
  <if_matched_sid>5760</if_matched_sid>
  <same_srcip />
```
- **Fires:** on the 5th password failure from the same IP within 120 s.
- **Why:** an earlier, lower-severity warning than built-in 5763 (8 in 120 s, level 10).
- **`ignore="60"`:** the rule stays quiet for 60 s after firing, to avoid a flood of identical alerts. The pause
  applies to the rule as a whole, not per IP.
- **Groups:** `ssh_brute_force, ssh_failed_login, ssh_repeated_failures`.
- **Test:** scenario `test3_repeated_failed_logins`. Expected: lines 1-4 → 5760, line 5 → **100101**, lines 6-7 →
  5760, line 8 → 5763.

### R2 - 100102 Several non-existent usernames (High, level 10)
```xml
<rule id="100102" level="10" frequency="4" timeframe="300" ignore="120">
  <if_matched_sid>5710</if_matched_sid>
  <same_srcip />
  <different_srcuser />
```
- **Fires:** on the 4th invalid-user event from one IP within 5 min, when the earlier events carry usernames
  that differ from the current one.
- **Field:** the decoder stores non-existent usernames in `srcuser`, so `different_srcuser` is used here.
- **Limitation:** Wazuh compares the earlier events with the current event's username. That is not an exact
  count of distinct names. `scripts/analyze_wazuh_alerts.py` reports the exact number per IP.
- **Test:** `test4a_multiple_invalid_usernames` (admin, test, oracle, guest). Expected: line 4 → **100102**.

### R2b - 100103 Several existing accounts (High, level 10)
- Same idea as R2 for **existing** accounts: parent 5760, `<different_user />` (`user` = `dstuser`), 4 events in
  300 s. This pattern resembles password spraying.
- **Test:** `test4b_multiple_existing_accounts` (alice, bob, carol, dave). Expected: line 4 → **100103**.

### R3 - 100104 Repeated failed root logins (Medium, level 9)
```xml
<rule id="100104" level="9" frequency="3" timeframe="300" ignore="120">
  <if_matched_sid>5760</if_matched_sid>
  <same_srcip />
  <same_user />
  <user>^root$</user>
```
- **Fires:** on the 3rd failed root password from one IP within 5 min. `<user>` checks that the current event is
  for root, and `<same_user/>` counts only earlier events for the same user.
- **Why level 9:** Wazuh level 9 is "error from invalid source", which the documentation describes as more
  concerning when admin/root accounts are involved.
- **Hardening hint (not done automatically):** `PermitRootLogin no` in `sshd_config`.
- **Test:** `test5_root_login_attempts`. Expected: line 3 → **100104**.

### R4 - 100105 High-volume failures (High, level 12)
- **Fires:** on the 15th password failure from one IP within 5 min (`ignore="300"`).
- **Test:** `test5b_high_volume_failures`. Expected: line 5 → 100101, line 8 → 5763, line 15 → **100105**.
  If line 15 still shows 5760, your Wazuh version did not count the events that became 100101/5763 alerts
  towards 5760's history. R4 then appears a line or two later. Record what you see in
  `documentation/VERIFIED_RESULTS.md`.

### R5 - 100110 Successful login after brute-force indicators (Critical, level 14)
```xml
<rule id="100110" level="14" timeframe="600">
  <if_sid>5715</if_sid>
  <if_matched_group>ssh_brute_force</if_matched_group>
  <same_srcip />
```
- **Fires:** on a successful SSH login (5715) when R1, R2, R2b, R3 or R4 (all in group `ssh_brute_force`) fired
  for the same source IP within the last 10 minutes.
- **Structure:** this mirrors Wazuh's built-in correlation rule 40112 ("Multiple authentication failures followed
  by a success"), which uses `if_group`/`if_matched_group` without `frequency`.
- **Correlation limits (read before presenting):**
  - It correlates by **source IP only**. The successful username may differ from the failed ones. Check
    `data.dstuser` during triage.
  - One IP can stand for many people (NAT, VPN, jump host).
  - It needs a brute-force indicator first: 1-4 failures followed by a success don't trigger it.
  - If built-in 40112 exists in your version and built-in 5712/5763 fired first, Wazuh may report the success as
    **40112** instead of 100110. Both mean the same thing.
  - If the earlier brute-force rule was suppressed by its `ignore` timer, there is nothing to correlate with.
- **Test:** `test5c_success_after_failures`. Expected: line 5 → 100101, line 6 → **100110**.

## Install / change / roll back safely
```bash
sudo cp wazuh/manager/custom_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo chown --reference=/var/ossec/etc/rules/local_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo chmod --reference=/var/ossec/etc/rules/local_rules.xml /var/ossec/etc/rules/custom_rules.xml
sudo /var/ossec/bin/wazuh-analysisd -t && sudo systemctl restart wazuh-manager
```
- **Rollback:** remove the file and restart the manager.
- **Changing a threshold:** edit `frequency`/`timeframe` in the file, then re-run `scripts/validate_rules.py`,
  `wazuh-analysisd -t` and the logtest runner.

## Checklist done for every rule
| Check | How |
|---|---|
| XML structure | `scripts/validate_rules.py` (offline, done) → `wazuh-analysisd -t` (on the manager) |
| Parent rule / decoder dependency | parents limited to 5710/5715/5760, printed by `verify_installed_ruleset.sh` |
| No conflict with built-in IDs | custom range 100000-120000; collision check in `verify_installed_ruleset.sh` |
| Field names | only `srcip`, `srcuser`, `user`/`dstuser`; confirm in logtest Phase 2 |
| Test | one scenario per rule (`scripts/scenarios.py`), run with `wazuh-logtest` or `logtest_api_runner.py` |
| Restart safely | `wazuh-analysisd -t` first, then `systemctl restart wazuh-manager`, then check `ossec.log` |
