# Detection: SSH failed and successful logins (single events)

Single authentication events are handled by **built-in** Wazuh rules. The project does not duplicate them.

| Log line on the agent (Ubuntu 24.04, OpenSSH 9.6) | Decoder fields | Rule | Level |
|---|---|---|---|
| `sshd[123]: Accepted password for alice from 192.168.56.1 port 50122 ssh2` | srcip, dstuser | 5715 sshd: authentication success. | 3 |
| `sshd[123]: Accepted publickey for alice from ...` | srcip, dstuser | 5715 | 3 |
| `sshd[123]: Failed password for alice from 192.168.56.30 port 50200 ssh2` | srcip, srcport, **dstuser** | 5760 sshd: authentication failed. | 5 |
| `sshd[123]: Failed password for root from ...` | srcip, dstuser=root | 5760 | 5 |
| `sshd[123]: Invalid user admin from 192.168.56.32 port 52000` | srcip, srcport, **srcuser** | 5710 Attempt to login using a non-existent user | 5 |
| `sshd[123]: Failed publickey for alice from ...` | - | verify with wazuh-logtest (5716 family) | - |

Rows with "verify" haven't been confirmed against an installed ruleset. Paste them into `wazuh-logtest` and
record the result in `documentation/VERIFIED_RESULTS.md`.

## What a real failed attempt looks like
One wrong password over SSH usually writes several lines to `/var/log/auth.log`, for example a PAM
`authentication failure` line and the sshd `Failed password` line. A non-existent user adds an
`Invalid user` line before the failure. Wazuh evaluates **every line**, so:
- one attempt can produce more than one alert (e.g. PAM rule 5503 plus sshd rule 5760);
- built-in frequency rules count log events, not attempts.

That's why the custom brute-force rules count only one specific rule (5760 or 5710), not a whole group.

## Severity
A single failure is **Low** (level 5, "user generated error"): it is usually a typo. It becomes interesting only
when it repeats (see `brute_force_detection.md`).

## Dashboard searches
| Purpose | Query (DQL, Discover / Threat Hunting) |
|---|---|
| All failed SSH logins | `rule.groups:"authentication_failed" and rule.groups:"sshd"` |
| Successful SSH logins | `rule.id:5715` |
| Non-existent usernames | `rule.id:5710` |
| Root attempts | `rule.id:5760 and data.dstuser:"root"` |
| One source | `data.srcip:"192.168.56.30"` |
| Only synthetic demo events | `location:"/var/log/mini-siem/synthetic_auth.log"` |
| Only real auth.log events | `location:"/var/log/auth.log"` |
