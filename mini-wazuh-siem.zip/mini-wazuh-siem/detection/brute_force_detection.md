# Detection methodology: repeated failures and potential brute-force activity

## Idea
One failed login means little. A **pattern** - many failures, many usernames, root as the target, or a success
right after failures - from **one source within a short time** is suspicious authentication behaviour worth
investigating. Wazuh expresses such patterns with frequency rules: count earlier matches of a parent rule within
a time window, grouped by a field (`same_srcip`).

## Detection layers
| Layer | Pattern | Rule | Window | Level / severity |
|---|---|---|---|---|
| 1 | single failure | built-in 5760 / 5710 | - | 5 Low |
| 2 | 5 password failures, one IP | **100101** (R1) | 120 s | 8 Medium |
| 2 | 3 failed root passwords, one IP | **100104** (R3) | 300 s | 9 Medium |
| 3 | 8 password failures, one IP | built-in 5763 | 120 s | 10 High |
| 3 | 8 invalid-user events, one IP | built-in 5712 | 120 s | 10 High |
| 3 | 4 events with differing invalid usernames, one IP | **100102** (R2) | 300 s | 10 High |
| 3 | 4 failures for differing existing accounts, one IP | **100103** (R2b) | 300 s | 10 High |
| 3 | 15 password failures, one IP | **100105** (R4) | 300 s | 12 High |
| 4 | success after any layer-2/3 custom indicator, same IP | **100110** (R5) | 600 s | 14 Critical |

## Choosing thresholds
- Humans mistype a password 1-3 times. 5 failures in 2 minutes is unusual, but still only "review" (Medium).
- Automated guessing produces dozens of attempts per minute, which leads to the higher tiers.
- All thresholds are attributes in `custom_rules.xml`. Adjust them to your environment and re-test.

## What the rules cannot tell
- **Intent:** a forgotten password, a broken cron job with old credentials and an attacker look the same.
- **Who is behind an IP:** NAT, VPN and shared jump hosts merge many users into one address.
- **Slow attacks:** one attempt every few minutes stays below every window. Long-term trends in the dashboard
  (24 h / 7 days, top source IPs) are needed for that.
- **Distributed attacks:** many IPs with one attempt each are invisible to `same_srcip` rules. Look at
  "most targeted usernames" over time instead.

## Correlation: success after failures
R5 (`100110`) correlates a successful login (5715) with an earlier brute-force indicator from the **same
source IP**. It does **not** prove that the same person guessed the password: the username may differ, and the
IP may be shared. See `wazuh/manager/CUSTOM_RULES_README.md` → R5 for the full list of limits. During triage,
compare `data.dstuser` of the success with the usernames of the failures.

## Response (manual, by design)
The project detects only. It does not configure Wazuh active response and blocks nothing automatically.
Recommended manual steps for a confirmed incident:
1. Confirm with the account owner, and check `last -i` / `lastlog` on the agent.
2. Reset the password and review `~/.ssh/authorized_keys` of the affected account.
3. Harden SSH: key-only authentication, `PermitRootLogin no`, `AllowUsers`, MFA.
4. Block the source at the firewall only after a human decision, and document it.

## Troubleshooting: a rule did not fire
1. Paste the scenario into `wazuh-logtest -v` (verbose) in **one** session: are the parent rules (5760/5710)
   matching?
2. Phase 2 must show `srcip`. Without it, `same_srcip` can't count.
3. Is `sshd-session` in the log? See `deployment/version_information.md`.
4. Did an `ignore` timer from an earlier test suppress the rule? Start a new logtest session, or wait 5 minutes
   on a live system.
5. Is the custom file loaded? `sudo grep -n "custom_rules" /var/ossec/logs/ossec.log` and
   `sudo /var/ossec/bin/wazuh-analysisd -t`.
