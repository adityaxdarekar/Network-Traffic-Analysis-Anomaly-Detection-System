# Optional extension: Wazuh File Integrity Monitoring (FIM)

Login monitoring answers "who is trying to get in?". FIM answers "what changed after they got in?". An attacker
with access often edits configuration files (sshd_config, sudoers, cron jobs) or drops new files. FIM records a
baseline of file checksums and attributes, and alerts when they change.

## Safe demo setup (agent VM)
Only a **dedicated synthetic directory** is monitored. Real system files are not modified.
```bash
sudo mkdir -p /opt/mini-siem-fim-test
```
Agent `ossec.conf` (block 3 of `wazuh/agent/ossec.conf.example`):
```xml
<ossec_config>
  <syscheck>
    <directories check_all="yes" realtime="yes">/opt/mini-siem-fim-test</directories>
  </syscheck>
</ossec_config>
```
- `realtime="yes"` reports changes as they happen (inotify) instead of waiting for the periodic scan.
- `check_all="yes"` compares size, permissions, owner, group, modification time, inode and hashes.
- `report_changes="yes"` is **not** used. The documentation warns that it makes Wazuh copy every monitored file to
  a private location, and it would put file contents into alerts.

Restart the agent: `sudo systemctl restart wazuh-agent`. Wait until `/var/ossec/logs/ossec.log` shows that
real-time monitoring of syscheck has started. The first scan creates the baseline.

## Test 6 - commands and expected alerts
| Step | Command (agent) | Expected rule (Wazuh FIM) |
|---|---|---|
| Create | `echo "SIMULATED config v1" \| sudo tee /opt/mini-siem-fim-test/app.conf` | 554 "File added to the system." (level 5) |
| Modify | `echo "SIMULATED config v2" \| sudo tee -a /opt/mini-siem-fim-test/app.conf` | 550 "Integrity checksum changed." (level 7) |
| Delete | `sudo rm /opt/mini-siem-fim-test/app.conf` | 553 "File deleted." |

Rules 550 (level 7) and 554 (level 5) are as given in the Wazuh FIM documentation. Confirm 553, and the levels
on your version, with `scripts/verify_installed_ruleset.sh`.

Dashboard: **File Integrity Monitoring** module, or Discover with `rule.groups:"syscheck"` and
`syscheck.path:"/opt/mini-siem-fim-test/app.conf"`. The alert shows the path, the event (added / modified /
deleted), the changed attributes and the old and new hashes.

## Extending to real configuration files (read-only monitoring)
For a real deployment, you could monitor (not modify) `/etc/ssh`, `/etc/sudoers.d` and `/etc/cron.d`. The
default agent configuration usually includes `/etc` in its periodic scans already. Check the `<syscheck>` section
of the agent's `ossec.conf`. In this lab, demonstrate only with the
synthetic directory.
