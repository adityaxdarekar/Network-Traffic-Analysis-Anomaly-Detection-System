# Suspicious source IP analysis

Goal: for each source IP that touched SSH, answer these questions. How many failures? Which usernames? When
first and last seen? Any successful login? Which rules fired, and how severe?

**Principle:** "suspicious" means "needs review". Repeated failures alone never make an IP malicious. No external
reputation lookups and no automatic blocking in this version.

## A. In the Wazuh dashboard
Use **Discover** (or **Threat Hunting → Events**) on the `wazuh-alerts-*` index pattern, with time range
"Last 24 hours":

| Question | How |
|---|---|
| Top source IPs for SSH failures | Query `rule.groups:"authentication_failed"` → field list → `data.srcip` → "Visualize" / top 5 values |
| Failed events for one IP | `data.srcip:"192.168.56.31" and rule.groups:"authentication_failed"` → hit count |
| Targeted usernames for one IP | same query → field `data.dstuser` (existing accounts) and `data.srcuser` (non-existent) |
| First / last observed | same query, sort by `timestamp` ascending / descending |
| Related successful logins | `data.srcip:"192.168.56.31" and rule.id:5715` |
| Detection rule and severity | add the columns `rule.id`, `rule.level`, `rule.description` |
| All custom detections | `rule.groups:"mini_siem"` |
| High and Critical only | `rule.level >= 10` |

Save the search ("Save" → name it `Mini-SIEM - SSH by source IP`) so it can be reopened during the demo.

## B. With the helper script (exported alerts)
Export alerts (see `wazuh/dashboards/dashboard_setup.md` → Export), or copy
`/var/ossec/logs/alerts/alerts.json` from the manager. Then:
```bash
python3 scripts/analyze_wazuh_alerts.py alerts.json --csv output/ip_summary.csv
python3 scripts/export_alert_summary.py alerts.json --out output/case-001 --case CASE-001 --analyst "Name"
```
Columns of `ip_summary.csv`: `srcip, ip_version, ip_class, failed_events, successful_logins, distinct_usernames,
targeted_usernames, first_seen, last_seen, rules_triggered, correlation_rules, max_level, max_severity, agents,
review_note`.

### Address classes
| Class | Ranges | What it suggests |
|---|---|---|
| loopback | 127.0.0.0/8, ::1 | activity from the machine itself (scripts, local tests) |
| private | 10/8, 172.16/12, 192.168/16, fc00::/7 | internal host - find the owner on your network |
| link-local | 169.254/16, fe80::/10 | same network segment, often misconfiguration |
| documentation | 192.0.2/24, 198.51.100/24, 203.0.113/24, 2001:db8::/32 | example/test data, never real traffic |
| reserved | other special ranges (e.g. 100.64/10 shared address space) | check carrier/NAT setups |
| public | globally routable | external source - review exposure of SSH to the internet |

IPv4 and IPv6 are reported separately (`ip_version`). An IPv4-mapped IPv6 address (`::ffff:a.b.c.d`) is treated
as IPv4.

## Triage questions for each IP
1. Is the IP known (admin PC, monitoring server, CI runner, NAT gateway)?
2. Were many **different** usernames tried (enumeration/spraying), or one account many times (forgotten password
   or targeted guessing)?
3. Was there any **successful** login from this IP? With which user? At what time relative to the failures?
4. Did it touch root or service accounts?
5. Is the activity still ongoing (`last_seen`)?

Record the decision (false positive / policy issue / incident) in the investigation report
(`reports/report_template.md`).

## Handling exported data
Alert exports contain usernames, IP addresses and host names. Keep them in a restricted folder
(`chmod 700 output/`), share them only with the people who need them, and delete them when the investigation
ends.
