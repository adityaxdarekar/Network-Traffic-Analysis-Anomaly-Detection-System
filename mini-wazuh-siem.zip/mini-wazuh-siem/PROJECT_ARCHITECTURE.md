# Project architecture - how a security event moves through the Mini-SIEM

```
 ┌──────────────────────────── lab-ubuntu-agent  192.168.56.20 ────────────────────────────┐
 │  sshd ──writes──► /var/log/auth.log            replay_synthetic_events.py ──appends──►  │
 │                          │                     /var/log/mini-siem/synthetic_auth.log     │
 │                          ▼                                  │                            │
 │                 Wazuh AGENT: wazuh-logcollector (localfile) ◄┘   wazuh-syscheckd (FIM)    │
 │                          │   wazuh-agentd: encrypts + sends                               │
 └──────────────────────────┼─────────────────────────────────────────────────────────────┘
                            │ TCP 1514 (events)   TCP 1515 (one-time enrollment)
 ┌──────────────────────────▼──────────── wazuh-server  192.168.56.10 ─────────────────────┐
 │ Wazuh MANAGER (server)                                                                   │
 │   wazuh-remoted  ──►  wazuh-analysisd                                                    │
 │                         1 pre-decoding  (timestamp, hostname, program_name = sshd)       │
 │                         2 decoding      (sshd decoders → srcip, srcport, srcuser/dstuser)│
 │                         3 rule matching (built-in 5710/5715/5760/5712/5763 + custom      │
 │                                          100101-100110, frequency/timeframe/same_srcip)  │
 │                         ──► alert (level ≥ 3) ──► /var/ossec/logs/alerts/alerts.json     │
 │   Wazuh server API :55000  (agent status, ruleset, logtest)                              │
 │                         │                                                                │
 │   Filebeat ─── TLS ──► Wazuh INDEXER :9200  (index wazuh-alerts-4.x-YYYY.MM.DD)          │
 │                         │                                                                │
 │                Wazuh DASHBOARD :443 (HTTPS)  ◄── queries indexer, calls API :55000       │
 └─────────────────────────┼────────────────────────────────────────────────────────────────┘
                           │ https://192.168.56.10  (host-only network only)
                    SOC analyst (browser on the host PC)
                    + optional: exported alerts.json ──► scripts/analyze_wazuh_alerts.py
```

## Components
| Component | Runs on | Responsibility in this project |
|---|---|---|
| **Wazuh agent** | monitored Ubuntu VM | Reads `/var/log/auth.log` and the synthetic test log line by line (`wazuh-logcollector`), watches the FIM test directory (`wazuh-syscheckd`), and sends events encrypted to the manager over TCP 1514. It enrolls once through TCP 1515. It does no detection itself. |
| **Wazuh manager (server)** | server VM | Receives events (`wazuh-remoted`) and analyses them (`wazuh-analysisd`): pre-decoding, decoding, rule matching, correlation (frequency, timeframe, same source IP). Writes alerts to `alerts.json`. Provides the server API (agent status, logtest). |
| **Filebeat** | server VM | Ships alerts from the manager to the indexer over TLS. |
| **Wazuh indexer** | server VM | Stores and indexes alerts (OpenSearch-based) so they can be searched and aggregated (top IPs, counts over time). |
| **Wazuh dashboard** | server VM | Web UI on HTTPS 443: alert search (DQL), visualizations, dashboards, agent management, ruleset test, reports. |
| **Custom rules** | manager: `/var/ossec/etc/rules/custom_rules.xml` | Extend the built-in sshd rules (see `wazuh/manager/CUSTOM_RULES_README.md`). |
| **Python helpers** | analyst PC or server | Optional and read-only: analyse exported alerts, replay synthetic events, run logtest scenarios, validate rules. They never replace Wazuh's detection. |

## Life of one event - example
1. A client at 192.168.56.31 enters a wrong password. sshd writes
   `Nov  6 18:00:09 lab-ubuntu-agent sshd[4204]: Failed password for alice from 192.168.56.31 port 51004 ssh2`.
2. The agent's logcollector reads the new line from `/var/log/auth.log` and sends it to the manager.
3. **Pre-decoding:** the timestamp, `hostname=lab-ubuntu-agent` and `program_name=sshd` are extracted.
4. **Decoding:** the sshd decoder sets `srcip=192.168.56.31`, `srcport=51004`, `dstuser=alice`.
5. **Rules:** 5700 (sshd group) → 5716 (authentication failed) → 5760 (Failed password). Wazuh then tests the
   children of 5760. If this is the 5th 5760 event from 192.168.56.31 within 120 s, custom rule **100101**
   matches and becomes the alert (level 8).
6. The alert (JSON) is written to `alerts.json`. Filebeat sends it to the indexer, and it appears in the
   dashboard within seconds.
7. The analyst filters `data.srcip:"192.168.56.31"`, reviews the timeline and usernames, and documents the
   decision. Nothing is blocked automatically.

## Design decisions
| Decision | Reason |
|---|---|
| All-in-one server + separate agent VM (Option A) | Realistic agent → manager flow over the network, and it fits on one PC with 16 GB RAM |
| Extend built-in rules instead of copying them | No duplicate alerts; upgrades keep improving the base rules |
| Count specific rules (5760, 5710), not whole groups | One SSH attempt writes several log lines (PAM + sshd) |
| Synthetic events in a separate file | Predictable tests without modifying real logs or guessing passwords |
| No active response | Detection and investigation project; avoids locking out legitimate users |
| Private host-only network | The dashboard and agent ports are never exposed |
