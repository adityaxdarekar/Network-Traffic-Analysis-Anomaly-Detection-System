# Mini Security Information and Event Management (SIEM) System Using Wazuh for Linux Log Monitoring and Brute-Force Detection

**College Project Report - Cybersecurity**

---

## Abstract
Linux servers exposed to SSH continuously receive authentication attempts, some of them automated
password-guessing. Individual log entries are of little value; security-relevant information lies in patterns
across many events. This project implements a mini Security Information and Event Management (SIEM) system on
the open-source Wazuh platform, version 4.14. A Wazuh agent on an Ubuntu 24.04 endpoint collects authentication
logs and forwards them to a Wazuh manager. The manager decodes the events and applies the built-in SSH rules
together with six custom correlation rules. These rules detect repeated failed logins, username enumeration,
password spraying, repeated root login attempts, high-volume failures, and successful logins following
brute-force indicators from the same source. Alerts are stored in the Wazuh indexer and analysed on the Wazuh
dashboard. Optional Python tools summarise exported alerts per source IP and generate investigation reports.
The rule set is validated statically and through a scenario-based test plan using synthetic log events. The
project follows a detection-only approach in an isolated virtual lab and uses cautious wording that
distinguishes suspicious behaviour from confirmed attacks.

## 1. Introduction
Security monitoring is a core function of a Security Operations Centre (SOC). Analysts depend on centralised
log collection and automated detection, because manual review of logs on many hosts is infeasible. A SIEM
system provides this capability by collecting, normalising, correlating and visualising security events. This
project applies a production-grade open-source SIEM, Wazuh, to one of the most common threats against Linux
systems: password-guessing attacks against SSH.

## 2. Problem statement
- Authentication events are distributed across hosts in plain-text logs (`/var/log/auth.log`, `/var/log/secure`).
- Individual failures are normal (typing mistakes). Indicators of attack emerge only from correlation over time,
  source and account.
- Analysts need prioritised, explainable alerts and investigation support, without automatic actions that could
  lock out legitimate users.

## 3. Existing system
- **Manual inspection:** `grep "Failed password" /var/log/auth.log` on each host. This doesn't scale, has no
  history and no correlation.
- **Host-level tools such as fail2ban:** they block IPs locally after N failures. That is enforcement without
  central visibility, investigation or reporting.
- **Commercial SIEMs:** comprehensive, but costly and complex for a learning environment.

## 4. Proposed system
- A Wazuh-based mini SIEM in a private VirtualBox lab.
- Central collection of authentication logs from an agent.
- Built-in detection of single events, extended by custom correlation rules with a four-level severity scale.
- Dashboard visualisations for monitoring and investigation.
- An investigation-report workflow, supported by optional, read-only Python helpers.

## 5. Objectives
1. Deploy Wazuh manager, indexer and dashboard, plus a Linux agent, following the official documentation.
2. Collect SSH authentication logs.
3. Detect failed, invalid-user and successful SSH logins.
4. Detect repeated failures, multiple targeted usernames, repeated root attempts, high-volume failures, and
   success after failures.
5. Support the analysis of suspicious source IPs (counts, usernames, first and last seen, severity).
6. Visualise alerts and produce investigation reports.
7. Optionally, demonstrate File Integrity Monitoring.

## 6. Scope
**In scope:**
- SSH authentication monitoring on Ubuntu (and RHEL through `/var/log/secure`)
- custom Wazuh rules
- dashboard configuration
- synthetic test scenarios
- report generation
- optional FIM on a test directory

**Out of scope:**
- automated blocking (active response)
- external threat intelligence
- multi-node clusters
- Windows endpoints
- production hardening of the SIEM itself

## 7. Hardware requirements
| Machine | CPU | RAM | Disk |
|---|---|---|---|
| Wazuh server VM (Quickstart: 1-25 agents) | 4 vCPU | 8 GiB | 50 GB |
| Monitored Ubuntu VM | 1-2 vCPU | 2 GiB | 20 GB |
| Host PC | 6+ cores | 16 GB | ~80 GB free |

## 8. Software requirements
- Ubuntu Server 24.04 LTS (both VMs)
- Wazuh 4.14.10 (installation assistant and agent package)
- OpenSSH 9.6
- VirtualBox 7
- A modern web browser
- Optional: Python 3.10+ with pandas and pytest

## 9. System architecture
```
Ubuntu agent VM (sshd → auth.log) → Wazuh agent ──TCP 1514──► Wazuh manager (decoders + rules → alerts)
        → Filebeat ──TLS──► Wazuh indexer (:9200) ──► Wazuh dashboard (HTTPS :443) ──► SOC analyst
```
Both VMs share a VirtualBox host-only network (192.168.56.0/24). A NAT adapter provides internet access for
package installation only. `PROJECT_ARCHITECTURE.md` gives the detailed flow.

## 10. Module descriptions
| Module | Description |
|---|---|
| Deployment | Server installation (all-in-one assistant), agent installation and enrollment, network and port plan, version compatibility (`deployment/`) |
| Log collection | Agent `localfile` configuration for auth.log / secure / journald, and a dedicated synthetic log (`wazuh/agent/ossec.conf.example`) |
| Detection rules | Six custom rules extending the sshd ruleset (`wazuh/manager/custom_rules.xml`) |
| Dashboard | Saved searches, ten visualizations, dashboard assembly (`wazuh/dashboards/dashboard_setup.md`) |
| Suspicious IP analysis | Dashboard method and `analyze_wazuh_alerts.py` (per-IP summary, IP classes, severity) |
| Reporting | `export_alert_summary.py` (CSV + Markdown report) and `reports/report_template.md` |
| Testing | Scenario definitions, logtest API runner, synthetic replay, offline validator, pytest suite |
| FIM (optional) | Wazuh syscheck on `/opt/mini-siem-fim-test` |

## 11. Wazuh architecture
- **Agent:** collects logs (`wazuh-logcollector`) and file-integrity data (`wazuh-syscheckd`), and sends events
  encrypted to the manager.
- **Manager:** receives events (`wazuh-remoted`) and analyses them (`wazuh-analysisd`).
  - Pre-decoding extracts the syslog header.
  - Decoders extract fields: `srcip`, `srcport`, and the username as `srcuser` or `dstuser`.
  - Rules form a tree of parent/child rules with levels 0-16. Correlation rules count earlier matches within a
    timeframe, optionally per source IP.
  - Alerts of level ≥ 3 are written to `alerts.json`.
- **Indexer:** an OpenSearch-based store that receives alerts from Filebeat.
- **Dashboard:** the web interface for search, visualisation, agent management and rule testing.

## 12. Detection methodology
Detection is layered:
1. **Single events** (built-in rules):
   - 5715: successful login, level 3
   - 5760: failed password, level 5
   - 5710: non-existent user, level 5
2. **Early warning (custom):**
   - 100101: five failures from one IP within two minutes, level 8
   - 100104: three failed root logins, level 9
3. **Brute-force indicators:**
   - built-in 5763 and 5712: eight events within two minutes, level 10
   - custom 100102 (invalid usernames) and 100103 (existing accounts): several different usernames from one IP,
     level 10
   - custom 100105: fifteen failures within five minutes, level 12
4. **Correlation:** custom 100110, a successful login from an IP that triggered any layer-2/3 custom indicator
   within ten minutes, level 14.

The custom rules count one specific parent rule (5760 or 5710) rather than a whole group. This avoids double
counting, because one SSH attempt can write several log lines (PAM and sshd). Severity is mapped to Wazuh's
documented level classification:
- Low: 4-6
- Medium: 7-9
- High: 10-12
- Critical: 13-15

Alert texts use the terms "potential brute-force activity" and "suspicious" behaviour.

## 13. Custom rule explanations
| Rule | Parent | Condition | Level | Rationale |
|---|---|---|---|---|
| 100101 | 5760 | `frequency=5`, `timeframe=120`, `same_srcip`, `ignore=60` | 8 | earlier warning than built-in 5763 |
| 100102 | 5710 | `frequency=4`, `timeframe=300`, `same_srcip`, `different_srcuser` | 10 | username enumeration (invalid users are decoded into `srcuser`) |
| 100103 | 5760 | `frequency=4`, `timeframe=300`, `same_srcip`, `different_user` | 10 | password spraying (`user` is an alias of `dstuser`) |
| 100104 | 5760 | `frequency=3`, `timeframe=300`, `same_srcip`, `same_user`, `<user>^root$</user>` | 9 | privileged account targeted |
| 100105 | 5760 | `frequency=15`, `timeframe=300`, `same_srcip` | 12 | sustained high volume |
| 100110 | 5715 | `if_matched_group=ssh_brute_force`, `timeframe=600`, `same_srcip` | 14 | possible successful compromise; same structure as built-in rule 40112 |

All IDs lie in Wazuh's custom range (100000-120000). Rules are ordered from specific to generic, because Wazuh
evaluates sibling rules in file order. The detailed explanation is in `wazuh/manager/CUSTOM_RULES_README.md`.

## 14. Implementation
- **Deployment:** the Wazuh installation assistant
  (`curl -sO https://packages.wazuh.com/4.14/wazuh-install.sh && sudo bash ./wazuh-install.sh -a`), and the agent
  through the official APT repository with `WAZUH_MANAGER=192.168.56.10`.
- **Rule installation:**
  1. Copy the rules to `/var/ossec/etc/rules/custom_rules.xml`.
  2. Check them with `wazuh-analysisd -t`.
  3. Restart the manager.
- **Agent configuration:**
  - collect `/var/log/auth.log`
  - collect the synthetic log `/var/log/mini-siem/synthetic_auth.log`
  - optionally, real-time FIM on `/opt/mini-siem-fim-test`
- **Helpers:** Python and shell, about 1,300 lines, plus about 530 lines of tests.
  - Analysis and export of alerts.
  - Synthetic event replay, restricted to the dedicated log file.
  - Logtest automation through the documented Wazuh API endpoint `PUT /logtest`, using session tokens.
  - Static rule validation.

## 15. Testing
| Level | Method | Result |
|---|---|---|
| Static | `validate_rules.py`: XML, ID range, uniqueness, documented options, value ranges, parent references, group references | passed |
| Unit | pytest, 91 tests: alert parsing (JSON Lines, arrays, indexer responses, malformed input), grouping, IP classification (IPv4/IPv6, private, loopback, documentation, public), severity, CSV/report export, replay safety, logtest runner (mocked API) | 91 passed |
| Rule | `wazuh-logtest` / `logtest_api_runner.py`, 8 scenarios with per-line expected rule IDs | to be executed on the lab manager |
| End-to-end | synthetic replay on the agent → alerts in the dashboard; optional manual wrong-password login in the lab | to be executed in the lab |
| FIM | create, modify and delete a file in the test directory | to be executed in the lab |

Test scenarios:
1. Normal login → 5715
2. One failure → 5760
3. Repeated failures → 100101 at the 5th line, 5763 at the 8th
4. Multiple usernames → 100102 / 100103
5. Root attempts → 100104
6. High volume → 100105
7. Success after failures → 100110
8. FIM → 554 / 550 / 553

## 16. Results
- **Built and tested offline:** the rule file, the agent configuration and the helpers. Static validation passed,
  and 91 of 91 unit tests passed.
- **Analysis output:** on the synthetic sample alerts (46 alerts, 11 source IPs), the analysis tool ranks the
  source with a successful login after brute-force indicators first (Critical). It then ranks the high-volume
  source (High, 15 failures), the enumeration and spraying sources (4 distinct usernames each) and the root
  source (Medium). Normal logins from private, loopback and IPv6 documentation addresses are classified as
  informational.
- **Live Wazuh results** (logtest outputs, dashboard visualisations) are recorded in
  `documentation/VERIFIED_RESULTS.md` after deployment.

## 17. Advantages
- Uses a real, widely deployed SIEM platform and its documented features.
- Extends built-in rules instead of duplicating them, and keeps a clear severity scale.
- Detects patterns that single-event rules miss: diversity of usernames, root focus, success after failures.
- Safe and reproducible testing: synthetic events, a private network, no attack tools.
- Investigation support (per-IP analysis, report template) that doesn't replace analyst judgement.

## 18. Limitations
- Correlation by source IP only (NAT and shared addresses). Success-after-failure doesn't prove the same actor.
- Slow and distributed attacks can stay below the per-IP time windows.
- Log-event counting and per-rule `ignore` timers affect exact thresholds.
- OpenSSH ≥ 9.8 (`sshd-session`) lines are not decoded by the default sshd decoders (open Wazuh issue #39954).
  The lab therefore uses Ubuntu 24.04.
- No automated response or threat-intelligence enrichment in this version. Single-node deployment.

## 19. Future scope
- Active response with allow-lists after tuning.
- CDB-list and GeoIP enrichment.
- Notifications.
- Decoders for the `sshd-session` format.
- Additional log sources (sudo, web servers, Windows RDP).
- MITRE ATT&CK-oriented dashboards.
- A multi-node indexer with retention policies.

## 20. Conclusion
The project demonstrates the complete SOC cycle on Wazuh:
- collection of Linux authentication logs
- layered detection, from single failures to correlated success-after-brute-force
- investigation of suspicious sources on the dashboard
- structured reporting

The implementation relies on documented Wazuh mechanisms (parent rules, frequency and timeframe, source-IP
grouping, decoder fields) and on careful, honest wording of alerts. It provides a sound basis for extending the
lab towards automated response and threat intelligence.

## 21. References
1. Wazuh, *Quickstart* (installation assistant, requirements, supported OS), version 4.14. https://documentation.wazuh.com/current/quickstart.html
2. Wazuh, *Deploying Wazuh agents on Linux endpoints*, 4.14. https://documentation.wazuh.com/4.14/installation-guide/wazuh-agent/wazuh-agent-package-linux.html
3. Wazuh, *Architecture* (components, required ports). https://documentation.wazuh.com/current/getting-started/architecture.html
4. Wazuh, *Rules syntax*, 4.14. https://documentation.wazuh.com/4.14/user-manual/ruleset/ruleset-xml-syntax/rules.html
5. Wazuh, *Decoders syntax*. https://documentation.wazuh.com/current/user-manual/ruleset/ruleset-xml-syntax/decoders.html
6. Wazuh, *Custom rules*. https://documentation.wazuh.com/current/user-manual/ruleset/rules/custom.html
7. Wazuh, *Rules classification*, 4.14. https://documentation.wazuh.com/4.14/user-manual/ruleset/rules/rules-classification.html
8. Wazuh, *Testing decoders and rules* (wazuh-logtest, logtest API). https://documentation.wazuh.com/current/user-manual/ruleset/testing.html
9. Wazuh, *wazuh-logtest reference*. https://documentation.wazuh.com/current/user-manual/reference/tools/wazuh-logtest.html
10. Wazuh, *localfile* reference and *Journald log collection*, 4.14. https://documentation.wazuh.com/4.14/user-manual/reference/ossec-conf/localfile.html
11. Wazuh, *Proof of concept: Detecting a brute-force attack*. https://documentation.wazuh.com/current/proof-of-concept-guide/detect-brute-force-attack.html
12. Wazuh, *File integrity monitoring - configuration*. https://documentation.wazuh.com/4.3/user-manual/capabilities/file-integrity/fim-configuration.html
13. Wazuh GitHub issue #39954, *sshd decoder/rules do not match OpenSSH 9.8+ sshd-session auth failure log format*. https://github.com/wazuh/wazuh/issues/39954
14. Wazuh, *Release notes*. https://documentation.wazuh.com/current/release-notes/index.html
15. MITRE ATT&CK, T1110 Brute Force (T1110.001 Password Guessing, T1110.003 Password Spraying), T1078 Valid Accounts. https://attack.mitre.org/techniques/T1110/
16. NIST SP 800-92, *Guide to Computer Security Log Management*. https://csrc.nist.gov/pubs/sp/800/92/final
