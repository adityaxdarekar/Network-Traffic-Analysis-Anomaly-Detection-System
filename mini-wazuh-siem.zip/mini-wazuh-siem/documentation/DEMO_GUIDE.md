# College demonstration guide (15-20 minutes)

## Before the presentation (day before)
1. Both VMs installed and verified (`deployment/`): agent **Active** in the dashboard.
2. Custom rules installed and tested: `logtest_api_runner.py` run, and results written in `VERIFIED_RESULTS.md`.
3. Dashboard `Mini-SIEM - SSH Security Monitoring` created and saved (`wazuh/dashboards/dashboard_setup.md`).
4. Scripts copied to the agent: `~/mini-siem-scripts/`.
5. Take screenshots as a backup in case the live demo fails (projector, network).
6. Start both VMs 10 minutes early. The indexer needs time after boot.

## Live demo script
| Min | Step | What you do | What the audience sees / what you say |
|---|---|---|---|
| 0-2 | Problem | Slide: "Thousands of log lines per day - who notices 40 failed logins at 3 a.m.?" | Why a SIEM: collect, detect, alert, investigate. |
| 2-4 | Architecture | Show `PROJECT_ARCHITECTURE.md` diagram | Agent → manager (rules) → indexer → dashboard. |
| 4-5 | It's live | Dashboard → Agents: `lab-ubuntu-agent` Active | Real Wazuh 4.14, two VMs on a private network. |
| 5-7 | Normal login | Agent: `sudo python3 replay_synthetic_events.py --scenario test1_normal_login` | Rule **5715**, level 3, informational, not an alert to worry about. |
| 7-9 | One failure | `--scenario test2_one_failed_login` | **5760**, level 5: a typo is not an attack. |
| 9-11 | Repeated failures | `--scenario test3_repeated_failed_logins` | 5th line → **100101** (Medium, custom early warning), 8th → **5763** (built-in brute force). |
| 11-13 | Rule test | Manager: `sudo /var/ossec/bin/wazuh-logtest`, paste `samples/logs/test5_root_login_attempts.log` | Phase 1/2/3: decoder extracts `srcip`/`dstuser`; 3rd line → **100104** root indicator. |
| 13-15 | Correlation | Agent: `--scenario test5c_success_after_failures` (at least 5 min after test3) | **100110**, level 14, Critical: success after brute-force indicators from the same IP. Explain the limits (same IP ≠ same person). |
| 15-17 | Investigation | Dashboard: click the 100110 alert → filter `data.srcip` → timeline; run `export_alert_summary.py` | First/last seen, usernames, rules, report. "Suspicious - review", not "malicious". |
| 17-18 | Optional FIM | Agent: create/modify/delete in `/opt/mini-siem-fim-test` | 554 / 550 / 553 in the FIM module. |
| 18-20 | Wrap-up | Limitations + future work slides | Honest limits; questions. |

Timing tip: rule `ignore` timers are global. Run test3 early and test5c last, at least 5 minutes later. Or show
test5c only through wazuh-logtest, which uses its own session.

## Talking points
- **Built-in first:** Wazuh already detects SSH failures (5710, 5760) and brute force (5712, 5763). The custom rules
  add an earlier warning, username diversity, a root indicator, a high-volume tier and success-after-failure
  correlation.
- **Severity is a scale, not a verdict:** level 5 typo → level 14 correlated pattern.
- **Detection, not enforcement:** nothing is blocked automatically. A human decides.
- **Safe testing:** synthetic events in a separate log file, private addresses, fictional users, no attack tools.

## Likely questions and answers
1. **What's the difference between the manager and the indexer?** The manager analyses events with decoders and
   rules and creates alerts. The indexer stores and searches the alerts. The dashboard only displays what the
   indexer returns.
2. **Why not count all `authentication_failed` events?** One SSH attempt writes several log lines (PAM and
   sshd), so counting a whole group double-counts. The rules count one specific rule (5760 or 5710).
3. **What does `same_srcip` do?** It counts events separately for each source IP, so two users mistyping once
   each don't add up to an alert.
4. **Can an attacker evade this?** Yes: slow attacks below the time window, and distributed attacks from many
   IPs. Long-term views and username-based analysis help, and this is listed as a limitation.
5. **Why Ubuntu 24.04 for the agent?** OpenSSH 9.8+ logs failed logins as `sshd-session`, which the default
   decoders don't parse yet (Wazuh issue #39954).
6. **Why not block the IP automatically?** False positives (NAT, a forgotten password) would lock out legitimate
   users. Active response is a deliberate later step.
7. **How do you know the rules work?** wazuh-logtest and the API runner show the exact rule ID per line, and the
   end-to-end replay shows the same alerts in the dashboard. See `VERIFIED_RESULTS.md`.
