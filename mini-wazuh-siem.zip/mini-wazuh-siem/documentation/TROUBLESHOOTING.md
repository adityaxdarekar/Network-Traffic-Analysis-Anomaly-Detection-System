# Troubleshooting guide

| Symptom | Likely cause | Check / fix |
|---|---|---|
| **Manager won't start after adding rules** | XML syntax error, duplicate rule ID, unknown option | `sudo /var/ossec/bin/wazuh-analysisd -t` prints the file and line. Also `sudo tail -n 50 /var/ossec/logs/ossec.log`. Roll back: remove `/var/ossec/etc/rules/custom_rules.xml`, restart. Run `python3 scripts/validate_rules.py` before copying. |
| **XML syntax error** | unclosed tag, `&` or `<` in a description | Use `&amp;`, `&lt;`. Each `<rule>` must sit inside `<group name="...,">`. |
| **Rule conflict / duplicate ID** | ID also used in another file | `sudo bash scripts/verify_installed_ruleset.sh` (section 2). Keep custom IDs in 100000-120000. |
| **Custom rule never fires** | parent rule differs on your version, field missing, `ignore` timer active | `wazuh-logtest -v`: does the parent (5760/5710/5715) match? Does Phase 2 show `srcip`? Start a fresh logtest session. See `detection/brute_force_detection.md` → Troubleshooting. |
| **Incorrect field names** (e.g. searching `data.user`) | sshd decoders use `srcuser` for non-existent users and `dstuser` for existing ones | Expand one alert in Discover and use the field names shown there. |
| **Logs show `sshd-session[...]`, no brute-force alerts** | OpenSSH ≥ 9.8 format not decoded by the default sshd decoders (Wazuh issue #39954, open) | Use Ubuntu 24.04 (OpenSSH 9.6) for the agent, or demonstrate with the synthetic log file. See `deployment/version_information.md`. |
| **Agent shows Disconnected / Never connected** | wrong manager IP, ports blocked, agent newer than manager | Agent: `sudo grep -E "ERROR|WARN" /var/ossec/logs/ossec.log | tail`; `nc -zv 192.168.56.10 1514`. Manager: `sudo /var/ossec/bin/agent_control -l`. Check `<address>` in the agent's `ossec.conf`, the firewall (`sudo ufw status`), and that agent version ≤ manager version. |
| **Agent enrollment fails** | port 1515 blocked, agent name already registered | `nc -zv 192.168.56.10 1515`. Remove the stale agent in the dashboard (Agents) or with `manage_agents` on the manager, then restart the agent. |
| **Authentication log not collected** | `localfile` missing, wrong path, file doesn't exist | Agent: `sudo grep -n "<location>" /var/ossec/etc/ossec.conf`; `sudo grep "Analyzing file" /var/ossec/logs/ossec.log`; `ls -l /var/log/auth.log`. On systems without rsyslog, use the journald block (1c). Don't configure both, or you get duplicates. |
| **Duplicate alerts for every SSH event** | same file in two `localfile` blocks, or auth.log + journald | Keep exactly one source per log. |
| **No alerts appear in the dashboard** | level below 3, wrong time range, indexer/Filebeat issue | Manager: `sudo tail -f /var/ossec/logs/alerts/alerts.json` while replaying. If alerts appear there but not in the dashboard: `sudo systemctl status filebeat wazuh-indexer`, `sudo filebeat test output`. Widen the time picker. |
| **Dashboard not loading** | service down, low RAM, wrong URL | `sudo systemctl status wazuh-dashboard wazuh-indexer`; `free -g` (8 GiB recommended); use `https://192.168.56.10` (https, not http). After a VM reboot the indexer needs 1-2 minutes. |
| **Browser certificate warning** | self-signed lab certificate | Expected in the lab. Accept it for 192.168.56.10 only. |
| **Events at the wrong time / not in "Last 15 minutes"** | VM clocks out of sync, wrong timezone | `timedatectl` on both VMs: "System clock synchronized: yes". Set the timezone with `sudo timedatectl set-timezone ...`. Syslog lines carry no year or zone, so a wrong agent clock shifts events. |
| **`logtest_api_runner.py`: HTTP 401** | wrong API user or password | Use the `wazuh` API user from `wazuh-passwords.txt` (not the dashboard `admin`, unless it has API rights). |
| **`logtest_api_runner.py`: certificate verify failed** | self-signed API certificate | In the isolated lab, `--insecure`; otherwise `--cacert <file>`. |
| **Replay script: "refusing to write"** | output path outside `/var/log/mini-siem` | Intended safety check. Use the default path. |
| **FIM alert missing** | directory not in `syscheck`, real-time not started yet | Agent `ossec.log` must show that syscheck real-time monitoring started. Create the directory **before** restarting the agent. |
