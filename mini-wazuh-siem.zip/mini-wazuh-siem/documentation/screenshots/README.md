# Screenshots

Empty on purpose: no Wazuh dashboard was available while this package was built, so no screenshot exists yet.
Add your own from the lab, for example:
01_agents_active.png, 02_logtest_phase123.png, 03_alert_100101.png, 04_alert_100110.png,
05_dashboard_overview.png, 06_top_source_ips.png, 07_fim_events.png.
