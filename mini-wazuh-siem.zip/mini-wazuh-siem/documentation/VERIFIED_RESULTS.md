# Verified results (fill in during your lab)

This file separates **what was verified on a real Wazuh installation** from expectations. When the package was
built, no Wazuh manager was available (no virtualization in the build environment). So the "Actual" columns
are empty until you run the tests.

## Environment
| Item | Value |
|---|---|
| Date | |
| Wazuh manager version (`wazuh-control info`) | |
| Wazuh agent version | |
| Agent OS / `ssh -V` | |
| `wazuh-analysisd -t` result after installing custom_rules.xml | |
| `verify_installed_ruleset.sh` result (all parents OK, no conflicts?) | |

## Part A - logtest (`python3 scripts/logtest_api_runner.py --insecure --json output/logtest_results.json`)
| Scenario | Line | Expected rule / level | Actual rule / level | OK? |
|---|---|---|---|---|
| test1_normal_login | 1 | 5715 / 3 | | |
| test2_one_failed_login | 1 | 5760 / 5 | | |
| test3_repeated_failed_logins | 5 | 100101 / 8 | | |
| test3_repeated_failed_logins | 8 | 5763 / 10 | | |
| test4a_multiple_invalid_usernames | 1 | 5710 / 5 | | |
| test4a_multiple_invalid_usernames | 4 | 100102 / 10 | | |
| test4b_multiple_existing_accounts | 4 | 100103 / 10 | | |
| test5_root_login_attempts | 3 | 100104 / 9 | | |
| test5b_high_volume_failures | 15 | 100105 / 12 | | |
| test5c_success_after_failures | 6 | 100110 / 14 | | |
| FIM create / modify / delete | - | 554 / 550 / 553 | | |

Decoder fields seen in Phase 2:
- Invalid user line: srcip ☐, srcuser ☐
- Failed password line: srcip ☐, dstuser ☐

## Part B - end-to-end (replay on the agent → dashboard)
| Scenario | Alert visible in dashboard? | Rule IDs seen | Delay (s) |
|---|---|---|---|
| | | | |

## Differences and what was changed
_If a line differed: note the actual rule, the reason (e.g. counting behaviour of R4, rule 40112 instead of
100110), and any threshold change you made to custom_rules.xml._
