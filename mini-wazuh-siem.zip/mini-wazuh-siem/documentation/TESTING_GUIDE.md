# Testing guide - exact commands and expected results

There are three levels of testing. Each one gives stronger evidence than the one before.

| Part | Where | What it proves | Status of this package |
|---|---|---|---|
| 0. Offline checks | any PC with Python 3 | XML well-formed, IDs/levels/options valid, Python helpers correct | **done**: `pytest` passes, `validate_rules.py` OK |
| A. Rule test (wazuh-logtest) | Wazuh manager | decoders + built-in + custom rules produce the expected rule IDs | **you run it** in the lab |
| B. End-to-end | agent → manager → dashboard | collection, transport, indexing and display | **you run it** in the lab |

All test events are synthetic: private lab addresses 192.168.56.0/24 and fictional usernames. No password lists,
no brute-force tools, no third-party systems.

## Part 0 - offline (already executed while building the package)
```bash
cd mini-wazuh-siem
python3 -m pip install -r requirements.txt     # pandas, pytest
python3 -m pytest -v                            # Python helpers, rule-file checks, replay safety, logtest runner (mocked API)
python3 scripts/validate_rules.py               # static checks of custom_rules.xml and the agent example
```

## Part A - rule tests on the manager
### A1. Interactive (good for the demo)
```bash
sudo /var/ossec/bin/wazuh-logtest          # add -v to see every rule that was tried
```
Paste the lines of **one** file from `samples/logs/` one at a time. Example: `samples/logs/test3_repeated_failed_logins.log`.
Wazuh keeps a session, so frequency rules see the earlier lines. Before the next scenario, press **Ctrl+C** and
start `wazuh-logtest` again. A fresh session resets counters and `ignore` timers, so scenarios can't influence
each other.

What to read in the output:
- **Phase 1** - `program_name: 'sshd'` (pre-decoding worked)
- **Phase 2** - `name: 'sshd'`, `srcip: '192.168.56.xx'`, and `srcuser` (non-existent user) or `dstuser` (existing user)
- **Phase 3** - `id: '...'`, `level: '...'`, `description`, and `frequency` for correlation rules
- `**Alert to be generated.` (level ≥ 3)

Single-line check with an exit code (documented `-U rule:level:decoder` option):
```bash
echo 'Nov  6 18:00:01 lab-ubuntu-agent sshd[4242]: Invalid user admin from 192.168.56.32 port 52000' \
  | sudo /var/ossec/bin/wazuh-logtest -U 5710:5:sshd ; echo "exit=$?"     # 0 = matched as expected
```
(The documentation describes `-U` for one log line. If piping isn't accepted on your version, start the command
and paste the line.)

### A2. Automated (all scenarios, through the Wazuh server API)
```bash
python3 scripts/logtest_api_runner.py --user wazuh --insecure            # lab only: self-signed API certificate
python3 scripts/logtest_api_runner.py --scenario test5c_success_after_failures --insecure
python3 scripts/logtest_api_runner.py --insecure --json output/logtest_results.json
```
The runner opens a new logtest session per scenario (`PUT /logtest`), sends the lines with the session token,
compares rule ID and level for every line, and closes the session. The password for the API user `wazuh` is in
`wazuh-passwords.txt` (see `deployment/server_setup.md`). You can also put it in the `WAZUH_API_PASSWORD`
environment variable for the current shell only. Exit code 0 means every line matched.

## Expected results per scenario
The expected IDs come from the official Wazuh documentation and ruleset (built-in rules) and from
`custom_rules.xml`. They are **expectations to verify**: record the real output in
`documentation/VERIFIED_RESULTS.md`.

### TEST 1 - Normal successful login  (`test1_normal_login`)
A normal successful SSH login is recorded as an authentication-success event.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Accepted password for alice from 192.168.56.1 port 50122 ssh2` | **5715** | 3 | sshd: authentication success |

Basis: built-in rule 5715 (level 3).

### TEST 2 - One failed login  (`test2_one_failed_login`)
A single wrong password is recorded as a low-severity failure - not as an attack.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for alice from 192.168.56.30 port 50200 ssh2` | **5760** | 5 | sshd: authentication failed |

Basis: built-in rule 5760 (child of 5716).

### TEST 3 - Repeated failed logins (one account, one IP)  (`test3_repeated_failed_logins`)
5 failures in 2 minutes -> custom early warning; 8 failures -> built-in brute-force rule.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for alice from 192.168.56.31 port 51000 ssh2` | **5760** | 5 | single failure |
| 2 | `Failed password for alice from 192.168.56.31 port 51001 ssh2` | **5760** | 5 | single failure |
| 3 | `Failed password for alice from 192.168.56.31 port 51002 ssh2` | **5760** | 5 | single failure |
| 4 | `Failed password for alice from 192.168.56.31 port 51003 ssh2` | **5760** | 5 | single failure |
| 5 | `Failed password for alice from 192.168.56.31 port 51004 ssh2` | **100101** | 8 | R1: 5th failure from the same IP within 120 s |
| 6 | `Failed password for alice from 192.168.56.31 port 51005 ssh2` | **5760** | 5 | single failure |
| 7 | `Failed password for alice from 192.168.56.31 port 51006 ssh2` | **5760** | 5 | single failure |
| 8 | `Failed password for alice from 192.168.56.31 port 51007 ssh2` | **5763** | 10 | built-in: 8th failure from the same IP within 120 s |

Basis: custom 100101 (frequency 5) and built-in 5763 (frequency 8).

### TEST 4a - Several non-existent usernames from one IP  (`test4a_multiple_invalid_usernames`)
Username enumeration: 4 different fictional usernames that do not exist on the system.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Invalid user admin from 192.168.56.32 port 52000` | **5710** | 5 | attempt to log in with a non-existent user |
| 2 | `Invalid user test from 192.168.56.32 port 52001` | **5710** | 5 | attempt to log in with a non-existent user |
| 3 | `Invalid user oracle from 192.168.56.32 port 52002` | **5710** | 5 | attempt to log in with a non-existent user |
| 4 | `Invalid user guest from 192.168.56.32 port 52003` | **100102** | 10 | R2: 4th event with a username different from the earlier ones |

Basis: built-in 5710 (decodes srcuser); custom 100102 (different_srcuser, frequency 4).

### TEST 4b - Several existing accounts from one IP  (`test4b_multiple_existing_accounts`)
Password spraying pattern: one wrong password each for 4 different (fictional) accounts.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for alice from 192.168.56.33 port 53000 ssh2` | **5760** | 5 | single failure |
| 2 | `Failed password for bob from 192.168.56.33 port 53001 ssh2` | **5760** | 5 | single failure |
| 3 | `Failed password for carol from 192.168.56.33 port 53002 ssh2` | **5760** | 5 | single failure |
| 4 | `Failed password for dave from 192.168.56.33 port 53003 ssh2` | **100103** | 10 | R2b: 4th failure, usernames differ |

Basis: built-in 5760 (decodes dstuser = user); custom 100103 (different_user, frequency 4).

### TEST 5 - Repeated failed root logins  (`test5_root_login_attempts`)
Three failed password attempts for root from the same IP.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for root from 192.168.56.34 port 54000 ssh2` | **5760** | 5 | single failure |
| 2 | `Failed password for root from 192.168.56.34 port 54001 ssh2` | **5760** | 5 | single failure |
| 3 | `Failed password for root from 192.168.56.34 port 54002 ssh2` | **100104** | 9 | R3: 3rd failed root login from the same IP within 300 s |

Basis: custom 100104 (same_user + <user>^root$</user>, frequency 3).

### TEST 5b - High-volume authentication failures  (`test5b_high_volume_failures`)
15 failures from one IP in a short time.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for alice from 192.168.56.35 port 55000 ssh2` | **5760** | 5 | single failure |
| 2 | `Failed password for alice from 192.168.56.35 port 55001 ssh2` | **5760** | 5 | single failure |
| 3 | `Failed password for alice from 192.168.56.35 port 55002 ssh2` | **5760** | 5 | single failure |
| 4 | `Failed password for alice from 192.168.56.35 port 55003 ssh2` | **5760** | 5 | single failure |
| 5 | `Failed password for alice from 192.168.56.35 port 55004 ssh2` | **100101** | 8 | R1 at the 5th failure |
| 6 | `Failed password for alice from 192.168.56.35 port 55005 ssh2` | **5760** | 5 | single failure |
| 7 | `Failed password for alice from 192.168.56.35 port 55006 ssh2` | **5760** | 5 | single failure |
| 8 | `Failed password for alice from 192.168.56.35 port 55007 ssh2` | **5763** | 10 | built-in 5763 at the 8th failure |
| 9 | `Failed password for alice from 192.168.56.35 port 55008 ssh2` | **5760** | 5 | single failure |
| 10 | `Failed password for alice from 192.168.56.35 port 55009 ssh2` | **5760** | 5 | single failure |
| 11 | `Failed password for alice from 192.168.56.35 port 55010 ssh2` | **5760** | 5 | single failure |
| 12 | `Failed password for alice from 192.168.56.35 port 55011 ssh2` | **5760** | 5 | single failure |
| 13 | `Failed password for alice from 192.168.56.35 port 55012 ssh2` | **5760** | 5 | single failure |
| 14 | `Failed password for alice from 192.168.56.35 port 55013 ssh2` | **5760** | 5 | single failure |
| 15 | `Failed password for alice from 192.168.56.35 port 55014 ssh2` | **100105** | 12 | R4 at the 15th failure (see note on counting) |

Basis: custom 100105 (frequency 15). If the 15th line still shows 5760, Wazuh did not count the events that became 100101/5763 alerts - then R4 appears on the 16th/17th line..

### TEST 5c - Successful login after repeated failures  (`test5c_success_after_failures`)
5 failures followed by a successful login from the same IP.

| # | Log message (after `sshd[pid]: `) | Expected rule | Level | Why |
|---|---|---|---|---|
| 1 | `Failed password for alice from 192.168.56.36 port 56000 ssh2` | **5760** | 5 | single failure |
| 2 | `Failed password for alice from 192.168.56.36 port 56001 ssh2` | **5760** | 5 | single failure |
| 3 | `Failed password for alice from 192.168.56.36 port 56002 ssh2` | **5760** | 5 | single failure |
| 4 | `Failed password for alice from 192.168.56.36 port 56003 ssh2` | **5760** | 5 | single failure |
| 5 | `Failed password for alice from 192.168.56.36 port 56004 ssh2` | **100101** | 8 | R1 at the 5th failure |
| 6 | `Accepted password for alice from 192.168.56.36 port 56010 ssh2` | **100110** | 14 | R5: success from an IP that triggered a brute-force indicator in the last 600 s |

Basis: custom 100110 (if_sid 5715 + if_matched_group ssh_brute_force + same_srcip).

### TEST 6 - File modification (optional FIM)
See `detection/fim_detection.md`. Create, modify and delete `/opt/mini-siem-fim-test/app.conf` on the agent.
Expected: 554 (added), 550 (checksum changed), 553 (deleted).

## Part B - end-to-end on the lab (agent → dashboard)
On the **agent** (copy the `scripts/` folder there first, e.g. `scp -r scripts <you>@192.168.56.20:~/mini-siem-scripts`):
```bash
cd ~/mini-siem-scripts
sudo python3 replay_synthetic_events.py --list
sudo python3 replay_synthetic_events.py --scenario test1_normal_login
sudo python3 replay_synthetic_events.py --scenario test3_repeated_failed_logins
#   wait 5 minutes between scenarios (rule "ignore" timers on the manager are global), or:
sudo python3 replay_synthetic_events.py --scenario all       # waits 310 s between scenarios automatically
```
The script only appends to `/var/log/mini-siem/synthetic_auth.log`. It refuses `/var/log/auth.log` and any
other path.

On the **dashboard** (time range: last 15 minutes):
- `location:"/var/log/mini-siem/synthetic_auth.log"` shows every synthetic event.
- `rule.groups:"mini_siem"` shows the custom detections.

The same rule IDs as in Part A should appear, normally within seconds.

On the **manager** (optional check of the raw alert file):
```bash
sudo grep -c '"location":"/var/log/mini-siem/synthetic_auth.log"' /var/ossec/logs/alerts/alerts.json
sudo tail -n 3 /var/ossec/logs/alerts/alerts.json | python3 -m json.tool | head -40
```

### Optional live SSH test (authorized lab only)
To show that real SSH logs are collected, type a wrong password **by hand** two or three times from the host PC
to the agent VM you own:
```bash
ssh labuser@192.168.56.20      # wrong password 2-3 times, then Ctrl+C
```
Expected on the dashboard: `location:"/var/log/auth.log"` with rule 5760 (or 5710 for a non-existent user), and
`data.srcip` = your host-only address (192.168.56.1). Don't use password lists or automated guessing tools.

## After testing: analyse the exported alerts
```bash
sudo cp /var/ossec/logs/alerts/alerts.json ~/alerts.json && sudo chown $USER: ~/alerts.json && chmod 600 ~/alerts.json
python3 scripts/analyze_wazuh_alerts.py ~/alerts.json
python3 scripts/export_alert_summary.py ~/alerts.json --out output/case-001 --case CASE-001 --analyst "Your Name"
```
