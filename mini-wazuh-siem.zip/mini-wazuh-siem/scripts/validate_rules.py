#!/usr/bin/env python3
"""
validate_rules.py - OFFLINE static checks of wazuh/manager/custom_rules.xml and the agent example.

This does NOT replace Wazuh's own check (/var/ossec/bin/wazuh-analysisd -t) or wazuh-logtest on a
real manager. It catches mistakes before you copy the file to the manager:

  * XML well-formed (Wazuh rule files may hold several top-level <group> blocks, so the file is
    wrapped in a temporary root element for parsing)
  * every <rule> sits inside a <group name="..."> and has a description
  * IDs unique, inside the custom range 100000-120000
  * level 0-16, frequency 2-9999, timeframe 1-99999, ignore 1-999999 (documented ranges)
  * frequency is used together with timeframe and an if_matched_* element
  * child elements are documented rule options (allow-list below)
  * parent references (if_sid / if_matched_sid) point to the expected built-in sshd rules or to a
    rule in this file; if_matched_group names a group defined in this file or a known built-in group
  * descriptions avoid verdict words ("confirmed", "malicious", "attacker")

Usage:  python scripts/validate_rules.py [rules.xml] [agent_conf.example]
Exit code 0 = no errors.
"""

from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RULES = ROOT / "wazuh" / "manager" / "custom_rules.xml"
AGENT = ROOT / "wazuh" / "agent" / "ossec.conf.example"

CUSTOM_RANGE = (100000, 120000)
# Built-in sshd rules this project builds on (Wazuh 4.14 ruleset/rules/0095-sshd_rules.xml).
# Confirm on the manager with scripts/verify_installed_ruleset.sh.
KNOWN_BUILTIN_PARENTS = {"5700", "5710", "5715", "5716", "5760"}
KNOWN_BUILTIN_GROUPS = {"authentication_failed", "authentication_success", "authentication_failures",
                        "invalid_login", "sshd", "syslog"}
# Rule options documented in the Wazuh "Rules Syntax" reference that this project may use
ALLOWED_CHILDREN = {
    "match", "regex", "decoded_as", "category", "field", "srcip", "dstip", "srcport", "dstport", "data",
    "extra_data", "user", "system_name", "program_name", "protocol", "hostname", "time", "weekday", "id",
    "url", "location", "action", "status", "srcgeoip", "dstgeoip", "if_sid", "if_group", "if_level",
    "if_matched_sid", "if_matched_group", "same_id", "same_srcip", "same_source_ip", "different_srcip",
    "same_location", "same_user", "different_user", "same_srcuser", "different_srcuser", "same_field",
    "different_field", "description", "list", "info", "options", "check_diff", "group", "mitre",
}
RANGES = {"level": (0, 16), "frequency": (2, 9999), "timeframe": (1, 99999), "ignore": (1, 999999)}
VERDICT_WORDS = re.compile(r"\b(confirmed|malicious|attacker|hacked|compromised)\b", re.I)


def parse_multi_root(path: Path) -> ET.Element:
    text = path.read_text(encoding="utf-8")
    return ET.fromstring(f"<mini_siem_root>{text}</mini_siem_root>")


def validate_rules(path: Path = RULES) -> tuple[list[str], list[dict]]:
    errors: list[str] = []
    try:
        root = parse_multi_root(path)
    except ET.ParseError as exc:
        return [f"XML not well-formed: {exc}"], []
    rules = []
    defined_groups: set[str] = set()
    for grp in root.findall("group"):
        names = [n.strip() for n in (grp.get("name") or "").split(",") if n.strip()]
        if not names:
            errors.append("a <group> has no name attribute")
        if not (grp.get("name") or "").endswith(","):
            errors.append(f"group name {grp.get('name')!r} should end with ',' (Wazuh convention)")
        defined_groups.update(names)
        for r in grp.findall("rule"):
            for g in r.findall("group"):
                defined_groups.update(n.strip() for n in (g.text or "").split(",") if n.strip())
            rules.append(r)
    if root.findall("rule"):
        errors.append("rule(s) outside a <group> block")
    ids = [r.get("id") for r in rules]
    own_ids = set(ids)
    summary = []
    for r in rules:
        rid = r.get("id") or "?"
        if not rid.isdigit():
            errors.append(f"rule {rid}: id must be numeric")
            continue
        if not CUSTOM_RANGE[0] <= int(rid) <= CUSTOM_RANGE[1]:
            errors.append(f"rule {rid}: id outside the custom range {CUSTOM_RANGE}")
        if ids.count(rid) > 1:
            errors.append(f"rule {rid}: duplicate id")
        for attr, (lo, hi) in RANGES.items():
            if r.get(attr) is not None:
                v = r.get(attr)
                if not v.isdigit() or not lo <= int(v) <= hi:
                    errors.append(f"rule {rid}: {attr}={v!r} outside {lo}-{hi}")
        if r.get("level") is None:
            errors.append(f"rule {rid}: missing level")
        if r.get("frequency") and not r.get("timeframe"):
            errors.append(f"rule {rid}: frequency without timeframe")
        if r.get("frequency") and r.find("if_matched_sid") is None and r.find("if_matched_group") is None:
            errors.append(f"rule {rid}: frequency needs if_matched_sid or if_matched_group")
        if (r.find("if_matched_sid") is not None or r.find("if_matched_group") is not None) and not r.get("timeframe"):
            errors.append(f"rule {rid}: if_matched_* needs a timeframe")
        for child in r:
            if child.tag not in ALLOWED_CHILDREN:
                errors.append(f"rule {rid}: unknown option <{child.tag}>")
        desc = (r.findtext("description") or "").strip()
        if not desc:
            errors.append(f"rule {rid}: missing description")
        if VERDICT_WORDS.search(desc):
            errors.append(f"rule {rid}: description uses a verdict word: {desc!r}")
        if r.find("group") is None:
            errors.append(f"rule {rid}: no <group> inside the rule (needed for dashboard filtering)")
        for tag in ("if_sid", "if_matched_sid"):
            for el in r.findall(tag):
                for ref in re.split(r"[,\s]+", (el.text or "").strip()):
                    if ref and ref not in own_ids and ref not in KNOWN_BUILTIN_PARENTS:
                        errors.append(f"rule {rid}: <{tag}> {ref} is neither built-in sshd nor defined here")
                    if ref == rid:
                        errors.append(f"rule {rid}: references itself")
        for el in r.findall("if_matched_group"):
            g = (el.text or "").strip()
            own = {n.strip() for x in r.findall("group") for n in (x.text or "").split(",")}
            if g in own:
                errors.append(f"rule {rid}: if_matched_group {g!r} is one of its own groups (self-trigger)")
            if g not in defined_groups and g not in KNOWN_BUILTIN_GROUPS:
                errors.append(f"rule {rid}: if_matched_group {g!r} is not defined")
        for m in r.findall("mitre"):
            for i in m.findall("id"):
                if not re.fullmatch(r"T\d{4}(\.\d{3})?", (i.text or "").strip()):
                    errors.append(f"rule {rid}: bad MITRE id {i.text!r}")
        summary.append({"id": rid, "level": int(r.get("level", 0)), "frequency": r.get("frequency"),
                        "timeframe": r.get("timeframe"),
                        "parent": (r.findtext("if_matched_sid") or r.findtext("if_sid") or "").strip(),
                        "description": desc})
    return errors, summary


def validate_agent_conf(path: Path = AGENT) -> list[str]:
    errors = []
    try:
        root = parse_multi_root(path)
    except ET.ParseError as exc:
        return [f"agent example XML not well-formed: {exc}"]
    blocks = root.findall("ossec_config")
    if not blocks:
        errors.append("agent example has no <ossec_config> block")
    locations = [lf.findtext("location") for b in blocks for lf in b.findall("localfile")]
    for lf in (lf for b in blocks for lf in b.findall("localfile")):
        if not lf.findtext("log_format"):
            errors.append(f"localfile {lf.findtext('location')}: log_format is required")
    if len(locations) != len(set(locations)):
        errors.append("the same location is configured twice (duplicate events)")
    if "/var/log/auth.log" not in locations:
        errors.append("active configuration does not collect /var/log/auth.log")
    for b in blocks:
        for d in b.iter("directories"):
            if (d.text or "").strip() in {"/etc", "/usr/bin", "/usr/sbin", "/bin", "/sbin", "/"}:
                errors.append(f"FIM demo must use a synthetic directory, not {d.text}")
    return errors


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    rules = Path(argv[0]) if argv else RULES
    agent = Path(argv[1]) if len(argv) > 1 else AGENT
    errors, summary = validate_rules(rules)
    errors += validate_agent_conf(agent)
    for s in summary:
        freq = f"{s['frequency']} in {s['timeframe']}s" if s["frequency"] else (f"within {s['timeframe']}s" if s["timeframe"] else "-")
        print(f"rule {s['id']}  level {s['level']:>2}  parent {s['parent']:<6} {freq:<14} {s['description'][:70]}")
    if errors:
        print("\nERRORS:\n  " + "\n  ".join(errors))
        return 1
    print(f"\nOK: {len(summary)} custom rules and the agent example passed the offline checks.")
    print("Still required on the manager: wazuh-analysisd -t and wazuh-logtest (see deployment/server_setup.md).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
