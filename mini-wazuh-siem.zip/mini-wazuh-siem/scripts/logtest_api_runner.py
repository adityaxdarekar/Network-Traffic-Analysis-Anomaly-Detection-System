#!/usr/bin/env python3
"""
logtest_api_runner.py - automated rule test, run ON THE WAZUH MANAGER (or a host on the lab network).

For every scenario in scripts/scenarios.py it opens a NEW logtest session through the Wazuh server
API (the same engine as /var/ossec/bin/wazuh-logtest), sends the scenario's lines in order with the
session token (so frequency rules see the earlier events), records the rule ID and level Wazuh
returns for every line, compares them with the expected values and closes the session.

Documented API calls used:
  POST   /security/user/authenticate          (basic auth -> JWT)
  PUT    /logtest                             body: {"event", "log_format", "location", "token"?}
  DELETE /logtest/sessions/{token}

Usage on the manager:
  python3 logtest_api_runner.py --user wazuh --cacert /path/to/api-ca.pem
  python3 logtest_api_runner.py --user wazuh --insecure          # lab only: self-signed API certificate
  python3 logtest_api_runner.py --scenario test3_repeated_failed_logins --insecure
The password is read from the WAZUH_API_PASSWORD environment variable or asked interactively
(it is never stored). The API user password is in wazuh-passwords.txt from the installation.

Exit code: 0 = every line matched the expected rule, 1 = differences (printed), 2 = error.
"""

from __future__ import annotations

import argparse
import base64
import getpass
import json
import os
import ssl
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import scenarios as S  # noqa: E402

LOCATION = "mini-siem->/var/log/mini-siem/synthetic_auth.log"


class ApiError(RuntimeError):
    pass


class WazuhAPI:
    def __init__(self, base_url: str, context: ssl.SSLContext | None, opener=None):
        self.base = base_url.rstrip("/")
        self.context = context
        self.token = None
        self._open = opener or (lambda req: urllib.request.urlopen(req, context=self.context, timeout=30))

    def _request(self, method: str, path: str, body: dict | None = None, headers: dict | None = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        h.update(headers or {})
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            with self._open(req) as resp:
                raw = resp.read().decode() or "{}"
        except urllib.error.HTTPError as exc:
            raise ApiError(f"{method} {path}: HTTP {exc.code} {exc.read().decode(errors='replace')[:300]}") from exc
        except urllib.error.URLError as exc:
            raise ApiError(f"{method} {path}: {exc.reason}") from exc
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"raw": raw}

    def login(self, user: str, password: str) -> None:
        cred = base64.b64encode(f"{user}:{password}".encode()).decode()
        res = self._request("POST", "/security/user/authenticate", headers={"Authorization": f"Basic {cred}"})
        token = (res.get("data") or {}).get("token")
        if not token:
            raise ApiError(f"authentication failed: {res}")
        self.token = token

    def logtest(self, event: str, session: str | None) -> dict:
        body = {"event": event, "log_format": "syslog", "location": LOCATION}
        if session:
            body["token"] = session
        return self._request("PUT", "/logtest", body)

    def close(self, session: str) -> None:
        try:
            self._request("DELETE", f"/logtest/sessions/{session}")
        except ApiError:
            pass


def parse_result(res: dict) -> tuple[str | None, str, int | None, str]:
    """-> (session_token, rule_id, rule_level, description) from a PUT /logtest response."""
    data = res.get("data") or {}
    output = data.get("output") or {}
    rule = output.get("rule") or {}
    level = rule.get("level")
    return (data.get("token"), str(rule.get("id", "-")) if rule else "-",
            int(level) if level is not None else None, rule.get("description", "(no rule matched)"))


def run_scenario(api: WazuhAPI, scenario: S.Scenario, out=None) -> list[dict]:
    out = out or sys.stdout
    session = None
    rows = []
    out.write(f"\n== {scenario.title} ==\n")
    try:
        for i, step in enumerate(scenario.steps, 1):
            line = S.syslog_line(step.message, datetime.now(), pid=4200 + i)
            token, rid, level, desc = parse_result(api.logtest(line, session))
            session = token or session
            ok = rid == step.expect_rule and level == step.expect_level
            rows.append({"scenario": scenario.key, "n": i, "expected": step.expect_rule,
                         "expected_level": step.expect_level, "actual": rid, "actual_level": level,
                         "description": desc, "ok": ok})
            out.write(f"  [{i:>2}] {'OK  ' if ok else 'DIFF'} expected {step.expect_rule}/{step.expect_level}"
                      f"  got {rid}/{level}  {desc}\n")
    finally:
        if session:
            api.close(session)
    return rows


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Run the Mini-SIEM scenarios through the Wazuh logtest API.")
    p.add_argument("--url", default="https://localhost:55000", help="Wazuh server API URL")
    p.add_argument("--user", default="wazuh", help="API user (default wazuh)")
    p.add_argument("--scenario", default="all", help="scenario key or 'all'")
    p.add_argument("--cacert", help="CA certificate that signed the API certificate")
    p.add_argument("--insecure", action="store_true", help="skip TLS verification (isolated lab only)")
    p.add_argument("--json", help="also write the results to this JSON file")
    args = p.parse_args(argv)

    try:
        chosen = S.SCENARIOS if args.scenario == "all" else [S.by_key(args.scenario)]
    except KeyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.insecure:
        ctx = ssl._create_unverified_context()  # noqa: S323 - explicit lab-only opt-in
        print("WARNING: TLS verification disabled (--insecure). Use only inside the isolated lab.", file=sys.stderr)
    else:
        ctx = ssl.create_default_context(cafile=args.cacert) if args.cacert else ssl.create_default_context()
    password = os.environ.get("WAZUH_API_PASSWORD") or getpass.getpass(f"Password for API user {args.user}: ")
    api = WazuhAPI(args.url, ctx)
    try:
        api.login(args.user, password)
        rows = [r for s in chosen for r in run_scenario(api, s)]
    except ApiError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    bad = [r for r in rows if not r["ok"]]
    print(f"\n{len(rows) - len(bad)}/{len(rows)} lines matched the expected rule and level.")
    if args.json:
        Path(args.json).write_text(json.dumps(rows, indent=2), encoding="utf-8")
        print(f"Results written to {args.json}")
    if bad:
        print("Differences are information, not failure of the project: record the actual IDs in "
              "documentation/VERIFIED_RESULTS.md and see detection/brute_force_detection.md (troubleshooting).")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
