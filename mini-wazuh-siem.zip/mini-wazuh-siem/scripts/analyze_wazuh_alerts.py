#!/usr/bin/env python3
"""
analyze_wazuh_alerts.py - summarise EXPORTED Wazuh alerts for an investigation.

Wazuh does the detection. This helper only reads alerts that Wazuh already generated and
groups the authentication-related ones by source IP and by username, so an analyst can
write up an investigation. It never blocks anything, never contacts external services and
never labels an IP "malicious".

Accepted input (auto-detected):
  * JSON Lines - one alert per line, like /var/ossec/logs/alerts/alerts.json on the manager
  * a JSON array of alerts
  * an indexer/OpenSearch search response: {"hits": {"hits": [{"_source": {...}}, ...]}}

Usage:
  python scripts/analyze_wazuh_alerts.py samples/brute_force_events.json
  python scripts/analyze_wazuh_alerts.py alerts.json --csv out/ip_summary.csv --top 10

Exported alerts can contain usernames, IP addresses and host names - store them like other
sensitive investigation data (restricted folder, delete when no longer needed).
"""

from __future__ import annotations

import argparse
import csv
import ipaddress
import json
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

# Rule groups (as written by Wazuh in rule.groups) that mark authentication activity
FAILURE_GROUPS = {"authentication_failed", "invalid_login", "authentication_failures", "ssh_brute_force"}
SUCCESS_GROUPS = {"authentication_success", "ssh_success_after_failures"}
# Correlation (frequency / follow-up) rules: each of these alerts replaces the alert of the single
# event that completed the pattern, so it still represents one failed (or successful) attempt.
CORRELATION_GROUPS = {"authentication_failures", "ssh_brute_force", "ssh_success_after_failures"}

SEVERITY_ORDER = ["Informational", "Low", "Medium", "High", "Critical"]


def severity_label(level: int) -> str:
    """Project severity scale on top of Wazuh rule levels (0-16)."""
    if level <= 3:
        return "Informational"     # level 3 = successful/authorized events in Wazuh's classification
    if level <= 6:
        return "Low"
    if level <= 9:
        return "Medium"
    if level <= 12:
        return "High"
    return "Critical"


def classify_ip(value: str | None) -> tuple[str, str]:
    """-> (ip_version, ip_class). Classes: loopback, private, link-local, documentation,
    reserved, public, invalid, missing. 'public' only means 'globally routable', not 'malicious'."""
    if not value:
        return "", "missing"
    try:
        ip = ipaddress.ip_address(value.strip().split("%")[0])
    except ValueError:
        return "", "invalid"
    version = f"IPv{ip.version}"
    if ip.version == 6 and ip.ipv4_mapped:
        return classify_ip(str(ip.ipv4_mapped))
    if ip.is_loopback:
        return version, "loopback"
    if ip.is_link_local:
        return version, "link-local"
    doc_nets = [ipaddress.ip_network(n) for n in
                ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24", "2001:db8::/32")]
    if any(ip in n for n in doc_nets if n.version == ip.version):
        return version, "documentation"
    if ip.version == 4 and any(ip in ipaddress.ip_network(n)
                               for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")):
        return version, "private"
    if ip.version == 6 and ip in ipaddress.ip_network("fc00::/7"):
        return version, "private"        # unique local addresses
    if ip.is_global:
        return version, "public"
    return version, "reserved"


# ------------------------------------------------------------------------------------- loading
@dataclass
class LoadResult:
    alerts: list = field(default_factory=list)
    skipped_lines: int = 0
    source_format: str = ""


def _unwrap(obj) -> list:
    if isinstance(obj, dict) and "hits" in obj and isinstance(obj["hits"], dict):
        return [h.get("_source", h) for h in obj["hits"].get("hits", []) if isinstance(h, dict)]
    if isinstance(obj, list):
        out = []
        for item in obj:
            if isinstance(item, dict) and "_source" in item:
                out.append(item["_source"])
            elif isinstance(item, dict):
                out.append(item)
        return out
    if isinstance(obj, dict):
        return [obj]
    return []


def load_alerts(path: str | Path) -> LoadResult:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    stripped = text.strip()
    if not stripped:
        return LoadResult([], 0, "empty")
    try:
        obj = json.loads(stripped)
        alerts = _unwrap(obj)
        fmt = "opensearch" if isinstance(obj, dict) and "hits" in obj else (
            "json-array" if isinstance(obj, list) else "json-object")
        return LoadResult(alerts, 0, fmt)
    except json.JSONDecodeError:
        pass
    res = LoadResult(source_format="json-lines")
    for line in stripped.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            res.skipped_lines += 1
            continue
        if isinstance(item, dict):
            res.alerts.append(item)
        else:
            res.skipped_lines += 1
    return res


# ------------------------------------------------------------------------------------ extraction
def _groups(alert: dict) -> set:
    g = (alert.get("rule") or {}).get("groups") or []
    return {str(x) for x in g} if isinstance(g, list) else {str(g)}


def event_kind(alert: dict) -> str | None:
    """'failure', 'success' or None (not an authentication event)."""
    groups = _groups(alert)
    if groups & SUCCESS_GROUPS:
        return "success"
    if groups & FAILURE_GROUPS:
        return "failure"
    return None


def is_auth_event(alert: dict) -> bool:
    return event_kind(alert) is not None


def username(alert: dict) -> str:
    data = alert.get("data") or {}
    for key in ("dstuser", "srcuser", "user"):
        if data.get(key):
            return str(data[key])
    return ""


def to_record(alert: dict) -> dict:
    rule = alert.get("rule") or {}
    data = alert.get("data") or {}
    agent = alert.get("agent") or {}
    try:
        level = int(rule.get("level", 0))
    except (TypeError, ValueError):
        level = 0
    groups = _groups(alert)
    srcip = data.get("srcip") or ""
    version, ip_class = classify_ip(srcip)
    return {
        "timestamp": alert.get("timestamp", ""),
        "rule_id": str(rule.get("id", "")),
        "rule_level": level,
        "severity": severity_label(level),
        "rule_description": rule.get("description", ""),
        "kind": event_kind(alert),
        "correlation": bool(groups & CORRELATION_GROUPS),
        "srcip": srcip,
        "ip_version": version,
        "ip_class": ip_class,
        "username": username(alert),
        "agent": agent.get("name", ""),
        "location": alert.get("location", ""),
        "full_log": alert.get("full_log", ""),
    }


def auth_frame(alerts: list) -> pd.DataFrame:
    rows = [to_record(a) for a in alerts if is_auth_event(a)]
    cols = ["timestamp", "rule_id", "rule_level", "severity", "rule_description", "kind", "correlation",
            "srcip", "ip_version", "ip_class", "username", "agent", "location", "full_log"]
    df = pd.DataFrame(rows, columns=cols)
    if not df.empty:
        df["ts"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    else:
        df["ts"] = pd.Series(dtype="datetime64[ns, UTC]")
    return df


# ------------------------------------------------------------------------------------- analysis
def _fmt_ts(value) -> str:
    return "" if pd.isna(value) else value.strftime("%Y-%m-%d %H:%M:%S UTC")


def review_note(failed: int, success: int, distinct_users: int, correlation_rules: list) -> str:
    """Plain-language triage hint. Never a verdict - repeated failures are not proof of an attack."""
    notes = []
    if success and failed and any(r for r in correlation_rules):
        notes.append("successful login after brute-force indicators - investigate first")
    elif success and failed:
        notes.append("failures and successes from the same IP - check whether it is the same user")
    if distinct_users >= 3 and failed:
        notes.append(f"{distinct_users} different usernames - possible enumeration/spraying")
    if correlation_rules and not notes:
        notes.append("correlation rule fired - review activity")
    if not notes:
        notes.append("no correlation rule fired" if failed else "normal authentication activity")
    return "; ".join(notes)


def summarise_by_ip(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["srcip", "ip_version", "ip_class", "failed_events", "successful_logins", "distinct_usernames",
            "targeted_usernames", "first_seen", "last_seen", "rules_triggered", "correlation_rules",
            "max_level", "max_severity", "agents", "review_note"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    rows = []
    for ip, g in df.groupby(df["srcip"].replace("", "(none)"), sort=False):
        failed = int((g["kind"] == "failure").sum())
        success = int((g["kind"] == "success").sum())
        users = Counter(u for u in g.loc[g["kind"] == "failure", "username"] if u)
        corr = sorted({f"{r} {d}" for r, d, c in zip(g["rule_id"], g["rule_description"], g["correlation"]) if c})
        rows.append({
            "srcip": ip,
            "ip_version": g["ip_version"].iloc[0],
            "ip_class": g["ip_class"].iloc[0],
            "failed_events": failed,
            "successful_logins": success,
            "distinct_usernames": len(users),
            "targeted_usernames": ", ".join(f"{u} ({n})" for u, n in users.most_common()),
            "first_seen": _fmt_ts(g["ts"].min()),
            "last_seen": _fmt_ts(g["ts"].max()),
            "rules_triggered": ", ".join(f"{r} x{n}" for r, n in Counter(g["rule_id"]).most_common()),
            "correlation_rules": " | ".join(corr),
            "max_level": int(g["rule_level"].max()),
            "max_severity": severity_label(int(g["rule_level"].max())),
            "agents": ", ".join(sorted(set(a for a in g["agent"] if a))),
            "review_note": review_note(failed, success, len(users), corr),
        })
    out = pd.DataFrame(rows, columns=cols)
    return out.sort_values(["max_level", "failed_events"], ascending=False, kind="stable").reset_index(drop=True)


def summarise_users(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["username", "failed_events", "successful_logins", "source_ips"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    rows = []
    for user, g in df[df["username"] != ""].groupby("username"):
        rows.append({"username": user,
                     "failed_events": int((g["kind"] == "failure").sum()),
                     "successful_logins": int((g["kind"] == "success").sum()),
                     "source_ips": ", ".join(sorted(set(g["srcip"]) - {""}))})
    out = pd.DataFrame(rows, columns=cols)
    return out.sort_values(["failed_events", "username"], ascending=[False, True]).reset_index(drop=True)


def severity_summary(df: pd.DataFrame) -> dict:
    counts = Counter(df["severity"]) if not df.empty else Counter()
    return {s: int(counts.get(s, 0)) for s in SEVERITY_ORDER}


def rule_summary(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["rule_id", "rule_level", "rule_description", "alerts"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    # descriptions can contain the source IP ($(srcip)), so group by rule and show one example
    g = (df.groupby(["rule_id", "rule_level"])
           .agg(rule_description=("rule_description", "first"), alerts=("rule_id", "size"))
           .reset_index())
    return g.sort_values(["rule_level", "alerts"], ascending=False).reset_index(drop=True)[cols]


@dataclass
class Analysis:
    total_alerts: int
    auth_alerts: int
    skipped_lines: int
    by_ip: pd.DataFrame
    by_user: pd.DataFrame
    by_rule: pd.DataFrame
    severity: dict
    events: pd.DataFrame


def analyse(path: str | Path) -> Analysis:
    loaded = load_alerts(path)
    df = auth_frame(loaded.alerts)
    return Analysis(len(loaded.alerts), len(df), loaded.skipped_lines, summarise_by_ip(df),
                    summarise_users(df), rule_summary(df), severity_summary(df), df)


def write_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, quoting=csv.QUOTE_MINIMAL)
    return path


def print_report(a: Analysis, top: int = 10, out=None) -> None:
    out = out or sys.stdout
    w = out.write
    w(f"Alerts read: {a.total_alerts}   authentication-related: {a.auth_alerts}"
      + (f"   malformed lines skipped: {a.skipped_lines}" if a.skipped_lines else "") + "\n\n")
    w("Severity summary: " + ", ".join(f"{k} {v}" for k, v in a.severity.items()) + "\n\n")
    if a.by_ip.empty:
        w("No authentication alerts found.\n")
        return
    w("Source IPs (sorted by highest alert level):\n")
    view = a.by_ip.head(top)[["srcip", "ip_class", "failed_events", "successful_logins", "distinct_usernames",
                              "max_level", "max_severity", "first_seen", "last_seen", "review_note"]]
    w(view.to_string(index=False) + "\n\n")
    w("Most targeted usernames (failed events):\n")
    w(a.by_user.head(top).to_string(index=False) + "\n\n")
    w("Rules:\n" + a.by_rule.to_string(index=False) + "\n")
    w("\nNote: counts are Wazuh alerts, not proven attacks. Review each IP before drawing conclusions.\n")


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Summarise exported Wazuh authentication alerts (read-only).")
    p.add_argument("alerts", help="exported alerts: JSON Lines, JSON array or indexer search response")
    p.add_argument("--csv", help="write the per-IP summary to this CSV file")
    p.add_argument("--top", type=int, default=10, help="rows to print per table (default 10)")
    args = p.parse_args(argv)
    if not Path(args.alerts).is_file():
        print(f"error: file not found: {args.alerts}", file=sys.stderr)
        return 2
    a = analyse(args.alerts)
    print_report(a, args.top)
    if args.csv:
        print(f"\nCSV written: {write_csv(a.by_ip, args.csv)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
