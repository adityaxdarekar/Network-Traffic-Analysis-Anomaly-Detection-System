#!/usr/bin/env python3
"""
replay_synthetic_events.py - run on the AGENT VM to demonstrate detection with SYNTHETIC events.

It appends sshd-style lines (current timestamps) for a test scenario to a DEDICATED file that the
Wazuh agent monitors (see wazuh/agent/ossec.conf.example, block 2):

    /var/log/mini-siem/synthetic_auth.log

Why a separate file: the project must not modify real authentication logs and must not perform
real password guessing. Wazuh decodes these lines exactly like auth.log lines (syslog format,
program name sshd), and every resulting alert shows location = the synthetic file, so synthetic
and real events are never confused.

Usage (on the agent, as root because /var/log is root-owned):
  sudo python3 replay_synthetic_events.py --list
  sudo python3 replay_synthetic_events.py --scenario test3_repeated_failed_logins
  sudo python3 replay_synthetic_events.py --scenario all          # waits --gap seconds between scenarios
  python3 replay_synthetic_events.py --scenario test1_normal_login --dry-run   # print only

Safety:
  * refuses to write to /var/log/auth.log, /var/log/secure or any file outside /var/log/mini-siem/
    (or the --output directory given for tests);
  * only appends; never truncates, deletes or edits existing lines.

Timing: the manager keeps frequency counters and "ignore" timers per rule for all sources, so
scenarios influence each other if run back-to-back. With --scenario all the script waits --gap
seconds (default 310 = longest ignore time + margin) between scenarios.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import scenarios as S  # noqa: E402

DEFAULT_FILE = Path("/var/log/mini-siem/synthetic_auth.log")
ALLOWED_DIR = Path("/var/log/mini-siem")
FORBIDDEN_NAMES = {"auth.log", "secure", "syslog", "messages", "wtmp", "btmp", "lastlog"}


class UnsafeOutput(ValueError):
    pass


def check_output(path: Path, allowed_dir: Path = ALLOWED_DIR) -> Path:
    """Resolve and validate the output file: must be inside allowed_dir and not a real system log."""
    resolved = path.expanduser().resolve()
    allowed = allowed_dir.expanduser().resolve()
    if resolved.name in FORBIDDEN_NAMES or resolved.name.startswith(("auth.log", "secure")):
        raise UnsafeOutput(f"refusing to write to a real system log: {resolved}")
    if allowed not in resolved.parents:
        raise UnsafeOutput(f"output must be inside {allowed}: {resolved}")
    if resolved.is_symlink() or (resolved.exists() and not resolved.is_file()):
        raise UnsafeOutput(f"output is not a regular file: {resolved}")
    return resolved


def append_lines(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o640)
    with os.fdopen(fd, "a", encoding="utf-8") as fh:
        for line in lines:
            fh.write(line + "\n")
            fh.flush()


def replay(scenario: S.Scenario, path: Path | None, delay: float, dry_run: bool, out=None) -> list[str]:
    out = out or sys.stdout
    written = []
    out.write(f"\n== {scenario.title} ==\n{scenario.goal}\n")
    for i, step in enumerate(scenario.steps, 1):
        line = S.syslog_line(step.message, datetime.now(), pid=4200 + i)
        if not dry_run:
            append_lines(path, [line])
        written.append(line)
        out.write(f"  [{i:>2}] {line}\n       expected: rule {step.expect_rule} (level {step.expect_level}) {step.note}\n")
        if delay and i < len(scenario.steps):
            time.sleep(delay)
    return written


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Append SYNTHETIC sshd events to the dedicated test log.")
    p.add_argument("--scenario", help="scenario key or 'all' (see --list)")
    p.add_argument("--list", action="store_true", help="list scenarios")
    p.add_argument("--output", default=str(DEFAULT_FILE), help=f"output file (default {DEFAULT_FILE})")
    p.add_argument("--allowed-dir", default=str(ALLOWED_DIR), help=argparse.SUPPRESS)
    p.add_argument("--delay", type=float, default=1.0, help="seconds between lines (default 1)")
    p.add_argument("--gap", type=float, default=310.0, help="seconds between scenarios with 'all' (default 310)")
    p.add_argument("--dry-run", action="store_true", help="print the lines, do not write")
    args = p.parse_args(argv)

    if args.list or not args.scenario:
        for s in S.SCENARIOS:
            print(f"{s.key:<36} {len(s.steps):>2} events  {s.title}")
        return 0
    try:
        chosen = S.SCENARIOS if args.scenario == "all" else [S.by_key(args.scenario)]
    except KeyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    path = None
    if not args.dry_run:
        try:
            path = check_output(Path(args.output), Path(args.allowed_dir))
        except UnsafeOutput as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
    for n, s in enumerate(chosen):
        replay(s, path, args.delay, args.dry_run)
        if n < len(chosen) - 1:
            print(f"\n... waiting {args.gap:.0f} s so rule timers from this scenario expire ...")
            time.sleep(args.gap)
    print("\nDone." + ("" if args.dry_run else f" Lines appended to {path}. Check the dashboard (location: {path})."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
