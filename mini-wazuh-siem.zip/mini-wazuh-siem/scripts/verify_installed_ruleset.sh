#!/usr/bin/env bash
# verify_installed_ruleset.sh - READ-ONLY check on the Wazuh MANAGER before installing custom_rules.xml.
#
# Confirms, on YOUR installed version, that:
#   1. the built-in sshd rules the custom rules depend on exist (5700 5710 5712 5715 5716 5760 5763),
#      and prints their real level and description;
#   2. none of the custom IDs (100101-100110) is already used by another rule file;
#   3. the FIM rules used in the optional demo exist (550 553 554);
#   4. whether built-in rule 40112 (success after failures) exists on this version.
# It only reads files under /var/ossec. Run:  sudo bash scripts/verify_installed_ruleset.sh
set -u
RULESET=/var/ossec/ruleset/rules
LOCAL=/var/ossec/etc/rules
[ -d "$RULESET" ] || { echo "Not a Wazuh manager: $RULESET not found"; exit 2; }

echo "Wazuh version: $(/var/ossec/bin/wazuh-control info 2>/dev/null | grep -i version || echo unknown)"
status=0
show_rule() {   # $1 = id
  local hit
  hit=$(grep -rn -E "<rule id=\"$1\"" "$RULESET" 2>/dev/null | head -1)
  if [ -z "$hit" ]; then echo "  MISSING  rule $1"; return 1; fi
  local file=${hit%%:*} line; line=$(echo "$hit" | cut -d: -f2)
  local level; level=$(echo "$hit" | grep -o 'level="[0-9]*"' | head -1)
  local desc; desc=$(sed -n "${line},$((line+25))p" "$file" | grep -m1 -o '<description>.*</description>' | sed 's/<[^>]*>//g')
  printf "  OK  %-6s %-10s %-28s %s\n" "$1" "$level" "$(basename "$file")" "$desc"
}

echo; echo "1) Built-in sshd rules used as parents / referenced in the docs:"
for id in 5700 5710 5712 5715 5716 5760 5763; do show_rule "$id" || status=1; done

echo; echo "2) Custom ID collisions (should list only etc/rules/custom_rules.xml, if installed):"
for id in 100101 100102 100103 100104 100105 100110; do
  hits=$(grep -rln -E "<rule id=\"$id\"" "$RULESET" "$LOCAL" 2>/dev/null | grep -v "/custom_rules.xml$")
  if [ -n "$hits" ]; then echo "  CONFLICT $id also in: $hits"; status=1; else echo "  free     $id"; fi
done

echo; echo "3) FIM rules for the optional demo:"
for id in 550 553 554; do show_rule "$id" || status=1; done

echo; echo "4) Built-in 'success after failures' correlation (optional, informational):"
show_rule 40112 || echo "  (not present on this version - the custom rule 100110 covers it)"

echo; echo "5) Field names: run this line through wazuh-logtest and check Phase 2 shows srcuser / srcip:"
echo "   Nov  6 18:00:01 lab-ubuntu-agent sshd[4242]: Invalid user admin from 192.168.56.32 port 52000"
echo "   ...and this one shows dstuser / srcip:"
echo "   Nov  6 18:00:01 lab-ubuntu-agent sshd[4242]: Failed password for alice from 192.168.56.30 port 50200 ssh2"
exit $status
