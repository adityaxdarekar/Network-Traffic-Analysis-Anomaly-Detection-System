#!/usr/bin/env python3
"""
generate_samples.py - (re)create the SYNTHETIC sample files in samples/ from scripts/scenarios.py.

  samples/logs/<scenario>.log        raw sshd lines to paste into wazuh-logtest
  samples/normal_authentication.json synthetic alerts shaped like Wazuh's alerts.json (JSON Lines)
  samples/failed_login_events.json
  samples/brute_force_events.json

The JSON files are NOT output of a real Wazuh manager. They follow the documented alert layout
(rule / agent / manager / data / full_log / location ...) so the Python helpers and their tests have
predictable input. Every alert carries "mini_siem_synthetic": true. Real alerts carry more fields
(e.g. compliance groups such as pci_dss, gdpr, nist_800_53) which the helpers simply ignore.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import scenarios as S  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"
LOCATION = "/var/log/mini-siem/synthetic_auth.log"
AGENT = {"id": "001", "name": S.HOST, "ip": "192.168.56.20"}

# Built-in rule metadata, as published in the Wazuh documentation / ruleset (compliance groups omitted)
BUILTIN = {
    "5710": ("sshd: Attempt to login using a non-existent user", ["syslog", "sshd", "invalid_login", "authentication_failed"], ["T1110"]),
    "5715": ("sshd: authentication success.", ["syslog", "sshd", "authentication_success"], ["T1078", "T1021"]),
    "5760": ("sshd: authentication failed.", ["syslog", "sshd", "authentication_failed"], ["T1110.001", "T1021.004"]),
    "5763": ("sshd: brute force trying to get access to the system. Authentication failed.", ["syslog", "sshd", "authentication_failures"], ["T1110"]),
}
CUSTOM = {
    "100101": ("Mini-SIEM: Repeated failed SSH logins (5 in 2 min) from {ip} - potential brute-force activity", ["ssh_brute_force", "ssh_failed_login", "ssh_repeated_failures"], ["T1110.001"]),
    "100102": ("Mini-SIEM: SSH logins attempted with several different non-existent usernames from {ip} - possible username enumeration", ["ssh_brute_force", "ssh_invalid_user", "ssh_multiple_user_attempts"], ["T1110", "T1087"]),
    "100103": ("Mini-SIEM: Failed SSH logins for several different accounts from {ip} - possible password spraying", ["ssh_brute_force", "ssh_multiple_user_attempts"], ["T1110.003"]),
    "100104": ("Mini-SIEM: Repeated failed SSH logins for root (3 in 5 min) from {ip} - suspicious privileged-account activity", ["ssh_brute_force", "ssh_root_login_attempt"], ["T1110.001", "T1078.003"]),
    "100105": ("Mini-SIEM: High volume of SSH authentication failures (15 in 5 min) from {ip} - sustained potential brute-force activity", ["ssh_brute_force", "ssh_high_volume_failures"], ["T1110.001"]),
    "100110": ("Mini-SIEM: Successful SSH login by {user} from {ip} after brute-force indicators from the same IP - investigate immediately", ["ssh_success_after_failures"], ["T1110", "T1078"]),
}


def _decode(message: str) -> dict:
    """Fields the sshd decoders extract (invalid user -> srcuser, existing user -> dstuser)."""
    parts = message.split()
    port = parts[parts.index("port") + 1]
    ip = parts[parts.index("from") + 1]
    if message.startswith("Invalid user"):
        return {"srcip": ip, "srcport": port, "srcuser": parts[2]}
    return {"srcip": ip, "srcport": port, "dstuser": parts[parts.index("for") + 1]}


def make_alert(step: S.Step, line: str, when: datetime, seq: int, fired: dict) -> dict:
    data = _decode(step.message)
    rid = step.expect_rule
    if rid in BUILTIN:
        desc, groups, mitre = BUILTIN[rid]
    else:
        desc, groups, mitre = CUSTOM[rid]
        desc = desc.format(ip=data["srcip"], user=data.get("dstuser", ""))
        groups = ["mini_siem", "syslog", "sshd"] + groups
    fired[rid] = fired.get(rid, 0) + 1
    return {
        "timestamp": when.strftime("%Y-%m-%dT%H:%M:%S.000+0000"),
        "rule": {"level": step.expect_level, "description": desc, "id": rid, "firedtimes": fired[rid],
                 "mail": False, "groups": groups, "mitre": {"id": mitre}},
        "agent": AGENT,
        "manager": {"name": "wazuh-server"},
        "id": f"{int(when.timestamp())}.{seq}",
        "full_log": line,
        "predecoder": {"program_name": "sshd", "timestamp": line[:15], "hostname": S.HOST},
        "decoder": {"parent": "sshd", "name": "sshd"},
        "data": data,
        "location": LOCATION,
        "mini_siem_synthetic": True,
    }


def scenario_alerts(keys, start: datetime, fired: dict, seq0: int = 0) -> list:
    out, seq = [], seq0
    t = start
    for key in keys:
        s = S.by_key(key)
        for i, step in enumerate(s.steps):
            when = t + timedelta(seconds=2 * i)
            line = S.syslog_line(step.message, when, pid=4200 + i)
            seq += 1
            out.append(make_alert(step, line, when, seq, fired))
        t += timedelta(minutes=10)
    return out


def extra_successes(start: datetime, fired: dict) -> list:
    """Additional normal logins (incl. loopback and IPv6) for the normal_authentication sample."""
    rows = [("bob", "192.168.56.1"), ("carol", "10.0.2.2"), ("alice", "::1"), ("dave", "2001:db8:56::25")]
    out = []
    for i, (user, ip) in enumerate(rows):
        when = start + timedelta(minutes=3 * (i + 1))
        msg = f"Accepted publickey for {user} from {ip} port {50300 + i} ssh2"
        step = S.Step(msg, "5715", 3)
        out.append(make_alert(step, S.syslog_line(msg, when, pid=4300 + i), when, 900 + i, fired))
    return out


def write_jsonl(path: Path, alerts: list) -> None:
    path.write_text("".join(json.dumps(a, separators=(",", ":")) + "\n" for a in alerts), encoding="utf-8")


def main() -> int:
    base = datetime(2026, 11, 6, 9, 0, 0, tzinfo=timezone.utc)
    (SAMPLES / "logs").mkdir(parents=True, exist_ok=True)
    for s in S.SCENARIOS:
        lines = S.scenario_lines(s, base.replace(tzinfo=None))
        (SAMPLES / "logs" / f"{s.key}.log").write_text("\n".join(lines) + "\n", encoding="utf-8")
    fired: dict = {}
    normal = scenario_alerts(["test1_normal_login"], base, fired) + extra_successes(base, fired)
    failed = scenario_alerts(["test2_one_failed_login", "test4a_multiple_invalid_usernames",
                              "test4b_multiple_existing_accounts", "test5_root_login_attempts"],
                             base + timedelta(hours=1), fired, 100)
    brute = scenario_alerts(["test3_repeated_failed_logins", "test5b_high_volume_failures",
                             "test5c_success_after_failures"], base + timedelta(hours=2), fired, 200)
    write_jsonl(SAMPLES / "normal_authentication.json", normal)
    write_jsonl(SAMPLES / "failed_login_events.json", failed)
    write_jsonl(SAMPLES / "brute_force_events.json", brute)
    print(f"logs: {len(S.SCENARIOS)} files; alerts: normal {len(normal)}, failed {len(failed)}, brute force {len(brute)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
