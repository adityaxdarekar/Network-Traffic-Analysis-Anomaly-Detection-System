#!/usr/bin/env python3
"""
export_alert_summary.py - turn exported Wazuh alerts into an investigation package:

  <out>/ip_summary.csv          one row per source IP (counts, usernames, first/last seen, rules, severity)
  <out>/username_summary.csv    one row per targeted username
  <out>/rule_summary.csv        alerts per rule ID / level
  <out>/auth_events.csv         every authentication alert (timestamp, rule, IP, user, full_log)
  <out>/investigation_report.md filled-in version of reports/report_template.md

Usage:
  python scripts/export_alert_summary.py samples/brute_force_events.json --out output/case-001 \
         --analyst "Your Name" --case "CASE-001"

Read-only towards Wazuh: it only reads an exported file. The output contains IP addresses and
usernames - keep it in a protected folder.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analyze_wazuh_alerts import Analysis, analyse, write_csv  # noqa: E402


def _md_table(frame, columns, max_rows=20) -> str:
    if frame.empty:
        return "_None._"
    f = frame[columns].head(max_rows)
    head = "| " + " | ".join(columns) + " |\n|" + "---|" * len(columns) + "\n"
    body = "".join("| " + " | ".join(str(v).replace("|", "\\|") for v in row) + " |\n" for row in f.itertuples(index=False))
    more = f"\n_{len(frame) - max_rows} more rows in the CSV._\n" if len(frame) > max_rows else ""
    return head + body + more


def render_report(a: Analysis, source: str, analyst: str = "", case: str = "") -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    highest = a.by_ip.iloc[0] if not a.by_ip.empty else None
    findings = []
    for row in a.by_ip.itertuples(index=False):
        if row.max_level >= 8 or row.correlation_rules:
            findings.append(f"- **{row.srcip}** ({row.ip_class}): {row.failed_events} failed events, "
                            f"{row.successful_logins} successful logins, {row.distinct_usernames} usernames; "
                            f"highest severity {row.max_severity} (level {row.max_level}). {row.review_note}.")
    sev = ", ".join(f"{k}: {v}" for k, v in a.severity.items())
    return f"""# Security Investigation Report - SSH Authentication Activity

| Field | Value |
|---|---|
| Case ID | {case or "-"} |
| Analyst | {analyst or "-"} |
| Generated | {now} |
| Data source | `{Path(source).name}` (exported Wazuh alerts) |
| Alerts read | {a.total_alerts} (authentication-related: {a.auth_alerts}) |

## 1. Summary
Severity distribution of authentication alerts: {sev}.
{"Highest-priority source: **" + str(highest.srcip) + "** - " + str(highest.review_note) + "." if highest is not None else "No authentication alerts found."}

## 2. Findings requiring review
{chr(10).join(findings) if findings else "_No source IP reached level 8 or triggered a correlation rule._"}

## 3. Source IP overview
{_md_table(a.by_ip, ["srcip", "ip_class", "failed_events", "successful_logins", "distinct_usernames", "first_seen", "last_seen", "max_level", "max_severity"])}

## 4. Targeted usernames
{_md_table(a.by_user, ["username", "failed_events", "successful_logins", "source_ips"])}

## 5. Detection rules involved
{_md_table(a.by_rule, ["rule_id", "rule_level", "rule_description", "alerts"])}

## 6. Recommended investigation steps
1. In the Wazuh dashboard, filter `data.srcip:<IP>` for the full timeline (all agents, all rules).
2. Check whether the IP belongs to a known system, administrator, scanner or NAT gateway.
3. For any successful login after failures: confirm with the account owner, review
   `last`/`lastlog` and the session's commands, and reset the password if the login was not expected.
4. Check whether password authentication is needed at all (key-based SSH, MFA, AllowUsers).
5. Document the decision: false positive, policy issue, or incident (escalate).

## 7. Notes and limitations
- Counts are Wazuh alerts. Repeated failures are **suspicious authentication behaviour**, not proof of an attack
  (forgotten passwords, misconfigured scripts and shared NAT addresses produce the same pattern).
- One failed SSH attempt can produce more than one log line; Wazuh counts log events.
- No IP was blocked and no external reputation service was queried.
- This report contains IP addresses and usernames - store and share it as sensitive data.
"""


def export(alerts_path: str, out_dir: str, analyst: str = "", case: str = "") -> dict:
    a = analyse(alerts_path)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    events = a.events.drop(columns=["ts"], errors="ignore")
    files = {
        "ip_summary": write_csv(a.by_ip, out / "ip_summary.csv"),
        "username_summary": write_csv(a.by_user, out / "username_summary.csv"),
        "rule_summary": write_csv(a.by_rule, out / "rule_summary.csv"),
        "auth_events": write_csv(events, out / "auth_events.csv"),
    }
    report = out / "investigation_report.md"
    report.write_text(render_report(a, alerts_path, analyst, case), encoding="utf-8")
    files["report"] = report
    return files


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Export CSV summaries and a Markdown investigation report.")
    p.add_argument("alerts", help="exported Wazuh alerts (JSON Lines / JSON array / indexer response)")
    p.add_argument("--out", default="output/report", help="output folder (default output/report)")
    p.add_argument("--analyst", default="")
    p.add_argument("--case", default="")
    args = p.parse_args(argv)
    if not Path(args.alerts).is_file():
        print(f"error: file not found: {args.alerts}", file=sys.stderr)
        return 2
    for name, path in export(args.alerts, args.out, args.analyst, args.case).items():
        print(f"{name:<17} {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
