"""
Synthetic SSH test scenarios - the single source of truth for:
  * samples/logs/*.log                      (paste into wazuh-logtest)
  * scripts/replay_synthetic_events.py      (append to the synthetic log file on the agent)
  * scripts/logtest_api_runner.py           (automated rule test on the manager)
  * the expected-results tables in the documentation

All events are SYNTHETIC. Addresses are private lab addresses (192.168.56.0/24, VirtualBox host-only)
and usernames are fictional. No real system, account or password is involved.

Expected rule IDs
  Built-in IDs (5710, 5715, 5760, 5763) come from the official Wazuh documentation and published
  ruleset; custom IDs (1001xx) come from wazuh/manager/custom_rules.xml. Nothing here has been run
  through a real Wazuh manager yet - wazuh-logtest on your manager is the authority. Wazuh numbers a
  frequency rule's alert on the Nth matching event (official example: the 8th "Invalid user" line
  produces 5712 with frequency 8).

Run each scenario in a NEW logtest session: the "ignore" timers and frequency counters are kept per
session, so a previous scenario could otherwise suppress or trigger rules.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

HOST = "lab-ubuntu-agent"


@dataclass
class Step:
    message: str                  # text after "sshd[pid]: "
    expect_rule: str              # expected final rule ID (string, as Wazuh reports it)
    expect_level: int
    note: str = ""


@dataclass
class Scenario:
    key: str
    title: str
    goal: str
    steps: list = field(default_factory=list)
    verified_basis: str = ""      # where the expectation comes from


def _failed(user: str, ip: str, port: int) -> str:
    return f"Failed password for {user} from {ip} port {port} ssh2"


def _invalid(user: str, ip: str, port: int) -> str:
    return f"Invalid user {user} from {ip} port {port}"


def _accepted(user: str, ip: str, port: int) -> str:
    return f"Accepted password for {user} from {ip} port {port} ssh2"


SCENARIOS: list[Scenario] = [
    Scenario(
        "test1_normal_login", "TEST 1 - Normal successful login",
        "A normal successful SSH login is recorded as an authentication-success event.",
        [Step(_accepted("alice", "192.168.56.1", 50122), "5715", 3, "sshd: authentication success")],
        "built-in rule 5715 (level 3)"),
    Scenario(
        "test2_one_failed_login", "TEST 2 - One failed login",
        "A single wrong password is recorded as a low-severity failure - not as an attack.",
        [Step(_failed("alice", "192.168.56.30", 50200), "5760", 5, "sshd: authentication failed")],
        "built-in rule 5760 (child of 5716)"),
    Scenario(
        "test3_repeated_failed_logins", "TEST 3 - Repeated failed logins (one account, one IP)",
        "5 failures in 2 minutes -> custom early warning; 8 failures -> built-in brute-force rule.",
        [Step(_failed("alice", "192.168.56.31", 51000 + i), *(
            ("100101", 8, "R1: 5th failure from the same IP within 120 s") if i == 4 else
            ("5763", 10, "built-in: 8th failure from the same IP within 120 s") if i == 7 else
            ("5760", 5, "single failure"))) for i in range(8)],
        "custom 100101 (frequency 5) and built-in 5763 (frequency 8)"),
    Scenario(
        "test4a_multiple_invalid_usernames", "TEST 4a - Several non-existent usernames from one IP",
        "Username enumeration: 4 different fictional usernames that do not exist on the system.",
        [Step(_invalid(u, "192.168.56.32", 52000 + i), *(
            ("100102", 10, "R2: 4th event with a username different from the earlier ones") if i == 3 else
            ("5710", 5, "attempt to log in with a non-existent user")))
         for i, u in enumerate(["admin", "test", "oracle", "guest"])],
        "built-in 5710 (decodes srcuser); custom 100102 (different_srcuser, frequency 4)"),
    Scenario(
        "test4b_multiple_existing_accounts", "TEST 4b - Several existing accounts from one IP",
        "Password spraying pattern: one wrong password each for 4 different (fictional) accounts.",
        [Step(_failed(u, "192.168.56.33", 53000 + i), *(
            ("100103", 10, "R2b: 4th failure, usernames differ") if i == 3 else
            ("5760", 5, "single failure")))
         for i, u in enumerate(["alice", "bob", "carol", "dave"])],
        "built-in 5760 (decodes dstuser = user); custom 100103 (different_user, frequency 4)"),
    Scenario(
        "test5_root_login_attempts", "TEST 5 - Repeated failed root logins",
        "Three failed password attempts for root from the same IP.",
        [Step(_failed("root", "192.168.56.34", 54000 + i), *(
            ("100104", 9, "R3: 3rd failed root login from the same IP within 300 s") if i == 2 else
            ("5760", 5, "single failure"))) for i in range(3)],
        "custom 100104 (same_user + <user>^root$</user>, frequency 3)"),
    Scenario(
        "test5b_high_volume_failures", "TEST 5b - High-volume authentication failures",
        "15 failures from one IP in a short time.",
        [Step(_failed("alice", "192.168.56.35", 55000 + i), *(
            ("100101", 8, "R1 at the 5th failure") if i == 4 else
            ("5763", 10, "built-in 5763 at the 8th failure") if i == 7 else
            ("100105", 12, "R4 at the 15th failure (see note on counting)") if i == 14 else
            ("5760", 5, "single failure"))) for i in range(15)],
        "custom 100105 (frequency 15). If the 15th line still shows 5760, Wazuh did not count the "
        "events that became 100101/5763 alerts - then R4 appears on the 16th/17th line."),
    Scenario(
        "test5c_success_after_failures", "TEST 5c - Successful login after repeated failures",
        "5 failures followed by a successful login from the same IP.",
        [Step(_failed("alice", "192.168.56.36", 56000 + i), *(
            ("100101", 8, "R1 at the 5th failure") if i == 4 else ("5760", 5, "single failure")))
         for i in range(5)] +
        [Step(_accepted("alice", "192.168.56.36", 56010), "100110", 14,
              "R5: success from an IP that triggered a brute-force indicator in the last 600 s")],
        "custom 100110 (if_sid 5715 + if_matched_group ssh_brute_force + same_srcip)"),
]


def by_key(key: str) -> Scenario:
    for s in SCENARIOS:
        if s.key == key:
            return s
    raise KeyError(f"unknown scenario {key!r}; choose from: {', '.join(s.key for s in SCENARIOS)}")


def syslog_line(message: str, when: datetime | None = None, host: str = HOST, pid: int = 4242) -> str:
    """Classic BSD-syslog line ("Nov  6 18:00:01 host sshd[pid]: ..."), the format used in the Wazuh
    documentation examples. (Ubuntu 24.04 may write real auth.log lines with ISO 8601 timestamps -
    check one real line with wazuh-logtest: Phase 1 must show program_name 'sshd'.)"""
    when = when or datetime.now()
    stamp = when.strftime("%b ") + f"{when.day:>2}" + when.strftime(" %H:%M:%S")
    return f"{stamp} {host} sshd[{pid}]: {message}"


def scenario_lines(s: Scenario, start: datetime, step_seconds: int = 2) -> list[str]:
    from datetime import timedelta
    return [syslog_line(st.message, start + timedelta(seconds=i * step_seconds), pid=4200 + i)
            for i, st in enumerate(s.steps)]
