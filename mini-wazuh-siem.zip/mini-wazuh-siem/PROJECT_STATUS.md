# Project status - what is implemented, what was verified, what you must do

## Built and verified in the build environment (executed)
| Item | Evidence |
|---|---|
| Custom rule file (6 rules, IDs 100101-100110) | `scripts/validate_rules.py` → OK: well-formed XML, IDs in the custom range and unique, documented options only, valid levels/frequency/timeframe ranges, parents limited to built-in 5710/5715/5760, if_matched_group defined, no self-trigger |
| Agent configuration example | well-formed, no duplicate locations, auth.log collected, FIM limited to the synthetic directory |
| Python helpers (analysis, export, replay, logtest runner, sample generator) | `pytest`: **91 tests passed**: parsing (4 formats, malformed lines), grouping, counting, IP classes, severity, CSV/report export, replay path safety, logtest runner against a mocked API |
| Sample data | 8 raw log scenario files and 3 synthetic alert files, consistent with the scenario definitions (tested) |

## Researched against official sources (not executed on Wazuh)
- Wazuh version 4.14.10 and the install commands (Quickstart, agent installation page)
- Required ports (architecture page)
- Custom rule range 100000-120000 (custom rules page)
- Rule options and their ranges (rules syntax page)
- `user` = alias of `dstuser` (decoders syntax page)
- Invalid-user line → 5710 with `srcuser`; 8th line → 5712 with frequency 8 (testing page)
- 5760/5763 definitions (Wazuh community thread quoting `0095-sshd_rules.xml`)
- The logtest API (testing page)
- Level classification (rules classification page)
- FIM rules 550/554
- The OpenSSH ≥ 9.8 decoder gap (GitHub issue #39954)

## Not verified - you must do this in VirtualBox
| Item | How | Record in |
|---|---|---|
| Wazuh installation, agent enrollment, dashboard access | `deployment/server_setup.md`, `deployment/agent_setup.md` | `documentation/VERIFIED_RESULTS.md` |
| `wazuh-analysisd -t` accepts custom_rules.xml | server_setup.md step 7 | VERIFIED_RESULTS.md |
| Expected rule IDs per scenario (especially R4 counting and R5 vs built-in 40112) | `scripts/logtest_api_runner.py` | VERIFIED_RESULTS.md |
| End-to-end alerts in the dashboard | replay script + saved searches | VERIFIED_RESULTS.md + screenshots |
| Dashboard visualizations | `wazuh/dashboards/dashboard_setup.md` | screenshots in `documentation/screenshots/` |
| FIM rule 553 and levels | `scripts/verify_installed_ruleset.sh` | VERIFIED_RESULTS.md |

Why not verified: the build environment had no virtualization support (no `/dev/kvm`), and its shell had no
internet access to download Wazuh packages or container images. Wazuh was therefore **not installed and no real
alert was generated** while building this package.
