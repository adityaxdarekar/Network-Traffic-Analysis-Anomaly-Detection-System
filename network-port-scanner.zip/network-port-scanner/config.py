"""
Central configuration for the Network Port Scanner and Service Detection System.

Everything a user may want to tune lives here. Changes made on the Settings
page are saved to ``user_settings.json`` and merged over these defaults.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
SCAN_DIR = OUTPUT_DIR / "scans"          # raw Nmap XML files
REPORT_DIR = OUTPUT_DIR / "reports"      # PDF reports
EXPORT_DIR = OUTPUT_DIR / "exports"      # CSV / TXT / XML exports
SCREENSHOT_DIR = BASE_DIR / "screenshots"
DB_PATH = OUTPUT_DIR / "scan_history.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"
PORT_REFERENCE_FILE = DATA_DIR / "common_ports.json"
VERSION_REFERENCE_FILE = DATA_DIR / "version_reference.json"

for _d in (OUTPUT_DIR, SCAN_DIR, REPORT_DIR, EXPORT_DIR, SCREENSHOT_DIR):
    _d.mkdir(parents=True, exist_ok=True)

APP_TITLE = "Network Port Scanner and Service Detection System"
APP_SHORT_TITLE = "PortSentinel"
APP_VERSION = "1.0.0"

SEVERITY_ORDER = ["Informational", "Low", "Medium", "High", "Critical"]
SEVERITY_COLORS = {
    "Informational": "#94a3b8",
    "Low": "#38bdf8",
    "Medium": "#facc15",
    "High": "#fb923c",
    "Critical": "#ef4444",
}
PORT_STATES = ["open", "closed", "filtered", "open|filtered", "closed|filtered", "unfiltered", "unknown"]

# ---------------------------------------------------------------------------
# Scan safety limits (see scanner/scan_engine.py)
# ---------------------------------------------------------------------------
DEFAULT_TARGET = "127.0.0.1"
MAX_PORTS_PER_SCAN = 65535
MAX_CIDR_HOSTS = 256              # a lab range may be at most a /24
DEFAULT_SCAN = {
    "profile": "tcp_connect",
    "ports": "1-1024",
    "timeout_sec": 300,           # whole scan is stopped after this
    "host_timeout_sec": 240,      # Nmap --host-timeout
    "timing": "T3",               # Nmap's normal timing template (T4 = faster, still polite on a LAN)
    "skip_host_discovery": True,  # -Pn: lab hosts often block ping
}
TIMEOUT_LIMITS = (10, 3600)

DEFAULT_SETTINGS = {
    "scan": copy.deepcopy(DEFAULT_SCAN),
    # Public (Internet) targets are blocked unless this is switched on in
    # Settings AND the user confirms authorisation for that scan.
    "allow_public_targets": False,
    # Ports the user expects to be open (e.g. their own web server). Findings
    # for these ports are reduced to Informational.
    "expected_open_ports": [],
    "many_open_ports_threshold": 15,
    "localhost_downgrade": True,  # services only reachable on 127.0.0.1 are less exposed
}


def default_settings() -> dict:
    return copy.deepcopy(DEFAULT_SETTINGS)


def load_settings(path: Path | None = None) -> dict:
    settings = default_settings()
    path = path or SETTINGS_FILE
    try:
        if path.exists():
            stored = json.loads(path.read_text(encoding="utf-8"))
            for key, value in stored.items():
                if isinstance(value, dict) and isinstance(settings.get(key), dict):
                    settings[key].update(value)
                elif key in settings:
                    settings[key] = value
    except (OSError, ValueError):
        pass   # a broken settings file must never stop the app
    return settings


def save_settings(settings: dict, path: Path | None = None) -> None:
    (path or SETTINGS_FILE).write_text(json.dumps(settings, indent=2), encoding="utf-8")
