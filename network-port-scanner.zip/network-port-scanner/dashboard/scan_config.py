"""Scan Configuration page: what each scan type does, default scan settings and the target policy."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from config import TIMEOUT_LIMITS, save_settings
from dashboard.common import get_settings, page_header, show_table
from scanner.scan_engine import ALLOWED_FLAGS, PROFILES, TIMING_CHOICES
from scanner.target_validator import parse_ports


def render() -> None:
    page_header("Scan Configuration", "Scan types, defaults and safety rules")
    settings = get_settings()

    st.subheader("Available scan types")
    show_table(pd.DataFrame([{"Scan type": p.name, "Nmap options": " ".join(p.nmap_args), "Example": p.example,
                              "Needs admin": "yes" if p.requires_admin else "no", "What it does": p.description}
                             for p in PROFILES.values()]))

    st.subheader("Default settings for new scans")
    d = settings["scan"]
    c1, c2, c3, c4 = st.columns(4)
    keys = list(PROFILES)
    profile = c1.selectbox("Default scan type", keys, index=keys.index(d.get("profile", "tcp_connect")),
                           format_func=lambda k: PROFILES[k].name, key="cfg_profile")
    ports = c2.text_input("Default ports", d["ports"], key="cfg_ports")
    timing = c3.selectbox("Default timing", TIMING_CHOICES, index=TIMING_CHOICES.index(d["timing"]), key="cfg_timing")
    timeout = c4.number_input("Default timeout (s)", TIMEOUT_LIMITS[0], TIMEOUT_LIMITS[1], int(d["timeout_sec"]),
                              key="cfg_timeout")
    skip = st.checkbox("Skip host discovery (-Pn) by default", bool(d["skip_host_discovery"]), key="cfg_skip")
    _, err = parse_ports(ports)
    if err:
        st.error(err)
    if st.button("💾 Save defaults", type="primary", disabled=bool(err)):
        settings["scan"].update(profile=profile, ports=ports, timing=timing, timeout_sec=int(timeout),
                                skip_host_discovery=skip)
        save_settings(settings)
        st.success("Defaults saved.")

    st.subheader("Safety rules built into the scanner")
    st.markdown(f"""
- **Targets:** localhost and private lab addresses (10.x, 172.16-31.x, 192.168.x, fc00::/7) are allowed.
  Public addresses are blocked unless enabled in *Settings* **and** confirmed for each scan
  (currently: **{'enabled' if settings['allow_public_targets'] else 'disabled'}**).
- **Ranges:** at most 256 addresses (a /24). Multicast, broadcast and reserved addresses are refused.
- **No shell:** Nmap is started directly with a fixed list of arguments - typed text can never run commands.
- **Allowlisted options only:** `{' '.join(sorted(ALLOWED_FLAGS))}`.
- **Never used:** stealth/evasion scans (-sS, -sN, -sF, -sX, -f, -D, spoofing), NSE scripts (`--script`),
  exploits or denial-of-service options.
- **Conservative timing:** -T3 by default (T4 max), `--max-retries 2`, a per-host timeout and an overall timeout
  that stops Nmap.
""")
