"""Shared dashboard helpers: state access, KPI cards, tables, charts, database access."""

from __future__ import annotations

import html

import pandas as pd
import plotly.express as px
import streamlit as st

from config import SEVERITY_COLORS, load_settings
from dashboard.theme import CHART_COLORS, plotly_layout
from database.db_manager import DatabaseError, DatabaseManager


def get_settings() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = load_settings()
    return st.session_state["settings"]


def get_result():
    return st.session_state.get("result")


def require_result():
    r = get_result()
    if r is None:
        st.info("No scan loaded yet. Run one on the **New Scan** page, import an Nmap XML file there, or open a "
                "previous scan from **Scan History**.")
        st.stop()
    return r


@st.cache_resource
def get_db() -> DatabaseManager | None:
    try:
        return DatabaseManager()
    except DatabaseError:
        return None


def db_or_warn() -> DatabaseManager | None:
    db = get_db()
    if db is None:
        st.error("The scan history database could not be opened (output/scan_history.db). Check that the folder is "
                 "writable; scanning still works but results will not be saved.")
    return db


def go_to(page: str) -> None:
    st.session_state["nav_target"] = page
    st.rerun()


def page_header(title: str, subtitle: str = "") -> None:
    r = get_result()
    pill = (f"<span class='soc-pill'>🎯 {html.escape(r.target)} · {html.escape(r.started_at or '')}</span>" if r
            else "<span class='soc-pill'>no scan loaded</span>")
    st.markdown(f"<div class='soc-header'><div><div class='title'>{html.escape(title)}</div>"
                f"<div class='subtitle'>{html.escape(subtitle)}</div></div><div>{pill}</div></div>",
                unsafe_allow_html=True)


def kpi_row(items: list[tuple]) -> None:
    cols = st.columns(len(items))
    for col, item in zip(cols, items):
        label, value, *rest = item           # (label, value[, sub-text[, style]])
        sub = rest[0] if rest else ""
        style = rest[1] if len(rest) > 1 else "accent"
        col.markdown(f"<div class='kpi {style}'><div class='label'>{html.escape(label)}</div>"
                     f"<div class='value'>{html.escape(str(value))}</div>"
                     f"<div class='sub'>{html.escape(str(sub or ''))}</div></div>", unsafe_allow_html=True)
    st.write("")


def severity_badge(sev: str) -> str:
    return f"<span class='sev sev-{html.escape(sev)}'>{html.escape(sev.upper())}</span>"


def show_table(df: pd.DataFrame, height: int | None = None, empty_msg: str = "Nothing to show.") -> None:
    if df is None or df.empty:
        st.caption(empty_msg)
        return
    kwargs = {"hide_index": True, "width": "stretch"}
    if height:
        kwargs["height"] = height
    st.dataframe(df, **kwargs)


def bar(df: pd.DataFrame, x: str, y: str, title: str, horizontal: bool = False, color: str | None = None,
        height: int = 330, color_map: dict | None = None):
    if df is None or df.empty or df[y].sum() == 0:
        st.caption(f"{title}: no data.")
        return
    kwargs = {"color_discrete_sequence": [color or CHART_COLORS[0]]}
    if color_map:
        kwargs = {"color": x, "color_discrete_map": color_map}
    if horizontal:
        fig = px.bar(df.iloc[::-1], x=y, y=x, orientation="h", **kwargs)
    else:
        fig = px.bar(df, x=x, y=y, **kwargs)
    fig.update_layout(showlegend=False)
    st.plotly_chart(plotly_layout(fig, title, height), width="stretch")


def donut(labels, values, title: str, colors: list[str] | None = None, height: int = 330):
    data = [(lab, v) for lab, v in zip(labels, values) if v]
    if not data:
        st.caption(f"{title}: no data.")
        return
    labs, vals = zip(*data)
    fig = px.pie(names=list(labs), values=list(vals), hole=0.55, color=list(labs),
                 color_discrete_map=dict(zip(labels, colors)) if colors else None,
                 color_discrete_sequence=CHART_COLORS)
    fig.update_traces(textinfo="value+percent", hovertemplate="%{label}: %{value:,}<extra></extra>")
    st.plotly_chart(plotly_layout(fig, title, height), width="stretch")


def severity_chart(counts: dict, title: str = "Findings by severity"):
    df = pd.DataFrame({"severity": list(counts), "findings": list(counts.values())})
    bar(df, "severity", "findings", title, color_map=SEVERITY_COLORS)


def download(label: str, data, filename: str, mime: str, key: str, primary: bool = False) -> None:
    if data is None or (hasattr(data, "__len__") and len(data) == 0):
        return
    kwargs = {"type": "primary"} if primary else {}
    st.download_button(label, data, file_name=filename, mime=mime, key=key, **kwargs)
