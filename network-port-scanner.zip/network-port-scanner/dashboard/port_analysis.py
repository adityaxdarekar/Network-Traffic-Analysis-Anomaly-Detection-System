"""Port Analysis page: every port Nmap reported, with search, filters and sorting."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from analyzer.port_analyzer import STATE_ORDER
from dashboard.common import download, kpi_row, page_header, require_result, show_table

STATE_HELP = {
    "Open": "a program accepted the connection",
    "Closed": "the host answered but nothing listens (connection refused)",
    "Filtered": "no answer - usually a firewall dropping the probe",
    "Open|Filtered": "Nmap could not tell whether it is open or filtered",
    "Unknown": "other Nmap states (closed|filtered, unfiltered)",
}


def render() -> None:
    page_header("Port Analysis", "Port numbers, protocols, states and services")
    r = require_result()
    c = r.state_counts
    kpi_row([("Ports scanned", f"{sum(c.values()):,}"), ("Open", c["Open"]), ("Closed", f"{c['Closed']:,}"),
             ("Filtered", f"{c['Filtered']:,}"), ("Open|Filtered", c["Open|Filtered"]), ("Unknown", c["Unknown"])])
    with st.expander("What do the states mean?"):
        for k, v in STATE_HELP.items():
            st.markdown(f"- **{k}** - {v}")
        st.markdown("Nmap lists 'interesting' ports one by one and only *counts* large groups of closed/filtered "
                    "ports, so the table can be shorter than the total.")

    df = r.ports
    if df.empty:
        st.info("Nmap did not list any port individually (e.g. every scanned port was closed).")
        return
    f1, f2, f3, f4 = st.columns([1.3, 1.6, 1, 1])
    states = f1.multiselect("State", STATE_ORDER, key="pa_state")
    search = f2.text_input("Search (port, service, product, version)", key="pa_search")
    hosts = sorted(df["host"].unique())
    host = f3.selectbox("Host", ["All"] + hosts, key="pa_host")
    sort = f4.selectbox("Sort by", ["port", "state", "service", "host"], key="pa_sort")
    view = df
    if states:
        view = view[view["state"].isin(states)]
    if host != "All":
        view = view[view["host"] == host]
    if search:
        q = search.strip().lower()
        hay = (view["port"].astype(str) + " " + view["service"] + " " + view["product"] + " " + view["version"]).str.lower()
        view = view[hay.str.contains(q, regex=False)]
    if sort == "state":
        view = view.assign(_o=view["state"].map(STATE_ORDER.index)).sort_values(["_o", "port"]).drop(columns="_o")
    else:
        view = view.sort_values([sort, "port"] if sort != "port" else ["port", "host"])
    st.markdown(f"**{len(view)}** of {len(df)} listed ports")
    cols = ["host", "port", "protocol", "state", "reason", "service", "product", "version", "extrainfo"]
    show_table(view[cols], height=420)
    download("⬇ Download ports (CSV)", view[cols].to_csv(index=False).encode(), f"ports_{r.scan_id}.csv", "text/csv",
             "dl_ports")
    if len(df["host"].unique()) > 1:
        st.markdown("**Per host**")
        show_table(pd.DataFrame(r.hosts))
