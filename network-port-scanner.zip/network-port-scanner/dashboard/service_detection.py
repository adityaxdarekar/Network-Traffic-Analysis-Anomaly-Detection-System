"""Service Detection page: services and versions on open ports, with a per-service investigation view."""

from __future__ import annotations

import html

import streamlit as st

from analyzer.service_analyzer import load_port_reference
from dashboard.common import donut, kpi_row, page_header, require_result, severity_badge, show_table


def render() -> None:
    page_header("Service Detection", "What is running on each open port, as identified by Nmap")
    r = require_result()
    sv, st_ = r.services, r.service_stats
    kpi_row([("Open services", len(sv)), ("Versions identified", st_.get("versions_identified", 0)),
             ("Confirmed by probing", st_.get("probed", 0)), ("Guessed from port", st_.get("guessed", 0)),
             ("Encrypted", st_.get("encrypted", 0))])
    if sv.empty:
        st.info("No open services in this scan.")
        return
    if st_.get("probed", 0) == 0:
        st.info("Service names were only guessed from port numbers. Use **Service & Version Detection** to have "
                "Nmap actually identify the software.")
    c1, c2 = st.columns(2)
    with c1:
        donut(list(st_["service_counts"]), list(st_["service_counts"].values()), "Services")
    with c2:
        donut(list(st_["category_counts"]), list(st_["category_counts"].values()), "Service categories")
    show_table(sv[["host", "port", "service", "product_version", "extrainfo", "identification", "confidence",
                   "encrypted", "category"]], height=320)

    st.divider()
    st.subheader("Investigate a service")
    options = [f"{x.host}:{x.port} - {x.service}" for x in sv.itertuples()]
    pick = st.selectbox("Service", options, key="sd_pick")
    row = sv.iloc[options.index(pick)]
    ref = load_port_reference().get(int(row["port"]), {})
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(f"""
**Host / port:** {row['host']} : {row['port']}/{row['protocol']}
**Service:** {row['service']}
**Product / version:** {row['product_version']}
**Extra information:** {row['extrainfo'] or '-'}
**Identification:** {row['identification']} (confidence {row['confidence'] if row['confidence'] == row['confidence'] else '-'}/10)
**Encrypted:** {'yes' if row['encrypted'] else 'no'}
**CPE:** {row['cpe'] or '-'}
""")
    with c2:
        if ref:
            st.markdown(f"**Reference:** {ref.get('service')} · {ref.get('category')}  \n"
                        f"**Why it matters:** {ref.get('risk')}  \n**Typical hardening:** {ref.get('mitigation')}")
        else:
            st.caption("This port is not in the port reference database (data/common_ports.json).")
    related = r.findings[(r.findings["host"] == row["host"]) & (r.findings["port"] == int(row["port"]))]
    for f in related.itertuples():
        st.markdown(f"{severity_badge(f.severity)} &nbsp; {html.escape(f.title)} <span class='muted'>"
                    f"({f.finding_id})</span>", unsafe_allow_html=True)
