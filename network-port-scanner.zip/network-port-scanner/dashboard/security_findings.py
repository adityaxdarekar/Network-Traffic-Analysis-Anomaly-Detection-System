"""Security Findings page."""

from __future__ import annotations

import html

import pandas as pd
import streamlit as st

from config import SEVERITY_ORDER
from dashboard.common import download, kpi_row, page_header, require_result, severity_badge, severity_chart, show_table


def render() -> None:
    page_header("Security Findings", "Rule-based exposure assessment - not confirmed vulnerabilities")
    r = require_result()
    fd, sev = r.findings, r.severity_counts
    kpi_row([(s, sev[s], "", "alert" if s in ("High", "Critical") and sev[s] else "accent")
             for s in reversed(SEVERITY_ORDER)])
    st.markdown("<div class='panel'>An open port is <b>not</b> automatically a vulnerability. Findings explain why a "
                "reachable service may matter and how to reduce the exposure. <b>Version observations</b> only mean "
                "the version Nmap reported is older than a reference version - vendors often backport fixes, so "
                "verify on the host. No CVEs are claimed.</div>", unsafe_allow_html=True)
    if fd.empty:
        st.success("No findings for this scan.")
        return
    c1, c2 = st.columns([1, 1.2])
    with c1:
        severity_chart(sev)
    with c2:
        t = fd["finding_type"].value_counts()
        show_table(pd.DataFrame({"finding type": t.index, "count": t.values}))

    f1, f2, f3 = st.columns(3)
    sev_f = f1.multiselect("Severity", list(reversed(SEVERITY_ORDER)), key="sf_sev")
    type_f = f2.multiselect("Type", sorted(fd["finding_type"].unique()), key="sf_type")
    q = f3.text_input("Search", key="sf_q")
    view = fd
    if sev_f:
        view = view[view["severity"].isin(sev_f)]
    if type_f:
        view = view[view["finding_type"].isin(type_f)]
    if q:
        view = view[(view["title"] + " " + view["service"] + " " + view["explanation"]).str.contains(q, case=False,
                                                                                                       regex=False)]
    show_table(view[["finding_id", "severity", "finding_type", "host", "port", "service", "observed_version", "title"]],
               height=280)
    download("⬇ Download findings (CSV)", fd.to_csv(index=False).encode(), f"findings_{r.scan_id}.csv", "text/csv",
             "dl_findings")

    for f in view.itertuples():
        port = "-" if pd.isna(f.port) else f.port
        with st.expander(f"{f.finding_id} · {f.severity} · {f.title}"):
            st.markdown(f"{severity_badge(f.severity)} &nbsp; <b>{html.escape(f.finding_type)}</b> "
                        f"<span class='muted'>rule {f.rule}</span>", unsafe_allow_html=True)
            c1, c2, c3 = st.columns(3)
            c1.markdown(f"**Host / port**  \n{f.host} : {port}")
            c2.markdown(f"**Service**  \n{f.service}")
            c3.markdown(f"**Observed version**  \n{f.observed_version}")
            st.markdown(f"**Explanation:** {f.explanation}")
            st.markdown(f"**Potential risk:** {f.risk}")
            st.markdown(f"**Evidence:** `{f.evidence}`")
            st.info(f"**Recommended mitigation:** {f.mitigation}")
