"""Reports page: PDF report, CSV / XML / TXT exports."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from dashboard.common import db_or_warn, download, page_header, require_result
from reports.export_manager import (export_filename, findings_csv, ports_csv, save_exports, services_csv,
                                    text_summary, xml_bytes, zip_bundle)
from reports.pdf_generator import generate_pdf_report


def render() -> None:
    page_header("Reports", "Download the scan as PDF, CSV, Nmap XML or a text summary")
    r = require_result()
    st.subheader("📄 PDF report")
    analyst = st.text_input("Prepared by (optional)")
    if st.button("Generate PDF report", type="primary"):
        with st.spinner("Building the report..."):
            try:
                path = generate_pdf_report(r, analyst=analyst)
                st.session_state["last_report"] = str(path)
                db = db_or_warn()
                if db:
                    db.add_report(r.scan_id, "pdf", str(path))
            except Exception as exc:  # noqa: BLE001
                st.error(f"Report generation failed: {exc}")
    last = st.session_state.get("last_report")
    if last and Path(last).exists():
        st.success(f"Saved to `{last}`")
        download("⬇ Download PDF", Path(last).read_bytes(), Path(last).name, "application/pdf", "dl_pdf", True)

    st.subheader("⬇ Data exports")
    c1, c2, c3 = st.columns(3)
    with c1:
        download("Ports (CSV)", ports_csv(r).encode(), export_filename("ports", r.target, "csv"), "text/csv", "dl_p")
        download("Services (CSV)", services_csv(r).encode(), export_filename("services", r.target, "csv"), "text/csv",
                 "dl_s")
    with c2:
        download("Findings (CSV)", findings_csv(r).encode(), export_filename("findings", r.target, "csv"), "text/csv",
                 "dl_f")
        download("Summary (TXT)", text_summary(r).encode(), export_filename("summary", r.target, "txt"), "text/plain",
                 "dl_t")
    with c3:
        xml = xml_bytes(r)
        if xml:
            download("Nmap XML (original)", xml, export_filename("nmap", r.target, "xml"), "application/xml", "dl_x")
        else:
            st.caption("Original Nmap XML file not found on disk.")
        download("Everything (ZIP)", zip_bundle(r), export_filename("scan", r.target, "zip"), "application/zip", "dl_z")
    if st.button("💾 Also save all exports to output/exports"):
        files = save_exports(r)
        st.success("Saved: " + ", ".join(p.name for p in files.values()))
    with st.expander("Preview the text summary"):
        st.code(text_summary(r), language=None)
