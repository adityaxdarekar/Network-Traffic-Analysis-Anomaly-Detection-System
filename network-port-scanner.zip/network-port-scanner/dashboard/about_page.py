"""About Project page."""

from __future__ import annotations

import streamlit as st

from config import APP_TITLE, APP_VERSION
from dashboard.common import page_header

ARCHITECTURE = """
 Streamlit dashboard (New Scan)
        │  target + scan type + ports
        ▼
 Target validator ── blocks public / multicast / oversized targets, checks characters
        │
 Scan engine ─────── fixed profiles → allowlisted arguments → subprocess (no shell) → Nmap
        │                                                         │
        │                                                   nmap -oX scan.xml
        ▼                                                         ▼
 XML parser ◄──────────────────────────────────────────── Nmap XML results
        │
 Port analyzer → Service analyzer → Risk analyzer (port reference + version reference)
        │
 SQLite history ── PDF / CSV / XML / TXT reports ── dashboard pages
"""


def render() -> None:
    page_header("About Project", APP_TITLE)
    st.markdown(f"**{APP_TITLE}** (v{APP_VERSION}) is a defensive tool for assessing machines you own or are "
                "authorised to test. Nmap does the real scanning; this application makes it safe to run, explains "
                "the results and documents them.")
    st.code(ARCHITECTURE, language=None)
    c1, c2 = st.columns(2)
    c1.markdown("""
**Technology**
- Python 3.11+
- Nmap (TCP connect scan, -sV, optional -O)
- XML parsing (defusedxml)
- pandas, Streamlit, Plotly
- SQLite, ReportLab, Matplotlib
""")
    c2.markdown("""
**Responsible use**
- Localhost by default; private lab ranges only
- Explicit authorisation confirmation
- No stealth, evasion, scripts or exploits
- Findings are exposure observations, not confirmed vulnerabilities
- No invented CVEs
""")
    st.info("Scanning networks without permission may be illegal. Use this tool only on systems you own or are "
            "explicitly authorised to test.")
