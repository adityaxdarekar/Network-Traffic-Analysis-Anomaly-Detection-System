"""Scan History page: list, open, compare and delete stored scans."""

from __future__ import annotations

import streamlit as st

from analyzer.assessment import result_from_history
from dashboard.common import db_or_warn, get_settings, go_to, page_header, show_table
from database.db_manager import DatabaseError


def render() -> None:
    page_header("Scan History", "Previous scans stored in SQLite")
    db = db_or_warn()
    if db is None:
        return
    try:
        scans = db.list_scans()
    except DatabaseError as exc:
        st.error(str(exc))
        return
    if scans.empty:
        st.info("No scans stored yet.")
        return
    show_table(scans.drop(columns=["severity_json"]), height=300)
    label = {r.scan_id: f"{r.started_at} · {r.target} · {r.scan_type} ({r.open_ports} open)" for r in scans.itertuples()}
    ids = list(label)

    st.subheader("Open a scan")
    pick = st.selectbox("Scan", ids, format_func=label.get, key="sh_pick")
    c1, c2, _ = st.columns([1, 1, 3])
    if c1.button("📂 Load into dashboard", key="sh_load"):
        record = db.get_scan(pick)
        try:
            st.session_state["result"] = result_from_history(record, get_settings())
            go_to("Dashboard Overview")
        except ValueError as exc:
            st.warning(str(exc))
            show_table(record["ports"])
    if c2.button("🗑 Delete", key="sh_delete"):
        db.delete_scan(pick)
        current = st.session_state.get("result")
        if current is not None and current.scan_id == pick:
            st.session_state.pop("result")
        st.rerun()

    st.subheader("Compare two scans")
    if len(ids) < 2:
        st.caption("Run at least two scans to compare them.")
        return
    c1, c2 = st.columns(2)
    old = c1.selectbox("Earlier scan", ids, index=1, format_func=label.get, key="sh_old")
    new = c2.selectbox("Later scan", ids, index=0, format_func=label.get, key="sh_new")
    if old == new:
        st.caption("Choose two different scans.")
        return
    diff = db.compare_scans(old, new)
    if diff.empty:
        st.success("No differences in the ports Nmap listed.")
    else:
        st.markdown(f"**{len(diff)} change(s)** - newly open ports deserve attention; "
                    "'no longer open' usually confirms a fix.")
        show_table(diff)
