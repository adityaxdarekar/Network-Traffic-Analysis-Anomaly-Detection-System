"""Dashboard Overview: totals across all stored scans plus charts for the current scan."""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from analyzer.port_analyzer import STATE_ORDER
from dashboard.common import bar, db_or_warn, donut, get_result, kpi_row, page_header, severity_chart
from dashboard.theme import BLUE, CYAN, plotly_layout

STATE_COLORS = ["#3b82f6", "#64748b", "#f59e0b", "#a78bfa", "#94a3b8"]


def render() -> None:
    page_header("Dashboard Overview", "All scans in the history database, and the scan currently loaded")
    db = db_or_warn()
    totals = db.totals() if db else {"scans": 0, "open": 0, "closed": 0, "filtered": 0, "services": 0, "findings": 0}
    st.markdown("##### All scans")
    kpi_row([("Total scans", totals["scans"]), ("Open ports", totals["open"]), ("Closed ports", f"{totals['closed']:,}"),
             ("Filtered ports", f"{totals['filtered']:,}"), ("Services detected", totals["services"]),
             ("Security findings", totals["findings"], "", "alert" if totals["findings"] else "accent")])

    if db and totals["scans"]:
        trend = db.history_trend()
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=trend["started_at"], y=trend["open_ports"], mode="lines+markers", name="open ports",
                                 line=dict(color=CYAN)))
        fig.add_trace(go.Scatter(x=trend["started_at"], y=trend["findings"], mode="lines+markers", name="findings",
                                 line=dict(color="#fb923c")))
        st.plotly_chart(plotly_layout(fig, "Scan history", 260), width="stretch")

    r = get_result()
    if r is None:
        st.info("Run a scan on the **New Scan** page (localhost is the safe default) to see detailed charts.")
        return
    st.markdown(f"##### Current scan · {r.target} · {r.profile}")
    c1, c2 = st.columns(2)
    with c1:
        counts = r.state_counts
        donut(list(counts), list(counts.values()), "Open vs closed vs filtered ports", STATE_COLORS)
    with c2:
        op = r.open_ports
        if op.empty:
            st.caption("Port distribution: no open ports.")
        else:
            d = op.assign(label=op["port"].astype(str) + "/" + op["service"].replace("", "unknown"))
            d = d.groupby("label", sort=False).size().reset_index(name="hosts")
            bar(d, "label", "hosts", "Open port distribution", color=BLUE)
    c3, c4 = st.columns(2)
    with c3:
        sc = r.service_stats.get("service_counts", {})
        bar(pd.DataFrame({"service": list(sc), "ports": list(sc.values())}), "service", "ports",
            "Service distribution", horizontal=True, color=CYAN)
    with c4:
        severity_chart(r.severity_counts, "Security finding severity")
    if r.parsed.hosts and len(r.parsed.hosts) > 1:
        st.markdown("**Hosts in this scan**")
        st.dataframe(r.hosts, hide_index=True, width="stretch")
    st.caption("States: " + ", ".join(f"{k} {r.state_counts[k]:,}" for k in STATE_ORDER))
