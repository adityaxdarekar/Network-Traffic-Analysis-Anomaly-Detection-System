"""New Scan page: target, scan type, ports, start/stop, live status, results; plus Nmap XML import."""

from __future__ import annotations

import time
import uuid

import streamlit as st

from analyzer.assessment import result_from_job, result_from_xml
from config import DEFAULT_TARGET, SCAN_DIR, TIMEOUT_LIMITS
from dashboard.common import db_or_warn, get_result, get_settings, go_to, kpi_row, page_header, show_table
from scanner.nmap_manager import get_nmap_info
from scanner.scan_engine import PROFILES, TIMING_CHOICES, TOP_PORT_CHOICES, ScanConfigError, ScanJob, build_config
from scanner.target_validator import validate_target


@st.cache_data(ttl=120, show_spinner=False)
def nmap_info():
    return get_nmap_info()


def _store(result) -> None:
    st.session_state["result"] = result
    st.session_state.pop("last_report", None)
    db = db_or_warn()
    if db is not None:
        try:
            db.save_scan(result)
        except Exception as exc:  # noqa: BLE001 - history is optional
            st.warning(f"Scan finished but could not be saved to history: {exc}")


def _result_summary(r) -> None:
    s = r.summary
    kpi_row([("Ports scanned", f"{s['total_ports']:,}"), ("Open", s["open"]), ("Closed", f"{s['closed']:,}"),
             ("Filtered", f"{s['filtered']:,}"), ("Services", s["services"]),
             ("Findings", s["findings"], f"{s['sev_high'] + s['sev_critical']} high/critical",
              "alert" if s["sev_high"] + s["sev_critical"] else "accent")])
    for w in r.warnings:
        st.warning(w)
    st.markdown("**Open ports**")
    show_table(r.open_ports[["host", "port", "protocol", "service", "product", "version", "extrainfo"]],
               empty_msg="No open ports were found.")
    c1, c2, _ = st.columns([1, 1, 2])
    if c1.button("🔎 Port Analysis", key="go_ports"):
        go_to("Port Analysis")
    if c2.button("🛡 Security Findings", key="go_findings"):
        go_to("Security Findings")


def render() -> None:
    page_header("New Scan", "Scan authorised lab machines with Nmap")
    settings = get_settings()
    info = nmap_info()
    if info.installed:
        st.caption(f"✅ Nmap {info.version} found at `{info.path}`"
                   f"{'' if info.in_path else ' (not on PATH - found in the default install folder)'} · "
                   f"administrator: {'yes' if info.is_admin else 'no'}")
    else:
        st.error(f"❌ {info.error}  \nYou can still analyse an existing Nmap XML file with **Import** below.")

    st.warning("⚠️ Only scan computers you own or have explicit permission to test. By default only localhost and "
               "private lab addresses are allowed.")

    job: ScanJob | None = st.session_state.get("scan_job")
    running = bool(job and job.is_running())
    defaults = settings["scan"]

    c1, c2 = st.columns([1.3, 1])
    target_raw = c1.text_input("Target IP address, hostname or lab range", value=DEFAULT_TARGET, disabled=running,
                               help="Examples: 127.0.0.1 · localhost · 192.168.56.101 · 192.168.56.0/28")
    profile_keys = list(PROFILES)
    profile = c2.selectbox("Scan type", profile_keys, format_func=lambda k: PROFILES[k].name,
                           index=profile_keys.index(defaults.get("profile", "tcp_connect")), disabled=running)
    prof = PROFILES[profile]
    st.caption(f"ℹ️ {prof.description}  Equivalent command: `{prof.example}`")
    if prof.requires_admin and not info.is_admin:
        st.warning("OS detection needs the app to run as Administrator. Start the terminal with 'Run as "
                   "administrator', or choose another scan type.")

    c3, c4, c5, c6 = st.columns([1.4, 1, 1, 1])
    if prof.uses_port_list:
        ports = c3.text_input("Ports", value="22,80,443,3306,3389" if prof.requires_ports else defaults["ports"],
                              disabled=running, help="Single ports and ranges, e.g. 22,80,443 or 1-1024")
        top_ports = 100
    else:
        ports = ""
        top_ports = c3.selectbox("Most common ports", TOP_PORT_CHOICES, index=1, disabled=running)
    timing = c4.selectbox("Timing", TIMING_CHOICES, index=TIMING_CHOICES.index(defaults.get("timing", "T3")),
                          disabled=running, help="T2 = polite/slow, T3 = normal, T4 = faster (LAN)")
    timeout = c5.number_input("Timeout (s)", TIMEOUT_LIMITS[0], TIMEOUT_LIMITS[1], int(defaults["timeout_sec"]),
                              disabled=running)
    skip = c6.checkbox("Skip ping (-Pn)", value=bool(defaults["skip_host_discovery"]), disabled=running,
                       help="Treat the host as up even if it does not answer ping (common for lab VMs).")

    # ---- validation ------------------------------------------------------
    check = validate_target(target_raw, allow_public=settings["allow_public_targets"], authorized=False)
    needs_auth = check.scope in ("private", "public")
    authorized = False
    if check.scope == "public" and settings["allow_public_targets"]:
        authorized = st.checkbox("I have WRITTEN permission from the owner to scan this public address.",
                                 disabled=running)
        check = validate_target(target_raw, allow_public=True, authorized=authorized)
    elif check.ok and needs_auth:
        authorized = st.checkbox("I own this machine/network or am authorised to scan it.", disabled=running)
    if check.ok:
        st.success(f"Target OK: {check.target} - {check.message}")
    else:
        st.error(f"Target not allowed: {check.message}")

    can_start = check.ok and info.installed and not running and (authorized or not needs_auth)
    b1, b2, _ = st.columns([1, 1, 3])
    if b1.button("▶ Start scan", type="primary", disabled=not can_start):
        try:
            cfg = build_config(check, profile, ports, top_ports, timing, timeout, skip_host_discovery=skip)
            job = ScanJob(cfg).start()
            st.session_state["scan_job"] = job
            st.session_state["scan_saved"] = None
            st.rerun()
        except ScanConfigError as exc:
            st.error(f"❌ {exc}")
    if b2.button("■ Stop scan", disabled=not running):
        job.stop()
        st.rerun()

    # ---- status ------------------------------------------------------------
    if job is not None:
        status = job.status()
        st.markdown(f"**Status:** {status['state'].upper()} · {status['phase']} · {status['elapsed_sec']:.0f}s elapsed")
        if status["command"]:
            st.code(status["command"], language=None)
        if status["state"] == "running":
            st.progress(status["progress"] / 100, text=f"{status['progress']:.0f}% (Nmap's estimate)")
            if status["last_lines"]:
                st.caption(status["last_lines"][-1])
            time.sleep(1)
            st.rerun()
        else:
            if status["error"]:
                (st.warning if status["state"] in ("stopped", "timeout") else st.error)(status["error"])
            if job.result is not None and st.session_state.get("scan_saved") != job.scan_id:
                try:
                    _store(result_from_job(job, settings))
                    st.session_state["scan_saved"] = job.scan_id
                except ValueError as exc:
                    st.error(str(exc))
            current = get_result()
            if current is not None and current.scan_id == job.scan_id:
                _result_summary(current)

    # ---- import -------------------------------------------------------------
    st.divider()
    st.subheader("Import an existing Nmap XML file")
    st.caption("Already ran Nmap yourself (e.g. `nmap -sT -sV -oX lab.xml 192.168.56.101`)? Import the XML to "
               "analyse it here. The file is parsed safely and is not executed.")
    upload = st.file_uploader("Nmap XML file", type=["xml"])
    if upload is not None and st.session_state.get("imported_id") != upload.file_id:
        dest = SCAN_DIR / f"import_{uuid.uuid4().hex[:8]}.xml"
        dest.write_bytes(upload.getbuffer())
        try:
            result = result_from_xml(dest, settings)
            _store(result)
            st.session_state["imported_id"] = upload.file_id
            st.success(f"Imported {upload.name}: {len(result.parsed.hosts)} host(s).")
            _result_summary(result)
        except Exception as exc:  # noqa: BLE001 - any parse problem is shown to the user
            dest.unlink(missing_ok=True)
            st.error(f"❌ Could not import this file: {exc}")
