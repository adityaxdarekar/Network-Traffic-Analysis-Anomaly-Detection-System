"""Settings page: target policy, risk-assessment options and the reference databases."""

from __future__ import annotations

import json

import pandas as pd
import streamlit as st

from analyzer.assessment import build_result
from analyzer.risk_analyzer import load_version_rules
from analyzer.service_analyzer import load_port_reference
from config import PORT_REFERENCE_FILE, VERSION_REFERENCE_FILE, default_settings, save_settings
from dashboard.common import get_result, get_settings, page_header, show_table
from scanner.target_validator import parse_ports


def render() -> None:
    page_header("Settings", "Safety policy and risk-assessment options")
    settings = get_settings()

    st.subheader("Target policy")
    allow = st.toggle("Allow public (Internet) targets - each scan still requires a written-permission confirmation",
                      value=bool(settings["allow_public_targets"]), key="set_public")
    if allow:
        st.warning("Scanning systems without permission may be illegal. Keep this off unless you have written "
                   "authorisation for a specific public system.")

    st.subheader("Risk assessment")
    expected_text = st.text_input("Expected open ports (comma separated) - findings on these become Informational",
                                  ", ".join(map(str, settings["expected_open_ports"])), key="set_expected")
    c1, c2 = st.columns(2)
    threshold = c1.number_input("Open ports on one host before an 'attack surface' finding", 2, 500,
                                int(settings["many_open_ports_threshold"]), key="set_many")
    downgrade = c2.toggle("Lower severity one level for services seen only on localhost",
                          value=bool(settings["localhost_downgrade"]), key="set_down")
    expected, err = [], None
    if expected_text.strip():
        ranges, err = parse_ports(expected_text)
        expected = sorted({p for a, b in ranges for p in range(a, b + 1)})[:1000]
    if err:
        st.error(err)

    b1, b2 = st.columns([1, 1])
    if b1.button("💾 Save settings", type="primary", disabled=bool(err)):
        settings.update(allow_public_targets=allow, expected_open_ports=expected,
                        many_open_ports_threshold=int(threshold), localhost_downgrade=downgrade)
        save_settings(settings)
        r = get_result()
        if r is not None:      # re-run the assessment on the loaded scan with the new options
            st.session_state["result"] = build_result(
                r.parsed, scan_id=r.scan_id, target=r.target, profile=r.profile, scan_config=r.scan_config,
                command=r.command, nmap_version=r.nmap_version, xml_path=r.xml_path, status=r.status, error=r.error,
                settings=settings)
        st.success("Settings saved" + (" and findings recalculated." if r is not None else "."))
    if b2.button("↺ Reset to defaults"):
        st.session_state["settings"] = default_settings()
        save_settings(st.session_state["settings"])
        for k in [k for k in st.session_state if k.startswith("set_")]:
            del st.session_state[k]
        st.rerun()

    st.subheader("Port reference database")
    st.caption(f"Edit `{PORT_REFERENCE_FILE.relative_to(PORT_REFERENCE_FILE.parent.parent)}` to change severities, "
               "risks or mitigations, then restart the app. Severity = exposure level when the port is open.")
    ref = load_port_reference()
    show_table(pd.DataFrame([{"port": p, **v} for p, v in sorted(ref.items())]), height=300)
    st.subheader("Version reference (observations only)")
    st.caption(f"`{VERSION_REFERENCE_FILE.name}` - a match is a version observation, never a confirmed vulnerability.")
    show_table(pd.DataFrame(load_version_rules()))
    with st.expander("Raw settings"):
        st.code(json.dumps(settings, indent=2), language="json")
