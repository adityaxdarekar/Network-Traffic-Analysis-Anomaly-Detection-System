"""
Headless smoke test of all dashboard pages (Streamlit/Plotly replaced by stand-ins
from tests/streamlit_stub.py), including a full New Scan run with the stand-in Nmap.
"""

from __future__ import annotations

import importlib

import pytest

from tests import streamlit_stub as stub
from tests.conftest import FAKE_NMAP

PAGES = ["Dashboard Overview", "New Scan", "Scan Configuration", "Port Analysis", "Service Detection",
         "Security Findings", "Scan History", "Reports", "Settings", "About Project"]
EXPECTED_ERRORS = ("Nmap was not found", "Target not allowed")


@pytest.fixture
def app(tmp_path, monkeypatch):
    stub.install()
    import config
    monkeypatch.setattr(config, "SETTINGS_FILE", tmp_path / "settings.json")
    application = importlib.import_module("app")
    import dashboard.common as common
    import dashboard.new_scan as ns
    import reports.pdf_generator as pg
    from database.db_manager import DatabaseManager
    from scanner import scan_engine
    db = DatabaseManager(tmp_path / "db.sqlite")
    monkeypatch.setattr(common, "get_db", lambda: db)
    monkeypatch.setattr(pg, "REPORT_DIR", tmp_path)
    monkeypatch.setattr(ns, "SCAN_DIR", tmp_path)

    class TestJob(scan_engine.ScanJob):
        def __init__(self, cfg):
            super().__init__(cfg, nmap_cmd=FAKE_NMAP)

        def start(self, output_dir=tmp_path):
            return super().start(output_dir)
    monkeypatch.setattr(ns, "ScanJob", TestJob)
    st = stub._module
    st.session_state.clear()
    stub.StubState.press, stub.StubState.inputs, stub.StubState.calls = set(), {}, []
    return application, st, db


def run_page(application, st, page):
    st.session_state["nav"] = page
    try:
        application.main()
    except (stub.StopException, stub.RerunException):
        pass
    errors = [c for c in stub.StubState.calls if c[0] in ("error", "exception")
              and not any(e in str(c[1]) for e in EXPECTED_ERRORS)]
    stub.StubState.calls = []
    return errors


def load(st, fixture_path, name):
    from analyzer.assessment import result_from_xml
    st.session_state["result"] = result_from_xml(fixture_path(name))


def test_pages_without_scan(app):
    application, st, _ = app
    for page in PAGES:
        assert run_page(application, st, page) == [], page


@pytest.mark.parametrize("name", ["lab_risky.xml", "localhost_service.xml", "no_open_ports.xml", "host_down.xml",
                                  "multi_host.xml"])
def test_pages_with_scan(app, fixture_path, name):
    application, st, db = app
    load(st, fixture_path, name)
    db.save_scan(st.session_state["result"])
    for page in PAGES:
        assert run_page(application, st, page) == [], page


def test_filters(app, fixture_path):
    application, st, _ = app
    load(st, fixture_path, "lab_risky.xml")
    stub.StubState.inputs = {"pa_state": ["Open"], "pa_search": "sql", "pa_sort": "state", "sf_sev": ["High"],
                             "sf_type": ["Unencrypted service"], "sf_q": "telnet"}
    for page in ("Port Analysis", "Security Findings", "Service Detection"):
        assert run_page(application, st, page) == [], page


def test_new_scan_full_flow(app, monkeypatch):
    """Start a scan from the UI with the stand-in Nmap, let it finish, results are stored and shown."""
    import dashboard.new_scan as ns
    from scanner.nmap_manager import get_nmap_info
    monkeypatch.setattr(ns, "nmap_info", lambda: get_nmap_info(FAKE_NMAP))
    application, st, db = app
    stub.StubState.press = {"▶ Start scan"}
    assert run_page(application, st, "New Scan") == []
    job = st.session_state["scan_job"]
    job.wait(10)
    stub.StubState.press = set()
    assert run_page(application, st, "New Scan") == []
    assert job.state == "completed"
    assert st.session_state["result"].scan_id == job.scan_id
    assert len(db.list_scans()) == 1
    stub.StubState.press = {"Generate PDF report"}
    assert run_page(application, st, "Reports") == []
    assert st.session_state["last_report"].endswith(".pdf")


def test_private_target_requires_confirmation(app, monkeypatch):
    import dashboard.new_scan as ns
    from scanner.nmap_manager import get_nmap_info
    monkeypatch.setattr(ns, "nmap_info", lambda: get_nmap_info(FAKE_NMAP))
    application, st, _ = app
    stub.StubState.inputs = {"Target IP address, hostname or lab range": "192.168.56.20"}
    stub.StubState.press = {"▶ Start scan"}
    run_page(application, st, "New Scan")
    assert "scan_job" not in st.session_state                       # button disabled without confirmation
    stub.StubState.inputs["I own this machine/network or am authorised to scan it."] = True
    run_page(application, st, "New Scan")
    assert st.session_state["scan_job"].config.target.target == "192.168.56.20"


def test_public_target_blocked(app, monkeypatch):
    import dashboard.new_scan as ns
    from scanner.nmap_manager import get_nmap_info
    monkeypatch.setattr(ns, "nmap_info", lambda: get_nmap_info(FAKE_NMAP))
    application, st, _ = app
    stub.StubState.inputs = {"Target IP address, hostname or lab range": "8.8.8.8"}
    stub.StubState.press = {"▶ Start scan"}
    run_page(application, st, "New Scan")
    assert "scan_job" not in st.session_state


def test_import_xml(app, fixture_path):
    application, st, db = app

    class Upload:
        name, file_id = "lab.xml", "u1"

        def getbuffer(self):
            return memoryview(fixture_path("lab_risky.xml").read_bytes())
    stub.StubState.inputs = {"Nmap XML file": Upload()}
    assert run_page(application, st, "New Scan") == []
    assert st.session_state["result"].summary["open"] == 16 and len(db.list_scans()) == 1


def test_invalid_import_rejected(app):
    application, st, _ = app

    class Upload:
        name, file_id = "evil.xml", "u2"

        def getbuffer(self):
            return memoryview(b"<?xml version='1.0'?><!DOCTYPE x [<!ENTITY a 'b'>]><nmaprun>&a;</nmaprun>")
    stub.StubState.inputs = {"Nmap XML file": Upload()}
    errs = run_page(application, st, "New Scan")
    assert errs and "entity" in str(errs[0][1]) and "result" not in st.session_state


def test_settings_recalculates_findings(app, fixture_path):
    application, st, _ = app
    load(st, fixture_path, "lab_risky.xml")
    run_page(application, st, "Dashboard Overview")
    stub.StubState.inputs = {"set_expected": "23, 2375"}
    stub.StubState.press = {"💾 Save settings"}
    assert run_page(application, st, "Settings") == []
    f = st.session_state["result"].findings
    assert f[f["port"] == 2375].iloc[0]["severity"] == "Informational"
