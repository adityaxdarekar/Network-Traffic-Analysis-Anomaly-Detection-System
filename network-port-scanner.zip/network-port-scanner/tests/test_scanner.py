"""Nmap detection, target validation, safe command building and the scan engine."""

from __future__ import annotations

import socket
import time

import pytest

from analyzer.assessment import result_from_job
from scanner import nmap_manager
from scanner.scan_engine import (PROFILES, ScanConfigError, ScanJob, build_arguments, build_config, run_scan,
                                 validate_arguments)
from scanner.target_validator import count_ports, normalise_ports, parse_ports, validate_target
from tests.conftest import FAKE_NMAP, requires_nmap


def no_dns(name):
    return {"localhost": ["127.0.0.1"], "labvm.local": ["192.168.56.101"], "public.example": ["8.8.8.8"],
            "mixed.example": ["192.168.1.5", "8.8.4.4"]}.get(name, [])


# ---------------------------------------------------------------- 1. Nmap installation detection
def test_detects_nmap_via_stand_in():
    info = nmap_manager.get_nmap_info(FAKE_NMAP)
    assert info.installed and info.version == "7.95"


def test_missing_nmap_is_reported(monkeypatch):
    monkeypatch.setattr(nmap_manager, "find_nmap", lambda: (None, False))
    info = nmap_manager.get_nmap_info()
    assert not info.installed and "not found" in info.error and not info.can_os_detect


def test_parse_version():
    assert nmap_manager.parse_version("Nmap version 7.95 ( https://nmap.org )\nPlatform: x86_64") == "7.95"
    assert nmap_manager.parse_version("Nmap version 7.94SVN ( https://nmap.org )") == "7.94SVN"
    assert nmap_manager.parse_version("garbage") is None


def test_nmap_path_environment_variable(monkeypatch, tmp_path):
    exe = tmp_path / "nmap.exe"
    exe.write_text("")
    monkeypatch.setenv("NMAP_PATH", str(exe))
    assert nmap_manager.find_nmap() == (str(exe), False)


# ---------------------------------------------------------------- 2. Target validation
@pytest.mark.parametrize("target,ok,scope", [
    ("127.0.0.1", True, "loopback"), ("::1", True, "loopback"), ("localhost", True, "loopback"),
    ("192.168.56.101", True, "private"), ("10.0.0.5", True, "private"), ("172.16.3.4", True, "private"),
    ("fd00::5", True, "private"), ("192.168.56.0/24", True, "private"), ("labvm.local", True, "private"),
    ("8.8.8.8", False, "public"), ("public.example", False, "public"), ("mixed.example", False, "public"),
    ("0.0.0.0", False, "blocked"), ("224.0.0.1", False, "blocked"), ("255.255.255.255", False, "blocked"),
    ("203.0.113.9", False, "blocked"),
])
def test_target_scopes(target, ok, scope):
    c = validate_target(target, resolver=no_dns)
    assert c.ok is ok and c.scope == scope


@pytest.mark.parametrize("bad", ["", "   ", "127.0.0.1; rm -rf /", "127.0.0.1 -oN x", "-sS", "$(whoami)",
                                 "a" * 300, "10.0.0.0/8", "192.168.0.0/23", "not_a_host!", "unknown.invalid",
                                 "127.0.0.1\n8.8.8.8", "../../etc/passwd"])
def test_invalid_targets_rejected(bad):
    assert not validate_target(bad, resolver=no_dns).ok


def test_public_target_needs_setting_and_confirmation():
    assert "blocked by default" in validate_target("8.8.8.8").message
    c = validate_target("8.8.8.8", allow_public=True)
    assert not c.ok and c.needs_authorization
    assert validate_target("8.8.8.8", allow_public=True, authorized=True).ok


def test_port_parsing():
    ranges, err = parse_ports("443, 22,80,1-1024,8080")
    assert err is None and normalise_ports(ranges) == "1-1024,8080" and count_ports(ranges) == 1025
    for bad in ("", "0", "70000", "80-20", "22;ls", "a-b", "1-", ",".join(["1"] * 101)):
        assert parse_ports(bad)[1], bad


# ---------------------------------------------------------------- safe command building
def test_arguments_are_allowlisted(tmp_path):
    for key, prof in PROFILES.items():
        cfg = build_config(validate_target("127.0.0.1"), key, "22,80" if prof.uses_port_list else "", 100)
        args = build_arguments(cfg, tmp_path / "x.xml")
        assert args[-1] == "127.0.0.1" and "-sT" in args and "-oX" in args
        assert not any(a.startswith("--script") or a in ("-sS", "-sU", "-f", "-D") for a in args)
    cfg = build_config(validate_target("192.168.56.0/28"), "tcp_connect", "22")
    assert "-Pn" not in build_arguments(cfg, tmp_path / "y.xml")   # ranges keep host discovery


@pytest.mark.parametrize("args", [
    ["-sS", "127.0.0.1"], ["--script", "vuln", "127.0.0.1"], ["--script=vuln", "127.0.0.1"],
    ["-p", "22;id", "127.0.0.1"], ["-oX", "out.txt", "127.0.0.1"], ["-D", "RND:10", "127.0.0.1"],
    ["--top-ports", "65535", "127.0.0.1"], ["-sT", "8.8.8.8;id"], ["-sT"], ["-iL", "list.txt", "127.0.0.1"],
])
def test_validate_arguments_refuses_unsafe(args):
    with pytest.raises(ScanConfigError):
        validate_arguments(args, args[-1] if args[-1] != "-sT" else "127.0.0.1")


def test_build_config_errors():
    good = validate_target("127.0.0.1")
    with pytest.raises(ScanConfigError):
        build_config(validate_target("8.8.8.8"), "tcp_connect", "80")
    with pytest.raises(ScanConfigError):
        build_config(good, "stealth", "80")
    with pytest.raises(ScanConfigError):
        build_config(good, "tcp_connect", "99999")
    with pytest.raises(ScanConfigError):
        build_config(good, "tcp_connect", "80", timeout_sec=5)
    with pytest.raises(ScanConfigError):
        build_config(good, "tcp_connect", "80", timing="T5")
    with pytest.raises(ScanConfigError):
        build_config(good, "common", top_ports=5000)
    with pytest.raises(ScanConfigError):
        build_config(good, "selected", "")


# ---------------------------------------------------------------- engine with stand-in Nmap
def test_scan_completes_and_parses(tmp_path):
    cfg = build_config(validate_target("127.0.0.1"), "service", "1-1024,3306")
    job = run_scan(cfg, nmap_cmd=FAKE_NMAP, output_dir=tmp_path)
    assert job.state == "completed" and job.progress == 100 and job.error is None
    assert job.xml_path.exists() and job.command_line.startswith("nmap -sT -sV")
    r = result_from_job(job)
    assert r.summary["open"] == 4 and r.nmap_version == "7.95" and r.target_scope == "loopback"


def test_invalid_scan_handling_nmap_error(tmp_path):
    cfg = build_config(validate_target("192.168.56.77"), "tcp_connect", "22")
    job = run_scan(cfg, nmap_cmd=FAKE_NMAP, output_dir=tmp_path)
    assert job.state == "failed" and "Administrator" in job.error
    with pytest.raises(ValueError):
        result_from_job(job)


def test_stop_keeps_partial_results(tmp_path):
    cfg = build_config(validate_target("192.168.56.66"), "tcp_connect", "1-1000")
    job = ScanJob(cfg, nmap_cmd=FAKE_NMAP).start(tmp_path)
    deadline = time.time() + 10
    while job.progress == 0 and time.time() < deadline:
        time.sleep(0.05)
    assert job.is_running() and job.progress > 0
    job.stop()
    assert job.state == "stopped" and "stopped by the user" in job.error
    assert job.result is not None and not job.result.complete
    assert result_from_job(job).summary["open"] >= 1


def test_timeout_stops_scan(tmp_path):
    cfg = build_config(validate_target("192.168.56.66"), "tcp_connect", "1-1000", timeout_sec=10)
    cfg.timeout_sec = 1                      # shorten for the test (the UI minimum is 10 s)
    job = run_scan(cfg, nmap_cmd=FAKE_NMAP, output_dir=tmp_path)
    assert job.state == "timeout" and "timeout" in job.error


def test_os_detection_requires_admin(tmp_path, monkeypatch):
    monkeypatch.setattr(nmap_manager, "is_admin", lambda: False)
    cfg = build_config(validate_target("127.0.0.1"), "os_detection", "22")
    job = ScanJob(cfg, nmap_cmd=FAKE_NMAP).start(tmp_path)
    assert job.state == "failed" and "Administrator" in job.error


def test_missing_nmap_scan_fails_cleanly(tmp_path, monkeypatch):
    monkeypatch.setattr("scanner.scan_engine.find_nmap", lambda: (None, False))
    job = ScanJob(build_config(validate_target("127.0.0.1"), "tcp_connect", "22")).start(tmp_path)
    assert job.state == "failed" and "not installed" in job.error


# ---------------------------------------------------------------- 3-5. REAL localhost scans (need Nmap)
@requires_nmap
def test_real_localhost_tcp_scan(tmp_path, local_listener):
    """3 + 4: scan 127.0.0.1 with the real Nmap and detect the open test port."""
    with socket.socket() as s:                        # find a port that is very likely closed
        s.bind(("127.0.0.1", 0))
        closed_port = s.getsockname()[1]
    cfg = build_config(validate_target("127.0.0.1"), "tcp_connect", f"{local_listener},{closed_port}", timeout_sec=120)
    job = run_scan(cfg, output_dir=tmp_path)
    assert job.state == "completed", job.error
    r = result_from_job(job)
    states = dict(zip(r.ports["port"], r.ports["state"]))
    assert states.get(local_listener) == "Open"
    assert r.state_counts["Closed"] >= 1


@requires_nmap
def test_real_localhost_service_detection(tmp_path, local_listener):
    """5: Nmap's -sV identifies the SSH banner served by the local test listener."""
    cfg = build_config(validate_target("127.0.0.1"), "selected", str(local_listener), timeout_sec=180)
    job = run_scan(cfg, output_dir=tmp_path)
    assert job.state == "completed", job.error
    r = result_from_job(job)
    row = r.ports[r.ports["port"] == local_listener].iloc[0]
    assert row["state"] == "Open" and row["service"] == "ssh"
