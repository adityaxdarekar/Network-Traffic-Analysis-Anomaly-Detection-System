"""Database storage (9), PDF generation (10), CSV/XML/TXT export (11)."""

from __future__ import annotations

import csv
import io
import zipfile

import pytest

from analyzer.assessment import result_from_history, result_from_xml
from database.db_manager import DatabaseError, DatabaseManager
from reports.export_manager import (export_filename, findings_csv, ports_csv, save_exports, text_summary,
                                    xml_bytes, zip_bundle)
from reports.pdf_generator import generate_pdf_report


def pdf_text(path):
    pypdf = pytest.importorskip("pypdf")
    reader = pypdf.PdfReader(str(path))
    return len(reader.pages), "\n".join(pg.extract_text() for pg in reader.pages)


# ---------------------------------------------------------------- 9. database
def test_database_roundtrip_and_compare(fixture_path, tmp_path, settings):
    db = DatabaseManager(tmp_path / "s.db")
    a = result_from_xml(fixture_path("truncated_scan.xml"), settings)
    b = result_from_xml(fixture_path("lab_risky.xml"), settings)
    db.save_scan(a)
    db.save_scan(b)
    db.save_scan(b)                                     # re-saving replaces, never duplicates
    assert len(db.list_scans()) == 2
    rec = db.get_scan(b.scan_id)
    assert rec["open_ports"] == 16 and len(rec["ports"]) == 20 and len(rec["findings"]) == len(b.findings)
    assert rec["severity_counts"]["Critical"] == 1 and rec["target"] == "192.168.56.101"
    diff = db.compare_scans(a.scan_id, b.scan_id)
    assert set(diff[diff["change"] == "Newly open"]["port"]) >= {2375, 3306, 27017}
    assert db.totals()["scans"] == 2
    reopened = result_from_history(rec, settings)
    assert reopened.summary["open"] == 16 and reopened.scan_id == b.scan_id
    db.add_report(b.scan_id, "pdf", "x.pdf")
    assert len(db.get_scan(b.scan_id)["reports"]) == 1
    db.delete_scan(b.scan_id)
    assert db.get_scan(b.scan_id) is None and len(db.list_scans()) == 1


def test_database_error_handling(tmp_path):
    bad = tmp_path / "dir_not_db"
    bad.mkdir()
    with pytest.raises(DatabaseError):
        DatabaseManager(bad)
    db = DatabaseManager(tmp_path / "ok.db")
    with pytest.raises(DatabaseError):
        db.compare_scans("missing-1", "missing-2")


def test_history_without_xml(fixture_path, tmp_path, settings):
    db = DatabaseManager(tmp_path / "s.db")
    r = result_from_xml(fixture_path("localhost_service.xml"), settings)
    r.xml_path = str(tmp_path / "deleted.xml")
    db.save_scan(r)
    with pytest.raises(ValueError, match="no longer on disk"):
        result_from_history(db.get_scan(r.scan_id), settings)


# ---------------------------------------------------------------- 10. PDF
def test_pdf_report(fixture_path, tmp_path, settings):
    r = result_from_xml(fixture_path("lab_risky.xml"), settings)
    out = generate_pdf_report(r, tmp_path / "r.pdf", analyst="Test Student")
    assert out.read_bytes()[:4] == b"%PDF"
    pages, text = pdf_text(out)
    assert pages >= 8
    for heading in ("Table of Contents", "Executive Summary", "Target Information", "Scan Methodology",
                    "Port Results", "Identified Services and Versions", "Potential Security Findings",
                    "Severity Distribution", "Security Recommendations", "Conclusion"):
        assert heading in text, heading
    for fact in ("192.168.56.101", "7.95", "Test Student", "Docker API", "F-001", "Page 2 of"):
        assert fact in text, fact


@pytest.mark.parametrize("name", ["no_open_ports.xml", "host_down.xml", "multi_host.xml", "truncated_scan.xml"])
def test_pdf_edge_cases(fixture_path, tmp_path, settings, name):
    out = generate_pdf_report(result_from_xml(fixture_path(name), settings), tmp_path / "e.pdf")
    _, text = pdf_text(out)
    assert "Conclusion" in text


# ---------------------------------------------------------------- 11. exports
def test_csv_exports(fixture_path, settings):
    r = result_from_xml(fixture_path("lab_risky.xml"), settings)
    rows = list(csv.DictReader(io.StringIO(ports_csv(r))))
    assert len(rows) == 20 and rows[0]["port"] == "21" and rows[0]["service"] == "ftp"
    f = list(csv.DictReader(io.StringIO(findings_csv(r))))
    assert f[0]["finding_id"] == "F-001" and f[0]["severity"] == "Critical"


def test_txt_xml_zip_and_files(fixture_path, tmp_path, settings):
    r = result_from_xml(fixture_path("localhost_service.xml"), settings)
    txt = text_summary(r)
    assert "Open           : 4" in txt and "3306/tcp" in txt
    assert xml_bytes(r) == fixture_path("localhost_service.xml").read_bytes()
    names = zipfile.ZipFile(io.BytesIO(zip_bundle(r))).namelist()
    assert len(names) == 5 and any(n.endswith(".xml") for n in names)
    files = save_exports(r, tmp_path)
    assert all(p.exists() for p in files.values()) and set(files) >= {"ports_csv", "summary_txt", "nmap_xml"}


def test_export_filenames():
    from datetime import datetime
    assert export_filename("ports", "192.168.56.0/24", "csv", datetime(2026, 11, 5, 10, 0, 0)) == \
        "ports_192.168.56.0_24_20261105_100000.csv"
    for evil in ("../../evil", "..", "a/b\\c"):
        name = export_filename("x", evil, "csv")
        assert "/" not in name and "\\" not in name and ".." not in name
