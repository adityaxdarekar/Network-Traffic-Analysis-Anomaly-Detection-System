"""
Stand-in for the nmap program, used ONLY by the unit tests on machines without Nmap.
It performs no network activity: it prints Nmap-like progress lines and copies a
SYNTHETIC fixture XML to the -oX path.

Behaviour is chosen by the target argument (the last argument):
    127.0.0.1        -> copies fixtures/localhost_service.xml, exits 0
    192.168.56.20    -> copies fixtures/no_open_ports.xml
    192.168.56.66    -> runs slowly (for stop / timeout tests)
    192.168.56.77    -> exits 1 with an "requires root privileges" error
"""
import shutil
import sys
import time
from pathlib import Path

FIX = Path(__file__).resolve().parent / "fixtures"
args = sys.argv[1:]
if args == ["--version"]:
    print("Nmap version 7.95 ( https://nmap.org )\nPlatform: test-stub")
    sys.exit(0)
out = Path(args[args.index("-oX") + 1])
target = args[-1]
if target == "192.168.56.77":
    sys.stderr.write("You requested a scan type which requires root privileges.\nQUITTING!\n")
    sys.exit(1)
print("Starting Nmap 7.95 ( https://nmap.org )", flush=True)
if target == "192.168.56.66":
    text = (FIX / "lab_risky.xml").read_text()
    out.write_text(text[: text.index("<port protocol=\"tcp\" portid=\"80\">")])   # partial file
    for i in range(600):
        print(f"Connect Scan Timing: About {i / 6:.2f}% done; ETC: 10:05 (0:04:00 remaining)", flush=True)
        time.sleep(0.05)
    sys.exit(0)
fixture = "no_open_ports.xml" if target == "192.168.56.20" else "localhost_service.xml"
for pct in ("12.50", "55.00", "90.10"):
    print(f"Connect Scan Timing: About {pct}% done; ETC: 10:00 (0:00:05 remaining)", flush=True)
    time.sleep(0.05)
shutil.copy(FIX / fixture, out)
print("Nmap done: 1 IP address (1 host up) scanned in 0.2 seconds", flush=True)
