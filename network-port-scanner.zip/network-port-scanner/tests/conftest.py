"""Shared fixtures. All XML in tests/fixtures is SYNTHETIC; no external host is ever scanned."""

from __future__ import annotations

import socket
import sys
import threading
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import default_settings  # noqa: E402
from scanner.nmap_manager import find_nmap  # noqa: E402

FIXTURES = Path(__file__).resolve().parent / "fixtures"
FAKE_NMAP = [sys.executable, str(Path(__file__).resolve().parent / "fake_nmap.py")]
REAL_NMAP = find_nmap()[0]
requires_nmap = pytest.mark.skipif(not REAL_NMAP, reason="Nmap is not installed on this machine")


@pytest.fixture
def settings():
    return default_settings()


@pytest.fixture
def fixture_path():
    return lambda name: FIXTURES / name


@pytest.fixture
def local_listener():
    """
    A real TCP server on 127.0.0.1 (random free port) for safe localhost scanning tests.
    It sends an SSH-style banner so Nmap's service detection has something to identify.
    """
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(16)
    srv.settimeout(0.5)
    stop = threading.Event()

    def serve():
        while not stop.is_set():
            try:
                conn, _ = srv.accept()
            except OSError:
                continue
            try:
                conn.sendall(b"SSH-2.0-OpenSSH_9.6\r\n")
                conn.settimeout(2)
                conn.recv(1024)
            except OSError:
                pass
            finally:
                conn.close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    yield srv.getsockname()[1]
    stop.set()
    srv.close()
    t.join(timeout=2)
