"""Nmap XML parsing (test 6) and parser robustness."""

from __future__ import annotations

import pytest

from scanner.xml_parser import NmapXMLError, parse_nmap_xml


def test_parse_service_scan(fixture_path):
    s = parse_nmap_xml(fixture_path("localhost_service.xml"))
    assert s.complete and s.scanner_version == "7.95" and s.hosts_up == 1 and s.elapsed == 8.21
    h = s.hosts[0]
    assert h.address == "127.0.0.1" and h.hostnames[0] == "localhost" and h.extraports == {"closed": 1020}
    ssh = next(p for p in h.ports if p.port == 22)
    assert (ssh.service, ssh.product, ssh.version, ssh.method, ssh.confidence) == \
        ("ssh", "OpenSSH", "9.6p1 Ubuntu 3ubuntu13.5", "probed", 10)
    assert "cpe:/a:openbsd:openssh:9.6p1" in ssh.cpe
    https = next(p for p in h.ports if p.port == 443)
    assert https.tunnel == "ssl" and https.service == "http"
    assert next(p for p in h.ports if p.port == 135).state == "filtered"


def test_parse_os_mac_and_states(fixture_path):
    h = parse_nmap_xml(fixture_path("lab_risky.xml")).hosts[0]
    assert h.mac == "08:00:27:AA:BB:CC" and "VirtualBox" in h.vendor
    assert h.os_matches[0].name.startswith("Linux") and h.os_matches[0].accuracy == 96
    states = {p.port: p.state for p in h.ports}
    assert states[111] == "open|filtered" and states[8443] == "unfiltered" and states[25] == "closed"


def test_multi_host_and_host_down(fixture_path):
    m = parse_nmap_xml(fixture_path("multi_host.xml"))
    assert [h.address for h in m.hosts] == ["192.168.56.97", "192.168.56.98"] and m.hosts_down == 6
    d = parse_nmap_xml(fixture_path("host_down.xml"))
    assert d.hosts == [] and d.hosts_down == 1 and any("No hosts" in w for w in d.warnings)


def test_truncated_scan_is_repaired(fixture_path):
    s = parse_nmap_xml(fixture_path("truncated_scan.xml"))
    assert not s.complete and len(s.hosts[0].ports) == 10
    assert any("did not finish" in w for w in s.warnings)


def test_nmap_error_is_reported(fixture_path):
    s = parse_nmap_xml(fixture_path("nmap_error.xml"))
    assert s.exit_status == "error" and any("root privileges" in w for w in s.warnings)


@pytest.mark.parametrize("content,message", [
    ("", "empty"), ("   ", "empty"), ("<html><body>hi</body></html>", "not Nmap XML"),
    ("<?xml version='1.0'?><!DOCTYPE x [<!ENTITY a 'b'>]><nmaprun>&a;</nmaprun>", "entity"),
    ("<nmaprun><host></nmaprun>", "could not be parsed"),
])
def test_invalid_xml(content, message):
    with pytest.raises(NmapXMLError, match=message):
        parse_nmap_xml(content)


def test_missing_file(tmp_path):
    with pytest.raises(NmapXMLError, match="not found"):
        parse_nmap_xml(tmp_path / "nope.xml")


def test_bytes_input(fixture_path):
    assert parse_nmap_xml(fixture_path("no_open_ports.xml").read_bytes()).hosts[0].extraports == {"closed": 1000}


def test_cut_off_document_is_partial_not_an_error():
    s = parse_nmap_xml("<nmaprun version='7.95'><host><status state='up'/>")
    assert not s.complete and len(s.hosts) == 1
