"""Security risk analysis (test 8)."""

from __future__ import annotations

import pandas as pd

from analyzer.assessment import result_from_xml
from analyzer.risk_analyzer import is_older, version_tuple

REQUIRED = ["finding_id", "port", "service", "observed_version", "severity", "explanation", "risk", "mitigation"]


def by_port(findings, port, rule=None):
    f = findings[findings["port"] == port]
    return f[f["rule"] == rule] if rule else f


def test_lab_findings(fixture_path, settings):
    r = result_from_xml(fixture_path("lab_risky.xml"), settings)
    f = r.findings
    assert all(c in f.columns for c in REQUIRED)
    assert f["finding_id"].is_unique and f["finding_id"].iloc[0] == "F-001"
    assert by_port(f, 2375).iloc[0]["severity"] == "Critical"            # unauthenticated Docker API
    assert by_port(f, 23).iloc[0]["severity"] == "High"                  # Telnet
    assert by_port(f, 21).iloc[0]["finding_type"] == "Unencrypted service"
    assert by_port(f, 445).iloc[0]["severity"] == "Medium"               # SMB
    assert by_port(f, 3306, "E1").iloc[0]["finding_type"] == "Exposed service"
    assert by_port(f, 9999).iloc[0]["finding_type"] == "Unidentified service"
    assert (f["rule"] == "A1").sum() == 1                                 # 16 open ports >= 15
    assert list(f["severity"]) == sorted(f["severity"], key=["Critical", "High", "Medium", "Low",
                                                              "Informational"].index)


def test_never_claims_confirmed_vulnerabilities(fixture_path, settings):
    f = result_from_xml(fixture_path("lab_risky.xml"), settings).findings
    assert not f["confirmed_vulnerability"].any()
    text = " ".join(f["explanation"].tolist() + f["title"].tolist() + f["risk"].tolist())
    assert "CVE-" not in text
    assert "is vulnerable" not in text.lower()


def test_version_observations(fixture_path, settings):
    f = result_from_xml(fixture_path("lab_risky.xml"), settings).findings
    v = f[f["rule"] == "V1"]
    assert set(v["port"]) == {22, 80, 3306, 5432, 27017}
    assert (v["finding_type"] == "Version observation").all()
    assert v["explanation"].str.contains("not a confirmed vulnerability").all()
    # Modern versions are not flagged
    loc = result_from_xml(fixture_path("localhost_service.xml"), settings).findings
    assert (loc["rule"] != "V1").all()


def test_version_helpers():
    assert version_tuple("6.6.1p1 Ubuntu") == (6, 6, 1) and version_tuple("9.6.0 - 9.6.2") == (9, 6, 0)
    assert version_tuple("") is None and version_tuple("unknown") is None
    assert is_older((2, 2, 8), (2, 4)) and not is_older((2, 4), (2, 4, 0)) and not is_older((10,), (9, 9))


def test_open_port_alone_is_not_high_severity(fixture_path, settings):
    f = result_from_xml(fixture_path("localhost_service.xml"), settings).findings
    https = by_port(f, 443).iloc[0]
    assert https["severity"] == "Informational"
    assert not (f["severity"].isin(["High", "Critical"])).any()


def test_localhost_downgrade(fixture_path, settings):
    on = result_from_xml(fixture_path("localhost_service.xml"), settings).findings
    settings["localhost_downgrade"] = False
    off = result_from_xml(fixture_path("localhost_service.xml"), settings).findings
    assert by_port(on, 3306).iloc[0]["severity"] == "Low" and by_port(off, 3306).iloc[0]["severity"] == "Medium"
    assert "localhost" in by_port(on, 3306).iloc[0]["explanation"]


def test_expected_ports_become_informational(fixture_path, settings):
    settings["expected_open_ports"] = [23, 2375]
    f = result_from_xml(fixture_path("lab_risky.xml"), settings).findings
    assert by_port(f, 23).iloc[0]["severity"] == "Informational"
    assert by_port(f, 2375).iloc[0]["severity"] == "Informational"


def test_no_findings_without_open_ports(fixture_path, settings):
    for name in ("no_open_ports.xml", "host_down.xml"):
        r = result_from_xml(fixture_path(name), settings)
        assert r.findings.empty and isinstance(r.findings, pd.DataFrame)


def test_closed_and_filtered_ports_make_no_findings(fixture_path, settings):
    f = result_from_xml(fixture_path("lab_risky.xml"), settings).findings
    assert not set(f["port"].dropna()) & {25, 111, 443, 8443}
