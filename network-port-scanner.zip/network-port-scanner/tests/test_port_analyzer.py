"""Port state classification (test 7), port tables and service analysis."""

from __future__ import annotations

import pytest

from analyzer.port_analyzer import analyze_ports, classify_state, ports_dataframe, state_counts
from analyzer.service_analyzer import analyze_services
from scanner.xml_parser import parse_nmap_xml


@pytest.mark.parametrize("raw,label", [("open", "Open"), ("closed", "Closed"), ("filtered", "Filtered"),
                                       ("open|filtered", "Open|Filtered"), ("closed|filtered", "Unknown"),
                                       ("unfiltered", "Unknown"), ("", "Unknown"), (None, "Unknown"),
                                       ("OPEN", "Open")])
def test_classify_state(raw, label):
    assert classify_state(raw) == label


def test_counts_include_extraports(fixture_path):
    s = parse_nmap_xml(fixture_path("localhost_service.xml"))
    assert state_counts(s) == {"Open": 4, "Closed": 1020, "Filtered": 1, "Open|Filtered": 0, "Unknown": 0}
    pa = analyze_ports(s)
    assert pa["total_scanned"] == 1025 and pa["open_count"] == 4


def test_lab_counts_and_table(fixture_path):
    s = parse_nmap_xml(fixture_path("lab_risky.xml"))
    c = state_counts(s)
    assert c == {"Open": 16, "Closed": 29981, "Filtered": 1, "Open|Filtered": 1, "Unknown": 1}
    assert sum(c.values()) == 30000
    df = ports_dataframe(s)
    assert list(df["port"]) == sorted(df["port"]) and len(df) == 20
    assert df.set_index("port").loc[111, "state"] == "Open|Filtered"


def test_no_open_ports(fixture_path):
    pa = analyze_ports(parse_nmap_xml(fixture_path("no_open_ports.xml")))
    assert pa["ports"].empty and pa["state_counts"]["Closed"] == 1000 and pa["open_ports"].empty


def test_multi_host_per_host_counts(fixture_path):
    pa = analyze_ports(parse_nmap_xml(fixture_path("multi_host.xml")))
    hosts = pa["hosts"].set_index("host")
    assert hosts.loc["192.168.56.97", "closed"] == 99 and hosts.loc["192.168.56.98", "filtered"] == 98


def test_service_analysis(fixture_path):
    sa = analyze_services(analyze_ports(parse_nmap_xml(fixture_path("lab_risky.xml")))["ports"])
    sv = sa["services"].set_index("port")
    assert sa["probed"] == 14 and sa["guessed"] == 2
    assert sv.loc[8080, "identification"] == "Guessed from port number"
    assert sv.loc[8080, "product_version"] == "Not reported"           # never invented
    assert sv.loc[22, "encrypted"] and not sv.loc[23, "encrypted"]
    assert sv.loc[3306, "category"] == "Database"
    loc = analyze_services(analyze_ports(parse_nmap_xml(fixture_path("localhost_service.xml")))["ports"])
    assert loc["services"].set_index("port").loc[443, "service"] == "https"


def test_versions_are_exactly_as_reported(fixture_path):
    s = parse_nmap_xml(fixture_path("localhost_service.xml"))
    sv = analyze_services(analyze_ports(s)["ports"])["services"].set_index("port")
    assert sv.loc[3306, "version"] == "8.0.39-0ubuntu0.24.04.2"
