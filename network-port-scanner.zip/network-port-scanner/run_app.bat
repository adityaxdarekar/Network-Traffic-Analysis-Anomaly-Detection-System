@echo off
REM Starts the Streamlit dashboard at http://localhost:8501  (stop with Ctrl+C)
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Run setup_windows.bat first.
  pause
  exit /b 1
)
venv\Scripts\python.exe -m streamlit run app.py
