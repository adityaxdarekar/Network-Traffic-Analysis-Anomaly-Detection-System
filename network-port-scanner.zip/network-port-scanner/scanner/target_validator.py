"""
Target and port validation - the first line of the project's safety rules.

Policy (see section 16 of the project brief):
    * Loopback (127.0.0.0/8, ::1) and private lab addresses (RFC 1918,
      IPv6 ULA fc00::/7, link-local) are allowed.
    * Anything else (public Internet addresses, hostnames that resolve to
      them) is BLOCKED unless public targets were enabled in Settings AND the
      user ticks an explicit authorisation box for that scan.
    * Multicast, broadcast, unspecified (0.0.0.0) and reserved addresses are
      never scanned.
    * Lab ranges (CIDR) may cover at most 256 addresses (a /24).
    * Input may only contain the characters of an IP address, CIDR or
      hostname - so nothing can be smuggled into the Nmap command line.
"""

from __future__ import annotations

import ipaddress
import re
import socket
from dataclasses import dataclass, field

from config import MAX_CIDR_HOSTS

HOSTNAME_RE = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))*\.?$")
PORT_SPEC_RE = re.compile(r"^[0-9,\- ]+$")


@dataclass
class TargetCheck:
    ok: bool
    message: str
    target: str = ""                 # normalised value passed to Nmap
    kind: str = ""                   # ip | cidr | hostname
    scope: str = ""                  # loopback | private | public | blocked
    resolved: list[str] = field(default_factory=list)
    needs_authorization: bool = False

    @property
    def is_local_only(self) -> bool:
        return self.scope == "loopback"


def classify_address(addr: ipaddress._BaseAddress) -> str:
    """loopback | private | public | blocked"""
    if addr.is_unspecified or addr.is_multicast or (addr.version == 4 and str(addr) == "255.255.255.255"):
        return "blocked"
    if addr.is_loopback:
        return "loopback"
    if addr.is_link_local:
        return "private"
    if addr.version == 4 and any(addr in ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12",
                                                                          "192.168.0.0/16")):
        return "private"
    if addr.version == 6 and addr in ipaddress.ip_network("fc00::/7"):
        return "private"
    if addr.is_global:
        return "public"
    return "blocked"   # reserved, documentation, CGNAT ... - not lab targets


def _scope_message(scope: str) -> str:
    return {"loopback": "Localhost - always allowed.",
            "private": "Private lab address - allowed. Scan it only if you own it or are authorised.",
            "public": "Public Internet address - blocked by default."}.get(scope, "")


def resolve_hostname(name: str, timeout: float = 5.0) -> list[str]:
    old = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        infos = socket.getaddrinfo(name, None, proto=socket.IPPROTO_TCP)
        return sorted({info[4][0].split("%")[0] for info in infos})
    finally:
        socket.setdefaulttimeout(old)


def validate_target(raw: str, allow_public: bool = False, authorized: bool = False,
                    resolver=resolve_hostname) -> TargetCheck:
    """Validate one scan target (IP, small CIDR range or hostname)."""
    value = (raw or "").strip()
    if not value:
        return TargetCheck(False, "Please enter a target (e.g. 127.0.0.1).")
    if len(value) > 253 or not re.fullmatch(r"[A-Za-z0-9.:/\-]+", value) or value.startswith("-"):
        return TargetCheck(False, "Invalid characters. Enter a single IP address, a lab range such as "
                                  "192.168.56.0/24, or a hostname.")
    scope = None
    resolved: list[str] = []
    kind = ""
    try:
        if "/" in value:
            net = ipaddress.ip_network(value, strict=False)
            kind = "cidr"
            if net.num_addresses > MAX_CIDR_HOSTS:
                return TargetCheck(False, f"Range {net} has {net.num_addresses:,} addresses; the limit is "
                                          f"{MAX_CIDR_HOSTS} (a /24). Scan a smaller lab range.")
            # A /24 or smaller range lies inside one address class; check both ends to be sure.
            scopes = {classify_address(net.network_address), classify_address(net.broadcast_address)}
            scope = max(scopes, key=["loopback", "private", "public", "blocked"].index)
            value = str(net)
        else:
            addr = ipaddress.ip_address(value)
            kind = "ip"
            scope = classify_address(addr)
            value = str(addr)
    except ValueError:
        if not HOSTNAME_RE.match(value):
            return TargetCheck(False, "Not a valid IP address, CIDR range or hostname.")
        kind = "hostname"
        try:
            resolved = resolver(value)
        except (OSError, UnicodeError):
            resolved = []
        if not resolved:
            return TargetCheck(False, f"Could not resolve hostname '{value}'. Check the spelling or use its IP.",
                               value, kind)
        scopes = {classify_address(ipaddress.ip_address(ip)) for ip in resolved}
        order = ["loopback", "private", "public", "blocked"]
        scope = max(scopes, key=order.index)       # the most restrictive address decides

    if scope == "blocked":
        return TargetCheck(False, "This address type (multicast, broadcast, unspecified or reserved) cannot be "
                                  "scanned.", value, kind, scope, resolved)
    if scope == "public":
        if not allow_public:
            return TargetCheck(False, "Public Internet targets are blocked by default. Only scan systems you own or "
                                      "have written permission to test. (They can be enabled in Settings.)",
                               value, kind, scope, resolved, needs_authorization=True)
        if not authorized:
            return TargetCheck(False, "Confirm that you are authorised to scan this public target.",
                               value, kind, scope, resolved, needs_authorization=True)
    msg = _scope_message(scope)
    if resolved:
        msg = f"Resolves to {', '.join(resolved)}. " + msg
    return TargetCheck(True, msg, value, kind, scope, resolved, needs_authorization=scope == "public")


def parse_ports(spec: str) -> tuple[list[tuple[int, int]], str | None]:
    """
    Parse a port specification such as '22,80,443' or '1-1024,8080'.
    Returns (list of (start, end) ranges, error message or None).
    """
    spec = (spec or "").strip()
    if not spec:
        return [], "Enter at least one port."
    if not PORT_SPEC_RE.match(spec):
        return [], "Ports may only contain digits, commas and hyphens (e.g. 22,80,443 or 1-1024)."
    ranges = []
    for part in [p.strip() for p in spec.split(",") if p.strip()]:
        if "-" in part:
            a, _, b = part.partition("-")
            if not a.isdigit() or not b.isdigit():
                return [], f"Invalid range '{part}'."
            lo, hi = int(a), int(b)
        elif part.isdigit():
            lo = hi = int(part)
        else:
            return [], f"Invalid port '{part}'."
        if not (1 <= lo <= hi <= 65535):
            return [], f"Port range '{part}' must be between 1 and 65535 with start ≤ end."
        ranges.append((lo, hi))
    if len(ranges) > 100:
        return [], "Too many port entries (maximum 100 comma-separated items)."
    return ranges, None


def normalise_ports(ranges: list[tuple[int, int]]) -> str:
    """Merge overlapping ranges and render them in Nmap's -p syntax."""
    merged: list[list[int]] = []
    for lo, hi in sorted(ranges):
        if merged and lo <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    return ",".join(str(a) if a == b else f"{a}-{b}" for a, b in merged)


def count_ports(ranges: list[tuple[int, int]]) -> int:
    spec = normalise_ports(ranges)
    total = 0
    for part in spec.split(","):
        a, _, b = part.partition("-")
        total += (int(b) - int(a) + 1) if b else 1
    return total
