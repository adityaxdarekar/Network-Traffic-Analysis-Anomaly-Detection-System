"""
Parse Nmap XML output (``nmap -oX``) into Python dataclasses.

Why XML and not Nmap's normal text output? The XML format is stable,
documented (nmap.dtd) and machine-readable, so nothing has to be guessed
from screen text.

Important details handled here:
    * Nmap lists "interesting" ports individually but collapses the rest into
      ``<extraports state="closed" count="995">``; those counts are kept, so
      closed/filtered totals are correct.
    * A scan that was interrupted leaves an unfinished XML file; it is
      repaired where possible and marked ``complete=False``.
    * XML is parsed safely (defusedxml when installed; DTD entities rejected
      otherwise), so a crafted file cannot exploit the XML parser.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

try:   # defusedxml blocks entity-expansion and external-entity attacks
    from defusedxml.ElementTree import ParseError, fromstring
except ImportError:   # pragma: no cover - fallback when defusedxml is not installed
    from xml.etree.ElementTree import ParseError, fromstring


class NmapXMLError(Exception):
    """Raised when a file is not usable Nmap XML."""


@dataclass
class PortResult:
    protocol: str
    port: int
    state: str
    reason: str = ""
    service: str = ""
    product: str = ""
    version: str = ""
    extrainfo: str = ""
    ostype: str = ""
    method: str = ""            # "probed" (really detected) or "table" (guessed from the port number)
    confidence: int | None = None
    tunnel: str = ""            # "ssl" when the service runs inside TLS
    cpe: list[str] = field(default_factory=list)
    scripts: dict[str, str] = field(default_factory=dict)


@dataclass
class OSMatch:
    name: str
    accuracy: int
    os_family: str = ""
    vendor: str = ""


@dataclass
class HostResult:
    address: str
    address_type: str = "ipv4"
    mac: str = ""
    vendor: str = ""
    hostnames: list[str] = field(default_factory=list)
    status: str = "unknown"
    status_reason: str = ""
    ports: list[PortResult] = field(default_factory=list)
    extraports: dict[str, int] = field(default_factory=dict)   # state -> count of ports not listed
    os_matches: list[OSMatch] = field(default_factory=list)


@dataclass
class ParsedScan:
    args: str = ""
    scanner_version: str = ""
    start_time: int | None = None
    end_time: int | None = None
    elapsed: float | None = None
    scan_types: list[str] = field(default_factory=list)
    services_requested: int = 0
    hosts: list[HostResult] = field(default_factory=list)
    hosts_up: int = 0
    hosts_down: int = 0
    exit_status: str = ""
    error_message: str = ""
    summary: str = ""
    complete: bool = True
    warnings: list[str] = field(default_factory=list)


def _int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _repair_truncated(text: str) -> str:
    """Close an interrupted Nmap XML document so the ports found so far can still be read."""
    # Drop any partially written final element
    cut = text.rfind(">")
    text = text[:cut + 1] if cut != -1 else text
    open_tags = []
    for m in re.finditer(r"<(/?)([A-Za-z_][\w:-]*)[^>]*?(/?)>", text):
        closing, name, selfclosing = m.group(1), m.group(2), m.group(3)
        if name.startswith("?") or selfclosing:
            continue
        if closing:
            if open_tags and open_tags[-1] == name:
                open_tags.pop()
        else:
            open_tags.append(name)
    return text + "".join(f"</{t}>" for t in reversed(open_tags))


def parse_nmap_xml(source: str | Path | bytes) -> ParsedScan:
    """Parse Nmap XML from a file path, an XML string or bytes."""
    if isinstance(source, Path) or (isinstance(source, str) and source.strip() and
                                    not source.lstrip().startswith("<")):
        path = Path(source)
        if not path.exists():
            raise NmapXMLError(f"File not found: {path.name}")
        text = path.read_text(encoding="utf-8", errors="replace")
    elif isinstance(source, bytes):
        text = source.decode("utf-8", errors="replace")
    else:
        text = source
    if not text.strip():
        raise NmapXMLError("The XML file is empty - Nmap produced no output.")
    if "<!ENTITY" in text:
        raise NmapXMLError("XML entity declarations are not allowed (possible XML attack).")
    if "<nmaprun" not in text:
        raise NmapXMLError("This is not Nmap XML output (no <nmaprun> element).")

    complete = True
    # Nmap's DOCTYPE line is harmless but unnecessary; remove it before parsing.
    clean = re.sub(r"<!DOCTYPE[^>]*>", "", text)
    try:
        root = fromstring(clean)
    except ParseError:
        complete = False
        try:
            root = fromstring(_repair_truncated(clean))
        except ParseError as exc:
            raise NmapXMLError(f"The XML could not be parsed: {exc}") from exc
    if root.tag != "nmaprun":
        raise NmapXMLError("Root element is not <nmaprun>.")

    scan = ParsedScan(args=root.get("args", ""), scanner_version=root.get("version", ""),
                      start_time=_int(root.get("start")), complete=complete)
    for si in root.findall("scaninfo"):
        scan.scan_types.append(f"{si.get('type', '')}/{si.get('protocol', '')}")
        scan.services_requested += _int(si.get("numservices"), 0)

    for h in root.findall("host"):
        host = HostResult(address="")
        for addr in h.findall("address"):
            atype = addr.get("addrtype", "")
            if atype == "mac":
                host.mac, host.vendor = addr.get("addr", ""), addr.get("vendor", "")
            elif not host.address:
                host.address, host.address_type = addr.get("addr", ""), atype
        host.hostnames = [hn.get("name", "") for hn in h.findall("hostnames/hostname") if hn.get("name")]
        status = h.find("status")
        if status is not None:
            host.status, host.status_reason = status.get("state", "unknown"), status.get("reason", "")
        ports_el = h.find("ports")
        if ports_el is not None:
            for ep in ports_el.findall("extraports"):
                state = ep.get("state", "unknown")
                host.extraports[state] = host.extraports.get(state, 0) + _int(ep.get("count"), 0)
            for p in ports_el.findall("port"):
                st = p.find("state")
                sv = p.find("service")
                pr = PortResult(protocol=p.get("protocol", "tcp"), port=_int(p.get("portid"), 0),
                                state=(st.get("state") if st is not None else "unknown") or "unknown",
                                reason=st.get("reason", "") if st is not None else "")
                if sv is not None:
                    pr.service, pr.product = sv.get("name", ""), sv.get("product", "")
                    pr.version, pr.extrainfo = sv.get("version", ""), sv.get("extrainfo", "")
                    pr.ostype, pr.method = sv.get("ostype", ""), sv.get("method", "")
                    pr.confidence, pr.tunnel = _int(sv.get("conf")), sv.get("tunnel", "")
                    pr.cpe = [c.text or "" for c in sv.findall("cpe")]
                for script in p.findall("script"):
                    pr.scripts[script.get("id", "")] = (script.get("output", "") or "")[:500]
                host.ports.append(pr)
        for om in h.findall("os/osmatch"):
            cls = om.find("osclass")
            host.os_matches.append(OSMatch(om.get("name", ""), _int(om.get("accuracy"), 0) or 0,
                                           cls.get("osfamily", "") if cls is not None else "",
                                           cls.get("vendor", "") if cls is not None else ""))
        scan.hosts.append(host)

    finished = root.find("runstats/finished")
    if finished is not None:
        scan.end_time = _int(finished.get("time"))
        try:
            scan.elapsed = float(finished.get("elapsed", ""))
        except ValueError:
            scan.elapsed = None
        scan.exit_status = finished.get("exit", "")
        scan.error_message = finished.get("errormsg", "")
        scan.summary = finished.get("summary", "")
    else:
        scan.complete = False
    hosts = root.find("runstats/hosts")
    if hosts is not None:
        scan.hosts_up, scan.hosts_down = _int(hosts.get("up"), 0), _int(hosts.get("down"), 0)
    else:
        scan.hosts_up = sum(1 for h in scan.hosts if h.status == "up")

    if not scan.complete:
        scan.warnings.append("The scan did not finish (stopped, timed out or interrupted). Results are partial.")
    if scan.exit_status == "error":
        scan.warnings.append(f"Nmap reported an error: {scan.error_message or 'unknown error'}")
    if scan.complete and not scan.hosts:
        scan.warnings.append("No hosts in the results - the target may be down or blocking probes.")
    return scan
