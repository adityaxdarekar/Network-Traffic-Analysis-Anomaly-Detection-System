"""
Scan engine: builds SAFE Nmap command lines and runs them.

Safety design (beginner-friendly explanation):
    * The user never types Nmap options. They choose a *profile* from a fixed
      menu; each profile maps to a hard-coded list of options.
    * The command is passed to ``subprocess`` as a LIST, never through a shell,
      so characters such as ``;`` or ``&&`` can never run another program.
    * Every argument is checked against an allowlist just before Nmap runs.
    * Only TCP connect scans (-sT) are used: they complete a normal TCP
      handshake like any client. There are no stealth (-sS/-sN/-sF/-sX),
      evasion (-f, -D, --spoof-mac ...), exploit or script (--script) options.
    * Conservative timing (-T3 by default, -T4 at most), --max-retries 2,
      a per-host timeout and an overall timeout that stops the scan.
"""

from __future__ import annotations

import re
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from config import DEFAULT_SCAN, SCAN_DIR, TIMEOUT_LIMITS
from scanner.nmap_manager import IS_WINDOWS, find_nmap, get_nmap_info, no_window
from scanner.target_validator import TargetCheck, count_ports, normalise_ports, parse_ports
from scanner.xml_parser import NmapXMLError, ParsedScan, parse_nmap_xml


@dataclass(frozen=True)
class ScanProfile:
    key: str
    name: str
    nmap_args: tuple[str, ...]
    description: str
    uses_port_list: bool = True
    requires_ports: bool = False
    requires_admin: bool = False
    example: str = ""


PROFILES: dict[str, ScanProfile] = {
    "tcp_connect": ScanProfile(
        "tcp_connect", "Basic TCP Connect Scan", ("-sT",),
        "Tries a normal TCP connection to each port. Open = the connection was accepted, closed = refused, "
        "filtered = no answer (usually a firewall). Fast and needs no special permissions.",
        example="nmap -sT -p 1-1024 TARGET"),
    "service": ScanProfile(
        "service", "Service & Version Detection", ("-sT", "-sV"),
        "TCP connect scan, then talks to every open port to identify the service, product and version "
        "(e.g. 'ssh / OpenSSH 9.6'). Slower than a basic scan.",
        example="nmap -sT -sV -p 1-1024 TARGET"),
    "selected": ScanProfile(
        "selected", "Selected Port Scan", ("-sT", "-sV"),
        "Scans only the ports you list (e.g. 22,80,443) with service detection.",
        requires_ports=True, example="nmap -sT -sV -p 22,80,443 TARGET"),
    "common": ScanProfile(
        "common", "Common Ports Scan", ("-sT", "-sV"),
        "Scans Nmap's list of the most frequently used ports (Top 100 by default) with service detection - "
        "a quick, safe overview.", uses_port_list=False, example="nmap -sT -sV --top-ports 100 TARGET"),
    "os_detection": ScanProfile(
        "os_detection", "OS Detection (optional)", ("-sT", "-sV", "-O", "--osscan-limit"),
        "Adds operating-system fingerprinting. Needs Administrator rights (Windows, with Npcap) or root, "
        "and works best when at least one open and one closed port are found. The guess may be wrong or "
        "missing - treat it as a hint.", requires_admin=True, example="nmap -sT -sV -O -p 1-1024 TARGET"),
}

TOP_PORT_CHOICES = (20, 100, 1000)
TIMING_CHOICES = ("T2", "T3", "T4")

# Every option that may ever reach Nmap. Values are checked separately.
ALLOWED_FLAGS = {"-sT", "-sV", "-O", "--osscan-limit", "-p", "--top-ports", "-T2", "-T3", "-T4", "-Pn",
                 "--host-timeout", "--max-retries", "-oX", "--stats-every", "--reason", "-n", "-6"}
FLAGS_WITH_VALUE = {"-p", "--top-ports", "--host-timeout", "--max-retries", "-oX", "--stats-every"}
FORBIDDEN_PATTERNS = ("--script", "-sS", "-sN", "-sF", "-sX", "-sU", "-f", "-D", "--spoof", "--data", "-S",
                      "--proxies", "--badsum", "-iL", "--resume", "--datadir", "--servicedb", "--exec")


class ScanConfigError(ValueError):
    """Raised for an invalid or unsafe scan configuration."""


@dataclass
class ScanConfig:
    target: TargetCheck
    profile: str = DEFAULT_SCAN["profile"]
    ports: str = DEFAULT_SCAN["ports"]
    top_ports: int = 100
    timing: str = DEFAULT_SCAN["timing"]
    timeout_sec: int = DEFAULT_SCAN["timeout_sec"]
    host_timeout_sec: int = DEFAULT_SCAN["host_timeout_sec"]
    skip_host_discovery: bool = DEFAULT_SCAN["skip_host_discovery"]
    port_count: int = 0

    def describe(self) -> dict:
        p = PROFILES[self.profile]
        return {"profile": p.name, "ports": self.ports if p.uses_port_list else f"top {self.top_ports}",
                "timing": self.timing, "timeout_sec": self.timeout_sec, "host_timeout_sec": self.host_timeout_sec,
                "skip_host_discovery": self.skip_host_discovery, "port_count": self.port_count}


def build_config(target: TargetCheck, profile: str, ports: str = "", top_ports: int = 100, timing: str = "T3",
                 timeout_sec: int = 300, host_timeout_sec: int | None = None,
                 skip_host_discovery: bool = True) -> ScanConfig:
    """Validate every user choice and return a ScanConfig (raises ScanConfigError)."""
    if not target.ok:
        raise ScanConfigError(target.message)
    if profile not in PROFILES:
        raise ScanConfigError(f"Unknown scan type '{profile}'.")
    prof = PROFILES[profile]
    if timing not in TIMING_CHOICES:
        raise ScanConfigError("Timing must be T2, T3 or T4.")
    try:
        timeout_sec = int(timeout_sec)
    except (TypeError, ValueError) as exc:
        raise ScanConfigError("Timeout must be a whole number of seconds.") from exc
    if not TIMEOUT_LIMITS[0] <= timeout_sec <= TIMEOUT_LIMITS[1]:
        raise ScanConfigError(f"Timeout must be between {TIMEOUT_LIMITS[0]} and {TIMEOUT_LIMITS[1]} seconds.")
    host_timeout_sec = int(host_timeout_sec or max(timeout_sec - 10, 10))
    host_timeout_sec = min(host_timeout_sec, timeout_sec)
    port_spec, count = "", 0
    if prof.uses_port_list:
        ranges, err = parse_ports(ports)
        if err:
            raise ScanConfigError(err)
        port_spec, count = normalise_ports(ranges), count_ports(ranges)
    else:
        if int(top_ports) not in TOP_PORT_CHOICES:
            raise ScanConfigError(f"Top-ports must be one of {TOP_PORT_CHOICES}.")
        count = int(top_ports)
    return ScanConfig(target, profile, port_spec, int(top_ports), timing, timeout_sec, host_timeout_sec,
                      bool(skip_host_discovery), count)


def build_arguments(cfg: ScanConfig, xml_path: Path) -> list[str]:
    """The Nmap options (without the program name), in a fixed safe order."""
    prof = PROFILES[cfg.profile]
    args = list(prof.nmap_args)
    if prof.uses_port_list:
        args += ["-p", cfg.ports]
    else:
        args += ["--top-ports", str(cfg.top_ports)]
    args += [f"-{cfg.timing}", "--max-retries", "2", "--host-timeout", f"{cfg.host_timeout_sec}s", "--reason",
             "--stats-every", "2s", "-oX", str(xml_path)]
    # -Pn ("treat the host as up") helps with lab VMs that block ping, but for a whole range it would
    # port-scan every empty address, so ranges always use normal host discovery.
    if cfg.skip_host_discovery and cfg.target.kind != "cidr":
        args.append("-Pn")
    if ":" in cfg.target.target:
        args.append("-6")
    args.append(cfg.target.target)
    validate_arguments(args, cfg.target.target)
    return args


def validate_arguments(args: list[str], target: str) -> None:
    """Last line of defence: refuse anything not on the allowlist."""
    if not args or args[-1] != target:
        raise ScanConfigError("The target must be the last argument.")
    i = 0
    body = args[:-1]
    while i < len(body):
        a = body[i]
        if any(a == f or a.startswith(f + "=") for f in FORBIDDEN_PATTERNS):
            raise ScanConfigError(f"Option '{a}' is not allowed.")
        if a not in ALLOWED_FLAGS:
            raise ScanConfigError(f"Option '{a}' is not on the allowlist.")
        if a in FLAGS_WITH_VALUE:
            if i + 1 >= len(body):
                raise ScanConfigError(f"Option '{a}' needs a value.")
            value = body[i + 1]
            ok = {
                "-p": re.fullmatch(r"[0-9,\-]+", value),
                "--top-ports": value in {str(n) for n in TOP_PORT_CHOICES},
                "--host-timeout": re.fullmatch(r"[0-9]{1,5}s", value),
                "--max-retries": value in {"0", "1", "2", "3"},
                "--stats-every": re.fullmatch(r"[0-9]{1,3}s", value),
                "-oX": value.lower().endswith(".xml") and not value.startswith("-"),
            }[a]
            if not ok:
                raise ScanConfigError(f"Invalid value '{value}' for {a}.")
            i += 2
        else:
            i += 1
    if not re.fullmatch(r"[A-Za-z0-9.:/\-]+", target) or target.startswith("-"):
        raise ScanConfigError("Invalid target.")


# ---------------------------------------------------------------------------
# Running a scan
# ---------------------------------------------------------------------------
PROGRESS_RE = re.compile(r"About\s+([0-9.]+)%\s+done(?:.*?\(([^)]*)\))?")
PHASE_RE = re.compile(r"(Connect Scan|Service scan|OS detection|SYN Stealth Scan|Ping Scan|NSE)\s+Timing", re.I)


@dataclass
class ScanJob:
    """A scan running in the background. The dashboard polls ``status()``."""
    config: ScanConfig
    nmap_cmd: list[str] | None = None
    scan_id: str = field(default_factory=lambda: datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6])
    xml_path: Path | None = None
    command_line: str = ""
    state: str = "pending"          # pending | running | completed | failed | stopped | timeout
    progress: float = 0.0
    phase: str = "Starting"
    started_at: float | None = None
    finished_at: float | None = None
    error: str | None = None
    nmap_version: str | None = None
    stderr: str = ""
    result: ParsedScan | None = None
    log: list[str] = field(default_factory=list)
    _proc: subprocess.Popen | None = None
    _thread: threading.Thread | None = None
    _stop_requested: bool = False

    # ------------------------------------------------------------------
    def start(self, output_dir: Path = SCAN_DIR) -> "ScanJob":
        cmd = self.nmap_cmd
        if cmd is None:
            path, _ = find_nmap()
            if not path:
                self.state, self.error = "failed", "Nmap is not installed or not found (see README, 'Nmap setup')."
                return self
            cmd = [path]
        info = get_nmap_info(self.nmap_cmd)
        self.nmap_version = info.version
        if PROFILES[self.config.profile].requires_admin and not info.is_admin:
            self.state = "failed"
            self.error = ("OS detection needs Administrator rights. Close the app, open the terminal with "
                          "'Run as administrator' and start it again - or choose another scan type.")
            return self
        output_dir.mkdir(parents=True, exist_ok=True)
        safe_target = re.sub(r"[^A-Za-z0-9.-]", "_", self.config.target.target)
        self.xml_path = output_dir / f"scan_{self.scan_id}_{safe_target}.xml"
        args = build_arguments(self.config, self.xml_path)
        self.command_line = "nmap " + " ".join(args)
        self.started_at = time.time()
        self.state = "running"
        try:
            self._proc = subprocess.Popen(list(cmd) + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                          text=True, bufsize=1, creationflags=no_window(), shell=False)
        except OSError as exc:
            self.state, self.error = "failed", f"Could not start Nmap: {exc}"
            self.finished_at = time.time()
            return self
        self._thread = threading.Thread(target=self._watch, daemon=True)
        self._thread.start()
        return self

    def _watch(self) -> None:
        proc = self._proc
        timer = threading.Timer(self.config.timeout_sec, self._on_timeout)
        timer.daemon = True
        timer.start()
        try:
            for line in proc.stdout:            # type: ignore[union-attr]
                line = line.rstrip()
                if not line:
                    continue
                self.log.append(line)
                self.log = self.log[-200:]
                m = PROGRESS_RE.search(line)
                if m:
                    self.progress = min(float(m.group(1)), 99.0)
                ph = PHASE_RE.search(line)
                if ph:
                    self.phase = ph.group(1)
            proc.wait()
            self.stderr = (proc.stderr.read() if proc.stderr else "")[-4000:]
        finally:
            timer.cancel()
        self._finish(proc.returncode)

    def _on_timeout(self) -> None:
        if self._proc and self._proc.poll() is None:
            self.state = "timeout"
            self._terminate()

    def _terminate(self) -> None:
        try:
            self._proc.terminate()               # type: ignore[union-attr]
            self._proc.wait(timeout=5)           # type: ignore[union-attr]
        except (subprocess.TimeoutExpired, OSError):
            try:
                self._proc.kill()                # type: ignore[union-attr]
            except OSError:
                pass

    def stop(self) -> None:
        """Stop a running scan; any ports found so far are kept."""
        if self.state == "running" and self._proc and self._proc.poll() is None:
            self._stop_requested = True
            self.state = "stopped"
            self._terminate()
        if self._thread:
            self._thread.join(timeout=10)

    def _finish(self, returncode: int | None) -> None:
        self.finished_at = time.time()
        try:
            if self.xml_path and self.xml_path.exists() and self.xml_path.stat().st_size > 0:
                self.result = parse_nmap_xml(self.xml_path)
        except NmapXMLError as exc:
            self.error = f"Could not read Nmap's results: {exc}"
        if self.state in ("stopped", "timeout"):
            reason = "stopped by the user" if self.state == "stopped" else \
                f"stopped after the {self.config.timeout_sec}s timeout"
            self.error = f"Scan {reason}. " + ("Partial results are shown." if self.result and self.result.hosts
                                               else "No results were saved.")
            return
        if returncode != 0:
            self.state = "failed"
            self.error = friendly_nmap_error(self.stderr, returncode)
            return
        if self.result is None:
            self.state = "failed"
            self.error = self.error or "Nmap finished but wrote no XML results."
            return
        self.state = "completed"
        self.progress = 100.0
        self.phase = "Done"

    # ------------------------------------------------------------------
    def wait(self, timeout: float | None = None) -> "ScanJob":
        if self._thread:
            self._thread.join(timeout)
        return self

    def is_running(self) -> bool:
        return self.state == "running"

    def status(self) -> dict:
        end = self.finished_at or time.time()
        return {"scan_id": self.scan_id, "state": self.state, "progress": round(self.progress, 1),
                "phase": self.phase, "elapsed_sec": round(end - self.started_at, 1) if self.started_at else 0.0,
                "error": self.error, "command": self.command_line, "last_lines": self.log[-5:]}


def friendly_nmap_error(stderr: str, returncode: int | None) -> str:
    text = (stderr or "").lower()
    if "requires root privileges" in text or "dnet: failed to open device" in text or "administrator" in text:
        return ("Nmap needs Administrator rights for this scan type (OS detection). Run the terminal as "
                "Administrator, or choose a scan type without OS detection.")
    if "failed to resolve" in text:
        return "Nmap could not resolve the target hostname."
    if "npcap" in text or "winpcap" in text:
        return "Nmap could not use Npcap. Reinstall Nmap with the Npcap option ticked (see README)."
    return f"Nmap exited with code {returncode}: {(stderr or '').strip()[-400:] or 'no error message'}"


def run_scan(config: ScanConfig, nmap_cmd: list[str] | None = None, output_dir: Path = SCAN_DIR) -> ScanJob:
    """Run a scan and wait for it to finish (used by tests and scripts)."""
    job = ScanJob(config, nmap_cmd=nmap_cmd).start(output_dir)
    return job.wait(config.timeout_sec + 30)


__all__ = ["PROFILES", "ScanConfig", "ScanJob", "ScanConfigError", "build_config", "build_arguments",
           "validate_arguments", "run_scan", "IS_WINDOWS"]
