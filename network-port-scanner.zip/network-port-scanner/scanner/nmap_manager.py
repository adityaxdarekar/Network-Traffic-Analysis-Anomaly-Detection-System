"""
Locate the installed Nmap program and report its version and capabilities.

Nmap itself is the scanning engine; this project never re-implements or
simulates scanning.
"""

from __future__ import annotations

import ctypes
import os
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

IS_WINDOWS = platform.system() == "Windows"

WINDOWS_NMAP_PATHS = [
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Nmap" / "nmap.exe",
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Nmap" / "nmap.exe",
]


@dataclass
class NmapInfo:
    installed: bool
    path: str | None
    version: str | None
    in_path: bool
    is_admin: bool
    npcap_installed: bool | None
    platform: str
    error: str | None = None

    @property
    def can_os_detect(self) -> bool:
        """OS detection (-O) needs raw packets: Administrator on Windows (with Npcap), root elsewhere."""
        return self.installed and self.is_admin


def no_window() -> int:
    """Prevent a console window flashing up on Windows."""
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if IS_WINDOWS else 0


def find_nmap() -> tuple[str | None, bool]:
    """Return (path to nmap, found via PATH?). Checks NMAP_PATH, PATH, then the Windows install folders."""
    env = os.environ.get("NMAP_PATH")
    if env and Path(env).is_file():
        return env, False
    found = shutil.which("nmap")
    if found:
        return found, True
    if IS_WINDOWS:
        for candidate in WINDOWS_NMAP_PATHS:
            if candidate.is_file():
                return str(candidate), False
    return None, False


def parse_version(output: str) -> str | None:
    """'Nmap version 7.95 ( https://nmap.org )' -> '7.95'"""
    m = re.search(r"Nmap version\s+([0-9][0-9A-Za-z.\-]*)", output or "")
    return m.group(1) if m else None


def is_admin() -> bool:
    try:
        if IS_WINDOWS:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())   # type: ignore[attr-defined]
        return os.geteuid() == 0
    except (AttributeError, OSError):
        return False


def npcap_installed() -> bool | None:
    if not IS_WINDOWS:
        return None
    return (Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "Npcap").exists()


def get_nmap_info(nmap_cmd: list[str] | None = None) -> NmapInfo:
    """
    Detect Nmap. ``nmap_cmd`` overrides the command (used by the unit tests
    with a stand-in script).
    """
    if nmap_cmd:
        path, in_path = nmap_cmd[-1], False
        cmd = list(nmap_cmd)
    else:
        path, in_path = find_nmap()
        cmd = [path] if path else None
    base = dict(is_admin=is_admin(), npcap_installed=npcap_installed(),
                platform=f"{platform.system()} {platform.release()}")
    if not cmd:
        return NmapInfo(False, None, None, False, error="Nmap was not found. Install it from https://nmap.org/download "
                        "(see README, 'Nmap setup').", **base)
    try:
        proc = subprocess.run(cmd + ["--version"], capture_output=True, text=True, timeout=20,
                              creationflags=no_window())
    except (OSError, subprocess.SubprocessError) as exc:
        return NmapInfo(False, path, None, in_path, error=f"Nmap could not be started: {exc}", **base)
    version = parse_version(proc.stdout)
    if proc.returncode != 0 or not version:
        return NmapInfo(False, path, None, in_path, error=f"Unexpected output from 'nmap --version': "
                        f"{(proc.stdout + proc.stderr).strip()[:200]}", **base)
    return NmapInfo(True, path, version, in_path, **base)
