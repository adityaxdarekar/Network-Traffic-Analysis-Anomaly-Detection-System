# Network Port Scanner and Service Detection System Using Nmap and Python
### Project Documentation

| | |
|---|---|
| **Project type** | Cybersecurity - defensive network security assessment |
| **Platform** | Python 3.11+, Nmap, Windows 10/11 (also Linux/macOS) |
| **Version** | 1.0.0 |
| **Student** | *(name, roll number, department)* |
| **Guide** | *(guide's name)* |
| **Institution** | *(college, academic year)* |

---

## Abstract
Unnecessary or poorly secured network services are a common entry point for attackers, yet many users do
not know which services their machines expose. Nmap is the standard open-source tool for discovering open
ports and identifying services, but its command-line interface and raw output are difficult for beginners
and offer many options that are unsafe in inexperienced hands. This project develops a Python application
that drives Nmap safely and turns its results into an explainable security assessment. Targets are
validated (localhost by default, private lab networks only unless explicitly authorised), scans are chosen
from five fixed profiles - TCP connect, service/version detection, selected ports, common ports and
optional OS detection - and every Nmap argument is checked against an allowlist before execution without a
shell. Nmap's XML output is parsed into structured port, service and host data; a rule-based risk analyser
backed by a configurable port reference database reports exposure findings from Informational to Critical,
distinguishing version observations from confirmed vulnerabilities and never inventing CVEs. Results are
stored in SQLite, explored in a ten-page Streamlit dashboard, compared across scans and exported as PDF,
CSV, XML and text reports. The implementation was verified with 116 automated tests, including synthetic
Nmap XML fixtures, a stand-in Nmap executable for the process-control logic, and two real-Nmap localhost
tests that run on a machine with Nmap installed.

**Keywords:** port scanning, service detection, Nmap, vulnerability management, attack surface, network
security assessment, Python, Streamlit.

## 1. Introduction
A computer communicates through numbered TCP and UDP ports; each listening port belongs to a program (a web
server, a database, remote desktop ...). Every reachable service increases the *attack surface*: it must be
configured securely, patched and monitored. Port scanning is therefore a basic defensive activity: an
administrator scans their own systems to verify that only intended services are reachable.

Nmap ("Network Mapper") is the most widely used open-source scanner. It can determine port states, identify
services and versions (`-sV`) and fingerprint operating systems (`-O`). This project builds a guided,
safety-first application around Nmap that a beginner can use and explain, while keeping Nmap as the real
scanning engine.

## 2. Problem Statement
* Beginners do not know which Nmap options are appropriate, and some options (stealth scans, scripts,
  aggressive timing) can be intrusive or unsafe.
* Raw Nmap output lists ports and versions but does not explain *why* an exposed service matters or what to
  do about it.
* Results of different scans are not easily stored, compared or reported.
* Misusing a scanner against systems one is not authorised to test is unethical and can be illegal.

**Problem:** build an application that lets an inexperienced user scan authorised lab machines safely with
Nmap, understand the results through transparent rules, track changes over time and produce professional
reports - without exaggerating findings into unverified vulnerabilities.

## 3. Objectives
1. Detect and integrate the installed Nmap, reporting its version and permissions.
2. Validate targets and restrict scanning to localhost and private lab addresses by default.
3. Implement TCP connect, service/version, selected-port, common-port and optional OS-detection scans.
4. Parse Nmap XML into port, service, version and host information.
5. Classify ports as Open, Closed, Filtered, Open|Filtered or Unknown.
6. Assess exposure with configurable rules and clear severities.
7. Present results in an interactive dashboard with search, filters and comparisons.
8. Persist scans in SQLite and generate PDF/CSV/XML/TXT reports.

## 4. Existing System
| Approach | Strengths | Limitations |
|---|---|---|
| Nmap command line | Powerful, accurate, free | Many options incl. intrusive ones; text output; no risk explanation, history or reports |
| Zenmap (Nmap GUI) | Visual, saves scans | Exposes all options including intrusive ones; no rule-based risk assessment or PDF reports |
| Commercial vulnerability scanners | Comprehensive vulnerability checks, reporting | Costly, complex; active vulnerability testing is beyond a beginner's lab scope |
| Online port-check websites | Simple | Only test the public IP, few ports, third-party sees results |

## 5. Proposed System
A Python/Streamlit application in which:
* the user chooses a **scan profile**, never raw options;
* the **target validator** enforces the authorisation policy;
* the **scan engine** runs Nmap in the background with allowlisted arguments, progress, stop and timeout;
* the **XML parser** converts Nmap output into structured data;
* **analysers** classify ports, describe services and assess exposure with editable reference data;
* results are **stored, compared and reported**.

**Advantages:** safe defaults, explainable findings, honest wording (observations vs. vulnerabilities),
history and comparison, professional reports, works offline, free.

## 6. System Architecture
```
User ──► Streamlit dashboard (10 pages)
              │ target, profile, ports, timeout
              ▼
     Target validator ──(blocked)──► error message
              │ allowed
              ▼
     Scan engine: profile → allowlisted argument list → subprocess (no shell) ──► Nmap ──► XML file
              │ progress / stop / timeout                                         │
              ▼                                                                   ▼
     XML parser ◄─────────────────────────────────────────────────────────────────┘
              ▼
     Port analyzer → Service analyzer → Risk analyzer ◄── data/common_ports.json, data/version_reference.json
              ▼
     ScanResult ──► SQLite (scans, ports, findings, reports)
              ├──► Dashboard pages (overview, ports, services, findings, history)
              └──► Reports (PDF, CSV, Nmap XML, TXT, ZIP)
```

### Database design
| Table | Columns (main) |
|---|---|
| `scans` | scan_id (PK), target, target_scope, scan_type, scan_config, command, started_at, finished_at, duration, nmap_version, status, error, hosts_up, port-state counts, services, findings, severity_json, xml_path |
| `ports` | scan_id (FK), host, port, protocol, state, state_raw, reason, service, product, version, extrainfo, confidence, method |
| `findings` | scan_id (FK), finding_id, rule, finding_type, severity, title, host, port, service, observed_version, explanation, risk, mitigation, evidence |
| `reports` | scan_id (FK), report_type, path, created_at |

## 7. Hardware Requirements
| Component | Minimum |
|---|---|
| Processor | Any dual-core x86-64 |
| RAM | 4 GB |
| Disk | 500 MB free |
| Network | Any adapter; a host-only virtual network is recommended for lab targets |

## 8. Software Requirements
| Software | Version |
|---|---|
| Windows 10/11 (or Linux/macOS) | - |
| Python | 3.11+ |
| Nmap (with Npcap on Windows) | current stable release |
| streamlit, plotly, pandas, reportlab, matplotlib, defusedxml, pytest, pypdf | see requirements.txt |
| Optional lab | VirtualBox/VMware with a test VM on a host-only network |

## 9. Methodology
1. **Environment inspection** - Python version, Nmap availability.
2. **Nmap integration** - detection, version parsing, permission check.
3. **Target validation and scan engine** - validation policy, profiles, argument allowlist, background
   execution, progress parsing (`--stats-every`), stop and timeout.
4. **Port and service analysis** - XML parsing, state classification, service identification quality.
5. **Risk assessment** - port reference database, version reference, contextual adjustments.
6. **Dashboard** - ten pages with KPIs, charts, filters and drill-down.
7. **Database** - SQLite persistence and comparison.
8. **Reporting** - PDF, CSV, XML, TXT.
9. **Testing** - synthetic fixtures, stand-in Nmap, real localhost tests, dashboard smoke tests.
10. **Documentation and demonstration preparation.**

### Scan techniques used
* **TCP connect scan (`-sT`)** - the operating system's normal `connect()` call is used for each port.
  SYN-ACK → open, RST → closed, no reply → filtered. It needs no special privileges and completes the
  handshake (so it is logged by the target - appropriate for authorised testing).
* **Service/version detection (`-sV`)** - Nmap sends probes to open ports and matches responses against its
  `nmap-service-probes` database, reporting product, version, extra info and a confidence value.
* **OS detection (`-O`)** - TCP/IP stack fingerprinting; needs raw packets (Administrator/root), and is a
  best-effort guess.
* Deliberately **excluded**: SYN "stealth" and other raw scans (-sS/-sN/-sF/-sX), fragmentation/decoys
  /spoofing, NSE scripts, aggressive timing (-T5) and any exploitation or DoS behaviour.

## 10. Implementation
### 10.1 Safe command construction
```python
PROFILES = {"tcp_connect": ("-sT",), "service": ("-sT", "-sV"), "selected": ("-sT", "-sV"),
            "common": ("-sT", "-sV"), "os_detection": ("-sT", "-sV", "-O", "--osscan-limit")}
args = [*profile, "-p", "22,80,443", "-T3", "--max-retries", "2", "--host-timeout", "240s",
        "--reason", "--stats-every", "2s", "-oX", xml_path, "-Pn", "127.0.0.1"]
validate_arguments(args, target)          # every flag must be in ALLOWED_FLAGS, values pattern-checked
subprocess.Popen([nmap_path] + args, shell=False, ...)
```
The target string can only contain characters of an IP, CIDR or hostname and may not start with `-`, so it
can never be interpreted as an option; the list form of `Popen` means no shell ever parses it.

### 10.2 Background scanning
`ScanJob` starts Nmap, reads its output line by line in a thread, extracts "About 45.30% done" progress
lines, enforces an overall timeout with a timer, and supports stopping. Interrupted scans leave unfinished
XML; the parser closes open tags so ports found so far are still reported (marked partial).

### 10.3 XML parsing
`defusedxml` parses the file safely (entity declarations rejected). For each host the parser reads
addresses, MAC vendor, hostnames, status, each `<port>` with `<state>` and `<service>` (name, product,
version, extrainfo, method, conf, tunnel, CPE), the `<extraports>` summaries (e.g. 995 closed ports) and
OS matches.

### 10.4 Risk rules
| Rule | Logic |
|---|---|
| E1 | Open port listed in `common_ports.json` → finding with the reference severity, risk and mitigation; clear-text protocols flagged as "Unencrypted service" (severity lowered if Nmap saw TLS) |
| E2 | Plain HTTP on a port not in the reference → Low |
| E3 | Open port whose service is unidentified/guessed → Informational |
| E0 | Other identified services → Informational |
| V1 | Product version older than `version_reference.json` → Medium *version observation*, explicitly not a confirmed vulnerability |
| A1 | ≥ 15 open ports on one host → Low attack-surface finding |
| Context | Expected ports → Informational; localhost scans lowered one level with an explanation |

## 11. Module Descriptions
| Module | Responsibility |
|---|---|
| `scanner/nmap_manager.py` | Locate Nmap (PATH, NMAP_PATH, Windows folders), version, admin rights, Npcap |
| `scanner/target_validator.py` | Target/port validation and scope policy |
| `scanner/scan_engine.py` | Profiles, config validation, argument allowlist, background ScanJob |
| `scanner/xml_parser.py` | Safe Nmap XML parsing incl. truncated files |
| `analyzer/port_analyzer.py` | State classification, port table, counts incl. extraports, per-host summary |
| `analyzer/service_analyzer.py` | Service table, identification quality, encryption, categories |
| `analyzer/risk_analyzer.py` | Rule-based findings and severities |
| `analyzer/assessment.py` | Builds the single ScanResult from a scan, an import or history |
| `database/db_manager.py` | SQLite schema, save/list/get/delete, totals, comparison, error handling |
| `reports/pdf_generator.py` | ReportLab report with TOC, charts, tables, page numbers |
| `reports/export_manager.py` | CSV, XML, TXT, ZIP exports with timestamped names |
| `dashboard/*` | Overview, New Scan, Scan Configuration, Port Analysis, Service Detection, Security Findings, Scan History, Reports, Settings, About |
| `data/*.json` | Editable port and version reference databases |

## 12. Results
### 12.1 Verification with synthetic Nmap XML fixtures
The test fixtures in `tests/fixtures/` are hand-written in Nmap's XML format (they are **not** real scans).
Analysing them with default settings gives:

| Fixture | Ports scanned | Open | Closed | Filtered | Services | Findings |
|---|---|---|---|---|---|---|
| localhost_service.xml | 1,025 | 4 | 1,020 | 1 | 4 | 4 (3 Informational, 1 Low) |
| lab_risky.xml | 30,000 | 16 | 29,981 | 1 | 16 | 22 (1 Critical, 6 High, 10 Medium, 4 Low, 1 Informational) |
| no_open_ports.xml | 1,000 | 0 | 1,000 | 0 | 0 | 0 |
| multi_host.xml (2 hosts) | 200 | 3 | 99 | 98 | 3 | 3 (1 Medium, 2 Low) |
| truncated_scan.xml (stopped scan) | 29,990 | 6 | 29,981 | 1 | 6 | 8 (partial results flagged) |
| host_down.xml | 0 | 0 | 0 | 0 | 0 | 0 |

These confirm that counts include Nmap's summarised ports, that risky services (unauthenticated Docker
API, Telnet, FTP, Redis, MongoDB ...) are ranked above benign ones (HTTPS), that old versions appear as
*observations*, and that modern versions and closed/filtered ports produce no findings.

### 12.2 Real scans
*To be completed on the demonstration laptop:* run a Service & Version Detection scan of `127.0.0.1` and of
a lab VM, then record the results here (target, open ports, services, findings) and insert screenshots
from `screenshots/`. Do not copy the fixture numbers above as real results.

| Target | Scan type | Open ports | Services identified | Findings | Duration |
|---|---|---|---|---|---|
| 127.0.0.1 | | | | | |
| *(lab VM)* | | | | | |

## 13. Testing
116 automated tests (pytest). On the development machine 114 passed and 2 were skipped because Nmap was not
installed there; those 2 run real scans of 127.0.0.1 and execute automatically wherever Nmap is installed.

| # | Required test | Implementation | Result (development machine) |
|---|---|---|---|
| 1 | Nmap installation detection | stand-in Nmap detected with version; missing Nmap reported; version parsing; NMAP_PATH | Pass |
| 2 | Target IP validation | 16 scope cases + 13 invalid/injection inputs; public needs setting + confirmation; /24 limit | Pass |
| 3 | Localhost scanning | real `nmap -sT` of 127.0.0.1 against a temporary listener | Skipped (no Nmap) - runs on laptop |
| 4 | TCP port detection | open listener port detected, closed port counted (real Nmap); engine run with stand-in | Pass / laptop |
| 5 | Service version detection | real `-sV` identifies the test SSH banner; fixture version fields exact | Pass / laptop |
| 6 | XML parsing | all fixtures, OS/MAC, multi-host, truncated, error, empty, non-Nmap, entity attack | Pass |
| 7 | Port state classification | all Nmap states incl. open\|filtered and unfiltered; counts with extraports | Pass |
| 8 | Security risk analysis | severities, types, version observations, no CVEs/"confirmed", localhost downgrade, expected ports | Pass |
| 9 | Database storage | save/replace/list/get/delete, compare scans, reopen from XML, error handling | Pass |
| 10 | PDF report generation | all sections and real values present; edge cases (no ports, host down, partial) | Pass |
| 11 | CSV export | ports/findings CSV content; TXT, XML copy, ZIP, safe filenames | Pass |
| 12 | Invalid scan handling | Nmap error exit, admin required, missing Nmap, stop, timeout, unsafe arguments rejected | Pass |

Additional: a headless smoke test runs all ten dashboard pages with every fixture, the full New Scan flow
(start → finish → saved → PDF), confirmation and public-target blocking, XML import and rejection.

**Defects found and fixed during testing:** an empty input was treated as a file path; a malformed
`<nmaprun>` fragment needed defined behaviour (treated as partial output, while mismatched tags raise an
error); export file names could contain `..`; imported range scans showed the first host instead of the
range; the attack-surface evidence string raised a `TypeError`.

## 14. Limitations
* TCP scanning only; UDP services are not assessed.
* Accuracy of service, version and OS detection depends on Nmap's databases; firewalls can hide services.
* A scan reflects reachability from one vantage point at one moment.
* The assessment is exposure-based; it does not verify vulnerabilities, and version references must be
  maintained manually.
* Dashboard rendering was verified headlessly during development; the final visual check is done on the
  demonstration laptop.

## 15. Future Scope
* Optional UDP scanning of a few common ports (with administrator rights).
* Integration with a vulnerability database (e.g. matching CPEs against the NVD) clearly labelled as
  candidate matches.
* Scheduled scans with e-mail alerts on newly opened ports.
* TLS configuration checks (certificate expiry, protocol versions) for HTTPS services.
* Multi-user access control and role-based authorisation records.

## 16. Conclusion
The project delivers a working, safety-focused port scanning and service detection system built on Nmap.
It restricts scanning to authorised targets, executes only allowlisted Nmap options, parses Nmap's XML
reliably, classifies ports and services, and explains exposure with transparent and configurable rules
while carefully distinguishing observations from confirmed vulnerabilities. History, comparison and
professional reports make it useful for repeated lab assessments and for demonstrating security
improvements, and the automated test suite documents how each requirement was verified.

## 17. References
1. G. Lyon, *Nmap Network Scanning: The Official Nmap Project Guide to Network Discovery and Security
   Scanning*, Insecure.Com LLC, 2009. Online reference guide: <https://nmap.org/book/man.html>
2. Nmap XML output format and DTD: <https://nmap.org/book/output-formats-xml-output.html>
3. W. Eddy (ed.), *Transmission Control Protocol (TCP)*, RFC 9293, IETF, 2022.
4. M. Cotton et al., *Internet Assigned Numbers Authority (IANA) Procedures for the Management of the Service
   Name and Transport Protocol Port Number Registry*, RFC 6335, IETF, 2011.
5. IANA Service Name and Transport Protocol Port Number Registry:
   <https://www.iana.org/assignments/service-names-port-numbers/>
6. K. Scarfone, M. Souppaya, A. Cody, A. Orebaugh, *Technical Guide to Information Security Testing and
   Assessment*, NIST SP 800-115, 2008.
7. K. Scarfone, W. Jansen, M. Tracy, *Guide to General Server Security*, NIST SP 800-123, 2008.
8. MITRE ATT&CK®, T1046 Network Service Discovery: <https://attack.mitre.org/techniques/T1046/>
9. Docker documentation, "Protect the Docker daemon socket": <https://docs.docker.com/engine/security/protect-access/>
10. Redis documentation, "Redis security": <https://redis.io/docs/latest/operate/oss_and_stack/management/security/>
11. Python documentation, `subprocess` - security considerations: <https://docs.python.org/3/library/subprocess.html>
12. defusedxml project: <https://pypi.org/project/defusedxml/>
13. Streamlit documentation: <https://docs.streamlit.io/> · ReportLab user guide: <https://docs.reportlab.com/>
