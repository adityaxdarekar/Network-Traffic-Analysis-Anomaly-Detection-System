"""
Port analysis: turn parsed Nmap results into a tidy table and state counts.

Nmap port states and what they mean (TCP connect scan):
    open            a program accepted the connection
    closed          the host answered but nothing listens there (connection refused)
    filtered        no answer - a firewall probably dropped the probe
    open|filtered   Nmap cannot tell which of the two it is
    anything else   (closed|filtered, unfiltered ...) is shown as "Unknown"
"""

from __future__ import annotations

import pandas as pd

from scanner.xml_parser import ParsedScan

STATE_LABELS = {"open": "Open", "closed": "Closed", "filtered": "Filtered", "open|filtered": "Open|Filtered"}
STATE_ORDER = ["Open", "Closed", "Filtered", "Open|Filtered", "Unknown"]

PORT_COLUMNS = ["host", "hostname", "port", "protocol", "state", "state_raw", "reason", "service", "product",
                "version", "extrainfo", "confidence", "method", "encrypted", "cpe"]


def classify_state(raw: str | None) -> str:
    """Map an Nmap state to one of: Open, Closed, Filtered, Open|Filtered, Unknown."""
    return STATE_LABELS.get((raw or "").strip().lower(), "Unknown")


def ports_dataframe(scan: ParsedScan) -> pd.DataFrame:
    """One row per port that Nmap listed individually (collapsed 'extraports' are only counted)."""
    rows = []
    for h in scan.hosts:
        for p in h.ports:
            rows.append({
                "host": h.address, "hostname": h.hostnames[0] if h.hostnames else "",
                "port": p.port, "protocol": p.protocol, "state": classify_state(p.state), "state_raw": p.state,
                "reason": p.reason, "service": p.service, "product": p.product, "version": p.version,
                "extrainfo": p.extrainfo, "confidence": p.confidence, "method": p.method,
                "encrypted": p.tunnel == "ssl" or p.service in ("https", "ssl", "imaps", "pop3s", "ldaps"),
                "cpe": ", ".join(p.cpe),
            })
    df = pd.DataFrame(rows, columns=PORT_COLUMNS)
    if not df.empty:
        df["port"] = df["port"].astype(int)
        df = df.sort_values(["host", "port"]).reset_index(drop=True)
    return df


def state_counts(scan: ParsedScan) -> dict[str, int]:
    """Counts per state INCLUDING the ports Nmap collapsed into <extraports>."""
    counts = {s: 0 for s in STATE_ORDER}
    for h in scan.hosts:
        for p in h.ports:
            counts[classify_state(p.state)] += 1
        for state, n in h.extraports.items():
            counts[classify_state(state)] += n
    return counts


def analyze_ports(scan: ParsedScan) -> dict:
    df = ports_dataframe(scan)
    counts = state_counts(scan)
    open_df = df[df["state"] == "Open"]
    per_host = []
    for h in scan.hosts:
        hc = {s: 0 for s in STATE_ORDER}
        for p in h.ports:
            hc[classify_state(p.state)] += 1
        for state, n in h.extraports.items():
            hc[classify_state(state)] += n
        per_host.append({"host": h.address, "hostname": ", ".join(h.hostnames), "status": h.status,
                         "mac": h.mac, "vendor": h.vendor, "os_guess": h.os_matches[0].name if h.os_matches else "",
                         "os_accuracy": h.os_matches[0].accuracy if h.os_matches else None,
                         **{k.lower(): v for k, v in hc.items()}})
    return {
        "ports": df,
        "open_ports": open_df.reset_index(drop=True),
        "state_counts": counts,
        "total_scanned": sum(counts.values()),
        "open_count": counts["Open"],
        "hosts": pd.DataFrame(per_host),
        "hosts_up": scan.hosts_up,
        "hosts_down": scan.hosts_down,
    }
