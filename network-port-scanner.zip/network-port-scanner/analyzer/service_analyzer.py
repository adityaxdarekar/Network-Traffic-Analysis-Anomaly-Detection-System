"""
Service analysis: describe what is running on each open port.

Nmap's service detection (-sV) reports how it identified a service:
    method="probed"  Nmap talked to the service and matched its answer -> trustworthy
    method="table"   Nmap only looked the port number up in a table   -> a guess
plus a confidence value from 0-10. Both are shown so that a guess is never
presented as a fact. Versions are always exactly what Nmap reported.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import pandas as pd

from config import PORT_REFERENCE_FILE


# Protocols that are encrypted by design (others count as encrypted only if Nmap saw TLS on the port)
ENCRYPTED_PROTOCOLS = {"ssh", "https", "ssl", "imaps", "pop3s", "ldaps", "ftps", "ssl/http"}


@lru_cache(maxsize=4)
def load_port_reference(path: str = str(PORT_REFERENCE_FILE)) -> dict[int, dict]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return {int(k): v for k, v in data.get("ports", {}).items()}
    except (OSError, ValueError):
        return {}


def display_name(service: str, encrypted: bool) -> str:
    if not service:
        return "unknown"
    if service == "http" and encrypted:
        return "https"
    return service


def identification(method: str, confidence) -> str:
    if method == "probed":
        return "Probed (confirmed by Nmap)"
    if method == "table":
        return "Guessed from port number"
    return "Not identified"


def product_version(product: str, version: str) -> str:
    text = " ".join(x for x in (product, version) if x)
    return text or "Not reported"


def analyze_services(ports_df: pd.DataFrame, reference: dict[int, dict] | None = None) -> dict:
    reference = reference if reference is not None else load_port_reference()
    open_df = ports_df[ports_df["state"] == "Open"] if not ports_df.empty else ports_df
    cols = ["host", "port", "protocol", "service", "product", "version", "product_version", "extrainfo",
            "identification", "confidence", "encrypted", "category", "description", "cpe"]
    if open_df.empty:
        return {"services": pd.DataFrame(columns=cols), "service_counts": {}, "category_counts": {},
                "versions_identified": 0, "probed": 0, "guessed": 0, "encrypted": 0}
    rows = []
    for r in open_df.itertuples():
        ref = reference.get(int(r.port), {})
        rows.append({
            "host": r.host, "port": int(r.port), "protocol": r.protocol,
            "service": display_name(r.service, bool(r.encrypted)), "product": r.product, "version": r.version,
            "product_version": product_version(r.product, r.version), "extrainfo": r.extrainfo,
            "identification": identification(r.method, r.confidence), "confidence": r.confidence,
            "encrypted": bool(r.encrypted) or r.service in ENCRYPTED_PROTOCOLS,
            "category": ref.get("category", "Other"), "description": ref.get("service", ""), "cpe": r.cpe,
        })
    df = pd.DataFrame(rows, columns=cols)
    return {
        "services": df,
        "service_counts": df["service"].value_counts().to_dict(),
        "category_counts": df["category"].value_counts().to_dict(),
        "versions_identified": int((df["version"].fillna("") != "").sum()),
        "probed": int((df["identification"].str.startswith("Probed")).sum()),
        "guessed": int((df["identification"].str.startswith("Guessed")).sum()),
        "encrypted": int(df["encrypted"].sum()),
    }
