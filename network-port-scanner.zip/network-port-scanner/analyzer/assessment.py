"""
Combine one Nmap run into a single ``ScanResult`` used by the dashboard,
the database and the reports - so every number shown anywhere comes from the
same real scan data.
"""

from __future__ import annotations

import ipaddress
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import pandas as pd

from analyzer.port_analyzer import analyze_ports
from analyzer.risk_analyzer import analyze_risks, severity_counts
from analyzer.service_analyzer import analyze_services
from config import load_settings
from scanner.target_validator import classify_address
from scanner.xml_parser import ParsedScan, parse_nmap_xml


@dataclass
class ScanResult:
    scan_id: str
    target: str
    target_scope: str
    profile: str
    scan_config: dict
    command: str
    started_at: str
    finished_at: str
    duration_sec: float | None
    nmap_version: str
    xml_path: str
    status: str                  # completed | stopped | timeout | imported
    error: str | None
    parsed: ParsedScan
    ports: pd.DataFrame
    open_ports: pd.DataFrame
    hosts: pd.DataFrame
    state_counts: dict
    services: pd.DataFrame
    service_stats: dict
    findings: pd.DataFrame
    severity_counts: dict
    warnings: list[str] = field(default_factory=list)

    @property
    def summary(self) -> dict:
        return {
            "scan_id": self.scan_id, "target": self.target, "profile": self.profile, "status": self.status,
            "started_at": self.started_at, "duration_sec": self.duration_sec, "nmap_version": self.nmap_version,
            "hosts_up": self.parsed.hosts_up, "total_ports": sum(self.state_counts.values()),
            "open": self.state_counts["Open"], "closed": self.state_counts["Closed"],
            "filtered": self.state_counts["Filtered"], "open_filtered": self.state_counts["Open|Filtered"],
            "unknown": self.state_counts["Unknown"], "services": len(self.services),
            "versions_identified": self.service_stats.get("versions_identified", 0),
            "findings": len(self.findings), **{f"sev_{k.lower()}": v for k, v in self.severity_counts.items()},
        }


def _ts(epoch) -> str:
    return datetime.fromtimestamp(epoch).strftime("%Y-%m-%d %H:%M:%S") if epoch else ""


def target_scope_of(parsed: ParsedScan, target: str) -> str:
    """loopback/private/public based on the scanned addresses."""
    addrs = [h.address for h in parsed.hosts if h.address] or [target]
    scopes = set()
    for a in addrs:
        try:
            scopes.add(classify_address(ipaddress.ip_address(a.split("/")[0])))
        except ValueError:
            scopes.add("unknown")
    for s in ("public", "private", "loopback"):
        if s in scopes:
            return s
    return "unknown"


def build_result(parsed: ParsedScan, *, scan_id: str | None = None, target: str = "", profile: str = "",
                 scan_config: dict | None = None, command: str = "", nmap_version: str = "", xml_path: str = "",
                 status: str = "completed", error: str | None = None, settings: dict | None = None,
                 started: float | None = None, finished: float | None = None) -> ScanResult:
    settings = settings or load_settings()
    if not target:
        # For imported XML use the target from Nmap's own command line (keeps ranges such as /29 intact)
        last = parsed.args.split()[-1] if parsed.args.split() else ""
        target = last if last and not last.startswith("-") else (parsed.hosts[0].address if parsed.hosts else "")
    scope = target_scope_of(parsed, target)
    pa = analyze_ports(parsed)
    sa = analyze_services(pa["ports"])
    findings = analyze_risks(pa["ports"], settings, scope)
    started = started or parsed.start_time
    finished = finished or parsed.end_time
    duration = parsed.elapsed if parsed.elapsed is not None else (round(finished - started, 2)
                                                                  if started and finished else None)
    return ScanResult(
        scan_id=scan_id or datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6],
        target=target, target_scope=scope, profile=profile or "Imported Nmap XML",
        scan_config=scan_config or {"nmap_arguments": parsed.args}, command=command or parsed.args,
        started_at=_ts(started), finished_at=_ts(finished), duration_sec=duration,
        nmap_version=nmap_version or parsed.scanner_version, xml_path=str(xml_path), status=status, error=error,
        parsed=parsed, ports=pa["ports"], open_ports=pa["open_ports"], hosts=pa["hosts"],
        state_counts=pa["state_counts"], services=sa["services"], service_stats=sa, findings=findings,
        severity_counts=severity_counts(findings), warnings=list(parsed.warnings),
    )


def result_from_job(job, settings: dict | None = None) -> ScanResult:
    """Build a ScanResult from a finished ScanJob (scanner/scan_engine.py)."""
    if job.result is None:
        raise ValueError(job.error or "The scan produced no results.")
    return build_result(job.result, scan_id=job.scan_id, target=job.config.target.target,
                        profile=job.config.describe()["profile"], scan_config=job.config.describe(),
                        command=job.command_line, nmap_version=job.nmap_version or job.result.scanner_version,
                        xml_path=str(job.xml_path), status=job.state, error=job.error, settings=settings,
                        started=job.started_at, finished=job.finished_at)


def result_from_xml(path: str | Path, settings: dict | None = None) -> ScanResult:
    """Analyse an existing Nmap XML file (e.g. one produced by running nmap -oX yourself)."""
    parsed = parse_nmap_xml(Path(path))
    return build_result(parsed, xml_path=str(path), status="imported" if parsed.complete else "imported (partial)",
                        settings=settings)


def result_from_history(record: dict, settings: dict | None = None) -> ScanResult:
    """Re-open a stored scan by re-reading its saved Nmap XML (findings use the current settings)."""
    path = Path(record.get("xml_path") or "")
    if not path.is_file():
        raise ValueError("The Nmap XML file of this scan is no longer on disk, so it can only be viewed as stored "
                         "tables.")
    parsed = parse_nmap_xml(path)
    return build_result(parsed, scan_id=record["scan_id"], target=record["target"], profile=record["scan_type"],
                        scan_config=record.get("scan_config") or {}, command=record.get("command") or "",
                        nmap_version=record.get("nmap_version") or "", xml_path=str(path),
                        status=record.get("status") or "completed", error=record.get("error"), settings=settings)
