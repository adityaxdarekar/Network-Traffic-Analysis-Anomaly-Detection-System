"""
Rule-based security assessment of scan results.

Principles (from the project brief):
    * An open port is NOT automatically a vulnerability. Findings describe
      EXPOSURE ("this service is reachable, here is why that matters").
    * No CVEs or vulnerabilities are invented. Old version numbers produce a
      "Version observation" that must be verified - never a confirmed
      vulnerability (distributions often backport fixes).
    * Everything is configurable: data/common_ports.json (severity, risk and
      mitigation per port), data/version_reference.json, the "expected open
      ports" list and the localhost downgrade switch on the Settings page.

Rules:
    E1  Exposed service from the port reference database (remote access,
        databases, file sharing, administrative interfaces, clear-text
        protocols ...).
    E2  Unencrypted HTTP on a port not in the reference database.
    E3  Open port whose service Nmap could not identify (or only guessed).
    E0  Any other identified open service (Informational - part of the attack surface).
    V1  Version observation: product version older than a reference version.
    A1  Large attack surface: many open ports on one host.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path

import pandas as pd

from analyzer.service_analyzer import load_port_reference
from config import SEVERITY_ORDER, VERSION_REFERENCE_FILE

FINDING_COLUMNS = ["finding_id", "rule", "finding_type", "severity", "title", "host", "port", "protocol", "service",
                   "observed_version", "explanation", "risk", "mitigation", "evidence", "confirmed_vulnerability"]


@dataclass
class Finding:
    rule: str
    finding_type: str          # Exposed service | Unencrypted service | Unidentified service | Version observation | Attack surface
    severity: str
    title: str
    host: str
    port: int | None
    protocol: str
    service: str
    observed_version: str
    explanation: str
    risk: str
    mitigation: str
    evidence: str
    confirmed_vulnerability: bool = False      # always False: this tool does not confirm vulnerabilities
    finding_id: str = ""
    notes: list[str] = field(default_factory=list)


def lower(sev: str, levels: int = 1) -> str:
    return SEVERITY_ORDER[max(SEVERITY_ORDER.index(sev) - levels, 0)]


@lru_cache(maxsize=4)
def load_version_rules(path: str = str(VERSION_REFERENCE_FILE)) -> list[dict]:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8")).get("rules", [])
    except (OSError, ValueError):
        return []


def version_tuple(text: str) -> tuple[int, ...] | None:
    """'6.6.1p1 Ubuntu 2ubuntu2' -> (6, 6, 1); '9.6.0 - 9.6.2' -> (9, 6, 0); '' -> None"""
    m = re.match(r"\s*(\d+(?:\.\d+)*)", text or "")
    return tuple(int(x) for x in m.group(1).split(".")) if m else None


def is_older(observed: tuple[int, ...], reference: tuple[int, ...]) -> bool:
    n = max(len(observed), len(reference))
    return observed + (0,) * (n - len(observed)) < reference + (0,) * (n - len(reference))


def _evidence(row) -> str:
    parts = [f"state: {row.state_raw} ({row.reason})" if row.reason else f"state: {row.state_raw}"]
    if row.product or row.version:
        parts.append(f"Nmap reported: {' '.join(x for x in (row.product, row.version) if x)}")
    if row.extrainfo:
        parts.append(f"extra info: {row.extrainfo}")
    if row.method:
        conf = f", confidence {int(row.confidence)}/10" if row.confidence == row.confidence and row.confidence is not None else ""
        parts.append(f"identified by: {'probing the service' if row.method == 'probed' else 'port-number table (guess)'}{conf}")
    return "; ".join(parts)


def analyze_risks(ports_df: pd.DataFrame, settings: dict | None = None, target_scope: str = "",
                  reference: dict[int, dict] | None = None, version_rules: list[dict] | None = None) -> pd.DataFrame:
    """Return a DataFrame of findings (empty if there is nothing to report)."""
    settings = settings or {}
    reference = reference if reference is not None else load_port_reference()
    version_rules = version_rules if version_rules is not None else load_version_rules()
    expected = {int(p) for p in settings.get("expected_open_ports", [])}
    many_threshold = int(settings.get("many_open_ports_threshold", 15))
    localhost_downgrade = settings.get("localhost_downgrade", True) and target_scope == "loopback"

    findings: list[Finding] = []
    if ports_df is None or ports_df.empty:
        return pd.DataFrame(columns=FINDING_COLUMNS)
    open_ports = ports_df[ports_df["state"] == "Open"]

    for row in open_ports.itertuples():
        port = int(row.port)
        ref = reference.get(port)
        version = " ".join(x for x in (row.product, row.version) if x) or "not reported"
        svc = row.service or (ref or {}).get("service", "unknown")
        ev = _evidence(row)
        encrypted = bool(row.encrypted)

        # ---- E1: services in the reference database ----------------------
        if ref:
            sev = ref.get("severity", "Low")
            cleartext = ref.get("cleartext", False) and not encrypted
            ftype = "Unencrypted service" if cleartext else "Exposed service"
            explanation = (f"Port {port}/{row.protocol} is open and Nmap identified it as '{svc}'"
                           f"{' (identified only from the port number)' if row.method == 'table' else ''}. "
                           f"Reference: {ref.get('service')} - category {ref.get('category')}.")
            if ref.get("cleartext") and encrypted:
                sev = lower(sev)
                explanation += " Nmap saw TLS on this port, so traffic appears to be encrypted."
            findings.append(Finding("E1", ftype, sev, f"{ref.get('service')} open on port {port}", row.host, port,
                                    row.protocol, svc, version, explanation, ref.get("risk", ""),
                                    ref.get("mitigation", ""), ev))
        # ---- E2: clear-text HTTP elsewhere ------------------------------------
        elif row.service.startswith("http") and not encrypted and row.service not in ("https", "https-alt"):
            findings.append(Finding("E2", "Unencrypted service", "Low", f"Unencrypted HTTP on port {port}", row.host,
                                    port, row.protocol, svc, version,
                                    f"Port {port} serves plain HTTP (Nmap service '{row.service}'), which is not encrypted.",
                                    "Credentials or session cookies sent to this service can be intercepted on the "
                                    "network.", "Serve it over HTTPS, or restrict it to localhost if it is a local "
                                    "development or admin tool.", ev))
        # ---- E3: unidentified service ------------------------------------------
        elif row.method != "probed":
            findings.append(Finding("E3", "Unidentified service", "Informational",
                                    f"Unidentified service on port {port}", row.host, port, row.protocol, svc, version,
                                    f"Port {port} is open but its service was "
                                    f"{'only guessed from the port number' if row.method == 'table' else 'not identified'}"
                                    f"{'' if row.method else ' (run a Service & Version Detection scan)'}.",
                                    "Unknown listening programs enlarge the attack surface and may be unintended.",
                                    "Find the owning process (Windows: netstat -ano, then Task Manager › Details by "
                                    "PID; Linux: ss -ltnp) and stop it if it is not needed.", ev))
        else:
            findings.append(Finding("E0", "Exposed service", "Informational", f"{svc} on port {port}", row.host, port,
                                    row.protocol, svc, version,
                                    f"Port {port} is open running '{svc}' ({version}). It is not on the risky-services list.",
                                    "Every reachable service is part of the attack surface.",
                                    "Confirm the service is required and kept up to date.", ev))

        # ---- V1: version observations -----------------------------------------
        observed = version_tuple(row.version)
        if observed and row.product:
            for rule in version_rules:
                try:
                    if not re.search(rule["product_regex"], row.product, re.I):
                        continue
                except re.error:
                    continue
                ref_v = version_tuple(rule["below"])
                if ref_v and is_older(observed, ref_v):
                    findings.append(Finding(
                        "V1", "Version observation", "Medium",
                        f"Outdated version observed: {row.product} {row.version}", row.host, port, row.protocol, svc,
                        version,
                        f"Nmap reported {row.product} {row.version}, which is older than the reference version "
                        f"{rule['below']}. {rule['note']} This is a VERSION OBSERVATION, not a confirmed "
                        f"vulnerability: vendors (e.g. Linux distributions) often backport security fixes without "
                        f"changing the version number, and Nmap's version string can be imprecise.",
                        "Software that no longer receives security updates is likely to contain known, unpatched "
                        "weaknesses.",
                        f"Verify the exact version and patch level on the host. {rule.get('check', '')} "
                        f"Upgrade to a supported release if it is confirmed.", ev))
                    break

    # ---- A1: attack surface per host ------------------------------------------
    for host, g in open_ports.groupby("host"):
        if len(g) >= many_threshold:
            findings.append(Finding("A1", "Attack surface", "Low", f"{len(g)} open ports on {host}", host, None, "tcp",
                                    "multiple", "-",
                                    f"{len(g)} ports are open on this host (threshold {many_threshold}).",
                                    "Each additional service is another thing to patch and secure; unnecessary "
                                    "services are a common source of compromise.",
                                    "Review every open port, disable services that are not needed and firewall the "
                                    "rest to the hosts that need them.",
                                    "open ports: " + ", ".join(str(x) for x in sorted(g["port"].astype(int))[:40])))

    # ---- context adjustments ---------------------------------------------------
    for f in findings:
        if f.port in expected and f.rule != "V1":
            f.severity = "Informational"
            f.notes.append("Marked as an expected open port in Settings.")
        elif localhost_downgrade and f.rule in ("E1", "E2") and f.severity != "Informational":
            f.severity = lower(f.severity)
            f.notes.append("Seen on localhost: a scan of 127.0.0.1 cannot show whether the service is also reachable "
                           "from the network, so severity was lowered one level. Scan the machine's LAN address from "
                           "another lab host to check real exposure.")
    findings.sort(key=lambda f: (-SEVERITY_ORDER.index(f.severity), f.host, f.port or 0))
    for i, f in enumerate(findings, 1):
        f.finding_id = f"F-{i:03d}"
    if not findings:
        return pd.DataFrame(columns=FINDING_COLUMNS)
    df = pd.DataFrame([asdict(f) for f in findings])
    df["explanation"] = df.apply(lambda r: r["explanation"] + (" " + " ".join(r["notes"]) if r["notes"] else ""), axis=1)
    df["port"] = pd.to_numeric(df["port"], errors="coerce").astype("Int64")
    return df[FINDING_COLUMNS]


def severity_counts(findings: pd.DataFrame) -> dict[str, int]:
    counts = {s: 0 for s in SEVERITY_ORDER}
    if findings is not None and not findings.empty:
        for k, v in findings["severity"].value_counts().items():
            counts[k] = int(v)
    return counts
