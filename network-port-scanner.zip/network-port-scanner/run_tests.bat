@echo off
REM Runs the automated test suite.
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Run setup_windows.bat first.
  pause
  exit /b 1
)
venv\Scripts\python.exe -m pytest
pause
