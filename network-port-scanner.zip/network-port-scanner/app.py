"""
Network Port Scanner and Service Detection System - Streamlit entry point.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import APP_SHORT_TITLE, APP_TITLE, APP_VERSION  # noqa: E402
from dashboard import (about_page, new_scan, overview, port_analysis, reports_page, scan_config,  # noqa: E402
                       scan_history, security_findings, service_detection, settings_page)
from dashboard.common import get_result, get_settings  # noqa: E402
from dashboard.theme import CSS  # noqa: E402

PAGES = {
    "Dashboard Overview": ("📊", overview.render),
    "New Scan": ("🎯", new_scan.render),
    "Scan Configuration": ("🧩", scan_config.render),
    "Port Analysis": ("🔌", port_analysis.render),
    "Service Detection": ("🔎", service_detection.render),
    "Security Findings": ("🛡️", security_findings.render),
    "Scan History": ("🗂️", scan_history.render),
    "Reports": ("📄", reports_page.render),
    "Settings": ("⚙️", settings_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def main() -> None:
    st.set_page_config(page_title=APP_SHORT_TITLE, page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")
    st.markdown(CSS, unsafe_allow_html=True)
    get_settings()
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "New Scan"

    with st.sidebar:
        st.markdown(f"## 🛡️ {APP_SHORT_TITLE}")
        st.caption(f"{APP_TITLE} · v{APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        r = get_result()
        if r is not None:
            st.markdown(f"**Loaded scan:** `{r.target}`")
            st.caption(f"{r.profile} · {r.summary['open']} open · {len(r.findings)} findings")
        else:
            st.caption("No scan loaded.")
        st.caption("🔐 Scan only systems you own or are authorised to test.")

    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001 - one page bug must not take down the app
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException") for c in type(exc).__mro__):
            raise
        st.error(f"Something went wrong on this page: {exc.__class__.__name__}: {exc}")
        st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
