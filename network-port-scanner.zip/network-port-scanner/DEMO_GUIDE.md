# Demonstration Guide (≈ 10 minutes)

## Before the demo
1. Run `run_tests.bat` once - expect **116 passed** when Nmap is installed (the two real localhost scans run too).
2. Start the app: `run_app.bat` → <http://localhost:8501>. Check **New Scan** shows "✅ Nmap ... found".
3. Optional - give your own machine a predictable extra service for the demo. In a second terminal:
   ```
   python -m http.server 8000 --bind 127.0.0.1
   ```
   This opens port 8000 (plain HTTP) on localhost only. Press Ctrl+C after the demo to close it again.
4. Optional lab VM: a VirtualBox/VMware VM on a **host-only** network (e.g. 192.168.56.101) that you own.

## 1. Context (1 min)
"Every open port is a door. Admins scan their own machines to check only the intended doors are open. This
tool drives the real Nmap scanner safely, explains what it finds and documents it." Show **About Project**.

## 2. Safety first (1 min)
On **New Scan** type `8.8.8.8` → "Target not allowed: public Internet targets are blocked". Type
`127.0.0.1; whoami` → invalid characters. Then show **Scan Configuration → Safety rules**: allowlisted
options, no shell, no stealth scans or scripts.

## 3. Scan localhost (3 min)
Target `127.0.0.1`, scan type **Service & Version Detection**, ports `1-1024,3306,3389,5432,8000`, **Start**.
Point at the progress bar and the exact Nmap command. When it finishes:
* **Port Analysis** - filter State = Open; explain open / closed / filtered.
* **Service Detection** - pick port 8000: Nmap usually identifies Python's server by probing it (look at the product, version and confidence it reports).
* **Security Findings** - severities with explanation, evidence and mitigation; note the localhost note
  ("a localhost scan cannot prove network exposure").
On Windows you will typically also see 135 (MS-RPC) and 445 (SMB) - real Windows services, good talking points.

## 4. Lab VM (optional, 2 min)
Scan the VM's private address (tick the authorisation box). Show OS detection only if the app was started as
Administrator.

## 5. Fix and compare (1.5 min)
Stop the `http.server` (Ctrl+C), scan localhost again with the same settings, then **Scan History →
Compare** the two scans: port 8000 shows as **No longer open**. "This is how you prove a fix."

## 6. Reports (1 min)
**Reports → Generate PDF report → Download**. Scroll through cover, contents, methodology with the Nmap
command and version, port table, services, findings, recommendations. Show the CSV, XML and TXT downloads.

## 7. Quality (30 s)
Show `pytest` output and mention the synthetic XML fixtures, the stand-in Nmap and the real localhost tests.

## Likely viva questions
| Question | Short answer |
|---|---|
| Why TCP connect (-sT) and not SYN (-sS)? | -sT needs no admin rights and completes normal connections; SYN "stealth" scanning was deliberately excluded for an authorised, transparent tool. |
| How do you prevent command injection? | Fixed profiles, input character whitelist, allowlisted flags with value patterns, target last, `subprocess` with a list (no shell). |
| Open vs closed vs filtered? | Open = connection accepted; closed = RST (nothing listening); filtered = no answer (firewall). |
| Is an open port a vulnerability? | No - it is exposure. The tool explains the risk and mitigation; only verification on the host can confirm a vulnerability. |
| What is a version observation? | The reported version is older than a reference version. Distributions backport fixes, so it must be verified; no CVE is claimed. |
| How accurate is OS detection? | Best-effort fingerprinting with an accuracy %, needs admin rights, often uncertain behind firewalls/VMs. |
| Why parse XML? | It is Nmap's stable machine-readable format; text output is meant for humans. |
| Why lower severity on localhost? | Scanning 127.0.0.1 cannot tell whether a service also listens on the network interface. |
| How is a stopped scan handled? | Nmap is terminated; the partial XML is repaired and shown as partial results. |
| What would you add next? | UDP for a few ports, TLS checks, CPE-to-NVD candidate matching, scheduled scans. |
