# 🛡️ Network Port Scanner and Service Detection System
### Using Nmap and Python

A defensive, beginner-friendly network security assessment tool. It drives the real **Nmap** scanner
safely, identifies open/closed/filtered TCP ports, services and versions, highlights potentially risky
exposure with transparent rules, and presents everything in a dark SOC-style dashboard with PDF, CSV,
XML and TXT reports.

> ⚠️ **Only scan computers you own or have explicit permission to test.** Scanning other people's systems
> may be illegal. The app scans **localhost** by default and blocks public Internet targets.

---

## Contents
1. [Introduction](#1-introduction) · 2. [Objectives](#2-objectives) · 3. [Features](#3-features) ·
4. [Technology stack](#4-technology-stack) · 5. [Architecture](#5-architecture) ·
6. [Installation](#6-installation) · 7. [Nmap setup](#7-nmap-setup) · 8. [Python setup](#8-python-setup) ·
9. [Dependency installation](#9-dependency-installation) · 10. [Running the application](#10-running-the-application) ·
11. [Performing a scan](#11-performing-a-scan) · 12. [Understanding the results](#12-understanding-the-results) ·
13. [Generating reports](#13-generating-reports) · 14. [Tests](#14-running-the-tests) ·
15. [Troubleshooting](#15-troubleshooting) · 16. [Limitations](#16-limitations) · 17. [Project structure](#17-project-structure)

## 1. Introduction
Every service listening on a network port is a potential way into a computer. Security teams therefore
regularly ask: *which ports are open, what software is behind them, and should any of it be reachable?*
Nmap answers the first two questions; this project wraps Nmap in a safe interface, organises its results,
adds a rule-based assessment of the third question, keeps a history of scans and produces professional
reports.

Nmap is the real scanning engine - **no scan results are simulated** in the application.

## 2. Objectives
1. Scan authorised lab machines (localhost and private lab addresses).
2. Identify open TCP ports, and closed and filtered ports.
3. Detect running services and their software versions.
4. Offer optional operating-system detection.
5. Organise results in searchable tables.
6. Identify potentially risky exposed services.
7. Display results in an interactive dashboard.
8. Generate professional PDF reports and CSV/XML/TXT exports.

## 3. Features
| Area | Details |
|---|---|
| **Nmap integration** | Finds Nmap (PATH, `NMAP_PATH`, default Windows folder), reports its version and admin rights, runs scans in the background with progress, stop button and timeout, saves the raw XML |
| **Scan types** | Basic TCP connect (`-sT`), Service & version detection (`-sV`), Selected ports (`-p 22,80,443`), Common ports (`--top-ports 20/100/1000`), optional OS detection (`-O`) |
| **Target safety** | Localhost default; private lab addresses/ranges (max /24); public targets blocked unless enabled in Settings **and** confirmed per scan; multicast/broadcast/reserved refused; confirmation checkbox for every non-localhost target |
| **Safe execution** | Fixed scan profiles → allowlisted arguments → `subprocess` with an argument list (never a shell); no stealth, evasion, NSE scripts or exploits |
| **Analysis** | Port table with Open / Closed / Filtered / Open\|Filtered / Unknown, protocol, reason, service, product, version, extra info, Nmap confidence and identification method; counts include ports Nmap summarises |
| **Risk assessment** | Configurable port reference database (`data/common_ports.json`, 45 ports) and version reference; Informational → Critical; exposure findings, clear-text services, unidentified services, version *observations*, attack-surface size; expected-port allowlist; no invented CVEs |
| **Dashboard** | 10 pages, dark navy theme, KPI cards, Plotly charts, search/filter/sort |
| **History** | SQLite database of scans, ports and findings; reopen old scans; compare two scans |
| **Reports** | PDF (cover, contents, page numbers, tables, charts), CSV (ports/services/findings), original Nmap XML, TXT summary, ZIP of everything |
| **Import** | Analyse any Nmap XML file you produced yourself (`nmap ... -oX file.xml`) |

## 4. Technology stack
Python 3.11+ · Nmap · XML parsing (`defusedxml`) · Streamlit · Plotly · pandas · SQLite · ReportLab ·
Matplotlib · pytest. Developed with VS Code and Claude Code.

**Why `subprocess` instead of `python-nmap`?** python-nmap accepts a free-form argument string. Calling
Nmap directly with a *list* of arguments lets every option be checked against an allowlist, and parsing the
XML ourselves gives full control over states, confidence and truncated files. python-nmap remains optional.

## 5. Architecture
```
Streamlit dashboard (New Scan page)
      │  target + scan type + ports + timeout
      ▼
scanner/target_validator.py   → allowed? (localhost / private lab / blocked public)
      ▼
scanner/scan_engine.py        → profile → allowlisted args → subprocess (no shell) → nmap -oX scan.xml
      │                         progress, stop, timeout          (scanner/nmap_manager.py finds Nmap)
      ▼
scanner/xml_parser.py         → hosts, ports, extraports, services, OS matches
      ▼
analyzer/port_analyzer.py → analyzer/service_analyzer.py → analyzer/risk_analyzer.py
      │                                      (data/common_ports.json, data/version_reference.json)
      ▼
analyzer/assessment.py  → ScanResult (one object used everywhere)
      ├── database/db_manager.py   (SQLite history, comparison)
      ├── reports/pdf_generator.py (PDF) and reports/export_manager.py (CSV/XML/TXT/ZIP)
      └── dashboard/*.py           (10 pages)
```

## 6. Installation
Summary (details in the next sections):
1. Install **Nmap** for Windows (includes Npcap).
2. Install **Python 3.11+**.
3. Unzip this project, open a terminal in its folder, create a virtual environment and install the
   requirements - or simply double-click **`setup_windows.bat`**.

## 7. Nmap setup
1. Download the latest **"Latest stable release self-installer"** for Windows from <https://nmap.org/download.html>.
2. Run it and keep the default components, including **Npcap** (needed for OS detection) and Zenmap (optional).
3. During the Npcap step you can leave "Restrict Npcap driver's access to Administrators only" unticked.
4. Open a **new** Command Prompt and check:
   ```
   nmap --version
   ```
   If the command is not found, Nmap is still usable: the app looks in `C:\Program Files (x86)\Nmap\nmap.exe`
   automatically. To use another location set `setx NMAP_PATH "D:\Tools\Nmap\nmap.exe"`.
5. In the app, **New Scan** shows "✅ Nmap 7.xx found at ...".

## 8. Python setup
Install Python 3.11 or newer from <https://www.python.org/downloads/> and tick **"Add python.exe to PATH"**.
Check with `py --version` or `python --version`.

## 9. Dependency installation
```powershell
cd network-port-scanner
py -3 -m venv venv
venv\Scripts\activate          # PowerShell blocked? run once: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 10. Running the application
```powershell
venv\Scripts\activate
streamlit run app.py           # or double-click run_app.bat
```
The dashboard opens at <http://localhost:8501>. Stop it with Ctrl+C. For **OS detection** start the terminal
with *Run as administrator* first.

## 11. Performing a scan
1. Open **🎯 New Scan**. The target is `127.0.0.1` (this computer) by default.
2. Choose a scan type:
   | Scan type | Command used | When to use |
   |---|---|---|
   | Basic TCP Connect | `nmap -sT -p <ports>` | Fast check of which ports accept connections |
   | Service & Version Detection | `nmap -sT -sV -p <ports>` | Identify the software on open ports |
   | Selected Port Scan | `nmap -sT -sV -p 22,80,443` | Check specific ports |
   | Common Ports | `nmap -sT -sV --top-ports 100` | Quick overview of the most used ports |
   | OS Detection | `nmap -sT -sV -O -p <ports>` | Optional; needs Administrator; may be inaccurate |
3. Enter ports (e.g. `1-1024` or `22,80,443`), timing (T3 normal) and timeout.
4. For a lab machine (e.g. a VirtualBox VM at `192.168.56.101`) tick **"I own this machine/network or am
   authorised to scan it"**.
5. Press **▶ Start scan**. Progress, the exact Nmap command and the latest Nmap output are shown; **■ Stop**
   ends the scan and keeps partial results.
6. Results appear below and in every page; the scan is saved to the history.

Already have Nmap output? Use **Import an existing Nmap XML file** at the bottom of New Scan.

**Safe practice targets:** your own computer (`127.0.0.1`), or a virtual machine on a VirtualBox/VMware
host-only network that you created. Do not scan your school, ISP or Internet hosts.

## 12. Understanding the results
**Port states**
| State | Meaning |
|---|---|
| Open | A program accepted the connection - something is listening |
| Closed | The host replied "nothing here" (connection refused) |
| Filtered | No reply - a firewall probably dropped the probe |
| Open\|Filtered | Nmap could not decide between the two |
| Unknown | Other Nmap states (closed\|filtered, unfiltered) |

**Service identification** - "Probed (confirmed by Nmap)" means Nmap talked to the service and matched its
answer; "Guessed from port number" means Nmap only looked the port up in a table. Versions are always shown
exactly as Nmap reported them.

**Findings and severities**
| Severity | Typical example |
|---|---|
| Critical | Unauthenticated Docker API (2375) - effectively full control of the host |
| High | Telnet, FTP, VNC, Redis, MongoDB, Elasticsearch reachable |
| Medium | Databases, SMB, RDP; version observations of end-of-life software |
| Low | SSH, plain HTTP, many open ports |
| Informational | HTTPS, unidentified or expected services |

Important rules the assessment follows:
* **An open port is not a vulnerability.** Findings describe *exposure* and how to reduce it.
* **Version observations** mean "older than a reference version" - Linux distributions often backport fixes,
  so verify on the host. **No CVEs are claimed.**
* Results for `127.0.0.1` are lowered one level (a localhost scan cannot show whether a service is reachable
  from the network); scan the machine's LAN address from another lab host to check.
* Ports you list as **expected** in Settings become Informational.
* All references are editable: `data/common_ports.json`, `data/version_reference.json`.

**Scan History** lets you reopen previous scans and **compare** two of them ("Newly open", "No longer open",
"Version changed") - ideal for showing that a fix worked.

## 13. Generating reports
**📄 Reports** → *Generate PDF report* → *Download PDF*. Other downloads: ports/services/findings CSV, the
original Nmap XML, a TXT summary and a ZIP of everything. Files are named like
`port_scan_report_127.0.0.1_20261105_143000.pdf`; copies are saved in `output/reports` and `output/exports`.

## 14. Running the tests
```powershell
python -m pytest           # or run_tests.bat
```
116 tests: Nmap detection, target validation (incl. injection attempts), argument allowlisting, the scan
engine (complete / stopped / timed-out / failed scans using a stand-in `tests/fake_nmap.py`), XML parsing
of synthetic fixtures (incl. truncated, error and malicious XML), port classification, risk rules, database,
PDF/CSV/TXT/XML exports and a headless run of all 10 dashboard pages. **Two tests run real Nmap scans of
127.0.0.1** against a temporary test server; they are skipped automatically when Nmap is not installed.

## 15. Troubleshooting
| Problem | Fix |
|---|---|
| "Nmap was not found" | Install Nmap (section 7), open a new terminal, or set `NMAP_PATH` |
| OS detection fails / "requires root privileges" | Start the terminal with *Run as administrator*; make sure Npcap is installed |
| All ports "filtered" on a lab VM | The VM firewall blocks probes; this is a valid result. Try with the firewall temporarily disabled on your own VM |
| Host appears down | Keep "Skip ping (-Pn)" ticked for single hosts; check the VM network (host-only adapter) |
| Scan is slow | Use fewer ports, Common Ports (Top 100) or timing T4 on your LAN; service detection is slower than a basic scan |
| "Target not allowed" | Public addresses are blocked by default; use localhost or a private lab address |
| `streamlit` not recognised | Activate the venv or run `python -m streamlit run app.py` |
| PowerShell will not activate the venv | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| Database error | Make sure the `output` folder is writable (not inside a protected folder) |

## 16. Limitations
* TCP only (UDP scanning needs raw packets and is slow); TCP connect scans are visible in target logs by design.
* Service/version/OS detection depends on Nmap's signature databases and can be wrong or incomplete.
* A scan shows reachability from the scanning machine only, at that moment.
* The risk assessment is rule-based exposure analysis; it does not test for or confirm vulnerabilities.
* Version references must be kept up to date by the user.

## 17. Project structure
```
network-port-scanner/
├── app.py · config.py · requirements.txt · pytest.ini · README.md · DEMO_GUIDE.md · PROJECT_STATUS.md
├── setup_windows.bat · run_app.bat · run_tests.bat · .streamlit/config.toml
├── scanner/    nmap_manager.py · scan_engine.py · target_validator.py · xml_parser.py
├── analyzer/   port_analyzer.py · service_analyzer.py · risk_analyzer.py · assessment.py
├── dashboard/  overview · new_scan · scan_config · port_analysis · service_detection · security_findings ·
│               scan_history · reports_page · settings_page · about_page · common · theme
├── database/   db_manager.py
├── reports/    pdf_generator.py · export_manager.py
├── data/       common_ports.json · version_reference.json
├── tests/      6 test modules · fake_nmap.py · streamlit_stub.py · fixtures/ (synthetic Nmap XML)
├── output/     scans/ (raw XML) · reports/ · exports/ · scan_history.db
├── screenshots/
└── documentation/PROJECT_DOCUMENTATION.md
```
