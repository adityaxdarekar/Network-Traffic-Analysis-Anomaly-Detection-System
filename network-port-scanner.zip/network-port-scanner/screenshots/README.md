# Screenshots

Take these on your own laptop with the app running (Windows key + Shift + S, save here):

| File | What to capture |
|---|---|
| `01_new_scan.png` | New Scan with a completed localhost Service & Version scan |
| `02_blocked_target.png` | New Scan rejecting a public target (e.g. 8.8.8.8) |
| `03_overview.png` | Dashboard Overview charts |
| `04_port_analysis.png` | Port Analysis filtered to Open |
| `05_services.png` | Service Detection with one service investigated |
| `06_findings.png` | Security Findings with one finding expanded |
| `07_history_compare.png` | Scan History comparing two scans |
| `08_report.png` | The first pages of the PDF report |
| `09_tests.png` | Terminal showing `116 passed` |

Screenshots must come from the real running application - do not use mock-ups.
