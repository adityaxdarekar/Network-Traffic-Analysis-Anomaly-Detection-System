"""
SQLite storage for scan history.

Tables:
    scans     one row per scan (target, date, type, Nmap version, counts, XML path)
    ports     every port Nmap listed (state, service, product, version ...)
    findings  security findings of the scan
    reports   generated report files

All database errors are converted to ``DatabaseError`` with a readable
message, so the dashboard can show it instead of crashing.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    scan_id TEXT PRIMARY KEY, target TEXT NOT NULL, target_scope TEXT, scan_type TEXT, scan_config TEXT,
    command TEXT, started_at TEXT, finished_at TEXT, duration_sec REAL, nmap_version TEXT, status TEXT,
    error TEXT, hosts_up INTEGER, total_ports INTEGER, open_ports INTEGER, closed_ports INTEGER,
    filtered_ports INTEGER, open_filtered_ports INTEGER, unknown_ports INTEGER, services INTEGER,
    findings INTEGER, severity_json TEXT, xml_path TEXT, saved_at TEXT DEFAULT (datetime('now', 'localtime'))
);
CREATE TABLE IF NOT EXISTS ports (
    scan_id TEXT REFERENCES scans(scan_id) ON DELETE CASCADE, host TEXT, port INTEGER, protocol TEXT,
    state TEXT, state_raw TEXT, reason TEXT, service TEXT, product TEXT, version TEXT, extrainfo TEXT,
    confidence INTEGER, method TEXT
);
CREATE TABLE IF NOT EXISTS findings (
    scan_id TEXT REFERENCES scans(scan_id) ON DELETE CASCADE, finding_id TEXT, rule TEXT, finding_type TEXT,
    severity TEXT, title TEXT, host TEXT, port INTEGER, service TEXT, observed_version TEXT, explanation TEXT,
    risk TEXT, mitigation TEXT, evidence TEXT
);
CREATE TABLE IF NOT EXISTS reports (
    scan_id TEXT REFERENCES scans(scan_id) ON DELETE CASCADE, report_type TEXT, path TEXT,
    created_at TEXT DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_ports_scan ON ports(scan_id);
CREATE INDEX IF NOT EXISTS idx_findings_scan ON findings(scan_id);
"""


class DatabaseError(Exception):
    """A friendly wrapper around sqlite3 errors."""


def _none(v):
    try:
        return None if v is None or pd.isna(v) else v
    except (TypeError, ValueError):
        return v


class DatabaseManager:
    def __init__(self, path: str | Path = DB_PATH):
        self.path = Path(path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._connect() as con:
                con.executescript(SCHEMA)
        except (sqlite3.Error, OSError) as exc:
            raise DatabaseError(f"Could not open the scan database at {self.path}: {exc}") from exc

    @contextmanager
    def _connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.execute("PRAGMA foreign_keys = ON")
        try:
            yield con
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        finally:
            con.close()

    def _run(self, fn):
        try:
            with self._connect() as con:
                return fn(con)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Database error: {exc}") from exc

    # ------------------------------------------------------------------
    def save_scan(self, r) -> str:
        """Store a ScanResult (replaces an earlier copy with the same id)."""
        s = r.summary

        def work(con):
            con.execute("DELETE FROM scans WHERE scan_id = ?", (r.scan_id,))
            con.execute(
                "INSERT INTO scans (scan_id, target, target_scope, scan_type, scan_config, command, started_at, "
                "finished_at, duration_sec, nmap_version, status, error, hosts_up, total_ports, open_ports, "
                "closed_ports, filtered_ports, open_filtered_ports, unknown_ports, services, findings, severity_json, "
                "xml_path) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (r.scan_id, r.target, r.target_scope, r.profile, json.dumps(r.scan_config, default=str), r.command,
                 r.started_at, r.finished_at, r.duration_sec, r.nmap_version, r.status, r.error, s["hosts_up"],
                 s["total_ports"], s["open"], s["closed"], s["filtered"], s["open_filtered"], s["unknown"],
                 s["services"], s["findings"], json.dumps(r.severity_counts), r.xml_path))
            con.executemany(
                "INSERT INTO ports VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [(r.scan_id, p.host, int(p.port), p.protocol, p.state, p.state_raw, p.reason, p.service, p.product,
                  p.version, p.extrainfo, _none(p.confidence), p.method) for p in r.ports.itertuples()])
            con.executemany(
                "INSERT INTO findings VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [(r.scan_id, f.finding_id, f.rule, f.finding_type, f.severity, f.title, f.host,
                  None if _none(f.port) is None else int(f.port), f.service, f.observed_version, f.explanation,
                  f.risk, f.mitigation, f.evidence) for f in r.findings.itertuples()])
            return r.scan_id
        return self._run(work)

    def add_report(self, scan_id: str, report_type: str, path: str) -> None:
        self._run(lambda con: con.execute("INSERT INTO reports (scan_id, report_type, path) VALUES (?,?,?)",
                                          (scan_id, report_type, str(path))))

    # ------------------------------------------------------------------
    def list_scans(self) -> pd.DataFrame:
        return self._run(lambda con: pd.read_sql_query(
            "SELECT scan_id, started_at, target, scan_type, status, hosts_up, total_ports, open_ports, "
            "closed_ports, filtered_ports, services, findings, severity_json, nmap_version, duration_sec "
            "FROM scans ORDER BY started_at DESC, saved_at DESC", con))

    def get_scan(self, scan_id: str) -> dict | None:
        def work(con):
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM scans WHERE scan_id = ?", (scan_id,)).fetchone()
            if row is None:
                return None
            data = dict(row)
            data["severity_counts"] = json.loads(data.pop("severity_json") or "{}")
            data["scan_config"] = json.loads(data.get("scan_config") or "{}")
            for table in ("ports", "findings", "reports"):
                data[table] = pd.read_sql_query(f"SELECT * FROM {table} WHERE scan_id = ?", con,
                                                params=(scan_id,)).drop(columns=["scan_id"])
            return data
        return self._run(work)

    def delete_scan(self, scan_id: str) -> None:
        self._run(lambda con: con.execute("DELETE FROM scans WHERE scan_id = ?", (scan_id,)))

    def totals(self) -> dict:
        def work(con):
            row = con.execute("SELECT COUNT(*), COALESCE(SUM(open_ports),0), COALESCE(SUM(closed_ports),0), "
                              "COALESCE(SUM(filtered_ports),0), COALESCE(SUM(services),0), COALESCE(SUM(findings),0) "
                              "FROM scans").fetchone()
            return dict(zip(["scans", "open", "closed", "filtered", "services", "findings"], row))
        return self._run(work)

    # ------------------------------------------------------------------
    def compare_scans(self, old_id: str, new_id: str) -> pd.DataFrame:
        """What changed between two scans: newly opened/closed ports and changed versions."""
        old, new = self.get_scan(old_id), self.get_scan(new_id)
        if old is None or new is None:
            raise DatabaseError("One of the selected scans no longer exists.")
        cols = ["host", "port", "protocol", "change", "before", "after"]

        def keyed(df):
            return {(r.host, int(r.port), r.protocol): r for r in df.itertuples()}

        a, b = keyed(old["ports"]), keyed(new["ports"])
        rows = []
        for key in sorted(set(a) | set(b)):
            ra, rb = a.get(key), b.get(key)
            sa = ra.state if ra is not None else "not listed"
            sb = rb.state if rb is not None else "not listed"
            va = " ".join(x for x in (ra.product, ra.version) if x) if ra is not None else ""
            vb = " ".join(x for x in (rb.product, rb.version) if x) if rb is not None else ""
            if sa != sb:
                change = ("Newly open" if sb == "Open" else "No longer open" if sa == "Open" else "State changed")
                rows.append([*key, change, sa, sb])
            elif sa == "Open" and va != vb and va and vb:
                rows.append([*key, "Version changed", va, vb])
        return pd.DataFrame(rows, columns=cols)

    def history_trend(self) -> pd.DataFrame:
        return self._run(lambda con: pd.read_sql_query(
            "SELECT started_at, target, open_ports, findings FROM scans ORDER BY started_at", con))
