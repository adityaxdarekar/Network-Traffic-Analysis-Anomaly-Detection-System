"""
Professional PDF scan report (ReportLab), built only from real scan data.

Sections: cover · contents · 1 Executive summary · 2 Target information ·
3 Scan methodology & configuration · 4 Port results · 5 Services and
versions · 6 Security findings · 7 Severity distribution & finding details ·
8 Recommendations · 9 Conclusion · Appendix: Nmap command and warnings.
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402
import pandas as pd  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Frame, Image, KeepTogether,  # noqa: E402
                                NextPageTemplate, PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle)
from reportlab.platypus.tableofcontents import TableOfContents  # noqa: E402

from config import APP_TITLE, APP_VERSION, REPORT_DIR, SEVERITY_COLORS, SEVERITY_ORDER  # noqa: E402
from reports.export_manager import export_filename  # noqa: E402
from scanner.scan_engine import PROFILES  # noqa: E402

NAVY = colors.HexColor("#0b1f3a")
BLUE = colors.HexColor("#2563eb")
CYAN = colors.HexColor("#06b6d4")
LIGHT = colors.HexColor("#f1f5f9")
BORDER = colors.HexColor("#cbd5e1")
TEXT = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#64748b")
PAGE_W, PAGE_H = A4
MARGIN = 2 * cm
CONTENT_W = PAGE_W - 2 * MARGIN
STATE_COLORS = {"Open": "#2563eb", "Closed": "#94a3b8", "Filtered": "#f59e0b", "Open|Filtered": "#a78bfa",
                "Unknown": "#cbd5e1"}

GENERAL_RECOMMENDATIONS = [
    "Treat findings as exposure observations to verify, not as confirmed vulnerabilities.",
    "Close or firewall every service that is not needed; the safest port is one that is not open.",
    "Replace clear-text protocols (Telnet, FTP, HTTP, VNC without TLS) with encrypted alternatives.",
    "Keep operating systems and services updated, and confirm version observations with the vendor.",
    "Re-scan after changes and compare scans on the Scan History page to confirm the fix.",
    "Only scan systems you own or are explicitly authorised to assess.",
]


def fmt(value) -> str:
    try:
        if value is None or pd.isna(value):
            return "-"
    except (TypeError, ValueError):
        pass
    return str(value) if str(value) != "" else "-"


def _styles():
    return {
        "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.5, leading=13.5, textColor=TEXT, spaceAfter=6),
        "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8, leading=10.5, textColor=MUTED),
        "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=7.8, leading=9.8, textColor=TEXT),
        "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=7.8, leading=9.8, textColor=colors.white),
        "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=NAVY, spaceBefore=6,
                             spaceAfter=10),
        "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=11.5, leading=15, textColor=BLUE,
                             spaceBefore=10, spaceAfter=5),
        "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=9.5, leading=13, textColor=TEXT,
                                 leftIndent=12, bulletIndent=2, spaceAfter=3),
        "cover_title": ParagraphStyle("ct", fontName="Helvetica-Bold", fontSize=25, leading=31, textColor=colors.white),
        "cover_sub": ParagraphStyle("cs", fontName="Helvetica", fontSize=13, leading=18, textColor=CYAN),
        "cover_meta": ParagraphStyle("cm", fontName="Helvetica", fontSize=10, leading=15,
                                     textColor=colors.HexColor("#cbd5e1")),
        "toc_title": ParagraphStyle("tt", fontName="Helvetica-Bold", fontSize=16, textColor=NAVY, spaceAfter=14),
    }


def p(text, style) -> Paragraph:
    return Paragraph(escape(fmt(text)), style)


class ReportDoc(BaseDocTemplate):
    def __init__(self, filename, label: str):
        super().__init__(filename, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=2.2 * cm,
                         bottomMargin=2 * cm, title="Network Port Scan Report", author=APP_TITLE)
        self.label = label
        self.addPageTemplates([
            PageTemplate(id="cover", frames=[Frame(MARGIN, MARGIN, CONTENT_W, PAGE_H - 2 * MARGIN)], onPage=_cover_bg),
            PageTemplate(id="content", frames=[Frame(MARGIN, 2 * cm, CONTENT_W, PAGE_H - 4.2 * cm)], onPage=_header),
        ])

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("h1", "h2"):
            key = f"h{id(flowable)}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (0 if flowable.style.name == "h1" else 1, flowable.getPlainText(), self.page, key))


def _cover_bg(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, 0, PAGE_W, PAGE_H, stroke=0, fill=1)
    canvas.setFillColor(CYAN)
    canvas.rect(0, PAGE_H - 1.1 * cm, PAGE_W, 0.25 * cm, stroke=0, fill=1)
    canvas.setFillColor(BLUE)
    canvas.rect(0, 0, PAGE_W, 0.6 * cm, stroke=0, fill=1)
    canvas.restoreState()


def _header(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(CYAN)
    canvas.setLineWidth(1.2)
    canvas.line(MARGIN, PAGE_H - 1.5 * cm, PAGE_W - MARGIN, PAGE_H - 1.5 * cm)
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(NAVY)
    canvas.drawString(MARGIN, PAGE_H - 1.3 * cm, "Network Port Scan Report")
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 1.3 * cm, doc.label)
    canvas.restoreState()


def _numbered_canvas(*args, **kwargs):
    from reportlab.pdfgen.canvas import Canvas

    class NumberedCanvas(Canvas):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self._saved = []

        def showPage(self):
            self._saved.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._saved)
            for state in self._saved:
                self.__dict__.update(state)
                if self._pageNumber > 1:
                    self.setFont("Helvetica", 8)
                    self.setFillColor(MUTED)
                    self.drawRightString(PAGE_W - MARGIN, 1.2 * cm, f"Page {self._pageNumber} of {total}")
                    self.drawString(MARGIN, 1.2 * cm, "Authorised assessment · findings require verification")
                super().showPage()
            super().save()

    return NumberedCanvas(*args, **kwargs)


def table(rows, header, widths, s, max_rows=None, sev_col=None):
    total = len(rows)
    rows = rows[:max_rows] if max_rows else rows
    data = [[Paragraph(escape(h), s["cellb"]) for h in header]]
    data += [[Paragraph(escape(fmt(v)), s["cell"]) for v in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if sev_col is not None:
        for i, r in enumerate(rows, 1):
            c = SEVERITY_COLORS.get(str(r[sev_col]))
            if c:
                style.append(("BACKGROUND", (sev_col, i), (sev_col, i), colors.HexColor(c)))
    t.setStyle(TableStyle(style))
    out = [t]
    if max_rows and total > max_rows:
        out.append(p(f"Showing {max_rows} of {total} rows - the full list is in the CSV export.", s["small"]))
    return out


def kv(pairs, s, key_w=5.2 * cm):
    t = Table([[Paragraph(f"<b>{escape(k)}</b>", s["cell"]), Paragraph(escape(fmt(v)), s["cell"])] for k, v in pairs],
              colWidths=[key_w, CONTENT_W - key_w])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t


def kpis(items, s):
    t = Table([[Paragraph(f"<font size=15 color='#2563eb'><b>{escape(str(v))}</b></font><br/>"
                          f"<font size=7.5 color='#64748b'>{escape(k)}</font>", s["cell"]) for k, v in items]],
              colWidths=[CONTENT_W / len(items)] * len(items))
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.6, BORDER),
                           ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 7),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return t


def bullets(lines, s):
    return [Paragraph(escape(x), s["bullet"], bulletText="•") for x in lines]


# ---------------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------------
def _png(fig) -> Image:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    img = Image(io.BytesIO(buf.getvalue()))
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth, img.drawHeight = CONTENT_W * 0.92, CONTENT_W * 0.92 * ratio
    return img


def _axes(title, size=(7, 2.5)):
    fig, ax = plt.subplots(figsize=size)
    ax.set_title(title, fontsize=11, color="#0b1f3a", loc="left", fontweight="bold")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.tick_params(labelsize=8)
    return fig, ax


def bar_chart(labels, values, title, colors_list, log=False) -> Image:
    fig, ax = _axes(title)
    if sum(values) == 0:
        ax.axis("off")
        ax.text(0.5, 0.4, "No data", ha="center", color="#64748b")
        return _png(fig)
    bars = ax.bar(labels, values, color=colors_list, width=0.55)
    ax.bar_label(bars, labels=[f"{v:,}" for v in values], fontsize=8, padding=2)
    if log:
        ax.set_yscale("symlog")
    ax.grid(axis="y", color="#e2e8f0")
    ax.set_axisbelow(True)
    return _png(fig)


def hbar_chart(labels, values, title) -> Image:
    fig, ax = _axes(title, (7, 0.32 * max(len(labels), 1) + 1.1))
    if not labels:
        ax.axis("off")
        ax.text(0.5, 0.4, "No open services", ha="center", color="#64748b")
        return _png(fig)
    bars = ax.barh(list(labels)[::-1], list(values)[::-1], color="#06b6d4", height=0.6)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.bar_label(bars, fontsize=8, padding=3)
    ax.grid(axis="x", color="#e2e8f0")
    ax.set_axisbelow(True)
    return _png(fig)


# ---------------------------------------------------------------------------
def _recommendations(r) -> list[str]:
    recs, seen = [], set()
    for f in r.findings.itertuples():
        if f.severity in ("Critical", "High", "Medium") and f.mitigation not in seen:
            seen.add(f.mitigation)
            port = "" if fmt(f.port) == "-" else f" (port {f.port})"
            recs.append(f"{f.severity}: {f.title}{port} - {f.mitigation}")
    return recs[:15] + GENERAL_RECOMMENDATIONS


def _conclusion(r) -> str:
    s, sev = r.summary, r.severity_counts
    serious = sev.get("Critical", 0) + sev.get("High", 0)
    text = (f"The {r.profile.lower()} of {r.target} examined {s['total_ports']:,} port(s) and found {s['open']} open, "
            f"{s['closed']} closed and {s['filtered']} filtered. ")
    if serious:
        text += (f"{serious} high or critical exposure finding(s) should be reviewed first. ")
    elif len(r.findings):
        text += "No high or critical exposure was found; review the remaining findings against the system's purpose. "
    else:
        text += "No security findings were raised for the open services. "
    return text + ("These results describe what was reachable at scan time from the scanning machine. Findings are "
                   "rule-based exposure assessments and version observations, not confirmed vulnerabilities; "
                   "verify them on the host before taking action.")


def generate_pdf_report(r, output_path: str | Path | None = None, analyst: str = "") -> Path:
    s = _styles()
    sm = r.summary
    now = datetime.now()
    output_path = Path(output_path or REPORT_DIR / export_filename("port_scan_report", r.target, "pdf", now))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = ReportDoc(str(output_path), f"{r.target} · scan {r.scan_id}")
    story = []

    # Cover
    story += [Spacer(1, 4 * cm), Paragraph("AUTHORISED SECURITY ASSESSMENT", s["cover_sub"]), Spacer(1, 0.4 * cm),
              Paragraph("Network Port Scan and Service Detection Report", s["cover_title"]), Spacer(1, 0.6 * cm),
              Paragraph(escape(APP_TITLE) + " - Nmap and Python", s["cover_meta"]), Spacer(1, 3 * cm)]
    meta = [("Target", r.target), ("Scan type", r.profile), ("Scan date", r.started_at or "-"),
            ("Report generated", now.strftime("%Y-%m-%d %H:%M:%S")), ("Scan ID", r.scan_id),
            ("Nmap version", r.nmap_version or "-"), ("Software version", APP_VERSION)]
    if analyst:
        meta.insert(0, ("Prepared by", analyst))
    for k, v in meta:
        story.append(Paragraph(f"<font color='#06b6d4'>{escape(k)}:</font>&nbsp;&nbsp;{escape(fmt(v))}", s["cover_meta"]))
    story += [Spacer(1, 2.2 * cm),
              Paragraph("All results come from the Nmap scan identified above. Findings describe exposure and version "
                        "observations; they are not confirmed vulnerabilities.", s["cover_meta"]),
              NextPageTemplate("content"), PageBreak()]

    toc = TableOfContents()
    toc.levelStyles = [ParagraphStyle("t1", fontName="Helvetica-Bold", fontSize=10.5, leading=17, textColor=NAVY),
                       ParagraphStyle("t2", fontName="Helvetica", fontSize=9, leading=13, leftIndent=14)]
    story += [Paragraph("Table of Contents", s["toc_title"]), toc, PageBreak()]

    # 1 Executive summary
    sev = r.severity_counts
    story += [Paragraph("1. Executive Summary", s["h1"]),
              kpis([("Ports scanned", f"{sm['total_ports']:,}"), ("Open", sm["open"]), ("Closed", f"{sm['closed']:,}"),
                    ("Filtered", f"{sm['filtered']:,}"), ("Findings", sm["findings"]),
                    ("High / Critical", sev["High"] + sev["Critical"])], s), Spacer(1, 8)]
    summary = [f"Nmap {r.nmap_version or ''} scanned {r.target} ({r.target_scope} address) using '{r.profile}'. "
               f"{sm['hosts_up']} host(s) responded."]
    if r.open_ports.empty:
        summary.append("No open ports were found in the scanned range.")
    else:
        top = ", ".join(f"{x.port}/{x.service or 'unknown'}" for x in r.open_ports.head(10).itertuples())
        summary.append(f"Open ports: {top}{' ...' if len(r.open_ports) > 10 else ''}.")
    if len(r.findings):
        parts = ", ".join(f"{sev[k]} {k}" for k in reversed(SEVERITY_ORDER) if sev.get(k))
        summary.append(f"The rule-based assessment produced {len(r.findings)} finding(s): {parts}.")
        for f in r.findings.head(3).itertuples():
            summary.append(f"{f.severity}: {f.title}.")
    else:
        summary.append("The rule-based assessment produced no findings.")
    summary += [f"Note: {w}" for w in r.warnings]
    story += bullets(summary, s)

    # 2 Target
    story += [Paragraph("2. Target Information", s["h1"]),
              kv([("Target", r.target), ("Address scope", r.target_scope), ("Hosts up / down",
                  f"{sm['hosts_up']} / {r.parsed.hosts_down}")], s)]
    if not r.hosts.empty:
        story.append(Spacer(1, 6))
        story += table([[h.host, h.hostname, h.status, h.mac or "-", h.os_guess or "-",
                         f"{h.os_accuracy}%" if fmt(h.os_accuracy) != "-" else "-"] for h in r.hosts.itertuples()],
                       ["Host", "Hostname", "Status", "MAC", "OS guess", "Accuracy"],
                       [3 * cm, 3.2 * cm, 1.6 * cm, 3.2 * cm, CONTENT_W - 13 * cm, 2 * cm], s)
        if r.hosts["os_guess"].astype(bool).any():
            story.append(p("OS detection is a best-effort fingerprint match and can be wrong; treat it as a hint.",
                           s["small"]))

    # 3 Methodology
    prof = next((x for x in PROFILES.values() if x.name == r.profile), None)
    story += [Paragraph("3. Scan Methodology and Configuration", s["h1"]),
              p("The scan was performed with Nmap, the open-source network scanner, using a TCP connect scan (-sT): "
                "for each port a normal TCP connection is attempted. A completed handshake means the port is open, a "
                "refusal (RST) means closed, and no answer means filtered (usually a firewall). Service detection "
                "(-sV) then sends protocol probes to open ports and matches the answers against Nmap's signature "
                "database to identify the product and version. Results were exported by Nmap as XML (-oX) and "
                "parsed by this application. No stealth, evasion, exploit or script options were used.", s["body"]),
              p(prof.description if prof else "Results imported from an existing Nmap XML file.", s["body"])]
    cfg_rows = [("Nmap version", r.nmap_version), ("Scan type", r.profile)]
    cfg_rows += [(k.replace("_", " ").capitalize(), v) for k, v in r.scan_config.items() if k != "profile"]
    cfg_rows += [("Nmap command", r.command), ("Started", r.started_at), ("Finished", r.finished_at),
                 ("Duration", f"{r.duration_sec} s" if r.duration_sec is not None else "-"),
                 ("Status", r.status + (f" - {r.error}" if r.error else ""))]
    story.append(kv(cfg_rows, s))

    # 4 Ports
    counts = r.state_counts
    story += [PageBreak(), Paragraph("4. Port Results", s["h1"]),
              kv([("Total ports scanned", f"{sm['total_ports']:,}"), ("Open", sm["open"]), ("Closed", f"{sm['closed']:,}"),
                  ("Filtered", f"{sm['filtered']:,}"), ("Open|Filtered", sm["open_filtered"]),
                  ("Unknown / other", sm["unknown"])], s),
              bar_chart(list(counts), list(counts.values()), "Port states (log scale)",
                        [STATE_COLORS[k] for k in counts], log=True),
              p("Nmap lists 'interesting' ports individually and summarises large groups of closed or filtered ports; "
                "the counts above include both.", s["small"]),
              Paragraph("4.1 Individually reported ports", s["h2"])]
    rows = [[x.host, x.port, x.protocol, x.state, x.reason, x.service or "-",
             " ".join(v for v in (x.product, x.version) if v) or "-"] for x in r.ports.itertuples()]
    story += table(rows, ["Host", "Port", "Proto", "State", "Reason", "Service", "Product / version"],
                   [2.8 * cm, 1.2 * cm, 1.2 * cm, 2.1 * cm, 2.1 * cm, 2.6 * cm, CONTENT_W - 12 * cm], s, max_rows=60)\
        if rows else [p("No ports were listed individually.", s["body"])]

    # 5 Services
    sv = r.services
    story += [PageBreak(), Paragraph("5. Identified Services and Versions", s["h1"])]
    if sv.empty:
        story.append(p("No open services were identified.", s["body"]))
    else:
        vc = sv["service"].value_counts()
        story.append(hbar_chart(list(vc.index), list(vc.values), "Service distribution (open ports)"))
        story += table([[x.host, x.port, x.service, x.product_version, x.identification,
                         fmt(x.confidence), "yes" if x.encrypted else "no"] for x in sv.itertuples()],
                       ["Host", "Port", "Service", "Product / version (as reported)", "Identification", "Conf.",
                        "Encrypted"],
                       [2.6 * cm, 1.1 * cm, 2.3 * cm, CONTENT_W - 12.6 * cm, 3.4 * cm, 1.2 * cm, 2 * cm], s)
        story.append(p("Versions are shown exactly as Nmap reported them. 'Guessed from port number' means Nmap did not "
                       "confirm the service by probing it.", s["small"]))

    # 6 Findings
    fd = r.findings
    story += [PageBreak(), Paragraph("6. Potential Security Findings", s["h1"]),
              p("Findings are generated by transparent rules from a configurable port reference database. An open port "
                "is not automatically a vulnerability; 'Version observation' findings mean the reported version is "
                "older than a reference version and must be verified. No CVEs are asserted.", s["body"])]
    if fd.empty:
        story.append(p("No findings were generated.", s["body"]))
    else:
        story += table([[f.finding_id, f.severity, f.finding_type, f.host, fmt(f.port), f.title] for f in fd.itertuples()],
                       ["ID", "Severity", "Type", "Host", "Port", "Finding"],
                       [1.4 * cm, 2 * cm, 3 * cm, 2.6 * cm, 1.2 * cm, CONTENT_W - 10.2 * cm], s, sev_col=1)

    # 7 Severity + details
    story += [PageBreak(), Paragraph("7. Severity Distribution and Finding Details", s["h1"]),
              bar_chart(SEVERITY_ORDER, [sev[k] for k in SEVERITY_ORDER], "Findings by severity",
                        [SEVERITY_COLORS[k] for k in SEVERITY_ORDER])]
    for f in fd.itertuples():
        color = SEVERITY_COLORS.get(f.severity, "#64748b")
        block = [Paragraph(f"<font color='{color}'><b>■ {escape(f.severity.upper())}</b></font>&nbsp;&nbsp;"
                           f"<b>{escape(f.finding_id)} · {escape(f.title)}</b>", s["body"]),
                 kv([("Host / port", f"{f.host} : {fmt(f.port)}/{f.protocol}"), ("Service", f.service),
                     ("Observed version", f.observed_version), ("Finding type", f.finding_type),
                     ("Explanation", f.explanation), ("Potential risk", f.risk), ("Evidence", f.evidence),
                     ("Recommended mitigation", f.mitigation)], s), Spacer(1, 10)]
        story += [CondPageBreak(5 * cm), KeepTogether(block)]

    # 8-9
    story += [PageBreak(), Paragraph("8. Security Recommendations", s["h1"])]
    story += bullets(_recommendations(r), s)
    story += [Paragraph("9. Conclusion", s["h1"]), p(_conclusion(r), s["body"])]

    doc.multiBuild(story, canvasmaker=_numbered_canvas)
    return output_path
