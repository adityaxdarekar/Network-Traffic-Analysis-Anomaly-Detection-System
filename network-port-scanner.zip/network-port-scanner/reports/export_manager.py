"""
Export scan results: CSV tables, the original Nmap XML and a TXT summary.

File names follow ``<kind>_<target>_<YYYYmmdd_HHMMSS>.<ext>`` so they sort by
time and never overwrite each other.
"""

from __future__ import annotations

import io
import re
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

from config import APP_TITLE, EXPORT_DIR, SEVERITY_ORDER


def safe_name(text: str) -> str:
    name = re.sub(r"[^A-Za-z0-9.-]+", "_", text or "target")
    name = re.sub(r"\.{2,}", "_", name).strip("_.")          # no '..' path tricks
    return name[:60] or "target"


def export_filename(kind: str, target: str, ext: str, when: datetime | None = None) -> str:
    when = when or datetime.now()
    return f"{kind}_{safe_name(target)}_{when:%Y%m%d_%H%M%S}.{ext}"


def ports_csv(r) -> str:
    return r.ports.to_csv(index=False)


def findings_csv(r) -> str:
    return r.findings.to_csv(index=False)


def services_csv(r) -> str:
    return r.services.to_csv(index=False)


def xml_bytes(r) -> bytes | None:
    """The original Nmap XML exactly as Nmap wrote it."""
    p = Path(r.xml_path) if r.xml_path else None
    return p.read_bytes() if p and p.is_file() else None


def text_summary(r) -> str:
    s = r.summary
    lines = [
        APP_TITLE, "=" * len(APP_TITLE), "",
        f"Scan ID        : {r.scan_id}",
        f"Target         : {r.target} ({r.target_scope})",
        f"Scan type      : {r.profile}",
        f"Started        : {r.started_at}",
        f"Duration       : {r.duration_sec if r.duration_sec is not None else '-'} s",
        f"Nmap version   : {r.nmap_version}",
        f"Nmap command   : {r.command}",
        f"Status         : {r.status}" + (f" - {r.error}" if r.error else ""),
        "",
        f"Hosts up       : {s['hosts_up']}",
        f"Ports scanned  : {s['total_ports']}",
        f"Open           : {s['open']}",
        f"Closed         : {s['closed']}",
        f"Filtered       : {s['filtered']}",
        f"Open|Filtered  : {s['open_filtered']}",
        f"Unknown        : {s['unknown']}",
        "", "OPEN PORTS", "-" * 10,
    ]
    if r.open_ports.empty:
        lines.append("(none)")
    for p in r.open_ports.itertuples():
        ver = " ".join(x for x in (p.product, p.version) if x) or "version not reported"
        lines.append(f"{p.host:<16} {p.port:>5}/{p.protocol:<4} {p.service or 'unknown':<16} {ver}")
    lines += ["", "SECURITY FINDINGS (heuristic - verify before acting)", "-" * 52]
    if r.findings.empty:
        lines.append("(none)")
    for sev in reversed(SEVERITY_ORDER):
        for f in r.findings[r.findings["severity"] == sev].itertuples():
            port = "-" if f.port is None or str(f.port) == "<NA>" else f.port
            lines.append(f"[{f.finding_id}] {sev.upper():<13} port {port}: {f.title}")
            lines.append(f"      Mitigation: {f.mitigation}")
    for w in r.warnings:
        lines.append(f"Warning: {w}")
    return "\n".join(lines) + "\n"


def save_exports(r, out_dir: Path = EXPORT_DIR) -> dict[str, Path]:
    """Write all exports to disk and return their paths."""
    out_dir.mkdir(parents=True, exist_ok=True)
    when = datetime.now()
    files = {
        "ports_csv": out_dir / export_filename("ports", r.target, "csv", when),
        "findings_csv": out_dir / export_filename("findings", r.target, "csv", when),
        "services_csv": out_dir / export_filename("services", r.target, "csv", when),
        "summary_txt": out_dir / export_filename("summary", r.target, "txt", when),
    }
    files["ports_csv"].write_text(ports_csv(r), encoding="utf-8")
    files["findings_csv"].write_text(findings_csv(r), encoding="utf-8")
    files["services_csv"].write_text(services_csv(r), encoding="utf-8")
    files["summary_txt"].write_text(text_summary(r), encoding="utf-8")
    if xml_bytes(r) is not None:
        files["nmap_xml"] = out_dir / export_filename("nmap", r.target, "xml", when)
        shutil.copyfile(r.xml_path, files["nmap_xml"])
    return files


def zip_bundle(r) -> bytes:
    """Every export in one ZIP (for a single download button)."""
    buf = io.BytesIO()
    when = datetime.now()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(export_filename("ports", r.target, "csv", when), ports_csv(r))
        zf.writestr(export_filename("findings", r.target, "csv", when), findings_csv(r))
        zf.writestr(export_filename("services", r.target, "csv", when), services_csv(r))
        zf.writestr(export_filename("summary", r.target, "txt", when), text_summary(r))
        xml = xml_bytes(r)
        if xml is not None:
            zf.writestr(export_filename("nmap", r.target, "xml", when), xml)
    return buf.getvalue()
