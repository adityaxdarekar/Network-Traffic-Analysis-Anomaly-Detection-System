"""
Command-line interface (same engine as the dashboard). Nothing is opened or sent anywhere.

    python cli.py "http://192.0.2.10/verify-account"
    python cli.py --file samples/mixed_urls.csv --csv output/results.csv --json output/results.json
    python cli.py --file urls.txt --pdf output/bulk_report.pdf --save
Exit code: 0 = all LOW RISK, 1 = at least one MEDIUM/HIGH RISK, 2 = error / invalid input only.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from detector.detection_engine import analyze_bulk, analyze_url, read_urls, results_to_csv, results_to_json  # noqa: E402


def print_result(r) -> None:
    print(f"\nURL: {r.submitted}")
    if not r.valid:
        print(f"Invalid input: {r.error}")
        return
    print(f"Risk Score: {r.score}/100\nClassification: {r.classification}")
    if r.indicators:
        print("\nFindings:")
        for n, i in enumerate(r.indicators, 1):
            print(f"  {n}. {i.name} (+{i.weight}, {i.severity}) - {i.evidence}")
    print("\nRecommendation:")
    for rec in r.recommendations:
        print(f"  - {rec}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=C.APP_TITLE)
    ap.add_argument("url", nargs="?", help="a single URL to analyse")
    ap.add_argument("--file", help="CSV or TXT file with URLs")
    ap.add_argument("--csv", help="write results as CSV")
    ap.add_argument("--json", help="write results as JSON")
    ap.add_argument("--pdf", help="write a PDF report")
    ap.add_argument("--save", action="store_true", help="store the results in the scan history database")
    args = ap.parse_args(argv)
    settings = C.load_settings()
    if args.file:
        path = Path(args.file)
        if not path.is_file():
            print(f"error: file not found: {path}", file=sys.stderr)
            return 2
        urls, warnings = read_urls(path.read_bytes(), path.name)
        for w in warnings:
            print(f"warning: {w}", file=sys.stderr)
        results = analyze_bulk(urls, settings)
        for r in results:
            print(f"{(str(r.score) if r.valid else '-'):>3}  {r.classification:<11}  {r.submitted}")
    elif args.url:
        results = [analyze_url(args.url, settings)]
        print_result(results[0])
    else:
        ap.print_help()
        return 2
    for target, text in ((args.csv, results_to_csv), (args.json, results_to_json)):
        if target:
            Path(target).parent.mkdir(parents=True, exist_ok=True)
            Path(target).write_text(text(results), encoding="utf-8")
            print(f"written: {target}")
    if args.pdf:
        from reports.pdf_generator import bulk_report_bytes, single_report_bytes
        data = single_report_bytes(results[0]) if len(results) == 1 and not args.file else \
            bulk_report_bytes(results, args.file or "")
        Path(args.pdf).parent.mkdir(parents=True, exist_ok=True)
        Path(args.pdf).write_bytes(data)
        print(f"written: {args.pdf}")
    if args.save:
        from database.db_manager import DatabaseManager
        db = DatabaseManager()
        if args.file:
            print(f"stored as bulk session #{db.save_bulk(results, Path(args.file).name)}")
        else:
            print(f"stored as scan #{db.save_result(results[0])}")
    print(f"\nNote: {C.DISCLAIMER}")
    if all(not r.valid for r in results):
        return 2
    return 1 if any(r.classification in ("MEDIUM RISK", "HIGH RISK") for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
