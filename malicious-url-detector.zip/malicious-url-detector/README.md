# Malicious URL Detection and Risk Assessment System Using Python

A Python application that analyses URLs **as text** and explains which characteristics are typical of phishing
or malicious links. It looks at the scheme, IP-based hosts, domain structure, subdomains, length, suspicious
characters, phishing keywords, URL encoding, punycode, shorteners and lookalike domains. Every finding has a
configurable weight. The sum, capped at 100, gives a heuristic **risk score** and a **LOW / MEDIUM / HIGH RISK**
classification, with an explanation and recommended next steps for each URL.

The application has:
- a Streamlit dashboard (8 pages)
- a command-line tool
- SQLite scan history
- PDF, CSV and JSON reports
- 40 synthetic sample URLs
- 215 automated tests

> **Heuristic, not a verdict.** The score counts warning signs in the URL text. It is not a probability. LOW RISK
> does not guarantee that a URL is safe, and HIGH RISK does not prove that it is malicious.
>
> **Local and safe.** URLs are never opened, resolved, downloaded or sent anywhere. Two optional online checks
> (redirects, domain age) are disabled by default and need your confirmation for every request.

---

## Contents
1 Introduction · 2 Problem · 3 Objectives · 4 Technologies · 5 What is a malicious URL? · 6 How phishing URLs
work · 7 URL structure · 8 Domain analysis · 9 HTTPS · 10 IP-based URLs · 11 Keywords · 12 Risk scoring ·
13 Architecture · 14 Folder structure · 15 Installation · 16 Usage · 17 Sample results · 18 Testing ·
19 Limitations · 20 Future enhancements · 21 Conclusion

## 1. Project introduction
Most phishing attacks start with a link. Before anyone clicks it, the URL itself often gives warnings: an IP
address instead of a name, a brand name in the wrong place, a punycode lookalike, a hidden redirect. This project
turns those observations into a transparent rule-based analyser that a student, a help-desk analyst or a SOC
trainee can use and understand. Every point of the score is explained.

## 2. Problem statement
Users and analysts receive many links and cannot reliably judge them by eye:
- Lookalike domains (`examp1ebank.example`) and punycode (`exаmplebank` with a Cyrillic "а") are hard to spot.
- The real host can hide behind `@`, deep subdomains, redirect parameters or shorteners.
- Black-box tools say "bad" without saying why, and visiting a link to check it is dangerous.

So we need a safe, offline, explainable assessment of a URL's structure.

## 3. Objectives
1. Parse URLs robustly (malformed input never crashes the tool) and extract every component.
2. Extract domains correctly with the Public Suffix List, so suffixes like `co.uk` are handled.
3. Detect IP-based, punycode, shortened, encoded, overly long and structurally unusual URLs, phishing keywords
   and lookalike domains.
4. Score with configurable weights, classify LOW / MEDIUM / HIGH, and explain every indicator.
5. Provide single and bulk analysis, history, reports and a dashboard.
6. Stay local and safe, and test everything automatically.

## 4. Technologies used
| Technology | Purpose |
|---|---|
| Python 3.11+ | language |
| `urllib.parse` | URL splitting (scheme, netloc, path, query, fragment) |
| `ipaddress` | IPv4/IPv6 validation, private/loopback/link-local scope |
| `re` | pattern detection |
| `tldextract` (offline) / bundled Public Suffix List | registered domain, subdomain, suffix |
| `idna` / built-in IDNA codec, `unicodedata` | punycode ↔ Unicode, script detection |
| Streamlit + Plotly | dashboard and charts |
| pandas | tables, filters, exports |
| SQLite (`sqlite3`) | scan history |
| ReportLab | PDF reports |
| pytest (+ pypdf) | automated tests |
| requests | only for the optional, disabled-by-default online checks |

## 5. What is a malicious URL?
A URL that leads to harm: a phishing page that steals credentials, a page that delivers malware, a scam, or a
redirect chain to one of those. The harm is in the **destination**. The URL can only give **indicators**, which
is exactly why this tool speaks of risk and never of proof.

## 6. How phishing URLs work
Attackers make a link **look** trustworthy while it **goes** somewhere else:
| Trick | Example (synthetic) |
|---|---|
| Brand in the wrong place | `https://examplebank-secure-login.example.net/verify`: the real domain is `example.net` |
| Lookalike characters | `examp1ebank.example` (digit 1), `exаmplebank.example` (Cyrillic а, punycode `xn--exmplebank-0qi`) |
| `@` trick | `https://examplebank.example@203.0.113.9/login`: the browser goes to 203.0.113.9 |
| Hidden destination | shorteners (`tiny.example/AbC123`), redirect parameters (`?url=https%3A%2F%2F...`) |
| Raw or obfuscated IPs | `http://192.168.1.10/...`, `http://3232235786/` (= 192.168.1.10) |
| Pressure words | `verify`, `account`, `suspended`, `reward`, `free` |

## 7. URL structure explanation
```
https://user@login.secure.example.co.uk:8443/account/verify?next=%2Fhome&id=7#top
└─┬──┘ └┬─┘ └──────────┬──────────────┘└─┬┘└──────┬──────┘└──────┬──────┘└┬┘
scheme userinfo     hostname           port     path         query    fragment
                login.secure | example | co.uk
                 subdomain    domain    public suffix   → registered domain: example.co.uk
```
The **registered domain** decides who controls the site. Everything to its left can be chosen freely by its
owner, which is why attackers put trusted names there.

## 8. Domain analysis
- **Correct extraction:** a naive "last two labels" split gives `co.uk` for `example.co.uk`. This tool uses
  the Public Suffix List:
  - **tldextract** when it is installed. It is created with `suffix_list_urls=()`, so it uses its bundled
    snapshot and **never downloads** anything.
  - Otherwise a bundled copy of the official list in `data/` (ICANN section, snapshot 2025-12-28), with rules,
    wildcards and exceptions.
  - Reserved names (`.example`, `.test`, `.invalid`) are treated as TLDs.
- **Indicators:**
  - number of subdomains
  - hyphens
  - digits and random-looking labels
  - domain length and dots
  - underscores
  - embedded domain names in subdomains (`www.examplebank.example.verify-account.test`)
  - `http`/`www` inside a hostname
  - a watch-list TLD (weak signal)
  - an unknown TLD
- **Punycode:** `xn--` labels are decoded and **flagged for inspection, not condemned**. `münchen.example` is
  legitimate and stays LOW RISK. Mixed scripts in one label (Latin + Cyrillic) are a stronger hint.
- **Lookalikes:** compared with a configurable list of (fictional) brands and their legitimate domains:
  - the brand name inside an unlisted registered domain
  - lookalike characters (0→o, 1→l, rn→m, Cyrillic/Greek letters)
  - edit distance 1 (`exampelbank`)
  - the brand only in a subdomain or path

  The wording is evidence-based ("not one of the brand's known domains") and never claims impersonation.

## 9. HTTPS explanation
HTTPS encrypts the connection, so data can't be read or altered in transit. It says **nothing** about who runs
the site: phishing sites routinely have valid certificates. The tool therefore:
- flags **HTTP** as a risk indicator (+10)
- flags a missing scheme (+5) and non-web schemes (`ftp:` +15, `javascript:`/`data:` +60)
- gives **no bonus** for HTTPS

## 10. IP-based URL detection
`ipaddress` validates IPv4 and IPv6 hosts (including `[2001:db8::10]` literals). Obfuscated IPv4 forms that
browsers accept are decoded too: decimal `3232235786`, hex `0xc0a8010a`, octal `0300.0250.01.012` and short
`127.1`. The address scope (private, loopback, link-local, public) is shown. An IP host is an **indicator** (+25,
or +30 when obfuscated), not a verdict: routers and lab servers legitimately use IPs, so
`https://198.51.100.25/portal` alone stays LOW RISK.

## 11. Suspicious keyword detection
There are 44 configurable keywords in three groups:
- **credential:** login, verify, account, password, secure, update, reset, authentication …
- **financial:** payment, banking, wallet, billing …
- **lure:** free, reward, gift, bonus, urgent …

They are searched in the subdomain, the domain name, the path and the query (decoded twice, so `%6Cogin` is
found).
- Words of five or more letters also match inside tokens (`verifyaccount`).
- Short words (`pay`, `tax`, `card`) must be whole tokens, so `payroll` does not match.

Scoring is +5 per keyword, at most +15. A configured brand's own domain is not scanned (`paytrust.example`
doesn't "contain pay"). A brand reference **combined with** login/payment words adds +10.

## 12. Risk scoring methodology
`score = min(100, Σ weight of each distinct indicator)`. Every characteristic counts once:
- "very long" replaces "long"
- "obfuscated IP" replaces "IP"
- "double encoding" replaces "encoding"
- "lookalike domain" replaces "brand in subdomain"

| Indicator | Weight | Indicator | Weight |
|---|---|---|---|
| Script/data scheme (`javascript:`) | 60 | Redirect parameter | 15 |
| Obfuscated IP | 30 | Mixed scripts in a label | 10 |
| IP-based hostname | 25 | Many subdomains (> 3) | 10 |
| `@` in the address | 20 | Unusual domain structure | 10 |
| Lookalike domain | 20 | Brand + login/payment words | 10 |
| Punycode | 15 | Brand in subdomain/path | 10 |
| Unusual scheme (`ftp:` …) | 15 | `http`/`www` inside hostname | 10 |
| Phishing keywords | 5 each, max 15 | Double encoding | 10 |
| HTTP instead of HTTPS | 10 | Very long URL (≥ 150) | 10 |
| URL shortener | 10 | Long URL (≥ 75) | 5 |
| Missing scheme | 5 | Long query / many parameters | 5 |
| Watch-list TLD / unknown TLD | 5 | Unusual encoding | 5 |
| Non-standard port | 5 | Unusual characters (`//` in path, `\` …) | 5 |

- **Bands:** 0-29 **LOW RISK**, 30-59 **MEDIUM RISK**, 60-100 **HIGH RISK**.
- **Severity per indicator:** ≥ 20 high, ≥ 10 medium, otherwise low.
- **Configurable:** all weights, thresholds, bands and lists in `config.py` or on the **Settings** page (saved to
  `output/user_settings.json`).

## 13. System architecture
```
 Streamlit dashboard (app.py, dashboard/pages.py)         cli.py
        │ single URL / bulk file / sample dataset            │
        ▼                                                    ▼
 detector/detection_engine.py ──► url_parser ─► domain_analyzer (PSL / tldextract offline)
        │                         punycode_detector · keyword_detector · url_pattern_detector
        ▼
 risk_scorer (dedup, weights, cap 100, bands, recommendations)
        │
        ├──► database/db_manager.py (SQLite: url_scans, url_indicators, bulk_scan_sessions)
        └──► reports/pdf_generator.py (PDF) · CSV / JSON export
 services/ (OPTIONAL, off by default): network_guard · redirect_checker · domain_age (RDAP) · threat_intel stub
```

## 14. Folder structure
```
malicious-url-detector/
├── app.py                  Streamlit entry point (8 pages)
├── cli.py                  command-line analysis and exports
├── config.py               weights, thresholds, bands, keyword/shortener/brand/TLD lists
├── requirements.txt  pytest.ini  setup.sh  run.sh  setup.bat  run.bat  .streamlit/config.toml
├── detector/
│   ├── url_parser.py           validation, normalisation, components, refanging (hxxp, [.])
│   ├── idna_compat.py          punycode ↔ Unicode
│   ├── domain_analyzer.py      PSL extraction, IP forms and scope, domain-structure findings
│   ├── keyword_detector.py     phishing keywords
│   ├── url_pattern_detector.py scheme, IP, shortener, length, @, encoding, redirect, port, characters,
│   │                           subdomains, TLD, structure, lookalikes
│   ├── punycode_detector.py    xn-- labels, scripts, confusable skeleton
│   ├── indicators.py           Indicator type, severity, titles
│   ├── risk_scorer.py          scoring, classification, recommendations
│   └── detection_engine.py     analyze_url / analyze_bulk / file reading / CSV & JSON export
├── database/db_manager.py      SQLite (parameterized queries)
├── reports/pdf_generator.py    single and bulk PDF reports
├── services/                   optional online checks (disabled by default) + SSRF guard + threat-intel interface
├── dashboard/                  common.py (helpers), pages.py (all pages)
├── data/public_suffix_list.dat bundled Public Suffix List (MPL 2.0)
├── samples/                    low_risk_urls.csv, suspicious_urls.csv, high_risk_urls.csv, mixed_urls.csv,
│                               generate_samples.py - all SYNTHETIC
├── sample_output/              real PDFs, CSV, JSON and expected_outputs.txt generated from the samples
├── tests/                      215 pytest tests (+ Streamlit/Plotly stand-ins for headless page tests)
├── documentation/DEMO_GUIDE.md demonstration script, expected outputs, module explanations, viva Q&A
├── screenshots/                PDF report renders; add dashboard screenshots here
├── assets/style.css
└── output/                     url_scans.db, saved reports, user_settings.json (created at runtime)
```

## 15. Installation instructions
**Windows** (Python 3.11+ from python.org, with "Add python.exe to PATH" ticked):
```bat
cd malicious-url-detector
setup.bat
```
**Linux / macOS:**
```bash
cd malicious-url-detector
chmod +x setup.sh run.sh && ./setup.sh
```
**Manual:**
```bash
python -m venv venv
venv/bin/pip install -r requirements.txt     # Windows: venv\Scripts\pip install -r requirements.txt
```
Internet access is needed **once** to install the packages. The application itself runs offline.

## 16. Application usage
Start the dashboard:
```bash
./run.sh            # Windows: run.bat      → http://localhost:8501
# or: venv/bin/python -m streamlit run app.py
```
| Page | What you do |
|---|---|
| Overview Dashboard | totals, risk distribution, most common indicators, recent scans; "Load sample dataset" button |
| Single URL Analysis | paste a URL → score gauge, findings with explanations, recommendations, components, domain structure, PDF |
| Bulk URL Analysis | upload CSV (column `url`) or TXT (one per line), or load `samples/mixed_urls.csv` → filter, search, sort, export CSV/JSON/PDF |
| Domain Analysis | registered domain, subdomains, suffix/TLD, IP status, punycode/scripts, domain indicators |
| Scan History | all stored scans, details per scan, delete one, clear all (with confirmation) |
| Reports | single and bulk PDF/CSV/JSON, save PDFs to `output/reports`, full history CSV |
| Settings | weights, thresholds, bands, lists (shorteners, TLDs, brands, keywords), optional network features |
| About Project | objectives, methodology, weights, limitations, future work |

Command line:
```bash
venv/bin/python cli.py "http://192.168.1.10/verify-account"
venv/bin/python cli.py --file samples/mixed_urls.csv --csv output/results.csv --json output/results.json --pdf output/bulk.pdf
```
CLI exit codes:
- `0`: all LOW RISK
- `1`: at least one MEDIUM or HIGH RISK
- `2`: error, or invalid input only

## 17. Sample results
Generated by the tool with default settings. All of these are in `sample_output/expected_outputs.txt`.

| URL (synthetic) | Score | Class | Main findings |
|---|---|---|---|
| `https://www.example.com/` | 0 | LOW RISK | none |
| `https://münchen.example/stadtplan` | 15 | LOW RISK | punycode (legitimate IDN, flagged for inspection only) |
| `https://198.51.100.25/portal` | 25 | LOW RISK | IP host only |
| `http://192.168.1.10/verify-account` | 45 | MEDIUM RISK | IP host +25, HTTP +10, keywords verify/account +10 |
| `https://examp1ebank.example/login/verify` | 40 | MEDIUM RISK | lookalike +20, keywords +10, brand + login words +10 |
| `https://examplebank.example@203.0.113.9/login` | 50 | MEDIUM RISK | IP +25, `@` trick +20, keyword +5 |
| `https://xn--exmplebank-0qi.example/login` | 60 | HIGH RISK | lookalike +20, punycode +15, mixed scripts +10, brand + login +10, keyword +5 |
| `http://198.51.100.7/secure-login/verify-account?redirect=…` | 70 | HIGH RISK | IP +25, redirect +15, keywords +15, HTTP +10, long +5 |
| `javascript:alert('demo')` | 60 | HIGH RISK | script scheme +60 |

**Mixed dataset (40 URLs):** 26 LOW, 10 MEDIUM, 4 HIGH, 0 invalid.

The brief's example `http://192.168.1.10/verify-account` scores **45 (MEDIUM)** with the brief's own example
weights (HTTP 10 + IP 25 + keywords 10), not 75. The tool reports what its weights produce, and the weights can be
changed on the Settings page.

## 18. Testing instructions
```bash
venv/bin/python -m pytest -v
```
| File | Tests | Covers |
|---|---|---|
| test_url_parser.py | 28 | valid HTTP/HTTPS, missing scheme, host:port, empty/whitespace/invalid/malformed input (13 cases), too long, IPv6 literal, userinfo, IDN, encoded hostname, javascript:/data:/mailto:, refanging |
| test_domain_analyzer.py | 30 (+4 skipped) | PSL extraction incl. co.uk, com.au, wildcard/exception rules, reserved and unknown TLDs; IPv4/IPv6/decimal/hex/octal/short IPs; IP scope; structure findings; tldextract code path (simulated) |
| test_keyword_detector.py | 10 | locations, in-token matching, whole-token short words, once-only counting, encoded keywords, cap, custom lists, brand domain not scanned |
| test_url_pattern_detector.py | 35 | HTTP vs HTTPS, IP and obfuscated IP, shorteners (+ configurable list), long/very long, subdomains, `@`, encoding/double encoding, redirect parameters, long query, port, characters, scheme-in-hostname, TLDs, lookalikes, wording |
| test_punycode_detector.py | 7 | xn-- detection, legitimate IDN stays LOW, mixed-script lookalike, skeleton, scripts, invalid punycode |
| test_risk_scorer.py | 24 | sum of weights, cap at 100, bands, configurable weights/bands, dedup, severity, recommendations, reference classifications, invalid input |
| test_engine_bulk_reports.py | 19 | CSV/TXT bulk input (headers, BOM, comments, limit), malformed rows, CSV/JSON export, SQLite round trip, sessions, deletes, parameterized queries, PDF contents, sample datasets |
| test_safety_network.py | 41 | **no network access during analysis** (socket calls blocked), no network imports in core modules, features off by default, consent, SSRF guard (localhost, private, link-local, metadata, obfuscated IPs, ports), redirect re-validation and depth limit, RDAP handling, threat-intel key/consent, no API keys in code |
| test_dashboard.py | 19 | all 8 pages headless, single/bulk/sample flows, filters, exports, domain page, history delete/clear, reports, settings |
| test_cli.py | 2 | CLI exit codes and exports |

**Result in the development environment** (Ubuntu 24.04, Python 3.13): **215 passed, 4 skipped**. The 4 skipped
tests compare tldextract with the bundled list and run automatically once `tldextract` is installed; it was not
installable in the build environment. Streamlit and Plotly weren't installable there either, so the dashboard
pages were executed with the stand-ins in `tests/streamlit_stub.py`. See `PROJECT_STATUS.md`.

## 19. Limitations
- **Structure only:**
  - No page content, certificate, hosting or reputation checks by default.
  - A compromised legitimate site gets a low score.
  - A new phishing domain with a clean-looking URL also scores low.
- **Heuristic weights:** not statistically validated. There is no labelled dataset evaluation, so false
  positives (internal IPs, long tracking links, IDNs) and false negatives are expected.
- **Lookalike detection:** only covers configured brands and simple character substitutions. It cannot know all
  of a company's domains.
- **Keyword matching** is language- and wording-dependent.
- **Short links** are not expanded by default.
- **Optional redirect check:** a DNS-rebinding window remains (documented in `services/redirect_checker.py`).
- **Public Suffix List:** the bundled snapshot ages. Update `data/public_suffix_list.dat` or install tldextract.

## 20. Future enhancements
- Opt-in reputation lookups (VirusTotal, Google Safe Browsing) through the prepared `services/threat_intel.py`
  interface, with keys only from environment variables.
- A machine-learning model trained on labelled public datasets, combined with the explainable rules, and an
  evaluation of precision and recall.
- Certificate and hosting metadata, including domain age, as opt-in enrichment.
- A browser extension or e-mail gateway plug-in, and a REST API.
- A larger confusables table (Unicode TR39) and brand lists maintained per organisation.

## 21. Conclusion
The system turns expert knowledge about phishing URLs into a transparent, configurable scoring engine. It
parses URLs robustly, extracts domains correctly, detects a wide range of structural indicators, and explains
each point of the score. It does all of this without ever touching the link. With its dashboard, history,
reports, synthetic datasets and 215 automated tests, it is a complete, demonstrable cybersecurity tool. It also
states its limits clearly: it supports human judgement and does not replace it.
