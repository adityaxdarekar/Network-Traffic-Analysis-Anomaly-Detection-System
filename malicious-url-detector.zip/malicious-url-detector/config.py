"""
Central configuration: paths, thresholds, scoring weights, keyword lists, shortener list, brand list.

Everything that influences a risk score lives here so it can be explained and changed in one place.
User changes made on the dashboard's Settings panel are stored in output/user_settings.json and
merged over DEFAULT_SETTINGS (unknown keys are ignored, missing keys fall back to the defaults).
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
SAMPLES_DIR = BASE_DIR / "samples"
OUTPUT_DIR = BASE_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
DB_PATH = OUTPUT_DIR / "url_scans.db"
SETTINGS_FILE = OUTPUT_DIR / "user_settings.json"
PSL_FILE = DATA_DIR / "public_suffix_list.dat"
STYLE_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "Malicious URL Detection and Risk Assessment System"
APP_SHORT = "URL Risk Analyzer"
APP_VERSION = "1.0.0"

DISCLAIMER = ("Heuristic analysis of the URL text only. The score is not a probability and not a verdict: "
              "a LOW RISK result does not guarantee that a URL is safe, and a HIGH RISK result does not prove "
              "that it is malicious. The URL was not opened or visited.")

RISK_LEVELS = ["LOW RISK", "MEDIUM RISK", "HIGH RISK"]
RISK_COLORS = {"LOW RISK": "#22c55e", "MEDIUM RISK": "#f59e0b", "HIGH RISK": "#ef4444", "INVALID": "#64748b"}
SEVERITIES = ["info", "low", "medium", "high"]

# Reserved / special-use top-level names (RFC 2606, RFC 6761). Treated as TLDs although they are not
# in the Public Suffix List, so example data parses the same way with every backend.
RESERVED_TLDS = {"example", "test", "invalid", "localhost", "local", "internal", "onion"}

# URL shortening services (hostnames). Fictional *.example entries are used by the synthetic samples.
DEFAULT_SHORTENERS = [
    "bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "ow.ly", "buff.ly", "rebrand.ly",
    "tiny.cc", "rb.gy", "shorturl.at", "s.id", "t.ly", "v.gd", "lnkd.in", "bl.ink", "short.io",
    "tiny.example", "lnk.example",           # fictional - for the educational sample data only
]

# Phishing-related keywords, grouped so the explanation can say *why* a word matters.
DEFAULT_KEYWORDS = {
    "credential": ["login", "log-in", "signin", "sign-in", "logon", "password", "passwd", "credential",
                   "authentication", "authenticate", "auth", "account", "verify", "verification", "validate",
                   "confirm", "unlock", "reset", "secure", "update", "suspend", "suspended"],
    "financial": ["payment", "pay", "billing", "invoice", "banking", "bank", "wallet", "refund", "tax",
                  "transfer", "card", "crypto"],
    "lure": ["free", "reward", "gift", "bonus", "prize", "winner", "claim", "promo", "urgent", "limited"],
}

# Fictional brands for the lookalike demonstration (educational test cases, reserved .example TLD).
# Add real organisations for your own environment: brand keyword -> list of its legitimate registered domains.
DEFAULT_BRANDS = {
    "examplebank": ["examplebank.example"],
    "paytrust": ["paytrust.example"],
    "mailhub": ["mailhub.example"],
    "shopnova": ["shopnova.example"],
    "cloudvault": ["cloudvault.example"],
}

# TLDs that are often cheap/abused. A *weak* signal only - many legitimate sites use them.
DEFAULT_SUSPICIOUS_TLDS = ["zip", "mov", "top", "xyz", "click", "country", "gq", "tk", "ml", "cf", "ga",
                           "work", "rest", "support", "cam", "loan"]

# Parameter names commonly used to carry a redirect target.
REDIRECT_PARAMS = ["url", "redirect", "redirect_uri", "redirect_url", "redir", "next", "return", "returnurl",
                   "return_to", "goto", "dest", "destination", "continue", "target", "link", "out", "r", "u"]

DEFAULT_SETTINGS = {
    "thresholds": {
        "long_url": 75,               # characters - "long"
        "very_long_url": 150,         # characters - "very long" (same indicator, higher weight)
        "max_input_length": 4096,     # longer input is rejected as invalid
        "max_subdomains": 3,          # subdomain labels above the registered domain (www counts)
        "max_hyphens": 3,             # hyphens in the hostname
        "max_digits": 6,              # digits in the registered-domain label
        "max_domain_length": 30,      # characters of the registered-domain label
        "max_dots": 5,                # dots in the hostname
        "long_query": 120,            # characters of the query string
        "max_params": 8,              # number of query parameters
        "max_percent_encoded": 10,    # %xx sequences in the URL
        "lookalike_max_distance": 1,  # edit distance for typosquatting of brand domains
    },
    "weights": {
        "http_scheme": 10, "missing_scheme": 5, "unusual_scheme": 15, "dangerous_scheme": 60,
        "ip_host": 25, "obfuscated_ip": 30, "shortener": 10,
        "long_url": 5, "very_long_url": 10,
        "excessive_subdomains": 10, "punycode": 15, "mixed_script": 10,
        "keyword_each": 5, "keyword_max": 15,
        "at_symbol": 20, "unusual_domain_structure": 10, "lookalike_domain": 20, "brand_in_subdomain_or_path": 10,
        "suspicious_tld": 5, "unknown_tld": 5, "url_encoding": 5, "double_encoding": 10,
        "redirect_parameter": 15, "long_query": 5, "nonstandard_port": 5, "suspicious_characters": 5,
        "scheme_in_hostname": 10, "brand_keyword_combination": 10,
    },
    "risk_bands": {"medium": 30, "high": 60},     # 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH
    "shorteners": DEFAULT_SHORTENERS,
    "keywords": DEFAULT_KEYWORDS,
    "brands": DEFAULT_BRANDS,
    "suspicious_tlds": DEFAULT_SUSPICIOUS_TLDS,
    # Optional network features - all OFF by default (see services/).
    "network": {"allow_domain_age_lookup": False, "allow_redirect_check": False, "timeout_seconds": 5,
                "max_redirects": 5},
}


def default_settings() -> dict:
    return copy.deepcopy(DEFAULT_SETTINGS)


def _merge(base: dict, override: dict) -> dict:
    for key, value in override.items():
        if key not in base:
            continue
        if isinstance(base[key], dict) and isinstance(value, dict) and key not in ("keywords", "brands"):
            _merge(base[key], value)
        elif type(base[key]) is type(value) or (isinstance(base[key], (int, float)) and isinstance(value, (int, float))):
            base[key] = value
    return base


def load_settings(path: Path | None = None) -> dict:
    path = Path(path or SETTINGS_FILE)
    settings = default_settings()
    if path.exists():
        try:
            _merge(settings, json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass                                   # corrupt file -> defaults
    return settings


def save_settings(settings: dict, path: Path | None = None) -> Path:
    path = Path(path or SETTINGS_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    return path
