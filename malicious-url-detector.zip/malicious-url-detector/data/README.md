# Bundled Public Suffix List

`public_suffix_list.dat` is the official Public Suffix List (https://publicsuffix.org/), snapshot dated
2025-12-28, licensed under the Mozilla Public License 2.0 (header of the file). It is used offline for
domain extraction when the `tldextract` package is not installed. Only the ICANN section is used, which
matches tldextract's default behaviour. Update it by downloading the current list from publicsuffix.org.
