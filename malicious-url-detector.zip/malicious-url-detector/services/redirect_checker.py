"""
OPTIONAL redirect inspection - disabled by default; only runs after the user explicitly enables it in
Settings AND clicks the button on the Single URL page (which shows a warning first).

What it does:
  * sends HEAD requests (GET with stream=True only if HEAD is rejected), never reads or saves the body;
  * follows at most `max_redirects` hops manually (allow_redirects=False) with a strict timeout;
  * re-validates EVERY destination with network_guard.check_destination (http/https on 80/443 only,
    no localhost/private/link-local/metadata addresses);
  * never executes JavaScript and never downloads files.

Limitation: the address is checked when resolved here, and `requests` resolves the name again when
connecting (a DNS-rebinding window). In this educational tool the risk is reduced by the public-address
check on each hop; a production service would pin the resolved IP.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit

from services.network_guard import UnsafeDestination, check_destination

USER_AGENT = "URL-Risk-Analyzer/1.0 (educational; redirect check only)"


@dataclass
class RedirectHop:
    url: str
    status: int | None = None
    location: str = ""
    note: str = ""


@dataclass
class RedirectReport:
    start_url: str
    hops: list = field(default_factory=list)
    final_url: str = ""
    stopped_reason: str = ""


def check_redirects(url: str, settings: dict, consent: bool, session=None, resolver=None) -> RedirectReport:
    net = settings["network"]
    report = RedirectReport(start_url=url)
    if not net.get("allow_redirect_check"):
        report.stopped_reason = "redirect check is disabled in Settings"
        return report
    if not consent:
        report.stopped_reason = "no user consent given for this request"
        return report
    if session is None:
        import requests                            # imported only when the feature is really used
        session = requests.Session()
        session.trust_env = False                  # ignore proxy env settings
    kwargs = {"resolver": resolver} if resolver else {}
    current = url
    for _ in range(int(net.get("max_redirects", 5)) + 1):
        parts = urlsplit(current)
        try:
            check_destination(parts.scheme.lower(), parts.hostname or "", parts.port, **kwargs)
        except UnsafeDestination as exc:
            report.hops.append(RedirectHop(current, note=f"blocked: {exc}"))
            report.stopped_reason = f"stopped - unsafe destination ({exc})"
            return report
        try:
            resp = session.head(current, allow_redirects=False, timeout=net.get("timeout_seconds", 5),
                                headers={"User-Agent": USER_AGENT})
            if resp.status_code in (405, 501):
                resp = session.get(current, allow_redirects=False, timeout=net.get("timeout_seconds", 5),
                                   headers={"User-Agent": USER_AGENT}, stream=True)
                resp.close()                         # never read the body
        except Exception as exc:                    # network errors are reported, not raised
            report.hops.append(RedirectHop(current, note=f"request failed: {exc.__class__.__name__}"))
            report.stopped_reason = "network error"
            return report
        location = resp.headers.get("Location", "") if 300 <= resp.status_code < 400 else ""
        report.hops.append(RedirectHop(current, resp.status_code, location))
        if not location:
            report.final_url = current
            report.stopped_reason = "final destination reached"
            return report
        current = urljoin(current, location)
    report.stopped_reason = f"stopped after {net.get('max_redirects', 5)} redirects"
    return report
