"""
OPTIONAL domain-age lookup via RDAP (the successor of WHOIS) - disabled by default.

Only the registered DOMAIN (not the full URL, path or query) is sent, only after the user enabled the
feature in Settings and confirmed the lookup, to the public RDAP redirector https://rdap.org/domain/<domain>.
Missing or unavailable registration data is reported as "unknown" - never as a sign of maliciousness.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone

RDAP_URL = "https://rdap.org/domain/{domain}"
_DOMAIN_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9-]{1,63}\.)+[a-z0-9-]{2,63}$")


@dataclass
class DomainAge:
    domain: str
    status: str                  # ok / disabled / no_consent / invalid / unavailable / error
    registered: str = ""
    age_days: int | None = None
    note: str = ""


def lookup(domain: str, settings: dict, consent: bool, session=None, now: datetime | None = None) -> DomainAge:
    net = settings["network"]
    domain = (domain or "").lower().strip(".")
    if not net.get("allow_domain_age_lookup"):
        return DomainAge(domain, "disabled", note="Domain-age lookup is disabled in Settings.")
    if not consent:
        return DomainAge(domain, "no_consent", note="The lookup needs your confirmation.")
    if not _DOMAIN_RE.match(domain) or domain.split(".")[-1] in ("example", "test", "invalid", "localhost"):
        return DomainAge(domain, "invalid", note="Not a registrable public domain (reserved or malformed).")
    if session is None:
        import requests
        session = requests.Session()
        session.trust_env = False
    try:
        resp = session.get(RDAP_URL.format(domain=domain), timeout=net.get("timeout_seconds", 5),
                           headers={"Accept": "application/rdap+json"})
    except Exception as exc:
        return DomainAge(domain, "error", note=f"Network error ({exc.__class__.__name__}) - age unknown.")
    if resp.status_code != 200:
        return DomainAge(domain, "unavailable", note=f"No RDAP data (HTTP {resp.status_code}) - age unknown, "
                                                     "which is NOT evidence of maliciousness.")
    try:
        data = resp.json()
    except ValueError:
        return DomainAge(domain, "error", note="Unreadable RDAP response - age unknown.")
    reg = next((e.get("eventDate") for e in data.get("events", []) if e.get("eventAction") == "registration"), None)
    if not reg:
        return DomainAge(domain, "unavailable", note="Registry did not publish a registration date.")
    try:
        when = datetime.fromisoformat(reg.replace("Z", "+00:00"))
    except ValueError:
        return DomainAge(domain, "unavailable", registered=reg, note="Unrecognised date format.")
    now = now or datetime.now(timezone.utc)
    age = (now - when).days
    note = "Recently registered domains are more often used for phishing - a weak signal, not proof." \
        if age < 90 else "Domain is not newly registered (old domains can still be compromised)."
    return DomainAge(domain, "ok", when.date().isoformat(), age, note)
