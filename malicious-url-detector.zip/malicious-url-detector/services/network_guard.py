"""
Safety checks for the OPTIONAL network features (disabled by default).

is_public_destination() refuses anything that is not a normal public internet address:
localhost, private ranges (RFC 1918, ULA), link-local (incl. the cloud metadata address 169.254.169.254),
loopback, multicast, reserved, unspecified, and obfuscated IP forms. Hostnames are resolved and EVERY
resolved address must be public. Used before every request and for every redirect hop.
"""

from __future__ import annotations

import ipaddress
import socket

BLOCKED_HOSTNAMES = {"localhost", "localhost.localdomain", "metadata", "metadata.google.internal",
                     "instance-data", "instance-data.ec2.internal"}
METADATA_IPS = {"169.254.169.254", "fd00:ec2::254", "100.100.100.200"}
ALLOWED_SCHEMES = {"http", "https"}
ALLOWED_PORTS = {None, 80, 443}


class UnsafeDestination(ValueError):
    pass


def ip_is_public(ip_text: str) -> bool:
    ip = ipaddress.ip_address(ip_text.split("%")[0])
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    if str(ip) in METADATA_IPS:
        return False
    return ip.is_global and not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                                 or ip.is_reserved or ip.is_unspecified)


def check_destination(scheme: str, host: str, port: int | None, resolver=socket.getaddrinfo) -> list[str]:
    """Raise UnsafeDestination unless scheme/port are web defaults and all resolved IPs are public.
    Returns the resolved IP list."""
    from detector.domain_analyzer import parse_ip_host
    if scheme not in ALLOWED_SCHEMES:
        raise UnsafeDestination(f"scheme '{scheme}' is not allowed")
    if port not in ALLOWED_PORTS:
        raise UnsafeDestination(f"port {port} is not allowed (only 80/443)")
    h = (host or "").strip("[]").lower().rstrip(".")
    if not h or h in BLOCKED_HOSTNAMES or h.endswith((".localhost", ".local", ".internal")):
        raise UnsafeDestination(f"host '{host}' is not allowed")
    ip, form = parse_ip_host(h)
    if ip:
        if form == "obfuscated":
            raise UnsafeDestination("obfuscated IP addresses are not contacted")
        if not ip_is_public(ip):
            raise UnsafeDestination(f"{ip} is not a public address")
        return [ip]
    try:
        infos = resolver(h, port or (443 if scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except (socket.gaierror, OSError) as exc:
        raise UnsafeDestination(f"cannot resolve '{h}': {exc}") from exc
    ips = sorted({info[4][0] for info in infos})
    if not ips:
        raise UnsafeDestination(f"'{h}' did not resolve")
    bad = [a for a in ips if not ip_is_public(a)]
    if bad:
        raise UnsafeDestination(f"'{h}' resolves to non-public address(es): {', '.join(bad)}")
    return ips
