"""
Interface for FUTURE external threat-intelligence lookups (VirusTotal, Google Safe Browsing ...).

Nothing here contacts any service. Providers are disabled unless:
  1. an API key is present in an ENVIRONMENT VARIABLE (never in source code or config files), and
  2. the caller passes consent=True for that specific lookup.
Even then, the concrete HTTP calls are deliberately not implemented in this version - the classes show
where an integration would go and how consent and keys are handled.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ReputationResult:
    provider: str
    status: str           # not_configured / no_consent / not_implemented / ok / error
    verdict: str = ""
    detail: str = ""


class ThreatIntelProvider(ABC):
    name = "provider"
    env_var = ""

    @property
    def configured(self) -> bool:
        return bool(self.env_var and os.environ.get(self.env_var))

    def check(self, url: str, consent: bool) -> ReputationResult:
        if not self.configured:
            return ReputationResult(self.name, "not_configured", detail=f"set {self.env_var} to enable")
        if not consent:
            return ReputationResult(self.name, "no_consent", detail="the user did not approve sending this URL")
        return self._lookup(url)

    @abstractmethod
    def _lookup(self, url: str) -> ReputationResult: ...


class VirusTotalProvider(ThreatIntelProvider):
    name = "VirusTotal"
    env_var = "VIRUSTOTAL_API_KEY"

    def _lookup(self, url: str) -> ReputationResult:
        return ReputationResult(self.name, "not_implemented",
                                detail="Integration point for the VirusTotal URL API (future work).")


class SafeBrowsingProvider(ThreatIntelProvider):
    name = "Google Safe Browsing"
    env_var = "SAFE_BROWSING_API_KEY"

    def _lookup(self, url: str) -> ReputationResult:
        return ReputationResult(self.name, "not_implemented",
                                detail="Integration point for the Safe Browsing Lookup API (future work).")


PROVIDERS = [VirusTotalProvider(), SafeBrowsingProvider()]
