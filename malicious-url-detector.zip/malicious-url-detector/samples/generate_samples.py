"""
Create the SYNTHETIC educational URL datasets in samples/.

All hostnames use reserved names (example.com/.org/.net, *.example, *.test, *.invalid - RFC 2606/6761),
documentation or private IP ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24, 10/8, 192.168/16,
2001:db8::/32) or fictional brands. "tiny.example" / "lnk.example" are fictional shorteners.
None of these URLs points to a real malicious site. Nothing is ever visited.

The files are split by the classification the analyzer actually gives (run this script again after
changing weights):  low_risk_urls.csv, suspicious_urls.csv (MEDIUM), high_risk_urls.csv, mixed_urls.csv (all).

    python samples/generate_samples.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from detector.detection_engine import analyze_url  # noqa: E402

# (url, category, description)
SAMPLES = [
    # --- 10 ordinary, legitimate-looking examples
    ("https://www.example.com/", "ordinary", "Plain HTTPS home page"),
    ("https://example.org/about-us", "ordinary", "HTTPS page with a simple path"),
    ("https://docs.example.net/guide/getting-started", "ordinary", "Documentation subdomain"),
    ("https://www.example.com/products?id=1024&lang=en", "ordinary", "Short query string"),
    ("https://blog.example.org/2026/11/security-awareness-tips", "ordinary", "Dated blog article"),
    ("https://shop.example.com/cart", "ordinary", "Shop subdomain"),
    ("https://example.co.uk/contact", "ordinary", "Multi-part public suffix co.uk"),
    ("https://university.example.edu/library/catalogue", "ordinary", "University-style hostname"),
    ("https://www.examplebank.example/personal/accounts", "ordinary", "Fictional brand on its own listed domain"),
    ("https://münchen.example/stadtplan", "ordinary", "Legitimate internationalized (IDN) domain"),
    # --- 5 HTTP examples
    ("http://example.com/news", "http", "Unencrypted HTTP only"),
    ("http://intranet.example.org/wiki/start", "http", "Internal wiki over HTTP"),
    ("http://example.net/login", "http", "HTTP login page"),
    ("http://www.example.com/account/update-payment", "http", "HTTP with account/payment words"),
    ("example.org/downloads/manual", "http", "No scheme given (analysed as HTTP)"),
    # --- 5 IP-based examples
    ("http://192.0.2.10/", "ip", "Documentation IPv4 address, HTTP"),
    ("https://198.51.100.25/portal", "ip", "Documentation IPv4 address over HTTPS"),
    ("http://192.168.1.10/verify-account", "ip", "Private IPv4 with verification words"),
    ("http://[2001:db8::10]:8080/admin/login", "ip", "IPv6 literal with non-standard port"),
    ("http://3232235786/secure-login", "ip", "Decimal-obfuscated IPv4 (= 192.168.1.10)"),
    # --- 5 suspicious keyword examples
    ("https://example.com/account/verify?step=confirm", "keywords", "Account verification wording"),
    ("https://rewards.example.net/claim-your-free-gift-bonus", "keywords", "Reward / gift lure wording"),
    ("https://secure-login.example.org/password-reset", "keywords", "Login + password reset wording"),
    ("https://example.net/billing/update-payment-details?urgent=1", "keywords", "Billing update with urgency"),
    ("https://wallet.example.com/authentication/unlock", "keywords", "Wallet unlock wording"),
    # --- 5 unusual domain structure examples
    ("http://a.b.c.d.e.example.com/x", "structure", "Deep subdomain chain"),
    ("https://secure-update-account-verify-billing.example/confirm", "structure", "Many hyphens and a very long domain name"),
    ("https://www.examplebank.example.verify-account.test/login", "structure", "Brand domain embedded in a subdomain"),
    ("https://login-x7k29q4831.example.invalid/session", "structure", "Random-looking digits in the hostname"),
    ("https://https-www-secure.example.test/signin", "structure", "'https'/'www' used inside the hostname"),
    # --- shorteners, punycode, lookalikes, '@', encoding, redirects, scheme tricks
    ("https://tiny.example/AbC123", "shortener", "Fictional URL shortener"),
    ("https://lnk.example/r/free-reward", "shortener", "Fictional shortener with lure words"),
    ("https://xn--exmplebank-0qi.example/login", "punycode", "Punycode: Cyrillic 'а' imitating examplebank"),
    ("https://examp1ebank.example/login/verify", "lookalike", "Digit '1' instead of letter 'l'"),
    ("https://examplebank-secure-login.example.net/verify", "lookalike", "Brand name inside another domain"),
    ("https://examplebank.example@203.0.113.9/login", "at_symbol", "'@' trick: real host is the IP after '@'"),
    ("https://example.com/redirect?url=https%3A%2F%2Fpaytrust-verify.example.org%2Flogin", "redirect",
     "Encoded redirect to a brand-lookalike host"),
    ("http://198.51.100.7/secure-login/verify-account?redirect=https%3A%2F%2Fexample.net%2Fpay", "combined",
     "IP + HTTP + keywords + redirect parameter"),
    ("http://203.0.113.50:8080/paytrust/login/verify-payment?next=http%3A%2F%2Fexample.org%2F%2525&session="
     + "A" * 90, "combined", "Many indicators at once (very long, double-encoded)"),
    ("javascript:alert('demo')", "scheme", "Script scheme instead of a web address"),
]


def main() -> int:
    out = {"LOW RISK": [], "MEDIUM RISK": [], "HIGH RISK": []}
    mixed = []
    for url, cat, desc in SAMPLES:
        r = analyze_url(url)
        row = {"url": url, "category": cat, "description": desc,
               "label": "SYNTHETIC EDUCATIONAL TEST DATA - do not visit"}
        mixed.append(row)
        out.setdefault(r.classification, []).append(row)
    names = {"LOW RISK": "low_risk_urls.csv", "MEDIUM RISK": "suspicious_urls.csv", "HIGH RISK": "high_risk_urls.csv"}
    for level, fname in names.items():
        write(ROOT / "samples" / fname, out[level])
    write(ROOT / "samples" / "mixed_urls.csv", mixed)
    print({k: len(v) for k, v in out.items()}, "mixed:", len(mixed))
    return 0


def write(path: Path, rows: list) -> None:
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["url", "category", "description", "label"])
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    sys.exit(main())
