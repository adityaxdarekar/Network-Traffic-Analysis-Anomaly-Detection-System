# Malicious URL Detection and Risk Assessment System Using Python
### College Project Report - Cybersecurity

---

## Abstract
Phishing and malware campaigns depend on links that look trustworthy but lead elsewhere. This project presents
a Python-based system that assesses the risk of a URL by analysing its structure, without ever visiting it.

The system:
- parses and validates the URL
- extracts the registered domain with the Public Suffix List
- examines a set of heuristic indicators: insecure or unusual schemes, IP-based and obfuscated IP hosts, URL
  shorteners, excessive length and subdomains, the `@` userinfo trick, unusual encoding, embedded redirect
  targets, punycode and mixed-script hostnames, phishing-related keywords, and lookalike domains of configured
  brands
- combines the indicators in a weighted rule-based scoring engine (capped at 100) and classifies the URL as low,
  medium or high risk
- explains every contributing indicator and recommends next steps

The application provides a Streamlit dashboard, bulk analysis of CSV/TXT files, an SQLite scan history, and
PDF, CSV and JSON reports. Optional online checks for redirects and domain age are disabled by default and
protected against server-side request forgery. A suite of 215 automated tests verifies parsing, detection,
scoring, storage, reporting, the user interface and the absence of network access.

The result is an explainable, safe educational tool that supports, but does not replace, human judgement.

## 1. Introduction
URLs are the entry point of most social-engineering attacks. Security teams use reputation services and
sandboxes, but these depend on prior knowledge or require visiting the link. A complementary approach examines
the URL's lexical and structural features, which attackers manipulate to deceive users. This project implements
that approach transparently: each feature is a documented rule with a configurable weight, so the resulting
score can be explained to users, students and analysts.

## 2. Problem statement
- Users cannot reliably recognise deceptive URLs: lookalike characters, brand names in subdomains, `@`
  redirection, hidden destinations.
- Opaque "safe/unsafe" verdicts give no reasons and suggest certainty that structure alone cannot provide.
- Checking a link by opening it is unsafe.

The aim is therefore a local tool that analyses URL text only, quantifies the risk heuristically, and explains
the result.

## 3. Existing system
| Approach | Strength | Weakness |
|---|---|---|
| Manual inspection | no tools needed | slow, error-prone, misses punycode and lookalikes |
| Blocklists / reputation services (e.g. Safe Browsing, VirusTotal) | high precision for known threats | miss new URLs, require sending the URL to a third party |
| Sandboxes / crawlers | observe real behaviour | need isolation and infrastructure; visiting can be risky |
| ML classifiers | can generalise | often black boxes; need labelled data |

## 4. Proposed system
An explainable, rule-based URL analyser:
- robust parsing and Public-Suffix-List domain extraction
- modular detectors for 27 indicator types, plus capped keyword scoring
- a configurable scoring engine with deduplication and risk bands
- recommendations per classification and indicator
- a dashboard, bulk analysis, history, reports and a CLI
- strictly offline by default, with optional, consented online checks guarded against unsafe destinations

## 5. Objectives
1. Validate and parse URLs safely.
2. Extract domain components correctly.
3. Detect the indicators listed in the project brief.
4. Score, classify and explain.
5. Store history and generate reports.
6. Provide a usable dashboard.
7. Verify everything with automated tests.

## 6. Scope
**In scope:**
- lexical and structural URL analysis
- configurable lists (keywords, shorteners, brands, TLDs)
- single and bulk analysis
- SQLite history
- PDF, CSV and JSON reports
- an optional redirect check and RDAP domain-age lookup (disabled by default)
- an interface for future threat-intelligence providers

**Out of scope:**
- fetching or rendering page content
- certificate analysis
- machine-learning classification
- blocking or quarantining links
- real-time e-mail or browser integration

## 7. Hardware requirements
| Component | Minimum |
|---|---|
| Processor | dual-core 64-bit |
| RAM | 4 GB |
| Disk | 500 MB (application, virtual environment, history) |
| Network | only for installing packages, and optionally for the opt-in online checks |

## 8. Software requirements
- Windows 10/11, Linux or macOS
- Python 3.11 or newer
- streamlit, pandas, plotly, tldextract, reportlab, requests (optional features), pytest and pypdf
- A modern web browser

## 9. System architecture
```
User → Streamlit dashboard / CLI
        → Detection engine
            → URL parser → Domain analyzer (PSL / tldextract offline)
            → Punycode detector, Keyword detector, URL pattern detector (incl. lookalikes)
            → Risk scorer (deduplicate → weights → cap 100 → bands → recommendations)
        → SQLite (url_scans, url_indicators, bulk_scan_sessions)
        → Report generator (PDF / CSV / JSON)
Optional services (off by default): network guard → redirect checker, RDAP domain age; threat-intel interface
```

## 10. Module descriptions
| Module | Description |
|---|---|
| `url_parser.py` | Strips and validates input: empty, whitespace, control characters, length, ports, IPv6 literals and hostname characters. Refangs `hxxp`/`[.]`, adds a missing scheme, separates userinfo, converts IDN to punycode, and produces a normalised URL. Never raises for bad input. |
| `domain_analyzer.py` | Public Suffix List algorithm (rules, wildcards, exceptions) or offline tldextract; handles reserved and unknown TLDs. Decodes IPv4/IPv6 and obfuscated IPv4 forms and their scope. Reports counts and structural findings. |
| `punycode_detector.py` | Finds `xn--` labels, decodes them, detects mixed Unicode scripts per label, and computes a confusable "skeleton". |
| `keyword_detector.py` | Tokenises the subdomain, domain, path and query (double-decoded). Matches 44 configurable keywords in 3 categories with token rules, counts each keyword once and caps the score. |
| `url_pattern_detector.py` | Scheme, IP, shortener, length, `@`, encoding, redirect parameters, query size, port, unusual characters, subdomains, TLD, domain structure and lookalike detection (brand list, character normalisation, Damerau-Levenshtein distance). |
| `risk_scorer.py` | Deduplication with supersession rules, weights, severity, cap, classification and recommendations. |
| `detection_engine.py` | Orchestrates the detectors. Also handles bulk file reading (CSV/TXT), counts and exports. |
| `db_manager.py` | SQLite schema, parameterized queries, cascade deletes, overview statistics. |
| `pdf_generator.py` | Single-URL and bulk PDF reports, including limitations. |
| `services/*` | Network guard (public-address-only policy), redirect checker, RDAP domain age, threat-intel provider interface. |
| `dashboard/*`, `app.py` | Eight Streamlit pages. |
| `cli.py` | Terminal analysis and exports. |

## 11. Detection algorithms
**Parsing.**
1. Strip the input and validate it.
2. Refang it.
3. Detect the scheme. "host:port" is not taken as a scheme, and a missing scheme becomes `http://` with a flag.
   Non-web schemes are kept without a host.
4. Split with `urllib.parse.urlsplit`.
5. Separate the userinfo before the last `@`.
6. Validate the port and any IPv6 literal.
7. Decode a percent-encoded host, with a flag.
8. Convert IDN to punycode.
9. Check hostname characters and label lengths.

**Domain extraction (PSL algorithm).** For hostname labels l₁…lₙ, find the longest suffix that matches:
- a rule
- a wildcard `*.x`, where the parent matches
- an exception `!x`, where the suffix is the exception minus its first label

The registered domain is the suffix plus one label, and the rest is the subdomain. If nothing matches (reserved
or unknown TLD), the last label is the TLD.

**Obfuscated IPv4.**
1. The host consists of 1-4 parts of digits, hex `0x..` or octal `0..`.
2. Parse each part.
3. Apply inet_aton rules: the last part fills the remaining bytes.
4. Accept the host only if every part is within range.

**Lookalikes.**
1. If the registered domain is in the brand list, there is no finding.
2. Brand name inside the raw domain label → "brand in unlisted domain".
3. Brand name inside the normalised label (confusables → ASCII; 0→o, 1→l, 3→e, 5→s; rn→m; vv→w; hyphens
   removed) → "lookalike characters".
4. Damerau-Levenshtein distance between the normalised label and the brand ≤ 1 → "close name".
5. Otherwise, a brand in a subdomain or path → a weaker indicator.

**Keywords.**
1. Split the text into tokens `[a-z0-9]+`.
2. A keyword of 5 or more characters matches as a substring of a token; shorter keywords must equal a whole
   token.
3. Count each keyword once.
4. Score min(5·n, 15).

**Redirect parameter.** A parameter value starting with `http(s)://` or `//`, or a known redirect-parameter name
with a domain-like value, whose host is not the URL's own registered domain.

## 12. Risk scoring methodology
- **Score:** S = min(100, Σ wᵢ) over the distinct indicators *i*, after supersession:
  - very-long replaces long
  - obfuscated IP replaces IP
  - double encoding replaces encoding
  - lookalike replaces brand-in-subdomain
  - script scheme replaces other scheme findings
- **Default weights:** these follow the brief: HTTP 10, IP 25, shortener 10, long URL 5/10, subdomains 10,
  punycode 15, keywords 5-15, `@` 20, structure 10, lookalike 20. They are extended by:
  - obfuscated IP 30
  - script scheme 60
  - redirect parameter 15
  - mixed scripts 10
  - brand + keyword combination 10
  - other minor indicators 5
- **Classification:** 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH.
- **Severity of an indicator:** weight ≥ 20 high, ≥ 10 medium, otherwise low.
- **Interpretation:** the score measures the accumulation of warning signs. It is **not** a probability of
  maliciousness, because the weights were set by expert judgement, not fitted to labelled data.

## 13. Implementation
- **Size:** about 2,800 lines of Python in the application and about 1,100 lines of tests.
- **Configuration:** centralised in `config.py`, with user overrides in JSON. Unknown or mistyped keys are
  ignored.
- **Domain extraction:** tldextract when it is installed, created offline with `suffix_list_urls=()`. Otherwise
  the bundled Public Suffix List snapshot is used.
- **Safety:** the detector, report, database and dashboard modules import no network libraries; a test enforces
  this. The optional services resolve every destination and accept only public addresses on ports 80/443. They
  re-validate every redirect hop, send HEAD requests without reading bodies, and use timeouts and a hop limit.
- **Storage:** SQLite with foreign keys and cascading deletes. All queries are parameterized.
- **Dashboard:**
  - **Overview:** metrics, risk-distribution chart, top indicators, recent scans.
  - **Single URL:** score gauge, findings, recommendations, components, domain structure, PDF.
  - **Bulk:** upload CSV or TXT, or load the samples; filter, search, sort; export.
  - **Domain Analysis.**
  - **Scan History:** with delete.
  - **Reports.**
  - **Settings.**
  - **About.**

## 14. Testing
pytest, 215 tests on synthetic data. All 215 passed in the development environment, and 4 more were skipped
(tldextract-comparison tests, because the package was not installed there).

| Area | Tests |
|---|---|
| URL parser (valid/invalid/malformed/IPv6/IDN/schemes) | 28 |
| Domain analyzer (PSL, IP forms, structure) | 30 (+4 skipped) |
| Keyword detector | 10 |
| URL pattern detector (incl. lookalikes) | 35 |
| Punycode detector | 7 |
| Risk scorer | 24 |
| Bulk input, exports, database, PDF, sample datasets | 19 |
| Safety (no network access, SSRF guard, consent, no API keys) | 41 |
| Dashboard (all pages, headless) | 19 |
| CLI | 2 |

The dashboard tests run every page with stand-ins for Streamlit and Plotly, because these packages could not be
installed in the build environment. The visual appearance should be checked by running the app.

## 15. Results
- **Sample dataset:** 40 synthetic URLs give 26 LOW, 10 MEDIUM and 4 HIGH.
  - Every ordinary URL scored LOW. The legitimate IDN `münchen.example` scored 15 (flagged for inspection only).
  - Combined deceptive patterns were ranked highest:
    - IP + HTTP + keywords + redirect: 70
    - a punycode lookalike with mixed scripts: 60
    - a script scheme: 60
    - a many-indicator URL: capped at 100
  - Single weak indicators stayed low, as intended. Examples: an IP over HTTPS (25), a shortener (10), an HTTP
    news page (10).
- **Performance:** analysing the 40 samples takes well under a second. The whole test suite, including PDF
  generation, runs in about 3 seconds.

## 16. Advantages
- Fully explainable: each point of the score has a named indicator, an explanation and the evidence.
- Safe: no visiting, resolving or uploading of URLs. Optional features need opt-in and per-request consent.
- Correct domain handling via the Public Suffix List; handles IDN and obfuscated IPs.
- Configurable without code changes. Suitable for teaching and awareness training.

## 17. Limitations
- **Structure only:** compromised legitimate sites and clean-looking new phishing domains can score low.
- **Expert-set weights:** not statistically validated, so false positives and false negatives are expected.
- **Lookalike detection:** limited to configured brands and simple substitutions.
- **Keywords:** English-centric.
- **Shortened URLs:** not expanded by default.
- **Bundled Public Suffix List:** needs periodic updates.

## 18. Future scope
- Evaluation on labelled datasets, and hybrid rule + machine-learning scoring.
- Opt-in reputation services through the provided interface.
- Certificate, hosting and domain-age enrichment.
- A browser extension, mail gateway or REST API.
- Complete Unicode confusables data.

## 19. Conclusion
The project delivers a working, tested and explainable URL risk assessment tool. It shows how attackers
manipulate URL structure and how those manipulations can be detected safely. By pairing every score with
reasons and stated limitations, it supports responsible security decisions rather than replacing them.

## 20. References
1. T. Berners-Lee, R. Fielding, L. Masinter, *RFC 3986: Uniform Resource Identifier (URI): Generic Syntax*, IETF, 2005.
2. D. Eastlake, A. Panitz, *RFC 2606: Reserved Top Level DNS Names*, IETF, 1999; S. Cheshire, M. Krochmal, *RFC 6761: Special-Use Domain Names*, 2013.
3. A. Costello, *RFC 3492: Punycode*, IETF, 2003; J. Klensin, *RFC 5890-5891: IDNA2008*, IETF, 2010.
4. Unicode Consortium, *UTS #39: Unicode Security Mechanisms* (confusables).
5. Mozilla Foundation, *Public Suffix List*, https://publicsuffix.org/
6. RFC 5737 (IPv4 documentation addresses) and RFC 3849 (IPv6 documentation prefix), IETF.
7. RFC 9083: *JSON Responses for the Registration Data Access Protocol (RDAP)*, IETF, 2021.
8. OWASP, *Server-Side Request Forgery Prevention Cheat Sheet*.
9. Anti-Phishing Working Group (APWG), *Phishing Activity Trends Reports*.
10. MITRE ATT&CK, *T1566 Phishing* and *T1583.001 Acquire Infrastructure: Domains*.
11. Python Software Foundation, documentation of `urllib.parse`, `ipaddress`, `re`, `sqlite3`.
12. Documentation of Streamlit, pandas, Plotly, ReportLab, tldextract and pytest.
