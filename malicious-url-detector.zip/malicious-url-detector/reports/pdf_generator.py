"""
PDF reports with ReportLab - single-URL report and bulk-analysis report.

Reports contain the URL text and the analysis; they never contain fetched page content (nothing is
fetched). Long URLs are wrapped; all text is escaped for ReportLab's mini-markup.
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

import config as C

LIMITATIONS = [
    "Heuristic, rule-based analysis of the URL text only - the score is not a probability of maliciousness.",
    "LOW RISK does not mean safe: a compromised legitimate site or a new phishing domain can look harmless.",
    "HIGH RISK does not prove that a URL is malicious: internal systems, test servers and unusual but "
    "legitimate URLs also trigger indicators.",
    "The URL was not visited, resolved or sent to any external service; page content, certificates, "
    "domain age and reputation were not checked unless explicitly stated.",
    "Lookalike detection compares against a configurable brand list and cannot know every legitimate domain.",
]

_SEV_COLOR = {"high": "#b91c1c", "medium": "#b45309", "low": "#1d4ed8", "info": "#475569"}
_CLASS_COLOR = {"LOW RISK": "#15803d", "MEDIUM RISK": "#b45309", "HIGH RISK": "#b91c1c", "INVALID": "#475569"}


def _styles():
    ss = getSampleStyleSheet()
    s = {
        "title": ParagraphStyle("t", parent=ss["Title"], fontSize=17, leading=21, textColor=colors.HexColor("#0f172a")),
        "sub": ParagraphStyle("s", parent=ss["Normal"], fontSize=9, textColor=colors.HexColor("#475569")),
        "h": ParagraphStyle("h", parent=ss["Heading2"], fontSize=12.5, spaceBefore=10, spaceAfter=4,
                            textColor=colors.HexColor("#0f172a")),
        "p": ParagraphStyle("p", parent=ss["Normal"], fontSize=9.2, leading=12.5),
        "small": ParagraphStyle("sm", parent=ss["Normal"], fontSize=8, leading=10.5, textColor=colors.HexColor("#334155")),
        "mono": ParagraphStyle("m", parent=ss["Normal"], fontName="Courier", fontSize=8.3, leading=10.5,
                               wordWrap="CJK"),
        "cell": ParagraphStyle("c", parent=ss["Normal"], fontSize=8.2, leading=10.2, wordWrap="CJK"),
    }
    return s


def _e(value) -> str:
    return escape("" if value is None else str(value))


def _table(rows, widths, header=True, styles=None):
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    ts = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
          ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    if header:
        ts += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0f172a")),
               ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, 0), 8.5)]
    t.setStyle(TableStyle(ts + (styles or [])))
    return t


def _kv(rows, s):
    return _table([[Paragraph(f"<b>{_e(k)}</b>", s["cell"]), Paragraph(_e(v), s["cell"])] for k, v in rows],
                  [45 * mm, 125 * mm], header=False,
                  styles=[("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f1f5f9"))])


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.drawString(15 * mm, 10 * mm, f"{C.APP_TITLE} - heuristic analysis, not a verdict")
    canvas.drawRightString(195 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def _result_story(result, s, scan_id=None) -> list:
    story = []
    p, d = result.parsed, result.domain
    col = _CLASS_COLOR.get(result.classification, "#475569")
    story.append(Paragraph(f"<font color='{col}'><b>{_e(result.classification)}</b></font> &nbsp; "
                           f"Risk score <b>{result.score}/100</b>", ParagraphStyle("big", fontSize=15, leading=19)))
    story.append(Spacer(1, 4))
    story.append(_kv([("Scan ID", scan_id if scan_id is not None else "not stored"),
                      ("Date and time", result.analyzed_at),
                      ("Submitted URL", result.submitted),
                      ("Normalized URL", p.normalized if p and result.valid else "-")], s))
    if not result.valid:
        story.append(Spacer(1, 6))
        story.append(Paragraph(f"<b>Invalid input:</b> {_e(result.error)}", s["p"]))
        return story

    story.append(Paragraph("URL components", s["h"]))
    story.append(_kv([("Scheme", p.scheme or "-"), ("HTTPS status", result.https_status),
                      ("Hostname", p.hostname or "-"),
                      ("Hostname (decoded)", p.hostname_unicode if p.hostname_unicode != p.hostname else "same"),
                      ("Port", p.port or "default"), ("Path", p.path or "/"), ("Query", p.query or "-"),
                      ("Fragment", p.fragment or "-"), ("User info before '@'", p.userinfo or "-"),
                      ("URL length", f"{p.length} characters")], s))
    if d is not None:
        story.append(Paragraph("Domain analysis", s["h"]))
        if d.is_ip:
            rows = [("IP-based URL", f"YES - {d.ip} ({d.ip_form}, {d.ip_scope})")]
        else:
            rows = [("IP-based URL", "no"), ("Registered domain", d.registered_domain),
                    ("Subdomain", d.subdomain or "-"), ("Subdomain count", d.subdomain_count),
                    ("Public suffix / TLD", f"{d.suffix} / .{d.tld}"),
                    ("Hyphens / digits in domain", f"{d.hyphens} / {d.digits_in_domain}"),
                    ("Punycode", "yes - " + ", ".join(result.punycode.punycode_labels) if result.has_punycode else "no"),
                    ("URL shortener", "yes" if result.is_shortener else "no")]
        story.append(_kv(rows, s))
    story.append(Paragraph("Triggered indicators", s["h"]))
    if result.indicators:
        rows = [["Indicator", "Severity", "Score", "Explanation and evidence"]]
        for i in result.indicators:
            rows.append([Paragraph(_e(i.name), s["cell"]),
                         Paragraph(f"<font color='{_SEV_COLOR[i.severity]}'><b>{i.severity.upper()}</b></font>", s["cell"]),
                         Paragraph(f"+{i.weight}", s["cell"]),
                         Paragraph(f"{_e(i.explanation)}<br/><font color='#475569'>Evidence: {_e(i.evidence)}</font>",
                                   s["cell"])])
        story.append(_table(rows, [38 * mm, 17 * mm, 12 * mm, 103 * mm]))
    else:
        story.append(Paragraph("No indicators were triggered.", s["p"]))
    if result.keywords:
        story.append(Spacer(1, 3))
        story.append(Paragraph("Keywords found: " + _e(", ".join(f"{k['keyword']} ({k['category']}, {k['where']})"
                                                               for k in result.keywords)), s["small"]))
    story.append(Paragraph("Recommended actions", s["h"]))
    for r in result.recommendations:
        story.append(Paragraph(f"• {_e(r)}", s["p"]))
    return story


def single_report_bytes(result, scan_id=None) -> bytes:
    s = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm,
                            bottomMargin=16 * mm, title="URL Risk Assessment Report", author=C.APP_TITLE)
    story = [Paragraph(_e(C.APP_TITLE), s["title"]),
             Paragraph(f"URL Risk Assessment Report · generated {datetime.now():%Y-%m-%d %H:%M}", s["sub"]),
             Spacer(1, 8)]
    story += _result_story(result, s, scan_id)
    story.append(Paragraph("Limitations", s["h"]))
    story += [Paragraph(f"• {_e(x)}", s["small"]) for x in LIMITATIONS]
    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


def bulk_report_bytes(results: list, source_name: str = "", session_id=None, detail_limit: int = 25) -> bytes:
    from detector.detection_engine import counts
    s = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm,
                            bottomMargin=16 * mm, title="Bulk URL Risk Assessment Report", author=C.APP_TITLE)
    c = counts(results)
    story = [Paragraph(_e(C.APP_TITLE), s["title"]),
             Paragraph(f"Bulk URL Analysis Report · generated {datetime.now():%Y-%m-%d %H:%M}", s["sub"]),
             Spacer(1, 8),
             _kv([("Source", source_name or "-"), ("Session ID", session_id if session_id is not None else "not stored"),
                  ("URLs analysed", c["total"]), ("LOW RISK", c["LOW RISK"]), ("MEDIUM RISK", c["MEDIUM RISK"]),
                  ("HIGH RISK", c["HIGH RISK"]), ("Invalid input", c["INVALID"])], s),
             Paragraph("Results (sorted by risk score)", s["h"])]
    ordered = sorted(results, key=lambda r: -(r.score if r.valid else -1))
    rows = [["#", "URL", "Score", "Class", "Main indicators"]]
    for n, r in enumerate(ordered, 1):
        col = _CLASS_COLOR.get(r.classification, "#475569")
        rows.append([str(n), Paragraph(_e(r.submitted), s["mono"]),
                     Paragraph(str(r.score) if r.valid else "-", s["cell"]),
                     Paragraph(f"<font color='{col}'><b>{_e(r.classification)}</b></font>", s["cell"]),
                     Paragraph(_e("; ".join(i.name for i in r.indicators[:4]) or r.error or "none"), s["cell"])])
    story.append(_table(rows, [8 * mm, 72 * mm, 12 * mm, 24 * mm, 54 * mm]))
    top = [r for r in ordered if r.valid and r.classification != "LOW RISK"][:detail_limit]
    if top:
        story.append(Paragraph(f"Details for MEDIUM and HIGH RISK URLs (first {len(top)})", s["h"]))
        for r in top:
            story.append(KeepTogether([Paragraph(f"<b>{_e(r.classification)} {r.score}/100</b> - "
                                                 f"<font face='Courier'>{_e(r.submitted[:160])}</font>", s["p"])]
                                      + [Paragraph(f"• {_e(i.name)} (+{i.weight}): {_e(i.evidence)}", s["small"])
                                         for i in r.indicators] + [Spacer(1, 5)]))
    story.append(Paragraph("Limitations", s["h"]))
    story += [Paragraph(f"• {_e(x)}", s["small"]) for x in LIMITATIONS]
    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


def save(data: bytes, name: str, folder: Path | None = None) -> Path:
    folder = Path(folder or C.REPORT_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    path.write_bytes(data)
    return path
