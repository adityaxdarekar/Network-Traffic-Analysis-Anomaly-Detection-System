"""Shared helpers for the Streamlit pages."""

from __future__ import annotations

from html import escape

import pandas as pd
import streamlit as st

import config as C
from database.db_manager import DatabaseManager


@st.cache_resource
def get_db() -> DatabaseManager:
    return DatabaseManager()


def get_settings() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = C.load_settings()
    return st.session_state["settings"]


def css() -> str:
    try:
        return f"<style>{C.STYLE_FILE.read_text(encoding='utf-8')}</style>"
    except OSError:
        return ""


def page_header(title: str, subtitle: str = "") -> None:
    st.markdown(f"<div class='page-title'>{escape(title)}</div>"
                + (f"<div class='page-sub'>{escape(subtitle)}</div>" if subtitle else ""), unsafe_allow_html=True)


def badge(classification: str, score: int | None = None) -> str:
    color = C.RISK_COLORS.get(classification, "#64748b")
    s = f" · {score}/100" if score is not None else ""
    return (f"<span class='risk-badge' style='background:{color}22;border:1px solid {color};color:{color}'>"
            f"{escape(classification)}{s}</span>")


def disclaimer() -> None:
    st.caption("ℹ️ " + C.DISCLAIMER)


def indicators_frame(result) -> pd.DataFrame:
    return pd.DataFrame([{"Indicator": i.name, "Severity": i.severity.upper(), "Score": f"+{i.weight}",
                          "Why it matters": i.explanation, "Evidence": i.evidence} for i in result.indicators],
                        columns=["Indicator", "Severity", "Score", "Why it matters", "Evidence"])


def components_frame(result) -> pd.DataFrame:
    p = result.parsed
    rows = [("Submitted URL", result.submitted), ("Normalized URL", p.normalized), ("Scheme", p.scheme),
            ("Hostname", p.hostname), ("Hostname (decoded)", p.hostname_unicode),
            ("Port", p.port if p.port is not None else "default"), ("Path", p.path or "/"),
            ("Query", p.query or "-"), ("Query parameters", len(p.params)), ("Fragment", p.fragment or "-"),
            ("User info before '@'", p.userinfo or "-"), ("Length", f"{p.length} characters")]
    return pd.DataFrame([(k, str(v)) for k, v in rows], columns=["Component", "Value"])


def domain_frame(result) -> pd.DataFrame:
    d = result.domain
    if d is None:
        return pd.DataFrame(columns=["Property", "Value"])
    if d.is_ip:
        rows = [("Hostname", d.hostname), ("IP-based hostname", "YES"), ("IP address", d.ip),
                ("Form", d.ip_form), ("Address scope", d.ip_scope)]
    else:
        rows = [("Hostname", d.hostname), ("Decoded hostname", d.hostname_unicode),
                ("Registered domain", d.registered_domain), ("Domain name", d.domain),
                ("Subdomain(s)", d.subdomain or "-"), ("Subdomain count", d.subdomain_count),
                ("Public suffix", d.suffix), ("Top-level domain", f".{d.tld}" if d.tld else "-"),
                ("TLD in Public Suffix List", "yes" if d.tld_in_psl else "no"),
                ("IP-based hostname", "no"), ("Punycode", "yes" if result.has_punycode else "no"),
                ("URL shortener", "yes" if result.is_shortener else "no"),
                ("Hostname length", d.hostname_length), ("Hyphens", d.hyphens),
                ("Digits in domain name", d.digits_in_domain), ("Dots", d.dots)]
    return pd.DataFrame([(k, str(v)) for k, v in rows], columns=["Property", "Value"])


def show_table(df: pd.DataFrame, height: int | None = None) -> None:
    kwargs = {"width": "stretch", "hide_index": True}
    if height:
        kwargs["height"] = height
    st.dataframe(df, **kwargs)
