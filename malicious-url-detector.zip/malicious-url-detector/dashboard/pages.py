"""All dashboard pages (one render function per page)."""

from __future__ import annotations

from datetime import datetime
from html import escape

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config as C
from dashboard.common import (badge, components_frame, disclaimer, domain_frame, get_db, get_settings,
                              indicators_frame, page_header, show_table)
from detector.detection_engine import (analyze_bulk, analyze_url, counts, read_urls, results_to_csv,
                                       results_to_json)
from detector.domain_analyzer import backend_name
from reports.pdf_generator import bulk_report_bytes, save, single_report_bytes

_COLOR_MAP = {k: v for k, v in C.RISK_COLORS.items()}


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


# ===================================================================================== 1 Overview
def overview() -> None:
    page_header("Overview Dashboard", "Summary of all stored URL scans")
    db = get_db()
    o = db.overview()
    cols = st.columns(5)
    for col, (label, val) in zip(cols, [("URLs analysed", o["total"]), ("Low risk", o["low"]),
                                        ("Medium risk", o["medium"]), ("High risk", o["high"]),
                                        ("Unique domains", o["unique_domains"])]):
        col.metric(label, val)
    if o["total"] == 0:
        st.info("No scans yet. Analyse a URL on **Single URL Analysis** or load the sample dataset on "
                "**Bulk URL Analysis**.")
        if st.button("📂 Load and analyse the mixed sample dataset", key="ov_load_samples"):
            _analyse_samples()
            st.rerun()
        disclaimer()
        return
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Risk distribution")
        dist = pd.DataFrame({"classification": C.RISK_LEVELS + ["INVALID"],
                             "count": [o["low"], o["medium"], o["high"], o["invalid"]]})
        dist = dist[dist["count"] > 0]
        fig = px.pie(dist, names="classification", values="count", hole=0.5, color="classification",
                     color_discrete_map=_COLOR_MAP)
        fig.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10))
        st.plotly_chart(fig, width="stretch")
    with c2:
        st.subheader("Most common indicators")
        top = db.top_indicators(10)
        if top.empty:
            st.caption("No indicators triggered yet.")
        else:
            fig = px.bar(top.sort_values("count"), x="count", y="indicator", orientation="h")
            fig.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10), yaxis_title="", xaxis_title="URLs")
            st.plotly_chart(fig, width="stretch")
    st.subheader("Recent URL scans")
    recent = db.scans(limit=10)
    show_table(recent[["scan_id", "timestamp", "submitted_url", "domain", "risk_score", "classification"]])
    disclaimer()


def _analyse_samples() -> list:
    data = (C.SAMPLES_DIR / "mixed_urls.csv").read_bytes()
    urls, _ = read_urls(data, "mixed_urls.csv")
    results = analyze_bulk(urls, get_settings())
    sid = get_db().save_bulk(results, "samples/mixed_urls.csv (synthetic)")
    st.session_state["bulk"] = {"results": results, "session_id": sid, "source": "samples/mixed_urls.csv"}
    return results


# ===================================================================================== 2 Single URL
def single() -> None:
    page_header("Single URL Analysis", "Paste one URL - it is analysed as text and never opened")
    settings = get_settings()
    url = st.text_input("URL to analyse", key="single_url", placeholder="https://example.com/login")
    c1, c2 = st.columns([1, 3])
    run = c1.button("🔍 Analyse URL", type="primary", key="single_go")
    c2.caption("Examples: `http://192.0.2.10/verify-account` · `https://examp1ebank.example/login` · "
               "`https://www.example.com/`")
    if run:
        if not (url or "").strip():
            st.warning("Please enter a URL.")
        else:
            res = analyze_url(url, settings)
            scan_id = get_db().save_result(res)
            st.session_state["single"] = {"result": res, "scan_id": scan_id}
    data = st.session_state.get("single")
    if not data:
        disclaimer()
        return
    res, scan_id = data["result"], data["scan_id"]
    if not res.valid:
        st.error(f"Invalid or malformed URL: {res.error}")
        st.caption(f"Stored as scan #{scan_id} with classification INVALID.")
        return
    render_result(res, scan_id)
    _optional_network_tools(res, settings)


def render_result(res, scan_id=None) -> None:
    st.markdown(f"<div class='result-head'>{badge(res.classification, res.score)}"
                f"<span class='scan-id'>Scan #{scan_id}</span></div>", unsafe_allow_html=True)
    g, m = st.columns([1, 2])
    with g:
        fig = go.Figure(go.Indicator(mode="gauge+number", value=res.score,
                                     number={"suffix": "/100"},
                                     gauge={"axis": {"range": [0, 100]},
                                            "bar": {"color": C.RISK_COLORS.get(res.classification)},
                                            "steps": [{"range": [0, 30], "color": "#14532d55"},
                                                      {"range": [30, 60], "color": "#78350f55"},
                                                      {"range": [60, 100], "color": "#7f1d1d55"}]}))
        fig.update_layout(height=220, margin=dict(t=20, b=0, l=20, r=20))
        st.plotly_chart(fig, width="stretch")
    with m:
        d = res.domain
        cols = st.columns(3)
        cols[0].metric("HTTPS", res.https_status.split(" ")[0])
        cols[1].metric("IP-based", "Yes" if res.is_ip else "No")
        cols[2].metric("URL length", res.parsed.length)
        cols = st.columns(3)
        cols[0].metric("Subdomains", d.subdomain_count if d else 0)
        cols[1].metric("Punycode", "Yes" if res.has_punycode else "No")
        cols[2].metric("Shortener", "Yes" if res.is_shortener else "No")
        if res.keywords:
            st.markdown("**Suspicious keywords:** " + ", ".join(f"`{escape(k['keyword'])}`" for k in res.keywords))
    st.subheader(f"Findings ({len(res.indicators)})")
    if res.indicators:
        for n, i in enumerate(res.indicators, 1):
            st.markdown(f"**{n}. {escape(i.name)}** &nbsp; <span class='sev sev-{i.severity}'>{i.severity.upper()}"
                        f" +{i.weight}</span><br><span class='muted'>{escape(i.explanation)}</span><br>"
                        f"<code>{escape(i.evidence)}</code>", unsafe_allow_html=True)
    else:
        st.success("No indicators were triggered by the URL text.")
    st.subheader("Recommended actions")
    for r in res.recommendations:
        st.markdown(f"- {escape(r)}")
    t1, t2 = st.tabs(["URL components", "Domain structure"])
    with t1:
        show_table(components_frame(res))
    with t2:
        show_table(domain_frame(res))
    st.download_button("⬇ PDF report for this URL", single_report_bytes(res, scan_id),
                       f"url_report_{scan_id}_{_stamp()}.pdf", "application/pdf", key="single_pdf")
    disclaimer()


def _optional_network_tools(res, settings) -> None:
    net = settings["network"]
    with st.expander("🌐 Optional online checks (disabled by default)"):
        st.caption("These checks contact the internet. They are off unless enabled on the Settings page, and "
                   "each one needs your confirmation. Never used automatically.")
        if not (net["allow_redirect_check"] or net["allow_domain_age_lookup"]):
            st.info("Both online checks are disabled (Settings → Optional network features).")
            return
        consent = st.checkbox("I understand that this sends a request to the internet and want to continue.",
                              key="net_consent")
        if net["allow_redirect_check"] and res.parsed.scheme in ("http", "https"):
            st.warning("Redirect check: sends HEAD requests to the URL and every redirect target "
                       f"(max {net['max_redirects']} hops, {net['timeout_seconds']} s timeout, public addresses only).")
            if st.button("Check redirects", key="net_redirect", disabled=not consent):
                from services.redirect_checker import check_redirects
                rep = check_redirects(res.parsed.normalized, settings, consent)
                show_table(pd.DataFrame([vars(h) for h in rep.hops], columns=["url", "status", "location", "note"]))
                st.caption(rep.stopped_reason)
        if net["allow_domain_age_lookup"] and res.domain and not res.domain.is_ip:
            st.warning(f"Domain-age lookup: sends only the domain '{res.domain.registered_domain}' to rdap.org.")
            if st.button("Look up domain age", key="net_rdap", disabled=not consent):
                from services.domain_age import lookup
                info = lookup(res.domain.registered_domain, settings, consent)
                st.write(f"**{info.status}** - registered {info.registered or 'unknown'}"
                         f"{f' ({info.age_days} days ago)' if info.age_days is not None else ''}. {info.note}")


# ===================================================================================== 3 Bulk
def bulk() -> None:
    page_header("Bulk URL Analysis", "Upload a CSV or TXT file, or load the synthetic sample dataset")
    settings = get_settings()
    up = st.file_uploader("CSV (column 'url') or TXT (one URL per line)", type=["csv", "txt"], key="bulk_file")
    c1, c2 = st.columns(2)
    if c1.button("🔍 Analyse uploaded file", type="primary", key="bulk_go", disabled=up is None):
        urls, warnings = read_urls(up.getvalue(), up.name)
        for w in warnings:
            st.warning(w)
        if not urls:
            st.error("No URLs found in the file.")
        else:
            results = analyze_bulk(urls, settings)
            sid = get_db().save_bulk(results, up.name)
            st.session_state["bulk"] = {"results": results, "session_id": sid, "source": up.name}
    if c2.button("📂 Load mixed sample dataset (synthetic)", key="bulk_samples"):
        _analyse_samples()
    data = st.session_state.get("bulk")
    if not data:
        st.caption("Sample files: samples/low_risk_urls.csv, suspicious_urls.csv, high_risk_urls.csv, mixed_urls.csv "
                   "- synthetic educational data using reserved example domains.")
        disclaimer()
        return
    results = data["results"]
    c = counts(results)
    st.markdown(f"**Session #{data['session_id']}** · source `{escape(data['source'])}`")
    cols = st.columns(5)
    for col, (label, key) in zip(cols, [("Total", "total"), ("Low", "LOW RISK"), ("Medium", "MEDIUM RISK"),
                                        ("High", "HIGH RISK"), ("Invalid", "INVALID")]):
        col.metric(label, c[key])
    df = pd.DataFrame([r.summary_row() for r in results])
    f1, f2, f3 = st.columns([2, 2, 1])
    levels = f1.multiselect("Filter by risk level", C.RISK_LEVELS + ["INVALID"], default=C.RISK_LEVELS + ["INVALID"],
                            key="bulk_levels")
    search = f2.text_input("Search URL / domain", key="bulk_search")
    order = f3.selectbox("Sort", ["Score ↓", "Score ↑", "Input order"], key="bulk_sort")
    view = df[df["classification"].isin(levels)]
    if search:
        mask = view["url"].str.contains(search, case=False, regex=False) | \
            view["domain"].fillna("").str.contains(search, case=False, regex=False)
        view = view[mask]
    if order != "Input order":
        view = view.sort_values("risk_score", ascending=(order == "Score ↑"), na_position="last")
    show_table(view[["url", "domain", "risk_score", "classification", "indicator_count", "indicators", "https",
                     "ip_based", "shortener", "punycode", "error"]], height=420)
    chart = pd.DataFrame({"classification": C.RISK_LEVELS, "count": [c[x] for x in C.RISK_LEVELS]})
    fig = px.bar(chart, x="classification", y="count", color="classification", color_discrete_map=_COLOR_MAP)
    fig.update_layout(height=260, showlegend=False, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig, width="stretch")
    st.subheader("Export")
    e1, e2, e3 = st.columns(3)
    e1.download_button("⬇ CSV", results_to_csv(results).encode(), f"bulk_results_{_stamp()}.csv", "text/csv",
                       key="bulk_csv")
    e2.download_button("⬇ JSON", results_to_json(results).encode(), f"bulk_results_{_stamp()}.json",
                       "application/json", key="bulk_json")
    e3.download_button("⬇ PDF", bulk_report_bytes(results, data["source"], data["session_id"]),
                       f"bulk_report_{_stamp()}.pdf", "application/pdf", key="bulk_pdf")
    disclaimer()


# ===================================================================================== 4 Domain analysis
def domain() -> None:
    page_header("Domain Analysis", "Hostname, registered domain, subdomains, TLD and domain indicators")
    st.caption(f"Domain extraction backend: {backend_name()} - Public Suffix List aware (e.g. example.co.uk).")
    default = ""
    if st.session_state.get("single") and st.session_state["single"]["result"].valid:
        default = st.session_state["single"]["result"].submitted
    url = st.text_input("URL or hostname", value=default, key="dom_url")
    if not (url or "").strip():
        st.info("Enter a URL or hostname, or analyse one on the Single URL page first.")
        return
    res = analyze_url(url, get_settings())
    if not res.valid:
        st.error(f"Invalid input: {res.error}")
        return
    if res.domain is None:
        st.warning(f"'{res.parsed.scheme}:' URLs have no hostname to analyse.")
        return
    show_table(domain_frame(res))
    dom_ids = {"ip_host", "obfuscated_ip", "punycode", "mixed_script", "excessive_subdomains", "unusual_domain_structure",
               "suspicious_tld", "unknown_tld", "lookalike_domain", "brand_in_subdomain_or_path", "shortener",
               "scheme_in_hostname"}
    inds = [i for i in res.indicators if i.id in dom_ids]
    st.subheader("Suspicious domain indicators")
    if inds:
        show_table(pd.DataFrame([{"Indicator": i.name, "Severity": i.severity.upper(), "Score": i.weight,
                                  "Evidence": i.evidence, "Explanation": i.explanation} for i in inds]))
    else:
        st.success("No domain-level indicators.")
    if res.punycode and res.punycode.scripts:
        st.markdown("**Character scripts per label:** " +
                    "; ".join(f"`{escape(k)}`: {', '.join(v)}" for k, v in res.punycode.scripts.items()))
    st.caption("Lookalike checks compare with the configured brand list (Settings). They cannot know every "
               "legitimate domain of an organisation and never prove impersonation.")


# ===================================================================================== 5 History
def history() -> None:
    page_header("Scan History", "Stored scans (SQLite) - view details or delete")
    db = get_db()
    c1, c2 = st.columns([1, 2])
    level = c1.selectbox("Classification", ["All"] + C.RISK_LEVELS + ["INVALID"], key="hist_level")
    search = c2.text_input("Search URL / domain", key="hist_search")
    df = db.scans(None if level == "All" else level, search)
    if df.empty:
        st.info("No scans stored.")
        return
    show_table(df[["scan_id", "timestamp", "submitted_url", "domain", "risk_score", "classification"]], height=380)
    ids = df["scan_id"].tolist()
    sel = st.selectbox("Scan details", ids, key="hist_sel", format_func=lambda i: f"#{i}")
    row = db.scan(sel)
    if row:
        st.markdown(f"{badge(row['classification'], row['risk_score'])} &nbsp; `{escape(str(row['submitted_url']))}`",
                    unsafe_allow_html=True)
        show_table(db.indicators(sel))
        res = analyze_url(row["submitted_url"], get_settings())
        st.download_button("⬇ PDF report (re-analysed with current settings)", single_report_bytes(res, sel),
                           f"url_report_{sel}.pdf", "application/pdf", key="hist_pdf")
    d1, d2 = st.columns(2)
    if d1.button(f"🗑 Delete scan #{sel}", key="hist_del"):
        db.delete_scan(sel)
        st.rerun()
    sure = d2.checkbox("I want to delete the whole scan history", key="hist_sure")
    if d2.button("🗑 Clear history", key="hist_clear", disabled=not sure):
        db.clear_history()
        st.session_state.pop("bulk", None)
        st.session_state.pop("single", None)
        st.rerun()


# ===================================================================================== 6 Reports
def reports() -> None:
    page_header("Reports", "PDF, CSV and JSON exports")
    single_data = st.session_state.get("single")
    bulk_data = st.session_state.get("bulk")
    st.subheader("Individual URL report")
    if single_data and single_data["result"].valid:
        r, sid = single_data["result"], single_data["scan_id"]
        st.markdown(f"Last analysed: `{escape(r.submitted)}` {badge(r.classification, r.score)}", unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        c1.download_button("⬇ PDF", single_report_bytes(r, sid), f"url_report_{sid}.pdf", "application/pdf",
                           key="rep_single_pdf")
        c2.download_button("⬇ CSV", results_to_csv([r]).encode(), f"url_report_{sid}.csv", "text/csv",
                           key="rep_single_csv")
        c3.download_button("⬇ JSON", results_to_json([r]).encode(), f"url_report_{sid}.json", "application/json",
                           key="rep_single_json")
        if st.button("💾 Save PDF to output/reports", key="rep_single_save"):
            st.success(f"Saved: {save(single_report_bytes(r, sid), f'url_report_{sid}_{_stamp()}.pdf')}")
    else:
        st.caption("Analyse a URL on the Single URL Analysis page first.")
    st.subheader("Bulk analysis report")
    if bulk_data:
        res = bulk_data["results"]
        st.markdown(f"Session #{bulk_data['session_id']} · {len(res)} URLs · `{escape(bulk_data['source'])}`")
        c1, c2, c3 = st.columns(3)
        c1.download_button("⬇ PDF", bulk_report_bytes(res, bulk_data["source"], bulk_data["session_id"]),
                           f"bulk_report_{bulk_data['session_id']}.pdf", "application/pdf", key="rep_bulk_pdf")
        c2.download_button("⬇ CSV", results_to_csv(res).encode(), f"bulk_results_{bulk_data['session_id']}.csv",
                           "text/csv", key="rep_bulk_csv")
        c3.download_button("⬇ JSON", results_to_json(res).encode(), f"bulk_results_{bulk_data['session_id']}.json",
                           "application/json", key="rep_bulk_json")
        if st.button("💾 Save bulk PDF to output/reports", key="rep_bulk_save"):
            p = save(bulk_report_bytes(res, bulk_data["source"], bulk_data["session_id"]),
                     f"bulk_report_{bulk_data['session_id']}_{_stamp()}.pdf")
            st.success(f"Saved: {p}")
    else:
        st.caption("Run a bulk analysis (or load the sample dataset) first.")
    st.subheader("Full scan history (CSV)")
    hist = get_db().scans(limit=100000)
    if hist.empty:
        st.caption("No stored scans.")
    else:
        st.download_button("⬇ Scan history CSV", hist.to_csv(index=False).encode(), f"scan_history_{_stamp()}.csv",
                           "text/csv", key="rep_hist_csv")
    disclaimer()


# ===================================================================================== 7 Settings
def settings_page() -> None:
    page_header("Settings", "Scoring weights, thresholds, lists and optional network features")
    s = get_settings()
    with st.expander("Scoring weights", expanded=True):
        cols = st.columns(3)
        for n, (k, v) in enumerate(sorted(s["weights"].items())):
            s["weights"][k] = int(cols[n % 3].number_input(k, 0, 100, int(v), key=f"w_{k}"))
    with st.expander("Thresholds"):
        cols = st.columns(3)
        for n, (k, v) in enumerate(s["thresholds"].items()):
            s["thresholds"][k] = int(cols[n % 3].number_input(k, 0, 100000, int(v), key=f"t_{k}"))
        b1, b2 = st.columns(2)
        s["risk_bands"]["medium"] = int(b1.number_input("MEDIUM RISK from score", 1, 99, s["risk_bands"]["medium"], key="b_med"))
        s["risk_bands"]["high"] = int(b2.number_input("HIGH RISK from score", 2, 100, s["risk_bands"]["high"], key="b_high"))
    with st.expander("Lists"):
        sh = st.text_area("URL shorteners (one per line)", "\n".join(s["shorteners"]), key="l_short")
        s["shorteners"] = [x.strip().lower() for x in sh.splitlines() if x.strip()]
        tl = st.text_area("Watch-list TLDs (one per line)", "\n".join(s["suspicious_tlds"]), key="l_tld")
        s["suspicious_tlds"] = [x.strip().lower().lstrip(".") for x in tl.splitlines() if x.strip()]
        br = st.text_area("Brands: brand = domain1, domain2 (one brand per line)",
                          "\n".join(f"{b} = {', '.join(d)}" for b, d in s["brands"].items()), key="l_brand")
        brands = {}
        for line in br.splitlines():
            if "=" in line:
                b, _, doms = line.partition("=")
                if b.strip():
                    brands[b.strip().lower()] = [d.strip().lower() for d in doms.split(",") if d.strip()]
        s["brands"] = brands
        for cat in list(s["keywords"]):
            kw = st.text_area(f"Keywords - {cat}", ", ".join(s["keywords"][cat]), key=f"l_kw_{cat}")
            s["keywords"][cat] = [x.strip().lower() for x in kw.split(",") if x.strip()]
    with st.expander("Optional network features (off by default)"):
        st.warning("When enabled, these features contact the internet - but only after you confirm each request on "
                   "the Single URL page. URLs are never sent anywhere automatically.")
        s["network"]["allow_redirect_check"] = st.checkbox("Allow redirect check (HEAD requests, public addresses only)",
                                                           s["network"]["allow_redirect_check"], key="n_redirect")
        s["network"]["allow_domain_age_lookup"] = st.checkbox("Allow domain-age lookup via RDAP (domain only)",
                                                              s["network"]["allow_domain_age_lookup"], key="n_rdap")
    c1, c2 = st.columns(2)
    if c1.button("💾 Save settings", type="primary", key="set_save"):
        if s["risk_bands"]["high"] <= s["risk_bands"]["medium"]:
            st.error("HIGH RISK threshold must be above the MEDIUM RISK threshold.")
        else:
            st.success(f"Saved to {C.save_settings(s)}")
    if c2.button("↺ Restore defaults", key="set_reset"):
        st.session_state["settings"] = C.default_settings()
        C.save_settings(st.session_state["settings"])
        st.rerun()


# ===================================================================================== 8 About
def about() -> None:
    page_header("About Project", C.APP_TITLE)
    s = get_settings()
    st.markdown("""
**Objective.** Analyse URLs *as text* and explain which characteristics are typical of phishing or
malicious links: scheme, IP-based hosts, domain structure, subdomains, length, suspicious characters,
phishing keywords, URL encoding, punycode, shorteners and lookalike domains. Each finding has a weight;
the sum (capped at 100) gives a heuristic risk score and a LOW / MEDIUM / HIGH classification.

**Technologies.** Python · Streamlit · urllib.parse · ipaddress · re · tldextract (offline) / bundled Public
Suffix List · pandas · Plotly · SQLite · ReportLab · pytest.

**Safety.** URLs are never opened, resolved, downloaded or sent to external services. Optional online checks
(redirects, domain age) are disabled by default and need explicit consent per request.
""")
    st.subheader("Risk scoring")
    w = pd.DataFrame(sorted(s["weights"].items(), key=lambda kv: -kv[1]), columns=["indicator", "weight"])
    show_table(w, height=300)
    st.markdown(f"Bands: **0-{s['risk_bands']['medium'] - 1} LOW RISK**, "
                f"**{s['risk_bands']['medium']}-{s['risk_bands']['high'] - 1} MEDIUM RISK**, "
                f"**{s['risk_bands']['high']}-100 HIGH RISK**. Keywords: +{s['weights']['keyword_each']} each, "
                f"max +{s['weights']['keyword_max']}.")
    st.subheader("Limitations")
    st.markdown("""
- The score counts warning signs; it is **not** a validated probability. LOW RISK ≠ safe, HIGH RISK ≠ proven malicious.
- Only the URL text is analysed: page content, certificates, hosting, reputation and domain age are not checked by default.
- Lookalike detection depends on the configured brand list.
- Legitimate URLs (internal IP addresses, long tracking links, IDN domains) can trigger indicators.
""")
    st.subheader("Future enhancements")
    st.markdown("- Opt-in reputation lookups (VirusTotal, Safe Browsing) via the prepared provider interface\n"
                "- Machine-learning model trained on labelled datasets, combined with the explainable rules\n"
                "- Browser extension / e-mail gateway integration\n- Certificate and hosting metadata (opt-in)")
    st.caption(f"Version {C.APP_VERSION} · domain backend: {backend_name()}")
