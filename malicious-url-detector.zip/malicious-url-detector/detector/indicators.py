"""Common data type for detection findings."""

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class Indicator:
    id: str                 # key into settings["weights"]
    name: str               # short human-readable title
    explanation: str        # why this may be suspicious (and why it is not proof)
    evidence: str = ""      # the concrete part of the URL that triggered it
    weight: int = 0         # score contribution (filled in by the risk scorer)
    severity: str = "info"  # info / low / medium / high (filled in by the risk scorer)

    def to_dict(self) -> dict:
        return asdict(self)


def severity_for(weight: int) -> str:
    if weight >= 20:
        return "high"
    if weight >= 10:
        return "medium"
    if weight > 0:
        return "low"
    return "info"


# Stable titles per indicator id (names in results may include details such as counts).
TITLES = {
    "http_scheme": "HTTP instead of HTTPS", "missing_scheme": "No scheme given", "unusual_scheme": "Unusual scheme",
    "dangerous_scheme": "Script/data scheme", "ip_host": "IP address as hostname",
    "obfuscated_ip": "Obfuscated IP address", "shortener": "URL shortener", "long_url": "Long URL",
    "very_long_url": "Very long URL", "excessive_subdomains": "Many subdomains", "punycode": "Punycode hostname",
    "mixed_script": "Mixed scripts", "phishing_keywords": "Phishing-related keywords", "at_symbol": "'@' in address",
    "unusual_domain_structure": "Unusual domain structure", "lookalike_domain": "Lookalike domain",
    "brand_in_subdomain_or_path": "Brand outside its domain", "suspicious_tld": "Watch-list TLD",
    "unknown_tld": "Unknown TLD", "url_encoding": "Unusual URL encoding", "double_encoding": "Double encoding",
    "redirect_parameter": "Redirect parameter", "long_query": "Long query string",
    "nonstandard_port": "Non-standard port", "suspicious_characters": "Unusual characters",
    "scheme_in_hostname": "'http/www' inside hostname", "brand_keyword_combination": "Brand + login/payment words",
}
