"""
Hostname <-> punycode conversion without network access.

Uses the 'idna' package (IDNA 2008) when installed, otherwise Python's built-in 'idna' codec (IDNA 2003).
Labels that cannot be converted are left unchanged (the parser then reports invalid characters).
"""

from __future__ import annotations

try:
    import idna as _idna            # installed with requests / tldextract
except ImportError:                 # pragma: no cover - depends on environment
    _idna = None


def _label_to_unicode(label: str) -> str:
    if not label.startswith("xn--"):
        return label
    try:
        if _idna is not None:
            return _idna.decode(label)
        return label.encode("ascii").decode("idna")
    except Exception:               # invalid punycode - keep the raw label for display
        return label


def _label_to_ascii(label: str) -> str:
    if label.isascii():
        return label
    try:
        if _idna is not None:
            return _idna.encode(label, uts46=True).decode("ascii")
        return label.encode("idna").decode("ascii")
    except Exception:
        try:
            return label.encode("idna").decode("ascii")      # IDNA 2003 is more permissive (e.g. symbols)
        except Exception:
            return label


def to_ascii_and_unicode(host: str) -> tuple[str, str]:
    labels = host.split(".")
    ascii_labels = [_label_to_ascii(lab).lower() for lab in labels]
    unicode_labels = [_label_to_unicode(lab) for lab in ascii_labels]
    return ".".join(ascii_labels), ".".join(unicode_labels)
