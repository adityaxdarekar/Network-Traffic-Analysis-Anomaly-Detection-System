"""
URL parsing and validation - pure string processing, no network access, no DNS.

parse_url(text) -> ParsedURL with: original input, normalized URL, scheme, hostname (ASCII and Unicode),
port, path, query, query parameters, fragment, userinfo (the part before '@' in the authority), flags for
missing scheme / defanged input, and an error message for invalid input.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import asdict, dataclass, field
from urllib.parse import parse_qsl, unquote, urlsplit, urlunsplit

from detector import idna_compat

MAX_INPUT_LENGTH = 4096
DEFAULT_PORTS = {"http": 80, "https": 443, "ftp": 21}
WEB_SCHEMES = {"http", "https", "ftp", "ftps", "ws", "wss"}
# characters that may appear in a hostname label (ASCII) - anything else is reported
_HOST_OK = re.compile(r"^[a-z0-9.\-_]+$")
_SCHEME_RE = re.compile(r"^([a-zA-Z][a-zA-Z0-9+.\-]*):")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


class URLParseError(ValueError):
    pass


@dataclass
class ParsedURL:
    original: str
    normalized: str = ""
    scheme: str = ""
    scheme_was_missing: bool = False
    defanged: bool = False
    userinfo: str = ""
    hostname: str = ""              # lower-case, ASCII (punycode) form, no brackets for IPv6
    hostname_unicode: str = ""      # decoded IDN form for display
    port: int | None = None
    path: str = ""
    query: str = ""
    params: list = field(default_factory=list)      # [(name, value), ...] decoded once
    fragment: str = ""
    is_ipv6_literal: bool = False
    host_percent_encoded: bool = False
    valid: bool = True
    error: str = ""

    @property
    def length(self) -> int:
        return len(self.original)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["length"] = self.length
        return d


def refang(text: str) -> tuple[str, bool]:
    """Undo common 'defanging' used in threat reports: hxxp://, [.] (.) {.}, [:]//."""
    t = text
    t = re.sub(r"^hxxp(s?)", r"http\1", t, flags=re.I)
    t = re.sub(r"^fxp", "ftp", t, flags=re.I)
    for a, b in (("[.]", "."), ("(.)", "."), ("{.}", "."), ("[:]", ":"), ("[://]", "://"), ("[dot]", ".")):
        t = t.replace(a, b)
    return t, t != text


def parse_url(text, max_length: int = MAX_INPUT_LENGTH) -> ParsedURL:
    """Parse and validate. Never raises for bad input - returns ParsedURL(valid=False, error=...)."""
    raw = "" if text is None else str(text)
    result = ParsedURL(original=raw.strip())
    try:
        _parse_into(result, max_length)
    except URLParseError as exc:
        result.valid, result.error = False, str(exc)
    except (ValueError, UnicodeError) as exc:                     # anything urllib/idna rejects
        result.valid, result.error = False, f"malformed URL ({exc.__class__.__name__}: {exc})"
    return result


def _parse_into(r: ParsedURL, max_length: int) -> None:
    text = r.original
    if not text:
        raise URLParseError("empty input")
    if len(text) > max_length:
        raise URLParseError(f"input longer than {max_length} characters")
    if _CONTROL.search(text):
        raise URLParseError("contains control characters")
    if re.search(r"\s", text):
        raise URLParseError("contains whitespace - one URL per line")
    text, r.defanged = refang(text)

    m = _SCHEME_RE.match(text)
    scheme_candidate = m.group(1).lower() if m else ""
    # "example.com:8080/x" looks like scheme "example.com" - treat digits after ':' as a port, not a scheme
    if m and re.match(r"^\d+([/?#]|$)", text[m.end():]):
        scheme_candidate = ""
    if scheme_candidate and scheme_candidate not in WEB_SCHEMES and not text[m.end():].startswith("//"):
        # mailto:, javascript:, data:, tel: ... - no authority; keep the rest for display only
        r.scheme = scheme_candidate
        r.path = text[m.end():][:200]
        r.normalized = f"{r.scheme}:{r.path}"
        return
    if not scheme_candidate:
        if text.startswith("//"):
            text = "http:" + text
        else:
            text = "http://" + text
        r.scheme_was_missing = True
        scheme_candidate = "http"
    r.scheme = scheme_candidate

    parts = urlsplit(text)
    netloc = parts.netloc
    if not netloc:
        raise URLParseError("no hostname found")
    if "@" in netloc:
        r.userinfo, _, hostport = netloc.rpartition("@")
    else:
        hostport = netloc
    host, port = _split_host_port(hostport)
    if not host:
        raise URLParseError("no hostname found")
    r.port = port
    if host.startswith("["):
        if not host.endswith("]"):
            raise URLParseError("unterminated IPv6 literal")
        inner = host[1:-1]
        try:
            ipaddress.IPv6Address(inner.split("%")[0])
        except ValueError as exc:
            raise URLParseError(f"invalid IPv6 address: {inner}") from exc
        r.hostname = r.hostname_unicode = inner.lower()
        r.is_ipv6_literal = True
    else:
        r.host_percent_encoded = "%" in host
        host = unquote(host).rstrip(".").lower()        # %-encoded hostnames are decoded (and flagged later)
        if not host or ".." in host:
            raise URLParseError("empty label in hostname")
        ascii_host, uni_host = idna_compat.to_ascii_and_unicode(host)
        if not _HOST_OK.match(ascii_host):
            raise URLParseError(f"hostname contains invalid characters: {host!r}")
        if any(len(label) > 63 for label in ascii_host.split(".")) or len(ascii_host) > 253:
            raise URLParseError("hostname label too long")
        r.hostname, r.hostname_unicode = ascii_host, uni_host
    r.path = parts.path
    r.query = parts.query
    r.fragment = parts.fragment
    r.params = parse_qsl(parts.query, keep_blank_values=True)

    host_out = f"[{r.hostname}]" if r.is_ipv6_literal else r.hostname
    if r.port is not None and r.port != DEFAULT_PORTS.get(r.scheme):
        host_out += f":{r.port}"
    if r.userinfo:
        host_out = f"{r.userinfo}@{host_out}"
    r.normalized = urlunsplit((r.scheme, host_out, r.path or "/", r.query, r.fragment))


def _split_host_port(hostport: str) -> tuple[str, int | None]:
    if hostport.startswith("["):
        end = hostport.find("]")
        if end == -1:
            return hostport, None
        host, rest = hostport[:end + 1], hostport[end + 1:]
    else:
        host, sep, rest = hostport.partition(":")
        rest = sep + rest
    if rest:
        if not rest.startswith(":") or not rest[1:].isdigit():
            raise URLParseError(f"invalid port: {rest[1:]!r}")
        port = int(rest[1:])
        if not 0 < port < 65536:
            raise URLParseError(f"port out of range: {port}")
        return host, port
    return host, None
