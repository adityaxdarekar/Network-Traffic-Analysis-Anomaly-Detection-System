"""
Phishing-keyword detection in the URL text (subdomain, domain name, path, query) - configurable lists.

Matching rules (to keep false matches low):
  * the URL text is split into word tokens on any non-alphanumeric character;
  * keywords of 5+ letters also match inside a token ("verifyaccount" contains "verify" and "account");
  * shorter keywords (pay, tax, card, auth, bank, free ...) must be a whole token.
The registered domain of a configured legitimate brand domain is not scanned (paytrust.example does
not "contain" pay). Each keyword is counted once; the score is weight_each x matches, capped.
"""

from __future__ import annotations

import re
from urllib.parse import unquote

from detector.indicators import Indicator

_TOKEN = re.compile(r"[a-z0-9]+")


def url_text_parts(subdomain: str, domain: str, path: str, query: str, skip_domain: bool = False) -> dict:
    parts = {"subdomain": subdomain, "domain": "" if skip_domain else domain,
             "path": unquote(unquote(path)), "query": unquote(unquote(query))}
    return {k: v.lower() for k, v in parts.items()}


def find_keywords(parts: dict, keywords: dict) -> list[dict]:
    """-> [{"keyword", "category", "where"}] - each keyword once (first location wins)."""
    tokens = {where: _TOKEN.findall(text) for where, text in parts.items()}
    found, seen = [], set()
    for category, words in keywords.items():
        for kw in words:
            k = kw.lower().replace("-", "")
            if not k or k in seen:
                continue
            for where, toks in tokens.items():
                hit = any(t == k for t in toks) if len(k) < 5 else any(k in t for t in toks)
                if hit:
                    seen.add(k)
                    found.append({"keyword": kw, "category": category, "where": where})
                    break
    # "log-in", "sign-in" written with a hyphen are covered by the joined form; drop exact duplicates
    return found


def detect(parts: dict, settings: dict) -> tuple[list[dict], list[Indicator]]:
    matches = find_keywords(parts, settings["keywords"])
    if not matches:
        return matches, []
    w = settings["weights"]
    count = len(matches)
    capped = min(count * w["keyword_each"], w["keyword_max"])
    cats = sorted({m["category"] for m in matches})
    why = {"credential": "asks for or refers to login, account or verification",
           "financial": "refers to payments, banking or money",
           "lure": "uses reward or urgency wording to create pressure"}
    explanation = ("Words often used in phishing URLs: " + "; ".join(f"{c} ({why.get(c, c)})" for c in cats)
                   + ". Such words also appear in many legitimate URLs, so this is a weak signal on its own.")
    ind = Indicator("phishing_keywords", f"Phishing-related keywords ({count})", explanation,
                    ", ".join(f"{m['keyword']} [{m['where']}]" for m in matches), weight=capped)
    return matches, [ind]
