"""
Detection engine - runs every detector on one URL (or many) and returns an explainable result.

    from detector.detection_engine import analyze_url
    r = analyze_url("http://192.0.2.10/verify-account")
    r.score, r.classification, [i.name for i in r.indicators]

Purely local: the URL is parsed as text. Nothing is opened, resolved, downloaded or sent anywhere.
"""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from datetime import datetime

import config as C
from detector import keyword_detector, punycode_detector
from detector import url_pattern_detector as P
from detector.domain_analyzer import DomainInfo, analyze_domain
from detector.indicators import Indicator
from detector.risk_scorer import recommendations, score
from detector.url_parser import ParsedURL, parse_url

MAX_BULK_URLS = 5000


@dataclass
class AnalysisResult:
    submitted: str
    valid: bool
    error: str = ""
    parsed: ParsedURL | None = None
    domain: DomainInfo | None = None
    punycode: object = None
    keywords: list = field(default_factory=list)
    indicators: list = field(default_factory=list)       # [Indicator] with weight/severity
    score: int = 0
    classification: str = "INVALID"
    recommendations: list = field(default_factory=list)
    analyzed_at: str = ""

    # convenience fields for tables / reports
    @property
    def https_status(self) -> str:
        if not self.parsed or not self.valid:
            return "-"
        if self.parsed.scheme_was_missing:
            return "missing (analysed as HTTP)"
        return {"https": "HTTPS", "http": "HTTP (not encrypted)"}.get(self.parsed.scheme, f"other ({self.parsed.scheme})")

    @property
    def is_ip(self) -> bool:
        return bool(self.domain and self.domain.is_ip)

    @property
    def is_shortener(self) -> bool:
        return any(i.id == "shortener" for i in self.indicators)

    @property
    def has_punycode(self) -> bool:
        return bool(self.punycode and self.punycode.has_punycode)

    def summary_row(self) -> dict:
        p, d = self.parsed, self.domain
        return {
            "url": self.submitted,
            "normalized_url": p.normalized if p and self.valid else "",
            "hostname": p.hostname if p else "",
            "domain": (d.registered_domain if d and not d.is_ip else (d.ip if d else "")),
            "risk_score": self.score if self.valid else None,
            "classification": self.classification,
            "indicator_count": len(self.indicators),
            "indicators": "; ".join(i.name for i in self.indicators),
            "https": self.https_status,
            "ip_based": self.is_ip,
            "shortener": self.is_shortener,
            "punycode": self.has_punycode,
            "url_length": p.length if p else 0,
            "subdomain_count": d.subdomain_count if d else 0,
            "keywords": ", ".join(k["keyword"] for k in self.keywords),
            "error": self.error,
        }

    def to_dict(self) -> dict:
        return {
            "submitted_url": self.submitted,
            "valid": self.valid,
            "error": self.error,
            "analyzed_at": self.analyzed_at,
            "risk_score": self.score,
            "classification": self.classification,
            "https_status": self.https_status,
            "ip_based": self.is_ip,
            "shortener": self.is_shortener,
            "punycode": self.has_punycode,
            "components": self.parsed.to_dict() if self.parsed else None,
            "domain": self.domain.to_dict() if self.domain else None,
            "keywords": self.keywords,
            "indicators": [i.to_dict() for i in self.indicators],
            "recommendations": self.recommendations,
            "disclaimer": C.DISCLAIMER,
        }


def analyze_url(text: str, settings: dict | None = None) -> AnalysisResult:
    settings = settings or C.DEFAULT_SETTINGS
    th = settings["thresholds"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    parsed = parse_url(text, max_length=th["max_input_length"])
    res = AnalysisResult(submitted=parsed.original, valid=parsed.valid, error=parsed.error, parsed=parsed,
                         analyzed_at=now)
    if not parsed.valid:
        return res

    indicators: list[Indicator] = list(P.scheme_indicators(parsed))
    if not parsed.hostname:                       # mailto:, javascript:, data: ... no host to analyse
        res.score, res.classification, res.indicators = score(indicators, settings)
        res.recommendations = recommendations(res.classification, res.indicators)
        return res

    dom = analyze_domain(parsed.hostname, parsed.hostname_unicode, settings)
    res.domain = dom
    res.punycode, puny_inds = punycode_detector.detect(parsed.hostname, parsed.hostname_unicode)
    legit = {d.lower() for doms in settings["brands"].values() for d in doms}
    parts = keyword_detector.url_text_parts(dom.subdomain, dom.domain, parsed.path, parsed.query,
                                            skip_domain=dom.registered_domain in legit or dom.is_ip)
    res.keywords, kw_inds = keyword_detector.detect(parts, settings)

    indicators += P.ip_indicators(dom)
    indicators += P.shortener_indicator(dom, settings["shorteners"])
    indicators += P.length_indicator(parsed, th)
    indicators += P.at_symbol_indicator(parsed)
    indicators += P.encoding_indicators(parsed, th)
    indicators += P.query_indicators(parsed, th, dom.registered_domain if not dom.is_ip else "")
    indicators += P.port_indicator(parsed)
    indicators += P.character_indicators(parsed)
    indicators += P.subdomain_indicator(dom, th)
    indicators += P.tld_indicators(dom, settings["suspicious_tlds"])
    indicators += P.structure_indicators(dom)
    indicators += puny_inds
    indicators += P.lookalike_indicators(dom, parsed, settings["brands"], th["lookalike_max_distance"])
    indicators += kw_inds
    indicators += combination_indicators(indicators, res.keywords)

    res.score, res.classification, res.indicators = score(indicators, settings)
    res.recommendations = recommendations(res.classification, res.indicators)
    return res


def combination_indicators(indicators: list[Indicator], keywords: list) -> list[Indicator]:
    """A brand reference together with credential/payment words is a typical phishing combination."""
    ids = {i.id for i in indicators}
    risky_words = [k["keyword"] for k in keywords if k["category"] in ("credential", "financial")]
    if ids & {"lookalike_domain", "brand_in_subdomain_or_path"} and risky_words:
        return [Indicator("brand_keyword_combination", "Brand reference combined with login/payment words",
                          "A brand name outside its known domains together with words such as 'login' or "
                          "'verify' is a classic phishing combination. Each part alone is weaker evidence.",
                          ", ".join(risky_words[:5]))]
    return []


# ------------------------------------------------------------------------------------- bulk input
def read_urls(data: bytes | str, filename: str = "urls.txt", limit: int = MAX_BULK_URLS) -> tuple[list[str], list[str]]:
    """Read URLs from TXT (one per line) or CSV (column url/URL/link/address, else the first column).
    Lines starting with '#' and empty lines are ignored. -> (urls, warnings)"""
    text = data.decode("utf-8-sig", errors="replace") if isinstance(data, bytes) else data
    warnings: list[str] = []
    urls: list[str] = []
    if filename.lower().endswith(".csv"):
        rows = list(csv.reader(io.StringIO(text)))
        rows = [r for r in rows if r and any(c.strip() for c in r)]
        if not rows:
            return [], ["the CSV file is empty"]
        header = [h.strip().lower() for h in rows[0]]
        col, start = 0, 0
        for name in ("url", "urls", "link", "address", "submitted_url"):
            if name in header:
                col, start = header.index(name), 1
                break
        else:
            if not any(h.startswith(("http", "www")) or "." in h for h in header[:1]):
                start = 1                        # unknown header row - skip it
                warnings.append(f"no 'url' column found - using the first column '{rows[0][0]}'")
        for r in rows[start:]:
            if col < len(r) and r[col].strip() and not r[col].strip().startswith("#"):
                urls.append(r[col].strip())
    else:
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                urls.append(line)
    if len(urls) > limit:
        warnings.append(f"only the first {limit} of {len(urls)} URLs were analysed")
        urls = urls[:limit]
    return urls, warnings


def analyze_bulk(urls: list[str], settings: dict | None = None) -> list[AnalysisResult]:
    return [analyze_url(u, settings) for u in urls]


def counts(results: list[AnalysisResult]) -> dict:
    c = {lvl: 0 for lvl in C.RISK_LEVELS}
    c["INVALID"] = 0
    for r in results:
        c[r.classification] = c.get(r.classification, 0) + 1
    c["total"] = len(results)
    return c


def results_to_csv(results: list[AnalysisResult]) -> str:
    rows = [r.summary_row() for r in results]
    buf = io.StringIO()
    if rows:
        w = csv.DictWriter(buf, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return buf.getvalue()


def results_to_json(results: list[AnalysisResult]) -> str:
    return json.dumps({"generated_at": datetime.now().isoformat(timespec="seconds"), "tool": C.APP_TITLE,
                       "disclaimer": C.DISCLAIMER, "count": len(results),
                       "results": [r.to_dict() for r in results]}, indent=2, ensure_ascii=False)
