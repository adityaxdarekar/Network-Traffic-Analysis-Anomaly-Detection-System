"""
Structural URL indicators: scheme, IP host, shortener, length, '@', encoding, redirect parameters,
query size, port, unusual characters, subdomain depth, TLD, domain structure and lookalike domains.

Each function returns Indicator objects WITHOUT weights; the risk scorer applies the configured weights,
so every characteristic is counted once.
"""

from __future__ import annotations

import re
from urllib.parse import unquote, urlsplit

from detector.domain_analyzer import DomainInfo
from detector.indicators import Indicator
from detector.idna_compat import _label_to_unicode
from detector.punycode_detector import skeleton
from detector.url_parser import ParsedURL

DANGEROUS_SCHEMES = {"javascript", "data", "vbscript", "file"}
# label values that, inside a SUBDOMAIN, suggest an embedded domain name ("www.bank.com.other.test")
EMBEDDED_TLD_HINTS = {"com", "net", "org", "edu", "gov", "info", "biz", "co", "example", "test"}
_PCT = re.compile(r"%[0-9a-fA-F]{2}")


# ---------------------------------------------------------------------------------------- scheme / host
def scheme_indicators(p: ParsedURL) -> list[Indicator]:
    out = []
    if p.scheme in DANGEROUS_SCHEMES:
        out.append(Indicator("dangerous_scheme", f"Script/data scheme '{p.scheme}:'",
                             "This scheme can run code or embed content instead of opening a web page. "
                             "Legitimate links shared with users almost never use it.", f"{p.scheme}:"))
    elif p.scheme not in ("http", "https"):
        out.append(Indicator("unusual_scheme", f"Unusual scheme '{p.scheme}'",
                             "Not a normal web link (http/https); check what application it opens.", f"{p.scheme}:"))
    elif p.scheme_was_missing:
        out.append(Indicator("missing_scheme", "No scheme given",
                             "The input had no http:// or https://, so it was analysed as http://. The real "
                             "link may use either.", p.original[:60]))
    elif p.scheme == "http":
        out.append(Indicator("http_scheme", "HTTP instead of HTTPS",
                             "The connection would not be encrypted, so data such as passwords could be read or "
                             "altered in transit. HTTPS alone does NOT make a site trustworthy - phishing sites "
                             "commonly use HTTPS too.", "http://"))
    return out


def ip_indicators(d: DomainInfo) -> list[Indicator]:
    if not d.is_ip:
        return []
    if d.ip_form == "obfuscated":
        return [Indicator("obfuscated_ip", "Obfuscated IP address as hostname",
                          "The hostname is an IP address written in decimal, hex or octal form. Browsers accept "
                          "it, but it hides the real address from the reader - a typical evasion trick.",
                          f"{d.hostname} = {d.ip} ({d.ip_scope})")]
    return [Indicator("ip_host", "IP address instead of a domain name",
                      "Legitimate public websites almost always use a domain name. An IP address hides who "
                      "operates the server and avoids domain-based reputation checks. Internal devices (routers, "
                      "lab servers) do use IPs, so check the context.",
                      f"{d.ip} ({d.ip_form.upper()}, {d.ip_scope})")]


def shortener_indicator(d: DomainInfo, shorteners: list) -> list[Indicator]:
    host = d.hostname
    for s in shorteners:
        s = s.lower()
        if host == s or host.endswith("." + s):
            return [Indicator("shortener", "URL shortening service",
                              "The final destination is hidden behind the short link. It was NOT expanded or "
                              "visited; use a preview feature of the shortener or ask the sender.", s)]
    return []


def port_indicator(p: ParsedURL) -> list[Indicator]:
    if p.port is not None and p.port not in (80, 443):
        return [Indicator("nonstandard_port", f"Non-standard port {p.port}",
                          "Public websites normally use ports 80/443. Other ports are common for test or "
                          "self-hosted services and sometimes for malicious infrastructure.", f":{p.port}")]
    return []


# ---------------------------------------------------------------------------------------- text patterns
def length_indicator(p: ParsedURL, th: dict) -> list[Indicator]:
    n = p.length
    if n >= th["very_long_url"]:
        return [Indicator("very_long_url", f"Very long URL ({n} characters)",
                          "Very long URLs can hide the real destination or carry encoded data; the visible "
                          "start may look harmless.", f"{n} ≥ {th['very_long_url']}")]
    if n >= th["long_url"]:
        return [Indicator("long_url", f"Long URL ({n} characters)",
                          "Long URLs are harder to read and check. Many legitimate URLs are long too.",
                          f"{n} ≥ {th['long_url']}")]
    return []


def at_symbol_indicator(p: ParsedURL) -> list[Indicator]:
    if p.userinfo:
        return [Indicator("at_symbol", "'@' in the address part",
                          "Everything before '@' is ignored as a user name; the browser goes to the host AFTER "
                          "it. 'https://trusted.example@other.test/' opens other.test.",
                          f"{p.userinfo}@{p.hostname}")]
    return []


def encoding_indicators(p: ParsedURL, th: dict) -> list[Indicator]:
    out = []
    rest = p.original
    pct = _PCT.findall(rest)
    double = re.search(r"%25[0-9a-fA-F]{2}", rest)
    if double:
        out.append(Indicator("double_encoding", "Double URL encoding",
                             "'%25xx' decodes to another '%xx' sequence. Repeated encoding is used to slip "
                             "content past filters.", double.group(0)))
    elif p.host_percent_encoded or len(pct) > th["max_percent_encoded"]:
        where = "in the hostname" if p.host_percent_encoded else f"{len(pct)} encoded characters"
        out.append(Indicator("url_encoding", "Unusual URL encoding",
                             "Percent-encoding hides readable characters. Some encoding is normal in queries; "
                             "encoded hostnames or heavy encoding are not.", where))
    return out


def query_indicators(p: ParsedURL, th: dict, own_domain: str) -> list[Indicator]:
    out = []
    redirect = None
    for name, value in p.params:
        v = unquote(value).strip().lower()
        target = None
        if re.match(r"^(https?:)?//", v):
            target = v
        elif name.lower() in ("url", "redirect", "redirect_uri", "redirect_url", "redir", "next", "return",
                              "returnurl", "return_to", "goto", "dest", "destination", "continue", "target") \
                and re.match(r"^[a-z0-9.-]+\.[a-z]{2,}(/|$)", v):
            target = "//" + v
        if target:
            host = urlsplit(target if target.startswith(("http", "//")) else "//" + target).hostname or ""
            if host and own_domain and (host == own_domain or host.endswith("." + own_domain)):
                continue                                    # same-site redirect - normal for login pages
            redirect = f"{name}={value[:80]}"
            break
    if redirect:
        out.append(Indicator("redirect_parameter", "Redirect target in a URL parameter",
                             "A parameter contains another web address. Open-redirect tricks use a trusted-looking "
                             "first site to forward the visitor to a different one.", redirect))
    if len(p.query) > th["long_query"] or len(p.params) > th["max_params"]:
        out.append(Indicator("long_query", "Excessively long query string",
                             "Long or numerous parameters can hide tracking data, encoded payloads or redirect "
                             "targets.", f"{len(p.query)} characters, {len(p.params)} parameters"))
    return out


def character_indicators(p: ParsedURL) -> list[Indicator]:
    found = []
    if "//" in p.path:
        found.append("'//' inside the path")
    if "\\" in p.original:
        found.append("backslash")
    if p.original.count("@") > 1:
        found.append("several '@'")
    if re.search(r"[<>\"'`{}|^]", unquote(p.original)):
        found.append("characters like < > \" ' ` { } | ^")
    if re.search(r"\.{2,}", p.path):
        found.append("'..' path traversal pattern")
    if re.search(r"(?:;|,){2,}|[;,]https?:", p.original):
        found.append("unusual separators (; or ,)")
    if found:
        return [Indicator("suspicious_characters", "Unusual characters or separators",
                          "These characters are rare in normal links and are used to confuse parsers, readers or "
                          "filters.", "; ".join(found))]
    return []


# ---------------------------------------------------------------------------------------- domain structure
def subdomain_indicator(d: DomainInfo, th: dict) -> list[Indicator]:
    if not d.is_ip and d.subdomain_count > th["max_subdomains"]:
        return [Indicator("excessive_subdomains", f"Many subdomains ({d.subdomain_count})",
                          "Deep subdomain chains can push the real domain out of view, e.g. "
                          "'login.bank.example.com.attacker.test'.", d.subdomain)]
    return []


def tld_indicators(d: DomainInfo, suspicious_tlds: list) -> list[Indicator]:
    if d.is_ip or not d.tld:
        return []
    if d.tld in [t.lower().lstrip(".") for t in suspicious_tlds]:
        return [Indicator("suspicious_tld", f"Top-level domain '.{d.tld}' on the watch list",
                          "This TLD is frequently seen in abuse reports in general. Many legitimate sites use it; "
                          "this is a weak signal and never a reason on its own.", f".{d.tld}")]
    if not d.tld_in_psl and d.tld not in ("example", "test", "invalid", "localhost"):
        return [Indicator("unknown_tld", f"Unknown top-level domain '.{d.tld}'",
                          "The TLD is not in the Public Suffix List bundled with the tool - it may be internal, "
                          "mistyped or new.", f".{d.tld}")]
    return []


def structure_indicators(d: DomainInfo) -> list[Indicator]:
    if d.is_ip:
        return []
    out = []
    findings = [text for _, text in d.findings]
    embedded = [lab for lab in d.subdomain.split(".")[1:] if lab in EMBEDDED_TLD_HINTS] if d.subdomain else []
    if embedded:
        findings.append(f"subdomain '{d.subdomain}' contains what looks like another domain name "
                        f"(ends in '.{embedded[0]}')")
    if findings:
        out.append(Indicator("unusual_domain_structure", "Unusual domain structure",
                             "Hostnames built from many hyphens or digits, very long names or embedded domain "
                             "names are typical for throw-away or deceptive domains - and also occur in "
                             "legitimate technical hostnames.", "; ".join(findings)))
    labels = d.hostname.split(".")
    hits = [lab for i, lab in enumerate(labels)
            if re.search(r"(^|-)https?(-|$)", lab) or (re.search(r"(^|-)www\d*(-|$)", lab)
                                                      and not (i == 0 and re.fullmatch(r"www\d*", lab)))]
    if hits:
        out.append(Indicator("scheme_in_hostname", "'http', 'https' or 'www' inside the hostname",
                             "Words like 'https' or 'www' placed inside a hostname make a link look like a normal "
                             "address at first glance (e.g. 'https-secure-login.example').", ", ".join(hits)))
    return out


# ---------------------------------------------------------------------------------------- lookalike domains
HOMOGLYPH_ASCII = {"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "@": "a", "$": "s"}


def _norm(label: str) -> str:
    s = skeleton(label)
    s = "".join(HOMOGLYPH_ASCII.get(c, c) for c in s)
    return s.replace("rn", "m").replace("vv", "w").replace("-", "")


def edit_distance(a: str, b: str) -> int:
    """Damerau-Levenshtein (optimal string alignment) distance."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[len(a)][len(b)]


def lookalike_indicators(d: DomainInfo, p: ParsedURL, brands: dict, max_distance: int) -> list[Indicator]:
    """Compare the URL with the configured brand list. Evidence-based wording only: it says the domain is NOT
    on the brand's list, never that it impersonates the brand."""
    reg = "" if d.is_ip else d.registered_domain.lower()
    legit_all = {dom.lower() for doms in brands.values() for dom in doms}
    if reg and reg in legit_all:
        return []
    raw_label = "" if d.is_ip else _label_to_unicode(d.domain).lower()
    raw_flat = raw_label.replace("-", "")
    norm_label = _norm(raw_label)
    where_reg = reg or d.hostname
    for brand, domains in brands.items():
        names = {brand.lower()} | {dom.split(".")[0].lower() for dom in domains}
        names = {n for n in names if len(n) >= 4}
        listed = ", ".join(domains)
        if raw_label and any(n in raw_flat for n in names):
            return [Indicator("lookalike_domain", f"Brand name '{brand}' in an unlisted domain",
                              f"The registered domain '{where_reg}' contains the brand name, but it is not one of the "
                              f"brand's known domains ({listed}). This is a lookalike INDICATOR only - "
                              "organisations own many domains and the configured list may be incomplete.", where_reg)]
        if raw_label and any(n in norm_label for n in names):
            return [Indicator("lookalike_domain", f"Lookalike characters imitating '{brand}'",
                              f"'{raw_label}' reads as '{norm_label}' after replacing lookalike characters "
                              f"(0→o, 1→l, rn→m, Cyrillic/Greek letters ...). Known domains: {listed}.", where_reg)]
        for n in names:
            dist = edit_distance(norm_label, n) if raw_label and len(n) >= 5 else 99
            if 0 < dist <= max_distance:
                return [Indicator("lookalike_domain", f"Domain name close to '{n}'",
                                  f"'{raw_label}' differs from the known name '{n}' by {dist} character(s) - a "
                                  "possible typosquatting pattern, but similar names can also be coincidence. "
                                  f"Known domains: {listed}.", where_reg)]
    host_norm = _norm(d.hostname_unicode or d.hostname)
    path_text = (unquote(p.path) + " " + unquote(p.query)).lower()
    for brand in brands:
        b = brand.lower()
        if len(b) >= 4 and (b in host_norm or b in path_text):
            where = "subdomain" if b in host_norm else "path/query"
            return [Indicator("brand_in_subdomain_or_path", f"Brand name '{brand}' in the {where}",
                              f"A brand name appears outside the registered domain '{where_reg}'. Phishing pages "
                              "often place it there so the link looks familiar; it can also be a harmless mention.",
                              brand)]
    return []
