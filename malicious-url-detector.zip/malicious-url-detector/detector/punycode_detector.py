"""
Punycode / internationalized domain name (IDN) inspection.

* Any label starting with "xn--" is punycode. It is flagged for ADDITIONAL INSPECTION only - IDNs are
  legitimate and widely used (e.g. münchen.example). The concern is lookalikes such as Cyrillic "а"
  in place of Latin "a".
* A label that mixes scripts (e.g. Latin + Cyrillic) is a stronger hint of a deceptive lookalike.
* skeleton() maps common confusable characters to ASCII so lookalike checks can compare
  "exаmplebank" (Cyrillic а) with "examplebank".
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field

from detector.indicators import Indicator

# small, explainable confusables table (subset of Unicode TR39 data)
CONFUSABLES = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y", "х": "x", "і": "i", "ј": "j", "ѕ": "s",
    "ԁ": "d", "һ": "h", "ӏ": "l", "ԛ": "q", "ԝ": "w", "ɡ": "g", "ν": "v", "ο": "o", "α": "a", "ρ": "p",
    "τ": "t", "ι": "i", "κ": "k", "ı": "i", "ɩ": "i", "ʟ": "l", "ѡ": "w", "ӧ": "o", "ä": "a", "ö": "o",
    "ü": "u", "é": "e", "è": "e", "ë": "e", "á": "a", "à": "a", "í": "i", "ó": "o", "ú": "u", "ç": "c",
    "ñ": "n", "ß": "ss", "ø": "o", "å": "a",
}


def script_of(ch: str) -> str:
    if ch.isascii():
        return "Latin" if ch.isalpha() else "Common"
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return "Unknown"
    for script in ("LATIN", "CYRILLIC", "GREEK", "ARMENIAN", "HEBREW", "ARABIC", "CJK", "HIRAGANA", "KATAKANA",
                   "HANGUL", "THAI", "DEVANAGARI", "GEORGIAN"):
        if name.startswith(script) or f" {script} " in f" {name} ":
            return script.title()
    return "Other"


def skeleton(text: str) -> str:
    return "".join(CONFUSABLES.get(ch, ch) for ch in text.lower())


@dataclass
class PunycodeInfo:
    has_punycode: bool = False
    punycode_labels: list = field(default_factory=list)
    unicode_hostname: str = ""
    scripts: dict = field(default_factory=dict)        # label -> sorted list of scripts
    mixed_script_labels: list = field(default_factory=list)
    ascii_skeleton: str = ""


def inspect(hostname_ascii: str, hostname_unicode: str) -> PunycodeInfo:
    info = PunycodeInfo(unicode_hostname=hostname_unicode)
    labels_a = hostname_ascii.split(".")
    labels_u = hostname_unicode.split(".")
    info.punycode_labels = [lab for lab in labels_a if lab.startswith("xn--")]
    info.has_punycode = bool(info.punycode_labels)
    for lab in labels_u:
        scripts = sorted({script_of(c) for c in lab} - {"Common"})
        if not lab.isascii():
            info.scripts[lab] = scripts
        if len(scripts) > 1:
            info.mixed_script_labels.append(lab)
    info.ascii_skeleton = skeleton(hostname_unicode)
    return info


def detect(hostname_ascii: str, hostname_unicode: str) -> tuple[PunycodeInfo, list[Indicator]]:
    info = inspect(hostname_ascii, hostname_unicode)
    found = []
    if info.has_punycode:
        found.append(Indicator(
            "punycode", "Punycode (internationalized) hostname",
            "The hostname contains xn-- labels, i.e. non-ASCII characters. Internationalized domains are "
            "legitimate, but attackers use them for lookalikes (e.g. Cyrillic 'а' instead of Latin 'a'). "
            "Compare the decoded name carefully.",
            f"{', '.join(info.punycode_labels)} → {hostname_unicode}"))
    if info.mixed_script_labels:
        found.append(Indicator(
            "mixed_script", "Mixed character scripts in one label",
            "A single domain label mixes alphabets (e.g. Latin and Cyrillic). Real names rarely do this; "
            "it is a common way to imitate a familiar domain.",
            "; ".join(f"{lab}: {'+'.join(info.scripts.get(lab, []))}" for lab in info.mixed_script_labels)))
    return info, found
