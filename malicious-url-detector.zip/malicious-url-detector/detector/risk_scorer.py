"""
Weighted, rule-based risk scoring.

score = sum of the configured weight of every DISTINCT indicator (each indicator id counts once; the
keyword indicator already carries its capped weight), capped at 100.
Classification bands (configurable): 0-29 LOW RISK, 30-59 MEDIUM RISK, 60-100 HIGH RISK.

The score is a heuristic indicator of how many warning signs a URL shows - NOT a validated probability
that it is malicious. LOW RISK never means "safe".
"""

from __future__ import annotations

from detector.indicators import Indicator, severity_for

# Some indicators make others redundant (avoid counting the same characteristic twice).
SUPERSEDES = {
    "obfuscated_ip": {"ip_host", "unknown_tld", "unusual_domain_structure"},
    "very_long_url": {"long_url"},
    "double_encoding": {"url_encoding"},
    "dangerous_scheme": {"unusual_scheme", "missing_scheme", "http_scheme"},
    "lookalike_domain": {"brand_in_subdomain_or_path"},
}


def deduplicate(indicators: list[Indicator]) -> list[Indicator]:
    seen, out = set(), []
    present = {i.id for i in indicators}
    removed = set().union(*(SUPERSEDES.get(i, set()) for i in present)) if present else set()
    for ind in indicators:
        if ind.id in seen or ind.id in removed:
            continue
        seen.add(ind.id)
        out.append(ind)
    return out


def apply_weights(indicators: list[Indicator], weights: dict) -> list[Indicator]:
    for ind in indicators:
        if ind.id != "phishing_keywords":           # keyword weight is computed (each x count, capped)
            ind.weight = int(weights.get(ind.id, 0))
        ind.severity = severity_for(ind.weight)
    return indicators


def classify(score: int, bands: dict) -> str:
    if score >= bands["high"]:
        return "HIGH RISK"
    if score >= bands["medium"]:
        return "MEDIUM RISK"
    return "LOW RISK"


def score(indicators: list[Indicator], settings: dict) -> tuple[int, str, list[Indicator]]:
    inds = apply_weights(deduplicate(indicators), settings["weights"])
    inds.sort(key=lambda i: -i.weight)
    total = min(100, sum(max(0, i.weight) for i in inds))
    return total, classify(total, settings["risk_bands"]), inds


def recommendations(classification: str, indicators: list[Indicator]) -> list[str]:
    ids = {i.id for i in indicators}
    rec = []
    if classification == "HIGH RISK":
        rec.append("Do not open the link and do not enter credentials, payment or personal data.")
        rec.append("Verify the destination independently: type the organisation's official address yourself "
                   "or use its official app.")
        rec.append("If the link arrived by e-mail or message, report it to your IT/security team.")
    elif classification == "MEDIUM RISK":
        rec.append("Be cautious: confirm the sender and the destination before opening the link.")
        rec.append("Do not enter credentials unless you reached the site through a bookmark or the official address.")
    else:
        rec.append("No strong warning signs in the URL text. This does not guarantee that the site is safe - "
                   "the content and the sender still matter.")
    if "shortener" in ids:
        rec.append("Expand the short link with the service's preview feature (outside your browser session) "
                   "before visiting.")
    if ids & {"ip_host", "obfuscated_ip"}:
        rec.append("Ask who operates the IP address; public services should use a domain name.")
    if ids & {"lookalike_domain", "brand_in_subdomain_or_path", "punycode", "mixed_script"}:
        rec.append("Compare the registered domain letter by letter with the official one.")
    if "at_symbol" in ids:
        rec.append("Read the host after the '@' - that is where the link really goes.")
    if "redirect_parameter" in ids:
        rec.append("Check the address inside the redirect parameter; it is the real destination.")
    if classification != "LOW RISK":
        rec.append("Optionally check the URL in a threat-intelligence service (e.g. VirusTotal) - only if "
                   "sharing the URL with that service is acceptable.")
    return rec
