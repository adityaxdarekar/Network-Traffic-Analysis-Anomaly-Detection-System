"""
Domain analysis: registered domain / subdomain / public suffix extraction and domain-structure indicators.

Extraction uses the Public Suffix List (PSL), so multi-part suffixes are handled correctly:
    login.secure.example.co.uk  ->  subdomain "login.secure", domain "example", suffix "co.uk"
Backend:
  * tldextract, if installed - created OFFLINE (suffix_list_urls=()), so it uses its bundled snapshot
    and never downloads anything;
  * otherwise the bundled copy of the official PSL in data/public_suffix_list.dat (ICANN section).
Both backends treat the reserved names .example/.test/.invalid/.localhost as TLDs and fall back to the
last label as TLD when a TLD is not in the PSL (reported as "unknown TLD").
No DNS lookups are made.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path

import config as C

try:                                       # optional dependency
    import tldextract as _tldextract
except ImportError:                        # pragma: no cover - depends on environment
    _tldextract = None


# ------------------------------------------------------------------------------------ PSL backend
class PublicSuffixList:
    """Minimal implementation of the PSL algorithm (rules, wildcards '*.', exceptions '!')."""

    def __init__(self, path: Path, include_private: bool = False):
        self.rules: set[str] = set()
        self.wildcards: set[str] = set()
        self.exceptions: set[str] = set()
        section_private = False
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if "===BEGIN PRIVATE DOMAINS===" in line:
                section_private = True
            if not line or line.startswith("//"):
                continue
            if section_private and not include_private:
                continue
            rule = line.split()[0].lower()
            try:
                rule = rule.encode("idna").decode("ascii") if not rule.isascii() else rule
            except UnicodeError:
                continue
            if rule.startswith("!"):
                self.exceptions.add(rule[1:])
            elif rule.startswith("*."):
                self.wildcards.add(rule[2:])
            else:
                self.rules.add(rule)

    def suffix(self, host: str) -> str:
        """Longest matching public suffix ('' if none matched)."""
        labels = host.split(".")
        best = ""
        for i in range(len(labels)):
            cand = ".".join(labels[i:])
            if cand in self.exceptions:
                return ".".join(labels[i + 1:])
            if cand in self.rules and len(cand) > len(best):
                best = cand
            parent = ".".join(labels[i + 1:])
            if parent and parent in self.wildcards and len(cand) > len(best):
                best = cand
        return best


@lru_cache(maxsize=1)
def _psl() -> PublicSuffixList:
    return PublicSuffixList(C.PSL_FILE)


@lru_cache(maxsize=1)
def _tld_extractor():
    if _tldextract is None:
        return None
    # suffix_list_urls=() -> never fetch the list from the internet; use the snapshot shipped with tldextract
    return _tldextract.TLDExtract(suffix_list_urls=())


def backend_name() -> str:
    return "tldextract (offline snapshot)" if _tld_extractor() is not None else "bundled Public Suffix List"


def split_host(host: str, use_tldextract: bool = True) -> tuple[str, str, str]:
    """-> (subdomain, domain_label, suffix). Works for any hostname; no network access."""
    host = host.lower().rstrip(".")
    ext = _tld_extractor() if use_tldextract else None
    if ext is not None:
        r = ext(host)
        sub, dom, suf = r.subdomain, r.domain, r.suffix
    else:
        suf = _psl().suffix(host)
        rest = host[: -len(suf) - 1] if suf and host != suf else ("" if host == suf else host)
        if host == suf:
            sub, dom = "", ""
        else:
            sub, _, dom = rest.rpartition(".")
    if not suf:                               # not in the PSL (reserved or unknown TLD) -> last label
        labels = host.split(".")
        if len(labels) >= 2:
            suf = labels[-1]
            dom = labels[-2]
            sub = ".".join(labels[:-2])
        else:
            sub, dom, suf = "", host, ""
    return sub, dom, suf


# ------------------------------------------------------------------------------------ IP handling
def parse_ip_host(host: str) -> tuple[str | None, str]:
    """Return (canonical IP, form) if the host is an IP address, else (None, '').
    form: 'ipv4', 'ipv6', or 'obfuscated' (decimal / hex / octal / short forms that browsers accept)."""
    h = host.strip("[]")
    try:
        ip = ipaddress.ip_address(h.split("%")[0])
        return str(ip), f"ipv{ip.version}"
    except ValueError:
        pass
    if not re.fullmatch(r"[0-9a-fx.]+", h) or not re.search(r"\d", h):
        return None, ""
    parts = h.split(".")
    if not 1 <= len(parts) <= 4 or any(p == "" for p in parts):
        return None, ""
    values = []
    for p in parts:
        try:
            if p.startswith("0x"):
                values.append(int(p, 16))
            elif len(p) > 1 and p.startswith("0"):
                values.append(int(p, 8))
            else:
                values.append(int(p, 10))
        except ValueError:
            return None, ""
    # inet_aton rules: last part fills the remaining bytes
    limits = {1: [2 ** 32], 2: [256, 2 ** 24], 3: [256, 256, 2 ** 16], 4: [256, 256, 256, 256]}[len(values)]
    if any(v >= lim for v, lim in zip(values, limits)):
        return None, ""
    num = 0
    for v in values[:-1]:
        num = num * 256 + v
    num = num * limits[-1] + values[-1] if len(values) > 1 else values[0]
    return str(ipaddress.IPv4Address(num)), "obfuscated"


def ip_scope(ip: str) -> str:
    a = ipaddress.ip_address(ip)
    if a.is_loopback:
        return "loopback"
    if a.is_link_local:
        return "link-local"
    if a.is_private:
        return "private / reserved"
    if a.is_multicast:
        return "multicast"
    return "public"


# ------------------------------------------------------------------------------------ analysis
@dataclass
class DomainInfo:
    hostname: str
    hostname_unicode: str = ""
    is_ip: bool = False
    ip: str = ""
    ip_form: str = ""
    ip_scope: str = ""
    subdomain: str = ""
    domain: str = ""                 # registered-domain label, e.g. "example"
    suffix: str = ""                 # public suffix / TLD, e.g. "co.uk"
    registered_domain: str = ""      # domain + suffix, e.g. "example.co.uk"
    tld: str = ""                    # last label, e.g. "uk"
    tld_in_psl: bool = True
    subdomain_count: int = 0
    hyphens: int = 0
    digits_in_domain: int = 0
    dots: int = 0
    domain_length: int = 0
    hostname_length: int = 0
    findings: list = field(default_factory=list)     # [(code, text)] for the unusual-structure indicator

    def to_dict(self) -> dict:
        return asdict(self)


def analyze_domain(hostname: str, hostname_unicode: str = "", settings: dict | None = None) -> DomainInfo:
    settings = settings or C.DEFAULT_SETTINGS
    th = settings["thresholds"]
    info = DomainInfo(hostname=hostname, hostname_unicode=hostname_unicode or hostname,
                      hostname_length=len(hostname), dots=hostname.count("."))
    ip, form = parse_ip_host(hostname)
    if ip:
        info.is_ip, info.ip, info.ip_form, info.ip_scope = True, ip, form, ip_scope(ip)
        return info
    sub, dom, suf = split_host(hostname)
    info.subdomain, info.domain, info.suffix = sub, dom, suf
    info.registered_domain = f"{dom}.{suf}" if dom and suf else (dom or hostname)
    info.tld = hostname.rsplit(".", 1)[-1] if "." in hostname else ""
    info.tld_in_psl = bool(info.tld) and (_psl().suffix(info.tld) == info.tld)
    info.subdomain_count = len(sub.split(".")) if sub else 0
    info.hyphens = hostname.replace("xn--", "").count("-")
    info.digits_in_domain = sum(ch.isdigit() for ch in dom)
    info.domain_length = len(dom)

    f = info.findings
    if info.hyphens > th["max_hyphens"]:
        f.append(("hyphens", f"{info.hyphens} hyphens in the hostname (threshold {th['max_hyphens']})"))
    if info.digits_in_domain > th["max_digits"]:
        f.append(("digits", f"{info.digits_in_domain} digits in the domain name '{dom}'"))
    if info.domain_length > th["max_domain_length"]:
        f.append(("domain_length", f"domain name '{dom}' is {info.domain_length} characters long"))
    if info.dots > th["max_dots"]:
        f.append(("dots", f"{info.dots} dots in the hostname"))
    if "_" in hostname:
        f.append(("underscore", "underscore in the hostname (not valid in normal host names)"))
    if re.search(r"--", hostname.replace("xn--", "")):
        f.append(("double_hyphen", "consecutive hyphens in the hostname"))
    random_like = [lab for lab in hostname.split(".")[:-1]
                   if sum(c.isdigit() for c in lab) >= 5 and any(c.isalpha() for c in lab.replace("xn--", ""))]
    if random_like:
        f.append(("random_label", f"random-looking label with many digits: '{random_like[0]}'"))
    if not hostname.count(".") and hostname not in ("localhost",):
        f.append(("single_label", "hostname has no dot (internal or incomplete name)"))
    return info
