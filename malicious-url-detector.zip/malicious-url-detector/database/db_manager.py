"""
SQLite scan history - parameterized queries only.

Tables
  url_scans          one row per analysed URL (no personal data beyond the URL itself)
  url_indicators     triggered indicators of a scan (name, severity, explanation, score contribution)
  bulk_scan_sessions one row per bulk analysis (totals per risk level)
"""

from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import pandas as pd

import config as C

SCHEMA = """
CREATE TABLE IF NOT EXISTS bulk_scan_sessions (
    session_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp      TEXT NOT NULL,
    source_name    TEXT,
    total_urls     INTEGER NOT NULL DEFAULT 0,
    low_count      INTEGER NOT NULL DEFAULT 0,
    medium_count   INTEGER NOT NULL DEFAULT 0,
    high_count     INTEGER NOT NULL DEFAULT 0,
    invalid_count  INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS url_scans (
    scan_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    submitted_url   TEXT NOT NULL,
    normalized_url  TEXT,
    hostname        TEXT,
    domain          TEXT,
    risk_score      INTEGER,
    classification  TEXT NOT NULL,
    https_status    TEXT,
    ip_based        INTEGER NOT NULL DEFAULT 0,
    session_id      INTEGER REFERENCES bulk_scan_sessions(session_id) ON DELETE SET NULL,
    error           TEXT
);
CREATE TABLE IF NOT EXISTS url_indicators (
    indicator_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id            INTEGER NOT NULL REFERENCES url_scans(scan_id) ON DELETE CASCADE,
    indicator_key      TEXT NOT NULL,
    indicator_name     TEXT NOT NULL,
    severity           TEXT NOT NULL,
    explanation        TEXT,
    evidence           TEXT,
    score_contribution INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_scans_time ON url_scans(timestamp);
CREATE INDEX IF NOT EXISTS idx_scans_class ON url_scans(classification);
CREATE INDEX IF NOT EXISTS idx_ind_scan ON url_indicators(scan_id);
"""


class DatabaseManager:
    _lock = threading.RLock()

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path or C.DB_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.conn() as con:
            con.executescript(SCHEMA)

    @contextmanager
    def conn(self):
        with self._lock:
            con = sqlite3.connect(self.path)
            con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys = ON")
            try:
                yield con
                con.commit()
            finally:
                con.close()

    def query(self, sql: str, params: tuple = ()) -> pd.DataFrame:
        with self.conn() as con:
            return pd.read_sql_query(sql, con, params=params)

    # ----------------------------------------------------------------------------------- writes
    def save_result(self, result, session_id: int | None = None, con=None) -> int:
        """Store one AnalysisResult (+ its indicators). Returns scan_id."""
        row = result.summary_row()

        def _do(c):
            cur = c.execute(
                "INSERT INTO url_scans (timestamp, submitted_url, normalized_url, hostname, domain, risk_score, "
                "classification, https_status, ip_based, session_id, error) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (result.analyzed_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S"), result.submitted[:4096],
                 row["normalized_url"], row["hostname"], row["domain"], row["risk_score"], result.classification,
                 row["https"], int(bool(row["ip_based"])), session_id, result.error or None))
            scan_id = cur.lastrowid
            c.executemany(
                "INSERT INTO url_indicators (scan_id, indicator_key, indicator_name, severity, explanation, evidence, "
                "score_contribution) VALUES (?,?,?,?,?,?,?)",
                [(scan_id, i.id, i.name, i.severity, i.explanation, i.evidence[:500], i.weight)
                 for i in result.indicators])
            return scan_id
        if con is not None:
            return _do(con)
        with self.conn() as c:
            return _do(c)

    def save_bulk(self, results: list, source_name: str = "") -> int:
        from detector.detection_engine import counts
        c = counts(results)
        with self.conn() as con:
            cur = con.execute(
                "INSERT INTO bulk_scan_sessions (timestamp, source_name, total_urls, low_count, medium_count, "
                "high_count, invalid_count) VALUES (?,?,?,?,?,?,?)",
                (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), source_name[:200], c["total"], c["LOW RISK"],
                 c["MEDIUM RISK"], c["HIGH RISK"], c["INVALID"]))
            sid = cur.lastrowid
            for r in results:
                self.save_result(r, sid, con=con)
        return sid

    def delete_scan(self, scan_id: int) -> int:
        with self.conn() as con:
            return con.execute("DELETE FROM url_scans WHERE scan_id = ?", (int(scan_id),)).rowcount

    def delete_scans(self, scan_ids: list[int]) -> int:
        with self.conn() as con:
            return sum(con.execute("DELETE FROM url_scans WHERE scan_id = ?", (int(i),)).rowcount for i in scan_ids)

    def clear_history(self) -> None:
        with self.conn() as con:
            con.execute("DELETE FROM url_indicators")
            con.execute("DELETE FROM url_scans")
            con.execute("DELETE FROM bulk_scan_sessions")

    # ----------------------------------------------------------------------------------- reads
    def scans(self, classification: str | None = None, search: str = "", limit: int = 1000) -> pd.DataFrame:
        sql = ("SELECT scan_id, timestamp, submitted_url, normalized_url, hostname, domain, risk_score, "
               "classification, https_status, ip_based, session_id FROM url_scans WHERE 1=1")
        params: list = []
        if classification:
            sql += " AND classification = ?"
            params.append(classification)
        if search:
            sql += " AND (submitted_url LIKE ? OR domain LIKE ?)"
            params += [f"%{search}%", f"%{search}%"]
        sql += " ORDER BY scan_id DESC LIMIT ?"
        params.append(int(limit))
        return self.query(sql, tuple(params))

    def scan(self, scan_id: int) -> dict | None:
        df = self.query("SELECT * FROM url_scans WHERE scan_id = ?", (int(scan_id),))
        return None if df.empty else df.iloc[0].to_dict()

    def indicators(self, scan_id: int) -> pd.DataFrame:
        return self.query("SELECT indicator_name, severity, score_contribution, explanation, evidence FROM "
                          "url_indicators WHERE scan_id = ? ORDER BY score_contribution DESC", (int(scan_id),))

    def sessions(self) -> pd.DataFrame:
        return self.query("SELECT * FROM bulk_scan_sessions ORDER BY session_id DESC")

    def overview(self) -> dict:
        with self.conn() as con:
            total = con.execute("SELECT COUNT(*) FROM url_scans").fetchone()[0]
            by = dict(con.execute("SELECT classification, COUNT(*) FROM url_scans GROUP BY classification").fetchall())
            domains = con.execute("SELECT COUNT(DISTINCT domain) FROM url_scans WHERE domain IS NOT NULL "
                                  "AND domain != ''").fetchone()[0]
        return {"total": total, "low": by.get("LOW RISK", 0), "medium": by.get("MEDIUM RISK", 0),
                "high": by.get("HIGH RISK", 0), "invalid": by.get("INVALID", 0), "unique_domains": domains}

    def top_indicators(self, limit: int = 10) -> pd.DataFrame:
        from detector.indicators import TITLES
        df = self.query("SELECT indicator_key, COUNT(*) AS count FROM url_indicators "
                        "GROUP BY indicator_key ORDER BY count DESC, indicator_key LIMIT ?", (int(limit),))
        df.insert(0, "indicator", [TITLES.get(k, k) for k in df["indicator_key"]])
        return df
