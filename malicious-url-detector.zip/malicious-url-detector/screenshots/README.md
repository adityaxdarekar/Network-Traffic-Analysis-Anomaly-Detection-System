# Screenshots

Included: `pdf_single_report_high-1.png` and `pdf_bulk_report-1.png` are page 1 of the real PDFs in
`sample_output/`.

Dashboard screenshots could not be taken in the development environment (Streamlit was not installable). After
`run.sh` / `run.bat`, add for example: 01_overview.png, 02_single_low.png, 03_single_medium.png,
04_single_high.png, 05_bulk_filtered.png, 06_domain_analysis.png, 07_history.png, 08_reports.png, 09_settings.png.
