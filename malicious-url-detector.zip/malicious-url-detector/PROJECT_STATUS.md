# Project status - verified vs. to check on your computer

The development environment was Ubuntu 24.04 with Python 3.13, pandas 3.0, ReportLab 5.0, pytest 9.1 and
pypdf 6.17. Streamlit, Plotly and tldextract were **not installable** there (no package downloads).

## ✅ Verified by running it
| Item | Evidence |
|---|---|
| Detection engine, scoring, classification | 215 tests passed; results in `sample_output/expected_outputs.txt` |
| Domain extraction | bundled Public Suffix List (ICANN section, 2025-12-28): co.uk, com.au, wildcard `*.ck` and exception `!www.ck` tested; tldextract branch tested with a simulated extractor |
| Bulk analysis, CSV/TXT input, CSV/JSON export | tests + `sample_output/mixed_results.csv`, `mixed_results.json` |
| SQLite history | round trip, bulk sessions, delete, clear, injection-safe queries (tests) |
| PDF reports | `sample_output/single_report_low/medium/high.pdf`, `bulk_report_mixed.pdf`; page renders in `screenshots/`; text checked with pypdf in tests |
| No network access | analysis of shorteners, IPs and punycode with all socket functions blocked (test); core modules import no network libraries (test) |
| Optional online features | off by default, consent required, SSRF guard and redirect logic tested with simulated sessions/resolvers |
| Dashboard logic | all 8 pages executed headlessly with Streamlit/Plotly stand-ins (19 tests), including full single, bulk, history, reports and settings flows |
| CLI | exit codes and exports (tests) |

## ⚠️ Not verified here - please check
| Item | How |
|---|---|
| Visual look of the Streamlit pages and Plotly charts | `./run.sh` / `run.bat`, walk through `documentation/DEMO_GUIDE.md`, add screenshots to `screenshots/` |
| tldextract integration with the real package | after `setup`, `venv/bin/python -m pytest tests/test_domain_analyzer.py -v`: the 4 comparison tests then run instead of being skipped |
| Optional redirect check / RDAP lookup against real servers | enable them on Settings, confirm, try `https://example.com/` (only on a network where outbound requests are allowed) |
| Windows | `setup.bat`, then `venv\Scripts\python -m pytest -q` |
