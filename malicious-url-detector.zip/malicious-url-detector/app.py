"""
Malicious URL Detection and Risk Assessment System - Streamlit entry point.

    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from dashboard import pages  # noqa: E402
from dashboard.common import css, get_settings  # noqa: E402

PAGES = {
    "Overview Dashboard": ("📊", pages.overview),
    "Single URL Analysis": ("🔍", pages.single),
    "Bulk URL Analysis": ("📂", pages.bulk),
    "Domain Analysis": ("🌐", pages.domain),
    "Scan History": ("🗂️", pages.history),
    "Reports": ("📄", pages.reports),
    "Settings": ("⚙️", pages.settings_page),
    "About Project": ("ℹ️", pages.about),
}


def main() -> None:
    st.set_page_config(page_title=C.APP_SHORT, page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")
    st.markdown(css(), unsafe_allow_html=True)
    get_settings()
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Overview Dashboard"
    with st.sidebar:
        st.markdown("## 🛡️ URL Risk Analyzer")
        st.caption(f"Heuristic URL analysis · v{C.APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        st.caption("🔒 Local only - URLs are never opened or sent anywhere.")
    try:
        PAGES[page][1]()
    except Exception as exc:          # keep the app usable and show what went wrong
        if type(exc).__name__ in ("RerunException", "StopException"):
            raise                     # Streamlit control flow, not an error
        st.error(f"Something went wrong on this page: {exc}")
        st.exception(exc)


if __name__ == "__main__":
    main()
