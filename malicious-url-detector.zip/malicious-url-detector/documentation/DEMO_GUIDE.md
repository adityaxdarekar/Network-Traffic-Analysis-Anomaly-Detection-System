# College demonstration guide (10-15 minutes)

## Before the demo
```bash
cd malicious-url-detector
./setup.sh                          # Windows: setup.bat   (once, needs internet for packages)
venv/bin/python -m pytest -q        # expect: 215 passed (219 when tldextract is installed: +4 comparison tests)
rm -f output/url_scans.db           # optional: start with an empty history
./run.sh                            # Windows: run.bat  → http://localhost:8501
```
Keep `sample_output/expected_outputs.txt` open as a backup.

## Demo script
| Step | What you do | What appears / what you say |
|---|---|---|
| 1. Problem (1 min) | About Project page | "Links are the start of most phishing. We analyse the URL text only, never open it, and explain every point of the score." |
| 2. Safe URL | Single URL Analysis → `https://www.example.com/` → Analyse | **0/100 LOW RISK**, no findings. Point out: "LOW does not mean guaranteed safe." |
| 3. Medium | `http://192.168.1.10/verify-account` | **45/100 MEDIUM RISK**: IP host +25, HTTP +10, keywords verify/account +10. Show the explanations and recommendations, the URL components tab and the domain tab (IP scope: private). |
| 4. Lookalike | `https://examp1ebank.example/login/verify` | **40/100 MEDIUM**: "Lookalike characters imitating 'examplebank'" (digit 1 instead of l), brand + login words. |
| 5. Punycode | `https://xn--exmplebank-0qi.example/login` | **60/100 HIGH**: decoded name `exаmplebank.example` with a Cyrillic "а", mixed scripts. Then show `https://münchen.example/stadtplan` → **15 LOW**: IDNs are flagged for inspection, not condemned. |
| 6. @ trick | `https://examplebank.example@203.0.113.9/login` | **50 MEDIUM**: the real host is 203.0.113.9; everything before `@` is a user name. |
| 7. High | `http://198.51.100.7/secure-login/verify-account?redirect=https%3A%2F%2Fexample.net%2Fpay` | **70/100 HIGH**: IP, redirect parameter, 5 keywords, HTTP, long URL. Download the PDF report. |
| 8. Bulk | Bulk URL Analysis → "Load mixed sample dataset" | 40 URLs: **26 LOW, 10 MEDIUM, 4 HIGH**. Filter HIGH RISK, sort by score, search "examplebank". Export CSV / JSON / PDF. |
| 9. Domain | Domain Analysis → `https://login.secure.example.co.uk/` | Registered domain `example.co.uk`, subdomain `login.secure`, suffix `co.uk`, thanks to the Public Suffix List. |
| 10. Overview & history | Overview Dashboard, Scan History | Risk distribution, most common indicators, recent scans; delete a scan. |
| 11. Settings | Settings → set `http_scheme` to 30 → Save → re-analyse `http://example.com/` | Score changes from 10 to 30: everything is configurable. Click "Restore defaults" afterwards. |
| 12. Safety | Settings → optional network features (off) | No request is made unless enabled and confirmed. The SSRF guard blocks localhost, private and metadata addresses. |

## Expected outputs (default settings)
| Example | Score | Class |
|---|---|---|
| `https://www.example.com/` | 0 | LOW RISK |
| `https://docs.example.net/guide/getting-started` | 0 | LOW RISK |
| `https://münchen.example/stadtplan` | 15 | LOW RISK |
| `https://198.51.100.25/portal` | 25 | LOW RISK |
| `http://192.0.2.10/` | 35 | MEDIUM RISK |
| `https://examp1ebank.example/login/verify` | 40 | MEDIUM RISK |
| `http://192.168.1.10/verify-account` | 45 | MEDIUM RISK |
| `https://examplebank.example@203.0.113.9/login` | 50 | MEDIUM RISK |
| `https://xn--exmplebank-0qi.example/login` | 60 | HIGH RISK |
| `javascript:alert('demo')` | 60 | HIGH RISK |
| `http://198.51.100.7/secure-login/verify-account?redirect=https%3A%2F%2Fexample.net%2Fpay` | 70 | HIGH RISK |
| `not a url` | - | INVALID (contains whitespace) |

Full list for all 40 samples: `sample_output/expected_outputs.txt`.

## Explanation of each module (beginner level)
| Module | In simple words |
|---|---|
| `url_parser.py` | Cuts a URL into its parts (scheme, host, port, path, query …). It checks that the input is a valid URL and never crashes on rubbish input. It also turns `münchen` into its punycode form and back. |
| `domain_analyzer.py` | Finds the "real" domain using the official Public Suffix List, so `example.co.uk` is one domain and not "co.uk". It also detects IP addresses (even disguised ones like `3232235786`) and counts subdomains, hyphens and digits. |
| `punycode_detector.py` | Finds international domain names (`xn--…`), shows how they really look, and warns when one name mixes alphabets (Latin + Cyrillic). |
| `keyword_detector.py` | Looks for words like *login, verify, account, payment, free, reward* in the URL. Each adds a few points, up to a limit. |
| `url_pattern_detector.py` | All other checks: HTTP, shorteners, length, `@`, encoding, redirects, ports, strange characters, and lookalike brand domains. |
| `risk_scorer.py` | Adds the points of each finding once, caps the total at 100, decides LOW / MEDIUM / HIGH, and writes the recommendations. |
| `detection_engine.py` | Runs all of the above for one URL or a whole file, and exports CSV/JSON. |
| `db_manager.py` | Saves every scan and its findings in a small SQLite database file. |
| `pdf_generator.py` | Creates the PDF reports. |
| `services/` | Optional online checks, off by default, plus the safety guard that blocks requests to internal addresses. |
| `app.py`, `dashboard/` | The web interface. |
| `cli.py` | The same analysis from the terminal. |

## Likely questions and answers
1. **Why not just check if the site uses HTTPS?** Phishing sites use HTTPS too. HTTPS only encrypts the
   connection; it doesn't prove who you are talking to. So HTTP adds risk, but HTTPS earns no bonus.
2. **Is a HIGH RISK URL definitely malicious?** No. The score counts warning signs. Confirmation needs reputation
   data, analysis in a sandbox, or context.
3. **Why use the Public Suffix List?** To find the registered domain correctly. "Last two labels" would say
   `co.uk` for `bank.co.uk`, and attackers exploit that confusion.
4. **What is punycode?** The ASCII encoding of international domain names (`xn--…`). It is legitimate, but it
   allows lookalikes such as a Cyrillic "а".
5. **Why don't you expand short links?** Expanding means contacting the link, which can track or harm the user.
   We report that the destination is hidden instead.
6. **How do you avoid counting the same thing twice?** Each indicator counts once, and stronger ones replace
   weaker versions (very long replaces long, obfuscated IP replaces IP).
7. **How would you improve accuracy?** Evaluate on labelled datasets, tune the weights or add a machine-learning
   model, and add opt-in reputation lookups.
8. **What is SSRF and why does it matter here?** Server-side request forgery: a tool that fetches URLs could be
   abused to reach internal systems such as `169.254.169.254`. The optional checks block private, loopback,
   link-local and metadata addresses and re-check every redirect.
