import pytest
from tests.conftest import ids

from detector.detection_engine import analyze_url
from detector.url_pattern_detector import edit_distance


def test_http_flagged_https_not_proof_of_safety():
    assert "http_scheme" in ids(analyze_url("http://example.com/"))
    r = analyze_url("https://www.example.com/")
    assert ids(r) == set() and r.classification == "LOW RISK"


@pytest.mark.parametrize("url,ind", [
    ("http://192.0.2.10/", "ip_host"),
    ("https://198.51.100.25/portal", "ip_host"),
    ("http://[2001:db8::10]:8080/admin", "ip_host"),
    ("http://3232235786/", "obfuscated_ip"),
    ("http://0xc0a8010a/", "obfuscated_ip"),
])
def test_ip_based_urls(url, ind):
    r = analyze_url(url)
    assert ind in ids(r) and r.is_ip


def test_ip_is_indicator_not_verdict():
    r = analyze_url("https://198.51.100.25/portal")
    assert r.classification == "LOW RISK"           # IP alone (25) stays below MEDIUM


@pytest.mark.parametrize("url", ["https://bit.ly/abc", "https://tinyurl.com/x", "http://t.co/y", "https://is.gd/z",
                                 "https://cutt.ly/q", "https://tiny.example/AbC123"])
def test_shorteners(url):
    assert "shortener" in ids(analyze_url(url))


def test_shortener_list_is_configurable(settings):
    settings["shorteners"] = ["go.example.net"]
    assert "shortener" in ids(analyze_url("https://go.example.net/x", settings))
    assert "shortener" not in ids(analyze_url("https://bit.ly/x", settings))


def test_long_and_very_long_urls_counted_once(settings):
    assert "long_url" in ids(analyze_url("https://example.com/" + "a" * 60))
    r = analyze_url("https://example.com/" + "a" * 200)
    assert "very_long_url" in ids(r) and "long_url" not in ids(r)
    settings["thresholds"]["long_url"] = 30
    assert "long_url" in ids(analyze_url("https://example.com/" + "a" * 15, settings))


def test_excessive_subdomains():
    assert "excessive_subdomains" in ids(analyze_url("https://a.b.c.d.example.com/"))
    assert "excessive_subdomains" not in ids(analyze_url("https://a.b.example.com/"))


def test_at_symbol():
    r = analyze_url("https://examplebank.example@203.0.113.9/login")
    assert "at_symbol" in ids(r) and r.parsed.hostname == "203.0.113.9"
    assert "at_symbol" not in ids(analyze_url("https://example.com/user/@name"))     # '@' in the path is not the trick


def test_url_encoding_and_double_encoding():
    assert "url_encoding" in ids(analyze_url("https://exa%6dple.com/"))
    assert "url_encoding" in ids(analyze_url("https://example.com/" + "%41" * 12))
    r = analyze_url("https://example.com/a?x=%252e%252e")
    assert "double_encoding" in ids(r) and "url_encoding" not in ids(r)
    assert "url_encoding" not in ids(analyze_url("https://example.com/search?q=a%20b"))


def test_redirect_parameter():
    assert "redirect_parameter" in ids(analyze_url("https://example.com/r?url=https%3A%2F%2Fexample.org%2F"))
    assert "redirect_parameter" in ids(analyze_url("https://example.com/r?next=other.example.net/login"))
    assert "redirect_parameter" not in ids(analyze_url("https://example.com/login?next=/home"))
    assert "redirect_parameter" not in ids(analyze_url("https://example.com/login?next=https://www.example.com/a"))


def test_long_query():
    q = "&".join(f"p{i}=v{i}" for i in range(12))
    assert "long_query" in ids(analyze_url("https://example.com/?" + q))


def test_nonstandard_port():
    assert "nonstandard_port" in ids(analyze_url("https://example.com:8443/"))
    assert "nonstandard_port" not in ids(analyze_url("https://example.com:443/"))


def test_suspicious_characters():
    r = analyze_url("https://example.com//redirect//example.org")
    assert "suspicious_characters" in ids(r)


def test_scheme_in_hostname_and_embedded_domain():
    assert "scheme_in_hostname" in ids(analyze_url("https://https-www-secure.example.test/signin"))
    assert "scheme_in_hostname" not in ids(analyze_url("https://www.example.com/"))
    r = analyze_url("https://www.examplebank.example.verify-account.test/login")
    assert "unusual_domain_structure" in ids(r)


def test_suspicious_and_unknown_tld_are_weak_signals():
    r = analyze_url("https://shop.example.xyz/")
    assert "suspicious_tld" in ids(r) and r.classification == "LOW RISK"
    assert "unknown_tld" in ids(analyze_url("https://intranet.corp-lan/"))


@pytest.mark.parametrize("url,expected", [
    ("https://examp1ebank.example/login", "lookalike_domain"),             # digit 1 for l
    ("https://examplebank-login.test/", "lookalike_domain"),        # brand in unlisted domain
    ("https://exampelbank.example/", "lookalike_domain"),                  # transposition (distance 1)
    ("https://examplebank-secure-login.example.net/verify", "brand_in_subdomain_or_path"),
    ("https://example.org/examplebank/login", "brand_in_subdomain_or_path"),
])
def test_lookalike_detection(url, expected):
    assert expected in ids(analyze_url(url))


def test_listed_brand_domain_is_not_a_lookalike():
    r = analyze_url("https://login.examplebank.example/account")
    assert not ids(r) & {"lookalike_domain", "brand_in_subdomain_or_path"}


def test_lookalike_wording_does_not_claim_impersonation():
    r = analyze_url("https://examplebank-login.test/")
    text = " ".join(i.explanation for i in r.indicators).lower()
    assert "indicator only" in text and "impersonat" not in text


def test_edit_distance():
    assert edit_distance("examplebank", "exampelbank") == 1
    assert edit_distance("abc", "abc") == 0 and edit_distance("abc", "xyz") == 3


@pytest.mark.parametrize("url,ind", [("javascript:alert(1)", "dangerous_scheme"), ("ftp://example.com/x", "unusual_scheme"),
                                     ("example.com/x", "missing_scheme")])
def test_scheme_types(url, ind):
    assert ind in ids(analyze_url(url))
