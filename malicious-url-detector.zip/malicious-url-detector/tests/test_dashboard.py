"""Headless dashboard test: every page runs with the Streamlit/Plotly stand-ins (tests/streamlit_stub.py)."""

import pytest

from tests import streamlit_stub as S

S.install()
import streamlit as st  # noqa: E402

import app  # noqa: E402
import config as C  # noqa: E402
from dashboard import common  # noqa: E402


class Upload:
    def __init__(self, name, data):
        self.name, self._data = name, data

    def getvalue(self):
        return self._data


@pytest.fixture
def ui(db, monkeypatch, tmp_path):
    monkeypatch.setattr(common, "get_db", lambda: db)
    import dashboard.pages as pages
    monkeypatch.setattr(pages, "get_db", lambda: db)
    monkeypatch.setattr(C, "SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr(C, "REPORT_DIR", tmp_path / "reports")
    st.session_state.clear()
    S.StubState.press, S.StubState.inputs = set(), {}
    return db


def run(page, press=(), **inputs):
    st.session_state["nav"] = page
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(press), inputs
    try:
        app.main()
    except S.StopException:
        pass
    except S.RerunException:
        return "rerun"
    return [c for c in S.StubState.calls if c[0] in ("error", "exception")]


def downloads():
    return [c[1][1] for c in S.StubState.calls if c[0] == "download_button"]


@pytest.mark.parametrize("page", list(app.PAGES))
def test_every_page_renders_empty(ui, page):
    assert run(page) == []


def test_pages_present():
    for p in ["Overview Dashboard", "Single URL Analysis", "Bulk URL Analysis", "Domain Analysis", "Scan History",
              "Reports", "About Project"]:
        assert p in app.PAGES


def test_single_url_flow(ui):
    assert run("Single URL Analysis", press={"single_go"}, single_url="http://192.168.1.10/verify-account") == []
    r = st.session_state["single"]["result"]
    assert r.classification == "MEDIUM RISK" and r.score == 45
    assert any(name.endswith(".pdf") for name in downloads())
    assert ui.overview()["total"] == 1
    for page in app.PAGES:
        assert run(page) == [], page


def test_single_invalid_url(ui):
    assert run("Single URL Analysis", press={"single_go"}, single_url="not a url") == [
        c for c in S.StubState.calls if c[0] == "error"]
    assert any("Invalid or malformed URL" in str(c) for c in S.StubState.calls if c[0] == "error")


def test_bulk_upload_filter_and_exports(ui):
    up = Upload("urls.txt", b"https://www.example.com/\nhttp://192.0.2.10/\njavascript:alert(1)\nbad url\n")
    assert run("Bulk URL Analysis", press={"bulk_go"}, bulk_file=up) == []
    assert len(st.session_state["bulk"]["results"]) == 4
    names = downloads()
    assert any(n.endswith(".csv") for n in names) and any(n.endswith(".json") for n in names) \
        and any(n.endswith(".pdf") for n in names)
    assert run("Bulk URL Analysis", bulk_levels=["HIGH RISK"], bulk_search="javascript", bulk_sort="Score ↑") == []


def test_load_sample_dataset_and_overview(ui):
    assert run("Bulk URL Analysis", press={"bulk_samples"}) == []
    assert ui.overview()["total"] >= 30
    assert run("Overview Dashboard") == []
    assert any(c[0] == "plotly_chart" for c in S.StubState.calls)


def test_overview_load_button(ui):
    assert run("Overview Dashboard", press={"ov_load_samples"}) == "rerun"
    assert ui.overview()["total"] >= 30


def test_domain_page(ui):
    assert run("Domain Analysis", dom_url="https://login.secure.example.co.uk/") == []
    assert run("Domain Analysis", dom_url="http://[2001:db8::1]/") == []
    assert run("Domain Analysis", dom_url="javascript:alert(1)") == []


def test_history_delete_and_clear(ui):
    run("Single URL Analysis", press={"single_go"}, single_url="https://example.com/")
    run("Single URL Analysis", press={"single_go"}, single_url="http://example.org/")
    first = int(ui.scans()["scan_id"].min())
    assert run("Scan History", press={"hist_del"}, hist_sel=first) == "rerun"
    assert len(ui.scans()) == 1
    assert run("Scan History", press={"hist_clear"}) == []                 # not confirmed -> disabled
    assert len(ui.scans()) == 1
    assert run("Scan History", press={"hist_clear"}, hist_sure=True) == "rerun"
    assert ui.scans().empty


def test_reports_page_saves_pdf(ui):
    run("Single URL Analysis", press={"single_go"}, single_url="http://192.0.2.10/")
    run("Bulk URL Analysis", press={"bulk_samples"})
    assert run("Reports", press={"rep_single_save", "rep_bulk_save"}) == []
    assert len(list((C.REPORT_DIR).glob("*.pdf"))) == 2


def test_settings_save_and_effect(ui):
    assert run("Settings", press={"set_save"}, w_http_scheme=50) == []
    assert C.load_settings()["weights"]["http_scheme"] == 50
    run("Single URL Analysis", press={"single_go"}, single_url="http://example.com/")
    assert st.session_state["single"]["result"].score == 50


def test_network_tools_hidden_by_default(ui):
    run("Single URL Analysis", press={"single_go", "net_redirect", "net_rdap"}, single_url="https://example.com/")
    assert any("Both online checks are disabled" in str(c) for c in S.StubState.calls if c[0] == "info")
