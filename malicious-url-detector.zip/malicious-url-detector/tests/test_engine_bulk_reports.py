"""Bulk input, exports, database, PDF reports and sample datasets."""

import csv
import io
import json

import pytest
from pypdf import PdfReader

import config as C
from detector.detection_engine import (analyze_bulk, analyze_url, counts, read_urls, results_to_csv,
                                       results_to_json)
from reports.pdf_generator import bulk_report_bytes, single_report_bytes


# --------------------------------------------------------------------------------------- bulk input
def test_read_csv_with_url_column():
    data = b"id,url,note\n1,https://example.com/,a\n2,http://192.0.2.1/,b\n3,,empty\n"
    urls, warn = read_urls(data, "x.csv")
    assert urls == ["https://example.com/", "http://192.0.2.1/"] and warn == []


def test_read_csv_without_header_and_with_bom():
    urls, _ = read_urls("﻿https://example.com/\nexample.org\n".encode(), "x.csv")
    assert urls == ["https://example.com/", "example.org"]


def test_read_csv_unknown_header_uses_first_column():
    urls, warn = read_urls(b"address_list\nhttps://example.com/\n", "x.csv")
    assert urls == ["https://example.com/"] and warn


def test_read_txt_skips_comments_and_blanks():
    urls, _ = read_urls(b"# synthetic\n\nhttps://example.com/\n  http://example.org/  \n", "list.txt")
    assert urls == ["https://example.com/", "http://example.org/"]


def test_bulk_limit():
    urls, warn = read_urls("\n".join(f"https://example.com/{i}" for i in range(20)), "a.txt", limit=5)
    assert len(urls) == 5 and "first 5" in warn[0]


def test_bulk_analysis_with_malformed_rows():
    results = analyze_bulk(["https://example.com/", "not a url", "http://192.0.2.10/", ""])
    c = counts(results)
    assert c["total"] == 4 and c["INVALID"] == 2 and c["LOW RISK"] == 1 and c["MEDIUM RISK"] == 1


def test_csv_and_json_exports():
    results = analyze_bulk(["https://www.example.com/", "http://192.168.1.10/verify-account", "bad url"])
    rows = list(csv.DictReader(io.StringIO(results_to_csv(results))))
    assert [r["classification"] for r in rows] == ["LOW RISK", "MEDIUM RISK", "INVALID"]
    assert rows[1]["risk_score"] == "45" and rows[1]["ip_based"] == "True"
    data = json.loads(results_to_json(results))
    assert data["count"] == 3 and "not a probability" in data["disclaimer"]
    item = data["results"][1]
    assert item["classification"] == "MEDIUM RISK" and item["domain"]["is_ip"]
    assert {"weight", "severity", "explanation", "evidence"} <= set(item["indicators"][0])


# --------------------------------------------------------------------------------------- database
def test_database_round_trip(db):
    r = analyze_url("http://192.168.1.10/verify-account")
    sid = db.save_result(r)
    row = db.scan(sid)
    assert row["classification"] == "MEDIUM RISK" and row["risk_score"] == 45 and row["hostname"] == "192.168.1.10"
    ind = db.indicators(sid)
    assert len(ind) == 3 and ind["score_contribution"].sum() == 45


def test_database_bulk_session_and_overview(db):
    results = analyze_bulk(["https://www.example.com/", "http://192.0.2.10/", "javascript:alert(1)", "x y"])
    session = db.save_bulk(results, "test.txt")
    s = db.sessions().iloc[0]
    assert s["session_id"] == session and s["total_urls"] == 4 and s["high_count"] == 1 and s["invalid_count"] == 1
    o = db.overview()
    assert o == {"total": 4, "low": 1, "medium": 1, "high": 1, "invalid": 1, "unique_domains": 2}
    assert not db.top_indicators().empty


def test_database_delete_and_clear(db):
    a = db.save_result(analyze_url("http://example.com/"))
    b = db.save_result(analyze_url("http://example.org/"))
    assert db.delete_scan(a) == 1 and len(db.scans()) == 1
    assert db.indicators(a).empty                       # indicators deleted with the scan (cascade)
    db.clear_history()
    assert db.scans().empty and db.overview()["total"] == 0 and b


def test_database_queries_are_parameterized(db):
    db.save_result(analyze_url("https://example.com/"))
    evil = "x' OR '1'='1"
    assert db.scans(search=evil).empty and db.scans(classification=evil).empty
    assert len(db.scans()) == 1


# --------------------------------------------------------------------------------------- PDF
def _pdf_text(data: bytes) -> str:
    return "\n".join(page.extract_text() for page in PdfReader(io.BytesIO(data)).pages)


def test_single_pdf_contents():
    r = analyze_url("http://192.168.1.10/verify-account")
    text = _pdf_text(single_report_bytes(r, 42))
    for needle in ["Malicious URL Detection and Risk Assessment System", "MEDIUM RISK", "45/100", "Scan ID", "42",
                   "http://192.168.1.10/verify-account", "IP-based URL", "HTTPS status", "Triggered indicators",
                   "Recommended actions", "Limitations", "LOW RISK does not mean safe"]:
        assert needle in text, needle


def test_single_pdf_invalid_and_special_characters():
    assert b"%PDF" in single_report_bytes(analyze_url("bad url"))
    r = analyze_url("https://example.com/<script>&x=1")
    assert "<script>" in _pdf_text(single_report_bytes(r))


def test_bulk_pdf():
    results = analyze_bulk(["https://www.example.com/", "http://192.0.2.10/", "javascript:alert(1)"])
    text = _pdf_text(bulk_report_bytes(results, "samples.csv", 7))
    assert "Bulk URL Analysis Report" in text and "URLs analysed" in text and "javascript:alert(1)" in text
    assert "Details for MEDIUM and HIGH RISK URLs" in text


# --------------------------------------------------------------------------------------- samples
SAMPLE_FILES = {"low_risk_urls.csv": "LOW RISK", "suspicious_urls.csv": "MEDIUM RISK", "high_risk_urls.csv": "HIGH RISK"}


@pytest.mark.parametrize("name,level", SAMPLE_FILES.items())
def test_sample_files_match_their_risk_level(name, level):
    urls, _ = read_urls((C.SAMPLES_DIR / name).read_bytes(), name)
    assert urls and all(analyze_url(u).classification == level for u in urls)


def test_mixed_dataset_has_required_categories():
    rows = list(csv.DictReader((C.SAMPLES_DIR / "mixed_urls.csv").open(encoding="utf-8")))
    cats = [r["category"] for r in rows]
    assert len(rows) >= 30
    assert cats.count("ordinary") >= 10 and cats.count("http") >= 5 and cats.count("ip") >= 5
    assert cats.count("keywords") >= 5 and cats.count("structure") >= 5 and "shortener" in cats
    assert all("SYNTHETIC" in r["label"] for r in rows)


def test_samples_use_only_reserved_or_private_addresses():
    import ipaddress
    from detector.url_parser import parse_url
    from detector.domain_analyzer import parse_ip_host
    reserved = ("example.com", "example.org", "example.net", "example.co.uk", "example.edu")
    for r in csv.DictReader((C.SAMPLES_DIR / "mixed_urls.csv").open(encoding="utf-8")):
        p = parse_url(r["url"])
        if not p.hostname:
            continue
        ip, _ = parse_ip_host(p.hostname)
        if ip:
            assert not ipaddress.ip_address(ip).is_global, r["url"]
        else:
            h = p.hostname
            assert h.endswith(reserved) or h.split(".")[-1] in C.RESERVED_TLDS, r["url"]
