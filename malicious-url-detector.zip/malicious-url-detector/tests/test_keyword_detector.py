from detector import keyword_detector as K
from detector.detection_engine import analyze_url


def _parts(sub="", dom="", path="", query=""):
    return K.url_text_parts(sub, dom, path, query)


def test_finds_keywords_with_locations(settings):
    found = K.find_keywords(_parts("secure-login", "example", "/account/verify", "step=confirm"), settings["keywords"])
    by = {f["keyword"]: f["where"] for f in found}
    assert by["secure"] == "subdomain" and by["login"] == "subdomain"
    assert by["account"] == "path" and by["verify"] == "path" and by["confirm"] == "query"


def test_long_keywords_match_inside_tokens(settings):
    found = {f["keyword"] for f in K.find_keywords(_parts(path="/verifyaccountnow"), settings["keywords"])}
    assert {"verify", "account"} <= found


def test_short_keywords_need_whole_token(settings):
    found = {f["keyword"] for f in K.find_keywords(_parts(path="/payroll/taxonomy/cardiff"), settings["keywords"])}
    assert not found & {"pay", "tax", "card"}
    found = {f["keyword"] for f in K.find_keywords(_parts(path="/pay/tax"), settings["keywords"])}
    assert {"pay", "tax"} <= found


def test_each_keyword_counted_once_and_hyphen_variants_merge(settings):
    found = K.find_keywords(_parts(path="/login/log-in/login"), settings["keywords"])
    assert [f["keyword"] for f in found].count("login") == 1 and len(found) == 1


def test_encoded_keywords_are_found(settings):
    found = {f["keyword"] for f in K.find_keywords(_parts(path="/%6Cogin"), settings["keywords"])}
    assert "login" in found


def test_score_capped(settings):
    _, inds = K.detect(_parts(path="/login/verify/account/password/reset/payment/free/gift"), settings)
    assert inds[0].weight == settings["weights"]["keyword_max"] == 15


def test_score_per_keyword(settings):
    _, inds = K.detect(_parts(path="/login"), settings)
    assert inds[0].weight == 5 and "weak signal" in inds[0].explanation


def test_no_keywords(settings):
    assert K.detect(_parts(path="/about-us"), settings) == ([], [])


def test_custom_keyword_list(settings):
    settings["keywords"] = {"lure": ["jackpot"]}
    r = analyze_url("https://example.com/jackpot", settings)
    assert [k["keyword"] for k in r.keywords] == ["jackpot"]


def test_listed_brand_domain_label_not_scanned():
    r = analyze_url("https://paytrust.example/")
    assert r.keywords == []          # "pay" inside the legitimate brand domain is not a keyword hit
