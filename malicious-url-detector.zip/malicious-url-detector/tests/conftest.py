import socket
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config as C  # noqa: E402


@pytest.fixture
def settings():
    return C.default_settings()


@pytest.fixture
def no_network(monkeypatch):
    """Fail the test if anything tries to resolve a name or open a socket connection."""
    calls = []

    def blocked(*a, **k):
        calls.append(a)
        raise AssertionError(f"unexpected network access: {a[:2]}")
    monkeypatch.setattr(socket, "getaddrinfo", blocked)
    monkeypatch.setattr(socket, "gethostbyname", blocked)
    monkeypatch.setattr(socket, "create_connection", blocked)
    monkeypatch.setattr(socket.socket, "connect", blocked)
    return calls


@pytest.fixture
def db(tmp_path):
    from database.db_manager import DatabaseManager
    return DatabaseManager(tmp_path / "test.db")


def ids(result):
    return {i.id for i in result.indicators}
