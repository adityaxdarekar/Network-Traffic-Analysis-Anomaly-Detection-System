import pytest

from detector import domain_analyzer as D


@pytest.mark.parametrize("host,expected", [
    ("www.example.com", ("www", "example", "com")),
    ("login.secure.example.co.uk", ("login.secure", "example", "co.uk")),     # multi-part public suffix
    ("example.com.au", ("", "example", "com.au")),
    ("service.gov.uk", ("", "service", "gov.uk")),
    ("a.b.c.d.example.org", ("a.b.c.d", "example", "org")),
    ("examplebank.example", ("", "examplebank", "example")),                  # reserved TLD
    ("x.y.example.test", ("x.y", "example", "test")),
    ("shop.example.weirdtld", ("shop", "example", "weirdtld")),               # unknown TLD -> last label
    ("a.b.ck", ("", "a", "b.ck")),                                            # PSL wildcard *.ck
    ("x.www.ck", ("x", "www", "ck")),                                         # PSL exception !www.ck
    ("localhost", ("", "localhost", "")),
])
def test_split_host_uses_public_suffix_list(host, expected):
    assert D.split_host(host, use_tldextract=False) == expected


def test_backend_name_is_reported():
    assert D.backend_name() in ("tldextract (offline snapshot)", "bundled Public Suffix List")


@pytest.mark.skipif(D._tldextract is None, reason="tldextract not installed")
@pytest.mark.parametrize("host", ["www.example.com", "login.secure.example.co.uk", "examplebank.example",
                                  "a.b.c.d.example.org"])
def test_tldextract_and_psl_agree(host):
    assert D.split_host(host, use_tldextract=True) == D.split_host(host, use_tldextract=False)


@pytest.mark.parametrize("host,ip,form", [
    ("192.168.1.10", "192.168.1.10", "ipv4"),
    ("2001:db8::1", "2001:db8::1", "ipv6"),
    ("3232235786", "192.168.1.10", "obfuscated"),           # decimal
    ("0xc0a8010a", "192.168.1.10", "obfuscated"),           # hex
    ("0300.0250.01.012", "192.168.1.10", "obfuscated"),     # octal
    ("127.1", "127.0.0.1", "obfuscated"),                   # short form
])
def test_ip_hosts(host, ip, form):
    assert D.parse_ip_host(host) == (ip, form)


@pytest.mark.parametrize("host", ["example.com", "192.168.266.1", "123.example", "abc", "0xzz"])
def test_not_ip(host):
    assert D.parse_ip_host(host) == (None, "")


def test_ip_scope():
    assert D.ip_scope("127.0.0.1") == "loopback"
    assert D.ip_scope("169.254.169.254") == "link-local"
    assert D.ip_scope("10.1.2.3") == "private / reserved"
    assert D.ip_scope("8.8.8.8") == "public"       # classification only - nothing is contacted


def test_analyze_domain_counts(settings):
    d = D.analyze_domain("a.b.c.d.e.example.com", settings=settings)
    assert d.registered_domain == "example.com" and d.subdomain_count == 5 and d.tld == "com" and d.tld_in_psl
    assert any(code == "dots" for code, _ in d.findings)


def test_unusual_structure_findings(settings):
    d = D.analyze_domain("secure-update-account-verify-billing.xyz", settings=settings)
    codes = {c for c, _ in d.findings}
    assert "hyphens" in codes and "domain_length" in codes
    d2 = D.analyze_domain("login-x7k29q4831.example.invalid", settings=settings)
    assert any(c == "random_label" for c, _ in d2.findings)


def test_ordinary_domain_has_no_findings(settings):
    assert D.analyze_domain("docs.example.net", settings=settings).findings == []


def test_ip_domain_info(settings):
    d = D.analyze_domain("198.51.100.7", settings=settings)
    assert d.is_ip and d.ip_form == "ipv4" and d.registered_domain == ""


def test_psl_file_is_bundled():
    psl = D.PublicSuffixList(D.C.PSL_FILE)
    assert "co.uk" in psl.rules and "ck" in psl.wildcards and "www.ck" in psl.exceptions
    assert "blogspot.com" not in psl.rules                 # private section excluded (like tldextract default)


def test_tldextract_code_path_with_fake_extractor(monkeypatch):
    """The tldextract branch: known suffixes come from tldextract, unknown/reserved TLDs fall back to the last label."""
    class Result:
        def __init__(self, sub, dom, suf):
            self.subdomain, self.domain, self.suffix = sub, dom, suf

    def fake(host):
        if host.endswith(".co.uk"):
            return Result("login", "example", "co.uk")
        labels = host.split(".")                     # tldextract leaves suffix empty for unknown TLDs
        return Result(".".join(labels[:-1][:-1]), labels[-1], "") if len(labels) > 1 else Result("", host, "")
    monkeypatch.setattr(D, "_tld_extractor", lambda: fake)
    assert D.split_host("login.example.co.uk") == ("login", "example", "co.uk")
    assert D.split_host("examplebank.example") == ("", "examplebank", "example")
    assert D.split_host("a.b.example.test") == ("a.b", "example", "test")
