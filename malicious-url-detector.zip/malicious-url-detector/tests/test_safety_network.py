"""The default application never makes network requests; optional features are gated and SSRF-safe."""

import ast
import socket
from pathlib import Path

import pytest

from detector.detection_engine import analyze_bulk, analyze_url, read_urls
from services import domain_age, redirect_checker, threat_intel
from services.network_guard import UnsafeDestination, check_destination, ip_is_public

ROOT = Path(__file__).resolve().parent.parent


def test_analysis_makes_no_network_calls(no_network):
    urls = ["https://bit.ly/abc", "http://192.0.2.10/login", "https://xn--exmplebank-0qi.example/",
            "https://example.com/r?url=https%3A%2F%2Fexample.org", "https://tinyurl.com/x", "http://3232235786/"]
    for u in urls:
        analyze_url(u)
    data, _ = read_urls(b"url\nhttps://example.com/\nhttp://example.org/\n", "a.csv")
    analyze_bulk(data)
    assert no_network == []


def test_detector_and_reports_do_not_import_network_libraries():
    banned = {"requests", "urllib.request", "http.client", "socket", "httpx", "aiohttp", "webbrowser", "subprocess"}
    for folder in ("detector", "reports", "database", "dashboard"):
        for py in (ROOT / folder).glob("*.py"):
            tree = ast.parse(py.read_text())
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module]
                for n in names:
                    assert n not in banned and not n.startswith("urllib.request"), f"{py.name} imports {n}"


def test_network_features_disabled_by_default(settings):
    assert settings["network"]["allow_redirect_check"] is False
    assert settings["network"]["allow_domain_age_lookup"] is False
    rep = redirect_checker.check_redirects("https://example.com/", settings, consent=True)
    assert rep.hops == [] and "disabled" in rep.stopped_reason
    assert domain_age.lookup("example.com", settings, consent=True).status == "disabled"


def test_consent_required(settings):
    settings["network"]["allow_redirect_check"] = True
    settings["network"]["allow_domain_age_lookup"] = True
    assert "consent" in redirect_checker.check_redirects("https://example.com/", settings, consent=False).stopped_reason
    assert domain_age.lookup("example.com", settings, consent=False).status == "no_consent"


@pytest.mark.parametrize("ip,public", [("127.0.0.1", False), ("10.0.0.5", False), ("192.168.1.1", False),
                                       ("169.254.169.254", False), ("::1", False), ("fd00:ec2::254", False),
                                       ("fe80::1", False), ("0.0.0.0", False), ("224.0.0.1", False),
                                       ("100.64.0.1", False), ("::ffff:127.0.0.1", False), ("192.0.2.1", False),
                                       ("8.8.8.8", True), ("2606:4700::1111", True)])
def test_ip_is_public(ip, public):
    assert ip_is_public(ip) is public


def _resolver(mapping):
    def resolve(host, port, proto=0):
        if host not in mapping:
            raise socket.gaierror("no such host")
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port)) for ip in mapping[host]]
    return resolve


@pytest.mark.parametrize("scheme,host,port,msg", [
    ("ftp", "example.com", None, "scheme"), ("http", "example.com", 8080, "port"),
    ("http", "localhost", None, "not allowed"), ("http", "metadata.google.internal", None, "not allowed"),
    ("http", "169.254.169.254", None, "not a public"), ("http", "127.0.0.1", None, "not a public"),
    ("http", "3232235786", None, "obfuscated"), ("http", "printer.local", None, "not allowed"),
    ("https", "internal.example", None, "non-public"), ("https", "mixed.example", None, "non-public"),
    ("https", "missing.example", None, "cannot resolve"),
])
def test_check_destination_blocks_unsafe(scheme, host, port, msg):
    resolver = _resolver({"internal.example": ["10.0.0.7"], "mixed.example": ["93.184.215.14", "192.168.0.2"]})
    with pytest.raises(UnsafeDestination, match=msg):
        check_destination(scheme, host, port, resolver=resolver)


def test_check_destination_allows_public():
    assert check_destination("https", "public.example", None,
                             resolver=_resolver({"public.example": ["93.184.215.14"]})) == ["93.184.215.14"]


class FakeResp:
    def __init__(self, status, location=None):
        self.status_code, self.headers = status, ({"Location": location} if location else {})
        self.closed = False

    def close(self):
        self.closed = True


class FakeSession:
    def __init__(self, chain):
        self.chain, self.calls = chain, []

    def head(self, url, **kw):
        self.calls.append(("HEAD", url, kw))
        assert kw["allow_redirects"] is False and kw["timeout"] <= 10
        return self.chain.get(url, FakeResp(200))

    def get(self, url, **kw):
        self.calls.append(("GET", url, kw))
        assert kw["stream"] is True
        return FakeResp(200)


def _enabled(settings):
    settings["network"]["allow_redirect_check"] = True
    return settings


def test_redirect_chain_revalidates_each_hop(settings):
    sess = FakeSession({"https://a.example/": FakeResp(301, "https://b.example/x"),
                        "https://b.example/x": FakeResp(302, "http://169.254.169.254/latest/meta-data")})
    resolver = _resolver({"a.example": ["93.184.215.14"], "b.example": ["93.184.215.15"]})
    rep = redirect_checker.check_redirects("https://a.example/", _enabled(settings), True, sess, resolver)
    assert [h.url for h in rep.hops][-1].startswith("http://169.254.169.254")
    assert "unsafe destination" in rep.stopped_reason
    assert all("169.254" not in c[1] for c in sess.calls)          # metadata endpoint was never requested


def test_redirect_depth_limit(settings):
    settings = _enabled(settings)
    settings["network"]["max_redirects"] = 3
    chain = {f"https://r{i}.example/": FakeResp(302, f"https://r{i + 1}.example/") for i in range(10)}
    resolver = _resolver({f"r{i}.example": ["93.184.215.14"] for i in range(12)})
    rep = redirect_checker.check_redirects("https://r0.example/", settings, True, FakeSession(chain), resolver)
    assert len(rep.hops) == 4 and "after 3 redirects" in rep.stopped_reason


def test_redirect_final_and_head_fallback(settings):
    sess = FakeSession({"https://a.example/": FakeResp(405)})
    rep = redirect_checker.check_redirects("https://a.example/", _enabled(settings), True, sess,
                                           _resolver({"a.example": ["93.184.215.14"]}))
    assert [c[0] for c in sess.calls] == ["HEAD", "GET"]
    assert rep.final_url == "" or rep.stopped_reason


def test_redirect_network_error_is_reported(settings):
    class Boom(FakeSession):
        def head(self, url, **kw):
            raise TimeoutError("slow")
    rep = redirect_checker.check_redirects("https://a.example/", _enabled(settings), True, Boom({}),
                                           _resolver({"a.example": ["93.184.215.14"]}))
    assert rep.stopped_reason == "network error" and "TimeoutError" in rep.hops[0].note


class RdapSession:
    def __init__(self, status=200, payload=None, exc=None):
        self.status, self.payload, self.exc, self.urls = status, payload, exc, []

    def get(self, url, **kw):
        self.urls.append(url)
        if self.exc:
            raise self.exc
        outer = self

        class R:
            status_code = outer.status

            def json(self):
                return outer.payload
        return R()


def _rdap_on(settings):
    settings["network"]["allow_domain_age_lookup"] = True
    return settings


def test_domain_age_ok_and_only_domain_is_sent(settings):
    from datetime import datetime, timezone
    sess = RdapSession(payload={"events": [{"eventAction": "registration", "eventDate": "2026-10-01T00:00:00Z"}]})
    r = domain_age.lookup("newsite.com", _rdap_on(settings), True, sess, now=datetime(2026, 11, 6, tzinfo=timezone.utc))
    assert r.status == "ok" and r.age_days == 36 and "weak signal" in r.note
    assert sess.urls == ["https://rdap.org/domain/newsite.com"]


@pytest.mark.parametrize("sess,status", [(RdapSession(404), "unavailable"), (RdapSession(exc=OSError("down")), "error"),
                                         (RdapSession(payload={"events": []}), "unavailable")])
def test_domain_age_missing_data_is_not_malicious(settings, sess, status):
    r = domain_age.lookup("example.com", _rdap_on(settings), True, sess)
    assert r.status == status and r.age_days is None


def test_domain_age_rejects_reserved_domains(settings):
    assert domain_age.lookup("examplebank.example", _rdap_on(settings), True, RdapSession()).status == "invalid"


def test_threat_intel_needs_env_key_and_consent(monkeypatch):
    vt = threat_intel.VirusTotalProvider()
    monkeypatch.delenv("VIRUSTOTAL_API_KEY", raising=False)
    assert vt.check("https://example.com", consent=True).status == "not_configured"
    monkeypatch.setenv("VIRUSTOTAL_API_KEY", "dummy-for-test")
    assert vt.check("https://example.com", consent=False).status == "no_consent"
    assert vt.check("https://example.com", consent=True).status == "not_implemented"


def test_no_api_keys_in_source():
    import re
    pattern = re.compile(r"""(api[_-]?key|token|secret)\s*=\s*["'][A-Za-z0-9_\-]{16,}["']""", re.I)
    for py in ROOT.rglob("*.py"):
        if "tests" in py.parts:
            continue
        assert not pattern.search(py.read_text()), py
