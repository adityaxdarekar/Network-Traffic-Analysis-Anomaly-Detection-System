import pytest
from tests.conftest import ids

from detector.detection_engine import analyze_url
from detector.indicators import Indicator
from detector.risk_scorer import classify, deduplicate, recommendations, score


def test_score_is_sum_of_weights():
    r = analyze_url("http://192.168.1.10/verify-account")
    # http 10 + ip 25 + 2 keywords x 5
    assert r.score == 45 and r.classification == "MEDIUM RISK"
    assert sum(i.weight for i in r.indicators) == 45


def test_score_capped_at_100():
    r = analyze_url("http://203.0.113.50:8080/paytrust/login/verify-payment?next=http%3A%2F%2Fexample.org%2F%2525"
                    "&session=" + "A" * 90)
    assert sum(i.weight for i in r.indicators) > 100 and r.score == 100 and r.classification == "HIGH RISK"


@pytest.mark.parametrize("s,cls", [(0, "LOW RISK"), (29, "LOW RISK"), (30, "MEDIUM RISK"), (59, "MEDIUM RISK"),
                                   (60, "HIGH RISK"), (100, "HIGH RISK")])
def test_classification_bands(s, cls, settings):
    assert classify(s, settings["risk_bands"]) == cls


def test_weights_are_configurable(settings):
    settings["weights"]["http_scheme"] = 50
    r = analyze_url("http://example.com/", settings)
    assert r.score == 50 and r.classification == "MEDIUM RISK"


def test_bands_are_configurable(settings):
    settings["risk_bands"] = {"medium": 5, "high": 10}
    assert analyze_url("http://example.com/", settings).classification == "HIGH RISK"


def test_same_indicator_counted_once(settings):
    inds = [Indicator("http_scheme", "a", "x"), Indicator("http_scheme", "b", "y"), Indicator("long_url", "c", "z"),
            Indicator("very_long_url", "d", "w")]
    total, _, kept = score(inds, settings)
    assert sorted(i.id for i in kept) == ["http_scheme", "very_long_url"] and total == 20


def test_superseded_indicators():
    out = deduplicate([Indicator("ip_host", "", ""), Indicator("obfuscated_ip", "", "")])
    assert [i.id for i in out] == ["obfuscated_ip"]


def test_severity_follows_weight():
    r = analyze_url("https://examplebank.example@203.0.113.9/login")
    sev = {i.id: i.severity for i in r.indicators}
    assert sev["ip_host"] == "high" and sev["at_symbol"] == "high" and sev["phishing_keywords"] == "low"


def test_every_result_has_explanations_and_recommendations():
    for url in ["https://www.example.com/", "http://192.0.2.10/", "https://xn--exmplebank-0qi.example/login"]:
        r = analyze_url(url)
        assert r.recommendations
        assert all(i.explanation and i.name for i in r.indicators)


def test_low_risk_recommendation_does_not_promise_safety():
    rec = " ".join(recommendations("LOW RISK", []))
    assert "does not guarantee" in rec


def test_high_risk_recommendation():
    rec = " ".join(recommendations("HIGH RISK", [Indicator("shortener", "", "")]))
    assert "Do not open the link" in rec and "short link" in rec


@pytest.mark.parametrize("url,expected", [
    ("https://www.example.com/", "LOW RISK"),
    ("https://docs.example.net/guide/getting-started", "LOW RISK"),
    ("http://192.0.2.10/", "MEDIUM RISK"),
    ("https://examp1ebank.example/login/verify", "MEDIUM RISK"),
    ("https://xn--exmplebank-0qi.example/login", "HIGH RISK"),
    ("http://198.51.100.7/secure-login/verify-account?redirect=https%3A%2F%2Fexample.net%2Fpay", "HIGH RISK"),
    ("javascript:alert('demo')", "HIGH RISK"),
])
def test_reference_classifications(url, expected):
    assert analyze_url(url).classification == expected


def test_invalid_input_gets_invalid_class():
    r = analyze_url("not a url")
    assert not r.valid and r.classification == "INVALID" and r.score == 0 and ids(r) == set()
