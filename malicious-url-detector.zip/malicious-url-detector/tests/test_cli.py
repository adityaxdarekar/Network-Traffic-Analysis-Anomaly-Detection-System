import json

import cli
import config as C


def test_cli_single(capsys):
    assert cli.main(["https://www.example.com/"]) == 0
    assert "LOW RISK" in capsys.readouterr().out
    assert cli.main(["http://192.168.1.10/verify-account"]) == 1
    assert cli.main(["not a url"]) == 2


def test_cli_file_exports(tmp_path, capsys):
    out_json, out_csv, out_pdf = tmp_path / "r.json", tmp_path / "r.csv", tmp_path / "r.pdf"
    rc = cli.main(["--file", str(C.SAMPLES_DIR / "mixed_urls.csv"), "--json", str(out_json), "--csv", str(out_csv),
                   "--pdf", str(out_pdf)])
    assert rc == 1 and out_pdf.read_bytes().startswith(b"%PDF")
    assert json.loads(out_json.read_text())["count"] >= 30
    assert cli.main(["--file", str(tmp_path / "missing.csv")]) == 2
