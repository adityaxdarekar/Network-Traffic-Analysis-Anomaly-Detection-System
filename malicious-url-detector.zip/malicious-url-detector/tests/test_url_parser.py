import pytest

from detector.url_parser import parse_url, refang


def test_valid_https_components():
    p = parse_url("https://Shop.Example.com:443/cart/view?id=7&lang=en#top")
    assert p.valid and p.scheme == "https" and p.hostname == "shop.example.com"
    assert p.port == 443 and p.path == "/cart/view" and p.query == "id=7&lang=en" and p.fragment == "top"
    assert p.params == [("id", "7"), ("lang", "en")]
    assert p.normalized == "https://shop.example.com/cart/view?id=7&lang=en#top"     # default port dropped


def test_valid_http():
    p = parse_url("http://example.org/news")
    assert p.valid and p.scheme == "http" and not p.scheme_was_missing


def test_missing_scheme_is_assumed_http():
    p = parse_url("example.org/docs")
    assert p.valid and p.scheme == "http" and p.scheme_was_missing and p.hostname == "example.org"


@pytest.mark.parametrize("text", ["localhost:8080/x", "example.com:8080"])
def test_host_with_port_is_not_a_scheme(text):
    p = parse_url(text)
    assert p.valid and p.port == 8080 and p.scheme == "http"


@pytest.mark.parametrize("text,reason", [
    ("", "empty"), ("   ", "empty"), (None, "empty"),
    ("http://exa mple.com", "whitespace"),
    ("http://example.com:99999/", "port"),
    ("http://example.com:abc/", "port"),
    ("http:///nohost", "hostname"),
    ("http://[2001:db8::1/x", "IPv6"),
    ("http://[not-an-ip]/", "IPv6"),
    ("http://exa<mple.com/", "invalid characters"),
    ("http://example..com/", "empty label"),
    ("http://ex\x00ample.com", "control"),
    ("http://" + "a" * 64 + ".example/", "too long"),
])
def test_invalid_and_malformed_input_never_raises(text, reason):
    p = parse_url(text)
    assert not p.valid and reason.lower() in p.error.lower()


def test_too_long_input_rejected():
    p = parse_url("https://example.com/" + "a" * 5000)
    assert not p.valid and "longer than" in p.error


def test_ipv6_literal():
    p = parse_url("http://[2001:DB8::10]:8080/admin")
    assert p.valid and p.is_ipv6_literal and p.hostname == "2001:db8::10" and p.port == 8080
    assert p.normalized == "http://[2001:db8::10]:8080/admin"


def test_userinfo_before_at():
    p = parse_url("https://examplebank.example@203.0.113.9/login")
    assert p.userinfo == "examplebank.example" and p.hostname == "203.0.113.9"


def test_idn_is_converted_to_punycode_and_back():
    p = parse_url("https://münchen.example/")
    assert p.hostname == "xn--mnchen-3ya.example" and p.hostname_unicode == "münchen.example"


def test_percent_encoded_hostname_is_decoded_and_flagged():
    p = parse_url("https://exa%6dple.com/")
    assert p.hostname == "example.com" and p.host_percent_encoded


@pytest.mark.parametrize("text", ["javascript:alert(1)", "data:text/html;base64,AAAA", "mailto:a@b.example"])
def test_non_web_schemes_parse_without_host(text):
    p = parse_url(text)
    assert p.valid and p.hostname == "" and p.scheme == text.split(":")[0]


def test_refang():
    assert refang("hxxps://bad[.]example[.]com/x") == ("https://bad.example.com/x", True)
    p = parse_url("hxxp://bad[.]example/x")
    assert p.valid and p.defanged and p.hostname == "bad.example"


def test_protocol_relative():
    assert parse_url("//example.org/x").hostname == "example.org"
