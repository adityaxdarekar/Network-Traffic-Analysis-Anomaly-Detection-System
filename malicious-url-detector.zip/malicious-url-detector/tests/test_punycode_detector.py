from tests.conftest import ids

from detector import punycode_detector as PD
from detector.detection_engine import analyze_url


def test_punycode_label_detected():
    info, inds = PD.detect("xn--mnchen-3ya.example", "münchen.example")
    assert info.has_punycode and info.punycode_labels == ["xn--mnchen-3ya"]
    assert [i.id for i in inds] == ["punycode"]          # Latin-only IDN: no mixed-script finding


def test_legitimate_idn_is_not_high_risk():
    r = analyze_url("https://münchen.example/stadtplan")
    assert r.classification == "LOW RISK" and "punycode" in ids(r)


def test_mixed_script_lookalike():
    r = analyze_url("https://xn--exmplebank-0qi.example/login")      # Cyrillic 'а' in examplebank
    assert {"punycode", "mixed_script", "lookalike_domain"} <= ids(r)
    assert r.parsed.hostname_unicode == "exаmplebank.example"
    assert r.classification == "HIGH RISK"


def test_skeleton_maps_confusables():
    assert PD.skeleton("exаmplebаnk") == "examplebank"      # Cyrillic а -> a
    assert PD.skeleton("ρaytrust") == "paytrust"            # Greek rho -> p


def test_script_of():
    assert PD.script_of("a") == "Latin" and PD.script_of("а") == "Cyrillic" and PD.script_of("α") == "Greek"


def test_plain_ascii_has_no_punycode():
    info, inds = PD.detect("www.example.com", "www.example.com")
    assert not info.has_punycode and inds == []


def test_invalid_punycode_does_not_crash():
    r = analyze_url("https://xn--zz-invalid.example/")
    assert r.valid and "punycode" in ids(r)
