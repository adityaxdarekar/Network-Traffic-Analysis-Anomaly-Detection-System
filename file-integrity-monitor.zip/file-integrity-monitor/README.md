# File Integrity Monitoring System Using Python and SHA-256 Hashing

A Python File Integrity Monitoring (FIM) system. It records a trusted **SHA-256 baseline** of selected folders,
rescans them manually, periodically or in **real time** (watchdog), and detects **modified**, **deleted**,
**new** and **inaccessible** files. Every change raises an explained security alert with a status workflow. A
Streamlit dashboard, an SQLite history, a command-line tool and PDF/CSV/JSON reports complete the system.

> **Read-only by design.** Monitored files are never modified, repaired, deleted or executed. Only paths,
> sizes, timestamps and hashes are stored, never file contents. Nothing is sent to external services.
> A detected change is not proof of an attack: software updates and authorised edits also change files.

---

## Contents
1. [Introduction](#1-project-introduction) · 2. [Problem statement](#2-problem-statement) · 3. [Objectives](#3-objectives) ·
4. [Technologies](#4-technologies-used) · 5. [What is SHA-256?](#5-what-is-sha-256) · 6. [How FIM works](#6-how-file-integrity-monitoring-works) ·
7. [Architecture](#7-system-architecture) · 8. [Folder structure](#8-project-folder-structure) · 9. [Installation](#9-installation) ·
10. [Running](#10-running-the-application) · 11. [Creating a baseline](#11-creating-a-baseline) · 12. [Scanning](#12-scanning-files) ·
13. [Real-time monitoring](#13-real-time-monitoring) · 14. [Alerts](#14-understanding-alerts) · 15. [Reports](#15-exporting-reports) ·
16. [Testing](#16-testing) · 17. [Results](#17-results) · 18. [Limitations](#18-limitations) · 19. [Future work](#19-future-enhancements) ·
20. [Conclusion](#20-conclusion)

## 1. Project introduction
Attackers who gain access to a system often change files: they add a user to a configuration file, replace a
script with a backdoored version, delete logs, or drop a new executable. File Integrity Monitoring detects
such changes by comparing each file's cryptographic fingerprint with a fingerprint recorded when the file was
known to be good. FIM is a standard control in security frameworks, and this project implements its core for
folders a user chooses.

## 2. Problem statement
Administrators cannot notice by eye that a configuration file gained one line or that a script was swapped:
the file name, size and even the timestamp can stay plausible. Checking every file by hand is impossible.
A reliable, automatic and explainable way is needed to:
- record a trusted state,
- detect every content change, deletion and new file,
- avoid false conclusions (a file you cannot read is not "deleted"; the same problem should not create endless
  duplicate alerts), and
- leave the monitored files untouched.

## 3. Objectives
1. Hash files with SHA-256 safely: binary, chunked, read-only, robust against permission errors, missing files
   and files that change while they are read.
2. Scan selected folders recursively, with extension filters, exclusions, a size limit and no symlink following.
3. Store versioned baselines in SQLite; never replace a baseline without explicit confirmation.
4. Detect modified, deleted, new and inaccessible files.
5. Raise explained, severity-classified alerts without duplicates, with a status workflow.
6. Offer optional real-time monitoring (watchdog) with debouncing, plus periodic scanning.
7. Provide a dashboard and PDF/CSV/JSON reports; test everything automatically.

## 4. Technologies used
| Technology | Purpose |
|---|---|
| Python 3.11+ | language |
| hashlib | SHA-256 |
| pathlib, os, stat, fnmatch | cross-platform file handling, filters |
| watchdog | optional real-time file-system events (inotify / FSEvents / Windows) |
| Streamlit + Plotly | dashboard (9 pages) and charts |
| pandas | tables, comparisons, exports |
| SQLite (`sqlite3`) | baselines, hashes, scans, alerts |
| ReportLab + matplotlib | PDF report |
| pytest (+ pypdf) | automated tests |

## 5. What is SHA-256?
SHA-256 is a cryptographic hash function from the SHA-2 family (standardised by NIST in FIPS 180-4). It turns
input of any size into a fixed **256-bit (64 hexadecimal character)** value:
- **Deterministic:** the same file always gives the same hash.
- **Avalanche effect:** changing one character gives a completely different hash.
  `listen_port = 8080` and `listen_port = 8081` have unrelated hashes.
- **Collision resistance:** it is computationally infeasible to craft a different file with the same hash, so
  an attacker cannot change a file and keep its hash.
- **One-way:** the hash reveals nothing about the content, so storing hashes does not expose file contents.

The empty file always hashes to `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. The About
Project page lets you type text and watch its hash change.

## 6. How file integrity monitoring works
```
 trusted state ──► BASELINE: path → SHA-256, size, mtime  (stored in SQLite)
                         │
 later ──► RESCAN: hash every eligible file again
                         │
             COMPARE current with baseline
     ┌──────────┬────────┴─────┬──────────────┬────────────────────────────┐
  same hash   different hash  missing      not in baseline        could not be read
  UNCHANGED   MODIFIED        DELETED      NEW                    INACCESSIBLE (never "deleted")
                         │
                 ALERT ──► investigate ──► if authorised: create a new baseline (confirmed)
```
A changed timestamp with an identical hash is **not** a modification, because the content is the same.

## 7. System architecture
```
                 ┌──────────────────── Streamlit dashboard (app.py, dashboard/) ── cli.py ───────────────────┐
                 │                                                                                            │
 Create Baseline │   File Scanner          Real-Time Monitoring          Explorer / Alerts / Reports          │
                 ▼        ▼                        ▼                                ▲                          │
       core/baseline_manager    core/integrity_checker ◄── monitoring/realtime_monitor (watchdog, debounce)  │
                 │        │                 │                                       │                          │
                 └──► core/file_scanner ──► core/hash_engine (SHA-256, chunks, read-only, retry if changing)   │
                                            │                                                                  │
                          core/change_detector (MODIFIED / DELETED / NEW / INACCESSIBLE / SKIPPED)             │
                                            │                                                                  │
                          core/alert_manager (severity, explanation, no duplicates, status)                    │
                                            ▼                                                                  │
                          database/db_manager (SQLite)  ──►  reports/pdf_generator, export_manager ────────────┘
```

## 8. Project folder structure
```
file-integrity-monitor/
├── app.py                       Streamlit dashboard (9 pages)
├── cli.py                       command line: baseline · scan · watch · list (for cron / Task Scheduler)
├── config.py                    scan defaults, exclusions, severity rules, critical patterns, limits
├── requirements.txt  pytest.ini  setup.sh / run.sh (Linux, macOS)  setup.bat / run.bat (Windows)
├── core/
│   ├── hash_engine.py           SHA-256 engine
│   ├── file_scanner.py          path validation + recursive scanning
│   ├── baseline_manager.py      create / list / select / export / replace (confirmed) baselines
│   ├── change_detector.py       baseline vs. scan comparison
│   ├── integrity_checker.py     runs scans, stores results, single-file checks for real-time events
│   └── alert_manager.py         severity, explanation, duplicate prevention, status
├── monitoring/realtime_monitor.py   watchdog / polling observer / periodic scan, debounced
├── database/db_manager.py       SQLite schema and access
├── reports/                     pdf_generator.py, export_manager.py (CSV / JSON)
├── dashboard/                   one module per page + common helpers
├── samples/
│   ├── monitored_folder/        SIMULATED sample files (config.txt, users.txt, system_settings.txt, logs/, documents/)
│   └── sample_environment.py    reset + 5 demo simulations (only inside monitored_folder)
├── sample_output/               real PDF / CSV / JSON produced from the sample scenarios
├── tests/                       116 pytest tests
├── documentation/DEMO_GUIDE.md  step-by-step demonstration, expected outputs, viva questions
├── COLLEGE_PROJECT_REPORT.md    academic report
├── screenshots/                 report page images; add dashboard screenshots here
├── assets/style.css  .streamlit/config.toml
└── output/                      fim.db and saved reports (created at runtime)
```

## 9. Installation
**Linux (Ubuntu / Debian / Kali) / macOS**
```bash
sudo apt install -y python3 python3-venv python3-pip      # Debian-based, if missing
cd file-integrity-monitor
chmod +x setup.sh run.sh
./setup.sh
```
**Windows** (Python 3.11+ from python.org with "Add python.exe to PATH" ticked)
```bat
cd file-integrity-monitor
setup.bat
```
**Manual (any OS)**
```bash
python -m venv venv
venv/bin/pip install -r requirements.txt          # Windows: venv\Scripts\pip install -r requirements.txt
```
watchdog is optional: without it, the Real-Time Monitoring page offers periodic scanning instead.

## 10. Running the application
```bash
./run.sh                 # Windows: run.bat      → http://localhost:8501
```
Or with the venv activated: `streamlit run app.py`. The server listens on 127.0.0.1 only.

Command line:
```bash
venv/bin/python cli.py baseline samples/monitored_folder
venv/bin/python cli.py scan                 # exit code 0 = no changes, 1 = changes, 2 = error
venv/bin/python cli.py watch --mode watchdog
```
For periodic checks without the dashboard, run `cli.py scan` from cron (Linux), for example
`*/30 * * * * cd /path/to/file-integrity-monitor && venv/bin/python cli.py scan`, or from Windows Task Scheduler.

## 11. Creating a baseline
1. **Create Baseline** page. The directory field is pre-filled with the synthetic sample folder.
2. Optionally add directories (one per line), extensions (e.g. `.txt, .conf`), excluded folders/files and the
   maximum file size.
3. Click **🔒 Create Baseline**. Progress (files hashed, errors, current folder) is shown, followed by the result.
4. If an **active baseline already exists** for the same directories, nothing is replaced. A warning appears,
   and you must tick *"I confirm that the current files are authorized…"* and click **Replace baseline**. The old
   baseline is kept with status *Superseded*. Inactive baselines can be deleted only with a second confirmation;
   the active baseline cannot be deleted.
5. View, select and export baselines (JSON/CSV) on the same page.

**Path validation:**
- Refused: empty paths; paths that do not exist; files; symbolic links (the message names the real path);
  filesystem and drive roots (`/`, `C:\`); OS program folders (`/usr`, `/var`, `C:\Windows`, …); anything inside
  `/proc`, `/sys`, `/dev`, `/run`.
- Allowed: specific folders such as `/etc`, a project folder or `Documents`.

**Default exclusions:** `.git`, `__pycache__`, `node_modules`, `venv`, `.cache`, `tmp`, `temp`, `$RECYCLE.BIN`, …
and `*.tmp`, `*.swp`, `*~`, `.DS_Store`, `Thumbs.db`, `*.part`, `~$*`, …

**Safety limits:** 100 MB maximum file size (larger files are reported as *skipped*, never deleted); 50,000 files
per scan; symbolic links not followed; hard links and overlapping folders hashed once.

## 12. Scanning files
**File Scanner** page → **🔍 Run integrity scan**. The result shows unchanged, modified, deleted, new and
inaccessible counts, with tabs listing each group (baseline hash, current hash, sizes, reason).
For the sample folder, the page offers simulation buttons: *Modify config.txt*, *Delete documents/report.txt*,
*Create new files*, *Modify several files*, *No changes* and *Reset sample folder*. These only ever touch files
inside `samples/monitored_folder`; paths are resolved and checked first.

How hashing stays correct and safe:
- Files are opened read-only (`O_NOFOLLOW` where available) and read in 1 MiB binary chunks.
- Only regular files are hashed; FIFOs and devices are skipped, so a scan never hangs.
- The file's size, modification time and inode are compared before and after hashing. If they differ (the file
  was being written), it is hashed again, up to 3 times; then it is reported as inaccessible ("kept changing").
- A file deleted during the scan is not counted; it shows up as deleted on the next scan.
- Unreadable files and directories are **INACCESSIBLE (WARNING)**, never DELETED. Only a folder that really no
  longer exists makes its files DELETED.

## 13. Real-time monitoring
**Real-Time Monitoring** page → choose the mode → **▶ Start monitoring** / **■ Stop monitoring**. The page shows
status, mode, start time, events handled, pending events, live file events and the alerts created.

| Mode | Use |
|---|---|
| Native events (watchdog) | default; immediate (inotify on Linux, FSEvents on macOS, ReadDirectoryChangesW on Windows) |
| Polling observer | network drives / filesystems without native events |
| Periodic full scans | works without watchdog; a full scan every N seconds |

- **Debouncing:** a file is hashed only after it has been quiet for the debounce time (default 1.5 s,
  configurable), so a file still being written is not reported half-finished. Tested: a file written in five
  pieces gives one alert, with the hash of the finished file.
- **Renames:** reported as *old path deleted* plus *new path created*. A deleted or renamed folder checks every
  baseline file below it.
- The application's own `output/` folder (database, reports) is ignored.
- Real-time alerts use the same duplicate prevention as scans. Restoring a file clears its alert.

## 14. Understanding alerts
```
FILE INTEGRITY ALERT #1

Event: FILE MODIFIED
File: …/samples/monitored_folder/config.txt

Original SHA-256:
08b849b5ef95fef7a032af2c1c8254e89c85ebd103e00a0335d7c28f4a683c39

Current SHA-256:
fd273dc920eec8bdb1672031f0879db68236c1b30c25336b4524ad0457368ce1

Severity: HIGH

Explanation:
The current SHA-256 hash does not match the trusted baseline hash, so the file content has changed.
Severity HIGH: critical/configuration file. This does not prove malicious activity - software updates,
log rotation and authorised edits also change files.

Recommended action:
Verify whether the modification was authorized (change ticket, update, owner). If unexpected, compare with a
backup, review who had access and related system activity, and restore from a trusted copy if needed.
```
Every alert stores: alert ID, detection time, baseline ID, file path, event type, previous and current SHA-256,
severity, explanation, recommended action and status.

**Severity (configurable on the Settings page):**

| Event | Default |
|---|---|
| Modified critical/configuration file (`*.conf`, `*.ini`, `*config*`, `*settings*`, `users*`, `passwd`, `hosts`, `*.key`, …) | HIGH |
| Modified ordinary file | MEDIUM |
| Deleted file | HIGH |
| New file | LOW |
| New script/executable (`*.sh`, `*.exe`, `*.py`, `*.ps1`, …) | MEDIUM |
| Inaccessible file | WARNING |

**Status workflow:** New → Investigating → Resolved / False Positive (Alerts page).

**No duplicates:**
- An alert stays *active* while its condition exists. Rescanning the same condition only increases `times_seen`.
- A further change to the file (new hash) creates a new alert and supersedes the old one.
- Restoring the file clears the alert, so if the same change happens again later, it is reported again.

## 15. Exporting reports
**Reports** page (or `cli.py scan --pdf report.pdf`):
- **PDF integrity monitoring report:**
  - project title, generation date, baseline ID, monitored directory, scope and options
  - files in baseline and scanned
  - modified, deleted, new and inaccessible files, with previous and current SHA-256
  - alerts with severity distribution
  - recommended investigation steps and conclusion
- **CSV:** file inventory, hash comparison of the latest scan, security alerts.
- **JSON:** baseline export (also on the Create Baseline page).

All exports contain metadata and hashes only. Real examples are in `sample_output/`.

## 16. Testing
```bash
venv/bin/python -m pytest -v
```
| File | Tests | Covers |
|---|---|---|
| test_hash_engine.py | 17 | known SHA-256 value, same content → same hash, one-character change → different hash, empty file, 25 MiB file hashed in 1 MiB chunks, missing file, permission error (mocked and real), symlink not followed, FIFO not opened, **file changing while hashed is re-hashed**, never-stable file, file deleted while hashed, hashing leaves the file untouched |
| test_file_scanner.py | 21 | recursion, extension filter, excluded folders/files, symlinks not followed, duplicate folders and hard links hashed once, size limit, file limit, progress, unreadable directory (mocked and real), 6 invalid paths, file instead of folder, symlinked folder rejected, normalisation, eligibility |
| test_baseline_manager.py | 9 | creation, **refusal to replace without confirmation**, confirmed replacement keeps the old baseline, separate baselines per folder set, deletion needs confirmation and is refused for the active baseline, invalid directory, JSON/CSV export, no file contents stored |
| test_change_detector.py | 9 | unchanged, timestamp-only change, modified/deleted/new, unreadable file, unreadable directory, skipped file, incomplete scan never reports deletions, empty baseline |
| test_integrity_checker.py | 11 | no changes, modification, deletion, new file, multiple changes, deleted folder, unreadable file = warning, scan stored, scan leaves files untouched, vanished monitored folder, single-file check |
| test_alert_manager.py | 14 | alert fields and text, default severities (6), configurable severity, **no duplicate alerts on repeated scans**, new alert when the file changes again, restore clears and re-alerts, status workflow, status kept across scans, filters and SQL injection |
| test_realtime_monitor.py | 8 | **real watchdog events** (native and polling): modify, delete, create, rename; debounce of a file written in pieces; restore clears alert; periodic fallback; own output folder ignored; excluded files ignored; start/stop |
| test_reports_samples.py | 9 | sample reset, simulations refuse paths outside the sample folder (4 cases), **all 5 demo scenarios**, PDF contents incl. previous/current hashes and no file contents, PDF before any scan, CSV exports |
| test_dashboard_security.py | 18 | all 9 pages without data, full workflow (create → confirmation → replace → simulate → scan), invalid directory message, alert status, PDF saving, real-time start/stop from the page, settings, CLI exit codes, **source code of core/ and monitoring/ contains no write/delete/execute calls** |

Results in the development environment (Ubuntu 24.04, Python 3.13):
- As a normal user: **116 passed**.
- As root: **114 passed, 2 skipped**, because root can read mode-000 files, so the two real-permission tests
  skip themselves.
- The real-time tests passed in 3 consecutive runs.
- The code compiles on Python 3.11, 3.12 and 3.13.

Tests use only temporary folders and a temporary copy of the sample environment.

## 17. Results
**Demo scenarios** on `samples/monitored_folder` (real output, also in `sample_output/scenario_results.txt`):

| Step | Unchanged | Modified | Deleted | New | New alerts | Already reported |
|---|---|---|---|---|---|---|
| 4. No changes | 5 | 0 | 0 | 0 | 0 | 0 |
| 1. Modify config.txt | 4 | 1 | 0 | 0 | 1 (HIGH) | 0 |
| 2. Delete documents/report.txt | 3 | 1 | 1 | 0 | 1 (HIGH) | 1 |
| 3. Create unexpected_notes.txt + tools/update.sh | 3 | 1 | 1 | 2 | 2 (LOW, MEDIUM) | 2 |
| 5. Modify users.txt, system_settings.txt, application.log | 0 | 4 | 1 | 2 | 3 (HIGH, HIGH, MEDIUM) | 4 |
| Reset sample folder | 5 | 0 | 0 | 0 | 0 (7 alerts cleared) | – |

The "already reported" column shows duplicate prevention: conditions found again were not re-alerted.

**Real-time monitoring:** in native watchdog mode, a modification, a deletion, two new files, a file written in
five pieces and a rename produced 7 correct alerts within about 1.5 seconds.

**Real folders (read-only check in the development environment):**

| Folder | Files | Size | Baseline | Rescan | Result |
|---|---|---|---|---|---|
| /etc | 420 | 6 MB | 0.05 s | 0.03 s | 420 unchanged; 755 symlinks skipped |
| /usr/share/doc | 1,698 | 23 MB | 0.22 s | 0.10 s | all unchanged |
| Python dist-packages | 31,188 | 1.2 GB | 20.6 s | 2.1 s | all unchanged; 1,144 `__pycache__` items excluded |

All files had identical modification times and sizes before and after scanning. The fast rescan partly reflects
the operating system's file cache.

## 18. Limitations
- FIM shows **that** a file changed, not **who** changed it or **why**; combine it with system and audit logs
  (e.g. auditd).
- The baseline database is stored locally. An attacker with full control of the machine could alter it too;
  production FIM keeps baselines on a separate, protected system or signs them.
- Only file content is compared: permission/ownership-only changes and extended attributes are not reported.
- Periodic scans see only the state at scan time; a file changed and restored between scans is missed.
  Periodic mode has no debounce, so a scan during a write can report an intermediate version.
- Real-time events depend on the OS: very large trees may hit inotify watch limits on Linux
  (`fs.inotify.max_user_watches`); network drives need the polling mode.
- Files above the size limit, symbolic links and excluded patterns are not verified.
- Path comparison is case-sensitive; on Windows, renaming only the case of a file name appears as delete + new.
- Dashboard screenshots and Windows/macOS runs were not possible in the development environment (see PROJECT_STATUS.md).

## 19. Future enhancements
- Protected or signed baselines (HMAC) and off-host storage
- Monitoring permissions, ownership and extended attributes
- Integration with audit logs to show which user or process changed a file
- E-mail/chat notifications and a scheduler inside the dashboard
- Agent mode for several hosts with central reporting
- Optional diff view for text files with explicit user consent (contents are not stored today)

## 20. Conclusion
The project implements a complete, working file integrity monitor: safe chunked SHA-256 hashing, careful
scanning with filters and limits, versioned baselines that cannot be replaced by accident, correct
classification of modified, deleted, new and inaccessible files, explained alerts without duplicates, optional
real-time monitoring with debouncing, and professional reports. It is strictly read-only towards the files it
protects. 116 automated tests, five documented demo scenarios and read-only checks on real system folders show
that it behaves as designed.
