"""
Optional real-time monitoring.

Modes (chosen automatically, or by settings["realtime"]):
  * "watchdog"          native OS events (inotify / FSEvents / ReadDirectoryChangesW)
  * "watchdog-polling"  watchdog's PollingObserver - for network drives or when native events are unreliable
  * "periodic-scan"     no watchdog installed: a full integrity scan every polling_interval seconds

Event handling:
  * events are DEBOUNCED: a path is only re-hashed after it has been quiet for debounce_seconds, so a file
    that is still being written is not hashed half-way (the hash engine additionally retries unstable files)
  * a rename is handled as "old path removed" + "new path created"; a deleted or renamed directory checks every
    baseline file below it
  * events in the application's own output folder (database, reports) are ignored
  * the monitor only reads files; nothing is modified, deleted, repaired or executed
"""

from __future__ import annotations

import os
import threading
import time
from collections import deque
from datetime import datetime

import config as C
from core.file_scanner import ScanOptions
from core.integrity_checker import IntegrityChecker
from database.db_manager import DatabaseManager

try:
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer
    from watchdog.observers.polling import PollingObserver
    WATCHDOG_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only where watchdog is missing
    WATCHDOG_AVAILABLE = False
    FileSystemEventHandler = object


class _Handler(FileSystemEventHandler):
    def __init__(self, monitor: "RealtimeMonitor"):
        super().__init__()
        self.monitor = monitor

    def on_any_event(self, event):  # noqa: D401 - watchdog callback
        kind = event.event_type
        if kind not in ("created", "modified", "deleted", "moved"):
            return
        src = os.fsdecode(event.src_path)
        if kind == "moved":
            self.monitor.enqueue(src, "moved-from", event.is_directory)
            self.monitor.enqueue(os.fsdecode(event.dest_path), "moved-to", event.is_directory)
        elif event.is_directory and kind in ("created", "modified"):
            return                                     # file events inside the directory follow
        else:
            self.monitor.enqueue(src, kind, event.is_directory)


class RealtimeMonitor:
    def __init__(self, db: DatabaseManager, baseline_id: int, settings: dict | None = None, mode: str | None = None):
        self.db = db
        self.baseline_id = int(baseline_id)
        self.settings = settings or C.load_settings()
        self.checker = IntegrityChecker(db, self.settings)
        self.opts: ScanOptions = self.checker.baselines.options(self.baseline_id)
        rt = self.settings["realtime"]
        self.debounce = float(rt["debounce_seconds"])
        self.poll_interval = float(rt["polling_interval"])
        if mode is None:
            mode = ("watchdog-polling" if rt["use_polling"] else "watchdog") if WATCHDOG_AVAILABLE else "periodic-scan"
        self.mode = mode
        self.events: deque = deque(maxlen=500)            # live event log for the dashboard
        self.new_alert_ids: list = []
        self.pending: dict[str, tuple[float, str, bool]] = {}
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.observer = None
        self.worker: threading.Thread | None = None
        self.started_at: str | None = None
        self.error: str | None = None
        self.ignored_root = os.path.abspath(str(C.OUTPUT_DIR))

    # ------------------------------------------------------------------ control
    @property
    def running(self) -> bool:
        return self.worker is not None and self.worker.is_alive() and not self.stop_event.is_set()

    def start(self) -> None:
        if self.running:
            return
        self.stop_event.clear()
        self.started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if self.mode in ("watchdog", "watchdog-polling"):
            if not WATCHDOG_AVAILABLE:
                raise RuntimeError("watchdog is not installed - use periodic scanning instead.")
            self.observer = (PollingObserver(timeout=self.poll_interval) if self.mode == "watchdog-polling"
                             else Observer())
            for d in self.opts.directories:
                if os.path.isdir(d):
                    self.observer.schedule(_Handler(self), d, recursive=True)
            self.observer.start()
            self.worker = threading.Thread(target=self._process_loop, name="fim-debounce", daemon=True)
        else:
            self.worker = threading.Thread(target=self._periodic_loop, name="fim-periodic", daemon=True)
        self.worker.start()
        self._log("monitor", ", ".join(self.opts.directories), f"started ({self.mode})")

    def stop(self) -> None:
        self.stop_event.set()
        if self.observer is not None:
            self.observer.stop()
            self.observer.join(timeout=5)
            self.observer = None
        if self.worker is not None:
            self.worker.join(timeout=10)
        self._log("monitor", "", "stopped")

    def status(self) -> dict:
        return {"running": self.running, "mode": self.mode, "baseline_id": self.baseline_id,
                "directories": self.opts.directories, "started_at": self.started_at, "events": len(self.events),
                "pending": len(self.pending), "alerts_created": len(self.new_alert_ids),
                "debounce_seconds": self.debounce, "error": self.error}

    # ------------------------------------------------------------------ events
    def enqueue(self, path: str, kind: str, is_dir: bool = False) -> None:
        path = os.path.abspath(path)
        if path == self.ignored_root or path.startswith(self.ignored_root + os.sep):
            return
        with self.lock:
            self.pending[path] = (time.monotonic(), kind, is_dir)

    def _log(self, kind: str, path: str, result: str, alert_ids=None) -> None:
        self.events.appendleft({"time": datetime.now().strftime("%H:%M:%S"), "event": kind, "path": path,
                                "result": result, "alerts": ", ".join(f"#{a}" for a in alert_ids or [])})

    def _due(self) -> list[tuple[str, str, bool]]:
        now = time.monotonic()
        with self.lock:
            ready = [(p, k, d) for p, (t, k, d) in self.pending.items() if now - t >= self.debounce]
            for p, _, _ in ready:
                self.pending.pop(p, None)
        return ready

    def _paths_for(self, path: str, is_dir: bool) -> list[str]:
        if not is_dir and not os.path.isdir(path):
            return [path]
        prefix = path.rstrip(os.sep) + os.sep
        rows = self.db.query("SELECT file_path FROM baseline_files WHERE baseline_id = ? AND file_path LIKE ?",
                             (self.baseline_id, prefix.replace("%", r"\%") + "%"))
        paths = list(rows["file_path"]) if not rows.empty else []
        if os.path.isdir(path):                          # a directory moved INTO the monitored tree
            for root, dirs, files in os.walk(path):
                paths += [os.path.join(root, f) for f in files]
        return sorted(set(paths))

    def process_due(self) -> int:
        """Check every path whose events have settled. Returns the number of files checked."""
        n = 0
        for path, kind, is_dir in self._due():
            for p in self._paths_for(path, is_dir):
                try:
                    change, outcome = self.checker.check_single_file(self.baseline_id, p, self.opts)
                except Exception as exc:  # noqa: BLE001 - keep monitoring even if one file fails
                    self.error = f"{p}: {exc.__class__.__name__}"
                    self._log(kind, p, "error while checking")
                    continue
                if change is None:
                    continue
                n += 1
                ids = outcome.created if outcome else []
                self.new_alert_ids += ids
                result = change.status + (" - alert" if ids else (" - already alerted" if outcome and
                                                                  outcome.repeated else ""))
                self._log(kind, p, result, ids)
        return n

    def _process_loop(self) -> None:
        while not self.stop_event.is_set():
            self.process_due()
            self.stop_event.wait(0.25)
        self.process_due()

    def _periodic_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                rep = self.checker.run_scan(self.baseline_id, trigger="periodic")
                self.new_alert_ids += rep.alerts.created
                self._log("periodic scan", "", f"{rep.counts['MODIFIED']} modified, {rep.counts['DELETED']} "
                                              f"deleted, {rep.counts['NEW']} new", rep.alerts.created)
            except Exception as exc:  # noqa: BLE001
                self.error = f"periodic scan failed: {exc.__class__.__name__}"
            self.stop_event.wait(self.poll_interval)


# One monitor per process - the dashboard re-runs its script on every click, the monitor must survive that.
_MONITOR: RealtimeMonitor | None = None


def get_monitor() -> RealtimeMonitor | None:
    return _MONITOR


def start_monitor(db: DatabaseManager, baseline_id: int, settings: dict | None = None,
                  mode: str | None = None) -> RealtimeMonitor:
    global _MONITOR
    if _MONITOR is not None and _MONITOR.running:
        _MONITOR.stop()
    _MONITOR = RealtimeMonitor(db, baseline_id, settings, mode)
    _MONITOR.start()
    return _MONITOR


def stop_monitor() -> None:
    if _MONITOR is not None:
        _MONITOR.stop()
