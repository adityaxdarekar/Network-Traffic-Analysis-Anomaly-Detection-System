"""Real-time monitoring with real file-system events (watchdog) and the periodic fallback."""

from __future__ import annotations

import os
import time

import pytest

import config as C
from conftest import p
from monitoring import realtime_monitor as RM
from monitoring.realtime_monitor import RealtimeMonitor

pytestmark = pytest.mark.skipif(not RM.WATCHDOG_AVAILABLE, reason="watchdog not installed")


def wait_for(cond, timeout=10.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.1)
    return False


@pytest.fixture
def fast(env):
    env["settings"]["realtime"].update(debounce_seconds=0.4, polling_interval=0.3)
    return env


@pytest.mark.parametrize("mode", ["watchdog", "watchdog-polling"])
def test_events_create_modify_delete_rename(fast, mode):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], mode)
    m.start()
    try:
        time.sleep(0.5)
        f = fast["folder"]
        (f / "config.txt").write_text("listen_port = 1\n")
        (f / "docs" / "report.txt").unlink()
        (f / "docs" / "new.txt").write_text("new\n")
        os.rename(f / "users.txt", f / "users_old.txt")
        assert wait_for(lambda: len(m.new_alert_ids) >= 5), list(m.events)
    finally:
        m.stop()
    df = fast["ic"].alerts.list(fast["bid"])
    got = {(r.file_path, r.event_type) for r in df.itertuples()}
    assert {(p(f, "config.txt"), "MODIFIED"), (p(f, "docs/report.txt"), "DELETED"), (p(f, "docs/new.txt"), "NEW"),
            (p(f, "users.txt"), "DELETED"), (p(f, "users_old.txt"), "NEW")} <= got
    assert set(df["source"]) == {"realtime"} and not m.running


def test_debounce_hashes_a_file_being_written_once(fast):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], "watchdog")
    m.start()
    try:
        time.sleep(0.5)
        target = fast["folder"] / "docs" / "growing.txt"
        with open(target, "w") as fh:                          # written in pieces, 0.15 s apart
            for _ in range(5):
                fh.write("x" * 1000)
                fh.flush()
                time.sleep(0.15)
        assert wait_for(lambda: len(m.new_alert_ids) >= 1)
        time.sleep(1.0)
    finally:
        m.stop()
    df = fast["ic"].alerts.list(fast["bid"])
    assert len(df) == 1                                        # one alert, for the finished file
    from core.hash_engine import hash_file
    assert df.iloc[0]["current_hash"] == hash_file(target).sha256


def test_restore_clears_alert_in_realtime(fast):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], "watchdog")
    m.start()
    try:
        time.sleep(0.5)
        f = fast["folder"] / "users.txt"
        original = f.read_text()
        f.write_text("tampered\n")
        assert wait_for(lambda: len(m.new_alert_ids) == 1)
        f.write_text(original)
        assert wait_for(lambda: int(fast["ic"].alerts.list(fast["bid"])["active"].sum()) == 0)
    finally:
        m.stop()


def test_periodic_scan_fallback(fast):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], "periodic-scan")
    m.start()
    try:
        time.sleep(0.4)
        (fast["folder"] / "users.txt").write_text("changed\n")
        assert wait_for(lambda: len(m.new_alert_ids) >= 1)
    finally:
        m.stop()
    assert m.status()["mode"] == "periodic-scan" and not m.running


def test_own_output_folder_is_ignored(fast):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], "watchdog")
    m.enqueue(os.path.join(str(C.OUTPUT_DIR), "fim.db"), "modified")
    assert m.pending == {}


def test_excluded_files_are_ignored(fast):
    m = RealtimeMonitor(fast["db"], fast["bid"], fast["settings"], "watchdog")
    (fast["folder"] / "draft.tmp").write_text("t")
    m.debounce = 0
    m.enqueue(str(fast["folder"] / "draft.tmp"), "created")
    assert m.process_due() == 0 and m.new_alert_ids == []


def test_module_level_start_stop(fast):
    mon = RM.start_monitor(fast["db"], fast["bid"], fast["settings"], "watchdog")
    assert RM.get_monitor() is mon and mon.running
    RM.stop_monitor()
    assert not mon.running
