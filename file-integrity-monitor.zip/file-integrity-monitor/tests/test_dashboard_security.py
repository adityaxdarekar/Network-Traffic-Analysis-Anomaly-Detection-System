"""Headless dashboard tests (Streamlit stand-in) and read-only guarantees of the source code."""

from __future__ import annotations

import re

import pytest

from tests import streamlit_stub as S

S.install()
import streamlit as st  # noqa: E402

import app  # noqa: E402
import config as C  # noqa: E402
from conftest import ROOT  # noqa: E402
from dashboard import common  # noqa: E402
from samples import sample_environment as SE  # noqa: E402


@pytest.fixture
def ui(tmp_path, monkeypatch, db):
    monkeypatch.setattr(C, "SAMPLES_DIR", tmp_path / "samples")
    monkeypatch.setattr(C, "SAMPLE_FOLDER", tmp_path / "samples" / "monitored_folder")
    monkeypatch.setattr(C, "SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr(C, "REPORT_DIR", tmp_path / "reports")
    monkeypatch.setattr(common, "get_db", lambda: db)
    SE.reset_sample()
    st.session_state.clear()
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(), {}
    return db


def page(name, press=(), **inputs):
    st.session_state["nav"] = name
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(press), inputs
    try:
        app.main()
    except S.StopException:
        pass
    except S.RerunException:
        return "rerun"
    return [c for c in S.StubState.calls if c[0] in ("error", "exception")]


def test_pages():
    assert list(app.PAGES)[:8] == ["Overview Dashboard", "Create Baseline", "File Scanner", "Real-Time Monitoring",
                                   "File Explorer", "Alerts", "Reports", "Settings"]
    assert "About Project" in app.PAGES


@pytest.mark.parametrize("name", list(app.PAGES))
def test_pages_without_baseline(ui, name):
    assert page(name) == []


def test_full_workflow(ui):
    assert page("Create Baseline", press={"🔒 Create Baseline"}) == []
    assert "Baseline #1 created: 5 files" in st.session_state["baseline_msg"]
    # second click -> confirmation required, nothing replaced
    assert page("Create Baseline", press={"🔒 Create Baseline"}) == []
    assert st.session_state["pending_replace"] == 1 and len(ui.query("SELECT * FROM baselines")) == 1
    # confirm checkbox not ticked -> replace button disabled, still one baseline
    assert page("Create Baseline", press={"Replace baseline"}) == [] and len(ui.query("SELECT * FROM baselines")) == 1
    assert page("Create Baseline", press={"Replace baseline"}, b_confirm=True) == []
    assert list(ui.query("SELECT status FROM baselines ORDER BY baseline_id")["status"]) == ["Superseded", "Active"]
    # simulate + scan
    assert page("File Scanner", press={"✏️ Modify config.txt"}) == []
    assert page("File Scanner", press={"🔍 Run integrity scan"}) == []
    assert st.session_state["report"].counts["MODIFIED"] == 1
    for name in app.PAGES:
        assert page(name) == [], name


def test_invalid_directory_message(ui):
    errors = page("Create Baseline", press={"🔒 Create Baseline"}, b_dirs="/")
    assert len(errors) == 1 and "system location" in str(errors[0])


def test_alert_status_update(ui):
    page("Create Baseline", press={"🔒 Create Baseline"})
    SE.simulate_deletion()
    page("File Scanner", press={"🔍 Run integrity scan"})
    assert page("Alerts", press={"Update status"}, al_new="Investigating") == "rerun"
    assert set(ui.query("SELECT status FROM security_alerts")["status"]) == {"Investigating"}


def test_reports_page_saves_pdf(ui):
    page("Create Baseline", press={"🔒 Create Baseline"})
    page("File Scanner", press={"🔍 Run integrity scan"})
    assert page("Reports", press={"💾 Save PDF to output/reports"}) == []
    assert list(C.REPORT_DIR.glob("*.pdf"))


def test_realtime_page_start_stop(ui):
    page("Create Baseline", press={"🔒 Create Baseline"})
    assert page("Real-Time Monitoring", press={"▶ Start monitoring"}) == []
    from monitoring.realtime_monitor import get_monitor
    assert get_monitor().running
    assert page("Real-Time Monitoring", press={"■ Stop monitoring"}) == []
    assert not get_monitor().running


def test_settings_save(ui, tmp_path):
    assert page("Settings", press={"💾 Save settings"}, st_sev_NEW="HIGH") == []
    assert C.load_settings(tmp_path / "settings.json")["severity"]["NEW"] == "HIGH"


def test_monitoring_code_is_read_only():
    """core/ and monitoring/ never write, delete, move or execute files (only the sample simulator may write)."""
    forbidden = [r"open\([^)]*['\"][wax]b?\+?['\"]", r"\.write_(text|bytes)\(", r"os\.(remove|unlink|rename|"
                 r"replace|rmdir|chmod|chown|system)\(", r"shutil\.", r"subprocess", r"\.unlink\(", r"os\.O_WRONLY",
                 r"os\.O_RDWR", r"exec\(", r"eval\("]
    for folder in ("core", "monitoring"):
        for py in (ROOT / folder).glob("*.py"):
            text = py.read_text()
            for pat in forbidden:
                assert not re.search(pat, text), (py.name, pat)


def test_cli_baseline_scan_exit_codes(tmp_path, folder, capsys):
    import cli
    dbf = str(tmp_path / "cli.db")
    assert cli.main(["--db", dbf, "baseline", str(folder)]) == 0
    assert cli.main(["--db", dbf, "baseline", str(folder)]) == 2            # needs --replace
    assert "--replace" in capsys.readouterr().out
    assert cli.main(["--db", dbf, "scan"]) == 0                              # no changes
    (folder / "users.txt").write_text("changed\n")
    assert cli.main(["--db", dbf, "scan", "--pdf", str(tmp_path / "r.pdf")]) == 1
    out = capsys.readouterr().out
    assert "MODIFIED" in out and "users.txt" in out and (tmp_path / "r.pdf").exists()
    assert cli.main(["--db", dbf, "baseline", str(folder), "--replace"]) == 0
    assert cli.main(["--db", dbf, "list"]) == 0 and "Superseded" in capsys.readouterr().out
