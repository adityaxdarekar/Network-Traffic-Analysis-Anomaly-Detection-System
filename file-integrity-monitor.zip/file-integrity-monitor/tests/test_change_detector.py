"""Change detection logic (pure comparison)."""

from __future__ import annotations

from core.change_detector import compare, summarise
from core.file_scanner import ScanResult
from core.hash_engine import FileRecord

BASE = {"/m/a.txt": {"sha256": "aa", "size": 1, "mtime": 1.0},
        "/m/b.txt": {"sha256": "bb", "size": 2, "mtime": 2.0},
        "/m/sub/c.txt": {"sha256": "cc", "size": 3, "mtime": 3.0}}


def result(**records):
    r = ScanResult()
    for path, (sha, mtime) in records.items():
        r.records[path] = FileRecord(path, 1, mtime, sha)
    return r


def by_status(changes):
    return {c.path: c.status for c in changes}


def test_unchanged():
    r = result(**{"/m/a.txt": ("aa", 1.0), "/m/b.txt": ("bb", 2.0), "/m/sub/c.txt": ("cc", 3.0)})
    assert summarise(compare(BASE, r))["UNCHANGED"] == 3


def test_timestamp_only_change_is_not_a_modification():
    r = result(**{"/m/a.txt": ("aa", 99.0), "/m/b.txt": ("bb", 2.0), "/m/sub/c.txt": ("cc", 3.0)})
    ch = {c.path: c for c in compare(BASE, r)}
    assert ch["/m/a.txt"].status == "UNCHANGED" and "content identical" in ch["/m/a.txt"].detail


def test_modified_deleted_new():
    r = result(**{"/m/a.txt": ("XX", 5.0), "/m/sub/c.txt": ("cc", 3.0), "/m/new.txt": ("nn", 6.0)})
    ch = {c.path: c for c in compare(BASE, r)}
    assert by_status(ch.values()) == {"/m/a.txt": "MODIFIED", "/m/b.txt": "DELETED", "/m/sub/c.txt": "UNCHANGED",
                                      "/m/new.txt": "NEW"}
    assert (ch["/m/a.txt"].baseline_hash, ch["/m/a.txt"].current_hash) == ("aa", "XX")
    assert ch["/m/b.txt"].baseline_size == 2 and ch["/m/new.txt"].current_hash == "nn"


def test_unreadable_file_is_not_deleted():
    r = result(**{"/m/a.txt": ("aa", 1.0), "/m/sub/c.txt": ("cc", 3.0)})
    r.errors["/m/b.txt"] = "permission denied"
    assert by_status(compare(BASE, r))["/m/b.txt"] == "INACCESSIBLE"


def test_files_in_unreadable_directory_are_not_deleted():
    r = result(**{"/m/a.txt": ("aa", 1.0), "/m/b.txt": ("bb", 2.0)})
    r.errors["/m/sub"] = "permission denied (directory)"
    r.error_dirs.append("/m/sub")
    st = by_status(compare(BASE, r))
    assert st["/m/sub/c.txt"] == "INACCESSIBLE" and "/m/sub" not in st


def test_skipped_file_is_not_deleted():
    r = result(**{"/m/a.txt": ("aa", 1.0), "/m/b.txt": ("bb", 2.0)})
    r.skipped["/m/sub/c.txt"] = "larger than 1 MB"
    assert by_status(compare(BASE, r))["/m/sub/c.txt"] == "SKIPPED"


def test_incomplete_scan_does_not_report_deletions():
    r = result(**{"/m/a.txt": ("aa", 1.0)})
    r.limit_reached = True
    st = by_status(compare(BASE, r))
    assert st["/m/b.txt"] == st["/m/sub/c.txt"] == "INACCESSIBLE"


def test_new_unreadable_file():
    r = result(**{"/m/a.txt": ("aa", 1.0), "/m/b.txt": ("bb", 2.0), "/m/sub/c.txt": ("cc", 3.0)})
    r.errors["/m/locked.txt"] = "permission denied"
    assert by_status(compare(BASE, r))["/m/locked.txt"] == "INACCESSIBLE"


def test_empty_baseline_everything_new():
    r = result(**{"/m/a.txt": ("aa", 1.0)})
    assert by_status(compare({}, r)) == {"/m/a.txt": "NEW"}
