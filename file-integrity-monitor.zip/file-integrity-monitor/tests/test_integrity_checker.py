"""End-to-end integrity scans on a real temporary folder."""

from __future__ import annotations

import os
import shutil

from conftest import p


def statuses(rep):
    return {c.path: c.status for c in rep.changes}


def test_no_changes(env):
    rep = env["ic"].run_scan(env["bid"])
    assert rep.counts["UNCHANGED"] == 4 and rep.alerts.created == []


def test_modification_detected(env):
    (env["folder"] / "users.txt").write_text("alice\nbob\nmallory\n")
    rep = env["ic"].run_scan(env["bid"])
    ch = next(c for c in rep.changes if c.path == p(env["folder"], "users.txt"))
    assert ch.status == "MODIFIED" and ch.baseline_hash != ch.current_hash and len(ch.current_hash) == 64
    assert rep.counts["MODIFIED"] == 1 and len(rep.alerts.created) == 1


def test_deletion_detected(env):
    (env["folder"] / "docs" / "report.txt").unlink()
    rep = env["ic"].run_scan(env["bid"])
    assert statuses(rep)[p(env["folder"], "docs/report.txt")] == "DELETED"


def test_new_file_detected(env):
    (env["folder"] / "docs" / "new.txt").write_text("new")
    rep = env["ic"].run_scan(env["bid"])
    assert statuses(rep)[p(env["folder"], "docs/new.txt")] == "NEW"


def test_multiple_changes_one_scan(env):
    f = env["folder"]
    (f / "config.txt").write_text("listen_port = 22\n")
    (f / "logs" / "app.log").write_text("started\nstopped\n")
    (f / "users.txt").unlink()
    (f / "tool.sh").write_text("echo hi\n")
    rep = env["ic"].run_scan(env["bid"])
    c = rep.counts
    assert (c["MODIFIED"], c["DELETED"], c["NEW"], c["UNCHANGED"]) == (2, 1, 1, 1)


def test_deleted_directory_reports_its_files(env):
    shutil.rmtree(env["folder"] / "logs")
    rep = env["ic"].run_scan(env["bid"])
    assert statuses(rep)[p(env["folder"], "logs/app.log")] == "DELETED"


def test_unreadable_file_is_warning_not_deletion(env, monkeypatch):
    import core.hash_engine as H

    real = H._open_readonly

    def deny(path):
        if path.endswith("users.txt"):
            raise PermissionError(13, "denied")
        return real(path)
    monkeypatch.setattr(H, "_open_readonly", deny)
    rep = env["ic"].run_scan(env["bid"])
    assert statuses(rep)[p(env["folder"], "users.txt")] == "INACCESSIBLE" and rep.counts["DELETED"] == 0
    a = env["ic"].alerts.list(env["bid"]).iloc[0]
    assert a["event_type"] == "INACCESSIBLE" and a["severity"] == "WARNING"


def test_scan_is_stored(env):
    (env["folder"] / "config.txt").write_text("x")
    rep = env["ic"].run_scan(env["bid"])
    row = env["ic"].latest_scan(env["bid"])
    assert row["scan_id"] == rep.scan_id and row["modified_count"] == 1 and row["total_files"] == 4
    files = env["ic"].scan_files(rep.scan_id)
    assert len(files) == 4 and set(files["status"]) == {"MODIFIED", "UNCHANGED"}


def test_scan_does_not_modify_monitored_files(env):
    snap = {f: (f.read_bytes(), os.stat(f).st_mtime_ns) for f in env["folder"].rglob("*") if f.is_file()}
    env["ic"].run_scan(env["bid"])
    assert snap == {f: (f.read_bytes(), os.stat(f).st_mtime_ns) for f in env["folder"].rglob("*") if f.is_file()}


def test_monitored_directory_removed(env):
    shutil.rmtree(env["folder"])
    rep = env["ic"].run_scan(env["bid"])
    assert rep.counts["DELETED"] == 4


def test_single_file_check(env):
    f = env["folder"] / "config.txt"
    f.write_text("listen_port = 9999\n")
    ch, outcome = env["ic"].check_single_file(env["bid"], str(f))
    assert ch.status == "MODIFIED" and len(outcome.created) == 1
    ch, _ = env["ic"].check_single_file(env["bid"], str(env["folder"] / "draft.tmp"))
    assert ch is None                                  # excluded pattern, not in baseline -> ignored
