"""SHA-256 hashing engine."""

from __future__ import annotations

import hashlib
import os

import pytest

import core.hash_engine as H
from conftest import IS_ROOT
from core.hash_engine import calculate_sha256, hash_file, hash_path

EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


def test_known_value():
    assert H.sha256_bytes(b"abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"


def test_file_hash_matches_hashlib(tmp_path):
    f = tmp_path / "a.txt"
    f.write_bytes(b"hello world\n")
    rec = hash_file(f)
    assert rec.ok and rec.sha256 == hashlib.sha256(b"hello world\n").hexdigest() == calculate_sha256(f)
    assert rec.size == 12 and rec.mtime == pytest.approx(os.stat(f).st_mtime) and rec.path == str(f)


def test_same_content_same_hash(tmp_path):
    (tmp_path / "a").write_text("same")
    (tmp_path / "b").write_text("same")
    assert hash_file(tmp_path / "a").sha256 == hash_file(tmp_path / "b").sha256


def test_different_content_different_hash(tmp_path):
    (tmp_path / "a").write_text("port = 8080")
    (tmp_path / "b").write_text("port = 8081")          # one character differs
    assert hash_file(tmp_path / "a").sha256 != hash_file(tmp_path / "b").sha256


def test_empty_file(tmp_path):
    (tmp_path / "empty").write_bytes(b"")
    rec = hash_file(tmp_path / "empty")
    assert rec.ok and rec.sha256 == EMPTY_SHA256 and rec.size == 0


def test_large_file_is_hashed_in_chunks(tmp_path, monkeypatch):
    f = tmp_path / "big.bin"
    block = os.urandom(1024 * 1024)
    with open(f, "wb") as fh:
        for _ in range(25):                               # 25 MiB
            fh.write(block)
    expected = hashlib.sha256(block * 25).hexdigest()
    sizes = []
    real_read = os.read

    def spy(fd, n):
        sizes.append(n)
        return real_read(fd, n)
    monkeypatch.setattr(H.os, "read", spy)
    rec = hash_file(f)
    assert rec.sha256 == expected and rec.size == 25 * 1024 * 1024
    assert max(sizes) == H.C.HASH_CHUNK_SIZE and len(sizes) >= 25      # never one huge read


def test_missing_file(tmp_path):
    rec = hash_file(tmp_path / "nope.txt")
    assert not rec.ok and rec.error == H.ERR_MISSING and rec.sha256 is None


def test_permission_error_mocked(tmp_path, monkeypatch):
    f = tmp_path / "secret.txt"
    f.write_text("x")

    def deny(*a, **k):
        raise PermissionError(13, "Permission denied")
    monkeypatch.setattr(H, "_open_readonly", deny)
    assert hash_file(f).error == H.ERR_PERMISSION


@pytest.mark.skipif(IS_ROOT or os.name == "nt", reason="root can read mode-000 files")
def test_permission_error_real(tmp_path):
    f = tmp_path / "secret.txt"
    f.write_text("x")
    f.chmod(0)
    try:
        assert hash_file(f).error == H.ERR_PERMISSION
    finally:
        f.chmod(0o600)


@pytest.mark.skipif(os.name == "nt", reason="symlinks need extra rights on Windows")
def test_symlink_not_followed_by_default(tmp_path):
    target = tmp_path / "target.txt"
    target.write_text("data")
    link = tmp_path / "link.txt"
    link.symlink_to(target)
    assert hash_file(link).error == H.ERR_SYMLINK
    assert hash_file(link, follow_symlinks=True).sha256 == hash_file(target).sha256


@pytest.mark.skipif(not hasattr(os, "mkfifo"), reason="FIFOs are POSIX only")
def test_fifo_is_not_opened(tmp_path):
    fifo = tmp_path / "pipe"
    os.mkfifo(fifo)
    assert hash_file(fifo).error == H.ERR_NOT_REGULAR             # returns immediately, does not block


def test_directory_is_not_a_regular_file(tmp_path):
    assert hash_file(tmp_path).error == H.ERR_NOT_REGULAR


def test_file_changing_during_hashing_is_rehashed(tmp_path, monkeypatch):
    f = tmp_path / "growing.log"
    f.write_text("line 1\n")
    real = H._hash_fd
    calls = {"n": 0}

    def changing(fd, chunk):
        calls["n"] += 1
        digest = real(fd, chunk)
        if calls["n"] == 1:                                   # another program writes while we hash
            with open(f, "a") as fh:
                fh.write("line 2\n")
            os.utime(f, ns=(os.stat(f).st_atime_ns, os.stat(f).st_mtime_ns + 1_000_000))
        return digest
    monkeypatch.setattr(H, "_hash_fd", changing)
    rec = hash_file(f)
    assert rec.ok and rec.attempts == 2
    assert rec.sha256 == hashlib.sha256(b"line 1\nline 2\n").hexdigest()      # hash of the final, stable content


def test_file_that_never_stabilises(tmp_path, monkeypatch):
    f = tmp_path / "busy.log"
    f.write_text("x")
    real = H._hash_fd

    def always_changing(fd, chunk):
        digest = real(fd, chunk)
        with open(f, "a") as fh:
            fh.write("x")
        return digest
    monkeypatch.setattr(H, "_hash_fd", always_changing)
    rec = hash_file(f, retries=3)
    assert rec.error == H.ERR_UNSTABLE and rec.attempts == 3 and rec.sha256 is None


def test_file_deleted_during_hashing(tmp_path, monkeypatch):
    f = tmp_path / "temp.txt"
    f.write_text("x")
    real = H._hash_fd

    def delete_meanwhile(fd, chunk):
        digest = real(fd, chunk)
        f.unlink()
        return digest
    monkeypatch.setattr(H, "_hash_fd", delete_meanwhile)
    assert hash_file(f).error == H.ERR_MISSING


def test_hashing_does_not_modify_the_file(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("content")
    before = (f.read_bytes(), os.stat(f).st_mtime_ns, os.stat(f).st_size)
    hash_file(f)
    assert before == (f.read_bytes(), os.stat(f).st_mtime_ns, os.stat(f).st_size)


def test_hash_path_accepts_file_or_directory(tmp_path):
    (tmp_path / "a").write_text("1")
    (tmp_path / "b").write_text("2")
    assert len(hash_path(tmp_path)) == 2 and len(hash_path(tmp_path / "a")) == 1
