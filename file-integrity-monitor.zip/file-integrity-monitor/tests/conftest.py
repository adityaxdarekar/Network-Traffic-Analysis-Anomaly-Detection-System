"""Shared fixtures. Every test works in temporary directories with synthetic files - never on real user files."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config as C  # noqa: E402
from core.baseline_manager import BaselineManager  # noqa: E402
from core.integrity_checker import IntegrityChecker  # noqa: E402
from database.db_manager import DatabaseManager  # noqa: E402

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0


@pytest.fixture
def settings():
    return C.default_settings()


@pytest.fixture
def db(tmp_path):
    return DatabaseManager(tmp_path / "fim.db")


@pytest.fixture
def folder(tmp_path) -> Path:
    """A small synthetic monitored folder."""
    d = tmp_path / "monitored"
    (d / "logs").mkdir(parents=True)
    (d / "docs").mkdir()
    (d / "config.txt").write_text("listen_port = 8080\n")
    (d / "users.txt").write_text("alice\nbob\n")
    (d / "logs" / "app.log").write_text("started\n")
    (d / "docs" / "report.txt").write_text("quarterly report\n")
    return d


@pytest.fixture
def env(db, folder, settings):
    """Database + folder + an active baseline of the folder."""
    bm = BaselineManager(db)
    bid = bm.create_baseline([str(folder)], settings)["baseline_id"]
    return {"db": db, "folder": folder, "bm": bm, "ic": IntegrityChecker(db, settings), "bid": bid,
            "settings": settings}


def p(folder: Path, rel: str) -> str:
    return os.path.abspath(str(folder / rel))
