"""Directory scanning and path validation."""

from __future__ import annotations

import os

import pytest

from conftest import IS_ROOT, p
from core.file_scanner import PathValidationError, ScanOptions, is_eligible, scan, validate_directory


def opts(*dirs, **kw):
    return ScanOptions(directories=[str(d) for d in dirs], **kw)


def test_recursive_scan(folder):
    res = scan(opts(folder))
    assert set(res.records) == {p(folder, x) for x in ("config.txt", "users.txt", "logs/app.log", "docs/report.txt")}
    assert res.errors == {} and not res.limit_reached


def test_extension_filter(folder):
    res = scan(opts(folder, extensions=["log"]))
    assert list(res.records) == [p(folder, "logs/app.log")]


def test_excluded_dirs_and_files(folder):
    (folder / ".git").mkdir()
    (folder / ".git" / "HEAD").write_text("ref")
    (folder / "draft.tmp").write_text("t")
    res = scan(opts(folder, exclude_dirs=[".git", "logs"], exclude_files=["*.tmp"]))
    assert p(folder, ".git/HEAD") not in res.records and p(folder, "logs/app.log") not in res.records
    assert p(folder, "draft.tmp") not in res.records and res.excluded == 3


@pytest.mark.skipif(os.name == "nt", reason="symlinks need extra rights on Windows")
def test_symlinks_not_followed(folder, tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.txt").write_text("s")
    os.symlink(outside, folder / "linked_dir")
    os.symlink(folder / "config.txt", folder / "config_link.txt")
    res = scan(opts(folder))
    assert not any("secret.txt" in k for k in res.records)
    assert res.skipped[p(folder, "linked_dir")] == res.skipped[p(folder, "config_link.txt")] == \
        "symbolic link (not followed)"


def test_duplicate_scanning_avoided(folder):
    res = scan(opts(folder, folder / "logs", folder))       # overlapping and repeated selections
    assert len(res.records) == 4 and res.duplicates >= 1


@pytest.mark.skipif(os.name == "nt", reason="hard links behave differently on Windows")
def test_hard_link_hashed_once(folder):
    os.link(folder / "users.txt", folder / "users_hardlink.txt")
    assert len(scan(opts(folder)).records) == 4


def test_max_file_size_skips(folder):
    (folder / "big.bin").write_bytes(b"x" * 3 * 1024 * 1024)
    res = scan(opts(folder, max_file_size_mb=1))
    assert p(folder, "big.bin") not in res.records and "larger than 1 MB" in res.skipped[p(folder, "big.bin")]


def test_max_files_limit(folder):
    res = scan(opts(folder, max_files=2))
    assert len(res.records) == 2 and res.limit_reached


def test_progress_callback(folder):
    seen = []
    scan(opts(folder), progress=lambda f, e, cur: seen.append((f, cur)))
    assert seen[-1] == (4, "done")


def test_unreadable_directory_recorded(folder, monkeypatch):
    real = os.scandir

    def fake(path):
        if str(path) == p(folder, "logs"):
            raise PermissionError(13, "denied")
        return real(path)
    monkeypatch.setattr("core.file_scanner.os.scandir", fake)
    res = scan(opts(folder))
    assert p(folder, "logs") in res.error_dirs and "permission denied" in res.errors[p(folder, "logs")]
    assert len(res.records) == 3


@pytest.mark.skipif(IS_ROOT or os.name == "nt", reason="root can read every directory")
def test_unreadable_directory_real(folder):
    (folder / "logs").chmod(0)
    try:
        assert p(folder, "logs") in scan(opts(folder)).error_dirs
    finally:
        (folder / "logs").chmod(0o755)


@pytest.mark.parametrize("raw,msg", [("", "enter a directory"), ("   ", "enter a directory"),
                                     ("/definitely/not/here", "does not exist"), ("/", "system location"),
                                     ("/proc/1", "virtual file system"), ("/usr", "system location")])
@pytest.mark.skipif(os.name == "nt", reason="POSIX paths")
def test_invalid_directories(raw, msg):
    with pytest.raises(PathValidationError, match=msg):
        validate_directory(raw)


def test_file_is_not_a_directory(folder):
    with pytest.raises(PathValidationError, match="is a file"):
        validate_directory(str(folder / "config.txt"))


@pytest.mark.skipif(os.name == "nt", reason="symlinks need extra rights on Windows")
def test_symlinked_directory_rejected(folder, tmp_path):
    os.symlink(folder, tmp_path / "alias")
    with pytest.raises(PathValidationError, match="symbolic link"):
        validate_directory(str(tmp_path / "alias"))


def test_valid_directory_normalised(folder):
    assert validate_directory(f"  {folder}{os.sep}docs{os.sep}..{os.sep}  ") == os.path.abspath(str(folder))


def test_is_eligible(folder):
    o = opts(folder, exclude_dirs=["logs"], exclude_files=["*.tmp"])
    assert is_eligible(p(folder, "new.txt"), o) and not is_eligible(p(folder, "x.tmp"), o)
    assert not is_eligible(p(folder, "logs/new.log"), o) and not is_eligible("/elsewhere/file.txt", o)
