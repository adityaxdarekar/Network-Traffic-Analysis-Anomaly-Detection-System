"""PDF/CSV/JSON reports and the synthetic sample environment (including its safety guard)."""

from __future__ import annotations

import csv
import io
import os
import re

import pytest

import config as C
from core.baseline_manager import BaselineManager
from core.integrity_checker import IntegrityChecker
from reports.export_manager import alerts_csv, comparison_csv, inventory, inventory_csv
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report
from samples import sample_environment as S


@pytest.fixture
def sample(tmp_path, monkeypatch):
    """Point the sample environment at a temporary copy - the project's own sample folder is untouched."""
    monkeypatch.setattr(C, "SAMPLES_DIR", tmp_path / "samples")
    monkeypatch.setattr(C, "SAMPLE_FOLDER", tmp_path / "samples" / "monitored_folder")
    S.reset_sample()
    return C.SAMPLE_FOLDER


def test_sample_reset_creates_the_documented_files(sample):
    files = sorted(os.path.relpath(f, sample).replace(os.sep, "/") for f in sample.rglob("*") if f.is_file())
    assert files == ["config.txt", "documents/report.txt", "logs/application.log", "system_settings.txt", "users.txt"]
    assert all("SIMULATED DATA" in f.read_text() for f in sample.rglob("*") if f.is_file())


@pytest.mark.parametrize("bad", ["../outside.txt", "../../etc/passwd", "/etc/passwd", "documents/../../x.txt"])
def test_simulation_refuses_paths_outside_sample(sample, bad):
    with pytest.raises(S.UnsafeSamplePath):
        S.safe_path(bad)
    with pytest.raises(S.UnsafeSamplePath):
        S.simulate_modification(bad)


def test_five_demo_scenarios(sample, db, settings):
    bid = BaselineManager(db).create_baseline([str(sample)], settings)["baseline_id"]
    ic = IntegrityChecker(db, settings)
    S.simulate_no_change()
    assert ic.run_scan(bid).counts["UNCHANGED"] == 5                      # 4. no changes
    S.simulate_modification()
    assert ic.run_scan(bid).counts["MODIFIED"] == 1                       # 1. modification
    S.simulate_deletion()
    assert ic.run_scan(bid).counts["DELETED"] == 1                        # 2. deletion
    S.simulate_new_file()
    assert ic.run_scan(bid).counts["NEW"] == 2                            # 3. new files
    S.simulate_multiple()
    c = ic.run_scan(bid).counts
    assert c["MODIFIED"] == 4 and c["DELETED"] == 1 and c["NEW"] == 2      # 5. multiple modifications
    sev = ic.alerts.list(bid)["severity"].value_counts().to_dict()
    assert sev == {"HIGH": 4, "MEDIUM": 2, "LOW": 1}
    S.reset_sample()
    rep = ic.run_scan(bid)
    assert rep.counts["UNCHANGED"] == 5 and rep.counts["NEW"] == 0          # back to baseline, alerts cleared
    assert int(ic.alerts.list(bid)["active"].sum()) == 0


def test_pdf_report(sample, db, settings, tmp_path):
    pypdf = pytest.importorskip("pypdf")
    bid = BaselineManager(db).create_baseline([str(sample)], settings, name="Demo")["baseline_id"]
    ic = IntegrityChecker(db, settings)
    S.simulate_modification()
    S.simulate_deletion()
    S.simulate_new_file()
    rep = ic.run_scan(bid)
    path = generate_pdf_report(db, bid, tmp_path / "r.pdf", analyst="Tester")
    text = "\n".join(pg.extract_text() for pg in pypdf.PdfReader(str(path)).pages)
    for needed in ("File Integrity Monitoring Report", "Baseline ID", "Monitored directory", "Summary",
                   "Modified files", "Deleted files", "New files", "Inaccessible", "Security alerts",
                   "Severity distribution", "Recommended investigation steps", "Conclusion", "Tester"):
        assert needed in text, needed
    mod = next(c for c in rep.changes if c.status == "MODIFIED")
    flat = re.sub(r"\s+", "", text)
    assert mod.baseline_hash in flat and mod.current_hash in flat               # previous and current hash
    assert "app_name = ExampleApp" not in text                                  # no file contents


def test_pdf_before_any_scan(sample, db, settings):
    bid = BaselineManager(db).create_baseline([str(sample)], settings)["baseline_id"]
    assert generate_pdf_bytes(db, bid).startswith(b"%PDF")


def test_csv_exports(sample, db, settings):
    bid = BaselineManager(db).create_baseline([str(sample)], settings)["baseline_id"]
    ic = IntegrityChecker(db, settings)
    assert inventory(db, bid)["status"].iloc[0] == "BASELINE (not scanned yet)"
    S.simulate_modification()
    rep = ic.run_scan(bid)
    inv = list(csv.DictReader(io.StringIO(inventory_csv(db, bid))))
    assert len(inv) == 5 and {"file_name", "file_path", "file_size", "current_sha256", "baseline_sha256", "status",
                              "last_modified"} <= set(inv[0])
    cmp_ = list(csv.DictReader(io.StringIO(comparison_csv(db, rep.scan_id))))
    assert sum(r["status"] == "MODIFIED" for r in cmp_) == 1
    al = list(csv.DictReader(io.StringIO(alerts_csv(db, bid))))
    assert len(al) == 1 and al[0]["event_type"] == "MODIFIED"
