"""Baseline creation, confirmation before replacing, history, export."""

from __future__ import annotations

import csv
import io
import json

import pytest

from conftest import p
from core.baseline_manager import BaselineExistsError, BaselineManager, ConfirmationRequired
from core.file_scanner import PathValidationError
from core.hash_engine import hash_file


def test_baseline_creation(db, folder, settings):
    bm = BaselineManager(db)
    res = bm.create_baseline([str(folder)], settings, name="Demo")
    b = bm.get(res["baseline_id"])
    assert b["status"] == "Active" and b["file_count"] == 4 and b["name"] == "Demo" and b["created_at"]
    assert b["directories"] == [str(folder)]
    fm = bm.file_map(res["baseline_id"])
    rec = hash_file(folder / "config.txt")
    assert fm[p(folder, "config.txt")] == {"sha256": rec.sha256, "size": rec.size, "mtime": rec.mtime}


def test_existing_baseline_not_replaced_without_confirmation(env):
    bm, folder = env["bm"], env["folder"]
    with pytest.raises(BaselineExistsError) as exc:
        bm.create_baseline([str(folder)], env["settings"])
    assert exc.value.baseline["baseline_id"] == env["bid"]
    assert len(bm.list()) == 1 and bm.get(env["bid"])["status"] == "Active"


def test_replace_with_confirmation_keeps_old_baseline(env):
    bm = env["bm"]
    (env["folder"] / "config.txt").write_text("changed and approved\n")
    new = bm.create_baseline([str(env["folder"])], env["settings"], confirm_replace=True)
    assert new["replaced"] == env["bid"]
    assert bm.get(env["bid"])["status"] == "Superseded" and bm.get(new["baseline_id"])["status"] == "Active"
    assert bm.file_map(env["bid"])[p(env["folder"], "config.txt")]["sha256"] != \
        bm.file_map(new["baseline_id"])[p(env["folder"], "config.txt")]["sha256"]       # history preserved


def test_different_directories_get_separate_baselines(db, folder, settings):
    bm = BaselineManager(db)
    bm.create_baseline([str(folder)], settings)
    bm.create_baseline([str(folder / "logs")], settings)            # no confirmation needed
    assert list(bm.list()["status"]) == ["Active", "Active"]


def test_delete_requires_confirmation_and_inactive(env):
    bm = env["bm"]
    with pytest.raises(ConfirmationRequired):
        bm.delete_baseline(env["bid"])
    with pytest.raises(ConfirmationRequired, match="active baseline"):
        bm.delete_baseline(env["bid"], confirm=True)
    bm.set_status(env["bid"], "Archived")
    bm.delete_baseline(env["bid"], confirm=True)
    assert bm.get(env["bid"]) is None


def test_invalid_directory_creates_nothing(db, settings, tmp_path):
    bm = BaselineManager(db)
    with pytest.raises(PathValidationError):
        bm.create_baseline([str(tmp_path / "missing")], settings)
    assert bm.list().empty


def test_export_json_and_csv(env):
    data = json.loads(env["bm"].export_json(env["bid"]))
    assert data["hash_algorithm"] == "SHA-256" and len(data["files"]) == 4
    assert all(len(f["sha256"]) == 64 for f in data["files"])
    rows = list(csv.DictReader(io.StringIO(env["bm"].export_csv(env["bid"]))))
    assert len(rows) == 4 and set(rows[0]) == {"baseline_id", "file_path", "sha256", "file_size", "modified_at"}


def test_baseline_stores_no_file_contents(env):
    exported = env["bm"].export_json(env["bid"]) + env["bm"].export_csv(env["bid"])
    assert "listen_port" not in exported and "quarterly report" not in exported


def test_latest_active_and_options(env):
    b = env["bm"].latest_active()
    assert b["baseline_id"] == env["bid"]
    assert env["bm"].options(env["bid"]).directories == [str(env["folder"])]
