"""Alerts: content, severity classification, duplicate prevention, re-alerting, status."""

from __future__ import annotations

import pytest

import config as C
from conftest import p
from core.alert_manager import AlertManager, classify, format_alert


def alerts(env):
    return env["ic"].alerts.list(env["bid"])


def test_alert_contents(env):
    (env["folder"] / "config.txt").write_text("listen_port = 22\n")
    env["ic"].run_scan(env["bid"])
    a = env["ic"].alerts.get(int(alerts(env).iloc[0]["alert_id"]))
    assert a["baseline_id"] == env["bid"] and a["file_path"] == p(env["folder"], "config.txt")
    assert a["event_type"] == "MODIFIED" and a["status"] == "New" and a["created_at"]
    assert len(a["previous_hash"]) == len(a["current_hash"]) == 64 and a["previous_hash"] != a["current_hash"]
    assert a["severity"] == "HIGH"                                       # config file = critical
    assert "does not match the trusted baseline" in a["explanation"] and "not prove" in a["explanation"]
    assert "authorized" in a["recommended_action"]
    text = format_alert(a)
    assert "FILE INTEGRITY ALERT" in text and "Event: FILE MODIFIED" in text and a["current_hash"] in text


@pytest.mark.parametrize("event,path,expected", [("MODIFIED", "/x/app.conf", "HIGH"), ("MODIFIED", "/x/notes.txt",
                                                                                         "MEDIUM"),
                                                 ("DELETED", "/x/notes.txt", "HIGH"), ("NEW", "/x/readme.txt", "LOW"),
                                                 ("NEW", "/x/run.sh", "MEDIUM"), ("INACCESSIBLE", "/x/a", "WARNING")])
def test_default_severity(event, path, expected):
    assert classify(event, path, C.default_settings())[0] == expected


def test_severity_is_configurable(env):
    s = env["settings"]
    s["severity"]["NEW"] = "HIGH"
    s["critical_patterns"] = []
    assert classify("NEW", "/x/readme.txt", s)[0] == "HIGH"
    assert classify("MODIFIED", "/x/app.conf", s)[0] == "MEDIUM"


def test_no_duplicate_alerts_for_unchanged_condition(env):
    (env["folder"] / "users.txt").write_text("changed\n")
    (env["folder"] / "docs" / "report.txt").unlink()
    first = env["ic"].run_scan(env["bid"])
    second = env["ic"].run_scan(env["bid"])
    third = env["ic"].run_scan(env["bid"])
    assert len(first.alerts.created) == 2 and second.alerts.created == third.alerts.created == []
    assert second.alerts.repeated == 2
    df = alerts(env)
    assert len(df) == 2 and set(df["times_seen"]) == {3}


def test_new_alert_when_file_changes_again(env):
    f = env["folder"] / "users.txt"
    f.write_text("version 2\n")
    env["ic"].run_scan(env["bid"])
    f.write_text("version 3\n")
    rep = env["ic"].run_scan(env["bid"])
    assert len(rep.alerts.created) == 1
    df = alerts(env).sort_values("alert_id")
    assert list(df["active"]) == [0, 1] and df.iloc[0]["current_hash"] != df.iloc[1]["current_hash"]


def test_restored_file_clears_alert_and_can_alert_again(env):
    f = env["folder"] / "users.txt"
    original = f.read_text()
    f.write_text("tampered\n")
    env["ic"].run_scan(env["bid"])
    f.write_text(original)                                        # restored to the baseline content
    rep = env["ic"].run_scan(env["bid"])
    assert rep.alerts.cleared == 1 and int(alerts(env)["active"].sum()) == 0
    f.write_text("tampered\n")                                    # the same tampering happens again later
    assert len(env["ic"].run_scan(env["bid"]).alerts.created) == 1


def test_status_updates(env):
    (env["folder"] / "config.txt").write_text("x")
    env["ic"].run_scan(env["bid"])
    am: AlertManager = env["ic"].alerts
    aid = int(alerts(env).iloc[0]["alert_id"])
    for status in C.ALERT_STATUSES:
        am.set_status(aid, status)
        assert am.get(aid)["status"] == status
    with pytest.raises(ValueError):
        am.set_status(aid, "Ignored")


def test_status_kept_on_repeated_scans(env):
    (env["folder"] / "config.txt").write_text("x")
    env["ic"].run_scan(env["bid"])
    aid = int(alerts(env).iloc[0]["alert_id"])
    env["ic"].alerts.set_status(aid, "Investigating")
    env["ic"].run_scan(env["bid"])
    assert env["ic"].alerts.get(aid)["status"] == "Investigating" and len(alerts(env)) == 1


def test_filters_and_sql_injection(env):
    (env["folder"] / "config.txt").write_text("x")
    (env["folder"] / "users.txt").unlink()
    env["ic"].run_scan(env["bid"])
    am = env["ic"].alerts
    assert len(am.list(env["bid"], event_type="DELETED")) == 1 and len(am.list(env["bid"], severity="HIGH")) == 2
    assert len(am.list(env["bid"], search="config")) == 1
    assert am.list(env["bid"], search="' OR 1=1; DROP TABLE security_alerts; --").empty
    assert len(am.list(env["bid"])) == 2
