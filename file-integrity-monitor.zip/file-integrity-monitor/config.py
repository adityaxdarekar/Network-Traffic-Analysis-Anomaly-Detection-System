"""
Configuration for the File Integrity Monitoring System.

Everything that decides WHAT is scanned and HOW SEVERE a change is lives here (DEFAULT_SETTINGS) and can be
changed on the dashboard (saved to user_settings.json). Paths are handled with pathlib/os.path so the
application runs on Linux, macOS and Windows.
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SAMPLES_DIR = BASE_DIR / "samples"
SAMPLE_FOLDER = SAMPLES_DIR / "monitored_folder"        # the ONLY folder the simulation buttons may change
OUTPUT_DIR = BASE_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
DB_PATH = OUTPUT_DIR / "fim.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"
STYLE_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "File Integrity Monitoring System"
APP_SUBTITLE = "Python and SHA-256 Hashing"
APP_VERSION = "1.0.0"

HASH_CHUNK_SIZE = 1024 * 1024        # 1 MiB chunks: large files never load fully into memory
HASH_RETRIES = 3                      # re-hash attempts when a file changes while it is being hashed

# Directories that must never be monitored as a whole (the whole OS, virtual file systems).
PROTECTED_ROOTS_POSIX = ["/", "/proc", "/sys", "/dev", "/run", "/boot", "/usr", "/var", "/lib", "/lib64", "/bin",
                         "/sbin", "/snap"]
PROTECTED_ROOTS_WINDOWS = ["C:\\", "C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)",
                           "C:\\ProgramData"]

EVENT_TYPES = ["MODIFIED", "DELETED", "NEW", "INACCESSIBLE"]
EVENT_LABELS = {"MODIFIED": "FILE MODIFIED", "DELETED": "FILE DELETED", "NEW": "NEW FILE DETECTED",
                "INACCESSIBLE": "FILE INACCESSIBLE"}
SEVERITIES = ["INFO", "WARNING", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
SEVERITY_COLORS = {"INFO": "#64748b", "WARNING": "#a78bfa", "LOW": "#22c55e", "MEDIUM": "#f59e0b",
                   "HIGH": "#ef4444", "CRITICAL": "#b91c1c"}
ALERT_STATUSES = ["New", "Investigating", "Resolved", "False Positive"]

DEFAULT_SETTINGS = {
    "scan": {
        "extensions": [],                       # empty = all files; e.g. [".txt", ".conf"]
        "exclude_dirs": [".git", "__pycache__", "node_modules", ".venv", "venv", "env", ".cache", ".tox",
                         ".mypy_cache", ".pytest_cache", "tmp", "temp", ".Trash*", "$RECYCLE.BIN",
                         "System Volume Information"],
        "exclude_files": ["*.tmp", "*.temp", "*.swp", "*.swx", "*~", ".DS_Store", "Thumbs.db", "desktop.ini",
                          "*.part", "*.crdownload", "~$*", ".~lock.*"],
        "follow_symlinks": False,
        "max_file_size_mb": 100,                # larger files are skipped (reported, never "deleted")
        "max_files": 50000,                     # safety limit per scan
    },
    "severity": {
        "MODIFIED_CRITICAL": "HIGH",            # modified file that matches critical_patterns
        "MODIFIED": "MEDIUM",
        "DELETED": "HIGH",
        "NEW": "LOW",
        "NEW_EXECUTABLE": "MEDIUM",             # new script / executable
        "INACCESSIBLE": "WARNING",
    },
    "critical_patterns": ["*.conf", "*.cfg", "*.ini", "*.yaml", "*.yml", "*.json", "*.xml", "*.env", ".env",
                          "*config*", "*settings*", "users*", "passwd", "shadow", "group", "sudoers", "hosts",
                          "*.key", "*.pem", "*.crt", "authorized_keys", "*.service"],
    "executable_patterns": ["*.exe", "*.dll", "*.so", "*.sh", "*.bat", "*.cmd", "*.ps1", "*.py", "*.js", "*.vbs",
                            "*.jar", "*.elf", "*.bin", "*.msi", "*.php"],
    "realtime": {"debounce_seconds": 1.5, "use_polling": False, "polling_interval": 2.0},
}


def default_settings() -> dict:
    return copy.deepcopy(DEFAULT_SETTINGS)


def _merge(base: dict, new: dict) -> dict:
    for k, v in new.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _merge(base[k], v)
        elif k in base:
            base[k] = v
    return base


def load_settings(path: Path | None = None) -> dict:
    settings = default_settings()
    try:
        data = json.loads(Path(path or SETTINGS_FILE).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            _merge(settings, data)
    except (OSError, ValueError):
        pass
    return settings


def save_settings(settings: dict, path: Path | None = None) -> None:
    Path(path or SETTINGS_FILE).write_text(json.dumps(settings, indent=2), encoding="utf-8")


def protected_roots() -> list[str]:
    return PROTECTED_ROOTS_WINDOWS if os.name == "nt" else PROTECTED_ROOTS_POSIX
