# Screenshots

Included (rendered from the real sample PDF report):
- `report_page_1.png`, `report_page_2.png`, `report_page_3.png`: pages 1–3 of
  `sample_output/integrity_report_sample.pdf`

Dashboard screenshots could not be taken in the development environment (Streamlit was not installable
there). Add them after running `./run.sh`, following `documentation/DEMO_GUIDE.md`. Suggested names:

| File | Page / moment |
|---|---|
| 01_overview.png | Overview Dashboard after scenario 5 |
| 02_create_baseline.png | Baseline #1 created (5 files with hashes) |
| 03_replace_confirmation.png | warning + confirmation checkbox when creating a second baseline |
| 04_scan_modified.png | File Scanner after "Modify config.txt" |
| 05_scan_all_changes.png | File Scanner after scenario 5 |
| 06_alerts.png | Alerts page with the 7 alerts |
| 07_alert_detail.png | FILE INTEGRITY ALERT text of alert #1 |
| 08_realtime.png | Real-Time Monitoring with a live event |
| 09_explorer.png | File Explorer filtered to MODIFIED |
| 10_reports.png | Reports page |
| 11_settings.png | Settings (severity rules) |
| 12_about_sha256.png | About page SHA-256 demo |
