#!/usr/bin/env bash
# One-time setup on Linux / macOS: virtual environment + dependencies.
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv venv || { echo "Install python3-venv first:  sudo apt install -y python3-venv python3-pip"; exit 1; }
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
./venv/bin/python samples/sample_environment.py reset
echo; echo "Done.  Dashboard: ./run.sh    Tests: ./venv/bin/python -m pytest -v"
