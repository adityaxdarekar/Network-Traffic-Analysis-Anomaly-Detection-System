"""Page 8: About Project."""

from __future__ import annotations

import hashlib

import streamlit as st

import config as C
from dashboard.common import page_header

ARCH = """
 Selected folders ──► file_scanner  (validated paths, recursive, filters, no symlinks, no duplicates)
                         │
                         ▼
                    hash_engine   SHA-256, binary 1 MiB chunks, read-only, re-hash if the file changes meanwhile
                         │
         ┌───────────────┴────────────────┐
         ▼                                ▼
 baseline_manager                  integrity_checker ──► change_detector  MODIFIED / DELETED / NEW / INACCESSIBLE
 trusted hashes (SQLite)                 │
                                         ▼
                                  alert_manager  severity · explanation · no duplicates · status
                                         │
 realtime_monitor (watchdog, debounced) ─┘
                                         ▼
                      SQLite · Streamlit dashboard · PDF / CSV / JSON reports
"""


def render() -> None:
    page_header("About Project", f"{C.APP_TITLE} using {C.APP_SUBTITLE}")
    st.markdown("""
**Introduction.** File Integrity Monitoring (FIM) detects unexpected changes to important files - configuration
files, user lists, scripts - by comparing their current cryptographic fingerprint with a trusted baseline.

**Objectives:** hash files with SHA-256 · store a trusted baseline · rescan periodically or in real time · detect
modified, deleted, new and unreadable files · raise explained alerts · keep an alert history · produce reports.

**Technology:** Python · hashlib (SHA-256) · pathlib/os · watchdog · Streamlit · pandas · Plotly · SQLite · ReportLab ·
pytest
""")
    st.code(ARCH, language=None)
    st.subheader("How SHA-256 works")
    st.markdown("SHA-256 turns any amount of data into a fixed 256-bit (64 hex character) fingerprint. The same input "
                "always gives the same hash; changing even one character gives a completely different hash "
                "(the *avalanche effect*), and it is computationally infeasible to find a different file with the "
                "same hash. That is why comparing hashes reveals any content change.")
    text = st.text_input("Try it - type something:", "port = 8080", key="ab_text")
    st.code(f"SHA-256(\"{text}\") = {hashlib.sha256(text.encode()).hexdigest()}", language=None)
    st.subheader("How file integrity monitoring works")
    st.markdown("""
1. **Baseline** - hash every file in the chosen folders while they are known to be good and store the hashes.
2. **Rescan** - hash the files again (manually, periodically or on file-system events).
3. **Compare** - different hash → *modified*; missing → *deleted*; unknown path → *new*; unreadable → *inaccessible*
   (never assumed deleted).
4. **Alert** - record what changed, the previous and current hash, a severity and a recommended action.
5. **Investigate** - decide whether the change was authorised; if so, create a new baseline (explicit, confirmed).
""")
    st.subheader("Limitations")
    st.markdown("""
- FIM shows **that** a file changed, not **who** changed it or **why**; combine it with system logs.
- An attacker with full control of the system could also change the baseline database - production FIM stores
  baselines on a separate, protected system.
- Real-time events depend on the operating system; very fast successive changes are merged by debouncing.
- Files above the size limit, symbolic links and excluded patterns are not verified.
- Changes in file permissions or ownership alone (same content) are not reported.
""")
    st.info("The monitor is read-only: it never modifies, repairs, deletes or executes monitored files, and sends "
            "nothing to external services.")
