"""Settings page: severity rules, critical/executable patterns, default scan options."""

from __future__ import annotations

import streamlit as st

import config as C
from dashboard.common import get_settings, page_header

LABELS = {"MODIFIED_CRITICAL": "Modified critical / configuration file", "MODIFIED": "Modified ordinary file",
          "DELETED": "Deleted monitored file", "NEW": "Newly created file",
          "NEW_EXECUTABLE": "New script or executable", "INACCESSIBLE": "Inaccessible file"}


def render() -> None:
    page_header("Settings", "Risk classification and default scan options")
    s = get_settings()
    st.subheader("Severity of each event")
    st.caption("Modifications are not necessarily malicious - legitimate updates and authorised edits also trigger "
               "alerts. Adjust the severities to your environment. Changes apply to new alerts.")
    new_sev = {}
    cols = st.columns(3)
    for i, (k, label) in enumerate(LABELS.items()):
        new_sev[k] = cols[i % 3].selectbox(label, C.SEVERITIES, index=C.SEVERITIES.index(s["severity"][k]),
                                           key=f"st_sev_{k}")
    crit = st.text_area("Critical file patterns (a modification is 'critical')", "\n".join(s["critical_patterns"]),
                        key="st_crit", height=110)
    exe = st.text_area("Executable / script patterns (a new one gets the 'new executable' severity)",
                       "\n".join(s["executable_patterns"]), key="st_exe", height=90)
    st.subheader("Default scan options")
    c1, c2 = st.columns(2)
    max_files = c1.number_input("Maximum files per scan", 100, 1_000_000, int(s["scan"]["max_files"]), key="st_maxf")
    max_mb = c2.number_input("Maximum file size (MB)", 1, 10000, int(s["scan"]["max_file_size_mb"]), key="st_maxmb")
    b1, b2 = st.columns(2)
    if b1.button("💾 Save settings", type="primary", key="st_save"):
        s["severity"] = new_sev
        s["critical_patterns"] = [x.strip() for x in crit.splitlines() if x.strip()]
        s["executable_patterns"] = [x.strip() for x in exe.splitlines() if x.strip()]
        s["scan"]["max_files"], s["scan"]["max_file_size_mb"] = int(max_files), float(max_mb)
        try:
            C.save_settings(s)
            st.success("Settings saved.")
        except OSError:
            st.warning("Settings apply to this session only (user_settings.json could not be written).")
    if b2.button("↺ Reset to defaults", key="st_reset"):
        st.session_state["settings"] = C.default_settings()
        for k in [k for k in st.session_state if k.startswith("st_")]:
            del st.session_state[k]
        st.rerun()
