"""Page 5: File Explorer - every monitored file with its baseline and current hash."""

from __future__ import annotations

import streamlit as st

from dashboard.common import db_or_warn, kpi_row, page_header, require_baseline, show_table
from reports.export_manager import inventory


def render() -> None:
    page_header("File Explorer", "Monitored files, hashes and integrity status")
    db = db_or_warn()
    if db is None:
        return
    b = require_baseline()
    df = inventory(db, b["baseline_id"])
    scan = df.attrs.get("scan")
    st.caption(f"Status from scan #{scan['scan_id']} at {scan['scanned_at']}" if scan else
               "No scan yet - showing the baseline. Run a scan on the File Scanner page to see current hashes.")
    vc = df["status"].value_counts().to_dict() if not df.empty else {}
    kpi_row([("Files", len(df)), ("Unchanged", vc.get("UNCHANGED", 0)), ("Modified", vc.get("MODIFIED", 0)),
             ("Deleted", vc.get("DELETED", 0)), ("New", vc.get("NEW", 0))])
    c1, c2 = st.columns([2, 1])
    q = c1.text_input("Search file name or path", key="fx_q")
    statuses = c2.multiselect("Status", sorted(df["status"].unique()) if not df.empty else [], key="fx_status")
    view = df
    if q:
        view = view[view["file_path"].str.contains(q, case=False, regex=False)]
    if statuses:
        view = view[view["status"].isin(statuses)]
    st.markdown(f"**{len(view)}** of {len(df)} files")
    show_table(view, height=440, empty_msg="No files match.")
    st.caption("Only metadata and hashes are shown - file contents are never read into the dashboard.")
