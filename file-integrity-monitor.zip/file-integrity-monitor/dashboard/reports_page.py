"""Page 7: Reports - PDF, CSV and JSON downloads."""

from __future__ import annotations

import streamlit as st

from core.baseline_manager import BaselineManager
from core.integrity_checker import IntegrityChecker
from dashboard.common import db_or_warn, download, page_header, require_baseline
from reports.export_manager import alerts_csv, comparison_csv, inventory_csv, stamp
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report


def render() -> None:
    page_header("Reports", "Integrity reports and data exports (metadata and hashes only)")
    db = db_or_warn()
    if db is None:
        return
    b = require_baseline()
    bid = b["baseline_id"]
    latest = IntegrityChecker(db).latest_scan(bid)
    st.subheader("📄 PDF integrity monitoring report")
    analyst = st.text_input("Prepared by (optional)", key="rep_analyst")
    c1, c2 = st.columns(2)
    with c1:
        download("⬇ Download PDF report", generate_pdf_bytes(db, bid, analyst), stamp("integrity_report", "pdf", bid),
                 "application/pdf", "rep_pdf", primary=True)
    with c2:
        if st.button("💾 Save PDF to output/reports", key="rep_save", width="stretch"):
            st.success(f"Saved to {generate_pdf_report(db, bid, analyst=analyst)}")
    st.caption("Includes baseline and scope, scan results, modified/deleted/new/inaccessible files with previous and "
               "current SHA-256, alerts with severity distribution, investigation steps and conclusion.")
    st.subheader("⬇ Data exports")
    c1, c2 = st.columns(2)
    with c1:
        download("File inventory (CSV)", inventory_csv(db, bid).encode(), stamp("file_inventory", "csv", bid),
                 "text/csv", "rep_inv")
        download("Security alerts (CSV)", alerts_csv(db, bid).encode(), stamp("security_alerts", "csv", bid),
                 "text/csv", "rep_alerts")
    with c2:
        if latest:
            download(f"Hash comparison of scan #{latest['scan_id']} (CSV)",
                     comparison_csv(db, latest["scan_id"]).encode(), stamp("hash_comparison", "csv", bid), "text/csv",
                     "rep_cmp")
        else:
            st.caption("Hash comparison: run a scan first.")
        download("Baseline (JSON)", BaselineManager(db).export_json(bid).encode(), stamp("baseline", "json", bid),
                 "application/json", "rep_json")
