"""Page 3: File Scanner - manual integrity scan against a baseline, plus sample simulations."""

from __future__ import annotations

import streamlit as st

import config as C
from core.integrity_checker import IntegrityChecker
from dashboard.common import db_or_warn, kpi_row, page_header, require_baseline, show_table
from samples import sample_environment as S

COLS = ["path", "status", "baseline_hash", "current_hash", "baseline_size", "current_size", "detail"]
SIMULATIONS = [("✏️ Modify config.txt", S.simulate_modification), ("🗑 Delete documents/report.txt", S.simulate_deletion),
               ("➕ Create new files", S.simulate_new_file), ("✏️✏️ Modify several files", S.simulate_multiple),
               ("∅ No changes", S.simulate_no_change), ("↺ Reset sample folder", S.reset_sample)]


def render() -> None:
    page_header("File Scanner", "Compare current SHA-256 hashes with the trusted baseline")
    db = db_or_warn()
    if db is None:
        return
    b = require_baseline()
    st.markdown(f"**Baseline #{b['baseline_id']}** · {b['name']} · {b['file_count']} files · " +
                "; ".join(f"`{d}`" for d in b["directories"]))

    if any(str(C.SAMPLE_FOLDER) == d for d in b["directories"]):
        with st.expander("🧪 Simulate changes in the synthetic sample folder (simulated data only)", expanded=True):
            st.caption("These buttons only ever touch files inside samples/monitored_folder.")
            cols = st.columns(3)
            for i, (label, fn) in enumerate(SIMULATIONS):
                if cols[i % 3].button(label, key=f"sim_{i}", width="stretch"):
                    out = fn()
                    st.info(out if isinstance(out, str) else "Sample folder restored to its original files.")

    if st.button("🔍 Run integrity scan", type="primary", key="scan_go"):
        status = st.empty()

        def progress(files, errors, current):
            status.text(f"Scanning… {files} files hashed, {errors} errors · {current}")

        try:
            st.session_state["report"] = IntegrityChecker(db).run_scan(b["baseline_id"], progress)
        except Exception:  # noqa: BLE001
            st.error("The scan could not be completed. Check that the monitored directories still exist.")

    rep = st.session_state.get("report")
    if rep is None or rep.baseline_id != b["baseline_id"]:
        st.caption("Run a scan to compare the current files with the baseline.")
        return
    c = rep.counts
    st.markdown(f"**Scan #{rep.scan_id}** at {rep.scanned_at} · {rep.scan.files_scanned} files hashed in "
                f"{rep.scan.duration}s")
    kpi_row([("Unchanged", c["UNCHANGED"]), ("Modified", c["MODIFIED"], "", "alert" if c["MODIFIED"] else "accent"),
             ("Deleted", c["DELETED"], "", "alert" if c["DELETED"] else "accent"),
             ("New", c["NEW"], "", "alert" if c["NEW"] else "accent"),
             ("Inaccessible", c["INACCESSIBLE"], "never counted as deleted")])
    o = rep.alerts
    st.caption(f"Alerts: {len(o.created)} new · {o.repeated} unchanged condition(s) already alerted (no duplicates) "
               f"· {o.cleared} cleared because the file returned to its baseline state.")
    if not any(c[k] for k in ("MODIFIED", "DELETED", "NEW", "INACCESSIBLE")):
        st.success("All files match the trusted baseline.")
    tabs = st.tabs(["Modified", "Deleted", "New", "Inaccessible / skipped", "All files"])
    for tab, statuses in zip(tabs, [["MODIFIED"], ["DELETED"], ["NEW"], ["INACCESSIBLE", "SKIPPED"], None]):
        with tab:
            df = rep.frame(statuses)
            show_table(df[COLS] if not df.empty else df, height=320, empty_msg="None.")
