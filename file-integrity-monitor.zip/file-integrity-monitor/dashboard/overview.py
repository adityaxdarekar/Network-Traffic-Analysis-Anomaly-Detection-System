"""Page 1: Overview Dashboard."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

import config as C
from core.integrity_checker import IntegrityChecker
from dashboard.common import bar, db_or_warn, donut, kpi_row, page_header, plotly_layout, require_baseline, show_table
from monitoring.realtime_monitor import get_monitor

STATUS_COLORS = {"UNCHANGED": "#22c55e", "MODIFIED": "#f59e0b", "DELETED": "#ef4444", "NEW": "#3b82f6",
                 "INACCESSIBLE": "#a78bfa", "SKIPPED": "#94a3b8"}


def render() -> None:
    page_header("Overview Dashboard", f"{C.APP_TITLE} - {C.APP_SUBTITLE}")
    db = db_or_warn()
    if db is None:
        return
    b = require_baseline()
    ic = IntegrityChecker(db)
    latest = ic.latest_scan(b["baseline_id"])
    files = ic.scan_files(latest["scan_id"]) if latest else pd.DataFrame()
    counts = files["status"].value_counts().to_dict() if not files.empty else {}
    alerts = ic.alerts.list(b["baseline_id"])
    high = int(alerts["severity"].isin(["HIGH", "CRITICAL"]).sum()) if not alerts.empty else 0
    mon = get_monitor()
    running = mon is not None and mon.running and mon.baseline_id == b["baseline_id"]
    kpi_row([("Monitored files", b["file_count"], "in the baseline"),
             ("Modified", counts.get("MODIFIED", 0), "latest scan", "alert" if counts.get("MODIFIED") else "accent"),
             ("Deleted", counts.get("DELETED", 0), "latest scan", "alert" if counts.get("DELETED") else "accent"),
             ("New files", counts.get("NEW", 0), "latest scan", "alert" if counts.get("NEW") else "accent")])
    kpi_row([("Security alerts", len(alerts), f"{int((alerts['status'] == 'New').sum()) if not alerts.empty else 0}"
                                              " new"),
             ("High severity", high, "", "alert" if high else "accent"),
             ("Last scan", latest["scanned_at"][11:] if latest else "never", latest["scanned_at"][:10] if latest else ""),
             ("Real-time monitoring", "ON" if running else "OFF", mon.mode if running else "", "alert" if running
              else "accent")])
    st.caption(f"Baseline #{b['baseline_id']} · {b['name']} · " + "; ".join(b["directories"]))
    if not latest:
        st.info("No integrity scan yet - open **File Scanner** and run a scan.")
    c1, c2 = st.columns(2)
    with c1:
        donut(list(counts), list(counts.values()), "File integrity status (latest scan)", STATUS_COLORS)
    with c2:
        if alerts.empty:
            donut([], [], "Alerts by event type")
        else:
            vc = alerts["event_type"].value_counts()
            donut([C.EVENT_LABELS[k] for k in vc.index], vc.values, "Alerts by event type",
                  {C.EVENT_LABELS[k]: STATUS_COLORS[k] for k in vc.index})
    c3, c4 = st.columns(2)
    with c3:
        if alerts.empty:
            bar(pd.DataFrame(), "", "", "Alerts over time")
        else:
            t = alerts.assign(minute=pd.to_datetime(alerts["created_at"]).dt.floor("min"))
            g = t.groupby(["minute", "event_type"]).size().reset_index(name="alerts")
            fig = px.bar(g, x="minute", y="alerts", color="event_type", color_discrete_map=STATUS_COLORS)
            st.plotly_chart(plotly_layout(fig, "Alerts over time"), width="stretch")
    with c4:
        if alerts.empty:
            donut([], [], "Severity distribution")
        else:
            vc = alerts["severity"].value_counts()
            donut(vc.index, vc.values, "Severity distribution", C.SEVERITY_COLORS)
    if not alerts.empty:
        top = alerts[alerts["event_type"] == "MODIFIED"]["file_path"].value_counts().head(10)
        bar(pd.DataFrame({"file": [p.replace("\\", "/").rsplit("/", 1)[-1] for p in top.index], "modifications":
                          top.values}), "file", "modifications", "Most frequently modified files", "#f59e0b",
            horizontal=True)
    st.subheader("Recent scans")
    scans = ic.scans(b["baseline_id"])
    show_table(scans.head(10).drop(columns=["baseline_id"]) if not scans.empty else scans, empty_msg="No scans yet.")
    st.markdown("<div class='disclaimer'>A detected change is not proof of an attack - software updates, log "
                "rotation and authorised edits also change files. Verify before acting.</div>",
                unsafe_allow_html=True)
