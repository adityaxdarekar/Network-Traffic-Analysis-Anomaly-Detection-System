"""Page 2: Create Baseline (plus viewing, selecting and exporting baselines)."""

from __future__ import annotations

import streamlit as st

import config as C
from core.baseline_manager import BaselineExistsError, BaselineManager, ConfirmationRequired
from core.file_scanner import PathValidationError
from dashboard.common import db_or_warn, download, get_settings, kpi_row, page_header, show_table
from samples.sample_environment import reset_sample


def _create(bm: BaselineManager, dirs: list, name: str, settings: dict, confirm: bool) -> None:
    status = st.empty()

    def progress(files, errors, current):
        status.text(f"Scanning… {files} files hashed, {errors} errors · {current}")

    result = bm.create_baseline(dirs, settings, name=name, confirm_replace=confirm, progress=progress)
    st.session_state["baseline_id"] = result["baseline_id"]
    st.session_state.pop("pending_replace", None)
    sc = result["scan"]
    st.session_state["baseline_msg"] = (
        f"Baseline #{result['baseline_id']} created: {sc.files_scanned} files hashed in {sc.duration}s, "
        f"{len(sc.errors)} error(s), {len(sc.skipped)} skipped, {sc.excluded} excluded"
        + (f" - baseline #{result['replaced']} kept as Superseded." if result["replaced"] else "."))


def render() -> None:
    page_header("Create Baseline", "Record the trusted SHA-256 state of a folder")
    db = db_or_warn()
    if db is None:
        return
    bm = BaselineManager(db)
    settings = get_settings()
    s = settings["scan"]

    with st.expander("🧪 Synthetic sample folder (simulated data)", expanded=False):
        st.caption(f"`{C.SAMPLE_FOLDER}` contains harmless fictional files. Use it for demonstrations.")
        if st.button("↺ Reset sample folder to its original files", key="b_reset"):
            reset_sample()
            st.success("Sample folder restored.")
        if st.button("Use the sample folder below", key="b_use_sample"):
            st.session_state["b_dirs"] = str(C.SAMPLE_FOLDER)

    if "b_dirs" not in st.session_state:
        st.session_state["b_dirs"] = str(C.SAMPLE_FOLDER)
    dirs_text = st.text_area("Directories to monitor (one per line)", key="b_dirs", height=90,
                             help="e.g. a project folder, a configuration folder or a test folder. Whole-system "
                                  "locations such as / or C:\\ are refused.")
    name = st.text_input("Baseline name (optional)", key="b_name")
    c1, c2 = st.columns(2)
    ext = c1.text_input("File extensions (comma separated, empty = all files)", ", ".join(s["extensions"]),
                        key="b_ext")
    max_mb = c2.number_input("Maximum file size (MB)", 1, 10000, int(s["max_file_size_mb"]), key="b_max")
    ex_dirs = st.text_area("Excluded folders (patterns)", "\n".join(s["exclude_dirs"]), key="b_exd", height=80)
    ex_files = st.text_area("Excluded files (patterns)", "\n".join(s["exclude_files"]), key="b_exf", height=80)
    follow = st.checkbox("Follow symbolic links (not recommended)", value=bool(s["follow_symlinks"]), key="b_follow")

    local = {**settings, "scan": {**s, "extensions": [x.strip() for x in ext.split(",") if x.strip()],
                                  "max_file_size_mb": float(max_mb),
                                  "exclude_dirs": [x.strip() for x in ex_dirs.splitlines() if x.strip()],
                                  "exclude_files": [x.strip() for x in ex_files.splitlines() if x.strip()],
                                  "follow_symlinks": bool(follow)}}
    dirs = [d.strip() for d in dirs_text.splitlines() if d.strip()]

    if st.button("🔒 Create Baseline", type="primary", key="b_create"):
        try:
            _create(bm, dirs, name, local, confirm=False)
        except BaselineExistsError as exc:
            st.session_state["pending_replace"] = exc.baseline["baseline_id"]
        except (PathValidationError, ValueError, RuntimeError) as exc:
            st.error(str(exc))

    pending = st.session_state.get("pending_replace")
    if pending:
        st.warning(f"An active baseline (#{pending}) already exists for these directories. Replacing it changes "
                   "what counts as 'trusted'. The old baseline and its alerts are kept (status Superseded).")
        sure = st.checkbox(f"I confirm that the current files are authorized and should replace baseline #{pending}",
                           key="b_confirm")
        c1, c2 = st.columns(2)
        if c1.button("Replace baseline", key="b_replace", disabled=not sure):
            try:
                _create(bm, dirs, name, local, confirm=True)
            except (PathValidationError, ValueError, RuntimeError) as exc:
                st.error(str(exc))
        if c2.button("Cancel", key="b_cancel"):
            st.session_state.pop("pending_replace", None)
            st.rerun()

    if st.session_state.get("baseline_msg"):
        st.success(st.session_state["baseline_msg"])

    st.subheader("Existing baselines")
    df = bm.list()
    show_table(df.drop(columns=["directory_path"]) if not df.empty else df, empty_msg="No baselines yet.")
    if df.empty:
        return
    ids = list(df["baseline_id"])
    current = st.session_state.get("baseline_id", ids[0])
    pick = st.selectbox("Baseline", ids, index=ids.index(current) if current in ids else 0, key="b_pick",
                        format_func=lambda i: f"#{i} · " + df.set_index("baseline_id").loc[i, "name"])
    b = bm.get(pick)
    kpi_row([("Files", b["file_count"]), ("Status", b["status"]), ("Created", b["created_at"][:10],
                                                                    b["created_at"][11:]),
             ("Errors / skipped", f"{b['error_count']} / {len(b['skipped'])}")])
    c1, c2, c3 = st.columns(3)
    if c1.button("✔ Select this baseline", key="b_select", width="stretch"):
        st.session_state["baseline_id"] = int(pick)
        st.success(f"Baseline #{pick} selected for scanning and monitoring.")
    with c2:
        download("⬇ Export JSON", bm.export_json(pick).encode(), f"baseline_{pick}.json", "application/json",
                 "b_json")
    with c3:
        download("⬇ Export CSV", bm.export_csv(pick).encode(), f"baseline_{pick}.csv", "text/csv", "b_csv")
    files = bm.files(pick)
    show_table(files, height=300)
    if b["status"] != "Active":
        with st.expander("Delete this (inactive) baseline"):
            sure = st.checkbox(f"Yes, permanently delete baseline #{pick} with its scans and alerts", key="b_del_ok")
            if st.button("Delete baseline", key="b_del", disabled=not sure):
                try:
                    bm.delete_baseline(pick, confirm=True)
                    st.session_state.pop("baseline_id", None)
                    st.rerun()
                except ConfirmationRequired as exc:
                    st.error(str(exc))
