"""Page 6: Alerts - list, details and status updates."""

from __future__ import annotations

import streamlit as st

import config as C
from core.alert_manager import AlertManager, format_alert
from dashboard.common import badge, db_or_warn, e, kpi_row, page_header, show_table


def render() -> None:
    page_header("Alerts", "File integrity alerts and investigation status")
    db = db_or_warn()
    if db is None:
        return
    am = AlertManager(db)
    only_sel = st.checkbox("Only the selected baseline", value=True, key="al_only")
    bid = st.session_state.get("baseline_id") if only_sel else None
    c1, c2, c3, c4 = st.columns(4)
    sev = c1.selectbox("Severity", ["All"] + list(reversed(C.SEVERITIES)), key="al_sev")
    evt = c2.selectbox("Event", ["All"] + C.EVENT_TYPES, key="al_evt")
    status = c3.selectbox("Status", ["All"] + C.ALERT_STATUSES, key="al_status")
    q = c4.text_input("File path contains", key="al_q")
    df = am.list(bid, None if sev == "All" else sev, None if status == "All" else status,
                 None if evt == "All" else evt, q.strip())
    allv = am.list(bid)
    kpi_row([("Alerts", len(allv)), ("New", int((allv["status"] == "New").sum()) if not allv.empty else 0),
             ("High / critical", int(allv["severity"].isin(["HIGH", "CRITICAL"]).sum()) if not allv.empty else 0),
             ("Still active", int(allv["active"].sum()) if not allv.empty else 0, "condition still present")])
    cols = ["alert_id", "created_at", "file_path", "event_type", "severity", "previous_hash", "current_hash", "status",
            "active", "times_seen"]
    show_table(df[cols] if not df.empty else df, height=340, empty_msg="No alerts match.")
    st.caption("times_seen counts how many scans found the same unchanged condition (no duplicate alerts). "
               "active = 0: the condition has gone (e.g. file restored) or a newer alert replaced it.")
    if df.empty:
        return
    labels = {int(r.alert_id): f"#{r.alert_id} · {r.severity} · {r.event_type} · {r.file_path}" for r in df.itertuples()}
    aid = st.selectbox("Alert details", list(labels), format_func=labels.get, key="al_pick")
    a = am.get(aid)
    st.markdown(f"{badge(a['severity'])} &nbsp; <b>{e(C.EVENT_LABELS[a['event_type']])}</b> · status "
                f"<b>{e(a['status'])}</b>", unsafe_allow_html=True)
    st.code(format_alert(a), language=None)
    new = st.selectbox("Set status", C.ALERT_STATUSES, index=C.ALERT_STATUSES.index(a["status"]), key="al_new")
    if st.button("Update status", key="al_update"):
        am.set_status(aid, new)
        st.success(f"Alert #{aid} marked as {new}.")
        st.rerun()
