# Project Status — what was verified and what still needs to be checked

The development environment was Ubuntu 24.04 with Python 3.13 (also compiled on 3.11 and 3.12) and
watchdog 6.0.0. Streamlit and Plotly could not be installed there.

## ✅ Verified by actually running it
| Item | Evidence |
|---|---|
| Automated tests | `pytest`: **116 passed** as a normal user; **114 passed, 2 skipped** as root (two real-permission tests skip because root can read mode-000 files) |
| SHA-256 engine | known value of the empty file, avalanche, 25 MiB chunked file, permission/missing/symlink/FIFO cases, file changing while hashed |
| Baseline safety | replacement refused without confirmation; old baseline kept as *Superseded*; active baseline cannot be deleted |
| Change detection | all five demo scenarios produce the numbers in `sample_output/scenario_results.txt` |
| Duplicate prevention | repeated scans increase `times_seen` instead of creating alerts; a further change creates a new alert; restore clears it |
| Real-time monitoring | real inotify events through watchdog (native and polling modes) and the periodic-scan fallback; debounce; rename = delete + new |
| Reports | PDF (`sample_output/integrity_report_sample.pdf`, pages in `screenshots/`), CSV and JSON exports checked for contents and for the absence of file contents |
| CLI | `cli.py baseline/scan/list`, exit codes 0/1/2, `--replace`, `--pdf` |
| Read-only behaviour | test that scans the core/monitoring source for write/delete/execute calls; scans of /etc, /usr/share/doc and 31,188 Python package files left sizes and timestamps unchanged |
| Dashboard logic | all 9 pages executed headless with a Streamlit stand-in (`tests/streamlit_stub.py`): no errors with an empty database or after the full workflow (create → confirm → replace → simulate → scan → alert status → PDF → real-time start/stop → settings) |

## ⚠️ Not verified here — please check on your computer
| Item | How to check |
|---|---|
| Visual look of the Streamlit dashboard and Plotly charts in a real browser | `./run.sh` (or `run.bat`), follow `documentation/DEMO_GUIDE.md`, take screenshots into `screenshots/` |
| Windows and macOS | `setup.bat` + `venv\Scripts\python -m pytest -q`; manual steps in DEMO_GUIDE.md ("Testing manually") |
| Real-time monitoring on Windows/macOS and on network drives | Real-Time Monitoring page, native mode, then the polling mode for network shares |
| Very large folders (> 50,000 files) | raise `max_files` on the Settings page; on Linux, check `fs.inotify.max_user_watches` for real-time mode |

## Known limitations (by design or out of scope)
See README section 18: the tool shows *what* changed, not *who*. The local baseline can be altered by an
attacker who controls the host. Permissions and ownership are not monitored. Periodic scans miss changes
that are reverted between scans.
