"""
Baseline management - the trusted state of the monitored files.

  * creating a baseline is an explicit action; an existing Active baseline for the same directories is NEVER
    replaced silently: create_baseline() raises BaselineExistsError unless confirm_replace=True
  * a replaced baseline is kept (status 'Superseded') - history is preserved, nothing is deleted
  * deleting a baseline also requires explicit confirmation and is refused while it is the active one
"""

from __future__ import annotations

import csv
import io
import json
from datetime import datetime

import pandas as pd

import config as C
from core.file_scanner import ScanOptions, ScanResult, normalise, scan, validate_directory
from database.db_manager import DatabaseManager


class BaselineExistsError(RuntimeError):
    def __init__(self, baseline: dict):
        self.baseline = baseline
        super().__init__(f"An active baseline (#{baseline['baseline_id']}, created {baseline['created_at']}, "
                         f"{baseline['file_count']} files) already exists for these directories. Replacing it "
                         "requires explicit confirmation.")


class ConfirmationRequired(RuntimeError):
    pass


def dir_key(directories: list) -> str:
    return json.dumps(sorted(normalise(d) for d in directories))


class BaselineManager:
    def __init__(self, db: DatabaseManager):
        self.db = db

    # ------------------------------------------------------------------ read
    def list(self) -> pd.DataFrame:
        df = self.db.query("SELECT baseline_id, name, directory_path, created_at, file_count, status, error_count "
                           "FROM baselines ORDER BY baseline_id DESC")
        if not df.empty:
            df["directories"] = df["directory_path"].map(lambda s: ", ".join(json.loads(s)))
        return df

    def get(self, baseline_id: int) -> dict | None:
        b = self.db.one("SELECT * FROM baselines WHERE baseline_id = ?", (int(baseline_id),))
        if b:
            b["directories"] = json.loads(b["directory_path"])
            b["options"] = json.loads(b["options_json"] or "{}")
            b["skipped"] = json.loads(b["skipped_json"] or "{}")
        return b

    def active_for(self, directories: list) -> dict | None:
        b = self.db.one("SELECT * FROM baselines WHERE directory_path = ? AND status = 'Active' "
                        "ORDER BY baseline_id DESC LIMIT 1", (dir_key(directories),))
        return b

    def latest_active(self) -> dict | None:
        b = self.db.one("SELECT baseline_id FROM baselines WHERE status = 'Active' ORDER BY baseline_id DESC LIMIT 1")
        return self.get(b["baseline_id"]) if b else None

    def files(self, baseline_id: int) -> pd.DataFrame:
        return self.db.query("SELECT file_path, sha256, file_size, modified_at FROM baseline_files "
                             "WHERE baseline_id = ? ORDER BY file_path", (int(baseline_id),))

    def file_map(self, baseline_id: int) -> dict:
        df = self.files(baseline_id)
        return {r.file_path: {"sha256": r.sha256, "size": r.file_size, "mtime": r.modified_at}
                for r in df.itertuples()}

    def options(self, baseline_id: int) -> ScanOptions:
        b = self.get(baseline_id)
        return ScanOptions(**b["options"])

    # ------------------------------------------------------------------ write
    def create_baseline(self, directories: list, settings: dict | None = None, name: str = "",
                        confirm_replace: bool = False, progress=None, stop_event=None) -> dict:
        """Scan the directories and store a new baseline. Returns {"baseline_id", "scan": ScanResult, ...}."""
        settings = settings or C.load_settings()
        dirs = [validate_directory(d) for d in directories]
        if not dirs:
            raise ValueError("Select at least one directory.")
        existing = self.active_for(dirs)
        if existing and not confirm_replace:
            raise BaselineExistsError(existing)
        opts = ScanOptions.from_settings(dirs, settings)
        result: ScanResult = scan(opts, progress, stop_event)
        if result.stopped:
            raise RuntimeError("Baseline creation was stopped - no baseline was stored.")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self.db.conn() as con:
            if existing:
                con.execute("UPDATE baselines SET status = 'Superseded' WHERE baseline_id = ?",
                            (existing["baseline_id"],))
            cur = con.execute("INSERT INTO baselines (name, directory_path, created_at, file_count, status, "
                              "options_json, error_count, skipped_json) VALUES (?,?,?,?,?,?,?,?)",
                              (name or f"Baseline {now}", dir_key(dirs), now, len(result.records), "Active",
                               json.dumps(opts.to_dict()), len(result.errors), json.dumps(result.skipped)))
            bid = cur.lastrowid
            con.executemany("INSERT INTO baseline_files (baseline_id, file_path, sha256, file_size, modified_at) "
                            "VALUES (?,?,?,?,?)",
                            [(bid, r.path, r.sha256, r.size, r.mtime) for r in result.records.values()])
        return {"baseline_id": bid, "scan": result, "replaced": existing["baseline_id"] if existing else None}

    def set_status(self, baseline_id: int, status: str) -> None:
        if status not in ("Active", "Superseded", "Archived"):
            raise ValueError("Invalid baseline status")
        with self.db.conn() as con:
            if status == "Active":
                b = con.execute("SELECT directory_path FROM baselines WHERE baseline_id = ?", (baseline_id,)).fetchone()
                con.execute("UPDATE baselines SET status = 'Superseded' WHERE directory_path = ? AND status = 'Active'",
                            (b["directory_path"],))
            con.execute("UPDATE baselines SET status = ? WHERE baseline_id = ?", (status, int(baseline_id)))

    def delete_baseline(self, baseline_id: int, confirm: bool = False) -> None:
        """Remove a baseline and its records/alerts. Requires confirm=True; the Active baseline is refused."""
        if not confirm:
            raise ConfirmationRequired("Deleting a baseline requires explicit confirmation.")
        b = self.get(baseline_id)
        if b and b["status"] == "Active":
            raise ConfirmationRequired("The active baseline cannot be deleted. Create a new baseline or archive "
                                       "it first.")
        with self.db.conn() as con:
            con.execute("DELETE FROM security_alerts WHERE baseline_id = ?", (baseline_id,))
            con.execute("DELETE FROM scan_files WHERE scan_id IN (SELECT scan_id FROM file_scans WHERE "
                        "baseline_id = ?)", (baseline_id,))
            con.execute("DELETE FROM file_scans WHERE baseline_id = ?", (baseline_id,))
            con.execute("DELETE FROM baseline_files WHERE baseline_id = ?", (baseline_id,))
            con.execute("DELETE FROM baselines WHERE baseline_id = ?", (baseline_id,))

    # ------------------------------------------------------------------ export
    def export_json(self, baseline_id: int) -> str:
        b = self.get(baseline_id)
        files = self.files(baseline_id)
        return json.dumps({"baseline_id": b["baseline_id"], "name": b["name"], "directories": b["directories"],
                           "created_at": b["created_at"], "status": b["status"], "file_count": b["file_count"],
                           "options": b["options"], "hash_algorithm": "SHA-256",
                           "files": [{"path": r.file_path, "sha256": r.sha256, "size": r.file_size,
                                      "modified": datetime.fromtimestamp(r.modified_at).isoformat()
                                      if r.modified_at else None} for r in files.itertuples()]}, indent=2)

    def export_csv(self, baseline_id: int) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["baseline_id", "file_path", "sha256", "file_size", "modified_at"])
        for r in self.files(baseline_id).itertuples():
            w.writerow([baseline_id, r.file_path, r.sha256, r.file_size,
                        datetime.fromtimestamp(r.modified_at).isoformat() if r.modified_at else ""])
        return buf.getvalue()
