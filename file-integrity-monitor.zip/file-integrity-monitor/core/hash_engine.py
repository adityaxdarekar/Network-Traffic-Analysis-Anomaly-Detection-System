"""
SHA-256 hashing engine.

  * files are read in binary mode, in chunks (default 1 MiB) - large files never load fully into memory
  * the file is opened READ-ONLY and, where the OS supports it, with O_NOFOLLOW so a symbolic link swapped in
    at the last moment is not followed
  * only regular files are hashed (a FIFO or device would block or never end)
  * a file that changes WHILE it is being hashed (size or modification time differ before and after) is
    hashed again, up to HASH_RETRIES times; if it keeps changing the result is reported as unstable
  * every problem (missing, permission denied, I/O error) is returned as data - nothing is raised to the caller
  * monitored files are never modified, executed or interpreted - their bytes only go into hashlib
"""

from __future__ import annotations

import errno
import hashlib
import os
import stat
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

import config as C

ERR_MISSING = "missing"
ERR_PERMISSION = "permission denied"
ERR_NOT_REGULAR = "not a regular file"
ERR_SYMLINK = "symbolic link (not followed)"
ERR_UNSTABLE = "file kept changing while it was hashed"
ERR_IO = "read error"


@dataclass
class FileRecord:
    path: str
    size: int | None = None
    mtime: float | None = None          # modification time, seconds since epoch
    sha256: str | None = None
    error: str | None = None
    attempts: int = 0

    @property
    def ok(self) -> bool:
        return self.error is None and self.sha256 is not None

    @property
    def mtime_text(self) -> str:
        return datetime.fromtimestamp(self.mtime).strftime("%Y-%m-%d %H:%M:%S") if self.mtime else ""

    def to_dict(self) -> dict:
        return asdict(self)


def calculate_sha256(file_path: str | os.PathLike, chunk_size: int = C.HASH_CHUNK_SIZE) -> str:
    """Plain SHA-256 of a file (binary, chunked). Raises OSError on problems - see hash_file for the safe version."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as file:
        for chunk in iter(lambda: file.read(chunk_size), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _open_readonly(path: str) -> int:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    return os.open(path, flags)


def _hash_fd(fd: int, chunk_size: int) -> str:
    sha256 = hashlib.sha256()
    while True:
        chunk = os.read(fd, chunk_size)
        if not chunk:
            break
        sha256.update(chunk)
    return sha256.hexdigest()


def hash_file(path: str | os.PathLike, chunk_size: int = C.HASH_CHUNK_SIZE, retries: int = C.HASH_RETRIES,
              follow_symlinks: bool = False) -> FileRecord:
    """Hash one file safely. Returns a FileRecord; check `.error`."""
    p = os.path.abspath(os.fspath(path))
    rec = FileRecord(path=p)
    for attempt in range(1, retries + 1):
        rec.attempts = attempt
        try:
            before = os.stat(p, follow_symlinks=follow_symlinks)
        except FileNotFoundError:
            rec.error = ERR_MISSING
            return rec
        except PermissionError:
            rec.error = ERR_PERMISSION
            return rec
        except OSError as exc:
            rec.error = f"{ERR_IO}: {exc.strerror or exc.__class__.__name__}"
            return rec
        if stat.S_ISLNK(before.st_mode):
            rec.error = ERR_SYMLINK
            return rec
        if not stat.S_ISREG(before.st_mode):
            rec.error = ERR_NOT_REGULAR
            return rec
        try:
            fd = _open_readonly(p) if not follow_symlinks else os.open(p, os.O_RDONLY | getattr(os, "O_BINARY", 0))
            try:
                opened = os.fstat(fd)
                if not stat.S_ISREG(opened.st_mode):
                    rec.error = ERR_NOT_REGULAR
                    return rec
                digest = _hash_fd(fd, chunk_size)
                after = os.fstat(fd)
            finally:
                os.close(fd)
            after_path = os.stat(p, follow_symlinks=follow_symlinks)
        except FileNotFoundError:
            rec.error = ERR_MISSING                       # removed while we were reading it
            return rec
        except PermissionError:
            rec.error = ERR_PERMISSION
            return rec
        except OSError as exc:
            if getattr(exc, "errno", None) == errno.ELOOP:  # became a symlink (refused by O_NOFOLLOW)
                rec.error = ERR_SYMLINK
                return rec
            rec.error = f"{ERR_IO}: {exc.strerror or exc.__class__.__name__}"
            return rec
        stable = ((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
                  == (after_path.st_size, after_path.st_mtime_ns) and before.st_ino == after_path.st_ino)
        if stable:
            rec.size, rec.mtime, rec.sha256, rec.error = after.st_size, after.st_mtime, digest, None
            return rec
        rec.error = ERR_UNSTABLE
    return rec


def hash_path(path: str | os.PathLike) -> list[FileRecord]:
    """Accept a single file OR a directory (non-recursive convenience; use file_scanner for full scans)."""
    p = Path(path)
    if p.is_dir() and not p.is_symlink():
        return [hash_file(c) for c in sorted(p.iterdir()) if c.is_file() and not c.is_symlink()]
    return [hash_file(p)]


def short(h: str | None, n: int = 12) -> str:
    return (h[:n] + "…") if h else "-"
