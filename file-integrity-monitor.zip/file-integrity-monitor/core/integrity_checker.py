"""
Integrity checker: runs a scan for a baseline, compares, stores the scan, raises alerts.

Also provides check_single_file() for the real-time monitor (one path at a time).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd

from core.alert_manager import AlertManager, AlertOutcome
from core.baseline_manager import BaselineManager
from core.change_detector import FileChange, compare, summarise
from core.file_scanner import ScanOptions, ScanResult, is_eligible, scan
from core.hash_engine import hash_file
from database.db_manager import DatabaseManager


@dataclass
class IntegrityReport:
    scan_id: int
    baseline_id: int
    scanned_at: str
    changes: list = field(default_factory=list)    # [FileChange]
    counts: dict = field(default_factory=dict)
    scan: ScanResult | None = None
    alerts: AlertOutcome | None = None

    def frame(self, statuses: list | None = None) -> pd.DataFrame:
        rows = [c.to_dict() for c in self.changes if statuses is None or c.status in statuses]
        return pd.DataFrame(rows, columns=list(FileChange.__dataclass_fields__))


class IntegrityChecker:
    def __init__(self, db: DatabaseManager, settings: dict | None = None):
        self.db = db
        self.baselines = BaselineManager(db)
        self.alerts = AlertManager(db, settings)

    def run_scan(self, baseline_id: int, progress=None, stop_event=None, trigger: str = "manual") -> IntegrityReport:
        b = self.baselines.get(baseline_id)
        if not b:
            raise ValueError(f"Baseline {baseline_id} does not exist.")
        opts = ScanOptions(**b["options"])
        result = scan(opts, progress, stop_event)     # a vanished root ends up in result.missing_dirs
        changes = compare(self.baselines.file_map(baseline_id), result)
        counts = summarise(changes)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        outcome = self.alerts.process(baseline_id, changes, source=trigger)
        with self.db.conn() as con:
            cur = con.execute(
                "INSERT INTO file_scans (baseline_id, scanned_at, total_files, modified_count, deleted_count, "
                "new_count, error_count, unchanged_count, skipped_count, alerts_created, trigger, duration) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (baseline_id, now, result.files_scanned, counts["MODIFIED"], counts["DELETED"], counts["NEW"],
                 counts["INACCESSIBLE"], counts["UNCHANGED"], counts["SKIPPED"], len(outcome.created), trigger,
                 result.duration))
            scan_id = cur.lastrowid
            con.executemany("INSERT INTO scan_files VALUES (?,?,?,?,?,?,?,?,?,?)",
                            [(scan_id, c.path, c.status, c.baseline_hash, c.current_hash, c.baseline_size,
                              c.current_size, c.baseline_mtime, c.current_mtime, c.detail) for c in changes])
        return IntegrityReport(scan_id, baseline_id, now, changes, counts, result, outcome)

    def check_single_file(self, baseline_id: int, path: str, opts: ScanOptions | None = None,
                          source: str = "realtime") -> tuple[FileChange | None, AlertOutcome | None]:
        """Re-hash one file and compare it with the baseline (used for real-time events)."""
        opts = opts or self.baselines.options(baseline_id)
        path = os.path.abspath(path)
        base = self.db.one("SELECT sha256, file_size, modified_at FROM baseline_files WHERE baseline_id = ? AND "
                           "file_path = ?", (baseline_id, path))
        if base is None and not is_eligible(path, opts):
            return None, None
        rec = hash_file(path, follow_symlinks=opts.follow_symlinks)
        common = {}
        if base:
            common = dict(baseline_hash=base["sha256"], baseline_size=base["file_size"],
                          baseline_mtime=base["modified_at"])
        if rec.ok:
            if base is None:
                if rec.size is not None and rec.size > opts.max_file_size_mb * 1024 * 1024:
                    return None, None
                ch = FileChange(path, "NEW", None, rec.sha256, None, rec.size, None, rec.mtime, "not in the baseline")
            elif rec.sha256 == base["sha256"]:
                ch = FileChange(path, "UNCHANGED", current_hash=rec.sha256, current_size=rec.size,
                                current_mtime=rec.mtime, **common)
            else:
                ch = FileChange(path, "MODIFIED", current_hash=rec.sha256, current_size=rec.size,
                                current_mtime=rec.mtime, detail="SHA-256 differs from the baseline", **common)
        elif rec.error == "missing":
            if base is None:
                ch = FileChange(path, "UNCHANGED", detail="new file removed again")   # nothing to report
            else:
                ch = FileChange(path, "DELETED", detail="file no longer exists", **common)
        else:
            ch = FileChange(path, "INACCESSIBLE", detail=rec.error, **common)
        outcome = self.alerts.process(baseline_id, [ch], source=source, scope_paths={path})
        return ch, outcome

    # ------------------------------------------------------------------ history
    def scans(self, baseline_id: int | None = None) -> pd.DataFrame:
        if baseline_id:
            return self.db.query("SELECT * FROM file_scans WHERE baseline_id = ? ORDER BY scan_id DESC", (baseline_id,))
        return self.db.query("SELECT * FROM file_scans ORDER BY scan_id DESC")

    def scan_files(self, scan_id: int) -> pd.DataFrame:
        return self.db.query("SELECT * FROM scan_files WHERE scan_id = ? ORDER BY file_path", (int(scan_id),))

    def latest_scan(self, baseline_id: int) -> dict | None:
        return self.db.one("SELECT * FROM file_scans WHERE baseline_id = ? ORDER BY scan_id DESC LIMIT 1",
                           (int(baseline_id),))
