"""
Security alerts: severity classification, explanation, recommended action, duplicate prevention, status.

Duplicate prevention
--------------------
An alert stays ACTIVE while its condition exists. On every scan (or real-time check):
  * the same condition again (same baseline, path, event type and current hash)  -> no new alert,
    the existing one gets last_seen / times_seen updated
  * the file changes AGAIN (new current hash)                                     -> new alert
  * the condition disappears (file restored, file re-appears)                     -> alert set inactive,
    so if the problem comes back later it is reported again

Severity is configurable (settings["severity"]); critical-file and executable patterns decide which rule
applies. A change is not necessarily malicious - legitimate updates and authorised edits also trigger alerts.
"""

from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass
from datetime import datetime

import pandas as pd

import config as C
from core.change_detector import FileChange
from database.db_manager import DatabaseManager

ALERTABLE = {"MODIFIED", "DELETED", "NEW", "INACCESSIBLE"}
NOT_MALICIOUS = ("This does not prove malicious activity - software updates, log rotation and authorised edits "
                 "also change files.")
EXPLANATIONS = {
    "MODIFIED": "The current SHA-256 hash does not match the trusted baseline hash, so the file content has changed.",
    "DELETED": "The file is recorded in the trusted baseline but no longer exists in the monitored directory.",
    "NEW": "The file exists in the monitored directory but is not part of the trusted baseline.",
    "INACCESSIBLE": "The file could not be read, so its integrity could not be verified. It is NOT assumed deleted.",
}
ACTIONS = {
    "MODIFIED": "Verify whether the modification was authorized (change ticket, update, owner). If unexpected, "
                "compare with a backup, review who had access and related system activity, and restore from a "
                "trusted copy if needed.",
    "DELETED": "Check whether the deletion was intended. If not, restore the file from a backup and review "
               "access logs for the time window.",
    "NEW": "Identify who created the file and why. Be cautious with unknown scripts or executables - do not run "
           "them; inspect them in a safe environment.",
    "INACCESSIBLE": "Check file permissions and whether the file is locked or still being written; re-run the "
                    "scan with appropriate permissions.",
}


def _match(path: str, patterns: list) -> bool:
    name = os.path.basename(path)
    return any(fnmatch.fnmatch(name.lower(), p.lower()) for p in patterns)


def classify(event_type: str, path: str, settings: dict) -> tuple[str, str]:
    """Return (severity, reason) for an event."""
    sev = settings["severity"]
    if event_type == "MODIFIED":
        if _match(path, settings["critical_patterns"]):
            return sev["MODIFIED_CRITICAL"], "critical/configuration file"
        return sev["MODIFIED"], "ordinary monitored file"
    if event_type == "DELETED":
        return sev["DELETED"], "monitored file removed"
    if event_type == "NEW":
        if _match(path, settings["executable_patterns"]):
            return sev["NEW_EXECUTABLE"], "new script or executable"
        return sev["NEW"], "new file"
    return sev["INACCESSIBLE"], "integrity could not be verified"


@dataclass
class AlertOutcome:
    created: list
    repeated: int
    cleared: int


class AlertManager:
    def __init__(self, db: DatabaseManager, settings: dict | None = None):
        self.db = db
        self.settings = settings or C.load_settings()

    def process(self, baseline_id: int, changes: list[FileChange], source: str = "scan",
                scope_paths: set | None = None) -> AlertOutcome:
        """
        Create alerts for new conditions, refresh repeated ones and clear resolved ones.
        scope_paths: only these paths are considered "checked" (real-time checks of single files);
                     None = full scan (every active alert of the baseline is re-evaluated).
        """
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        created, repeated = [], 0
        current_keys = set()
        with self.db.conn() as con:
            for ch in changes:
                if ch.status not in ALERTABLE:
                    continue
                cur_hash = ch.current_hash if ch.status != "INACCESSIBLE" else None
                key = (ch.path, ch.status, cur_hash)
                current_keys.add(key)
                row = con.execute("SELECT alert_id FROM security_alerts WHERE baseline_id = ? AND file_path = ? AND "
                                  "event_type = ? AND COALESCE(current_hash, '') = COALESCE(?, '') AND active = 1",
                                  (baseline_id, ch.path, ch.status, cur_hash)).fetchone()
                if row:
                    repeated += 1
                    con.execute("UPDATE security_alerts SET last_seen = ?, times_seen = times_seen + 1 "
                                "WHERE alert_id = ?", (now, row["alert_id"]))
                    continue
                # the same file with a different condition (e.g. modified again): previous alert is superseded
                con.execute("UPDATE security_alerts SET active = 0 WHERE baseline_id = ? AND file_path = ? "
                            "AND active = 1", (baseline_id, ch.path))
                severity, reason = classify(ch.status, ch.path, self.settings)
                expl = f"{EXPLANATIONS[ch.status]} Severity {severity}: {reason}. "
                if ch.status == "INACCESSIBLE":
                    expl += f"Reason: {ch.detail}. "
                expl += NOT_MALICIOUS
                cur = con.execute(
                    "INSERT INTO security_alerts (baseline_id, created_at, file_path, event_type, previous_hash, "
                    "current_hash, severity, explanation, recommended_action, status, active, last_seen, source, "
                    "file_mtime, previous_size, current_size) VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?,?,?,?)",
                    (baseline_id, now, ch.path, ch.status, ch.baseline_hash, cur_hash, severity, expl,
                     ACTIONS[ch.status], "New", now, source, ch.current_mtime or ch.baseline_mtime, ch.baseline_size,
                     ch.current_size))
                created.append(cur.lastrowid)
            # clear active alerts whose condition no longer exists
            rows = con.execute("SELECT alert_id, file_path, event_type, current_hash FROM security_alerts "
                               "WHERE baseline_id = ? AND active = 1", (baseline_id,)).fetchall()
            cleared = 0
            for r in rows:
                if scope_paths is not None and r["file_path"] not in scope_paths:
                    continue
                if (r["file_path"], r["event_type"], r["current_hash"]) not in current_keys:
                    con.execute("UPDATE security_alerts SET active = 0 WHERE alert_id = ?", (r["alert_id"],))
                    cleared += 1
        return AlertOutcome(created, repeated, cleared)

    # ------------------------------------------------------------------ queries / status
    def list(self, baseline_id: int | None = None, severity: str | None = None, status: str | None = None,
             event_type: str | None = None, search: str = "") -> pd.DataFrame:
        sql = ("SELECT alert_id, created_at, baseline_id, file_path, event_type, severity, previous_hash, "
               "current_hash, status, active, times_seen, last_seen, source, explanation, recommended_action "
               "FROM security_alerts")
        cond, args = [], []
        for col, val in (("baseline_id", baseline_id), ("severity", severity), ("status", status),
                         ("event_type", event_type)):
            if val not in (None, ""):
                cond.append(f"{col} = ?")
                args.append(val)
        if search:
            cond.append("file_path LIKE ?")
            args.append(f"%{search}%")
        if cond:
            sql += " WHERE " + " AND ".join(cond)
        sql += " ORDER BY alert_id DESC"
        return self.db.query(sql, tuple(args))

    def get(self, alert_id: int) -> dict | None:
        return self.db.one("SELECT * FROM security_alerts WHERE alert_id = ?", (int(alert_id),))

    def set_status(self, alert_id: int, status: str) -> None:
        if status not in C.ALERT_STATUSES:
            raise ValueError(f"Status must be one of {C.ALERT_STATUSES}")
        with self.db.conn() as con:
            con.execute("UPDATE security_alerts SET status = ? WHERE alert_id = ?", (status, int(alert_id)))


def format_alert(a: dict) -> str:
    """Plain-text alert in the format shown in the project brief."""
    return (f"FILE INTEGRITY ALERT #{a['alert_id']}\n\nEvent: {C.EVENT_LABELS.get(a['event_type'], a['event_type'])}\n"
            f"File: {a['file_path']}\n\nOriginal SHA-256:\n{a.get('previous_hash') or '-'}\n\nCurrent SHA-256:\n"
            f"{a.get('current_hash') or '-'}\n\nSeverity: {a['severity']}\n\nExplanation:\n{a['explanation']}\n\n"
            f"Recommended action:\n{a['recommended_action']}\n")
