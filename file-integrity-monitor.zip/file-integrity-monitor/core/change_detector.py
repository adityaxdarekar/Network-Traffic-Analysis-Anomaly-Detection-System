"""
Change detection - compares a fresh scan with the trusted baseline (pure function, no I/O).

For every path in (baseline ∪ current scan):
  UNCHANGED     hash identical                    (a changed timestamp alone is not a modification)
  MODIFIED      hash differs
  NEW           in the scan, not in the baseline
  DELETED       in the baseline, not found - but ONLY if it was not inaccessible or skipped
  INACCESSIBLE  could not be read (permission, I/O error, changing while hashed) or lies inside a directory
                that could not be listed - NEVER reported as deleted
  SKIPPED       in the baseline but now skipped (e.g. grew beyond the size limit, became a symlink)
"""

from __future__ import annotations

import os
from dataclasses import asdict, dataclass

from core.file_scanner import ScanResult

STATUSES = ["UNCHANGED", "MODIFIED", "DELETED", "NEW", "INACCESSIBLE", "SKIPPED"]


@dataclass
class FileChange:
    path: str
    status: str
    baseline_hash: str | None = None
    current_hash: str | None = None
    baseline_size: int | None = None
    current_size: int | None = None
    baseline_mtime: float | None = None
    current_mtime: float | None = None
    detail: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _under(path: str, directory: str) -> bool:
    return path == directory or path.startswith(directory.rstrip(os.sep) + os.sep)


def compare(baseline: dict, current: ScanResult) -> list[FileChange]:
    """baseline: {path: {"sha256", "size", "mtime"}} -> list of FileChange (sorted by path)."""
    out: list[FileChange] = []
    for path in sorted(set(baseline) | set(current.records) | set(current.errors) | set(current.skipped)):
        b = baseline.get(path)
        rec = current.records.get(path)
        if path in current.error_dirs and path not in baseline:
            continue                                   # an unreadable directory is reported via its files
        if b is None:
            if rec is not None:
                out.append(FileChange(path, "NEW", None, rec.sha256, None, rec.size, None, rec.mtime,
                                      "not in the baseline"))
            elif path in current.errors:
                out.append(FileChange(path, "INACCESSIBLE", detail=current.errors[path]))
            continue
        common = dict(baseline_hash=b["sha256"], baseline_size=b["size"], baseline_mtime=b["mtime"])
        if rec is not None:
            if rec.sha256 == b["sha256"]:
                detail = "timestamp changed, content identical" if rec.mtime != b["mtime"] else ""
                out.append(FileChange(path, "UNCHANGED", current_hash=rec.sha256, current_size=rec.size,
                                      current_mtime=rec.mtime, detail=detail, **common))
            else:
                out.append(FileChange(path, "MODIFIED", current_hash=rec.sha256, current_size=rec.size,
                                      current_mtime=rec.mtime, detail="SHA-256 differs from the baseline", **common))
        elif path in current.errors:
            out.append(FileChange(path, "INACCESSIBLE", detail=current.errors[path], **common))
        elif path in current.skipped:
            out.append(FileChange(path, "SKIPPED", detail=current.skipped[path], **common))
        else:
            blocked = next((d for d in current.error_dirs if _under(path, d)), None)
            if blocked:
                out.append(FileChange(path, "INACCESSIBLE", detail=f"parent directory unreadable: "
                                                                   f"{current.errors.get(blocked, '')}", **common))
            elif current.stopped or current.limit_reached:
                out.append(FileChange(path, "INACCESSIBLE", detail="not reached - scan was incomplete", **common))
            else:
                gone = next((d for d in current.missing_dirs if _under(path, d)), None)
                out.append(FileChange(path, "DELETED", detail=f"directory {gone} no longer exists" if gone
                                      else "file no longer exists", **common))
    return out


def summarise(changes: list[FileChange]) -> dict:
    counts = {s: 0 for s in STATUSES}
    for c in changes:
        counts[c.status] += 1
    return counts
