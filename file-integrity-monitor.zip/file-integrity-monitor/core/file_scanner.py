"""
Directory scanning: validated paths, recursive walk, filters, exclusions, safety limits, progress.

  * symbolic links are NOT followed (recorded as skipped) unless explicitly enabled
  * the same physical file is never hashed twice (overlapping folders / hard links: (device, inode) check)
  * inaccessible directories and files are recorded as errors - never treated as deleted
  * files above max_file_size_mb are recorded as skipped - also never treated as deleted
  * the filesystem root, virtual file systems and OS program folders are refused (no whole-OS scans)
"""

from __future__ import annotations

import fnmatch
import os
import stat
import threading
import time
from dataclasses import dataclass, field

import config as C
from core.hash_engine import FileRecord, hash_file


class PathValidationError(ValueError):
    """Raised for directories that may not or cannot be monitored. The message is user-friendly."""


@dataclass
class ScanOptions:
    directories: list
    extensions: list = field(default_factory=list)
    exclude_dirs: list = field(default_factory=list)
    exclude_files: list = field(default_factory=list)
    follow_symlinks: bool = False
    max_file_size_mb: float = 100
    max_files: int = 50000

    @classmethod
    def from_settings(cls, directories: list, settings: dict) -> "ScanOptions":
        s = settings["scan"]
        return cls(directories=list(directories), extensions=list(s["extensions"]),
                   exclude_dirs=list(s["exclude_dirs"]), exclude_files=list(s["exclude_files"]),
                   follow_symlinks=bool(s["follow_symlinks"]), max_file_size_mb=float(s["max_file_size_mb"]),
                   max_files=int(s["max_files"]))

    def to_dict(self) -> dict:
        return dict(self.__dict__)


@dataclass
class ScanResult:
    records: dict = field(default_factory=dict)      # path -> FileRecord (successfully hashed)
    errors: dict = field(default_factory=dict)       # path -> error text (files or directories)
    error_dirs: list = field(default_factory=list)   # directories that could not be listed (permission / I/O)
    missing_dirs: list = field(default_factory=list) # directories that no longer exist (their files are deleted)
    skipped: dict = field(default_factory=dict)      # path -> reason (symlink, too large, not regular)
    excluded: int = 0
    duplicates: int = 0
    limit_reached: bool = False
    stopped: bool = False
    duration: float = 0.0

    @property
    def files_scanned(self) -> int:
        return len(self.records)


def normalise(path: str) -> str:
    return os.path.normpath(os.path.abspath(os.path.expanduser(path.strip().strip('"').strip("'"))))


def validate_directory(raw: str) -> str:
    """Return a normalised absolute directory path or raise PathValidationError."""
    if not raw or not raw.strip():
        raise PathValidationError("Please enter a directory path.")
    if "\x00" in raw:
        raise PathValidationError("The path contains an invalid character.")
    path = normalise(raw)
    if not os.path.exists(path):
        raise PathValidationError(f"'{path}' does not exist.")
    if os.path.islink(path):
        raise PathValidationError(f"'{path}' is a symbolic link. Enter the real directory "
                                  f"({os.path.realpath(path)}) - links are not followed.")
    if not os.path.isdir(path):
        raise PathValidationError(f"'{path}' is a file, not a directory.")
    here = os.path.normcase(path)
    protected = {os.path.normcase(os.path.normpath(r)) for r in C.protected_roots()}
    virtual = [os.path.normcase(v) for v in ("/proc", "/sys", "/dev", "/run")] if os.name != "nt" else []
    if here in protected or os.path.dirname(here) == here:          # an OS folder or a drive/filesystem root
        raise PathValidationError(f"'{path}' is a system location and cannot be monitored as a whole. "
                                  "Choose a specific folder (e.g. a project, configuration or test folder).")
    if any(here.startswith(v + os.sep) for v in virtual):
        raise PathValidationError(f"'{path}' is inside a virtual file system and cannot be monitored.")
    if not os.access(path, os.R_OK | os.X_OK):
        raise PathValidationError(f"'{path}' cannot be read with the current permissions.")
    return path


def _matches(name: str, patterns: list) -> bool:
    return any(fnmatch.fnmatch(name, p) or fnmatch.fnmatch(name.lower(), p.lower()) for p in patterns)


def _ext_ok(name: str, extensions: list) -> bool:
    if not extensions:
        return True
    exts = {e.lower() if e.startswith(".") else "." + e.lower() for e in extensions}
    return os.path.splitext(name)[1].lower() in exts


def is_eligible(path: str, opts: ScanOptions) -> bool:
    """Would a scan with these options include this file path? (Used by the real-time monitor.)"""
    name = os.path.basename(path)
    if _matches(name, opts.exclude_files) or not _ext_ok(name, opts.extensions):
        return False
    for d in opts.directories:
        rel = os.path.relpath(path, d)
        if not rel.startswith(".."):
            return not any(_matches(part, opts.exclude_dirs) for part in rel.split(os.sep)[:-1])
    return False


def scan(opts: ScanOptions, progress=None, stop_event: threading.Event | None = None) -> ScanResult:
    """Walk every directory in opts.directories and hash eligible files."""
    t0 = time.time()
    res = ScanResult()
    seen_inodes: set = set()
    seen_dirs: set = set()
    max_bytes = float(opts.max_file_size_mb) * 1024 * 1024
    last = 0.0
    roots = []
    for d in opts.directories:
        nd = normalise(d)
        if nd not in roots:
            roots.append(nd)
    stack = list(reversed(roots))
    while stack:
        if stop_event is not None and stop_event.is_set():
            res.stopped = True
            break
        current = stack.pop()
        try:
            st = os.stat(current, follow_symlinks=opts.follow_symlinks)
            key = (st.st_dev, st.st_ino)
            if key in seen_dirs:          # overlapping selections / bind mounts: scan each directory once
                res.duplicates += 1
                continue
            seen_dirs.add(key)
            with os.scandir(current) as it:
                entries = sorted(it, key=lambda e: e.name)
        except PermissionError:
            res.errors[current] = "permission denied (directory)"
            res.error_dirs.append(current)
            continue
        except FileNotFoundError:
            res.missing_dirs.append(current)          # gone, not unreadable: its files count as deleted
            continue
        except OSError as exc:
            res.errors[current] = f"cannot list directory: {exc.strerror or exc.__class__.__name__}"
            res.error_dirs.append(current)
            continue
        subdirs = []
        for entry in entries:
            path = entry.path
            try:
                is_link = entry.is_symlink()
                if is_link and not opts.follow_symlinks:
                    res.skipped[path] = "symbolic link (not followed)"
                    continue
                if entry.is_dir(follow_symlinks=opts.follow_symlinks):
                    if _matches(entry.name, opts.exclude_dirs):
                        res.excluded += 1
                    else:
                        subdirs.append(path)
                    continue
                if not entry.is_file(follow_symlinks=opts.follow_symlinks):
                    res.skipped[path] = "not a regular file"
                    continue
                if _matches(entry.name, opts.exclude_files) or not _ext_ok(entry.name, opts.extensions):
                    res.excluded += 1
                    continue
                est = entry.stat(follow_symlinks=opts.follow_symlinks)
            except PermissionError:
                res.errors[path] = "permission denied"
                continue
            except FileNotFoundError:
                continue                       # vanished between listing and checking: not part of this scan
            except OSError as exc:
                res.errors[path] = f"cannot read metadata: {exc.strerror or exc.__class__.__name__}"
                continue
            key = (est.st_dev, est.st_ino)
            if key in seen_inodes:
                res.duplicates += 1
                continue
            seen_inodes.add(key)
            if est.st_size > max_bytes:
                res.skipped[path] = f"larger than {opts.max_file_size_mb:g} MB"
                continue
            if len(res.records) >= opts.max_files:
                res.limit_reached = True
                break
            rec: FileRecord = hash_file(path, follow_symlinks=opts.follow_symlinks)
            if rec.ok:
                res.records[rec.path] = rec
            elif rec.error == "missing":
                continue                       # deleted during the scan: it will show as deleted next time
            else:
                res.errors[rec.path] = rec.error
            if progress and time.time() - last > 0.2:
                last = time.time()
                progress(len(res.records), len(res.errors), current)
        if res.limit_reached:
            break
        stack.extend(reversed(subdirs))
    res.duration = round(time.time() - t0, 3)
    if progress:
        progress(len(res.records), len(res.errors), "done")
    return res
