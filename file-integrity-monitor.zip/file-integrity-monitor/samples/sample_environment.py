"""
Synthetic sample environment - SIMULATED DATA for demonstrations.

Every function here works ONLY inside samples/monitored_folder. Paths are resolved and checked before any
write or delete, so a simulation can never touch a real file outside the sample folder.

    python samples/sample_environment.py reset      # restore the original sample files
    python samples/sample_environment.py modify     # modify config.txt
    python samples/sample_environment.py delete     # delete documents/report.txt
    python samples/sample_environment.py new        # create documents/unexpected_notes.txt and tools/update.sh
    python samples/sample_environment.py multiple   # modify users.txt, system_settings.txt and application.log
    python samples/sample_environment.py none       # do nothing (scan should report no changes)
"""

from __future__ import annotations

import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config as C  # noqa: E402

BANNER = "# SIMULATED DATA - fictional sample file for the File Integrity Monitoring demo\n"
SAMPLE_FILES = {
    "config.txt": BANNER + "app_name = ExampleApp\nlisten_port = 8080\ndebug = false\nlog_level = INFO\n"
                           "admin_email = admin@example.com\n",
    "users.txt": BANNER + "alice   role=admin    team=ops\nbob     role=user     team=dev\n"
                          "charlie role=user     team=finance\n",
    "system_settings.txt": BANNER + "backup_schedule = daily 02:00\nretention_days = 30\nfirewall = enabled\n"
                                    "auto_update = true\n",
    os.path.join("logs", "application.log"): BANNER + "2026-11-01 09:00:01 INFO  ExampleApp started\n"
                                                       "2026-11-01 09:05:12 INFO  User alice signed in\n"
                                                       "2026-11-01 17:30:44 INFO  Nightly report generated\n",
    os.path.join("documents", "report.txt"): BANNER + "Quarterly summary (fictional)\n"
                                                       "Revenue: 1,000 units of example currency\n"
                                                       "Status: on track\n",
}


class UnsafeSamplePath(ValueError):
    pass


def sample_root() -> Path:
    return C.SAMPLE_FOLDER.resolve()


def safe_path(relative: str) -> Path:
    """Resolve a path relative to the sample folder and refuse anything outside it."""
    root = sample_root()
    p = (root / relative).resolve()
    if p != root and root not in p.parents:
        raise UnsafeSamplePath(f"Refusing to touch {p}: simulations only work inside {root}")
    return p


def _stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def reset_sample() -> list[str]:
    """Recreate the sample folder with its original content (removes extra simulated files)."""
    root = C.SAMPLE_FOLDER
    if root.exists():
        resolved = root.resolve()
        if resolved.name != "monitored_folder" or resolved.parent != C.SAMPLES_DIR.resolve():
            raise UnsafeSamplePath(f"Unexpected sample folder location: {resolved}")
        shutil.rmtree(resolved)
    written = []
    for rel, content in SAMPLE_FILES.items():
        p = safe_path(rel)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        written.append(str(p))
    return written


def simulate_modification(relative: str = "config.txt") -> str:
    p = safe_path(relative)
    with open(p, "a", encoding="utf-8") as fh:
        fh.write(f"debug = true   # changed by simulation at {_stamp()}\n")
    return f"Modified {p}"


def simulate_deletion(relative: str = os.path.join("documents", "report.txt")) -> str:
    p = safe_path(relative)
    if p.exists():
        p.unlink()
        return f"Deleted {p}"
    return f"{p} was already deleted"


def simulate_new_file() -> str:
    a = safe_path(os.path.join("documents", "unexpected_notes.txt"))
    a.write_text(BANNER + f"Unexpected file created by simulation at {_stamp()}\n", encoding="utf-8")
    b = safe_path(os.path.join("tools", "update.sh"))
    b.parent.mkdir(exist_ok=True)
    b.write_text("#!/bin/sh\n# SIMULATED DATA - harmless placeholder script, never executed by the monitor\n"
                 "echo 'this is only a demo'\n", encoding="utf-8")
    return f"Created {a} and {b}"


def simulate_multiple() -> str:
    changed = []
    for rel in ("users.txt", "system_settings.txt", os.path.join("logs", "application.log")):
        p = safe_path(rel)
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(f"# edited by simulation at {_stamp()}\n")
        changed.append(p.name)
    return "Modified " + ", ".join(changed)


def simulate_no_change() -> str:
    return "No files were changed - the next scan should report everything as unchanged."


ACTIONS = {"reset": reset_sample, "modify": simulate_modification, "delete": simulate_deletion,
           "new": simulate_new_file, "multiple": simulate_multiple, "none": simulate_no_change}

if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "reset"
    if action not in ACTIONS:
        print("usage: python samples/sample_environment.py [" + "|".join(ACTIONS) + "]")
        sys.exit(2)
    out = ACTIONS[action]()
    print(out if isinstance(out, str) else f"Sample folder reset: {len(out)} files in {C.SAMPLE_FOLDER}")
