@echo off
REM One-time setup on Windows: virtual environment + dependencies.
cd /d "%~dp0"
python -m venv venv
venv\Scripts\python -m pip install --upgrade pip
venv\Scripts\python -m pip install -r requirements.txt
venv\Scripts\python samples\sample_environment.py reset
echo.
echo Done. Start the dashboard with run.bat
