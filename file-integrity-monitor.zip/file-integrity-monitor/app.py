"""
File Integrity Monitoring System - Streamlit entry point.

    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from dashboard import (about_page, alerts_page, baseline_page, explorer_page, overview, realtime_page,  # noqa: E402
                       reports_page, scanner_page, settings_page)
from dashboard.common import css, get_settings, selected_baseline  # noqa: E402
from monitoring.realtime_monitor import get_monitor  # noqa: E402

PAGES = {
    "Overview Dashboard": ("📊", overview.render),
    "Create Baseline": ("🔒", baseline_page.render),
    "File Scanner": ("🔍", scanner_page.render),
    "Real-Time Monitoring": ("📡", realtime_page.render),
    "File Explorer": ("🗂️", explorer_page.render),
    "Alerts": ("🚨", alerts_page.render),
    "Reports": ("📄", reports_page.render),
    "Settings": ("⚙️", settings_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def main() -> None:
    st.set_page_config(page_title="File Integrity Monitor", page_icon="🛡️", layout="wide",
                       initial_sidebar_state="expanded")
    st.markdown(css(), unsafe_allow_html=True)
    get_settings()
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Overview Dashboard"
    with st.sidebar:
        st.markdown("## 🛡️ File Integrity Monitor")
        st.caption(f"SHA-256 · v{C.APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        b = selected_baseline()
        if b:
            st.markdown(f"**Baseline #{b['baseline_id']}** · {b['status']}")
            st.caption(f"{b['file_count']} files · {b['created_at']}")
        else:
            st.caption("No baseline yet.")
        mon = get_monitor()
        st.caption(("📡 real-time monitoring ON" if mon is not None and mon.running else "📡 real-time monitoring off")
                   + " · 🔒 read-only")
    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException") for c in type(exc).__mro__):
            raise
        st.error("Something went wrong on this page. Please check the input and try again.")
        if "--debug" in sys.argv:
            st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
