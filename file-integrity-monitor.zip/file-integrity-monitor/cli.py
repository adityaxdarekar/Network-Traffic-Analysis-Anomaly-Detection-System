"""
Command-line interface - useful for scheduled (periodic) integrity checks.

    python cli.py baseline samples/monitored_folder            # create a baseline
    python cli.py baseline samples/monitored_folder --replace  # replace it (explicit confirmation flag)
    python cli.py scan                                          # scan the newest active baseline
    python cli.py scan --baseline 2 --pdf report.pdf
    python cli.py watch --mode watchdog                         # real-time monitoring until Ctrl+C
    python cli.py list                                          # list baselines

Exit code of `scan`: 0 = no changes, 1 = changes detected, 2 = error - handy for cron / Task Scheduler.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from core.baseline_manager import BaselineExistsError, BaselineManager  # noqa: E402
from core.file_scanner import PathValidationError  # noqa: E402
from core.integrity_checker import IntegrityChecker  # noqa: E402
from database.db_manager import DatabaseManager  # noqa: E402


def cmd_baseline(db, args) -> int:
    try:
        r = BaselineManager(db).create_baseline(args.directories, C.load_settings(), name=args.name or "",
                                                confirm_replace=args.replace)
    except BaselineExistsError as exc:
        print(f"{exc}\nRe-run with --replace if the current files are authorized.")
        return 2
    except PathValidationError as exc:
        print(f"Error: {exc}")
        return 2
    sc = r["scan"]
    print(f"Baseline #{r['baseline_id']} created: {sc.files_scanned} files hashed (SHA-256) in {sc.duration}s, "
          f"{len(sc.errors)} errors, {len(sc.skipped)} skipped, {sc.excluded} excluded"
          + (f"; baseline #{r['replaced']} kept as Superseded" if r["replaced"] else ""))
    return 0


def _baseline_id(db, args) -> int | None:
    if args.baseline:
        return args.baseline
    b = BaselineManager(db).latest_active()
    return b["baseline_id"] if b else None


def cmd_scan(db, args) -> int:
    bid = _baseline_id(db, args)
    if not bid:
        print("No baseline - create one first: python cli.py baseline <directory>")
        return 2
    ic = IntegrityChecker(db, C.load_settings())
    rep = ic.run_scan(bid, trigger="cli")
    c = rep.counts
    print(f"Scan #{rep.scan_id} of baseline #{bid}: {rep.scan.files_scanned} files · unchanged {c['UNCHANGED']} · "
          f"modified {c['MODIFIED']} · deleted {c['DELETED']} · new {c['NEW']} · inaccessible {c['INACCESSIBLE']}")
    for ch in rep.changes:
        if ch.status not in ("UNCHANGED",):
            print(f"  {ch.status:<12} {ch.path}  {(ch.baseline_hash or '-')[:12]} -> {(ch.current_hash or '-')[:12]}"
                  + (f"  ({ch.detail})" if ch.status in ("INACCESSIBLE", "SKIPPED") else ""))
    print(f"Alerts: {len(rep.alerts.created)} new, {rep.alerts.repeated} already reported, "
          f"{rep.alerts.cleared} cleared")
    if args.pdf:
        from reports.pdf_generator import generate_pdf_report
        print("PDF report:", generate_pdf_report(db, bid, args.pdf))
    return 1 if any(c[k] for k in ("MODIFIED", "DELETED", "NEW")) else 0


def cmd_watch(db, args) -> int:
    from monitoring.realtime_monitor import RealtimeMonitor
    bid = _baseline_id(db, args)
    if not bid:
        print("No baseline - create one first.")
        return 2
    m = RealtimeMonitor(db, bid, C.load_settings(), args.mode)
    m.start()
    print(f"Monitoring baseline #{bid} ({m.mode}) - press Ctrl+C to stop.")
    shown = 0
    try:
        while True:
            time.sleep(0.5)
            events = list(m.events)[::-1]
            for e in events[shown:]:
                print(f"[{e['time']}] {e['event']:<11} {e['path']} -> {e['result']} {e['alerts']}", flush=True)
            shown = len(events)
    except KeyboardInterrupt:
        m.stop()
        print("\nStopped.")
    return 0


def cmd_list(db, args) -> int:
    df = BaselineManager(db).list()
    print("No baselines." if df.empty else df[["baseline_id", "name", "status", "file_count", "created_at",
                                               "directories"]].to_string(index=False))
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=C.APP_TITLE)
    p.add_argument("--db", help="database file (default output/fim.db)")
    sub = p.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("baseline", help="create a baseline")
    b.add_argument("directories", nargs="+")
    b.add_argument("--name")
    b.add_argument("--replace", action="store_true", help="confirm replacing an existing active baseline")
    s = sub.add_parser("scan", help="integrity scan against a baseline")
    s.add_argument("--baseline", type=int)
    s.add_argument("--pdf")
    w = sub.add_parser("watch", help="real-time monitoring")
    w.add_argument("--baseline", type=int)
    w.add_argument("--mode", choices=["watchdog", "watchdog-polling", "periodic-scan"])
    sub.add_parser("list", help="list baselines")
    args = p.parse_args(argv)
    db = DatabaseManager(args.db) if args.db else DatabaseManager()
    return {"baseline": cmd_baseline, "scan": cmd_scan, "watch": cmd_watch, "list": cmd_list}[args.cmd](db, args)


if __name__ == "__main__":
    sys.exit(main())
