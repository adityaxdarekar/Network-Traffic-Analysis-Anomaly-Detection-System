"""
PDF integrity monitoring report (ReportLab + a matplotlib chart).

Sections: 1 Summary · 2 Baseline and scope · 3 Latest scan results · 4 Modified files (previous/current SHA-256) ·
5 Deleted files · 6 New files · 7 Inaccessible / skipped files · 8 Security alerts and severity distribution ·
9 Recommended investigation steps · 10 Conclusion

Only paths, sizes, timestamps and hashes are included - never file contents.
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import CondPageBreak, Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle  # noqa

import config as C  # noqa: E402
from core.alert_manager import AlertManager  # noqa: E402
from core.baseline_manager import BaselineManager  # noqa: E402
from core.integrity_checker import IntegrityChecker  # noqa: E402
from database.db_manager import DatabaseManager  # noqa: E402

NAVY, BLUE = colors.HexColor("#0b1f3a"), colors.HexColor("#2563eb")
LIGHT, BORDER = colors.HexColor("#f1f5f9"), colors.HexColor("#cbd5e1")
TEXT, MUTED = colors.HexColor("#0f172a"), colors.HexColor("#64748b")
SEV_BG = {"HIGH": "#fee2e2", "CRITICAL": "#fecaca", "MEDIUM": "#fef3c7", "LOW": "#dcfce7", "WARNING": "#ede9fe",
          "INFO": "#f1f5f9"}
STATUS_BG = {"MODIFIED": "#fef3c7", "DELETED": "#fee2e2", "NEW": "#dbeafe", "INACCESSIBLE": "#ede9fe",
             "SKIPPED": "#f1f5f9", "UNCHANGED": "#dcfce7"}
PAGE_W, PAGE_H = A4
MARGIN = 1.7 * cm
WIDTH = PAGE_W - 2 * MARGIN
STEPS = [
    "Confirm whether each change was authorized: check change tickets, software updates, deployments and the file owner.",
    "For unexpected modifications, compare the file with a trusted backup or version control and review the differences.",
    "Review system and authentication logs (who was logged in, which processes ran) around the modification time.",
    "For deleted files, restore from backup if needed and find out which account removed them.",
    "Treat unknown new scripts or executables with caution: do not run them; inspect them in an isolated environment.",
    "Fix permissions for inaccessible files, or run the scan with appropriate rights, then re-scan.",
    "After authorized changes are verified, create a new baseline (explicit, confirmed action) so future scans "
    "compare against the new trusted state.",
]

ST = {
    "title": ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=18, leading=22, textColor=NAVY),
    "sub": ParagraphStyle("s", fontName="Helvetica", fontSize=9.5, leading=13, textColor=MUTED, spaceAfter=8),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=13, leading=17, textColor=NAVY, spaceBefore=12,
                         spaceAfter=6),
    "body": ParagraphStyle("b", fontName="Helvetica", fontSize=9.2, leading=13, textColor=TEXT, spaceAfter=4),
    "small": ParagraphStyle("sm", fontName="Helvetica", fontSize=7.8, leading=10.2, textColor=MUTED),
    "cell": ParagraphStyle("c", fontName="Helvetica", fontSize=7.6, leading=9.6, textColor=TEXT),
    "wrap": ParagraphStyle("w", fontName="Helvetica", fontSize=7.6, leading=9.6, textColor=TEXT, wordWrap="CJK"),
    "mono": ParagraphStyle("m", fontName="Courier", fontSize=6.6, leading=8.4, textColor=TEXT, wordWrap="CJK"),
    "cellb": ParagraphStyle("cb", fontName="Helvetica-Bold", fontSize=7.6, leading=9.6, textColor=colors.white),
    "bullet": ParagraphStyle("bu", fontName="Helvetica", fontSize=9, leading=12.5, textColor=TEXT, leftIndent=12,
                             bulletIndent=2, spaceAfter=2),
}


def h(v) -> str:
    """Hash or '-' (pandas turns missing values into NaN)."""
    return v if isinstance(v, str) and v else "-"


def esc(v, limit=400) -> str:
    s = "-" if v is None or str(v) in ("", "nan", "None", "NaT") else str(v)
    return escape(s if len(s) <= limit else s[:limit] + "…")


def table(header, rows, widths, mono_cols=(), wrap_cols=(), color_col=None, palette=None):
    data = [[Paragraph(escape(h), ST["cellb"]) for h in header]]
    for r in rows:
        data.append([Paragraph(esc(c), ST["mono"] if j in mono_cols else ST["wrap"] if j in wrap_cols else ST["cell"])
                     for j, c in enumerate(r)])
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if color_col is not None and palette:
        for i, r in enumerate(rows, 1):
            if r[color_col] in palette:
                style.append(("BACKGROUND", (color_col, i), (color_col, i), colors.HexColor(palette[r[color_col]])))
    t.setStyle(TableStyle(style))
    return t


def kv(rows):
    t = Table([[Paragraph(f"<b>{escape(k)}</b>", ST["cell"]), Paragraph(esc(v), ST["wrap"])] for k, v in rows],
              colWidths=[4.6 * cm, WIDTH - 4.6 * cm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t


def kpis(items):
    t = Table([[Paragraph(f"<font size=15><b>{escape(str(v))}</b></font><br/><font size=7.5 color='#64748b'>"
                          f"{escape(k)}</font>", ST["cell"]) for k, v in items]],
              colWidths=[WIDTH / len(items)] * len(items))
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.6, BORDER),
                           ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 7),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return t


def bar_chart(counts: dict, title: str, palette: dict) -> Image | None:
    items = [(k, v) for k, v in counts.items() if v]
    if not items:
        return None
    fig, ax = plt.subplots(figsize=(7, 2.0), dpi=150)
    ax.barh([k for k, _ in items], [v for _, v in items],
            color=[palette.get(k, "#3b82f6") for k, _ in items])
    for i, (_, v) in enumerate(items):
        ax.text(v, i, f" {v}", va="center", fontsize=7)
    ax.set_title(title, fontsize=8, loc="left")
    ax.tick_params(labelsize=7)
    ax.xaxis.get_major_locator().set_params(integer=True)
    ax.invert_yaxis()
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return Image(buf, width=WIDTH, height=WIDTH * 2.0 / 7)


def _page(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, PAGE_H - 1.15 * cm, PAGE_W, 1.15 * cm, stroke=0, fill=1)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 8.5)
    canvas.drawString(MARGIN, PAGE_H - 0.75 * cm, "File Integrity Monitoring Report (SHA-256)")
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 0.75 * cm, f"Baseline #{doc.baseline_id}")
    canvas.setFillColor(MUTED)
    canvas.drawString(MARGIN, 0.95 * cm, "Metadata and hashes only - no file contents. Read-only monitoring.")
    canvas.drawRightString(PAGE_W - MARGIN, 0.95 * cm, f"Page {doc.page}")
    canvas.restoreState()


def _fmt_ts(v):
    try:
        return datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S") if v not in (None, "") else "-"
    except (TypeError, ValueError, OSError):
        return "-"


def build_story(db: DatabaseManager, baseline_id: int, analyst: str = "") -> list:
    bm, ic, am = BaselineManager(db), IntegrityChecker(db), AlertManager(db)
    b = bm.get(baseline_id)
    if not b:
        raise ValueError(f"Baseline {baseline_id} does not exist")
    latest = ic.latest_scan(baseline_id)
    files = ic.scan_files(latest["scan_id"]) if latest else None
    alerts = am.list(baseline_id)
    by_status = (files["status"].value_counts().to_dict() if files is not None and not files.empty else {})
    story = [Paragraph("File Integrity Monitoring Report", ST["title"]),
             Paragraph(f"{escape(C.APP_TITLE)} using {escape(C.APP_SUBTITLE)} · v{C.APP_VERSION}", ST["sub"])]
    story.append(kv([("Report generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                     ("Baseline ID / name", f"#{b['baseline_id']} · {b['name']}"),
                     ("Monitored directory", "; ".join(b["directories"])),
                     ("Baseline created", b["created_at"]), ("Baseline status", b["status"]),
                     ("Latest scan", f"#{latest['scan_id']} at {latest['scanned_at']}" if latest else "no scan yet"),
                     ("Prepared by", analyst or "-")]))
    story.append(Spacer(1, 8))

    story.append(Paragraph("1. Summary", ST["h1"]))
    story.append(kpis([("Files in baseline", b["file_count"]),
                       ("Files scanned", latest["total_files"] if latest else 0),
                       ("Modified", by_status.get("MODIFIED", 0)), ("Deleted", by_status.get("DELETED", 0)),
                       ("New", by_status.get("NEW", 0)), ("Inaccessible", by_status.get("INACCESSIBLE", 0)),
                       ("Alerts", len(alerts))]))
    changed = sum(by_status.get(k, 0) for k in ("MODIFIED", "DELETED", "NEW"))
    text = (f"The trusted baseline contains {b['file_count']} files. " +
            (f"The latest scan checked {latest['total_files']} files and found {changed} integrity change(s): "
             f"{by_status.get('MODIFIED', 0)} modified, {by_status.get('DELETED', 0)} deleted and "
             f"{by_status.get('NEW', 0)} new file(s); {by_status.get('INACCESSIBLE', 0)} file(s) could not be verified. "
             if latest else "No integrity scan has been run yet. ") +
            f"{len(alerts)} security alert(s) are recorded for this baseline. A detected change is not proof of "
            "malicious activity - authorised edits and software updates also change files.")
    story.append(Spacer(1, 6))
    story.append(Paragraph(escape(text), ST["body"]))

    story.append(Paragraph("2. Baseline and scope", ST["h1"]))
    o = b["options"]
    story.append(kv([("Hash algorithm", "SHA-256 (hashlib), files read in binary 1 MiB chunks"),
                     ("File extensions", ", ".join(o.get("extensions") or []) or "all files"),
                     ("Excluded folders", ", ".join(o.get("exclude_dirs") or [])),
                     ("Excluded file patterns", ", ".join(o.get("exclude_files") or [])),
                     ("Symbolic links", "followed" if o.get("follow_symlinks") else "not followed"),
                     ("Maximum file size", f"{o.get('max_file_size_mb')} MB"),
                     ("Skipped at baseline", f"{len(b['skipped'])} item(s)"),
                     ("Errors at baseline", b["error_count"])]))

    if files is not None and not files.empty:
        story.append(Paragraph("3. Latest scan results", ST["h1"]))
        chart = bar_chart({s: by_status.get(s, 0) for s in ["UNCHANGED", "MODIFIED", "DELETED", "NEW", "INACCESSIBLE",
                                                             "SKIPPED"]}, "File integrity status",
                          {"UNCHANGED": "#22c55e", "MODIFIED": "#f59e0b", "DELETED": "#ef4444", "NEW": "#3b82f6",
                           "INACCESSIBLE": "#a78bfa", "SKIPPED": "#94a3b8"})
        if chart:
            story.append(chart)
        sections = [("4. Modified files", "MODIFIED"), ("5. Deleted files", "DELETED"), ("6. New files", "NEW"),
                    ("7. Inaccessible and skipped files", ("INACCESSIBLE", "SKIPPED"))]
        for title, st_ in sections:
            part = files[files["status"].isin(st_ if isinstance(st_, tuple) else (st_,))]
            story.append(CondPageBreak(4 * cm))
            story.append(Paragraph(title, ST["h1"]))
            if part.empty:
                story.append(Paragraph("None.", ST["body"]))
                continue
            if st_ == "MODIFIED":
                story.append(table(["File", "Previous SHA-256", "Current SHA-256", "Modified"],
                                   [[r.file_path, r.baseline_hash, r.current_hash, _fmt_ts(r.current_mtime)]
                                    for r in part.itertuples()],
                                   [4.6 * cm, 5.0 * cm, 5.0 * cm, WIDTH - 14.6 * cm], mono_cols=(1, 2),
                                   wrap_cols=(0,)))
            elif st_ == "DELETED":
                story.append(table(["File", "Original SHA-256", "Last known size"],
                                   [[r.file_path, r.baseline_hash, f"{int(r.baseline_size):,} B"
                                     if r.baseline_size == r.baseline_size else "-"] for r in part.itertuples()],
                                   [6.4 * cm, 8.0 * cm, WIDTH - 14.4 * cm], mono_cols=(1,), wrap_cols=(0,)))
            elif st_ == "NEW":
                story.append(table(["File", "Current SHA-256", "Size"],
                                   [[r.file_path, r.current_hash, f"{int(r.current_size):,} B"
                                     if r.current_size == r.current_size else "-"] for r in part.itertuples()],
                                   [6.4 * cm, 8.0 * cm, WIDTH - 14.4 * cm], mono_cols=(1,), wrap_cols=(0,)))
            else:
                story.append(table(["File", "Status", "Reason"], [[r.file_path, r.status, r.detail]
                                                                  for r in part.itertuples()],
                                   [8 * cm, 2.6 * cm, WIDTH - 10.6 * cm], wrap_cols=(0,)))

    story.append(CondPageBreak(5 * cm))
    story.append(Paragraph("8. Security alerts", ST["h1"]))
    if alerts.empty:
        story.append(Paragraph("No security alerts were generated for this baseline.", ST["body"]))
    else:
        sev = alerts["severity"].value_counts().to_dict()
        story.append(Paragraph("Severity distribution: " + escape(", ".join(f"{k} {sev[k]}" for k in
                                                                            reversed(C.SEVERITIES) if k in sev)),
                               ST["body"]))
        story.append(table(["ID", "Detected", "Event", "Severity", "Status", "File", "Previous / current SHA-256"],
                           [[a.alert_id, a.created_at, C.EVENT_LABELS.get(a.event_type, a.event_type), a.severity,
                             a.status, a.file_path, f"{h(a.previous_hash)} / {h(a.current_hash)}"]
                            for a in alerts.itertuples()],
                           [0.9 * cm, 2.3 * cm, 2.4 * cm, 1.6 * cm, 1.8 * cm, 3.8 * cm, WIDTH - 12.8 * cm],
                           mono_cols=(6,), wrap_cols=(5,), color_col=3, palette=SEV_BG))
        story.append(Paragraph("Each alert records the previous (baseline) and current SHA-256. Repeated scans of an "
                               "unchanged condition do not create duplicate alerts; a further change creates a new "
                               "alert.", ST["small"]))

    story.append(CondPageBreak(5 * cm))
    story.append(Paragraph("9. Recommended investigation steps", ST["h1"]))
    story += [Paragraph(escape(s), ST["bullet"], bulletText="•") for s in STEPS]
    story.append(Paragraph("10. Conclusion", ST["h1"]))
    if latest and changed:
        concl = (f"The monitored files no longer fully match the trusted baseline: {changed} change(s) were detected "
                 "by comparing SHA-256 hashes. Each change should be verified as authorized or investigated using the "
                 "steps above. No file was modified, repaired or deleted by the monitoring system.")
    elif latest:
        concl = ("All verified files match the trusted baseline - no modification, deletion or new file was detected "
                 "in the latest scan.")
    else:
        concl = "A baseline has been recorded. Run an integrity scan to compare the current state with it."
    story.append(Paragraph(escape(concl), ST["body"]))
    return story


def generate_pdf_bytes(db: DatabaseManager, baseline_id: int, analyst: str = "") -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=1.8 * cm,
                            bottomMargin=1.6 * cm, title="File Integrity Monitoring Report", author=C.APP_TITLE)
    doc.baseline_id = baseline_id
    doc.build(build_story(db, baseline_id, analyst), onFirstPage=_page, onLaterPages=_page)
    return buf.getvalue()


def generate_pdf_report(db: DatabaseManager, baseline_id: int, output_path: Path | str | None = None,
                        analyst: str = "") -> Path:
    path = Path(output_path) if output_path else \
        C.REPORT_DIR / f"integrity_report_baseline{baseline_id}_{datetime.now():%Y%m%d_%H%M%S}.pdf"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(generate_pdf_bytes(db, baseline_id, analyst))
    return path
