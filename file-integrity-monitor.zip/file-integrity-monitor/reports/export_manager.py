"""CSV and JSON exports (metadata and hashes only - never file contents)."""

from __future__ import annotations

import io
from datetime import datetime

import pandas as pd

from core.baseline_manager import BaselineManager
from core.integrity_checker import IntegrityChecker
from database.db_manager import DatabaseManager


def stamp(kind: str, ext: str, baseline_id: int | None = None) -> str:
    return f"{kind}{f'_baseline{baseline_id}' if baseline_id else ''}_{datetime.now():%Y%m%d_%H%M%S}.{ext}"


def _ts(v):
    try:
        return datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S") if v not in (None, "") and \
            not pd.isna(v) else ""
    except (TypeError, ValueError, OSError):
        return ""


def inventory(db: DatabaseManager, baseline_id: int) -> pd.DataFrame:
    """Current file inventory: baseline files + latest scan status (falls back to the baseline if no scan yet)."""
    ic = IntegrityChecker(db)
    latest = ic.latest_scan(baseline_id)
    if latest:
        df = ic.scan_files(latest["scan_id"])
        out = pd.DataFrame({
            "file_name": df["file_path"].map(lambda p: p.replace("\\", "/").rsplit("/", 1)[-1]),
            "file_path": df["file_path"], "status": df["status"],
            "file_size": df["current_size"].fillna(df["baseline_size"]).astype("Int64"),
            "current_sha256": df["current_hash"], "baseline_sha256": df["baseline_hash"],
            "last_modified": df["current_mtime"].fillna(df["baseline_mtime"]).map(_ts), "detail": df["detail"]})
        out.attrs["scan"] = latest
        return out
    files = BaselineManager(db).files(baseline_id)
    return pd.DataFrame({
        "file_name": files["file_path"].map(lambda p: p.replace("\\", "/").rsplit("/", 1)[-1]) if len(files) else [],
        "file_path": files.get("file_path", []), "status": "BASELINE (not scanned yet)",
        "file_size": files.get("file_size", []), "current_sha256": None,
        "baseline_sha256": files.get("sha256", []), "last_modified": files.get("modified_at", pd.Series()).map(_ts),
        "detail": ""})


def to_csv(df: pd.DataFrame) -> str:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue()


def inventory_csv(db, baseline_id) -> str:
    return to_csv(inventory(db, baseline_id))


def comparison_csv(db, scan_id: int) -> str:
    df = IntegrityChecker(db).scan_files(scan_id)
    for c in ("baseline_mtime", "current_mtime"):
        if c in df:
            df[c] = df[c].map(_ts)
    return to_csv(df)


def alerts_csv(db, baseline_id: int | None = None) -> str:
    from core.alert_manager import AlertManager
    return to_csv(AlertManager(db).list(baseline_id))
