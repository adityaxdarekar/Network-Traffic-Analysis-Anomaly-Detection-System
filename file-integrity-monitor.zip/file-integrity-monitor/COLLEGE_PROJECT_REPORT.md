# File Integrity Monitoring System Using Python and SHA-256 Hashing
### College Project Report — Cybersecurity

---

## Abstract
Unauthorised changes to files are one of the most common traces of a system compromise: modified
configuration files, replaced scripts, deleted logs or newly dropped executables. This project designs and
implements a File Integrity Monitoring (FIM) system in Python. The system records a trusted baseline of
selected directories, storing for each file its path, size, modification time and SHA-256 hash in an SQLite
database. Later scans recompute the hashes and classify every file as unchanged, modified, deleted, new or
inaccessible. Each relevant change produces a severity-classified alert with an explanation, a recommended
action and an investigation status, and duplicate alerts for unchanged conditions are suppressed. Optional
real-time monitoring uses the watchdog library with debouncing. A Streamlit dashboard, a command-line
interface and PDF/CSV/JSON reports make the results usable. The system is strictly read-only towards
monitored files. It was verified with 116 automated tests, five scripted demonstration scenarios and read-only
scans of real system folders of up to 31,188 files.

## 1. Introduction
Integrity is one of the three goals of information security (confidentiality, integrity, availability). A
file has integrity when it has not been altered in an unauthorised way. File Integrity Monitoring is the
control that checks this, and it is required or recommended by common security standards. One example is
control SI-7 "Software, Firmware, and Information Integrity" in NIST SP 800-53. Commercial and open-source
tools such as Tripwire, AIDE, OSSEC/Wazuh and Samhain implement FIM. This project builds a simplified but
complete FIM from first principles to show how hashing, baselines, change detection and alerting work together.

## 2. Problem statement
Changes made by attackers or by mistake are hard to see. A one-line edit in a user list or a replaced script
keeps its file name, and its size and timestamp can look normal (timestamps can even be forged). Manual
checking is not feasible for thousands of files. The problem is to build a tool that:
- detects every content change reliably,
- distinguishes modifications, deletions, new files and unreadable files correctly,
- reports changes in an understandable, prioritised way without flooding the analyst with duplicates, and
- never alters the files it protects.

## 3. Existing system
- **Manual inspection:** comparing listings or opening files by hand. Slow, error-prone, impossible at scale.
- **Timestamp/size checks** (e.g. `ls -l`, backup tools): fast but unreliable. Content can change while the
  size stays the same, and timestamps can be reset with `touch`.
- **Enterprise FIM tools** (Tripwire, OSSEC/Wazuh, AIDE): powerful, but complex to configure. Many are
  command-line or agent based and not well suited to learning how FIM works internally.

## 4. Proposed system
A Python application that:
- builds SHA-256 baselines of user-selected folders, with filters and safety limits,
- versions baselines and requires confirmation before replacing one,
- detects changes with clear rules (an unreadable file is never "deleted"; a timestamp-only change is not a
  modification),
- raises explained, severity-classified alerts without duplicates and with a status workflow,
- monitors in real time (watchdog), by polling or by periodic scans, and
- offers a 9-page dashboard, a CLI for scheduled use, and PDF/CSV/JSON reports.

## 5. Objectives
1. Safe, efficient SHA-256 hashing (binary, 1 MiB chunks, read-only, robust to errors and to files changing
   during hashing).
2. Recursive, filtered, bounded scanning without following symbolic links.
3. Versioned baselines in SQLite with confirmed replacement.
4. Correct classification of modified, deleted, new, inaccessible and skipped files.
5. Explained, configurable, deduplicated alerts with a status workflow.
6. Real-time monitoring with debouncing.
7. Professional reports and automated tests.

## 6. Scope
**In scope:**
- monitoring user-selected local folders on Linux, Windows and macOS
- content integrity (SHA-256), deletion and creation of files
- local storage, a local dashboard and local reports

**Out of scope:**
- identifying the user or process responsible
- monitoring permissions and ownership
- multi-host or agent deployment
- tamper-proof storage of the baseline
- kernel-level protection
- automatic restoration (deliberately excluded for safety)

## 7. Hardware requirements
| Component | Minimum | Recommended |
|---|---|---|
| Processor | dual-core 64-bit | quad-core |
| RAM | 4 GB | 8 GB |
| Disk | 500 MB free (application and venv) | SSD for large scans |
| Display | 1280×720 | 1920×1080 |

## 8. Software requirements
| Software | Version |
|---|---|
| OS | Windows 10/11, Ubuntu/Kali/Debian, macOS |
| Python | 3.11 or newer |
| Libraries | streamlit, pandas, plotly, watchdog, reportlab, matplotlib, pytest, pypdf (requirements.txt) |
| Standard library | hashlib, sqlite3, os, pathlib, stat, fnmatch, threading |
| Browser | any modern browser for the dashboard |

## 9. System architecture
```
 User ──► Streamlit dashboard (9 pages) / CLI
                 │
   ┌─────────────┼───────────────────────┬────────────────────────────┐
   ▼             ▼                       ▼                            ▼
 Baseline     Integrity checker     Real-time monitor            Reports
 manager      (scan + compare)      (watchdog / polling /        (PDF, CSV, JSON)
   │             │                   periodic, debounced)            ▲
   └──► File scanner ──► Hash engine (SHA-256)    │                  │
                 │                                │                  │
          Change detector ──► Alert manager ◄─────┘                  │
                                   │                                 │
                          SQLite database (baselines, baseline_files, file_scans,
                                           scan_files, security_alerts) ─────────┘
```
**Data model:**
| Table | Contents |
|---|---|
| baselines | id, name, created_at, directories, file_count, total_size, options, status (Active/Superseded) |
| baseline_files | baseline_id, path, size, mtime, sha256 |
| file_scans | id, baseline_id, time, counts per status, alerts created, trigger, duration |
| scan_files | per-file result of every scan |
| security_alerts | id, time, baseline_id, path, event, previous and current hash, severity, explanation, action, status, active, times_seen, last_seen, source |

## 10. Module descriptions
| Module | Responsibility |
|---|---|
| `config.py` | default settings (extensions, exclusions, limits, severities, critical/executable patterns), protected system paths, load/save of user settings |
| `core/hash_engine.py` | SHA-256 of one file: read-only open with `O_NOFOLLOW`, regular files only, 1 MiB chunks, stability check with up to 3 re-hashes, errors returned as data |
| `core/file_scanner.py` | validation of user paths (refuses roots, OS folders, virtual filesystems, symlinks, files); iterative recursive scan; filters; size/file limits; hard-link and overlap de-duplication; progress and stop |
| `core/baseline_manager.py` | create (with confirmation for replacement), list, select, status, delete (with confirmation, never the active one), export JSON/CSV |
| `core/change_detector.py` | pure comparison of baseline and scan into UNCHANGED/MODIFIED/DELETED/NEW/INACCESSIBLE/SKIPPED |
| `core/alert_manager.py` | severity classification, explanation and action texts, deduplication (active / times_seen / cleared), status workflow, alert text format |
| `core/integrity_checker.py` | orchestrates a full scan and stores it; single-file check for real-time events |
| `monitoring/realtime_monitor.py` | watchdog observer, polling observer or periodic scans; debounce queue; worker thread; rename and folder handling; event log |
| `database/db_manager.py` | SQLite schema, indexes, thread-safe connections, queries |
| `reports/pdf_generator.py`, `export_manager.py` | PDF integrity report (10 sections with chart), CSV/JSON exports |
| `samples/sample_environment.py` | synthetic, labelled sample folder; reset and 5 simulations restricted to that folder |
| `dashboard/*`, `app.py` | Overview, Create Baseline, File Scanner, Real-Time Monitoring, File Explorer, Alerts, Reports, Settings, About |
| `cli.py` | baseline / scan / watch / list for scheduled checks (exit code 1 when changes are found) |

## 11. SHA-256 algorithm explanation
SHA-256 (FIPS 180-4) maps a message of any length to a 256-bit digest:
1. **Padding:** append bit `1`, then zeros, then the 64-bit message length, so the total length is a multiple
   of 512 bits.
2. **Parsing:** split the padded message into 512-bit blocks.
3. **Initial hash value:** eight 32-bit words H0…H7, derived from the fractional parts of the square roots of
   the first 8 primes.
4. **Message schedule:** for each block, expand 16 words into 64 words using rotations, shifts and XOR
   (σ0, σ1).
5. **Compression:** 64 rounds update working variables a…h using the functions Ch, Maj, Σ0, Σ1 and 64
   constants K (cube roots of the first 64 primes).
6. **Update:** add the result to H0…H7. After the last block, the concatenation of H0…H7 is the digest.

**Properties used by FIM:**
- determinism
- avalanche effect: one changed bit changes about half of the output bits
- pre-image resistance
- collision resistance: no practical collision for SHA-256 is known

MD5 and SHA-1 are not used because practical collisions exist for both.

Because SHA-256 processes data block by block, a file can be hashed in chunks with constant memory
(`hashlib.sha256().update(chunk)`). The engine uses this with 1 MiB chunks, so a 1 GB file needs only about
1 MiB of RAM.

## 12. Baseline generation algorithm
```
INPUT: directories D, settings S (extensions, exclusions, max size, max files), confirm flag
1. for each d in D: validate(d)          # exists, is a directory, not a symlink, not a protected/system root,
                                          # not inside /proc, /sys, /dev, /run, readable
2. if an Active baseline with the same directory set exists and not confirm:
       raise BaselineExistsError         # never replace silently
3. stack ← D; seen_dirs ← ∅; seen_files ← ∅
4. while stack not empty and not stopped:
       dir ← pop(stack); skip if (dev, inode) ∈ seen_dirs
       for entry in scandir(dir):         # errors: record dir in error_dirs (or missing_dirs if it vanished)
           if entry is symlink: skipped
           elif entry is dir: push unless name matches exclude_dirs
           elif entry is regular file and eligible (extension, exclude_files, size ≤ max):
               if (dev, inode) ∈ seen_files: duplicate, continue
               record ← hash_file(entry)  # see below
               if record.ok: records[path] ← record else errors[path] ← record.error
               if |records| ≥ max_files: limit_reached; stop
5. store baseline (status Active) and all records; mark the previous baseline Superseded
```
**hash_file(path):**
```
for attempt in 1..3:
    st1 ← lstat(path); fd ← open(path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK)
    require S_ISREG(fstat(fd)) and same inode as st1
    h ← sha256(); while chunk ← read(fd, 1 MiB): h.update(chunk)
    st2 ← lstat(path)
    if (size, mtime, inode) of st1 = st2: return (size, mtime, h.hexdigest())
return error "file kept changing while being hashed"
```
Missing files, permission errors and I/O errors are returned as error values, never raised to the user.

## 13. File change detection algorithm
```
INPUT: baseline B = {path → (hash, size, mtime)}, scan R (records, errors, skipped, error_dirs,
       missing_dirs, stopped, limit_reached)
for path in B ∪ R.records ∪ R.errors ∪ R.skipped (sorted):
    if path ∉ B:
        NEW if path ∈ R.records; INACCESSIBLE if path ∈ R.errors
    elif path ∈ R.records:
        UNCHANGED if hash equal (note if only the timestamp changed) else MODIFIED
    elif path ∈ R.errors:           INACCESSIBLE        # unreadable ≠ deleted
    elif path ∈ R.skipped:          SKIPPED             # e.g. now larger than the limit
    elif parent ∈ R.error_dirs:     INACCESSIBLE        # could not list the folder
    elif scan stopped/limited:      INACCESSIBLE        # not reached ≠ deleted
    else:                           DELETED             # (note if the whole folder is gone)
```
**Alert processing (deduplication):**
```
for each change c with status MODIFIED / DELETED / NEW / INACCESSIBLE:
    a ← active alert for (baseline, path)
    if a exists and a.event = c.status and a.current_hash = c.current_hash:
        a.times_seen += 1; a.last_seen ← now            # same condition: no new alert
    else:
        if a exists: a.active ← 0                       # superseded by a new change
        create alert with severity(c), explanation, action, status "New"
for each active alert whose path is now UNCHANGED: active ← 0   # condition gone: cleared
```
**Severity rules:**
| Event | Severity |
|---|---|
| Modified critical/config file | HIGH |
| Modified other file | MEDIUM |
| Deleted | HIGH |
| New executable/script | MEDIUM |
| New other file | LOW |
| Inaccessible | WARNING |

All of these are configurable.

**Real-time algorithm:** each file-system event puts its path into a pending map with a due time
(now + debounce). Moves add both paths, and folder events add every baseline file below the folder. A worker
thread processes due paths with `check_single_file`, so a file being written is hashed only once it has been
quiet for the debounce time.

## 14. Implementation
- **Language and structure:** Python 3.11+, about 2,800 lines of application code in the modules above and
  about 1,100 lines of tests.
- **Safety by construction:** the core and monitoring modules contain no calls that write, delete, rename,
  chmod or execute files. A test scans their source code to enforce this. Only the sample simulator writes,
  and it resolves every path and refuses anything outside `samples/monitored_folder`.
- **Privacy:** only metadata and hashes are stored or exported, never file contents. All processing is local.
  The dashboard binds to 127.0.0.1.
- **Concurrency:** SQLite access is serialised with a re-entrant lock. The real-time monitor runs an observer
  thread and a worker thread and stops cleanly.
- **Dashboard:** 9 Streamlit pages:
  - Overview: metrics and charts
  - Create Baseline: with confirmation dialog
  - File Scanner: with sample simulations
  - Real-Time Monitoring
  - File Explorer: filter by status
  - Alerts: with status update
  - Reports
  - Settings: severities, exclusions, limits
  - About: with an interactive SHA-256 demo
- **CLI:** `cli.py baseline|scan|watch|list`. Its exit codes make it usable with cron or Task Scheduler.

## 15. Testing
Automated tests with pytest. All tests use temporary directories and synthetic files.

| Test file | Tests | Main cases |
|---|---|---|
| test_hash_engine | 17 | known value, same/different content, empty and 25 MiB files, missing file, permission denied, symlink, FIFO, file changing during hashing, file deleted during hashing, file left untouched |
| test_file_scanner | 21 | recursion, filters, exclusions, symlinks, hard links, size and file limits, unreadable folders, invalid and protected paths |
| test_baseline_manager | 9 | creation, refusal without confirmation, confirmed replacement keeps history, deletion rules, exports, no contents stored |
| test_change_detector | 9 | all statuses, timestamp-only change, unreadable ≠ deleted, incomplete scan |
| test_integrity_checker | 11 | end-to-end scans, deleted folder, stored history, files untouched |
| test_alert_manager | 14 | severities, configurable rules, no duplicates, re-alert on further change, clearing, status workflow, SQL-injection-safe filters |
| test_realtime_monitor | 8 | real watchdog and polling events, debounce, rename, periodic fallback, ignoring own output |
| test_reports_samples | 9 | 5 demo scenarios, sample safety, PDF and CSV contents |
| test_dashboard_security | 18 | all pages headless, full UI workflow, CLI, read-only source check |

**Results:**
| Run | Result |
|---|---|
| Normal user | 116 passed |
| Root | 114 passed, 2 skipped (two real-permission tests cannot run as root, because root can read mode-000 files) |
| Real-time tests, 3 consecutive runs | stable |
| Compilation | Python 3.11, 3.12 and 3.13 |

**Not verified in the development environment:**
- The visual rendering of the dashboard in a real browser. Streamlit and Plotly were not installable there, so
  the pages were executed with a headless stand-in that runs all page code.
- Windows and macOS runs.

PROJECT_STATUS.md lists how to verify these manually.

## 16. Results
**Demonstration scenarios** on the synthetic sample folder (5 files):

| Scenario | Unchanged | Modified | Deleted | New | New alerts | Repeated (not duplicated) |
|---|---|---|---|---|---|---|
| No changes | 5 | 0 | 0 | 0 | 0 | 0 |
| Modify config.txt | 4 | 1 | 0 | 0 | 1 HIGH | 0 |
| + delete report.txt | 3 | 1 | 1 | 0 | 1 HIGH | 1 |
| + 2 new files | 3 | 1 | 1 | 2 | LOW + MEDIUM (update.sh) | 2 |
| + modify 3 more files | 0 | 4 | 1 | 2 | 3 (HIGH, HIGH, MEDIUM) | 4 |
| Reset | 5 | 0 | 0 | 0 | 0, 7 alerts cleared | – |

**Real-time:** 7 changes (modify, delete, create ×2, slow write, rename) were detected with native events
within about 1.5 s. A file written in five pieces produced one alert.

**Scale (read-only scans of real folders):**
| Folder | Files | Baseline | Rescan |
|---|---|---|---|
| /etc | 420 | 0.05 s | 0.03 s |
| /usr/share/doc | 1,698 | 0.22 s | 0.10 s |
| Python dist-packages (1.2 GB) | 31,188 | 20.6 s | 2.1 s |

All three rescans reported every file unchanged, and the files' sizes and timestamps were identical before and
after the scans. The rescan figures benefit from the OS file cache.

## 17. Advantages
- Detects any content change, with negligible risk of a forged match (SHA-256).
- Correct handling of edge cases: unreadable ≠ deleted, timestamp-only ≠ modified, incomplete scan ≠ deleted,
  files changing while hashed.
- No alert flooding: duplicates suppressed, alerts cleared when resolved.
- Safe: read-only, no symlink following, protected system paths refused, no contents stored, local only.
- Explainable alerts with recommended actions; configurable severity.
- Usable in three ways: dashboard, real-time, CLI/scheduled.
- Cross-platform and well tested.

## 18. Limitations
- Detects *what* changed, not *who* or *why*.
- The baseline database is local and could be altered by an attacker with full control of the host.
- Permissions, ownership and extended attributes are not monitored.
- Periodic scans miss changes reverted between scans.
- Real-time monitoring depends on OS limits (inotify watches) and needs polling for network drives.
- Files over the size limit and symbolic links are not verified.
- Path comparison is case-sensitive; on Windows, a case-only rename appears as delete + new.

## 19. Future scope
- Signed (HMAC) or remote, write-protected baselines
- Monitoring of permissions, owners and attributes
- Correlation with audit logs (auditd, Windows Event Log) to identify the actor
- Notifications (e-mail, chat, SIEM via syslog)
- Multi-host agents with a central server
- Opt-in text diffs for configuration files
- Role-based access to the dashboard

## 20. Conclusion
The project delivers a working FIM system that turns the theory of cryptographic hashing into a practical
security control. The design focuses on correctness in edge cases and on safety towards the monitored data.
The automated tests and the documented scenarios show that modifications, deletions, new files and
inaccessible files are detected and reported as intended, without duplicates. The system demonstrates the
detection side of integrity protection and is a solid basis for the enhancements listed above.

## 21. References
1. NIST, *FIPS PUB 180-4: Secure Hash Standard (SHS)*, 2015. https://csrc.nist.gov/pubs/fips/180-4/upd1/final
2. NIST, *SP 800-53 Rev. 5: Security and Privacy Controls for Information Systems and Organizations*, control
   SI-7 Software, Firmware, and Information Integrity. https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final
3. NIST, *SP 800-92: Guide to Computer Security Log Management*, 2006. https://csrc.nist.gov/pubs/sp/800/92/final
4. MITRE ATT&CK, *T1565 Data Manipulation* and *T1070 Indicator Removal*. https://attack.mitre.org/
5. Python Software Foundation, *hashlib — Secure hashes and message digests*. https://docs.python.org/3/library/hashlib.html
6. Python Software Foundation, *sqlite3 — DB-API 2.0 interface for SQLite databases*. https://docs.python.org/3/library/sqlite3.html
7. Python Software Foundation, *os.scandir*. https://docs.python.org/3/library/os.html#os.scandir
8. watchdog documentation. https://python-watchdog.readthedocs.io/
9. Streamlit documentation. https://docs.streamlit.io/
10. AIDE — Advanced Intrusion Detection Environment. https://aide.github.io/
11. W. Stallings, *Cryptography and Network Security: Principles and Practice*, Pearson.
