"""
SQLite storage (output/fim.db). Parameterised SQL only.

Tables (as specified): baselines, baseline_files, file_scans, security_alerts
Extra table: scan_files - the per-file result of each scan (used by the File Explorer and reports).

Only metadata and hashes are stored - never file contents.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

import config as C

SCHEMA = """
CREATE TABLE IF NOT EXISTS baselines (
    baseline_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT,
    directory_path  TEXT NOT NULL,          -- JSON list of monitored directories
    created_at      TEXT NOT NULL,
    file_count      INTEGER NOT NULL,
    status          TEXT NOT NULL,          -- Active / Superseded / Archived
    options_json    TEXT,
    error_count     INTEGER DEFAULT 0,
    skipped_json    TEXT
);
CREATE TABLE IF NOT EXISTS baseline_files (
    record_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    baseline_id     INTEGER NOT NULL REFERENCES baselines(baseline_id),
    file_path       TEXT NOT NULL,
    sha256          TEXT NOT NULL,
    file_size       INTEGER,
    modified_at     REAL,
    UNIQUE (baseline_id, file_path)
);
CREATE TABLE IF NOT EXISTS file_scans (
    scan_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    baseline_id     INTEGER NOT NULL REFERENCES baselines(baseline_id),
    scanned_at      TEXT NOT NULL,
    total_files     INTEGER NOT NULL,
    modified_count  INTEGER NOT NULL,
    deleted_count   INTEGER NOT NULL,
    new_count       INTEGER NOT NULL,
    error_count     INTEGER NOT NULL,
    unchanged_count INTEGER DEFAULT 0,
    skipped_count   INTEGER DEFAULT 0,
    alerts_created  INTEGER DEFAULT 0,
    trigger         TEXT DEFAULT 'manual',
    duration        REAL
);
CREATE TABLE IF NOT EXISTS scan_files (
    scan_id         INTEGER NOT NULL REFERENCES file_scans(scan_id),
    file_path       TEXT NOT NULL,
    status          TEXT NOT NULL,          -- UNCHANGED / MODIFIED / DELETED / NEW / INACCESSIBLE / SKIPPED
    baseline_hash   TEXT,
    current_hash    TEXT,
    baseline_size   INTEGER,
    current_size    INTEGER,
    baseline_mtime  REAL,
    current_mtime   REAL,
    detail          TEXT,
    PRIMARY KEY (scan_id, file_path)
);
CREATE TABLE IF NOT EXISTS security_alerts (
    alert_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    baseline_id     INTEGER NOT NULL REFERENCES baselines(baseline_id),
    created_at      TEXT NOT NULL,
    file_path       TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    previous_hash   TEXT,
    current_hash    TEXT,
    severity        TEXT NOT NULL,
    explanation     TEXT,
    recommended_action TEXT,
    status          TEXT NOT NULL DEFAULT 'New',
    active          INTEGER NOT NULL DEFAULT 1,   -- 1 while the condition still exists
    last_seen       TEXT,
    times_seen      INTEGER NOT NULL DEFAULT 1,
    source          TEXT DEFAULT 'scan',          -- scan / realtime
    file_mtime      REAL,
    previous_size   INTEGER,
    current_size    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_bf_baseline ON baseline_files(baseline_id);
CREATE INDEX IF NOT EXISTS idx_scans_baseline ON file_scans(baseline_id, scanned_at);
CREATE INDEX IF NOT EXISTS idx_alerts_lookup ON security_alerts(baseline_id, file_path, event_type, active);
CREATE INDEX IF NOT EXISTS idx_alerts_time ON security_alerts(created_at);
"""


class DatabaseError(RuntimeError):
    pass


class DatabaseManager:
    _lock = threading.RLock()          # serialises writes from the dashboard and the real-time monitor thread

    def __init__(self, path: Path | str | None = None):
        self.path = Path(path or C.DB_PATH)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.conn() as con:
                con.executescript(SCHEMA)
        except (OSError, sqlite3.Error) as exc:
            raise DatabaseError(f"Cannot open the database at {self.path}: {exc}") from exc

    @contextmanager
    def conn(self):
        with self._lock:
            con = sqlite3.connect(self.path, timeout=30)
            con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys = ON")
            try:
                yield con
                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

    def query(self, sql: str, args: tuple = ()) -> pd.DataFrame:
        with self.conn() as con:
            rows = [dict(r) for r in con.execute(sql, args)]
        return pd.DataFrame(rows)

    def one(self, sql: str, args: tuple = ()) -> dict | None:
        with self.conn() as con:
            row = con.execute(sql, args).fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------------ summaries for the dashboard
    def overview(self) -> dict:
        with self.conn() as con:
            alerts = dict(con.execute("SELECT event_type, COUNT(*) FROM security_alerts GROUP BY event_type")
                          .fetchall())
            sev = dict(con.execute("SELECT severity, COUNT(*) FROM security_alerts GROUP BY severity").fetchall())
            open_ = con.execute("SELECT COUNT(*) FROM security_alerts WHERE status IN ('New','Investigating')"
                                ).fetchone()[0]
            last = con.execute("SELECT scanned_at FROM file_scans ORDER BY scan_id DESC LIMIT 1").fetchone()
            baselines = con.execute("SELECT COUNT(*) FROM baselines").fetchone()[0]
        return {"alerts_by_type": alerts, "alerts_by_severity": sev, "alerts": sum(alerts.values()),
                "open_alerts": open_, "last_scan": last[0] if last else None, "baselines": baselines}

    def to_json(self, value) -> str:
        return json.dumps(value, default=str)
