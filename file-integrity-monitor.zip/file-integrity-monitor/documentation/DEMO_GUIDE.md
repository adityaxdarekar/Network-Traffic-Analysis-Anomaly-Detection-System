# Demonstration Guide — File Integrity Monitoring System

This guide is for presenting the project to a professor or examiner, in about 10–15 minutes. Every step uses
only the **synthetic sample folder** `samples/monitored_folder`. Its files are labelled
"SIMULATED DATA – safe to modify", and no real files are touched.

---

## 0. Before the demo (5 minutes, once)
```bash
cd file-integrity-monitor
./setup.sh                                  # Windows: setup.bat
venv/bin/python samples/sample_environment.py reset     # Windows: venv\Scripts\python samples\sample_environment.py reset
venv/bin/python -m pytest -q                # expect: 116 passed  (114 passed, 2 skipped if run as root)
```
Delete `output/fim.db` if you want to start with an empty history. Then start the dashboard:
```bash
./run.sh                                    # Windows: run.bat   → open http://localhost:8501
```

## 1. Introduce the problem (1 minute)
"Attackers change files: they add users, replace scripts, delete logs. FIM detects this by comparing each
file's SHA-256 fingerprint with a trusted baseline. Today I will show baseline creation, detection of
modified, deleted and new files, alerts without duplicates, real-time monitoring and reports."

Optional: open **About Project**, type `listen_port = 8080`, then change it to `8081`. The hash changes
completely: this is the avalanche effect.

## 2. Create the baseline
**Create Baseline** → the directory field already shows `samples/monitored_folder` → **🔒 Create Baseline**.

**Expected:** "Baseline #1 created: 5 files" and a table of the 5 files with their SHA-256 values
(config.txt, users.txt, system_settings.txt, logs/application.log, documents/report.txt).

Then show the safety feature: click **🔒 Create Baseline** again.
**Expected:** a warning that an active baseline exists, and nothing is replaced. The confirmation checkbox
and **Replace baseline** appear. Don't confirm now; explain that a silent replacement could hide an attack.

## 3. Scenario 4 — no changes
**File Scanner** → **🔍 Run integrity scan**.
**Expected:** 5 unchanged · 0 modified · 0 deleted · 0 new · 0 alerts.

## 4. Scenario 1 — modification
**✏️ Modify config.txt** → **🔍 Run integrity scan**.
**Expected:** 4 unchanged · **1 modified** (config.txt) · 1 new alert, severity **HIGH** (configuration file).
The Modified tab shows the original and current SHA-256, which are completely different.
Show the alert on the **Alerts** page:
```
FILE INTEGRITY ALERT #1
Event: FILE MODIFIED
File: …/samples/monitored_folder/config.txt
Original SHA-256: 08b849b5…a683c39
Current SHA-256:  fd273dc9…7368ce1
Severity: HIGH
Explanation: … This does not prove malicious activity …
Recommended action: Verify whether the modification was authorized …
```

## 5. Show duplicate prevention
Click **🔍 Run integrity scan** again without changing anything.
**Expected:** still 1 modified, but **0 new alerts, 1 already reported**. On the Alerts page, "times seen"
increases instead of a second alert appearing.

## 6. Scenario 2 — deletion
**🗑 Delete documents/report.txt** → scan.
**Expected:** 3 unchanged · 1 modified · **1 deleted** · 1 new alert (**HIGH**) · 1 repeated.

## 7. Scenario 3 — new files
**➕ Create new files** → scan.
**Expected:** **2 new** files: `documents/unexpected_notes.txt` (**LOW**) and `tools/update.sh` (**MEDIUM**,
because it is a script). 2 new alerts · 2 repeated.

## 8. Scenario 5 — several modifications
**✏️✏️ Modify several files** → scan.
**Expected:** 0 unchanged · 4 modified · 1 deleted · 2 new · 3 new alerts (users.txt HIGH,
system_settings.txt HIGH, application.log MEDIUM) · 4 repeated. Total 7 alerts.

## 9. Overview, Explorer and alert status
- **Overview Dashboard:** metric cards, a chart of file statuses, alerts by severity, the scan history.
- **File Explorer:** filter by status (e.g. only MODIFIED); hashes are shown side by side.
- **Alerts:** filter by severity; select alert #1, set status **Investigating** → **Update status**.
  Explain the workflow New → Investigating → Resolved / False Positive.

## 10. Real-time monitoring
1. **↺ Reset sample folder**, then on **Create Baseline** tick the confirmation and **Replace baseline**
   (shows the confirmed replacement; baseline #1 becomes *Superseded*).
2. **Real-Time Monitoring** → mode *Native file-system events (watchdog)* → **▶ Start monitoring**.
3. In a file manager or text editor, open `samples/monitored_folder/config.txt`, change a line and save.
4. Within about 2 seconds (debounce 1.5 s), click **⟳ Refresh** on the page.
   **Expected:** the event `modified … config.txt → MODIFIED` and a new HIGH alert.
5. Undo the change and save. **Expected:** the event shows UNCHANGED and the alert is cleared.
6. **■ Stop monitoring**.

Terminal alternative (live output): `venv/bin/python cli.py watch --mode watchdog`, then edit the file in
another window.

## 11. Reports
**Reports** → **⬇ Download PDF report** (or **💾 Save PDF to output/reports**) and open it.
**Expected:** a report with the title, date, baseline ID, monitored directory, files in baseline and scanned,
modified/deleted/new/inaccessible files with previous and current hashes, an alerts table with a severity
chart, recommendations and a conclusion. Also show the CSV downloads. Point out that the report contains
hashes and metadata only, never file contents.

## 12. Safety points to mention
- The core code only reads files. A test checks the source for write, delete and execute calls.
- An unreadable file is reported as INACCESSIBLE (warning), never as deleted.
- Symbolic links are not followed. `/`, `C:\`, `/usr`, `C:\Windows` and `/proc` are refused as scan roots.
- Baselines are never replaced without confirmation; old ones are kept as *Superseded*.
- Everything stays on the computer: no network, and the dashboard listens on localhost only.

At the end, click **↺ Reset sample folder** so the next demo starts clean.

---

## Expected outputs — summary
| Scenario | Unchanged | Modified | Deleted | New | New alerts | Repeated |
|---|---|---|---|---|---|---|
| 4 No changes | 5 | 0 | 0 | 0 | 0 | 0 |
| 1 Modification | 4 | 1 | 0 | 0 | 1 | 0 |
| 2 Deletion | 3 | 1 | 1 | 0 | 1 | 1 |
| 3 New files | 3 | 1 | 1 | 2 | 2 | 2 |
| 5 Multiple | 0 | 4 | 1 | 2 | 3 | 4 |
| Reset | 5 | 0 | 0 | 0 | 0 (7 cleared) | – |

These are the numbers produced in the development environment (`sample_output/scenario_results.txt`). The
scenarios are cumulative: run them in this order, from a reset sample folder and a fresh baseline.

Command-line version of the same check:
```bash
venv/bin/python samples/sample_environment.py reset
venv/bin/python cli.py baseline samples/monitored_folder     # add --replace if one exists
venv/bin/python samples/sample_environment.py modify
venv/bin/python samples/sample_environment.py delete
venv/bin/python samples/sample_environment.py new
venv/bin/python cli.py scan                                  # exit code 1, 4 alerts listed
venv/bin/python samples/sample_environment.py reset
venv/bin/python cli.py scan                                  # exit code 0, "4 cleared"
```
(Commands of `sample_environment.py`: reset, modify, delete, new, multiple, none.)

---

## Beginner explanation of each module
| Module | What it does, in simple words | How to show it |
|---|---|---|
| **Hash engine** (`core/hash_engine.py`) | Reads a file in 1 MiB pieces and computes its SHA-256 "fingerprint". It only reads. If the file changes while being read, it tries again. If it cannot read the file, it says why instead of crashing. | About page hash demo; the hash columns in any table |
| **File scanner** (`core/file_scanner.py`) | Walks through the chosen folders and picks which files to hash: right extension, not excluded, not too big, not a shortcut (symlink). It first checks that the folder is a safe, sensible choice. | Create Baseline with `/` → error "system location"; with filters |
| **Baseline manager** (`core/baseline_manager.py`) | Saves the "known good" list of files and hashes. It refuses to overwrite an existing baseline unless you confirm, and keeps the old one. | Create Baseline twice → confirmation |
| **Change detector** (`core/change_detector.py`) | Compares the new scan with the baseline: same hash = unchanged, different = modified, missing = deleted, extra = new, unreadable = inaccessible. | Scanner result tabs |
| **Alert manager** (`core/alert_manager.py`) | Turns changes into alerts with a severity, an explanation and advice. It does not repeat an alert for the same unchanged problem, and clears it when the file is restored. | Alerts page; scan twice → "already reported" |
| **Integrity checker** (`core/integrity_checker.py`) | The coordinator: runs scanner → detector → alerts and saves the scan history. | Overview scan history |
| **Real-time monitor** (`monitoring/realtime_monitor.py`) | Lets the operating system notify the program when a file changes, waits until the file is quiet, then checks only that file. | Real-Time Monitoring page |
| **Database** (`database/db_manager.py`) | Stores baselines, scans and alerts in one SQLite file (`output/fim.db`). | Overview numbers survive a restart |
| **Reports** (`reports/`) | Creates the PDF report and CSV/JSON files. | Reports page |
| **Sample environment** (`samples/sample_environment.py`) | Creates fake files and makes demo changes, only inside the sample folder. | Simulation buttons |
| **Dashboard** (`app.py`, `dashboard/`) | The web interface with 9 pages. | Everything above |
| **CLI** (`cli.py`) | The same functions from the terminal, for automatic scheduled checks. | `cli.py scan` and its exit code |

---

## Likely viva questions
1. **Why SHA-256 and not MD5?** MD5 and SHA-1 have practical collision attacks. SHA-256 has none, so an
   attacker cannot create a modified file with the same hash.
2. **Why not just compare timestamps?** Timestamps can be reset (`touch -d`), and content can change while the
   size stays the same. We use timestamps only as information; the hash decides.
3. **Why read in chunks?** Constant memory: a 1 GB file needs about 1 MiB of RAM.
4. **What if a file cannot be read?** It is INACCESSIBLE with a WARNING, not DELETED, because it may still
   exist. Calling it deleted would be a false conclusion.
5. **How do you avoid duplicate alerts?** An alert stays active while the same condition (same file, event and
   current hash) persists. Repeated scans only increment "times seen". A new hash creates a new alert, and a
   restored file clears it.
6. **What is debouncing?** Editors save files in several writes. We wait 1.5 s after the last event before
   hashing, so we report the finished file once.
7. **Can an attacker defeat this?** Yes, if they control the machine they can modify the baseline database
   too. Production systems store baselines off-host or sign them. This is listed as a limitation and future work.
8. **Why not follow symbolic links?** A link could point outside the chosen folder (e.g. to `/`) or create
   loops. Not following them keeps the scan inside the intended scope.
9. **Does a modified file mean an attack?** No. Updates, log rotation and admins also change files. FIM tells
   you *what* changed; a human decides whether it was authorised.
10. **Why no automatic repair?** Restoring files automatically could destroy evidence or legitimate changes.
    The brief requires read-only behaviour.

---

## Testing manually what could not be tested in the development environment
**Dashboard look (all OS):** run `./run.sh`, go through steps 2–11 and take screenshots for `screenshots/`
(see screenshots/README.md).

**Windows:**
1. Run `setup.bat`, then `venv\Scripts\python -m pytest -q`. Expect all tests to pass, with several skipped
   on purpose: the symlink, hard-link, FIFO, POSIX-path and real-permission tests are marked to skip on
   Windows; the mocked permission tests still run. (The suite has not yet been run on Windows.)
2. Try `C:\` or `C:\Windows` as a baseline directory → expect a refusal.
3. Real-time: start watchdog mode and edit `samples\monitored_folder\config.txt` in Notepad.
4. Inaccessible file: right-click a test file in a folder of your own → Properties → Security → deny Read for
   your user. Scan → expect INACCESSIBLE (WARNING), not DELETED. Remove the deny entry afterwards.

**Linux inaccessible file (as a normal user, not root):**
```bash
mkdir -p ~/fim-test && echo hello > ~/fim-test/a.txt
venv/bin/python cli.py baseline ~/fim-test
chmod 000 ~/fim-test/a.txt && venv/bin/python cli.py scan    # INACCESSIBLE, not DELETED
chmod 644 ~/fim-test/a.txt && venv/bin/python cli.py scan    # unchanged, alert cleared
```

**Network drive:** choose the *Polling observer (network drives)* mode, because native events often don't arrive from network
shares.
