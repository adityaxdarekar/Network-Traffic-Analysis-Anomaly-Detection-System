"""helpers.py - upload validation, redaction, formatting and logging."""
from __future__ import annotations

import html
import logging
import re
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import LOG_FILE, MAX_UPLOAD_MB, RISK_COLORS

ALLOWED_SUFFIXES = (".log", ".txt", ".csv")
SECRET_PARAM = re.compile(
    r"([?&;](?:password|passwd|pwd|pass|passphrase|token|access_token|refresh_token|id_token|api_?key|key|secret|"
    r"client_secret|session|sessionid|sid|phpsessid|jsessionid|auth|authorization|code|otp|pin)=)([^&\s\"]*)", re.I)
PAYLOAD_HINT = re.compile(r"['\"<>;()]|\.\./|%27|%22|%3c|%3e|%2e%2e|\bunion\b|\bselect\b|\bscript\b", re.I)


class UploadError(ValueError):
    pass


def validate_upload(name: str, data: bytes) -> None:
    """Reject anything that is not a reasonably sized text log before it is parsed."""
    suffix = Path(name or "").suffix.lower()
    if suffix not in ALLOWED_SUFFIXES and not re.search(r"\.log\.\d+$", name or "", re.I):
        raise UploadError("only .log, .txt or .csv access logs are accepted (rotated access.log.1 too)")
    if not data:
        raise UploadError("the file is empty")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise UploadError(f"the file is larger than {MAX_UPLOAD_MB} MB")
    if data[:2] == b"\x1f\x8b":
        raise UploadError("this is a gzip archive (access.log.2.gz) - decompress it first: gunzip -k file.gz")
    if b"\x00" in data[:8192]:
        raise UploadError("the file looks binary (NUL bytes), not a text access log")


def redact(text: str) -> str:
    """Mask values of secret-looking query parameters (password=, token=, session= ...).

    Values that look like attack payloads (quotes, tags, ../, SQL words) are kept, because they are the evidence.
    """
    if not text or "=" not in text:
        return text
    return SECRET_PARAM.sub(lambda m: m.group(1) + (m.group(2) if PAYLOAD_HINT.search(m.group(2)) or not m.group(2)
                                                   else "[REDACTED]"), text)


def fmt_ts(ts) -> str:
    if ts is None:
        return "-"
    try:
        return datetime.fromtimestamp(float(ts), timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (TypeError, ValueError, OSError):
        return str(ts)


def esc(v) -> str:
    return html.escape("" if v is None else str(v))


def badge(level: str) -> str:
    return f'<span class="risk-badge" style="background:{RISK_COLORS.get(level, "#64748b")}">{esc(level)}</span>'


def get_logger() -> logging.Logger:
    log = logging.getLogger("weblog")
    if not log.handlers:
        Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        h = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log


def csv_safe(v) -> str:
    """Neutralise spreadsheet formula injection in exported cells (log data is attacker-controlled)."""
    s = "" if v is None else str(v)
    if s == "-" or s.lstrip("-").replace(".", "", 1).isdigit():
        return s                                   # plain numbers and the "-" placeholder are safe
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s
