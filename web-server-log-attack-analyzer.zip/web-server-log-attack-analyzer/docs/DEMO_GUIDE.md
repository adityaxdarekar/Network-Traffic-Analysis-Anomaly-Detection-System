# Practical Demonstration Guide (Kali Linux / Ubuntu)

All nine demonstrations use the **SYNTHETIC** logs in `sample_logs/`. You can run them on the dashboard (`streamlit run app.py`) or all at once with `python run_demos.py`.

The output excerpts below are the real output of `run_demos.py` (`sample_output/demo_results.txt`). The generator is seeded, so you get the same numbers.

Never send attack strings to real websites. The logs already contain them as text.

---

## Demo 1: Apache log collection

**Steps:** follow `docs/APACHE_LOG_GUIDE.md` (location, rotation, CLF and Combined). On the dashboard, open *Apache Log Upload*, choose `access.log` and click **Analyse sample**. Then repeat with `demo_common_format.log` and `access_sample.csv`.

```
access.log: 889 lines -> 882 parsed (99.4%), 5 malformed, formats {'combined': 882}, synthetic=True
  line 150: does not match Apache Common/Combined format | this line is not an apache log entry
  line 297: invalid month 'Foo'                          | 192.0.2.40 - - [32/Foo/2026:10:61:00 +0000] ...
  line 444: invalid IP address '999.1.2.3'
  line 591: missing or unterminated fields
  line 738: invalid status code 'abc'
demo_common_format.log: 487 lines -> 485 parsed (100.0%) ... formats {'common': 485}
  time zone normalised: '02/Nov/2026:04:12:00 -0500' -> 2026-11-02 09:12:00+00:00 (UTC)
```

**Explain:**
- The 2 extra lines are comments.
- Malformed lines are kept with a reason and never stop the parse.
- CLF has no Referer or User-Agent, so User-Agent rules are skipped for it.

## Demo 2: Normal traffic analysis

**Dashboard:** load `demo_normal.log`, then open *Security Overview* (charts 1, 2, 4 and 9) and *HTTP Traffic Analysis*.

```
372 requests from 13 IPs
methods: {'GET': 366, 'POST': 5, '-': 1}
status codes: {200: 127, 302: 4, 304: 224, 401: 1, 404: 15, 408: 1}
most requested URLs: /static/css/site.css (68), /static/js/app.js (68), ... /products (18), /search (15)
[PASS] no incidents on normal traffic
```

**Explain:**
- 304 means "Not Modified": the browser cache is working.
- The single 401 is a customer mistyping a password; it is followed by a 302 login.
- Searches such as `union station` and `how to select a drop table lamp` contain SQL words but are **not** flagged, because no rule fires on a keyword alone.

## Demo 3: SQL injection detection

**Dashboard:** load `demo_sqli.log`, then open *SQL Injection Detection*. Pick a request under **Inspect request**. Try the **Test a request string** box with `/p?id=1' OR '1'='1`.

```
10:00:07 198.51.100.23 -> 200  GET /products.php?id=1%27%20OR%20%271%27%3D%271
    rules SQLI-01, SQLI-07, SQLI-08 (high confidence) | decoded: /products.php?id=1' OR '1'='1
10:00:17 198.51.100.23 -> 500  GET /products.php?id=-1%20UNION%20SELECT%201,2,3--   rules SQLI-02
... 1%2527%20OR%20%25271%2527%3D%25271 -> double-encoded quote, decoded in 2 layers: SQLI-01, SQLI-07, SQLI-08
-> 198.51.100.23: High 60 = Potential SQL injection (25) + Suspicious reconnaissance (15) + HTTP anomaly (10)
   + Multiple attack categories (10) = 60
[PASS] 14 of 16 sqlmap requests flagged ('id=1' and the lone quote 'id=1%27' are not)
```

**Explain each rule:**
- SQLI-01 is a tautology, SQLI-02 is UNION SELECT, SQLI-08 is an encoded quote.
- The 500 errors raise ANOM-04, because SQL errors often surface as 500.
- The `sqlmap` User-Agent adds reconnaissance (REC-05).
- A lone quote is **not** flagged. It is the scanner's first probe, but on its own it is not SQL.

## Demo 4: XSS detection

**Dashboard:** load `demo_xss.log`, then open *XSS Detection*.

```
GET /search?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E           XSS-01, XSS-05, XSS-06 | decoded <script>alert(1)</script>
GET /search?q=%3Cimg%20src%3Dx%20onerror%3Dalert(document.cookie)%3E      XSS-02, XSS-04, XSS-05, XSS-06
GET /redirect?url=javascript%3Aalert(1)                       XSS-03, XSS-05
GET /search?q=&lt;script&gt;alert(1)&lt;/script&gt;           XSS-01, XSS-05, XSS-06 (HTML entities decoded)
[PASS] 10 XSS requests, Medium risk
```

**Explain:**
- All 10 requests got a 200. That shows the server **accepted** the request; it does not show the page is vulnerable.
- Vulnerability needs reflection or storage without encoding, which only the application can show.

## Demo 5: Directory traversal detection

**Dashboard:** load `demo_traversal.log`, then open *Directory Traversal Detection*.

```
200  GET /download.php?file=../../../../etc/passwd                     TRV-01, TRV-04
400  GET /%2e%2e/%2e%2e/%2e%2e/etc/passwd                              TRV-01, TRV-02, TRV-04  (URL-encoded)
404  GET /download.php?file=%252e%252e%252f...etc%252fpasswd           TRV-01, TRV-03, TRV-04  (double-encoded)
400  GET /static/%c0%ae%c0%ae/%c0%ae%c0%ae/etc/passwd                  TRV-03, TRV-04          (overlong UTF-8)
404  GET /index.php?page=../../../../etc/passwd%00.html                TRV-01, TRV-04, TRV-06  (null byte)
!! answered 200 OK: GET /download.php?file=../../../../etc/passwd - check what was served (size in the log)
```

**Explain:**
- Double encoding (`%252e`) beats filters that decode only once.
- The **200 with 2,346 bytes** is the request to investigate first, because a password file is about that size.
- The tool never opens these files; it only reads the strings.

## Demo 6: Brute-force detection

**Dashboard:** load `demo_bruteforce.log`, then open *Brute Force Detection*. Select `203.0.113.10` and look at the per-minute chart and the busiest window. Then change the thresholds on *Detection Configuration* and compare.

```
203.0.113.10: BF-01, BF-02, BF-03 | peak 59 in window 09:20:04 - 09:23:56 | intensity critical
   per minute: {'09:20': 14, '09:21': 15, '09:22': 15, '09:23': 15}
   ... A login request was answered with 302 after the failures - possible successful guess; verify this account first.
198.51.100.77: BF-01, BF-02 | peak 24 in window 09:45:00 - 09:48:04 | intensity high
With max failed=30, high=40, critical=60: [('203.0.113.10', 'Medium', 40)]
[PASS] 203.0.113.10 High (incl. success after failures), 198.51.100.77 Medium, single typo not flagged
```

**Explain the time-window logic:**
- A sliding window (two pointers over sorted times) finds the busiest 5-minute stretch wherever it starts. Clock minutes would split a burst.
- The thresholds 10, 20 and 50 set the alert, the High bonus and the Critical bonus.
- Status codes alone do not prove failed logins. That is why BF-02 also counts login POSTs.

## Demo 7: Reconnaissance detection

**Dashboard:** load `demo_recon.log`, then open *Reconnaissance Analysis*.

```
203.0.113.99: REC-01, REC-02, REC-03, REC-04, REC-05, REC-06, REC-07
   38 distinct sensitive paths probed; scanner User-Agent 'gobuster' on 87 requests; 71 404 responses;
   86 unique paths with 90% 4xx responses. Also requested /robots.txt 1x (context only).
203.0.113.99: HTTP anomalies: unusual methods OPTIONS x1, TRACE x1, PUT x1.
[PASS] only the scanner IP is reported (Googlebot's robots.txt is context, not an alert)
```

## Demo 8: Incident investigation and persistence

**Dashboard:**
1. Load `access.log`.
2. Open *Incident Management*, set **Attack type** = Potential SQL injection, and open the Critical incident (203.0.113.66).
3. Set **Set status** = Investigating, write a note, and click **Save status and note**.
4. Stop Streamlit (Ctrl+C) and start it again.
5. Load `access.log` again and open the incident. The status, note and history are still there.

```
WEB-8B6F501689 (203.0.113.66, Critical 100) set to Investigating; database closed (simulated restart)
after restart + re-analysis: status=Investigating, note='Demo 8: Nikto scan with SQLi/XSS/traversal payloads;...',
detected 2x, history entries 1
```

The incident ID is a hash of the log file's SHA-256 and the IP, so re-analysing the same file updates the same record and never resets its status.

## Demo 9: Report generation

**Dashboard:**
1. Open *Reports and Downloads* and click **Build PDF report**.
2. Download the PDF and the **Suspicious requests (CSV)**.

The same files are in `sample_output/`:
- `security_investigation_report.pdf` (7 pages);
- `suspicious_requests.csv` (52 rows);
- `suspicious_ips.csv` (12 rows);
- `incidents.csv`.

**Explain the findings:**

| IP | Result | What to say |
|---|---|---|
| 203.0.113.66 | Critical 100 | A Nikto scan combining SQL injection, XSS, traversal and 130 requests in 55 s. |
| 198.51.100.23 | High 60 | sqlmap; check the 500 errors in the application log. |
| 203.0.113.10 | High 50 | A brute force that ended with a 302. Check that account first. |
| 4 Low IPs | Low | Monitoring curl, a large download, OPTIONS/TRACE, a TLS handshake. Probably benign, which shows why analyst validation matters. |

## Screenshots to take (dashboard)

The dashboard could not be rendered in the build environment. Terminal and PDF screenshots are in `screenshots/`. Take these yourself:

1. Overview.
2. Upload with the malformed list.
3. Traffic analysis.
4. SQL injection with an inspected request.
5. XSS.
6. Traversal.
7. Brute force for 203.0.113.10.
8. Reconnaissance.
9. IP investigation for 203.0.113.66.
10. An incident after the restart.
11. Reports.
12. Configuration.
