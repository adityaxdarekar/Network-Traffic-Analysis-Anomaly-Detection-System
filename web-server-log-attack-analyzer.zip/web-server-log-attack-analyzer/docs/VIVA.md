# Viva Questions and Answers (32)

**1. What is the Apache HTTP Server?**
The Apache HTTP Server is an open-source web server from the Apache Software Foundation. It listens on ports 80/443, serves static files, and runs applications through modules (`mod_php`, `mod_proxy` …). Logging is done by `mod_log_config`.

**2. What is an access log, and how does it differ from an error log?**
- The **access log** records one line per request: who, when, what, the status and the size.
- The **error log** records server problems: start-up messages, module errors, PHP warnings, "file does not exist" entries.

On Ubuntu and Kali they are `/var/log/apache2/access.log` and `error.log`.

**3. Explain the Common Log Format.**
`%h %l %u %t "%r" %>s %b`:
- client IP;
- identd identity (almost always `-`);
- authenticated user;
- time with time-zone offset;
- the request line;
- the final status code;
- the response body size (`-` when zero).

**4. What does the Combined Log Format add, and why is it more useful for security?**
It adds the quoted `Referer` and `User-Agent` headers. The User-Agent reveals tools (sqlmap, Nikto, gobuster, python-requests). The Referer shows how a user arrived, and direct hits with no referer on login pages are typical for scripts.

**5. Name the main HTTP methods and which ones are suspicious.**
- **Common:** GET (read), POST (submit), HEAD (headers only).
- **Others:** PUT (upload), DELETE, OPTIONS (capabilities), PATCH, TRACE (echo, abused for cross-site tracing), CONNECT (proxy tunnels), and WebDAV methods such as PROPFIND.

For a normal website, anything beyond GET/POST/HEAD deserves a look. The project's ANOM-03 rule flags methods outside a configurable list.

**6. Explain the HTTP status-code classes.**

| Class | Meaning | Examples |
|---|---|---|
| 1xx | Informational | |
| 2xx | Success | 200 OK |
| 3xx | Redirection | 301, 302, 304 Not Modified |
| 4xx | Client error | 400, 401, 403, 404, 405, 408 |
| 5xx | Server error | 500, 503 |

**7. What is the difference between 401, 403 and 404?**
- **401 Unauthorized:** authentication is required or failed; the client may retry with credentials.
- **403 Forbidden:** the server understood the request but refuses it, whoever you are.
- **404 Not Found:** the resource does not exist, or the server hides it.

For detection, many 401s from one IP suggest password guessing, while many 404s suggest scanning for files. A 403 is ambiguous: it can come from a login protection plug-in or from a forbidden directory. That is why the project counts 403 as a failure only on login paths.

**8. What is SQL injection?**
Untrusted input is concatenated into a SQL statement, so the attacker changes the query. For example, `' OR '1'='1` makes a `WHERE` clause always true, and `UNION SELECT` reads other tables. The prevention is parameterised queries.

**9. How does the project detect SQL injection without flagging normal pages?**
It decodes the URL first, then requires SQL *context*, not single keywords:
- a tautology after a quote;
- `UNION SELECT`;
- `; DROP TABLE`;
- a quote followed by a comment marker;
- `SLEEP(n)`;
- `information_schema`;
- a quote followed by a keyword.

Tested negatives such as `?q=union station`, `how to select a drop table lamp` and `O'Brien` are not flagged.

**10. What is Cross-Site Scripting, and what are its types?**
XSS injects script into pages viewed by others:
- **reflected:** the input is echoed in the response;
- **stored:** the input is saved and shown later;
- **DOM-based:** client-side JavaScript writes the input into the page.

It can steal cookies, perform actions as the victim, or deface pages. It is prevented with context-aware output encoding, sanitisation and a Content Security Policy.

**11. Why does a detected XSS pattern not prove a vulnerability?**
The log shows only that the string was *sent*. A vulnerability exists only if the application reflects or stores it without encoding. A 200 status means the request was accepted, not that script ran. Confirmation needs the application's response or testing in an authorised environment.

**12. What is directory traversal?**
Using `../` sequences (or absolute paths) in a file parameter to read files outside the intended directory, such as `/etc/passwd` or configuration files containing passwords. It is prevented by canonicalising paths, allow-listing files and least privilege.

**13. What are double encoding and overlong UTF-8, and why do attackers use them?**
- **Double encoding** encodes the `%` itself: `%252e` → `%2e` → `.`. A filter that decodes once sees no dots, while a later component decodes again.
- **Overlong UTF-8** (`%c0%ae` for `.`) is an invalid encoding that some old decoders accepted.

The project decodes repeatedly and has a dedicated rule (TRV-03).

**14. What is URL (percent) encoding?**
Characters that are reserved or unsafe in URLs are written as `%` plus two hex digits: space is `%20`, `'` is `%27`, `<` is `%3C`, `/` is `%2F`. In query strings, `+` usually means space. Detectors must decode before matching, otherwise `%27%20OR%20%271%27%3D%271` looks harmless.

**15. What is a brute-force attack, and how is it detected here?**
Repeatedly guessing passwords. The project counts per IP:
- 401/403 failures on login endpoints (or 401 anywhere);
- login POSTs.

A sliding 5-minute window finds the busiest stretch. 10 events raise an alert; 20 or more adds High intensity, and 50 or more Critical. A 2xx/3xx login after failures is flagged as a possible successful guess.

**16. Why use a sliding window instead of counting per clock minute?**
A burst from 10:04:30 to 10:05:30 would be split between two clock minutes and could stay under the threshold in both. A sliding window (two pointers over sorted timestamps) measures the true maximum in any interval of that length.

**17. What is web reconnaissance?**
The information-gathering phase before an attack: requesting admin panels, `.env`, `.git/`, backups and `server-status`, enumerating directories from word lists (gobuster, dirbuster), fingerprinting with Nikto. In logs it appears as many different paths, mostly 404, from one IP, often with a scanner User-Agent.

**18. What is a User-Agent, and can it be trusted?**
It is the request header naming the client software. It is useful context (`sqlmap/1.8`, `Nikto`, `python-requests`), but it is entirely controlled by the client and can be spoofed. That is why the project never treats it as proof, only as one weighted indicator.

**19. What can the source IP tell us, and what are its limits?**
It groups requests from one client and allows rate analysis. However:
- many users can share one IP (NAT, proxies, mobile carriers);
- attackers rotate IPs (botnets, VPNs, Tor);
- behind a reverse proxy, Apache logs the proxy's IP unless configured with `mod_remoteip`.

The project groups by IP but presents the result as a lead.

**20. What are regular expressions, and how are they used here?**
Patterns describing text, compiled with Python's `re`. They are used to:
- split each log line into fields, e.g. `"(?P<request>(?:[^"\\]|\\.)*)"` handles escaped quotes;
- define every detection rule, with `re.I` for case-insensitivity.

Patterns are precompiled once, and each unique request target is evaluated once and cached.

**21. What is a false positive? Give examples from this project.**
A benign event reported as suspicious:
- a monitoring script using curl (generic tool User-Agent);
- a customer downloading a 48 MB catalogue (unusual size);
- an administrator browsing `/wp-admin` (admin pages answered with 200 are deliberately not counted).

The four Low incidents in the sample are of this kind. The allowlist and the thresholds reduce them, and the analyst decides.

**22. What is a false negative?**
A real attack that goes undetected:
- injection inside a POST body (not logged);
- novel obfuscation;
- a slow brute force under the threshold;
- an attack distributed across many IPs.

**23. How does the risk score work, and how are duplicates handled?**
Each distinct category found for an IP contributes its weight once: SQLi 25, XSS 25, traversal 30, brute force 20, reconnaissance 15, frequency 15, anomalies 10. Bonuses are added for brute-force intensity and for multiple attack categories (+10 each extra, at most +20), and the total is capped at 100. Forty injection requests still give 25 points. Every contribution is shown.

**24. Why is a heuristic score not a confirmed attack?**
It measures how many independent suspicious behaviours occurred, not whether the server was compromised. Scanners generate Critical scores while failing completely, and a single successful injection might score only Medium. Analysts must check outcomes in application, database and system logs.

**25. Why use Streamlit for the dashboard?**
It turns Python scripts into interactive web apps (widgets, file upload, tables, Plotly charts) without front-end code. `st.session_state` keeps the analysis between interactions, and `st.cache_resource` shares the database connection. Changing thresholds re-scores the stored parse instantly.

**26. How is Pandas used?**
- Each parsed log becomes a DataFrame.
- `groupby('ip')` drives the per-IP detectors.
- `resample('1min')` builds the time charts.
- `value_counts` gives the top IPs, URLs and User-Agents.
- Filters power the request explorer.
- CSV export is done from the DataFrame.

NumPy computes the percentiles and the median/MAD robust z-score for response sizes.

**27. Why SQLite, and how do incidents survive a restart?**
SQLite is serverless, file-based, transactional and built into Python, which is ideal for a single-analyst tool. The incident ID is a hash of the log file's SHA-256 and the IP, so analysing the same file again maps to the same row. The upsert updates the detection fields but never the status or notes, and a notes table keeps the history.

**28. What is SOC monitoring?**
A Security Operations Centre continuously collects and analyses security data (logs, alerts), triages events, investigates incidents and coordinates the response. Analysts work from prioritised queues. This project imitates that with risk levels, incident statuses and evidence.

**29. Describe the incident response steps for a Critical incident from this tool.**
Following NIST SP 800-61:
1. **Prepare:** have logs and tools ready.
2. **Detect and analyse:** review the evidence, check 200 responses and their sizes, correlate with the application and error logs, and check for successful logins.
3. **Contain:** block at the firewall or WAF, a human decision; disable a compromised account.
4. **Eradicate and recover:** patch, rotate secrets.
5. **Post-incident:** lessons learned, rule tuning.

Notes are recorded throughout.

**30. Why does the tool not block IPs automatically?**
Detections are heuristic, and IPs can be shared or spoofed. Automatic blocking could lock out customers, or be abused by an attacker who forges traffic from a partner's IP. The brief also forbids it. The tool informs; humans decide.

**31. How does the project handle sensitive data and unsafe uploads?**
- **Uploads** are checked for extension, size, gzip and binary content, then parsed in memory (not stored). Control characters are replaced, and lines over 16 KB are rejected.
- **Secrets:** password, token and session values in query strings are redacted in displays, the database and exports (attack payloads are kept as evidence).
- **CSV exports** neutralise spreadsheet formulas.
- **HTML output** is escaped.

**32. How would you extend the project?**
- Nginx/IIS/JSON log formats and live tailing.
- Offline GeoIP/ASN enrichment.
- Distributed brute-force correlation.
- Correlation with error, application and WAF logs to confirm outcomes.
- ML anomaly models next to the rules.
- SIEM forwarding and Sigma rules.
