# Web Server Log Attack Analyzer and Threat Detection Dashboard Using Python
### College Project Report

---

## 1. Abstract

Web servers record every request in access logs, and those logs contain the traces of nearly every web attack: injected SQL and script fragments, path-traversal sequences, password-guessing bursts and automated scanning. Reading them by hand does not scale.

This project implements a defensive analyzer for Apache access logs. It:

- parses the Common and Combined Log Formats (and CSV), validating every field;
- keeps malformed lines for troubleshooting and normalises timestamps to UTC;
- decodes each request target safely (repeated URL decoding, HTML entities, SQL comments);
- applies 36 explainable rules for SQL injection, Cross-Site Scripting, directory traversal, brute-force authentication abuse, reconnaissance and HTTP anomalies.

Behaviour rules use sliding time windows per source IP. A transparent heuristic scorer combines the distinct categories found for each IP into a 0–100 risk score and a Low/Medium/High/Critical level, without counting repeated detections twice. Incidents are stored in SQLite with an analyst workflow. Everything is shown on a 12-page Streamlit dashboard and exported to CSV and PDF.

On a synthetic 887-entry log, the system:
- parsed 882 entries and listed 5 malformed lines with their reasons;
- raised no alert on normal browsing, including benign queries containing SQL words;
- classified 12 suspicious IPs (1 Critical, 2 High, 5 Medium, 4 Low).

158 automated tests pass.

## 2. Problem Statement

Small organisations and student labs run web servers without a SIEM or WAF. Their access logs are the only record of attacks, but they are large, noisy and full of encoded strings.

Simple `grep` searches for "select" or "script" flag harmless pages and miss encoded payloads such as `%2527` or `&lt;script&gt;`. Status codes are easy to misread: a 401 is not always a failed login, and a 200 does not mean an attack worked.

The problem is to analyse access logs automatically and robustly:
- decode payloads before matching;
- recognise both single malicious requests and suspicious behaviour over time;
- explain every finding;
- prioritise source IPs;
- support the analyst through investigation and documentation, without ever interacting with the attacker.

## 3. Project Objectives

1. Parse Apache CLF and Combined logs (and CSV), extracting timestamp, IP, method, URL, protocol, status, size, referrer, User-Agent and the original line. Handle malformed and missing fields safely.
2. Detect potential SQL injection, XSS and directory traversal in decoded request targets, with rules that avoid keyword-only false positives.
3. Detect brute-force and authentication abuse with configurable sliding time windows and thresholds.
4. Detect reconnaissance (sensitive paths, scanners, 404 storms) and HTTP anomalies (frequency, methods, error ratios, User-Agents, response sizes).
5. Profile each suspicious IP, and score it transparently with de-duplicated categories.
6. Provide a SOC dashboard, persistent incident management, defensive recommendations and CSV/PDF reports.
7. Provide a synthetic log generator, automated tests and a practical demonstration.

## 4. Existing System

| Approach | Limitation |
|---|---|
| Manual reading / `grep` / `awk` | Slow; misses encodings; no correlation over time; no scoring or history |
| AWStats / GoAccess | Traffic statistics, not security detection |
| ModSecurity / commercial WAF | Blocks inline, but needs tuning and installation on the server; not a retrospective analysis tool |
| Fail2ban | Bans IPs automatically on regex matches; limited explanation; acting automatically can lock out legitimate users |
| Commercial SIEM (Splunk, QRadar) | Powerful but expensive and complex for small teams and students |

## 5. Proposed System

The proposed system is an offline, explainable log analyzer:

- It accepts a log file (bundled sample or upload).
- It produces a parsed table, decodes every request target, and applies request-level and behaviour-level rules.
- It produces **findings** with rule IDs, evidence and an explanation.
- It groups the findings into **one incident per source IP**, with a transparent score.
- It provides an analyst workflow and reports.

It never blocks IPs, replays requests or contacts any system. Thresholds, weights, authentication paths, allowed methods, an IP allowlist and secret redaction are all configurable.

## 6. Hardware and Software Requirements

| Hardware | Minimum | Recommended |
|---|---|---|
| CPU | Dual-core | Quad-core |
| RAM | 4 GB | 8 GB (logs over 100 MB) |
| Disk | 500 MB | 2 GB |

| Software | Version |
|---|---|
| OS | Kali Linux 2024+, Ubuntu 22.04/24.04 (Windows also works) |
| Python | 3.11+ (tested on 3.13) |
| pandas / NumPy | 2.x / 1.26+ |
| Streamlit / Plotly | 1.32+ / 5.18+ |
| ReportLab | 4.x |
| SQLite | bundled with Python |
| pytest | 7+ |
| Apache HTTP Server | 2.4 (only for collecting real logs in a lab) |

## 7. System Architecture

| Layer | Components |
|---|---|
| Input | Bundled synthetic logs, uploaded `.log`/`.txt`/`.csv`, the CLI file argument |
| Validation and parsing | `helpers.validate_upload` (type, size, gzip/binary), `log_parser` (regex, field validation, UTC, malformed list, synthetic marker) |
| Normalisation | `normalizer.view()`: raw, decoded, HTML-unescaped and SQL views, plus the number of decoding layers |
| Detection | Request level: `sql_injection_detector`, `xss_detector`, `traversal_detector`. Per IP: `brute_force_detector`, `reconnaissance_detector`, `anomaly_detector` |
| Scoring | `risk_scorer`: incidents, contributions, bands, recommendations |
| Orchestration | `engine.analyze_parsed`: allowlist, redaction, statistics |
| Persistence | `db_manager` (SQLite) |
| Presentation | `app.py` (Streamlit + Plotly), `analyze_log.py`, `report_generator` (CSV, PDF) |

## 8. Data Flow Diagram

**Level 0:**

```
 Apache server ──(access.log, authorised copy)──► [ Web Server Log Attack Analyzer ] ──► dashboard, CSV, PDF ──► Analyst
                                                            ▲                                          │
                                                            └────── thresholds, status, notes ─────────┘
```

**Level 1:**

```
 log file ─► 1 Validate upload ─► 2 Parse lines ─► entries ─► 3 Decode targets ─► 4a Request rules (SQLi/XSS/TRV)
                 │ reject               │ malformed list                       └► 4b Per-IP windows (BF/REC/ANOM)
                 ▼                      ▼                                                │ findings
             error message        parsing statistics                                    ▼
                                                     D1 SQLite ◄── 6 Save ◄── 5 Score per IP (distinct categories)
                                                         │                                │
                                       7 Dashboard / reports ◄── status & notes from analyst
```

## 9. Use-Case Diagram

```
          ┌──────────────────────── Web Server Log Attack Analyzer ─────────────────────────┐
          │ (UC1) Load sample log          (UC2) Upload access log  «include» Validate file  │
 ┌──────┐ │ (UC3) View security overview   (UC4) Analyse HTTP traffic                        │
 │ SOC  │─│ (UC5) Review SQLi / XSS / traversal requests   (UC6) Review brute force          │
 │analyst│ │ (UC7) Review reconnaissance    (UC8) Investigate an IP                           │
 └──────┘ │ (UC9) Manage incident (status, notes)   (UC10) Download CSV / PDF                │
          │ (UC11) Configure thresholds, weights, allowlist                                   │
          └───────────────────────────────────────────────────────────────────────────────────┘
 Apache server (external) ──► produces the access log used in UC2
```

## 10. Detection Algorithm Flowchart

```
START
 → validate file (extension, size, not gzip/binary)
 → for each line: blank/comment? skip │ regex match? no → malformed(reason) │ validate IP, time, status, size
      → entry (UTC timestamp, fields, original line)
 → allowlist filter (later) ; sort by time
 → for each unique request target:
      decode (≤ 4 percent layers, '+' → space, NUL removed) → HTML-unescape → strip /* */
      SQLI-01..07 on SQL view; SQLI-08 if encoded metachar AND SQL context
      XSS-01..05 on HTML view; XSS-06 if encoded markup decodes to a tag
      TRV-01..05; TRV-06 only together with another TRV rule
      any hit → Finding(request, rules, evidence)
 → for each IP (sorted timestamps):
      failures/login POSTs → sliding window max ≥ 10? → BF finding (+ intensity, success-after-failure)
      sensitive probes ≥ 3 / scanner UA / ≥ 20 404s / ≥ 30 paths & ≥ 50 % 4xx → REC finding
      > 100 req/60 s → frequency ; identical path, methods, 5xx, UA, size → HTTP anomaly
 → group findings by IP → distinct categories → Σ weights + bonuses → cap 100 → band
 → save incidents (keep analyst status) → dashboard / reports
END
```

## 11. Module Descriptions

| Module | Responsibility |
|---|---|
| `log_parser.py` | Regex for CLF/Combined with escaped quotes; field validation (`ipaddress`, month table, status 100–599, `-` size); request-line split (`-` for 408, `INVALID` for garbage, HTTP/0.9); control-character sanitising; 16 KB line limit; CSV with aliases; SHA-256; synthetic marker |
| `normalizer.py` | `percent_decode` (repeat until stable, counting layers); `view()` with raw, decoded, HTML and SQL texts; evidence snippets |
| `findings.py` | `Finding`, `Rule`, confidence levels (1, 2 or 3+ rules), two-pointer `sliding_max`, shared request scanner (one finding per request per category) |
| `sql_injection_detector.py` | SQLI-01…08 |
| `xss_detector.py` | XSS-01…06 |
| `traversal_detector.py` | TRV-01…06 |
| `brute_force_detector.py` | Authentication-path matching, failure and attempt events, sliding windows, intensity, BF-03 |
| `reconnaissance_detector.py` | Path classes REC-01…04, scanner User-Agent list, per-IP aggregates |
| `anomaly_detector.py` | Frequency, repeated path, methods, 5xx ratio, User-Agent issues, robust z-score for sizes (NumPy median/MAD), global profile |
| `risk_scorer.py` | Contributions, bonuses, cap, bands, incident ID, recommendations, disclaimer |
| `engine.py` | Runs all detectors; allowlist; redaction; statistics; suspicious-request and IP tables |
| `db_manager.py` | Analyses, incidents (upsert that keeps the analyst status), notes history, filters |
| `report_generator.py` | 4 CSV exports (formula-injection safe) and the PDF |
| `sample_log_generator.py` | Seeded synthetic scenarios, 9 files |
| `app.py`, `analyze_log.py`, `run_demos.py` | The dashboard, the CLI and the demonstration runner |

## 12. Apache Log Format Explanation

**Common Log Format:** `%h %l %u %t "%r" %>s %b`

| Directive | Meaning |
|---|---|
| `%h` | Client IP |
| `%l` | identd identity (`-`) |
| `%u` | Authenticated user |
| `%t` | `[dd/Mon/yyyy:HH:MM:SS ±zzzz]` |
| `%r` | Request line (method, target, protocol) |
| `%>s` | Final status |
| `%b` | Body bytes (`-` = 0) |

**Combined** adds `"%{Referer}i" "%{User-agent}i"`.

Example:

```
203.0.113.10 - - [02/Nov/2026:09:20:04 +0000] "POST /login HTTP/1.1" 401 381 "https://shop.example.com/login" "python-requests/2.31.0"
```

Apache escapes `"` and `\` and writes non-printable bytes as `\xhh`. Logs live in `/var/log/apache2/access.log` (Debian family) or `/var/log/httpd/access_log` (Red Hat family) and are rotated by logrotate. Request bodies (POST data) are **not** logged.

## 13. SQL Injection Detection Methodology

SQL injection inserts SQL syntax into input that the application concatenates into a query.

**Decoding.** Percent-decoding is repeated up to 4 layers, so `%2527` becomes `%27` and then `'`. `+` becomes a space in the query string, `/**/` becomes a space in the SQL view, and matching is case-insensitive.

**Context instead of keywords.** A word such as *select*, *union* or *drop* appears in normal text (`how to select a drop table lamp`, `union station`), so no rule uses a keyword alone. Each rule needs a SQL-specific context:

| Rule | Context |
|---|---|
| SQLI-01 | A quote followed by `OR`/`AND` and a comparison (`' OR '1'='1`), or `OR n=n` |
| SQLI-02 | `UNION [ALL] SELECT` |
| SQLI-03 | `;` or a quote before `DROP`/`TRUNCATE`/`ALTER` `TABLE`, or `; DELETE FROM`, `; EXEC` |
| SQLI-04 | A quote or parenthesis followed by `--`, `#` or `/*`; a keyword followed by an inline comment |
| SQLI-05 | `SLEEP(n)`, `BENCHMARK(`, `WAITFOR DELAY`, `PG_SLEEP(` (time-based blind) |
| SQLI-06 | `information_schema`, `@@version`, `LOAD_FILE(`, `INTO OUTFILE`, `xp_cmdshell` |
| SQLI-07 | A quote followed by `AND`/`OR`/`UNION`/`SELECT`/`ORDER BY` |
| SQLI-08 | Encoded or double-encoded metacharacters (`%27 %22 %23 %2d%2d %3b %25..`) **and** SQL context; or `CHAR(…)`/`0x…` obfuscation with another rule |

**Output.** Each request gives one finding listing all the rules it triggered. Confidence is low (1 rule), medium (2) or high (3+). The finding includes the evidence snippet and a plain-language explanation.

**Limitation.** An access log cannot show whether the query actually executed. Look for 500 errors, unusual response sizes and the database logs.

## 14. XSS Detection Methodology

XSS injects script into pages viewed by other users.

**Decoding.** As for SQL injection, then HTML entities are unescaped twice (`&lt;script&gt;` becomes `<script>`).

| Rule | Detects |
|---|---|
| XSS-01 | `<script` |
| XSS-02 | Event handlers (`onerror=`, `onload=`, `ontoggle=` …) inside a tag or after a quote or space |
| XSS-03 | `javascript:`, `vbscript:`, `data:text/html` |
| XSS-04 | Injected tags (`iframe`, `svg`, `img`, `body`, `details`, `object` …) |
| XSS-05 | Sinks and proof functions (`document.cookie`, `window.location`, `alert(`, `eval(`, `String.fromCharCode`) |
| XSS-06 | Encoded `<` (`%3C`, `%253C`, `&lt;`, `&#60;`, `\x3c`) that decodes into a tag |

**Potential vs confirmed.** A match shows the input was *sent*. Confirming a vulnerability needs evidence that the application reflected or stored it without output encoding. A 200 status only shows the request was accepted.

## 15. Directory Traversal Detection Methodology

Traversal uses `../` to escape the web root and read files.

| Rule | Detects |
|---|---|
| TRV-01 | `../` or `..\` after decoding (including `....//`) |
| TRV-02 | URL-encoded dots or slashes (`%2e%2e%2f`, `..%5c`) in the raw request |
| TRV-03 | Double-encoded dots (`%252e`) or overlong UTF-8 (`%c0%ae`, `%c0%af`, `%uff0e`), which target decoders that decode twice |
| TRV-04 | OS paths: `/etc/passwd`, `/etc/shadow`, `/proc/self/environ`, `boot.ini`, `win.ini`, `C:\` |
| TRV-05 | A file-loading parameter (`file=`, `page=`, `template=` …) pointing at `.env`, `wp-config.php`, `.git/config`, `id_rsa` … |
| TRV-06 | `%00` null byte, only together with another TRV rule |

A direct request for `/.env` is reconnaissance, not traversal. Requests answered with **200** should be reviewed first, together with the response size. Only strings are analysed; no file is opened.

## 16. Brute-Force Detection Methodology

**Events per IP:**
- **failure:** a status in {401, 403} on an authentication endpoint, or a 401 on any path (HTTP authentication);
- **attempt:** a POST to an authentication endpoint (`/login`, `/wp-login.php`, `/xmlrpc.php`, … configurable).

**Sliding window.** Timestamps are sorted, and two pointers find the largest number of events within any `window` (default 5 minutes). This avoids splitting a burst at clock boundaries.

**Rules:**

| Rule | Condition |
|---|---|
| BF-01 | Failures ≥ 10 in the window |
| BF-02 | Login POSTs ≥ 10, which catches applications that answer failed logins with 200 |
| BF-03 | A login answered 2xx/3xx after BF-01, meaning a possible successful guess |

**Intensity.** A peak of 20 or more adds 10 points (High tier); a peak of 50 or more adds 20 (Critical tier). All thresholds are configurable.

**Caveat.** Status codes alone cannot confirm authentication failure:
- 403 is also used for forbidden directories;
- many applications return 200 with an error message.

Confirm with the application's authentication log.

## 17. Risk-Scoring Methodology

| Category | Points |
|---|---|
| SQL injection | 25 |
| XSS | 25 |
| Directory traversal | 30 |
| Repeated authentication failures | 20 (+10 or +20 intensity) |
| Reconnaissance | 15 |
| Excessive frequency | 15 |
| Other HTTP anomalies | 10 |
| Multiple attack categories | +10 per extra category, max +20 |

**Score** = the sum over the **distinct** categories found for the IP, plus bonuses, capped at 100.

**Bands:** 0–24 Low · 25–49 Medium · 50–74 High · 75–100 Critical.

Duplicates do not inflate the score: 40 injection requests add 25 points once, and all 40 remain as evidence. Every contribution is listed, for example `Potential SQL injection (25) + Suspicious reconnaissance (15) + HTTP anomaly (10) + Multiple attack categories (10) = 60`. The score is a triage priority, not a probability and not proof of compromise.

**Sample results:**

| IP | Score | Level |
|---|---|---|
| 203.0.113.66 (Nikto) | 100 | Critical (130 before the cap) |
| 198.51.100.23 (sqlmap) | 60 | High |
| 203.0.113.10 (login brute force) | 50 | High |
| Five other IPs | 25–30 | Medium |
| Four likely-benign IPs | 10 | Low |

## 18. Database Schema

| Table | Columns |
|---|---|
| analyses | id PK, analysed_at, file_name, file_sha256, synthetic, total_lines, parsed, malformed, unique_ips, incidents, settings JSON |
| incidents | incident_id PK (`WEB-` + SHA-1 of log hash and IP), ip, file_name, file_sha256, synthetic, risk_score, risk_level, categories JSON, rules JSON, total_requests, suspicious_requests, failed_responses, first_seen, last_seen, details JSON, status CHECK(Open/Investigating/Resolved), analyst_notes, created_at, updated_at, times_detected |
| incident_notes | id PK, incident_id FK (cascade), noted_at, analyst, status, note |

- The upsert on re-analysis refreshes the detection fields only, never the status or notes.
- All queries are parameterised; the IP search is a bound `LIKE` parameter.
- Notes are stripped of control characters and limited to 2,000 characters.

## 19. Testing Methodology

158 pytest tests run on synthetic inputs, with `python -m pytest -q`. The expected result is `158 passed` in about 10 seconds; `sample_output/test_results.txt` has the verbose list.

- **Unit tests** cover every parser branch and every detection rule, with both positive and negative (false-positive) cases. Boundary tests check thresholds (9 vs 10 failures, 100 vs 101 requests) and windows (spread-out attempts, minute boundaries).
- **Integration tests** cover the engine on the sample logs (exact levels per IP), SQLite persistence across a simulated restart and re-analysis, the filters, injection-safe search, and the reports.
- **Interface tests** cover the CLI end to end and all 12 dashboard pages with a stand-in Streamlit module (with and without Plotly), including upload validation, re-scoring, status persistence and downloads.
- **Demonstration testing:** `run_demos.py` checks the expected outcome of each demo and prints PASS or FAIL. All 9 pass.

## 20. Sample Output Descriptions

| File | Content |
|---|---|
| `sample_output/demo_results.txt` | The full run of Demos 1–9 |
| `cli_analyze_access.txt` | Statistics, incidents, score explanations and per-IP findings for the full sample |
| `cli_analyze_normal.txt` | The normal log: 0 incidents |
| `cli_analyze_common_format.txt` | The CLF log in −0500, normalised to UTC |
| `cli_incidents.txt` | Stored incidents |
| `security_investigation_report.pdf` | 7 pages: parsing statistics, status distribution, categories, severity breakdown, suspicious IPs, per-incident evidence, score explanation and recommendations, SYNTHETIC banner |
| `suspicious_requests.csv` (52 rows), `suspicious_ips.csv` (12), `incidents.csv` | The CSV exports |
| `screenshots/` | Terminal output of the demos, CLI and tests, and PDF pages |

## 21. Advantages and Limitations

**Advantages**

- Decoding-aware rules: catches URL, double, overlong and HTML-entity encodings.
- Context-based SQL and XSS rules, with tested benign look-alikes.
- Sliding time windows for brute force and frequency.
- Explainable findings, de-duplicated transparent scoring, and per-IP investigation.
- Persistent incident workflow; professional PDF and CSV reports.
- Safe by design: read-only, no blocking, no outbound traffic, secrets redacted in displays and exports, protection against CSV formula injection.

**Limitations**

- **Heuristic rules.** Clever obfuscation can evade them, and unusual but legitimate URLs can trigger them. Rules see only what the access log contains.
- **No request bodies.** POST data is not logged, so injection in form fields is invisible unless it appears in the URL.
- **Outcome unknown.** The log shows the status and size, not whether a payload executed.
- **Proxies and NAT.** Many users can share one IP, and attackers can rotate IPs (distributed brute force is not correlated).
- **Fixed formats.** Custom `LogFormat` variants (e.g. `vhost_combined`) need conversion. Logs are processed in memory (≤ 200 MB, 2 million lines).
- **Not verified in the build environment:** Streamlit and Plotly were not installable there, so the dashboard was exercised with stand-in modules (logic only, no visual check). Only synthetic logs were analysed; thresholds will need tuning on real traffic.

## 22. Future Enhancements

- Additional formats: Nginx, IIS W3C, vhost_combined, JSON logs; streaming and tail-follow mode.
- GeoIP and ASN enrichment (offline databases) and distributed brute-force correlation across IPs.
- Correlation with `error.log`, application logs and WAF logs (ModSecurity audit log) to confirm outcomes.
- Machine-learning anomaly models (isolation forest on per-IP features) alongside the rules.
- Sigma-rule export and SIEM forwarding (syslog, JSON lines); alert e-mails.
- A role-based multi-analyst workflow; case attachments.

## 23. Conclusion

The project shows that Apache access logs contain enough information to recognise most common web attack attempts, provided the requests are decoded before matching and behaviour is evaluated over time windows rather than line by line.

Combining request-level rules with per-IP behaviour and a transparent, de-duplicated score produces a small, prioritised list of incidents with clear evidence. On the synthetic log, the system produced no false alarms on normal browsing and ranked the attackers sensibly.

Its limits (no request bodies, unknown outcomes, heuristic rules) are stated throughout. It is a triage and learning tool whose findings always need an analyst's validation.

## 24. References

1. Apache HTTP Server 2.4 Documentation, *Log Files* and *mod_log_config* (LogFormat directives).
2. RFC 9110, *HTTP Semantics* (methods, status codes), 2022.
3. RFC 3986, *Uniform Resource Identifier (URI): Generic Syntax* (percent-encoding), 2005.
4. RFC 5737, *IPv4 Address Blocks Reserved for Documentation*, 2010.
5. OWASP Top 10 (2021): A03 Injection, A01 Broken Access Control, A07 Identification and Authentication Failures.
6. OWASP Cheat Sheets: SQL Injection Prevention, Cross Site Scripting Prevention, Input Validation, Authentication.
7. OWASP Web Security Testing Guide: Testing for Path Traversal.
8. MITRE ATT&CK: T1190 Exploit Public-Facing Application, T1110 Brute Force, T1595 Active Scanning.
9. CWE-89 (SQL Injection), CWE-79 (XSS), CWE-22 (Path Traversal), CWE-307 (Excessive Authentication Attempts).
10. NIST SP 800-92, *Guide to Computer Security Log Management*; NIST SP 800-61 Rev. 2, *Computer Security Incident Handling Guide*.
11. P. J. Rousseeuw and C. Croux, "Alternatives to the Median Absolute Deviation", *JASA*, 1993 (robust z-score).
12. pandas, NumPy, Streamlit, Plotly, ReportLab and Python `re` / `urllib.parse` documentation.
