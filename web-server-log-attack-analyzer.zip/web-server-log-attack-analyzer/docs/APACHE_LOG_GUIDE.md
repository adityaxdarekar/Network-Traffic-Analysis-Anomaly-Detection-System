# Apache Access Logs: a practical guide (Demo 1)

Use only a web server you own or are authorised to administer, such as a local lab VM.

## 1. What an access log is

Apache's `mod_log_config` writes **one line per HTTP request**, after the response has been sent. The line records:

- who asked (client IP);
- when (time with time-zone offset);
- what was asked (the request line);
- how the server answered (status code and response size);
- in the Combined format, where the user came from (Referer) and which software made the request (User-Agent).

Errors from the server itself go to a separate `error.log`.

## 2. Where to find it

| System | Access log | Error log | Configuration |
|---|---|---|---|
| Ubuntu / Debian / Kali | `/var/log/apache2/access.log` | `/var/log/apache2/error.log` | `/etc/apache2/apache2.conf`, `sites-enabled/*.conf` |
| RHEL / CentOS / Fedora | `/var/log/httpd/access_log` | `/var/log/httpd/error_log` | `/etc/httpd/conf/httpd.conf` |
| XAMPP (Windows) | `C:\xampp\apache\logs\access.log` | `error.log` | `C:\xampp\apache\conf\httpd.conf` |

```bash
grep -R "CustomLog\|LogFormat" /etc/apache2/        # which file and which format each site uses
ls -l /var/log/apache2/                              # access.log, access.log.1, access.log.2.gz ...
sudo tail -f /var/log/apache2/access.log             # watch requests arrive
```

- **Rotation:** `logrotate` renames the log to `access.log.1`, then compresses older copies as `.2.gz`, `.3.gz` and so on. Decompress a copy before uploading it: `gunzip -k access.log.2.gz`.
- **Permissions:** the logs belong to `root:adm`. Copy one for analysis instead of running the analyzer as root:

  ```bash
  sudo cp /var/log/apache2/access.log ~/lab_access.log && sudo chown $USER ~/lab_access.log
  ```

## 3. Lab setup (optional, Kali or Ubuntu)

```bash
sudo apt install -y apache2
sudo systemctl start apache2
curl -s http://127.0.0.1/ > /dev/null                # one normal request to your own server
curl -s http://127.0.0.1/does-not-exist > /dev/null  # a 404
sudo tail -n 2 /var/log/apache2/access.log
```

You will see two Combined-format lines from `127.0.0.1` with User-Agent `curl/...`. Only send requests to **your own** lab server. For attack patterns, use the bundled synthetic logs instead of generating them.

## 4. Common Log Format (CLF)

```apache
LogFormat "%h %l %u %t \"%r\" %>s %b" common
```

| Field | Meaning | Example |
|---|---|---|
| `%h` | Client IP (or host name if HostnameLookups is on) | `192.0.2.15` |
| `%l` | identd identity, almost always `-` | `-` |
| `%u` | User name from HTTP authentication, `-` if none | `frank` |
| `%t` | Time the request was received, with zone offset | `[02/Nov/2026:04:12:09 -0500]` |
| `"%r"` | Request line: method, target, protocol | `"POST /login HTTP/1.1"` |
| `%>s` | Final status code | `401` |
| `%b` | Response bytes without headers, `-` for 0 | `381` |

Example: `192.0.2.15 - - [02/Nov/2026:04:12:09 -0500] "POST /login HTTP/1.1" 401 381`

## 5. Combined Log Format

```apache
LogFormat "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\"" combined
CustomLog ${APACHE_LOG_DIR}/access.log combined
```

It is CLF plus two quoted headers:

- **Referer:** the page that linked to this request;
- **User-Agent:** the client software, such as a browser, curl or a scanner.

Example:

```
203.0.113.10 - - [02/Nov/2026:09:20:04 +0000] "POST /login HTTP/1.1" 401 381 "https://shop.example.com/login" "python-requests/2.31.0"
```

Details the parser handles:

- **Escaping:** Apache writes `"` inside fields as `\"`, and non-printable bytes as `\xhh`. A TLS handshake sent to port 80 appears as `"\x16\x03\x01..." 400`; the analyzer keeps it with method `INVALID`.
- **Time-outs:** a client that never sent a request gets `"-" 408`.
- **Time zones:** each line carries its own offset. The analyzer converts everything to **UTC**, so `04:12:09 -0500` becomes `09:12:09 UTC`.

## 6. Upload a log into the application

1. Run `streamlit run app.py` and open **Apache Log Upload**.
2. Choose `sample_logs/access.log` and click **Analyse sample**, or upload `~/lab_access.log`.
3. Check the parsing statistics:
   - lines in the file and log entries;
   - entries parsed successfully;
   - the malformed list, with line number, reason and original text;
   - the formats detected and the time range in UTC.
4. In the terminal: `python run_demos.py` (Demo 1) or `python analyze_log.py ~/lab_access.log`.

The bundled `access.log` has 887 entries: 882 are parsed and 5 deliberately broken lines are listed with their reasons:
- not an Apache line;
- invalid month;
- invalid IP address;
- unterminated request;
- invalid status code.
