"""
config.py - every detection threshold, scoring weight and path in one place.

All values can be changed on the dashboard's Detection Configuration page
or with analyze_log.py options. DetectionConfig.validate() rejects
impossible values before they are used.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SAMPLE_DIR = BASE_DIR / "sample_logs"
DB_PATH = BASE_DIR / "database" / "incidents.db"
REPORT_DIR = BASE_DIR / "reports"
LOG_FILE = BASE_DIR / "logs" / "analyzer.log"
CSS_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "Web Server Log Attack Analyzer and Threat Detection Dashboard"
MAX_UPLOAD_MB = 200
MAX_LINES = 2_000_000
RISK_LEVELS = ["Low", "Medium", "High", "Critical"]
RISK_COLORS = {"Low": "#22c55e", "Medium": "#eab308", "High": "#f97316", "Critical": "#ef4444"}
INCIDENT_STATUSES = ["Open", "Investigating", "Resolved"]

# Attack categories (scored once each per IP) and HTTP anomaly categories.
CATEGORY_NAMES = {
    "sql_injection": "Potential SQL injection",
    "xss": "Potential XSS",
    "traversal": "Directory traversal",
    "brute_force": "Repeated authentication failures",
    "reconnaissance": "Suspicious reconnaissance",
    "excessive_frequency": "Excessive request frequency",
    "http_anomaly": "HTTP anomaly",
}
ATTACK_CATEGORIES = ("sql_injection", "xss", "traversal", "brute_force", "reconnaissance")

DEFAULT_WEIGHTS = {
    "sql_injection": 25,
    "xss": 25,
    "traversal": 30,
    "brute_force": 20,
    "reconnaissance": 15,
    "excessive_frequency": 15,
    "http_anomaly": 10,
}

DEFAULT_AUTH_PATHS = ["/login", "/signin", "/sign-in", "/wp-login.php", "/admin/login", "/user/login", "/auth",
                      "/account/login", "/session", "/xmlrpc.php", "/j_security_check", "/api/login", "/api/auth"]
DEFAULT_ALLOWED_METHODS = ["GET", "POST", "HEAD"]


@dataclass
class DetectionConfig:
    # Brute force / authentication abuse
    bf_max_failed: int = 10            # failures in the window that raise a finding
    bf_window_minutes: float = 5.0
    bf_high_threshold: int = 20        # -> extra points (intensity)
    bf_critical_threshold: int = 50    # -> more extra points
    bf_high_bonus: int = 10
    bf_critical_bonus: int = 20
    bf_failure_statuses: list = field(default_factory=lambda: [401, 403])
    auth_paths: list = field(default_factory=lambda: list(DEFAULT_AUTH_PATHS))
    # Reconnaissance
    recon_min_sensitive_paths: int = 3     # distinct admin / sensitive / backup paths from one IP
    recon_max_404: int = 20                # 404 responses from one IP
    recon_min_unique_paths: int = 30       # distinct paths from one IP ...
    recon_min_error_ratio: float = 0.5     # ... when at least this share of its responses are 4xx
    # HTTP anomalies
    freq_window_seconds: int = 60
    freq_max_requests: int = 100           # requests from one IP in the window
    repeat_path_threshold: int = 50        # identical path from one IP in the frequency window
    error_ratio_threshold: float = 0.5     # share of 5xx responses from one IP ...
    error_ratio_min_requests: int = 10     # ... with at least this many requests
    size_mad_threshold: float = 10.0       # robust z-score for response sizes
    size_min_bytes: int = 1_000_000        # sizes below this are never flagged
    allowed_methods: list = field(default_factory=lambda: list(DEFAULT_ALLOWED_METHODS))
    # Scoring
    weights: dict = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    multi_category_bonus: int = 10         # per attack category beyond the first ...
    multi_category_bonus_cap: int = 20     # ... capped here
    # Privacy and allowlist
    redact_secrets: bool = True            # mask password/token query values in displays and exports
    allowlist_ips: list = field(default_factory=list)

    def validate(self) -> list[str]:
        e = []
        if self.bf_max_failed < 1:
            e.append("maximum failed attempts must be at least 1")
        if not 0 < self.bf_window_minutes <= 1440:
            e.append("brute-force window must be between 0 and 1440 minutes")
        if not self.bf_max_failed <= self.bf_high_threshold <= self.bf_critical_threshold:
            e.append("thresholds must satisfy max failed <= high <= critical")
        if self.freq_window_seconds < 1 or self.freq_max_requests < 2:
            e.append("frequency window must be >= 1 s and the request threshold >= 2")
        if not 0 < self.recon_min_error_ratio <= 1 or not 0 < self.error_ratio_threshold <= 1:
            e.append("ratios must be between 0 and 1")
        if self.recon_min_sensitive_paths < 1 or self.recon_max_404 < 1 or self.recon_min_unique_paths < 2:
            e.append("reconnaissance thresholds must be positive")
        if self.size_mad_threshold <= 0:
            e.append("the response-size threshold must be positive")
        if any(not isinstance(v, int) or v < 0 or v > 100 for v in self.weights.values()):
            e.append("weights must be whole numbers between 0 and 100")
        if set(self.weights) != set(DEFAULT_WEIGHTS):
            e.append("weights must cover every category")
        if not self.allowed_methods:
            e.append("at least one HTTP method must be allowed")
        return e

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "DetectionConfig":
        known = {k: v for k, v in (d or {}).items() if k in cls.__dataclass_fields__}
        cfg = cls(**known)
        cfg.weights = {**DEFAULT_WEIGHTS, **(cfg.weights or {})}
        return cfg
