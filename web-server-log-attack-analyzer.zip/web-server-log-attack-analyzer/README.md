# Web Server Log Attack Analyzer and Threat Detection Dashboard

**Python · Pandas · Regex · NumPy · Streamlit · Plotly · SQLite · ReportLab · Pytest**

This is a defensive analyzer for **Apache access logs**. It parses Common and Combined Log Format, as well as CSV, and looks for indicators of:

- SQL injection
- Cross-Site Scripting (XSS)
- directory traversal
- brute-force logins
- reconnaissance or scanning
- unusual HTTP behaviour

It explains every finding and scores each source IP from 0 to 100 (Low to Critical). Incidents are tracked in SQLite, results are shown on a 12-page Streamlit SOC dashboard, and reports export as CSV and PDF.

> **Defensive only.**
> - The tool only *reads* log files. It never sends a request, replays a payload, blocks an IP or contacts any system.
> - All bundled logs are **synthetic**: generated text using documentation IP ranges and a fictional site.
> - Every detection is a **potential** attack, an indicator for an analyst to validate. It is never a confirmed compromise.

---

## 1. Working principle

Every request to Apache is written as one line in `access.log`. Attacks leave traces in those lines:

- **in the request string:** `' OR '1'='1`, `<script>`, `../../etc/passwd`;
- **in the pattern of requests:** 58 failed logins in 4 minutes, 80 different admin and backup paths from one IP, 140 identical calls in 55 seconds;
- **in the User-Agent:** `sqlmap`, `Nikto`, `gobuster`.

The analyzer works in five steps:

1. **Parse** each line into fields with a regular expression. Malformed lines are kept with a reason and never stop the parse. Timestamps are normalised to UTC.
2. **Decode** each request target before matching: percent-decoding is repeated to catch double encoding, `+` becomes a space, HTML entities are unescaped, and SQL `/**/` comments are removed. This catches `%27`, `%2527`, `&lt;script&gt;` and `UNION/**/SELECT`.
3. **Detect:** 36 named rules (SQLI-01…08, XSS-01…06, TRV-01…06, BF-01…03, REC-01…07, ANOM-01…06). Request rules look at single requests; behaviour rules look at each IP over **sliding time windows**.
4. **Score** each IP from the *distinct* categories found. 40 SQL injection requests still count 25 points once, and all 40 stay as evidence.
5. **Investigate:** use the dashboard pages, the per-IP view, incidents with status and notes, and the CSV and PDF reports.

## 2. Architecture

```
 access.log / .txt / .csv ──► log_parser (regex, validation, UTC, malformed list)
                                   │  pandas DataFrame (one row per request)
                                   ▼
            normalizer (URL / double / HTML-entity decoding, SQL comment removal)
                                   │
    ┌───────────────── request detectors ─────────────────┐   ┌────────── per-IP detectors (sliding windows) ─────────┐
    │ sql_injection_detector · xss_detector · traversal    │   │ brute_force · reconnaissance · anomaly (NumPy MAD)    │
    └──────────────────────────┬───────────────────────────┘   └──────────────────────────┬─────────────────────────────┘
                               └────────────── Finding(rule IDs, evidence, explanation) ──┘
                                                       ▼
                         risk_scorer: one incident per IP, each category once, bonuses, cap 100
                                                       ▼
          db_manager (SQLite) ◄──► app.py (12 pages) · analyze_log.py (CLI) · report_generator (CSV, PDF)
```

## 3. Folder structure

```
web-server-log-attack-analyzer/
├── app.py                         Streamlit SOC dashboard (12 pages)
├── analyze_log.py                 command-line analysis, incident list, status updates
├── run_demos.py                   the 9 practical demonstrations (prints PASS/FAIL)
├── config.py                      every threshold and weight (DetectionConfig + validation)
├── requirements.txt  pytest.ini  .gitignore  .streamlit/config.toml
├── analyzer/
│   ├── log_parser.py              Common / Combined / CSV parsing, validation, UTC timestamps
│   ├── normalizer.py              safe decoding views of each request target
│   ├── findings.py                Finding / Rule data structures, sliding-window helper
│   ├── sql_injection_detector.py  SQLI-01..08
│   ├── xss_detector.py            XSS-01..06
│   ├── traversal_detector.py      TRV-01..06
│   ├── brute_force_detector.py    BF-01..03 (sliding window, intensity tiers)
│   ├── reconnaissance_detector.py REC-01..07
│   ├── anomaly_detector.py        ANOM-01..06 (frequency, methods, 5xx, User-Agent, response size)
│   ├── risk_scorer.py             incidents, scores, explanations, recommendations
│   └── engine.py                  one complete analysis (used by every interface)
├── database/
│   ├── db_manager.py              analyses, incidents, incident_notes
│   └── incidents.db               contains the synthetic demo analysis (delete it to start empty)
├── utils/
│   ├── sample_log_generator.py    SYNTHETIC logs (11 scenarios)
│   ├── report_generator.py        4 CSV exports + PDF
│   └── helpers.py                 upload validation, secret redaction, CSV-injection guard, logging
├── assets/style.css               dark SOC theme
├── sample_logs/                   access.log (887 entries) + 6 demo logs + CLF log + CSV
├── tests/                         158 pytest tests
├── docs/                          APACHE_LOG_GUIDE, DEMO_GUIDE, PROJECT_REPORT, VIVA
├── sample_output/                 real output of run_demos.py / analyze_log.py, PDF and CSV files
├── screenshots/                   terminal output and PDF pages
└── PROJECT_STATUS.md              what was verified and what was not
```

## 4. Apache log formats

```apache
LogFormat "%h %l %u %t \"%r\" %>s %b" common
LogFormat "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\"" combined
CustomLog ${APACHE_LOG_DIR}/access.log combined
```

```
203.0.113.10 - - [02/Nov/2026:09:20:04 +0000] "POST /login HTTP/1.1" 401 381 "https://shop.example.com/login" "python-requests/2.31.0"
└─ %h client ┘ │ └%u┘ └──────── %t time ───────┘ └──── %r request ────┘ %>s  %b  └──── Referer ────────────────┘ └─── User-Agent ───┘
               %l (identd, always "-")                                status bytes
```

The **Common** format stops after `%b`. See `docs/APACHE_LOG_GUIDE.md` for where to find the logs, rotation, and permissions.

**CSV logs** need the columns `timestamp, ip, method, path, status`, and may also have `protocol, size, referrer, user_agent`. Aliases such as `client_ip`, `url` and `status_code` are accepted. Timestamps can be ISO 8601 or in Apache format.

## 5. Installation (Kali Linux / Ubuntu)

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
cd web-server-log-attack-analyzer
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q          # expected last line: 158 passed
```

- **Windows:** `py -m venv .venv`, then `.\.venv\Scripts\Activate.ps1`, then the same pip and pytest commands.
- **Rights:** no root or administrator rights are needed. To read the server's real log, copy it as an authorised user first: `sudo cp /var/log/apache2/access.log ~/` followed by `sudo chown $USER ~/access.log`.

## 6. Generating the synthetic logs

```bash
python -m utils.sample_log_generator       # seeded: produces identical files every time
```

| File | Content | Expected result |
|---|---|---|
| `access.log` | Every scenario below, plus 5 malformed lines (887 entries) | 12 suspicious IPs: 1 Critical, 2 High, 5 Medium, 4 Low |
| `demo_normal.log` | 12 browsing visitors, Googlebot, a 408, benign searches with SQL words, one mistyped password | 0 incidents |
| `demo_sqli.log` | Normal traffic + `sqlmap` (16 requests, many 500s) | 198.51.100.23 High 60 |
| `demo_xss.log` | Normal traffic + 10 script-like searches | 198.51.100.45 Medium 25 |
| `demo_traversal.log` | Normal traffic + 12 traversal requests (encoded, double-encoded, overlong, null byte) | 192.0.2.77 Medium 30 |
| `demo_bruteforce.log` | 58 × `POST /login` 401, then a 302; 24 × `wp-login.php` 403 | 203.0.113.10 High 50, 198.51.100.77 Medium 30 |
| `demo_recon.log` | `gobuster` word list (87 paths, mostly 404) + OPTIONS/TRACE/PUT | 203.0.113.99 Medium 25 |
| `demo_common_format.log` | A mix in **Common** Log Format, server time zone −0500 | 4 Medium (no User-Agent rules in CLF) |
| `access_sample.csv` | CSV version (normal + XSS + brute force) | 3 incidents |

`access.log` also contains:
- a curl health check every 5 minutes;
- a 48 MB download;
- OPTIONS, TRACE and PROPFIND requests;
- a TLS handshake sent to port 80;
- a 140-request API burst;
- a Nikto scan mixing SQL injection, XSS, traversal and probes (**Critical 100**).

## 7. Launching the dashboard

```bash
streamlit run app.py              # opens http://localhost:8501
```

Open **Apache Log Upload**, then either choose `access.log` and click **Analyse sample**, or upload your own `.log`, `.txt` or `.csv` file (up to 200 MB).

| # | Page | What it shows |
|---|---|---|
| 1 | Security Overview | 9 metric cards and the 10 required Plotly charts |
| 2 | Apache Log Upload | Samples or upload, parsing statistics, the malformed entries list, a preview |
| 3 | HTTP Traffic Analysis | Traffic per status class, error ratio per IP, HTTP anomalies, a filterable request explorer |
| 4–6 | SQL Injection / XSS / Directory Traversal | Rule reference, an offline request tester, flagged requests with decoded text and evidence, recommendations |
| 7 | Brute Force Detection | 401/403 per minute, IPs over the threshold, the busiest window, success after failures |
| 8 | Reconnaissance Analysis | 404s per IP, probed sensitive paths, scanner User-Agents |
| 9 | Suspicious IP Investigation | IP table and per-IP profile: score contributions, findings, all requests |
| 10 | Incident Management | Filter by attack type, risk, status and IP; evidence; Open → Investigating → Resolved; notes and history |
| 11 | Reports and Downloads | 4 CSV files and the PDF; analysis history |
| 12 | Detection Configuration | Every threshold, authentication path, allowed method, IP allowlist, redaction setting, weight and bonus |

## 8. Detection rules (summary)

The full explanations are in each module's docstring and on the dashboard.

| Category | Rules | Weight |
|---|---|---|
| SQL injection | SQLI-01 tautology · 02 UNION SELECT · 03 `; DROP`/stacked · 04 comment terminator · 05 SLEEP/BENCHMARK · 06 information_schema/@@version · 07 quote + keyword · 08 encoded metacharacters (only in SQL context) | 25 |
| XSS | XSS-01 `<script` · 02 `on…=` handlers · 03 `javascript:` · 04 injected tags · 05 `document.cookie`/`alert(` · 06 encoded markup | 25 |
| Traversal | TRV-01 `../` · 02 `%2e%2e%2f` · 03 `%252e`, `%c0%ae` · 04 `/etc/passwd`, `boot.ini` · 05 `?file=.env` · 06 `%00` (with another TRV rule) | 30 |
| Brute force | BF-01 ≥ 10 failures (401, or 401/403 on login paths) in a 5-minute sliding window · BF-02 ≥ 10 login POSTs · BF-03 success after failures | 20, plus 10 at ≥ 20 attempts or 20 at ≥ 50 |
| Reconnaissance | REC-01 admin · 02 sensitive files · 03 server info · 04 backups (≥ 3 distinct) · 05 scanner User-Agent · 06 ≥ 20 404s · 07 ≥ 30 paths with ≥ 50 % 4xx | 15 |
| Excessive frequency | ANOM-01 > 100 requests in any 60 s | 15 |
| HTTP anomaly | ANOM-02 identical path ≥ 50 per 60 s · 03 unusual methods · 04 ≥ 50 % 5xx · 05 empty/tool/injection User-Agent · 06 response-size robust z ≥ 10 and ≥ 1 MB | 10 |

**Score** = the sum of the weights of the distinct categories, plus the brute-force intensity bonus, plus **10 per extra attack category (at most 20)**, capped at 100.

| Score | Risk |
|---|---|
| 0–24 | Low |
| 25–49 | Medium |
| 50–74 | High |
| 75–100 | Critical |

**False-positive controls:**
- No SQL rule fires on a keyword alone. `?q=union station`, `how to select a drop table lamp` and `O'Brien` are tested negatives.
- Admin pages answered with 200 don't count as probes.
- `robots.txt` is context only.
- One mistyped password is not brute force.
- 408 time-outs aren't "empty User-Agent".
- The IP allowlist covers your own monitoring hosts.

## 9. Command line

```bash
python analyze_log.py sample_logs/access.log                       # summary, incidents, per-IP findings
python analyze_log.py sample_logs/access.log --show requests       # every suspicious request
python analyze_log.py access.log --save --pdf reports/r.pdf --csv reports/
python analyze_log.py access.log --max-failed 5 --window 2 --high 15 --critical 40 --allow-ip 10.0.5.20
python analyze_log.py --incidents
python analyze_log.py --set-status WEB-8B6F501689 Investigating --note "checking app logs"
python run_demos.py                                                # Demos 1-9, expected: all PASS
```

Expected key lines for `python analyze_log.py sample_logs/access.log` (full output in `sample_output/cli_analyze_access.txt`):

```
lines 889 | entries 887 | parsed 882 (99.4%) | malformed 5 | formats {'combined': 882} | unique IPs 25
indicators: SQLi 20 requests, XSS 15, traversal 17 | brute-force IPs 2, recon IPs 3, high-frequency IPs 2, anomaly IPs 8
Incidents (suspicious IPs): 12 (critical 1, high 2, medium 5, low 4)
  [CRITICAL 100] 203.0.113.66    Potential SQL injection (25) + Potential XSS (25) + Directory traversal (30) + Suspicious reconnaissance (15) + Excessive request frequency (15) + Multiple attack categories (20) = 130 (capped at 100)
  [HIGH      60] 198.51.100.23   Potential SQL injection (25) + Suspicious reconnaissance (15) + HTTP anomaly (10) + Multiple attack categories (10) = 60
  [HIGH      50] 203.0.113.10    Repeated authentication failures (20) + HTTP anomaly (10) + Brute-force intensity (20) = 50
```

## 10. Testing

```bash
python -m pytest -q                       # expected: 158 passed (about 10 s)
python -m pytest tests/test_sql_injection.py -v
```

| File | Tests | Covers |
|---|---|---|
| test_log_parser.py | 23 | Common, Combined, escaped quotes, `-` size, 408, invalid request line, IPv6, 10 kinds of malformed line, blank/comment lines, UTC normalisation, CSV aliases, binary rejection, sample statistics |
| test_sql_injection.py | 32 | Every rule, URL and double decoding, case variations, 11 benign look-alikes, one finding per request |
| test_xss.py | 24 | Every rule incl. entity- and double-encoded, 8 benign look-alikes |
| test_traversal.py | 22 | Plain, encoded, double, overlong, null byte, `/.env` = reconnaissance |
| test_brute_force.py | 11 | Sliding window, boundary 9/10, spread-out attempts, intensity tiers, 401 vs 403 semantics, 200-answered logins, success after failures, configurable endpoints |
| test_reconnaissance.py | 12 | Path classes, probes, 404 storms, crawlers, every HTTP anomaly rule |
| test_risk_scorer.py | 14 | Bands, weights, duplicate handling, bonuses and cap, sample levels, allowlist, redaction, **SQLite persistence across restart**, filters, injection-safe search, reports, CSV formula guard, upload validation |
| test_app_smoke.py | 16 | All 12 pages with and without a log and with and without Plotly, upload validation, re-scoring, incident persistence, downloads (Streamlit stand-in) |
| test_cli.py | 4 | CLI analyse/save/PDF/CSV/incidents/status, thresholds, errors, `run_demos.py` |

## 11. Troubleshooting

| Problem | Fix |
|---|---|
| `0 parsed`, every line malformed | Your `LogFormat` differs (e.g. `vhost_combined` starts with `host:port`). Change `LogFormat` to `combined`, or export to CSV with the standard columns. |
| "gzip archive" on upload | Rotated logs are compressed: `gunzip -k access.log.2.gz` |
| Permission denied on `/var/log/apache2` | Copy the file with sudo (section 5); never run the dashboard as root. |
| Too many Low alerts for monitoring tools | Add their IPs to the allowlist (Detection Configuration, or `--allow-ip`). |
| A real login brute force is not shown | Your login URL may be different: add it under *Authentication endpoints*. Apps that answer failed logins with 200 are caught only by BF-02 (login POST count). |
| POST bodies are not analysed | Apache access logs don't contain request bodies. Use the application or WAF logs for those. |
| Charts are plain | Install Plotly (`pip install plotly`). |
| Port 8501 in use | `streamlit run app.py --server.port 8502` |

See **docs/DEMO_GUIDE.md** for the 9 demonstrations step by step, and **PROJECT_STATUS.md** for what was and was not verified.
