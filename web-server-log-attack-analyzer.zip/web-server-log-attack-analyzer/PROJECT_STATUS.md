# Project Status: what was verified, and what was not

Build environment: Ubuntu container, Python 3.13, pandas 3, NumPy 2.5, reportlab 4, tabulate. **Not available: Streamlit, Plotly and an Apache server**. There was no network access, so nothing could be installed.

## Verified by running it

| Item | Evidence |
|---|---|
| 158 automated tests pass | `python -m pytest -q` (`sample_output/test_results.txt`) |
| Common, Combined and CSV parsing; malformed lines kept with reasons; UTC normalisation | `tests/test_log_parser.py`, Demo 1 |
| SQL injection, XSS and traversal rules, including encoded, double-encoded and entity-encoded payloads, plus benign look-alikes not flagged | `test_sql_injection.py`, `test_xss.py`, `test_traversal.py` |
| Brute-force sliding windows, thresholds, intensity, success after failures | `test_brute_force.py`, Demo 6 |
| Reconnaissance and all HTTP anomaly rules | `test_reconnaissance.py`, Demo 7 |
| Scoring: each category once, bonuses, cap at 100, expected level for every sample IP | `test_risk_scorer.py` |
| Normal traffic: 0 incidents | Demo 2, `cli_analyze_normal.txt` |
| Incident status and notes persist after restart and re-analysis | Demo 8, `test_incident_persistence_across_restart` |
| CSV and PDF reports | `sample_output/` (PDF: 7 pages), `screenshots/10_*` |
| CLI end to end | `test_cli.py`, `sample_output/cli_*.txt` |

## Not verified (honest gaps)

| Item | Status |
|---|---|
| **Streamlit dashboard in a browser** | All 12 pages were run with stand-in Streamlit and Plotly modules, with and without Plotly and with and without a log loaded (`tests/test_app_smoke.py`). That checks the logic, data wiring, upload validation, re-scoring and persistence, **not** the visual layout. There are no dashboard screenshots; take them after `pip install -r requirements.txt` and `streamlit run app.py`. |
| Real Apache logs | Only synthetic logs and hand-written test lines were analysed. The parser follows the documented LogFormat directives, but real-world variants (custom formats, `vhost_combined`) were not tried. Expect to tune thresholds on real traffic. |
| Real attack outcomes | By design, the tool cannot tell whether an attack succeeded (no request bodies or responses in access logs). |

## Data honesty

- All sample logs are **SYNTHETIC**:
  - generated text from a seeded generator;
  - documentation IP ranges (RFC 5737) plus one private 10.x address;
  - a fictional `shop.example.com`.
- The attack strings are textbook examples used only as test data. Nothing was ever sent to a website.
- The logs are marked by a `# SYNTHETIC` header (CSV: a `.synthetic` sidecar file) and labelled in the dashboard, the CLI and the PDF.
- `database/incidents.db` contains only the synthetic analysis of `access.log`. Delete it to start empty.
- The timestamps (2 Nov 2026) were chosen by the generator.
