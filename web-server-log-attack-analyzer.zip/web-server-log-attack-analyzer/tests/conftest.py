import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from analyzer.engine import analyze_parsed           # noqa: E402
from analyzer.log_parser import parse_lines          # noqa: E402
from config import DetectionConfig                   # noqa: E402
from database.db_manager import DBManager            # noqa: E402

T0 = datetime(2026, 11, 2, 9, 0, 0, tzinfo=timezone.utc)
UA = "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0"


def line(ip="192.0.2.10", sec=0, method="GET", path="/", status=200, size=512, ua=UA, ref="-", fmt="combined"):
    """One synthetic Apache log line, `sec` seconds after T0."""
    t = (T0 + timedelta(seconds=sec)).strftime("%d/%b/%Y:%H:%M:%S +0000")
    req = "-" if method == "-" else f"{method} {path} HTTP/1.1"
    base = f'{ip} - - [{t}] "{req}" {status} {size if size else "-"}'
    return base if fmt == "common" else f'{base} "{ref}" "{ua}"'


def parse(lines, name="test.log"):
    return parse_lines(lines, name, sha256="0" * 64)


def analyze(lines, cfg=None):
    return analyze_parsed(parse(lines), cfg or DetectionConfig())


@pytest.fixture
def cfg():
    return DetectionConfig()


@pytest.fixture
def db(tmp_path):
    d = DBManager(tmp_path / "incidents.db")
    yield d
    d.close()


@pytest.fixture
def normal_lines():
    """A small, clearly normal browsing session from several IPs."""
    out = []
    for k in range(5):
        for n, p in enumerate(["/", "/products", "/static/css/site.css", "/search?q=union+station", "/about"]):
            out.append(line(f"192.0.2.{20 + k}", k * 100 + n * 7, path=p))
    return out
