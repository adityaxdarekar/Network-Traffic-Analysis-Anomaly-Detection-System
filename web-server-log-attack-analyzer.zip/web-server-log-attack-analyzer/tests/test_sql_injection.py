"""SQL injection rules, URL decoding, case handling and false-positive avoidance."""
import pytest

from analyzer import sql_injection_detector as sqli
from analyzer.normalizer import percent_decode, view
from conftest import analyze, line


def ids(target):
    return {r.rule_id for r, _ in sqli.detect(target)}


@pytest.mark.parametrize("target, rule", [
    ("/item?id=1' OR '1'='1", "SQLI-01"),
    ("/item?id=1%27%20OR%20%271%27%3D%271", "SQLI-01"),
    ("/item?id=1 or 1=1", "SQLI-01"),
    ('/item?id=1" or "a"="a', "SQLI-01"),
    ("/p?id=-1+UNION+SELECT+1,2,3", "SQLI-02"),
    ("/p?id=-1 union all select null,null", "SQLI-02"),
    ("/x?id=1';DROP TABLE users--", "SQLI-03"),
    ("/x?id=1; DELETE FROM orders", "SQLI-03"),
    ("/x?u=admin'--", "SQLI-04"),
    ("/x?id=1 UNION/**/SELECT/**/1", "SQLI-04"),
    ("/x?id=1 AND SLEEP(5)", "SQLI-05"),
    ("/x?id=1;WAITFOR DELAY '0:0:5'", "SQLI-05"),
    ("/x?id=1 and 1=2 union select table_name from information_schema.tables", "SQLI-06"),
    ("/x?id=@@version", "SQLI-06"),
    ("/x?id=1' AND 1=1", "SQLI-07"),
    ("/x?id=1 ORDER BY 3--", "SQLI-07"),
    ("/x?id=1%2527%20OR%201=1--", "SQLI-08"),
])
def test_positive_rules(target, rule):
    assert rule in ids(target), (target, ids(target))


@pytest.mark.parametrize("target", [
    "/search?q=union+station", "/search?q=how+to+select+a+drop+table+lamp", "/blog/select-the-right-database",
    "/products?sort=order-by-price", "/search?q=O%27Brien+jacket", "/x?name=O'Brien", "/item?id=1 or 1=2",
    "/static/js/app.js", "/x?id=1%27", "/search?q=sleep+well+pillow", "/api/update?set=1",
])
def test_benign_requests_not_flagged(target):
    assert sqli.detect(target) == [], ids(target)


def test_case_variations():
    assert ids("/p?id=-1 UnIoN SeLeCt 1,2") == ids("/p?id=-1 union select 1,2") == {"SQLI-02"}


def test_url_decoding_layers():
    assert percent_decode("%2527") == ("'", 2)
    assert percent_decode("%25252e") == (".", 3)
    assert percent_decode("plain") == ("plain", 0)
    v = view("/a%20b?q=a+b%2Bc&x=%3Cs%3E")
    assert v.decoded == "/a b?q=a b+c&x=<s>" and v.layers == 1
    assert view("/q?x=&lt;b&gt;").html == "/q?x=<b>"
    assert view("/q?x=1/**/union/**/select").sql == "/q?x=1 union select"
    assert "\x00" not in view("/a%00b").decoded


def test_encoded_metacharacters_need_sql_context():
    assert "SQLI-08" in ids("/x?id=1%27%20or%20%271%27=%271")
    assert sqli.detect("/x?q=%27hello%27") == []                     # quotes alone are not SQL


def test_scan_reports_ip_request_and_explanation_one_finding_per_request():
    res = analyze([line("198.51.100.23", 0, path="/p?id=1%27%20OR%20%271%27%3D%271%20UNION%20SELECT%201--"),
                   line("198.51.100.23", 5, path="/p?id=2"), line("192.0.2.1", 9, path="/search?q=union+station")])
    fs = res.by_category("sql_injection")
    assert len(fs) == 1                                               # several rules, still ONE finding
    f = fs[0]
    assert f.ip == "198.51.100.23" and f.request.startswith("GET /p?id=1%27")
    assert {"SQLI-01", "SQLI-02", "SQLI-07", "SQLI-08"} <= set(f.rule_ids)
    assert "[SQLI-02]" in f.explanation and "Potential SQL injection" in f.explanation
    assert f.details["confidence"] == "high" and all(e.startswith("SQLI-") for e in f.evidence)
