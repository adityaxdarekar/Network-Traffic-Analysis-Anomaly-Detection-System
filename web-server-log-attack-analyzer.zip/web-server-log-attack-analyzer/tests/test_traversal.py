"""Directory traversal: plain, encoded, double-encoded, overlong, sensitive files, null bytes."""
import pytest

from analyzer import traversal_detector as trv
from conftest import analyze, line


def ids(target):
    return {r.rule_id for r, _ in trv.detect(target)}


@pytest.mark.parametrize("target, expected", [
    ("/d?file=../../../../etc/passwd", {"TRV-01", "TRV-04"}),
    ("/d?file=..\\..\\boot.ini", {"TRV-01", "TRV-04"}),
    ("/%2e%2e/%2e%2e/etc/shadow", {"TRV-01", "TRV-02", "TRV-04"}),
    ("/d?f=..%2F..%2Fapp.cfg", {"TRV-01", "TRV-02"}),
    ("/d?f=%252e%252e%252fetc%252fpasswd", {"TRV-01", "TRV-03", "TRV-04"}),
    ("/s/%c0%ae%c0%ae/%c0%ae%c0%ae/etc/passwd", {"TRV-03", "TRV-04"}),
    ("/d?file=.env", {"TRV-05"}),
    ("/v?template=../../wp-config.php", {"TRV-01", "TRV-05"}),
    ("/i?page=../../../etc/passwd%00.html", {"TRV-01", "TRV-04", "TRV-06"}),
    ("/d?file=/proc/self/environ", {"TRV-04"}),
    ("/d?file=....//....//etc/passwd", {"TRV-01", "TRV-04"}),
])
def test_positive(target, expected):
    assert expected <= ids(target), (target, ids(target))


@pytest.mark.parametrize("target", [
    "/.env", "/docs/v1..2/readme", "/products/1042", "/static/app.min.js", "/img/a%00", "/s?q=..",
    "/download?file=brochure.pdf", "/s?q=%252f",
])
def test_negative(target):
    assert trv.detect(target) == [], ids(target)


def test_null_byte_only_with_other_indicator():
    assert trv.detect("/a%00.jpg") == []
    assert "TRV-06" in ids("/a?file=../x%00.jpg")


def test_direct_env_request_is_reconnaissance_not_traversal():
    lines = [line("203.0.113.5", k, path=p, status=404) for k, p in enumerate(["/.env", "/.git/config", "/backup.zip"])]
    res = analyze(lines)
    assert not res.by_category("traversal") and res.by_category("reconnaissance")


def test_traversal_scoring_and_double_encoding_detected_in_scan():
    res = analyze([line("192.0.2.77", 0, path="/d?file=%252e%252e%252fetc%252fpasswd", status=404),
                   line("192.0.2.77", 3, path="/d?file=../../etc/passwd", status=200, size=2346)])
    assert len(res.by_category("traversal")) == 2
    i = res.incidents[0]
    assert (i.level, i.score, i.categories) == ("Medium", 30, ["traversal"])
