"""
Smoke test for app.py with STAND-INS for Streamlit and Plotly (not installable in the
build environment). Every page runs against real analysis of the synthetic logs.
It does not verify the visual layout.
"""
import importlib
import io
import sys
import types

import pytest

from config import SAMPLE_DIR


class _Ctx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return getattr(FakeSt.current, name)


class FakeUpload(io.BytesIO):
    def __init__(self, name, data):
        super().__init__(data)
        self.name = name


class FakeSt(types.ModuleType):
    current = None

    def __init__(self):
        super().__init__("streamlit")
        self.session_state, self.calls, self.clicks, self.inputs = {}, [], set(), {}
        self.sidebar = _Ctx()
        self.upload = None
        FakeSt.current = self

    def cache_resource(self, fn=None, **kw):
        return fn if fn else (lambda f: f)

    def columns(self, n, **kw):
        return [_Ctx() for _ in range(n if isinstance(n, int) else len(n))]

    def expander(self, *a, **kw):
        return _Ctx()

    def spinner(self, *a, **kw):
        return _Ctx()

    def form(self, *a, **kw):
        return _Ctx()

    def form_submit_button(self, label, **kw):
        return label in self.clicks

    def progress(self, *a, **kw):
        return _Ctx()

    def number_input(self, label, lo=None, hi=None, value=None, **kw):
        return self.inputs.get(label, value)

    def text_area(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def radio(self, label, options, index=0, **kw):
        return self.inputs.get(label, options[index])

    def selectbox(self, label, options, index=0, format_func=None, **kw):
        options = list(options)
        if format_func and options:
            format_func(options[0])
        return self.inputs.get(label, options[index] if options else None)

    def multiselect(self, label, options, default=None, **kw):
        return self.inputs.get(label, default or [])

    def text_input(self, label, value="", **kw):
        return self.inputs.get(label, value)

    def checkbox(self, label, value=False, **kw):
        return self.inputs.get(label, value)

    def date_input(self, label, value=None, **kw):
        return self.inputs.get(label, value)

    def button(self, label, disabled=False, **kw):
        return label in self.clicks and not disabled

    def file_uploader(self, *a, **kw):
        return self.upload

    def download_button(self, label, data, *a, **kw):
        assert data, label
        self.calls.append(("download", label, data))

    def __getattr__(self, name):
        def record(*a, **kw):
            self.calls.append((name, a[0] if a else None))
        return record


def fake_plotly():
    calls = []

    class Fig:
        def update_layout(self, **kw):
            pass

    def mk(n):
        def f(*a, **kw):
            calls.append(n)
            return Fig()
        return f
    px = types.ModuleType("plotly.express")
    for n in ("bar", "pie", "line", "histogram", "scatter"):
        setattr(px, n, mk(n))
    pl = types.ModuleType("plotly")
    pl.express = px
    return pl, px, calls



@pytest.fixture(params=["plotly", "no-plotly"])
def app(request, monkeypatch, tmp_path):
    fake = FakeSt()
    monkeypatch.setitem(sys.modules, "streamlit", fake)
    calls = []
    if request.param == "plotly":
        pl, px, calls = fake_plotly()
        monkeypatch.setitem(sys.modules, "plotly", pl)
        monkeypatch.setitem(sys.modules, "plotly.express", px)
    else:
        monkeypatch.setitem(sys.modules, "plotly", None)
        monkeypatch.setitem(sys.modules, "plotly.express", None)
    sys.modules.pop("app", None)
    mod = importlib.import_module("app")
    from database.db_manager import DBManager
    holder = {}

    def get_db(path=None):
        if "db" not in holder:
            holder["db"] = DBManager(tmp_path / "i.db")
        return holder["db"]
    monkeypatch.setattr(mod, "get_db", get_db)
    yield mod, fake, request.param, calls, holder
    if "db" in holder:
        holder["db"].close()


def errors(fake):
    return [c for c in fake.calls if c[0] in ("error", "exception")]


def go(mod, fake, page):
    fake.inputs["Navigation"] = page
    mod.main()


def load_sample(mod, fake, name="access.log"):
    fake.inputs["Sample log"] = name
    fake.clicks = {"Analyse sample"}
    go(mod, fake, "Apache Log Upload")
    fake.clicks = set()


def test_twelve_pages_without_log(app):
    mod, fake, *_ = app
    assert len(mod.PAGES) == 12
    for p in mod.PAGES:
        go(mod, fake, p)
    assert not errors(fake), errors(fake)


def test_all_pages_with_sample(app):
    mod, fake, mode, calls, holder = app
    load_sample(mod, fake)
    res = fake.session_state["result"]
    assert res.stats["incidents"] == 12
    for p in mod.PAGES:
        go(mod, fake, p)
    assert not errors(fake), errors(fake)
    assert any(c[0] == "markdown" and "SYNTHETIC LOG" in str(c[1]) for c in fake.calls)
    cards = " ".join(str(c[1]) for c in fake.calls if c[0] == "markdown" and 'class="card"' in str(c[1]))
    for label in ["total log entries", "unique IP addresses", "suspicious IP addresses", "SQL injection indicators",
                  "XSS indicators", "directory traversal indicators", "critical-risk incidents"]:
        assert label in cards
    if mode == "plotly":
        assert {"bar", "pie", "line", "scatter"} <= set(calls)
    assert len(holder["db"].list_incidents()) == 12


def test_detection_pages_tester_and_inspection(app):
    mod, fake, *_ = app
    load_sample(mod, fake)
    fake.inputs.update({"Test a request string (offline)": "/p?id=1' OR '1'='1"})
    fake.calls.clear()
    go(mod, fake, "SQL Injection Detection")
    text = " ".join(str(c[1]) for c in fake.calls if c[0] == "markdown")
    assert "SQLI-01" in text and "Why it was flagged" in text
    for page in ["XSS Detection", "Directory Traversal Detection", "Brute Force Detection", "Reconnaissance Analysis",
                 "Suspicious IP Investigation"]:
        fake.calls.clear()
        go(mod, fake, page)
        assert not errors(fake), (page, errors(fake))
        assert any(c[0] == "dataframe" for c in fake.calls), page


def test_normal_log_shows_no_incidents(app):
    mod, fake, *_ = app
    load_sample(mod, fake, "demo_normal.log")
    assert fake.session_state["result"].stats["incidents"] == 0
    for p in mod.PAGES:
        go(mod, fake, p)
    assert not errors(fake), errors(fake)


def test_upload_valid_and_invalid(app):
    mod, fake, *_ = app
    fake.upload = FakeUpload("server_access.log", (SAMPLE_DIR / "demo_bruteforce.log").read_bytes())
    fake.clicks = {"Analyse uploaded log"}
    go(mod, fake, "Apache Log Upload")
    res = fake.session_state["result"]
    assert res.file_name == "server_access.log" and res.stats["brute_force_ips"] == 2
    fake.upload = FakeUpload("malware.exe", b"MZ....")
    fake.calls.clear()
    go(mod, fake, "Apache Log Upload")
    assert any(c[0] == "error" and "Upload rejected" in str(c[1]) for c in fake.calls)
    fake.upload = FakeUpload("bin.log", b"\x00\x01\x02\x03")
    fake.calls.clear()
    go(mod, fake, "Apache Log Upload")
    assert any(c[0] == "error" for c in fake.calls)
    fake.upload = FakeUpload("notes.txt", b"hello\nworld\n")          # text, but not a log
    fake.calls.clear()
    go(mod, fake, "Apache Log Upload")
    assert fake.session_state["result"].stats["parsed"] == 0
    assert any(c[0] == "error" and "no line matched" in str(c[1]) for c in fake.calls)


def test_config_rescoring_and_validation(app):
    mod, fake, *_ = app
    load_sample(mod, fake)
    fake.inputs["Allowlisted IPs (never reported, e.g. your monitoring host)"] = "10.0.5.20"
    fake.clicks = {"Apply"}
    go(mod, fake, "Detection Configuration")
    go(mod, fake, "Security Overview")
    assert fake.session_state["result"].stats["incidents"] == 11
    fake.inputs["Maximum failed attempts"] = 30          # > high threshold 20 -> rejected
    fake.calls.clear()
    go(mod, fake, "Detection Configuration")
    assert any(c[0] == "error" and "thresholds must satisfy" in str(c[1]) for c in fake.calls)


def test_incident_filters_status_and_persistence(app):
    mod, fake, _, _, holder = app
    load_sample(mod, fake)
    fake.inputs["Attack type"] = "xss"
    fake.calls.clear()
    go(mod, fake, "Incident Management")
    table = next(c for c in fake.calls if c[0] == "dataframe")
    iid = holder["db"].list_incidents(category="xss")[0]["incident_id"]
    fake.inputs.update({"Open incident": iid, "Set status": "Investigating", "Analyst note": "Demo 8"})
    fake.clicks = {"Save status and note"}
    go(mod, fake, "Incident Management")
    assert table is not None
    holder["db"].close()
    holder.clear()
    fake.session_state.clear()
    fake.clicks, fake.inputs = set(), {}
    load_sample(mod, fake)
    inc = holder["db"].get_incident(iid)
    assert inc["status"] == "Investigating" and inc["analyst_notes"] == "Demo 8"


def test_reports_downloads(app):
    mod, fake, *_ = app
    load_sample(mod, fake)
    fake.clicks = {"Build PDF report"}
    go(mod, fake, "Reports and Downloads")
    labels = {c[1] for c in fake.calls if c[0] == "download"}
    assert {"Analyzed log data (CSV)", "Suspicious requests (CSV)", "Suspicious IPs (CSV)", "Incidents (CSV)",
            "Download PDF security investigation report"} <= labels
