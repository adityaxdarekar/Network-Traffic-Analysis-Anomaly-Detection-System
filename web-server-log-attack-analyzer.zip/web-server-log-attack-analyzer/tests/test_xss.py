"""XSS rules on decoded and entity-decoded request targets."""
import pytest

from analyzer import xss_detector as xss
from conftest import analyze, line


def ids(target):
    return {r.rule_id for r, _ in xss.detect(target)}


@pytest.mark.parametrize("target, rule", [
    ("/s?q=<script>alert(1)</script>", "XSS-01"),
    ("/s?q=%3CScRiPt%3Ealert(1)%3C/script%3E", "XSS-01"),
    ("/s?q=<img src=x onerror=alert(1)>", "XSS-02"),
    ('/s?q=" onmouseover="alert(1)', "XSS-02"),
    ("/r?u=javascript:alert(1)", "XSS-03"),
    ("/r?u=JaVaScRiPt%3Aalert(1)", "XSS-03"),
    ("/r?u=data:text/html;base64,PHNjcmlwdD4=", "XSS-03"),
    ("/s?q=<iframe src=//evil.example>", "XSS-04"),
    ("/s?q=<svg/onload=alert(1)>", "XSS-04"),
    ("/s?q=document.cookie", "XSS-05"),
    ("/s?q=eval(atob('YWxlcnQoMSk='))", "XSS-05"),
    ("/s?q=%253Cscript%253E", "XSS-06"),
    ("/s?q=&lt;script&gt;alert(1)&lt;/script&gt;", "XSS-06"),
    ("/s?q=&#60;img src=x onerror=alert(1)&#62;", "XSS-02"),
])
def test_positive_rules(target, rule):
    assert rule in ids(target), (target, ids(target))


@pytest.mark.parametrize("target", [
    "/s?q=one+online+store", "/s?q=a<b", "/s?q=connection=on", "/s?q=java+script+tutorial",
    "/s?q=price%3C100", "/blog/how-scripts-work", "/s?q=onerror", "/s?q=document+cookie+policy",
])
def test_benign_not_flagged(target):
    assert xss.detect(target) == [], ids(target)


def test_encoded_marker_alone_needs_a_tag():
    assert xss.detect("/s?q=price%3C100") == []
    assert "XSS-06" in ids("/s?q=%3Cb%3Ehi")


def test_finding_explains_and_distinguishes_from_vulnerability():
    res = analyze([line("198.51.100.45", 0, path="/search?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E")])
    f = res.by_category("xss")[0]
    assert f.ip == "198.51.100.45" and f.status == 200
    assert "Potential XSS" in f.explanation and "[XSS-01]" in f.explanation
    assert res.incidents[0].level == "Medium"
    assert "not show the site" in xss.__doc__ or "does not show" in xss.__doc__
