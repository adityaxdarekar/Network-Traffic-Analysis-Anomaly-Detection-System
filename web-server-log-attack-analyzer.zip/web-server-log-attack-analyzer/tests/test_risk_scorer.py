"""Risk scoring, duplicate handling, configuration, persistence, filters and reports."""
import pytest

from analyzer.engine import analyze_parsed, run_analysis
from analyzer.risk_scorer import category, incident_id, score_categories
from config import SAMPLE_DIR, DetectionConfig
from database.db_manager import DBManager
from utils.helpers import UploadError, csv_safe, redact, validate_upload
from utils.report_generator import (entries_csv, incidents_csv, pdf_report, suspicious_ips_csv,
                                    suspicious_requests_csv)
from conftest import analyze, line


@pytest.fixture(scope="module")
def sample():
    return run_analysis(SAMPLE_DIR / "access.log")


def test_category_bands():
    assert [category(x) for x in (0, 24, 25, 49, 50, 74, 75, 100)] == \
        ["Low", "Low", "Medium", "Medium", "High", "High", "Critical", "Critical"]


def test_default_weights_from_brief(cfg):
    for cat, pts in [("sql_injection", 25), ("xss", 25), ("traversal", 30), ("brute_force", 20),
                     ("reconnaissance", 15), ("excessive_frequency", 15)]:
        assert score_categories({cat}, "base", cfg)[0] == pts


def test_multi_category_bonus_and_cap(cfg):
    s, c = score_categories({"sql_injection", "xss"}, None, cfg)
    assert s == 60 and c[-1]["component"] == "Multiple attack categories" and c[-1]["points"] == 10
    s, c = score_categories({"sql_injection", "xss", "traversal", "reconnaissance", "excessive_frequency"}, None, cfg)
    assert s == 100 and sum(x["points"] for x in c) == 130                 # bonus capped at 20, total at 100
    assert score_categories({"excessive_frequency", "http_anomaly"}, None, cfg)[0] == 25   # no attack bonus


def test_duplicate_detections_counted_once():
    lines = [line("198.51.100.23", k, path=f"/p?id={k}%27%20OR%20%271%27%3D%271") for k in range(40)]
    res = analyze(lines)
    assert len(res.by_category("sql_injection")) == 40                     # every request is evidence ...
    i = res.incidents[0]
    assert i.score == 25 and i.contributions == [{"component": "Potential SQL injection", "points": 25,
                                                   "reason": "category detected (counted once)"}]   # ... scored once
    assert i.suspicious_requests == 40


def test_custom_weights_and_validation():
    cfg = DetectionConfig(weights={"sql_injection": 60})
    assert cfg.validate() == ["weights must cover every category"]
    cfg = DetectionConfig.from_dict({"weights": {"sql_injection": 60}})
    assert cfg.weights["xss"] == 25 and cfg.validate() == []
    res = analyze([line("198.51.100.23", 0, path="/p?id=1 UNION SELECT 1")], cfg)
    assert (res.incidents[0].score, res.incidents[0].level) == (60, "High")
    with pytest.raises(ValueError, match="invalid configuration"):
        analyze([line()], DetectionConfig(freq_max_requests=1))


def test_incident_id_stable():
    assert incident_id("a" * 64, "192.0.2.1") == incident_id("a" * 64, "192.0.2.1")
    assert incident_id("a" * 64, "192.0.2.1") != incident_id("b" * 64, "192.0.2.1")
    assert incident_id("a" * 64, "192.0.2.1").startswith("WEB-")


def test_sample_levels(sample):
    got = {i.ip: (i.level, i.score) for i in sample.incidents}
    assert got == {"203.0.113.66": ("Critical", 100), "198.51.100.23": ("High", 60), "203.0.113.10": ("High", 50),
                   "198.51.100.77": ("Medium", 30), "192.0.2.77": ("Medium", 30), "198.51.100.45": ("Medium", 25),
                   "203.0.113.99": ("Medium", 25), "198.51.100.200": ("Medium", 25), "10.0.5.20": ("Low", 10),
                   "192.0.2.30": ("Low", 10), "192.0.2.99": ("Low", 10), "192.0.2.98": ("Low", 10)}
    s = sample.stats
    assert (s["sqli_indicators"], s["xss_indicators"], s["traversal_indicators"]) == (20, 15, 17)
    assert (s["unique_ips"], s["suspicious_ips"], s["critical"]) == (25, 12, 1)


def test_allowlist_and_rescoring(sample):
    cfg = DetectionConfig(allowlist_ips=["10.0.5.20"])
    res = analyze_parsed(sample.parsed, cfg)
    assert "10.0.5.20" not in {i.ip for i in res.incidents} and len(res.incidents) == 11


def test_redaction_of_secrets_but_not_payloads():
    assert redact("/login?user=bob&password=hunter2&next=/") == "/login?user=bob&password=[REDACTED]&next=/"
    assert redact("/cb?code=abc123&state=x") == "/cb?code=[REDACTED]&state=x"
    assert redact("/login?password=' OR '1'='1") == "/login?password=' OR '1'='1"     # payload kept as evidence
    res = analyze([line(path="/login?token=s3cr3t")])
    assert "s3cr3t" not in res.df.iloc[0]["path"] and "s3cr3t" not in res.df.iloc[0]["raw"]
    assert "s3cr3t" in res.parsed.entries.iloc[0]["path"]                   # detection used the original
    res = analyze([line(path="/login?token=s3cr3t")], DetectionConfig(redact_secrets=False))
    assert "s3cr3t" in res.df.iloc[0]["path"]


def test_incident_persistence_across_restart(tmp_path, sample):
    p = tmp_path / "i.db"
    db = DBManager(p)
    db.save_analysis(sample)
    iid = sample.incidents[0].incident_id
    assert db.update_status(iid, "Investigating", "checking app logs", "ana")
    db.close()
    db = DBManager(p)                                                       # "restart"
    db.save_analysis(run_analysis(SAMPLE_DIR / "access.log"))              # re-analysis must not reset it
    inc = db.get_incident(iid)
    assert inc["status"] == "Investigating" and inc["analyst_notes"] == "checking app logs"
    assert inc["times_detected"] == 2 and inc["notes"][0]["analyst"] == "ana"
    assert db.merged(sample)[0]["status"] == "Investigating"
    with pytest.raises(ValueError):
        db.update_status(iid, "Closed")
    assert not db.update_status("WEB-NOPE", "Resolved")
    db.close()


def test_filters_and_injection_safe_search(db, sample):
    db.save_analysis(sample)
    assert len(db.list_incidents()) == 12
    assert {r["ip"] for r in db.list_incidents(category="xss")} == {"203.0.113.66", "198.51.100.45"}
    assert {r["ip"] for r in db.list_incidents(levels=["High"])} == {"198.51.100.23", "203.0.113.10"}
    assert [r["ip"] for r in db.list_incidents(ip="203.0.113.1")] == ["203.0.113.10"]
    assert db.list_incidents(ip="' OR 1=1 --") == []
    assert db.status_counts() == {"Open": 12, "Investigating": 0, "Resolved": 0}


def test_reports_built_from_results(db, sample):
    db.save_analysis(sample)
    merged = db.merged(sample)
    pdf = pdf_report(sample, merged)
    assert pdf[:4] == b"%PDF" and len(pdf) > 10_000
    req = suspicious_requests_csv(sample).decode()
    assert req.count("\n") == 53 and "SQLI-02" in req                      # header + 52 suspicious requests
    assert suspicious_ips_csv(sample).decode().count("\n") == 13
    assert incidents_csv(merged).decode().splitlines()[1].startswith("WEB-")
    assert entries_csv(sample).decode().count("\n") == 883
    empty = analyze([line()])
    assert pdf_report(empty)[:4] == b"%PDF" and suspicious_requests_csv(empty).decode().count("\n") == 1


def test_csv_formula_neutralised():
    assert csv_safe("=HYPERLINK(1)") == "'=HYPERLINK(1)" and csv_safe("-") == "-" and csv_safe("-5") == "-5"
    assert csv_safe("@SUM(A1)") == "'@SUM(A1)" and csv_safe("/index.html") == "/index.html"


def test_upload_validation():
    validate_upload("access.log", b"x")
    validate_upload("access.log.1", b"x")
    for name, data, msg in [("a.exe", b"x", "only"), ("a.log", b"", "empty"), ("a.log", b"\x00\x01", "binary"),
                            ("a.txt", b"\x1f\x8b\x08", "gzip")]:
        with pytest.raises(UploadError, match=msg):
            validate_upload(name, data)
