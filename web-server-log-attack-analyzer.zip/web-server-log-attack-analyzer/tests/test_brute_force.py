"""Brute-force detection: sliding time windows, thresholds, intensity tiers, status-code caveats."""
from analyzer import brute_force_detector as bf
from analyzer.findings import sliding_max
from config import DetectionConfig
from conftest import analyze, line


def fails(ip, n, every, start=0, path="/login", status=401, method="POST"):
    return [line(ip, start + k * every, method, path, status) for k in range(n)]


def test_sliding_max_two_pointer():
    assert sliding_max([0, 10, 20, 299, 301, 302], 300) == (5, 10.0, 302.0)   # busiest stretch, not clock minutes
    assert sliding_max([], 60) == (0, 0.0, 0.0)
    assert sliding_max([5, 5, 5], 1)[0] == 3


def test_threshold_boundary_inside_window():
    assert not bf.scan(analyze(fails("203.0.113.1", 9, 10)).parsed.entries)          # 9 < 10
    f = bf.scan(analyze(fails("203.0.113.1", 10, 10)).parsed.entries)
    assert len(f) == 1 and f[0].details["peak_in_window"] == 10 and set(f[0].rule_ids) == {"BF-01", "BF-02"}


def test_same_count_spread_over_time_is_not_flagged():
    assert not bf.scan(analyze(fails("203.0.113.1", 12, 60)).parsed.entries)         # 12 in 11 min, window 5 min
    cfg = DetectionConfig(bf_window_minutes=15)
    assert bf.scan(analyze(fails("203.0.113.1", 12, 60)).parsed.entries, cfg)       # configurable window


def test_window_spanning_minute_boundary():
    lines = fails("203.0.113.2", 10, 20, start=170)     # 02:50 .. 05:50 crosses clock minutes / 5-min marks
    assert bf.scan(analyze(lines).parsed.entries)


def test_intensity_tiers_and_scores(cfg):
    for n, tier_name, score in [(10, "base", 20), (20, "high", 30), (50, "critical", 40)]:
        res = analyze(fails("203.0.113.3", n, 2))
        f = res.by_category("brute_force")[0]
        assert f.details["intensity"] == tier_name
        assert res.incidents[0].score == score, (n, res.incidents[0].explanation)


def test_custom_thresholds():
    cfg = DetectionConfig(bf_max_failed=3, bf_high_threshold=4, bf_critical_threshold=5)
    res = analyze(fails("203.0.113.4", 5, 5), cfg)
    assert res.by_category("brute_force")[0].details["intensity"] == "critical"
    assert DetectionConfig(bf_max_failed=30, bf_high_threshold=20).validate()        # inconsistent -> error


def test_status_code_semantics():
    # 403 on non-login pages is NOT a login failure (it is often a forbidden directory)
    assert not bf.scan(analyze(fails("203.0.113.5", 15, 3, path="/private/", method="GET", status=403)).parsed.entries)
    # 401 anywhere means HTTP authentication failed / was required
    assert bf.scan(analyze(fails("203.0.113.5", 15, 3, path="/admin/area", method="GET", status=401)).parsed.entries)
    # failed logins answered with 200 (many apps do this): caught as repeated login attempts (BF-02)
    f = bf.scan(analyze(fails("203.0.113.6", 12, 3, path="/wp-login.php", status=200)).parsed.entries)
    assert f and f[0].rule_ids == ["BF-02"]
    assert "Status codes alone do not prove" in f[0].explanation


def test_success_after_failures_is_highlighted():
    lines = fails("203.0.113.7", 12, 3) + [line("203.0.113.7", 40, "POST", "/login", 302)]
    f = bf.scan(analyze(lines).parsed.entries)[0]
    assert "BF-03" in f.rule_ids and f.details["success_after_failures"] == 1
    assert "possible successful guess" in f.explanation


def test_normal_user_typo_not_flagged(normal_lines):
    lines = normal_lines + [line("192.0.2.15", 5, "POST", "/login", 401), line("192.0.2.15", 20, "POST", "/login", 302)]
    assert analyze(lines).incidents == []


def test_auth_paths_configurable():
    lines = fails("203.0.113.8", 12, 2, path="/portal/signon", status=403)
    assert not bf.scan(analyze(lines).parsed.entries)
    cfg = DetectionConfig(auth_paths=["/portal/signon"])
    assert bf.scan(analyze(lines).parsed.entries, cfg)


def test_auth_regex_matches_prefixes_only():
    rx = bf.auth_regex(["/login", "/wp-login.php"])
    assert rx.match("/login") and rx.match("/login?next=/") and rx.match("/wp-login.php") and rx.match("/login/")
    assert not rx.match("/blog/login-tips") and not rx.match("/loginx")
