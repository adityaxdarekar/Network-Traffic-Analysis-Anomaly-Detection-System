"""analyze_log.py and run_demos.py end to end."""
import analyze_log
import run_demos
from config import SAMPLE_DIR

LOG = str(SAMPLE_DIR / "access.log")


def test_analyse_save_pdf_csv(tmp_path, capsys):
    db = tmp_path / "c.db"
    rc = analyze_log.main([LOG, "--save", "--db", str(db), "--pdf", str(tmp_path / "r.pdf"), "--csv",
                           str(tmp_path / "csv"), "--show", "all"])
    out = capsys.readouterr().out
    assert rc == 0 and "SYNTHETIC LOG" in out and "parsed 882 (99.4%)" in out
    assert "Incidents (suspicious IPs): 12 (critical 1, high 2, medium 5, low 4)" in out
    assert "Suspicious requests (52)" in out and "capped at 100" in out
    assert (tmp_path / "r.pdf").read_bytes()[:4] == b"%PDF"
    assert sorted(p.name for p in (tmp_path / "csv").iterdir()) == [
        "access_entries.csv", "access_incidents.csv", "access_suspicious_ips.csv", "access_suspicious_requests.csv"]


def test_incidents_and_status_update(tmp_path, capsys):
    db = str(tmp_path / "c.db")
    analyze_log.main([LOG, "--save", "--db", db, "--show", "summary"])
    capsys.readouterr()
    analyze_log.main(["--incidents", "--db", db])
    out = capsys.readouterr().out
    iid = next(line.split()[0] for line in out.splitlines() if line.startswith("WEB-") and "Critical" in line)
    assert analyze_log.main(["--set-status", iid, "investigating", "--note", "cli test", "--db", db]) == 0
    analyze_log.main(["--incidents", "--db", db])
    assert "Investigating" in capsys.readouterr().out
    assert analyze_log.main(["--set-status", iid, "closed", "--db", db]) == 2
    assert analyze_log.main(["--set-status", "WEB-NOTHERE", "Resolved", "--db", db]) == 1


def test_thresholds_allowlist_and_errors(tmp_path, capsys):
    analyze_log.main([str(SAMPLE_DIR / "demo_bruteforce.log"), "--max-failed", "30", "--high", "40",
                      "--critical", "60", "--show", "summary"])
    out = capsys.readouterr().out
    assert "Incidents (suspicious IPs): 1" in out and "203.0.113.10" in out
    analyze_log.main([LOG, "--allow-ip", "10.0.5.20", "--show", "summary"])
    assert "Incidents (suspicious IPs): 11" in capsys.readouterr().out
    assert analyze_log.main([str(tmp_path / "missing.log")]) == 2
    bad = tmp_path / "bin.log"
    bad.write_bytes(b"\x00\x01")
    assert analyze_log.main([str(bad)]) == 2
    try:
        analyze_log.main([LOG, "--max-failed", "30"])          # 30 > high threshold 20
    except SystemExit as exc:
        assert "invalid settings" in str(exc)
    else:
        raise AssertionError("expected SystemExit")


def test_run_demos_all_pass(tmp_path, capsys):
    assert run_demos.main(["--db", str(tmp_path / "d.db"), "--out", str(tmp_path / "out")]) == 0
    out = capsys.readouterr().out
    assert out.count(": PASS") == 9 and "FAIL" not in out
    assert (tmp_path / "out" / "security_investigation_report.pdf").exists()
