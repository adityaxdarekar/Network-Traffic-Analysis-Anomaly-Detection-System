"""Apache Common / Combined / CSV parsing, malformed handling and timestamp normalisation."""
import pytest

from analyzer.log_parser import (LineError, LogFormatError, parse_apache_time, parse_bytes, parse_csv_text,
                                 parse_file, parse_line, split_request)
from config import SAMPLE_DIR
from conftest import line, parse

COMBINED = ('203.0.113.10 - frank [02/Nov/2026:10:00:01 +0000] "POST /login?next=%2Faccount HTTP/1.1" 401 381 '
            '"https://shop.example.com/login" "python-requests/2.31.0"')
COMMON = '192.0.2.5 - - [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326'


def test_combined_format_fields():
    e = parse_line(COMBINED, 7)
    assert (e["ip"], e["user"], e["method"], e["path"], e["protocol"]) == \
        ("203.0.113.10", "frank", "POST", "/login?next=%2Faccount", "HTTP/1.1")
    assert (e["status"], e["size"], e["line_no"], e["log_format"]) == (401, 381, 7, "combined")
    assert e["referrer"] == "https://shop.example.com/login" and e["user_agent"] == "python-requests/2.31.0"
    assert e["timestamp"].isoformat() == "2026-11-02T10:00:01+00:00"
    assert e["raw"] == COMBINED


def test_common_log_format_and_timezone_normalised_to_utc():
    e = parse_line(COMMON)
    assert e["log_format"] == "common" and e["referrer"] == "" and e["user_agent"] == ""
    assert e["timestamp"].isoformat() == "2000-10-10T20:55:36+00:00"      # 13:55 at -0700 = 20:55 UTC
    assert e["path"] == "/apache_pb.gif" and e["size"] == 2326


def test_escaped_quotes_in_user_agent_and_request():
    raw = r'192.0.2.9 - - [02/Nov/2026:10:00:00 +0000] "GET /s?q=\"x\" HTTP/1.1" 200 10 "-" "Mozilla \"quoted\" agent"'
    e = parse_line(raw)
    assert e["path"] == '/s?q="x"' and e["user_agent"] == 'Mozilla "quoted" agent'


def test_dash_size_408_invalid_request_http09_ipv6():
    assert parse_line('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 304 -')["size"] == 0
    e = parse_line('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "-" 408 -')
    assert (e["method"], e["path"], e["status"]) == ("-", "", 408)
    e = parse_line(r'192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "\x16\x03\x01\x02" 400 226 "-" "-"')
    assert e["method"] == "INVALID" and e["user_agent"] == ""
    assert split_request("GET /index.html") == ("GET", "/index.html", "")
    assert parse_line('2001:db8::1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/2.0" 200 5')["ip"] == "2001:db8::1"


@pytest.mark.parametrize("bad, reason", [
    ("not an apache line", "does not match"),
    ('192.0.2.1 - - [32/Foo/2026:10:00:00 +0000] "GET / HTTP/1.1" 200 1', "month"),
    ('192.0.2.1 - - [31/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 200 1', "invalid timestamp"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00] "GET / HTTP/1.1" 200 1', "invalid timestamp"),
    ('999.1.1.1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 200 1', "invalid IP"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" abc 1', "status"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 999 1', "out of range"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 200 12x', "size"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] "GET /products/10', "missing or unterminated"),
    ('192.0.2.1 - - [02/Nov/2026:10:00:00 +0000] 200 1', "request line missing"),
])
def test_malformed_lines_raise_with_reason(bad, reason):
    with pytest.raises(LineError, match=reason):
        parse_line(bad)


def test_malformed_lines_do_not_stop_parsing_and_are_kept():
    lines = ["# SYNTHETIC test", "", line(sec=1), "garbage line", line(sec=2), "x" * 20000, line(sec=3)]
    r = parse(lines)
    s = r.stats()
    assert (s["parsed"], s["malformed"], s["blank"], s["comments"], s["log_entries"]) == (3, 2, 1, 1, 5)
    assert s["parse_rate"] == 60.0 and r.synthetic
    assert [m[0] for m in r.malformed] == [4, 6] and "longer than" in r.malformed[1][1]
    assert r.malformed[0][2] == "garbage line"           # original text available for troubleshooting


def test_control_characters_are_sanitised():
    r = parse([line(path="/a\x1b[31mred")])
    assert "\x1b" not in r.entries.iloc[0]["raw"] and r.entries.iloc[0]["path"].startswith("/a?[31m")


def test_entries_sorted_by_time_and_epoch_column():
    r = parse([line(sec=50), line(sec=10), line(sec=30)])
    assert r.entries["ts"].is_monotonic_increasing
    assert list(r.entries["line_no"]) == [2, 3, 1]


def test_apache_time_parser():
    assert parse_apache_time("02/Nov/2026:09:00:00 +0530").isoformat() == "2026-11-02T03:30:00+00:00"
    with pytest.raises(LineError):
        parse_apache_time("2026-11-02 09:00:00")


def test_csv_logs_with_aliases_iso_and_apache_times():
    text = ("Time,Client_IP,Verb,URL,Status_Code,Bytes,Referer,User_Agent\n"
            "2026-11-02T09:00:00Z,192.0.2.1,get,/,200,512,-,Mozilla\n"
            "02/Nov/2026:10:00:00 -0100,192.0.2.2,POST,/login,401,-,,curl/8\n"
            "not-a-time,192.0.2.3,GET,/,200,1,-,x\n"
            "2026-11-02T09:00:00Z,192.0.2.4,GET,/,2000,1,-,x\n"
            ",,,,,,,\n")
    r = parse_csv_text(text, "a.csv")
    assert r.parsed == 2 and len(r.malformed) == 2 and r.formats == {"csv": 2}
    e = r.entries.set_index("ip")
    assert e.loc["192.0.2.1", "method"] == "GET" and e.loc["192.0.2.2", "timestamp"].hour == 11
    assert e.loc["192.0.2.2", "size"] == 0 and e.loc["192.0.2.1", "user_agent"] == "Mozilla"


def test_csv_missing_columns_rejected():
    with pytest.raises(LogFormatError, match="missing required column"):
        parse_csv_text("ip,path\n1.2.3.4,/\n")


def test_parse_bytes_detects_csv_and_rejects_binary_and_empty():
    assert parse_bytes(b"timestamp,ip,method,path,status\n2026-11-02T09:00:00Z,192.0.2.1,GET,/,200\n", "x.txt") \
        .source_format == "csv"
    with pytest.raises(LogFormatError, match="binary"):
        parse_bytes(b"\x00\x01\x02 binary", "x.log")
    with pytest.raises(LogFormatError, match="empty"):
        parse_bytes(b"", "x.log")
    assert len(parse_bytes(b"\xff\xfe garbage\n", "x.log").malformed) == 1      # invalid UTF-8 -> replaced, kept


def test_sample_logs_parse_and_are_labelled_synthetic():
    r = parse_file(SAMPLE_DIR / "access.log")
    s = r.stats()
    assert s["parsed"] == 882 and s["malformed"] == 5 and s["parsed"] >= 200 and r.synthetic
    assert {"GET", "POST", "OPTIONS", "TRACE", "PUT", "PROPFIND", "INVALID", "-"} <= set(r.entries["method"])
    clf = parse_file(SAMPLE_DIR / "demo_common_format.log")
    assert clf.formats == {"common": clf.parsed} and clf.synthetic
    csvr = parse_file(SAMPLE_DIR / "access_sample.csv")
    assert csvr.source_format == "csv" and csvr.synthetic and not csvr.malformed


def test_missing_file():
    with pytest.raises(LogFormatError, match="not found"):
        parse_file(SAMPLE_DIR / "does_not_exist.log")
