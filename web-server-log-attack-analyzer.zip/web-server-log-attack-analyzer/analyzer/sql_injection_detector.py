"""
sql_injection_detector.py - rule-based indicators of SQL injection in request targets.

Every request target (path + query string) is decoded first (see normalizer:
repeated percent-decoding, '+' -> space, /**/ comments -> space) and matched
case-insensitively. To avoid flagging every page that merely contains a SQL
word ("/blog/how-to-select-a-lamp", "?q=union station"), no rule fires on a
keyword alone: each rule needs a keyword in a SQL-specific CONTEXT - after a
quote, together with an operator, a comment terminator, a function call or a
statement separator.

  SQLI-01 tautology                  ' OR '1'='1   " or "a"="a   OR 1=1
  SQLI-02 UNION SELECT               UNION [ALL] SELECT
  SQLI-03 destructive / stacked      '; DROP TABLE x   ; DELETE FROM   ; EXEC
  SQLI-04 comment terminator         quote/paren followed by -- # /*, UN/**/ION
  SQLI-05 time-based blind           SLEEP(5)  BENCHMARK(  WAITFOR DELAY  PG_SLEEP(
  SQLI-06 schema / system access     information_schema  @@version  LOAD_FILE(  INTO OUTFILE  xp_cmdshell
  SQLI-07 quote + SQL keyword        ' AND ...  ') OR ...  ' ORDER BY 3--
  SQLI-08 encoded metacharacters     %27 %22 %23 %2d%2d %3b (or double-encoded %25..) in a
                                     request whose decoded form is in SQL context; CHAR(..), 0x..

A match is a POTENTIAL injection attempt. Whether it worked can only be
judged from the application (errors, response sizes, database logs).
Nothing is ever executed or sent anywhere.
"""
from __future__ import annotations

from analyzer.findings import Rule, rx, scan_requests
from analyzer.normalizer import view

RULES = [
    Rule("SQLI-01", "Tautology (always-true condition)",
         rx(r"""['"`]\s*\)?\s*(or|and|\|\||&&)\s+['"`(]?\s*[\w]+\s*['"`)]?\s*(=|<>|!=|like)\s*['"`(]?\s*[\w]+"""
            r"""|\b(or|and)\s+(\d+)\s*=\s*\4\b|['"`]\s*(or|and)\s+(true|false)\b"""),
         "sql", "an always-true condition such as ' OR '1'='1 is used to bypass WHERE clauses (e.g. logins)."),
    Rule("SQLI-02", "UNION SELECT", rx(r"\bunion\b(\s+(all|distinct))?\s+select\b"),
         "sql", "UNION SELECT appends the attacker's own query to read other tables."),
    Rule("SQLI-03", "Destructive or stacked statement",
         rx(r"""(;|['"`])\s*(drop|truncate|alter)\s+(table|database|schema)\b"""
            r"""|;\s*(delete\s+from|insert\s+into|update\s+\w+\s+set|exec(ute)?\s|shutdown\b|declare\s+@)"""),
         "sql", "a statement separator or quote followed by DROP/DELETE/INSERT/EXEC tries to run a second statement."),
    Rule("SQLI-04", "SQL comment terminator",
         rx(r"""['"`)]\s*(--|#|/\*)|\b(union|select|and|or|from|where|order)\s*/\*.*?\*/"""),
         "decoded", "a quote followed by -- # or /* comments out the rest of the original query; /**/ hides spaces."),
    Rule("SQLI-05", "Time-based blind injection",
         rx(r"\b(sleep|pg_sleep)\s*\(\s*\d+|\bbenchmark\s*\(\s*\d+|\bwaitfor\s+delay\b|\bdbms_lock\.sleep\b"),
         "sql", "delay functions are used to infer data from response times when no output is visible."),
    Rule("SQLI-06", "Schema or system object access",
         rx(r"\binformation_schema\b|@@version\b|\bversion\s*\(\s*\)|\bload_file\s*\(|\binto\s+(out|dump)file\b"
            r"|\bxp_cmdshell\b|\bsysobjects\b|\bpg_catalog\b|\bsqlite_master\b|\bmysql\.user\b"),
         "sql", "metadata tables, version variables and file functions are used to map or escape the database."),
    Rule("SQLI-07", "Quote followed by SQL keyword",
         rx(r"""['"`]\s*\)*\s*(and|or|union|select|having|waitfor|order\s+by|group\s+by)\b"""
            r"""|\border\s+by\s+\d+\s*(--|#)"""),
         "sql", "closing a string literal and continuing with SQL syntax is the core of most injections."),
]
_ENCODED = rx(r"%27|%22|%60|%23|%2d%2d|%3b|%25(27|22|23|2d|3b)|%bf%27|%5c%27")
_KEYWORD = rx(r"\b(select|union|insert|update|delete|drop|or|and|sleep|exec|order\s+by)\b")
_OBFUSC = rx(r"\bchar\s*\(\s*\d+\s*(,\s*\d+\s*)+\)|\bconcat\s*\(|\b0x[0-9a-f]{6,}\b")
SQLI_08 = Rule("SQLI-08", "Encoded SQL metacharacters / obfuscation", _ENCODED, "raw",
               "quotes, comment markers or separators were URL-encoded (or double-encoded) to slip past filters, "
               "and the decoded request is in SQL context.")
ALL_RULES = RULES + [SQLI_08]


def detect(target: str) -> list[tuple[Rule, str]]:
    """Return [(rule, evidence)] for one request target (empty list = no indicator)."""
    v = view(target)
    hits = [(r, s) for r in RULES if (s := r.match(v))]
    enc = SQLI_08.match(v)
    obf = _OBFUSC.search(v.sql)
    if (enc and (hits or _KEYWORD.search(v.sql))) or (obf and hits):
        hits.append((SQLI_08, enc or v.sql[max(0, obf.start() - 10):obf.end() + 20]))
    return hits


def scan(df, cfg=None):
    return scan_requests(df, detect, "sql_injection", "SQL injection")
