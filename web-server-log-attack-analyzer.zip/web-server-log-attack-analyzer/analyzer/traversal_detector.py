"""
traversal_detector.py - indicators of directory (path) traversal and local file inclusion.

Only the request STRINGS in the log are analysed. No file on this or any
other system is opened or requested.

  TRV-01 dot-dot-slash               ../  ..\\  ....//  (after decoding)
  TRV-02 URL-encoded traversal       %2e%2e%2f  ..%2f  %2e%2e/  ..%5c
  TRV-03 double / overlong encoding  %252e%252e%252f  %c0%ae  %c0%af  %u002e  %uff0e
  TRV-04 sensitive system path       /etc/passwd  /etc/shadow  /proc/self/environ  boot.ini  win.ini  c:\\windows
  TRV-05 config/credential file      ?file=.env  ?page=wp-config.php  ?download=../.git/config ...
         requested through a file-like parameter
  TRV-06 null byte                   %00 used to cut off an appended extension (only with another TRV rule)

A direct request for "/.env" (no traversal, no file parameter) is treated
as reconnaissance (probing for an exposed file), not as traversal.
"""
from __future__ import annotations

from analyzer.findings import Rule, rx, scan_requests
from analyzer.normalizer import view

SENSITIVE_FILES = (r"\.env\b|wp-config\.php|\.htpasswd|\.htaccess|\.git/(config|head)|id_rsa|"
                   r"config\.(php|inc|ini|json|ya?ml)|web\.config|\.aws/credentials|settings\.py|database\.ya?ml|"
                   r"\.bash_history|\.ssh/")
FILE_PARAMS = (r"file|filename|path|filepath|page|doc|document|folder|dir|include|inc|template|tpl|load|read|"
               r"download|view|img|image|lang|module|style|show|cat|content")
RULES = [
    Rule("TRV-01", "Dot-dot-slash sequence", rx(r"\.\.[/\\]|[/\\]\.\.($|[?#&;])"), "decoded",
         "../ moves up one directory; chains of them try to escape the web root."),
    Rule("TRV-02", "URL-encoded traversal", rx(r"(%2e%2e|\.%2e|%2e\.)(%2f|%5c|/|\\)|\.\.(%2f|%5c)"), "raw",
         "the dots or slashes of ../ were percent-encoded to bypass simple filters."),
    Rule("TRV-03", "Double or overlong encoding",
         rx(r"%252e|(\.\.|%2e%2e)%25(2f|5c)|%c0%ae|%c0%af|%c1%9c|%c1%1c|%c0%2f|%e0%80%ae|%u002e|%u2215|%u2216|%uff0e"), "raw",
         "double-encoded dots (%252e) or invalid overlong UTF-8 (%c0%ae) characters target decoders that decode twice."),
    Rule("TRV-04", "Sensitive system path",
         rx(r"/etc/(passwd|shadow|group|hosts|issue|sudoers|crontab)\b|/proc/self/(environ|cmdline|fd)"
            r"|\bboot\.ini\b|\bwin\.ini\b|windows[/\\]+(system32|win\.ini)|\bc:[/\\]|/var/log/(apache2|httpd|auth)"
            r"|/root/\.|/home/[^/]+/\.ssh"), "decoded",
         "operating-system files (password databases, process environment, boot configuration) are requested."),
    Rule("TRV-05", "Config or credential file via file parameter",
         rx(rf"[?&;]({FILE_PARAMS})=[^&]*({SENSITIVE_FILES})"), "decoded",
         "a file-loading parameter points at a configuration or credential file (.env, wp-config.php, .git ...)."),
]
_NULL = rx(r"%00|%2500|\\x00|\\0")
TRV_06 = Rule("TRV-06", "Null byte injection", _NULL, "raw",
              "a NUL byte (%00) tries to truncate an extension the application appends (e.g. .php).")
ALL_RULES = RULES + [TRV_06]


def detect(target: str) -> list[tuple[Rule, str]]:
    v = view(target)
    hits = [(r, s) for r in RULES if (s := r.match(v))]
    if hits and (n := TRV_06.match(v)):
        hits.append((TRV_06, n))
    return hits


def scan(df, cfg=None):
    return scan_requests(df, detect, "traversal", "directory traversal")
