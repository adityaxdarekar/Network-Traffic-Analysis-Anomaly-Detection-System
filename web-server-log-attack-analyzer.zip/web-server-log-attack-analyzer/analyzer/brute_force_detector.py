"""
brute_force_detector.py - repeated authentication failures and login abuse per source IP.

Events counted per IP
  failure  = a response whose status is in cfg.bf_failure_statuses (401, 403)
             AND (the path is an authentication endpoint OR the status is 401,
             which means "HTTP authentication required/failed" on any path)
  attempt  = a POST to an authentication endpoint (whatever the status)

Rules (window = cfg.bf_window_minutes, a SLIDING window, not clock minutes)
  BF-01 Repeated authentication failures : >= cfg.bf_max_failed failures in the window
  BF-02 Repeated login attempts          : >= cfg.bf_max_failed login POSTs in the window
                                           (catches applications that answer failed logins with 200)
  BF-03 Success after failures           : a login POST answered 200/30x after BF-01 fired
                                           -> possible compromised account, check it first

Intensity: the peak count in the window is compared with
cfg.bf_high_threshold (default 20) and cfg.bf_critical_threshold (default 50);
the risk scorer adds bonus points for these tiers.

IMPORTANT: HTTP status codes alone cannot confirm a failed login. 401 means
the server wants (valid) credentials, 403 means access is refused (also for
reasons unrelated to logins), and many web applications return 200 with a
"wrong password" page. Confirm with application/authentication logs.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from analyzer.findings import Finding, sliding_max
from config import DetectionConfig


def auth_regex(paths) -> re.Pattern:
    alts = "|".join(re.escape(p.rstrip("/").lower()) for p in paths if p.strip())
    return re.compile(rf"^({alts})(/|\?|$|\.)", re.I) if alts else re.compile(r"(?!x)x")


def mark_auth(df: pd.DataFrame, cfg: DetectionConfig) -> pd.Series:
    rx = auth_regex(cfg.auth_paths)
    return df["path"].map(lambda p: bool(rx.match(p or "")))


def tier(peak: int, cfg: DetectionConfig) -> str:
    if peak >= cfg.bf_critical_threshold:
        return "critical"
    if peak >= cfg.bf_high_threshold:
        return "high"
    return "base"


def scan(df: pd.DataFrame, cfg: DetectionConfig | None = None) -> list[Finding]:
    cfg = cfg or DetectionConfig()
    if df is None or df.empty:
        return []
    window = cfg.bf_window_minutes * 60
    is_auth = mark_auth(df, cfg)
    fail_status = df["status"].isin(cfg.bf_failure_statuses)
    failure = fail_status & (is_auth | (df["status"] == 401))
    attempt = is_auth & (df["method"] == "POST")
    d = df.assign(_auth=is_auth, _fail=failure, _attempt=attempt)
    out = []
    for ip, g in d[d["_fail"] | d["_attempt"]].groupby("ip", sort=False):
        f_ts, a_ts = g.loc[g["_fail"], "ts"].to_numpy(), g.loc[g["_attempt"], "ts"].to_numpy()
        f_peak, f_s, f_e = sliding_max(f_ts, window)
        a_peak, a_s, a_e = sliding_max(a_ts, window)
        ids, names = [], []
        if f_peak >= cfg.bf_max_failed:
            ids.append("BF-01")
            names.append("Repeated authentication failures")
        if a_peak >= cfg.bf_max_failed:
            ids.append("BF-02")
            names.append("Repeated login attempts")
        if not ids:
            continue
        peak = max(f_peak, a_peak)
        ws, we = (f_s, f_e) if f_peak >= a_peak else (a_s, a_e)
        # BF-03 needs real failures first: when an application answers every login with 200 we cannot tell
        later_ok = g.iloc[0:0]
        if f_peak >= cfg.bf_max_failed:
            later_ok = g[g["_attempt"] & g["status"].between(200, 399) & (g["ts"] >= f_s)]
        if not later_ok.empty:
            ids.append("BF-03")
            names.append("Successful login response after failures")
        endpoints = g.loc[g["_auth"], "path"].map(lambda p: p.split("?")[0]).value_counts().head(5)
        statuses = g["status"].value_counts().to_dict()
        t = tier(peak, cfg)
        expl = (f"{peak} failure/login events within {cfg.bf_window_minutes:g} min "
                f"(threshold {cfg.bf_max_failed}; high {cfg.bf_high_threshold}, critical "
                f"{cfg.bf_critical_threshold} -> intensity '{t}'). {len(g)} events in total: "
                f"{int(g['_fail'].sum())} 401/403 responses, {int(g['_attempt'].sum())} login POSTs.")
        if "BF-03" in ids:
            expl += (f" A login request was answered with {int(later_ok['status'].iloc[0])} after the failures "
                     f"- possible successful guess; verify this account first.")
        expl += " Status codes alone do not prove failed logins - confirm in the application's authentication log."
        evidence = [f"{pd.to_datetime(r.ts, unit='s', utc=True):%H:%M:%S} {r.method} {r.path} -> {r.status}"
                    for r in g.head(5).itertuples()]
        if not later_ok.empty:
            r = later_ok.iloc[0]
            evidence.append(f"{pd.to_datetime(r.ts, unit='s', utc=True):%H:%M:%S} {r.method} {r.path} -> {r.status} "
                            f"(after failures)")
        out.append(Finding(
            category="brute_force", ip=ip, ts=float(g["ts"].min()), last_ts=float(g["ts"].max()), rule_ids=ids,
            rule_names=names, explanation=expl, evidence=evidence, line_nos=g["line_no"].tolist()[:2000],
            kind="aggregate", count=int(len(g)),
            details={"peak_in_window": int(peak), "window_start": ws, "window_end": we, "failures": int(g["_fail"].sum()),
                     "login_posts": int(g["_attempt"].sum()), "intensity": t,
                     "endpoints": {str(k): int(v) for k, v in endpoints.items()},
                     "status_counts": {int(k): int(v) for k, v in statuses.items()},
                     "success_after_failures": int(len(later_ok)),
                     "per_minute": _per_minute(g["ts"].to_numpy())}))
    return out


def _per_minute(ts: np.ndarray) -> dict:
    m = pd.Series(1, index=pd.to_datetime(ts, unit="s", utc=True)).resample("1min").sum()
    return {k.strftime("%H:%M"): int(v) for k, v in m.items()}
