"""
risk_scorer.py - transparent heuristic risk score per source IP (one incident per suspicious IP).

Score = sum of the weights of the DISTINCT categories found for the IP
      + brute-force intensity bonus (peak >= high threshold: +10, >= critical threshold: +20)
      + multi-category bonus (+10 per attack category beyond the first, at most +20)
      capped at 100.

Default weights: SQL injection 25 · XSS 25 · directory traversal 30 ·
repeated authentication failures 20 · reconnaissance 15 · excessive request
frequency 15 · other HTTP anomalies 10.

Duplicate handling: 40 SQL injection requests from one IP add 25 points ONCE.
Every request still appears as evidence. Attack categories for the
multi-category bonus are SQL injection, XSS, traversal, brute force and
reconnaissance.

Bands: 0-24 Low · 25-49 Medium · 50-74 High · 75-100 Critical.

This is a triage priority, not a probability and not a confirmed attack.
"""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field

import pandas as pd

from config import ATTACK_CATEGORIES, CATEGORY_NAMES, DetectionConfig

DISCLAIMER = ("Heuristic indicators only: every finding is a POTENTIAL attack that needs analyst validation. "
              "An access log shows what was requested and how the server answered - not whether an attack "
              "succeeded. No IP address was blocked or contacted.")

RECOMMENDATIONS = {
    "sql_injection": ["Use parameterized queries / prepared statements everywhere.",
                      "Validate input against allow-lists (type, length, format).",
                      "Give the application's database account least-privilege permissions.",
                      "Review application error handling so SQL errors are never shown to users.",
                      "Check database and application logs around the flagged times for errors or data access."],
    "xss": ["Apply context-aware output encoding (HTML, attribute, JavaScript, URL).",
            "Sanitize untrusted HTML with a maintained library before storing or displaying it.",
            "Implement an appropriate Content Security Policy (CSP) and HttpOnly cookies.",
            "Check whether the flagged parameters are reflected or stored by the application."],
    "traversal": ["Normalize (canonicalize) and validate file paths before use; reject '..' and encoded forms.",
                  "Restrict file access to approved directories (allow-list of file names or IDs).",
                  "Run the web server with least-privilege file-system permissions.",
                  "Check responses: a 200 with an unusual size for these requests needs urgent review."],
    "brute_force": ["Implement rate limiting on authentication endpoints.",
                    "Apply account lockout or progressive delays carefully (avoid denial of service to users).",
                    "Use multi-factor authentication.",
                    "Monitor authentication activity; review any successful login from the same IP first."],
    "reconnaissance": ["Review the suspicious request patterns and what the server returned.",
                       "Reduce unnecessary information disclosure (server-status, version banners, directory listing).",
                       "Make sure sensitive files (.env, .git, backups) are not inside the web root.",
                       "Monitor repeated requests for sensitive paths; consider a WAF rule after validation."],
    "excessive_frequency": ["Confirm whether the client is legitimate (monitoring, proxy, crawler).",
                            "Apply rate limiting or caching for the affected endpoints.",
                            "Watch for service degradation during the peak."],
    "http_anomaly": ["Disable HTTP methods the application does not need (TRACE, PUT, DELETE ...).",
                     "Investigate the cause of server errors (5xx) - they may reveal input handling bugs.",
                     "Verify large downloads were authorised; check what was served.",
                     "Treat generic tool User-Agents as context, not proof."],
}


def category(score: int) -> str:
    return "Critical" if score >= 75 else "High" if score >= 50 else "Medium" if score >= 25 else "Low"


@dataclass
class Incident:
    incident_id: str
    ip: str
    score: int
    level: str
    categories: list
    rules: list
    contributions: list
    explanation: str
    total_requests: int
    failed_responses: int
    suspicious_requests: int
    unique_paths: int
    first_seen: float
    last_seen: float
    user_agents: list = field(default_factory=list)
    findings: list = field(default_factory=list)          # compact finding dicts (evidence)
    recommendations: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def score_categories(cats: set, bf_intensity: str | None, cfg: DetectionConfig) -> tuple[int, list]:
    contrib = []
    for c in [c for c in CATEGORY_NAMES if c in cats]:
        contrib.append({"component": CATEGORY_NAMES[c], "points": int(cfg.weights.get(c, 0)),
                        "reason": "category detected (counted once)"})
    if "brute_force" in cats and bf_intensity in ("high", "critical"):
        pts = cfg.bf_critical_bonus if bf_intensity == "critical" else cfg.bf_high_bonus
        thr = cfg.bf_critical_threshold if bf_intensity == "critical" else cfg.bf_high_threshold
        contrib.append({"component": "Brute-force intensity", "points": int(pts),
                        "reason": f"peak reached the {bf_intensity} threshold ({thr} in {cfg.bf_window_minutes:g} min)"})
    n_attack = len([c for c in cats if c in ATTACK_CATEGORIES])
    if n_attack >= 2:
        pts = min(cfg.multi_category_bonus_cap, (n_attack - 1) * cfg.multi_category_bonus)
        contrib.append({"component": "Multiple attack categories", "points": int(pts),
                        "reason": f"{n_attack} attack categories from one IP"})
    raw = sum(c["points"] for c in contrib)
    return min(100, raw), contrib


def incident_id(sha256: str, ip: str) -> str:
    return "WEB-" + hashlib.sha1(f"{sha256}|{ip}".encode()).hexdigest()[:10].upper()


def compact(f) -> dict:
    return {"category": f.category, "rule_ids": f.rule_ids, "rule_names": f.rule_names, "request": f.request,
            "status": f.status, "ts": f.ts, "last_ts": f.last_ts, "kind": f.kind, "count": f.count,
            "explanation": f.explanation, "evidence": f.evidence[:10]}


def build_incidents(df: pd.DataFrame, findings: list, cfg: DetectionConfig, sha256: str) -> list[Incident]:
    by_ip: dict[str, list] = {}
    for f in findings:
        by_ip.setdefault(f.ip, []).append(f)
    out = []
    for ip, fs in by_ip.items():
        g = df[df["ip"] == ip]
        cats = {f.category for f in fs}
        bf = next((f.details.get("intensity") for f in fs if f.category == "brute_force"), None)
        score, contrib = score_categories(cats, bf, cfg)
        raw_total = sum(c["points"] for c in contrib)
        expl = " + ".join(f"{c['component']} ({c['points']})" for c in contrib) + f" = {raw_total}"
        if raw_total > 100:
            expl += " (capped at 100)"
        lines = {n for f in fs for n in f.line_nos}
        req_findings = [f for f in fs if f.kind == "request"]
        rules = sorted({r for f in fs for r in f.rule_ids})
        ordered = sorted(fs, key=lambda f: (list(CATEGORY_NAMES).index(f.category), f.ts))
        out.append(Incident(
            incident_id=incident_id(sha256, ip), ip=ip, score=score, level=category(score),
            categories=[c for c in CATEGORY_NAMES if c in cats], rules=rules, contributions=contrib, explanation=expl,
            total_requests=int(len(g)), failed_responses=int((g["status"] >= 400).sum()),
            suspicious_requests=len(lines | {n for f in req_findings for n in f.line_nos}),
            unique_paths=int(g["path"].map(lambda p: p.split("?")[0]).nunique()),
            first_seen=float(g["ts"].min()), last_seen=float(g["ts"].max()),
            user_agents=[u for u in g["user_agent"].value_counts().head(3).index if u],
            findings=[compact(f) for f in ordered[:300]],
            recommendations={c: RECOMMENDATIONS[c] for c in CATEGORY_NAMES if c in cats}))
    out.sort(key=lambda i: (-i.score, i.first_seen))
    return out
