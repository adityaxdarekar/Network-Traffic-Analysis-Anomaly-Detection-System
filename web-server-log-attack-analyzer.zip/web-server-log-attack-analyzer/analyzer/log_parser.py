"""
log_parser.py - Apache access log parser (Common, Combined and CSV).

Apache LogFormat directives
  Common   (CLF): "%h %l %u %t \"%r\" %>s %b"
  Combined      : "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-agent}i\""

  %h client IP · %l identd (almost always "-") · %u authenticated user ·
  %t time [10/Oct/2000:13:55:36 -0700] · %r request line "GET /path HTTP/1.1" ·
  %>s final status · %b response bytes ("-" when 0) · Referer · User-Agent

Example (combined):
  203.0.113.10 - - [02/Nov/2026:10:00:01 +0000] "POST /login HTTP/1.1" 401 512 "-" "python-requests/2.31"

Behaviour
  * one bad line never stops the parse: it is recorded in `malformed` with its
    line number, a reason and the (sanitised, truncated) original text
  * timestamps are normalised to UTC
  * a request line Apache could not understand (e.g. TLS bytes sent to port 80)
    is kept as an entry with method "INVALID"; "-" (408 timeouts) is method "-"
  * control characters are replaced, lines longer than 16 KB are rejected
  * CSV files need the columns timestamp, ip, method, path, status (aliases
    accepted) and may add protocol, size, referrer, user_agent
  * a file whose first comment lines mention SYNTHETIC, or that has a
    `.synthetic` sidecar file, is flagged as synthetic
"""
from __future__ import annotations

import csv
import hashlib
import io
import ipaddress
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

MAX_LINE = 16_384
LINE_RE = re.compile(
    r'^(?P<ip>\S+) (?P<ident>\S+) (?P<user>\S+) \[(?P<time>[^\]]+)\] '
    r'"(?P<request>(?:[^"\\]|\\.)*)" (?P<status>\S+) (?P<size>\S+)'
    r'(?: "(?P<referrer>(?:[^"\\]|\\.)*)" "(?P<ua>(?:[^"\\]|\\.)*)")?(?P<extra>\s.*)?$')
TIME_RE = re.compile(r"^(\d{1,2})/([A-Za-z]{3})/(\d{4}):(\d{2}):(\d{2}):(\d{2}) ([+-])(\d{2})(\d{2})$")
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                      "dec"], 1)}
METHOD_RE = re.compile(r"^[A-Z][A-Z_-]{0,19}$")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
COLUMNS = ["line_no", "timestamp", "ts", "ip", "ident", "user", "method", "path", "protocol", "status", "size",
           "referrer", "user_agent", "log_format", "raw"]
CSV_ALIASES = {
    "timestamp": ["timestamp", "time", "datetime", "date", "@timestamp"],
    "ip": ["ip", "source_ip", "src_ip", "client_ip", "remote_addr", "client"],
    "method": ["method", "http_method", "verb"],
    "path": ["path", "url", "uri", "request_path", "request_uri", "request"],
    "protocol": ["protocol", "http_version", "version"],
    "status": ["status", "status_code", "response_code", "code"],
    "size": ["size", "bytes", "response_size", "body_bytes_sent"],
    "referrer": ["referrer", "referer"],
    "user_agent": ["user_agent", "useragent", "ua", "agent"],
}


class LogFormatError(ValueError):
    """The input cannot be parsed at all (empty, binary, unknown CSV layout)."""


class LineError(ValueError):
    pass


@dataclass
class ParseResult:
    file_name: str
    file_sha256: str
    source_format: str                     # "apache" or "csv"
    entries: pd.DataFrame
    malformed: list = field(default_factory=list)    # (line_no, reason, raw)
    total_lines: int = 0
    blank_lines: int = 0
    comment_lines: int = 0
    synthetic: bool = False
    formats: dict = field(default_factory=dict)      # combined / common / csv counts
    truncated: bool = False

    @property
    def parsed(self) -> int:
        return len(self.entries)

    def stats(self) -> dict:
        considered = self.total_lines - self.blank_lines - self.comment_lines
        return {"total_lines": self.total_lines, "log_entries": considered, "parsed": self.parsed,
                "malformed": len(self.malformed), "blank": self.blank_lines, "comments": self.comment_lines,
                "parse_rate": round(100 * self.parsed / considered, 1) if considered else 0.0,
                "formats": dict(self.formats)}


# ------------------------------------------------------------------ field helpers
def sanitize(line: str) -> str:
    return CONTROL_RE.sub("?", line)


def parse_apache_time(t: str) -> datetime:
    m = TIME_RE.match(t.strip())
    if not m:
        raise LineError(f"invalid timestamp '{t[:40]}'")
    d, mon, y, hh, mm, ss, sign, oh, om = m.groups()
    if mon.lower() not in MONTHS:
        raise LineError(f"invalid month '{mon}'")
    try:
        off = timedelta(hours=int(oh), minutes=int(om)) * (1 if sign == "+" else -1)
        dt = datetime(int(y), MONTHS[mon.lower()], int(d), int(hh), int(mm), int(ss), tzinfo=timezone(off))
    except ValueError as exc:
        raise LineError(f"invalid timestamp '{t[:40]}': {exc}") from None
    return dt.astimezone(timezone.utc)


def parse_any_time(t: str) -> datetime:
    t = (t or "").strip()
    if TIME_RE.match(t):
        return parse_apache_time(t)
    try:
        ts = pd.Timestamp(t)
    except (ValueError, TypeError):
        raise LineError(f"invalid timestamp '{t[:40]}'") from None
    if pd.isna(ts):
        raise LineError("missing timestamp")
    ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    return ts.to_pydatetime()


def check_ip(ip: str) -> str:
    try:
        return str(ipaddress.ip_address(ip.strip()))
    except ValueError:
        raise LineError(f"invalid IP address '{ip[:45]}'") from None


def check_status(s) -> int:
    try:
        v = int(str(s).strip())
    except ValueError:
        raise LineError(f"invalid status code '{str(s)[:10]}'") from None
    if not 100 <= v <= 599:
        raise LineError(f"status code out of range: {v}")
    return v


def check_size(s) -> int:
    s = str(s).strip()
    if s in ("-", ""):
        return 0
    try:
        v = int(float(s))
    except ValueError:
        raise LineError(f"invalid response size '{s[:15]}'") from None
    if v < 0:
        raise LineError("negative response size")
    return v


def unescape_field(s: str | None) -> str:
    if s is None or s == "-":
        return ""
    return s.replace('\\"', '"').replace("\\\\", "\\")


def split_request(req: str) -> tuple[str, str, str]:
    """'GET /a b HTTP/1.1' -> ('GET', '/a b', 'HTTP/1.1'). Unparseable lines -> ('INVALID', req, '')."""
    req = req.strip()
    if req in ("", "-"):
        return "-", "", ""
    parts = req.split(" ")
    if len(parts) >= 3 and parts[-1].upper().startswith("HTTP/") and METHOD_RE.match(parts[0]):
        return parts[0], " ".join(parts[1:-1]), parts[-1]
    if len(parts) == 2 and METHOD_RE.match(parts[0]) and not parts[1].upper().startswith("HTTP/"):
        return parts[0], parts[1], ""                        # HTTP/0.9 style
    return "INVALID", req, ""


def parse_line(line: str, line_no: int = 0) -> dict:
    """One Apache CLF/Combined line -> entry dict. Raises LineError with a reason."""
    if len(line) > MAX_LINE:
        raise LineError(f"line longer than {MAX_LINE} characters")
    m = LINE_RE.match(line)
    if not m:
        if not re.match(r"^\S+ \S+ \S+ \[", line):
            raise LineError("does not match Apache Common/Combined format")
        if '"' not in line:
            raise LineError("request line missing")
        raise LineError("missing or unterminated fields")
    g = m.groupdict()
    dt = parse_apache_time(g["time"])
    method, path, proto = split_request(unescape_field(g["request"]) if g["request"] != "-" else "-")
    return {"line_no": line_no, "timestamp": dt, "ip": check_ip(g["ip"]), "ident": g["ident"],
            "user": "" if g["user"] == "-" else g["user"], "method": method, "path": path, "protocol": proto,
            "status": check_status(g["status"]), "size": check_size(g["size"]),
            "referrer": unescape_field(g["referrer"]), "user_agent": unescape_field(g["ua"]),
            "log_format": "combined" if g["ua"] is not None else "common", "raw": line}


# ------------------------------------------------------------------ whole inputs
def _frame(rows: list[dict]) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame(columns=COLUMNS)
    df = pd.DataFrame(rows)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df["ts"] = df["timestamp"].map(lambda t: t.timestamp())
    df = df.sort_values(["ts", "line_no"], kind="stable").reset_index(drop=True)
    return df[COLUMNS]


def parse_lines(lines, file_name: str = "<text>", sha256: str = "", max_lines: int | None = None) -> ParseResult:
    from config import MAX_LINES
    max_lines = max_lines or MAX_LINES
    rows, bad, fmts = [], [], Counter()
    total = blank = comments = 0
    synthetic = truncated = False
    for n, line in enumerate(lines, 1):
        if n > max_lines:
            truncated = True
            break
        total += 1
        line = sanitize(line.rstrip("\r\n"))
        if not line.strip():
            blank += 1
            continue
        if line.lstrip().startswith("#"):
            comments += 1
            synthetic = synthetic or "SYNTHETIC" in line.upper()
            continue
        try:
            e = parse_line(line, n)
        except LineError as exc:
            bad.append((n, str(exc), line[:500]))
            continue
        rows.append(e)
        fmts[e["log_format"]] += 1
    return ParseResult(file_name, sha256, "apache", _frame(rows), bad, total, blank, comments, synthetic, dict(fmts),
                       truncated)


def _csv_columns(header: list[str]) -> dict:
    low = {h.strip().lower(): h for h in header}
    out = {}
    for std, aliases in CSV_ALIASES.items():
        for a in aliases:
            if a in low:
                out[std] = low[a]
                break
    missing = [c for c in ("timestamp", "ip", "method", "path", "status") if c not in out]
    if missing:
        raise LogFormatError(f"CSV is missing required column(s): {', '.join(missing)} "
                             f"(found: {', '.join(header[:12])})")
    return out


def parse_csv_text(text: str, file_name: str = "<csv>", sha256: str = "") -> ParseResult:
    from config import MAX_LINES
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        raise LogFormatError("the CSV file is empty") from None
    cols = _csv_columns(header)
    idx = {k: header.index(v) for k, v in cols.items()}
    rows, bad = [], []
    total = blank = 1                                     # header counted as non-entry line
    for n, rec in enumerate(reader, 2):
        if n > MAX_LINES:
            break
        total += 1
        if not any(c.strip() for c in rec):
            blank += 1
            continue
        raw = sanitize(",".join(rec))
        try:
            if len(rec) < len(header):
                raise LineError(f"expected {len(header)} columns, found {len(rec)}")
            get = lambda k, d="": sanitize(rec[idx[k]]).strip() if k in idx else d   # noqa: E731
            method = get("method").upper() or "-"
            if method != "-" and not METHOD_RE.match(method):
                method = "INVALID"
            path = get("path")
            if not path and method != "-":
                raise LineError("missing path")
            rows.append({"line_no": n, "timestamp": parse_any_time(get("timestamp")), "ip": check_ip(get("ip")),
                         "ident": "-", "user": "", "method": method, "path": path, "protocol": get("protocol"),
                         "status": check_status(get("status")), "size": check_size(get("size", "0")),
                         "referrer": unescape_field(get("referrer") or "-"),
                         "user_agent": unescape_field(get("user_agent") or "-"), "log_format": "csv", "raw": raw[:2000]})
        except LineError as exc:
            bad.append((n, str(exc), raw[:500]))
    first = text[:4096].upper()
    return ParseResult(file_name, sha256, "csv", _frame(rows), bad, total, blank, 0, "SYNTHETIC" in first,
                       {"csv": len(rows)} if rows else {})


def looks_like_csv(name: str, text: str) -> bool:
    if Path(name).suffix.lower() == ".csv":
        return True
    first = text.lstrip()[:300].split("\n", 1)[0].lower()
    return "," in first and ("status" in first and ("ip" in first or "timestamp" in first))


def parse_bytes(data: bytes, file_name: str = "<upload>") -> ParseResult:
    if not data:
        raise LogFormatError("the file is empty")
    if b"\x00" in data[:8192]:
        raise LogFormatError("the file looks binary (NUL bytes) - expected a text access log")
    sha = hashlib.sha256(data).hexdigest()
    text = data.decode("utf-8", errors="replace")
    if looks_like_csv(file_name, text):
        res = parse_csv_text(text, file_name, sha)
    else:
        res = parse_lines(text.splitlines(), file_name, sha)
    return res


def parse_file(path, display_name: str | None = None) -> ParseResult:
    p = Path(path)
    if not p.is_file():
        raise LogFormatError(f"file not found: {p}")
    res = parse_bytes(p.read_bytes(), display_name or p.name)
    if p.with_name(p.name + ".synthetic").exists():
        res.synthetic = True
    return res
