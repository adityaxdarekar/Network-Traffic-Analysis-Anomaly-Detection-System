"""
engine.py - one complete analysis, used by the dashboard, the CLI and the tests.

  parse (log_parser) -> request detectors (SQLi, XSS, traversal) -> per-IP detectors
  (brute force, reconnaissance, anomalies) -> allowlist -> risk scoring -> display copy
  with secrets redacted.

Detection always runs on the original request text; only what is DISPLAYED,
stored or exported is redacted.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from analyzer import (anomaly_detector, brute_force_detector, reconnaissance_detector, sql_injection_detector,
                      traversal_detector, xss_detector)
from analyzer.log_parser import ParseResult, parse_file
from analyzer.risk_scorer import build_incidents
from config import DetectionConfig
from utils.helpers import redact

DETECTORS = [("sql_injection", sql_injection_detector), ("xss", xss_detector), ("traversal", traversal_detector),
             ("brute_force", brute_force_detector), ("reconnaissance", reconnaissance_detector),
             ("anomaly", anomaly_detector)]


@dataclass
class AnalysisResult:
    parsed: ParseResult
    config: dict
    findings: list
    incidents: list
    df: pd.DataFrame                       # display copy (secrets redacted if enabled)
    stats: dict = field(default_factory=dict)

    @property
    def file_name(self):
        return self.parsed.file_name

    def by_category(self, cat: str) -> list:
        return [f for f in self.findings if f.category == cat]

    def suspicious_requests(self) -> pd.DataFrame:
        """One row per request referenced by a request-level finding (SQLi / XSS / traversal)."""
        rows = {}
        for f in self.findings:
            if f.kind != "request":
                continue
            ln = f.line_nos[0]
            r = rows.setdefault(ln, {"line_no": ln, "time": pd.to_datetime(f.ts, unit="s", utc=True), "ip": f.ip,
                                     "request": f.request, "status": f.status, "categories": [], "rules": []})
            r["categories"].append(f.category)
            r["rules"] += f.rule_ids
        out = pd.DataFrame(rows.values(), columns=["line_no", "time", "ip", "request", "status", "categories", "rules"])
        if not out.empty:
            out["categories"] = out["categories"].map(", ".join)
            out["rules"] = out["rules"].map(", ".join)
            lv = {i.ip: i.level for i in self.incidents}
            out["ip_risk"] = out["ip"].map(lv)
            out = out.sort_values("time").reset_index(drop=True)
        return out

    def ip_table(self, only_suspicious: bool = True) -> pd.DataFrame:
        inc = {i.ip: i for i in self.incidents}
        if only_suspicious:
            rows = [{"ip": i.ip, "total_requests": i.total_requests, "failed_responses": i.failed_responses,
                     "suspicious_requests": i.suspicious_requests, "unique_paths": i.unique_paths,
                     "categories": ", ".join(i.categories), "first_seen": pd.to_datetime(i.first_seen, unit="s", utc=True),
                     "last_seen": pd.to_datetime(i.last_seen, unit="s", utc=True), "risk_score": i.score,
                     "risk_level": i.level, "incident_id": i.incident_id} for i in self.incidents]
            return pd.DataFrame(rows)
        d = self.df
        if d.empty:
            return pd.DataFrame()
        g = d.groupby("ip").agg(total_requests=("line_no", "count"), failed_responses=("status", lambda s: int((s >= 400).sum())),
                                unique_paths=("path", lambda s: s.map(lambda p: p.split("?")[0]).nunique()),
                                first_seen=("timestamp", "min"), last_seen=("timestamp", "max")).reset_index()
        g["risk_score"] = g["ip"].map(lambda ip: inc[ip].score if ip in inc else 0)
        g["risk_level"] = g["ip"].map(lambda ip: inc[ip].level if ip in inc else "None")
        g["categories"] = g["ip"].map(lambda ip: ", ".join(inc[ip].categories) if ip in inc else "")
        return g.sort_values(["risk_score", "total_requests"], ascending=False).reset_index(drop=True)


def analyze_parsed(parsed: ParseResult, cfg: DetectionConfig | None = None) -> AnalysisResult:
    cfg = cfg or DetectionConfig()
    errs = cfg.validate()
    if errs:
        raise ValueError("invalid configuration: " + "; ".join(errs))
    df = parsed.entries
    findings = []
    for _, mod in DETECTORS:
        findings += mod.scan(df, cfg)
    allow = set(cfg.allowlist_ips or [])
    findings = [f for f in findings if f.ip not in allow]
    findings.sort(key=lambda f: (f.ts, f.ip))
    incidents = build_incidents(df, findings, cfg, parsed.file_sha256)
    disp = df.copy()
    if cfg.redact_secrets and not disp.empty:
        disp["path"] = disp["path"].map(redact)
        disp["raw"] = disp["raw"].map(redact)
        for f in findings:
            f.request = redact(f.request)
            f.evidence = [redact(e) for e in f.evidence]
        for i in incidents:
            for f in i.findings:
                f["request"] = redact(f["request"])
                f["evidence"] = [redact(e) for e in f["evidence"]]
    res = AnalysisResult(parsed, cfg.to_dict(), findings, incidents, disp)
    res.stats = make_stats(res)
    return res


def make_stats(res: AnalysisResult) -> dict:
    p, df = res.parsed.stats(), res.df
    lv = [i.level for i in res.incidents]
    ips_of = lambda c: len({f.ip for f in res.findings if f.category == c})   # noqa: E731
    return {**p,
            "unique_ips": int(df["ip"].nunique()) if not df.empty else 0,
            "suspicious_ips": len(res.incidents), "incidents": len(res.incidents),
            "sqli_indicators": len(res.by_category("sql_injection")), "xss_indicators": len(res.by_category("xss")),
            "traversal_indicators": len(res.by_category("traversal")),
            "brute_force_ips": ips_of("brute_force"), "recon_ips": ips_of("reconnaissance"),
            "frequency_ips": ips_of("excessive_frequency"), "anomaly_ips": ips_of("http_anomaly"),
            "critical": lv.count("Critical"), "high": lv.count("High"), "medium": lv.count("Medium"),
            "low": lv.count("Low"),
            "first_ts": float(df["ts"].min()) if not df.empty else None,
            "last_ts": float(df["ts"].max()) if not df.empty else None,
            "status_counts": {int(k): int(v) for k, v in df["status"].value_counts().sort_index().items()}
            if not df.empty else {},
            "methods": df["method"].value_counts().to_dict() if not df.empty else {}}


def run_analysis(path, cfg: DetectionConfig | None = None, display_name: str | None = None) -> AnalysisResult:
    return analyze_parsed(parse_file(path, display_name), cfg)
