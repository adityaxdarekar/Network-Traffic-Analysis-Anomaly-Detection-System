"""
anomaly_detector.py - unusual HTTP behaviour per source IP.

  ANOM-01 Excessive request frequency  > cfg.freq_max_requests requests from one IP inside any
                                       cfg.freq_window_seconds window (sliding)     -> category excessive_frequency
  ANOM-02 Repeated identical path      >= cfg.repeat_path_threshold requests for the same path in one window
                                       (login endpoints excluded - brute force covers them)
  ANOM-03 Unusual HTTP method          methods outside cfg.allowed_methods (PUT, DELETE, TRACE, OPTIONS,
                                       PROPFIND, CONNECT ...) and unparseable request lines ("INVALID")
  ANOM-04 Abnormal status distribution share of 5xx server errors >= cfg.error_ratio_threshold
                                       (with >= cfg.error_ratio_min_requests requests)
  ANOM-05 Suspicious User-Agent        empty (except 408 time-outs), generic HTTP library/tool (curl, python-requests, Go-http-client
                                       ...), longer than 512 characters, or containing injection syntax
  ANOM-06 Unusual response size        robust z-score (median / MAD, NumPy) >= cfg.size_mad_threshold and at
                                       least cfg.size_min_bytes - e.g. a large file or database dump downloaded

ANOM-02..06 share the category http_anomaly (scored once per IP).
Repeated 404 responses are handled by the reconnaissance detector (REC-06).
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from analyzer.brute_force_detector import mark_auth
from analyzer.findings import Finding, sliding_max
from analyzer.reconnaissance_detector import scanner_name
from config import DetectionConfig

TOOL_UA = re.compile(r"^(curl|wget|python-requests|python-urllib|python-httpx|aiohttp|go-http-client|java/|"
                     r"apache-httpclient|okhttp|libwww-perl|lwp::|php/|ruby|powershell|winhttp|httpie|scrapy|axios|"
                     r"node-fetch|postmanruntime|masscan)", re.I)
INJECT_UA = re.compile(r"<\s*script|\$\{jndi:|\(\)\s*\{\s*:\s*;\s*\}|union\s+select|'\s*or\s+'|\.\./\.\./", re.I)
NAMES = {"ANOM-01": "Excessive request frequency", "ANOM-02": "Repeated identical path",
         "ANOM-03": "Unusual HTTP method", "ANOM-04": "Abnormal status distribution",
         "ANOM-05": "Suspicious User-Agent", "ANOM-06": "Unusual response size"}


def ua_issue(ua: str, log_format: str, method: str = "GET") -> str | None:
    if log_format == "common" or method == "-":   # CLF has no User-Agent; 408 time-outs carry no request
        return None
    if not ua:
        return "empty User-Agent"
    if INJECT_UA.search(ua):
        return "injection syntax in User-Agent"
    if len(ua) > 512:
        return "User-Agent longer than 512 characters"
    if TOOL_UA.match(ua):
        return f"generic HTTP tool '{ua.split('/')[0][:30]}'"
    return None


def size_outliers(df: pd.DataFrame, cfg: DetectionConfig) -> pd.Series:
    """Boolean mask of successful responses with an unusually large size (robust z-score)."""
    ok = df["status"].between(200, 299)
    sizes = df.loc[ok, "size"].to_numpy(dtype=float)
    mask = pd.Series(False, index=df.index)
    if sizes.size < 10:
        return mask
    med = float(np.median(sizes))
    mad = float(np.median(np.abs(sizes - med)))
    if mad > 0:
        z = 0.6745 * (df["size"] - med) / mad
    else:
        z = pd.Series(np.where(df["size"] > 10 * max(med, 1), np.inf, 0.0), index=df.index)
    return ok & (z >= cfg.size_mad_threshold) & (df["size"] >= cfg.size_min_bytes)


def scan(df: pd.DataFrame, cfg: DetectionConfig | None = None) -> list[Finding]:
    cfg = cfg or DetectionConfig()
    if df is None or df.empty:
        return []
    out = []
    auth = mark_auth(df, cfg)
    big = size_outliers(df, cfg)
    allowed = {m.upper() for m in cfg.allowed_methods} | {"-"}
    for ip, g in df.groupby("ip", sort=False):
        ts = g["ts"].to_numpy()
        # ANOM-01 -> its own category
        peak, ws, we = sliding_max(ts, cfg.freq_window_seconds)
        if peak > cfg.freq_max_requests:
            inwin = g[(g["ts"] >= ws) & (g["ts"] <= we)]
            out.append(Finding(
                category="excessive_frequency", ip=ip, ts=ws, last_ts=we, rule_ids=["ANOM-01"],
                rule_names=[NAMES["ANOM-01"]],
                explanation=f"{peak} requests within {cfg.freq_window_seconds} s (threshold "
                            f"{cfg.freq_max_requests}); {len(g)} requests in total. Could be a flood, a scraper or "
                            f"an automated attack - or a busy legitimate client (proxy, NAT, monitoring).",
                evidence=[f"top paths in the window: " + ", ".join(
                    f"{p} x{n}" for p, n in inwin["path"].value_counts().head(3).items())],
                line_nos=inwin["line_no"].tolist()[:2000], kind="aggregate", count=int(peak),
                details={"peak": int(peak), "window_start": ws, "window_end": we, "total": int(len(g))}))
        ids, parts, ev, lines = [], [], [], set()
        # ANOM-02
        rep = g[~auth.loc[g.index]]
        best = (0, "", 0.0, 0.0)
        for path, pg in rep.groupby("path", sort=False):
            if len(pg) >= cfg.repeat_path_threshold:
                n, s, e = sliding_max(pg["ts"].to_numpy(), cfg.freq_window_seconds)
                if n > best[0]:
                    best = (n, path, s, e)
        if best[0] >= cfg.repeat_path_threshold:
            ids.append("ANOM-02")
            parts.append(f"'{best[1][:80]}' requested {best[0]}x within {cfg.freq_window_seconds} s "
                         f"(threshold {cfg.repeat_path_threshold})")
            lines |= set(rep.loc[(rep["path"] == best[1]), "line_no"].head(500))
        # ANOM-03
        odd = g[~g["method"].str.upper().isin(allowed)]
        if not odd.empty:
            ids.append("ANOM-03")
            parts.append("unusual methods " + ", ".join(f"{m} x{n}" for m, n in odd["method"].value_counts().items()))
            ev += [f"{r.method} {r.path[:80]} -> {r.status}" for r in odd.head(4).itertuples()]
            lines |= set(odd["line_no"])
        # ANOM-04
        if len(g) >= cfg.error_ratio_min_requests:
            r5 = float(g["status"].between(500, 599).mean())
            if r5 >= cfg.error_ratio_threshold:
                ids.append("ANOM-04")
                parts.append(f"{r5:.0%} of {len(g)} responses are 5xx server errors (threshold "
                             f"{cfg.error_ratio_threshold:.0%}) - malformed or malicious input can cause errors")
                lines |= set(g.loc[g["status"] >= 500, "line_no"])
        # ANOM-05
        issues = g.apply(lambda r: ua_issue(r["user_agent"], r["log_format"], r["method"]), axis=1).dropna()
        issues = issues[g.loc[issues.index, "user_agent"].map(lambda u: scanner_name(u) is None)]  # scanners: REC-05
        if not issues.empty:
            ids.append("ANOM-05")
            parts.append("User-Agent: " + ", ".join(f"{k} x{v}" for k, v in issues.value_counts().head(3).items()))
            lines |= set(g.loc[issues.index, "line_no"].head(500))
        # ANOM-06
        large = g[big.loc[g.index]]
        if not large.empty:
            ids.append("ANOM-06")
            parts.append(f"{len(large)} unusually large response(s), up to {int(large['size'].max()):,} bytes")
            ev += [f"{r.method} {r.path[:80]} -> {r.status}, {int(r.size):,} bytes" for r in large.head(3).itertuples()]
            lines |= set(large["line_no"])
        if ids:
            out.append(Finding(
                category="http_anomaly", ip=ip, ts=float(g["ts"].min()), last_ts=float(g["ts"].max()), rule_ids=ids,
                rule_names=[NAMES[i] for i in ids], explanation="HTTP anomalies: " + "; ".join(parts) + ".",
                evidence=ev[:8], line_nos=sorted(lines)[:2000], kind="aggregate", count=len(lines),
                details={"requests": int(len(g))}))
    return out


def global_profile(df: pd.DataFrame) -> dict:
    """Whole-log statistics for the traffic page (status classes, methods, per-minute peak)."""
    if df is None or df.empty:
        return {}
    per_min = df.set_index("timestamp").resample("1min").size()
    return {"requests": int(len(df)), "peak_per_minute": int(per_min.max()), "median_per_minute": float(per_min.median()),
            "status_classes": df["status"].map(lambda s: f"{s // 100}xx").value_counts().to_dict(),
            "methods": df["method"].value_counts().to_dict()}
