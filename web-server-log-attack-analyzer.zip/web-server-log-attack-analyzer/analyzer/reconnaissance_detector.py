"""
reconnaissance_detector.py - scanning and discovery behaviour per source IP.

Per-request indicators (matched on the decoded path, case-insensitive)
  REC-01 admin interface      /admin /administrator /wp-admin /phpmyadmin /manager/html /cpanel /adminer.php ...
  REC-02 sensitive file       /.env /.git/ /.svn/ /.htaccess /.htpasswd /wp-config.php /config.php /id_rsa ...
  REC-03 server information   /server-status /server-info /phpinfo.php /info.php /cgi-bin/ /actuator ...
  REC-04 backup file          *.bak *.old *.orig *.swp *.sql backup.zip site.tar.gz db.sql trailing ~ ...
  REC-05 scanner User-Agent   sqlmap, Nikto, Nmap, gobuster, dirbuster, ffuf, wfuzz, nuclei, WPScan, masscan ...
  (info) /robots.txt          listed for context only - search engines read it legitimately

Per-IP indicators
  REC-06 repeated 404s        >= cfg.recon_max_404 "Not Found" responses
  REC-07 many unique paths    >= cfg.recon_min_unique_paths distinct paths AND >= cfg.recon_min_error_ratio of
                              the IP's responses are 4xx (a crawler of real pages gets 200s)

An IP is reported when it probed >= cfg.recon_min_sensitive_paths DISTINCT
sensitive paths, or used a scanner User-Agent, or REC-06 / REC-07 fired.
"Sensitive paths" count admin/server-info paths only when the server
answered 4xx (a real administrator gets 200), while sensitive and backup files
always count (there is no normal reason to request them).

These are indicators, not proof: link checkers, uptime monitors, SEO crawlers
and the site's own administrators can trigger some of them.
"""
from __future__ import annotations

import re

import pandas as pd

from analyzer.findings import Finding, rx
from analyzer.normalizer import view
from config import DetectionConfig

PATH_RULES = [
    ("REC-01", "Admin interface probe",
     rx(r"^/(admin|administrator|wp-admin|phpmyadmin|pma|myadmin|mysqladmin|dbadmin|sqladmin|manager/html|cpanel|"
        r"webadmin|admin\.php|admin\.asp|adminer(\.php)?|console|jenkins|solr/admin|_admin|backend|cms/admin)"
        r"(/|$|\.|\?)")),
    ("REC-02", "Sensitive file probe",
     rx(r"/(\.git|\.svn|\.hg|\.ssh|\.aws|\.vscode|\.idea)(/|$)"
        r"|/(\.env(\.\w+)?|\.htaccess|\.htpasswd|\.ds_store|wp-config\.php(\.\w+)?|config\.php|configuration\.php|"
        r"web\.config|id_rsa|\.bash_history|\.npmrc|\.dockerenv|docker-compose\.ya?ml|composer\.(json|lock)|"
        r"sftp-config\.json)($|[/?])")),
    ("REC-03", "Server information probe",
     rx(r"^/(server-status|server-info|phpinfo\.php|info\.php|test\.php|php_info\.php|cgi-bin/|actuator(/|$)|"
        r"\.well-known/(?!acme-challenge)|status\.php|elmah\.axd|trace\.axd)")),
    ("REC-04", "Backup file probe",
     rx(r"(\.(bak|old|orig|backup|save|swp|sql|sql\.gz)|~|/(backup|backups|bak|old|dump|db|database|site|www|"
        r"htdocs|public_html|wwwroot|website)[\w.-]*\.(zip|tar|tar\.gz|tgz|gz|rar|7z|sql))$")),
]
ALWAYS_COUNT = {"REC-02", "REC-04"}
SCANNER_UA = re.compile(
    r"sqlmap|nikto|nmap|masscan|zgrab|dirbuster|\bdirb\b|gobuster|wfuzz|\bffuf\b|feroxbuster|nuclei|acunetix|"
    r"netsparker|nessus|openvas|w3af|wpscan|whatweb|arachni|skipfish|burp ?suite|owasp ?zap|hydra|medusa|joomscan|"
    r"commix|jaeles|zmeu|morfeus|libwhisker|httpx|xray|fimap|havij|paros|webinspect|appscan|detectify|qualys",
    re.I)
RULE_NAMES = {r[0]: r[1] for r in PATH_RULES} | {"REC-05": "Scanner User-Agent", "REC-06": "Repeated 404 responses",
                                                  "REC-07": "Many unique paths with errors"}


def classify_path(path: str) -> list[str]:
    p = view(path).path.lower()
    return [rid for rid, _, pat in PATH_RULES if pat.search(p)]


def scanner_name(ua: str) -> str | None:
    m = SCANNER_UA.search(ua or "")
    return m.group(0) if m else None


def scan(df: pd.DataFrame, cfg: DetectionConfig | None = None) -> list[Finding]:
    cfg = cfg or DetectionConfig()
    if df is None or df.empty:
        return []
    cache: dict[str, list] = {}
    out = []
    for ip, g in df.groupby("ip", sort=False):
        probes = []                                      # (rule, path, status, line_no, ts)
        for r in g.itertuples(index=False):
            rules = cache.get(r.path)
            if rules is None:
                rules = cache[r.path] = classify_path(r.path) if r.path else []
            for rid in rules:
                probes.append((rid, r.path.split("?")[0], r.status, r.line_no, r.ts))
        counted = {(p[1]) for p in probes if p[0] in ALWAYS_COUNT or p[2] >= 400}
        scanners = g["user_agent"].map(scanner_name).dropna()
        n404 = int((g["status"] == 404).sum())
        uniq = int(g["path"].map(lambda p: p.split("?")[0]).nunique())
        err_ratio = float((g["status"].between(400, 499)).mean())
        ids = sorted({p[0] for p in probes if p[1] in counted})
        if len(counted) < cfg.recon_min_sensitive_paths:
            ids = []                                     # a couple of probes alone is not enough
        if not scanners.empty:
            ids.append("REC-05")
        if n404 >= cfg.recon_max_404:
            ids.append("REC-06")
        if uniq >= cfg.recon_min_unique_paths and err_ratio >= cfg.recon_min_error_ratio:
            ids.append("REC-07")
        if not ids:
            continue
        parts = []
        if len(counted) >= cfg.recon_min_sensitive_paths:
            parts.append(f"{len(counted)} distinct sensitive paths probed (threshold {cfg.recon_min_sensitive_paths})")
        if not scanners.empty:
            parts.append(f"scanner User-Agent '{scanners.iloc[0]}' on {len(scanners)} requests")
        if "REC-06" in ids:
            parts.append(f"{n404} 404 responses (threshold {cfg.recon_max_404})")
        if "REC-07" in ids:
            parts.append(f"{uniq} unique paths with {err_ratio:.0%} 4xx responses (thresholds "
                         f"{cfg.recon_min_unique_paths} / {cfg.recon_min_error_ratio:.0%})")
        robots = int(g["path"].str.lower().str.startswith("/robots.txt").sum())
        lines = sorted({p[3] for p in probes if p[1] in counted} | set(g.loc[g["status"] == 404, "line_no"])
                       | set(g.loc[scanners.index, "line_no"] if not scanners.empty else []))
        ev = []
        seen = set()
        for p in probes:
            if p[1] in counted and p[1] not in seen:
                seen.add(p[1])
                ev.append(f"{p[0]}: {p[1]} -> {p[2]}")
        out.append(Finding(
            category="reconnaissance", ip=ip, ts=float(g["ts"].min()), last_ts=float(g["ts"].max()), rule_ids=ids,
            rule_names=[RULE_NAMES[i] for i in ids],
            explanation="Possible reconnaissance/scanning: " + "; ".join(parts) + "."
                        + (f" Also requested /robots.txt {robots}x (context only)." if robots else "")
                        + " Indicator only - crawlers, monitors and administrators can look similar.",
            evidence=ev[:15] + ([f"User-Agent: {g.loc[scanners.index[0], 'user_agent'][:120]}"]
                                if not scanners.empty else []),
            line_nos=lines[:2000], kind="aggregate", count=len(lines),
            details={"sensitive_paths": sorted(counted)[:200], "n404": n404, "unique_paths": uniq,
                     "error_ratio": round(err_ratio, 3), "scanner_ua": sorted(set(scanners))[:5],
                     "robots_txt": robots, "requests": int(len(g))}))
    return out
