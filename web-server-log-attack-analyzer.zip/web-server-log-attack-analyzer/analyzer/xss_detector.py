"""
xss_detector.py - rule-based indicators of Cross-Site Scripting (XSS) attempts.

Request targets are percent-decoded (repeatedly) and HTML-entity-decoded
(&lt;script&gt; -> <script>) before matching, case-insensitively.

  XSS-01 script tag                 <script ...>   </script>
  XSS-02 event handler              <img src=x onerror=...>   " onmouseover=
  XSS-03 script URI scheme          javascript:  vbscript:  data:text/html
  XSS-04 HTML injection tag         <iframe <svg <img <object <embed <body <details ...
  XSS-05 JavaScript sink/function   document.cookie  window.location  alert(  eval(  String.fromCharCode
  XSS-06 encoded markup             %3C / %253C / &lt; / &#60; / \x3c that decodes into a tag

A match shows that someone SENT script-like input. It does not show the site
is vulnerable: that requires the input to be reflected or stored without
output encoding, which an access log cannot tell. Status codes (200 vs 4xx)
only hint whether the application accepted the request.
"""
from __future__ import annotations

from analyzer.findings import Rule, rx, scan_requests
from analyzer.normalizer import view

HANDLERS = ("error|load|mouseover|mouseenter|mouseout|focus|blur|click|dblclick|submit|toggle|animationstart|"
            "pointerover|keydown|keyup|keypress|input|change|begin|end|beforeunload|unload|resize|scroll|wheel|"
            "drag|drop|copy|paste|play|pageshow|hashchange|message")
RULES = [
    Rule("XSS-01", "Script tag", rx(r"<\s*/?\s*script\b"), "html",
         "a <script> tag would run JavaScript if the page reflected this input without encoding."),
    Rule("XSS-02", "JavaScript event handler",
         rx(rf"<[^>]*[\s/\"']on[a-z]{{3,20}}\s*=|[\"'\s/;]on({HANDLERS})\s*="), "html",
         "event-handler attributes such as onerror= or onload= execute script without a <script> tag."),
    Rule("XSS-03", "Script URI scheme", rx(r"\b(javascript|vbscript|livescript)\s*:|\bdata\s*:\s*text/html"),
         "html", "javascript:/vbscript:/data:text/html URIs run code when used in links, frames or redirects."),
    Rule("XSS-04", "HTML injection tag",
         rx(r"<\s*(iframe|frame|object|embed|svg|img|body|math|details|marquee|base|meta|link|style|form|input|"
            r"video|audio|isindex|textarea|xss)\b"), "html",
         "markup that can load content or carry handlers is being injected into the page."),
    Rule("XSS-05", "JavaScript sink or function",
         rx(r"\bdocument\s*\.\s*(cookie|domain|write|location)\b|\bwindow\s*\.\s*location\b"
            r"|\b(alert|prompt|confirm|eval)\s*\(|\bstring\s*\.\s*fromcharcode\b|\batob\s*\(|\bsrcdoc\s*="),
         "html", "functions used to prove execution (alert) or steal data (document.cookie) appear in the input."),
]
_ENCODED = rx(r"%3c|%253c|&lt;|&#x0*3c;?|&#0*60;?|\\x3c|\\u003c|%u003c")
_TAG = rx(r"<\s*[a-z/!]")
XSS_06 = Rule("XSS-06", "Encoded markup", _ENCODED, "raw",
              "angle brackets were URL-, double- or entity-encoded and decode into an HTML tag.")
ALL_RULES = RULES + [XSS_06]


def detect(target: str) -> list[tuple[Rule, str]]:
    v = view(target)
    hits = [(r, s) for r in RULES if (s := r.match(v))]
    enc = XSS_06.match(v)
    if enc and (hits or _TAG.search(v.html)):
        hits.append((XSS_06, enc))
    return hits


def scan(df, cfg=None):
    return scan_requests(df, detect, "xss", "XSS")
