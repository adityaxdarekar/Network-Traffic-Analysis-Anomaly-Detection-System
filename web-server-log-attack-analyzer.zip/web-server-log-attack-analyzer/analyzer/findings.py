"""
findings.py - shared data structures for all detectors.

Finding   one indicator: either one suspicious request (SQL injection, XSS,
          traversal) or one per-IP behaviour (brute force, reconnaissance,
          HTTP anomalies). It always carries the triggered rule IDs, the
          evidence and a plain-language explanation.
Rule      a named regular-expression rule applied to one view of a request.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

import numpy as np

from analyzer.normalizer import RequestView, snippet


@dataclass
class Finding:
    category: str                      # key of config.CATEGORY_NAMES
    ip: str
    ts: float                          # first related request (epoch seconds, UTC)
    rule_ids: list
    rule_names: list
    explanation: str
    evidence: list = field(default_factory=list)
    line_nos: list = field(default_factory=list)
    request: str = ""                  # "METHOD target" for request findings
    status: int | None = None
    kind: str = "request"              # "request" or "aggregate"
    count: int = 1                     # matching requests / events
    last_ts: float | None = None
    details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class Rule:
    rule_id: str
    name: str
    pattern: re.Pattern
    target: str                        # RequestView attribute: raw / decoded / html / sql / path
    explanation: str

    def match(self, v: RequestView) -> str | None:
        text = getattr(v, self.target)
        m = self.pattern.search(text)
        return snippet(text, m) if m else None


def rx(p: str) -> re.Pattern:
    return re.compile(p, re.I | re.S)


def confidence(n_rules: int) -> str:
    """More independent rules on one request = more confidence it is deliberate (still not proof)."""
    return "high" if n_rules >= 3 else "medium" if n_rules == 2 else "low"


def sliding_max(ts, window: float) -> tuple[int, float, float]:
    """Largest number of events inside any window of `window` seconds (two pointers over sorted times).

    Returns (count, window_start_ts, window_end_ts)."""
    t = np.sort(np.asarray(ts, dtype=float))
    if t.size == 0:
        return 0, 0.0, 0.0
    best, bs, be, j = 0, t[0], t[0], 0
    for i in range(t.size):
        while t[i] - t[j] >= window:
            j += 1
        if i - j + 1 > best:
            best, bs, be = i - j + 1, t[j], t[i]
    return int(best), float(bs), float(be)


def request_text(method: str, path: str) -> str:
    return f"{method} {path}".strip()


def scan_requests(df, detect, category: str, what: str) -> list[Finding]:
    """Run a per-request detector over a parsed log. `detect(target) -> [(Rule, evidence)]`.

    Each unique request target is analysed once; every request that matches
    becomes one Finding listing all rules it triggered (a request is never
    counted twice for the same category)."""
    out: list[Finding] = []
    if df is None or df.empty:
        return out
    cache: dict[str, list] = {}
    for r in df.itertuples(index=False):
        hits = cache.get(r.path)
        if hits is None:
            hits = cache[r.path] = detect(r.path) if r.path else []
        if not hits:
            continue
        ids = [h[0].rule_id for h in hits]
        out.append(Finding(
            category=category, ip=r.ip, ts=r.ts, rule_ids=ids, rule_names=[h[0].name for h in hits],
            explanation=f"Potential {what} ({confidence(len(ids))} confidence, {len(ids)} rule(s)): "
                        + " ".join(f"[{h[0].rule_id}] {h[0].explanation}" for h in hits),
            evidence=[f"{h[0].rule_id}: {h[1]}" for h in hits], line_nos=[r.line_no],
            request=request_text(r.method, r.path), status=r.status, last_ts=r.ts,
            details={"confidence": confidence(len(ids)), "user_agent": r.user_agent}))
    return out
