"""
normalizer.py - safe decoding of request targets before pattern matching.

Attackers hide payloads with URL encoding (%27 = '), double encoding
(%2527 -> %27 -> '), '+' for spaces, HTML entities (&lt;script&gt;) and SQL
inline comments (UNION/**/SELECT). The detectors therefore look at several
views of every request target:

  raw       the request target exactly as logged (lower-cased for matching)
  decoded   percent-decoded repeatedly (at most MAX_LAYERS times), '+' in the
            query string turned into spaces, NUL bytes removed
  html      `decoded` with HTML entities unescaped (for XSS)
  sql       `decoded` with /* ... */ comments replaced by spaces (for SQL)
  layers    how many percent-decoding passes changed the text (2+ = double encoding)

Decoding is pure string processing: nothing is executed, fetched or resolved.
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass
from functools import lru_cache
from urllib.parse import unquote

MAX_LAYERS = 4
_SQL_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_WS = re.compile(r"\s+")


def percent_decode(text: str, max_layers: int = MAX_LAYERS) -> tuple[str, int]:
    """Decode %XX repeatedly until the text stops changing. Returns (text, number of layers decoded)."""
    cur, layers = text or "", 0
    for _ in range(max_layers):
        nxt = unquote(cur, encoding="utf-8", errors="replace")
        if nxt == cur:
            break
        cur, layers = nxt, layers + 1
    return cur, layers


@dataclass(frozen=True)
class RequestView:
    raw: str
    decoded: str
    html: str
    sql: str
    layers: int
    path: str
    query: str

    @property
    def all_text(self) -> str:
        return f"{self.decoded}\n{self.html}"


@lru_cache(maxsize=100_000)
def view(target: str) -> RequestView:
    target = target or ""
    path, _, query = target.partition("?")
    dpath, l1 = percent_decode(path)
    dquery, l2 = percent_decode(query.replace("+", " "))
    decoded = (dpath + ("?" + dquery if query else "")).replace("\x00", "")
    unescaped = html.unescape(html.unescape(decoded))
    sql = _WS.sub(" ", _SQL_COMMENT.sub(" ", decoded))
    return RequestView(raw=target, decoded=decoded, html=unescaped, sql=sql, layers=max(l1, l2), path=dpath,
                       query=dquery)


def snippet(text: str, m: re.Match | None, width: int = 40) -> str:
    """A short excerpt around a regex match, for evidence."""
    if not m:
        return ""
    a, b = max(0, m.start() - 10), min(len(text), m.end() + width)
    return ("..." if a else "") + text[a:b] + ("..." if b < len(text) else "")
