#!/usr/bin/env python3
"""
analyze_log.py - terminal version of the analysis (same engine as the dashboard).

    python analyze_log.py sample_logs/access.log
    python analyze_log.py /var/log/apache2/access.log --save --pdf reports/report.pdf --csv reports/
    python analyze_log.py access.log --max-failed 5 --window 2 --high 15 --critical 40 --allow-ip 10.0.5.20
    python analyze_log.py access.log --show requests          # every suspicious request
    python analyze_log.py --incidents
    python analyze_log.py --set-status WEB-XXXXXXXXXX Investigating --note "checking with the app team"

Offline analysis only: the log file is read; nothing is blocked, sent or executed.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from analyzer.engine import run_analysis
from analyzer.log_parser import LogFormatError
from analyzer.risk_scorer import DISCLAIMER
from config import CATEGORY_NAMES, DB_PATH, DetectionConfig
from database.db_manager import DBManager
from utils.helpers import fmt_ts
from utils.report_generator import (entries_csv, incidents_csv, pdf_report, suspicious_ips_csv,
                                    suspicious_requests_csv)

try:
    from tabulate import tabulate
except ImportError:                                    # optional: plain columns without it
    def tabulate(rows, headers, **kw):
        rows = [[str(c) for c in r] for r in rows]
        w = [max([len(str(h))] + [len(r[i]) for r in rows]) for i, h in enumerate(headers)]
        line = lambda r: "  ".join(str(c).ljust(w[i]) for i, c in enumerate(r))   # noqa: E731
        return "\n".join([line(headers), line(["-" * x for x in w])] + [line(r) for r in rows])


def build_config(a) -> DetectionConfig:
    cfg = DetectionConfig()
    for opt, attr in [("max_failed", "bf_max_failed"), ("window", "bf_window_minutes"), ("high", "bf_high_threshold"),
                      ("critical", "bf_critical_threshold"), ("max_rpm", "freq_max_requests"),
                      ("max_404", "recon_max_404")]:
        if getattr(a, opt) is not None:
            setattr(cfg, attr, getattr(a, opt))
    cfg.allowlist_ips = list(a.allow_ip)
    cfg.redact_secrets = not a.no_redact
    errs = cfg.validate()
    if errs:
        raise SystemExit("invalid settings: " + "; ".join(errs))
    return cfg


def print_result(res, show: str, limit: int):
    s, p = res.stats, res.parsed
    if p.synthetic:
        print("*** SYNTHETIC LOG (generated sample, not real traffic) ***")
    print(f"File {p.file_name} [{p.source_format}]  SHA-256 {p.file_sha256[:16]}...")
    print(f"lines {s['total_lines']} | entries {s['log_entries']} | parsed {s['parsed']} ({s['parse_rate']}%) | "
          f"malformed {s['malformed']} | formats {s['formats']} | unique IPs {s['unique_ips']}")
    print(f"time range {fmt_ts(s['first_ts'])} -> {fmt_ts(s['last_ts'])}")
    for n, reason, _ in p.malformed[:10]:
        print(f"  malformed line {n}: {reason}")
    print(f"status codes: {s['status_counts']}")
    print(f"methods: {s['methods']}")
    print(f"indicators: SQLi {s['sqli_indicators']} requests, XSS {s['xss_indicators']}, traversal "
          f"{s['traversal_indicators']} | brute-force IPs {s['brute_force_ips']}, recon IPs {s['recon_ips']}, "
          f"high-frequency IPs {s['frequency_ips']}, anomaly IPs {s['anomaly_ips']}")
    print(f"\nIncidents (suspicious IPs): {s['incidents']} (critical {s['critical']}, high {s['high']}, "
          f"medium {s['medium']}, low {s['low']})")
    if res.incidents:
        print(tabulate([[i.incident_id, i.level, i.score, i.ip, i.total_requests, i.suspicious_requests,
                         ", ".join(i.categories)] for i in res.incidents],
                       headers=["Incident", "Level", "Score", "IP", "Requests", "Suspicious", "Categories"]))
        print("\nScore explanations:")
        for i in res.incidents:
            print(f"  [{i.level.upper():8s} {i.score:3d}] {i.ip:15s} {i.explanation}")
    if show in ("requests", "all"):
        sr = res.suspicious_requests()
        print(f"\nSuspicious requests ({len(sr)}):")
        if not sr.empty:
            print(tabulate([[r.time.strftime("%H:%M:%S"), r.ip, r.request[:70], r.status, r.rules]
                            for r in sr.head(limit).itertuples()], headers=["Time", "IP", "Request", "Status", "Rules"]))
    if show in ("findings", "all"):
        print("\nPer-IP findings:")
        for f in res.findings:
            if f.kind == "aggregate":
                print(f"  {CATEGORY_NAMES[f.category]:35s} {f.ip:15s} {', '.join(f.rule_ids)}\n      {f.explanation}")
    print("\n" + DISCLAIMER)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Apache access log attack analyzer (offline, defensive)")
    ap.add_argument("log", nargs="?")
    ap.add_argument("--max-failed", type=int, help="failed attempts in the window (default 10)")
    ap.add_argument("--window", type=float, help="brute-force window in minutes (default 5)")
    ap.add_argument("--high", type=int, help="high-risk attempts (default 20)")
    ap.add_argument("--critical", type=int, help="critical-risk attempts (default 50)")
    ap.add_argument("--max-rpm", type=int, help="requests per 60 s from one IP (default 100)")
    ap.add_argument("--max-404", type=int, help="404 responses from one IP (default 20)")
    ap.add_argument("--allow-ip", nargs="*", default=[], help="IPs never reported (e.g. your monitoring host)")
    ap.add_argument("--no-redact", action="store_true", help="show password/token query values")
    ap.add_argument("--show", choices=["summary", "requests", "findings", "all"], default="findings")
    ap.add_argument("--limit", type=int, default=40)
    ap.add_argument("--save", action="store_true", help="store incidents in SQLite")
    ap.add_argument("--db", default=str(DB_PATH))
    ap.add_argument("--pdf")
    ap.add_argument("--csv", help="directory for the 4 CSV exports")
    ap.add_argument("--incidents", action="store_true", help="list stored incidents")
    ap.add_argument("--set-status", nargs=2, metavar=("INCIDENT_ID", "STATUS"))
    ap.add_argument("--note", default="")
    ap.add_argument("--analyst", default="analyst")
    a = ap.parse_args(argv)

    if a.set_status or a.incidents:
        db = DBManager(a.db)
        try:
            if a.set_status:
                iid, status = a.set_status
                try:
                    ok = db.update_status(iid, status.capitalize(), a.note, a.analyst)
                except ValueError as exc:
                    print(f"error: {exc}", file=sys.stderr)
                    return 2
                print(f"{iid} -> {status.capitalize()}" if ok else f"incident {iid} not found")
                return 0 if ok else 1
            rows = db.list_incidents()
            print(tabulate([[r["incident_id"], r["risk_level"], r["risk_score"], r["ip"], ", ".join(r["categories"]),
                             r["status"], (r["analyst_notes"] or "")[:40], r["file_name"]] for r in rows],
                           headers=["Incident", "Level", "Score", "IP", "Categories", "Status", "Notes", "Log"]))
            return 0
        finally:
            db.close()
    if not a.log:
        ap.error("give a log file, --incidents or --set-status")
    try:
        res = run_analysis(a.log, build_config(a))
    except (LogFormatError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print_result(res, a.show, a.limit)
    merged = [i.to_dict() for i in res.incidents]
    if a.save or a.pdf:
        db = DBManager(a.db)
        try:
            db.save_analysis(res)
            merged = db.merged(res)
        finally:
            db.close()
        print(f"\nSaved {len(res.incidents)} incidents to {a.db}")
    if a.pdf:
        Path(a.pdf).parent.mkdir(parents=True, exist_ok=True)
        Path(a.pdf).write_bytes(pdf_report(res, merged))
        print(f"PDF report: {a.pdf}")
    if a.csv:
        d = Path(a.csv)
        d.mkdir(parents=True, exist_ok=True)
        stem = Path(res.file_name).stem
        for name, data in [("entries", entries_csv(res)), ("suspicious_requests", suspicious_requests_csv(res)),
                           ("suspicious_ips", suspicious_ips_csv(res)), ("incidents", incidents_csv(merged))]:
            (d / f"{stem}_{name}.csv").write_bytes(data)
        print(f"CSV exports written to {d}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
