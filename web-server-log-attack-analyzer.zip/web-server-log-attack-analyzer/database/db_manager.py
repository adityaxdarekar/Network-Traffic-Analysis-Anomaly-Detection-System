"""
db_manager.py - SQLite storage for analyses, incidents and analyst notes.

Tables
  analyses        one row per analysed log (file name, SHA-256, counts, settings, synthetic flag)
  incidents       one row per suspicious source IP per log file. Detection fields are refreshed when
                  the same log is analysed again; the analyst's status and notes are NEVER overwritten
  incident_notes  every status change / note with time and analyst name (history)

Incident ID = "WEB-" + SHA-1(log SHA-256 | IP)[:10], so analysing the same log
after a restart maps to the same stored incident. All SQL is parameterised.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

STATUSES = ("Open", "Investigating", "Resolved")
SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
  id INTEGER PRIMARY KEY AUTOINCREMENT, analysed_at TEXT NOT NULL, file_name TEXT, file_sha256 TEXT,
  synthetic INTEGER, total_lines INTEGER, parsed INTEGER, malformed INTEGER, unique_ips INTEGER, incidents INTEGER,
  settings TEXT);
CREATE TABLE IF NOT EXISTS incidents (
  incident_id TEXT PRIMARY KEY, ip TEXT NOT NULL, file_name TEXT, file_sha256 TEXT, synthetic INTEGER,
  risk_score INTEGER, risk_level TEXT, categories TEXT, rules TEXT, total_requests INTEGER,
  suspicious_requests INTEGER, failed_responses INTEGER, first_seen REAL, last_seen REAL, details TEXT,
  status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Investigating','Resolved')),
  analyst_notes TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, times_detected INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS ix_inc_ip ON incidents(ip);
CREATE TABLE IF NOT EXISTS incident_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
  noted_at TEXT NOT NULL, analyst TEXT, status TEXT, note TEXT);
"""


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _clean(s: str, n: int) -> str:
    return "".join(ch for ch in (s or "") if ch.isprintable() or ch in "\n\t").strip()[:n]


class DBManager:
    def __init__(self, path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    @contextmanager
    def tx(self):
        with self._lock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def q(self, sql, args=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def close(self):
        with self._lock:
            self.conn.close()

    def save_analysis(self, res) -> int:
        p, s, t = res.parsed, res.stats, now()
        rows = [{"iid": i.incident_id, "ip": i.ip, "file": p.file_name, "sha": p.file_sha256, "syn": int(p.synthetic),
                 "score": i.score, "level": i.level, "cats": json.dumps(i.categories), "rules": json.dumps(i.rules),
                 "tr": i.total_requests, "sr": i.suspicious_requests, "fr": i.failed_responses, "fs": i.first_seen,
                 "ls": i.last_seen, "details": json.dumps(i.to_dict(), default=str), "now": t} for i in res.incidents]
        with self.tx() as c:
            aid = c.execute("INSERT INTO analyses(analysed_at, file_name, file_sha256, synthetic, total_lines, parsed, "
                            "malformed, unique_ips, incidents, settings) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (t, p.file_name, p.file_sha256, int(p.synthetic), s["total_lines"], s["parsed"],
                             s["malformed"], s["unique_ips"], s["incidents"], json.dumps(res.config))).lastrowid
            c.executemany("""
              INSERT INTO incidents(incident_id, ip, file_name, file_sha256, synthetic, risk_score, risk_level, categories,
                rules, total_requests, suspicious_requests, failed_responses, first_seen, last_seen, details,
                created_at, updated_at)
              VALUES (:iid,:ip,:file,:sha,:syn,:score,:level,:cats,:rules,:tr,:sr,:fr,:fs,:ls,:details,:now,:now)
              ON CONFLICT(incident_id) DO UPDATE SET risk_score=excluded.risk_score, risk_level=excluded.risk_level,
                categories=excluded.categories, rules=excluded.rules, total_requests=excluded.total_requests,
                suspicious_requests=excluded.suspicious_requests, failed_responses=excluded.failed_responses,
                details=excluded.details, updated_at=excluded.updated_at,
                times_detected=incidents.times_detected + 1""", rows)
        return aid

    def _row(self, r):
        r["categories"] = json.loads(r["categories"] or "[]")
        r["rules"] = json.loads(r["rules"] or "[]")
        r["details"] = json.loads(r["details"] or "{}")
        return r

    def list_incidents(self, levels=None, ip="", statuses=None, sha256=None, category=None) -> list:
        sql, a = "SELECT * FROM incidents WHERE 1=1", []
        if levels:
            sql += f" AND risk_level IN ({','.join('?' * len(levels))})"
            a += list(levels)
        if statuses:
            sql += f" AND status IN ({','.join('?' * len(statuses))})"
            a += list(statuses)
        if ip:
            sql += " AND ip LIKE ?"
            a.append(f"%{ip.strip()}%")
        if sha256:
            sql += " AND file_sha256 = ?"
            a.append(sha256)
        if category:
            sql += " AND categories LIKE ?"
            a.append(f'%"{category}"%')
        return [self._row(r) for r in self.q(sql + " ORDER BY risk_score DESC, first_seen", a)]

    def get_incident(self, iid):
        r = self.q("SELECT * FROM incidents WHERE incident_id=?", (iid,))
        if not r:
            return None
        d = self._row(r[0])
        d["notes"] = self.q("SELECT noted_at, analyst, status, note FROM incident_notes WHERE incident_id=? ORDER BY id",
                            (iid,))
        return d

    def update_status(self, iid, status, note="", analyst="analyst") -> bool:
        if status not in STATUSES:
            raise ValueError(f"status must be one of {STATUSES}")
        note, analyst, t = _clean(note, 2000), _clean(analyst, 60) or "analyst", now()
        with self.tx() as c:
            if c.execute("UPDATE incidents SET status=?, updated_at=?, analyst_notes=CASE WHEN ?<>'' THEN ? ELSE "
                         "analyst_notes END WHERE incident_id=?", (status, t, note, note, iid)).rowcount != 1:
                return False
            c.execute("INSERT INTO incident_notes(incident_id, noted_at, analyst, status, note) VALUES (?,?,?,?,?)",
                      (iid, t, analyst, status, note))
        return True

    def merged(self, res) -> list[dict]:
        """Incidents of an analysis as dicts with the stored analyst status and notes attached."""
        stored = {r["incident_id"]: r for r in self.list_incidents(sha256=res.parsed.file_sha256)}
        out = []
        for i in res.incidents:
            d = i.to_dict()
            s = stored.get(i.incident_id, {})
            d["status"], d["analyst_notes"] = s.get("status", "Open"), s.get("analyst_notes", "")
            out.append(d)
        return out

    def status_counts(self) -> dict:
        out = {s: 0 for s in STATUSES}
        for r in self.q("SELECT status, COUNT(*) n FROM incidents GROUP BY status"):
            out[r["status"]] = r["n"]
        return out

    def analyses(self, limit=50):
        return self.q("SELECT id, analysed_at, file_name, synthetic, total_lines, parsed, malformed, unique_ips, "
                      "incidents FROM analyses ORDER BY id DESC LIMIT ?", (limit,))

    def clear(self):
        with self.tx() as c:
            c.execute("DELETE FROM incident_notes")
            c.execute("DELETE FROM incidents")
            c.execute("DELETE FROM analyses")
