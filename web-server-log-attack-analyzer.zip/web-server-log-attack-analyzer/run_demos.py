#!/usr/bin/env python3
"""
run_demos.py - the nine practical demonstrations, run against the SYNTHETIC logs in sample_logs/.

    python run_demos.py                       # writes the PDF/CSV of Demo 9 to sample_output/
    python run_demos.py --db /tmp/demo.db --out /tmp/demo_out

Each demo prints what the dashboard shows on the matching page and checks the
expected result (PASS/FAIL). Nothing is sent anywhere; no IP is blocked.
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

import pandas as pd

from analyzer.engine import analyze_parsed, run_analysis
from analyzer.log_parser import parse_file
from analyzer.normalizer import view
from config import BASE_DIR, SAMPLE_DIR, DetectionConfig
from database.db_manager import DBManager
from utils.helpers import fmt_ts
from utils.report_generator import incidents_csv, pdf_report, suspicious_ips_csv, suspicious_requests_csv

RESULTS = {}


def banner(n, title):
    print("\n" + "=" * 96 + f"\n  Demo {n}: {title}\n" + "=" * 96)


def check(n, cond, what):
    RESULTS[n] = RESULTS.get(n, True) and bool(cond)
    print(f"  [{'PASS' if cond else 'FAIL'}] {what}")


def show_requests(res, cat, limit=12):
    for f in res.by_category(cat)[:limit]:
        print(f"  {pd.to_datetime(f.ts, unit='s', utc=True):%H:%M:%S} {f.ip:15s} -> {f.status}  {f.request[:78]}")
        print(f"      rules {', '.join(f.rule_ids)} ({f.details['confidence']} confidence) | decoded: "
              f"{view(f.request.split(' ', 1)[1]).html[:90]}")


def demo1():
    banner(1, "Apache log collection and formats")
    print("  Apache writes one line per request to:")
    print("    Ubuntu/Debian/Kali : /var/log/apache2/access.log   (rotated: access.log.1, access.log.2.gz ...)")
    print("    RHEL/CentOS/Fedora : /var/log/httpd/access_log")
    print("  Formats (LogFormat in apache2.conf):")
    print('    common   "%h %l %u %t \\"%r\\" %>s %b"')
    print('    combined "%h %l %u %t \\"%r\\" %>s %b \\"%{Referer}i\\" \\"%{User-agent}i\\""')
    for name in ["access.log", "demo_common_format.log", "access_sample.csv"]:
        p = parse_file(SAMPLE_DIR / name)
        s = p.stats()
        print(f"\n  {name}: {s['total_lines']} lines -> {s['parsed']} parsed ({s['parse_rate']}%), {s['malformed']} "
              f"malformed, formats {s['formats']}, synthetic={p.synthetic}")
        for n, reason, raw in p.malformed:
            print(f"    line {n}: {reason:42s} | {raw[:60]}")
        if name == "demo_common_format.log":
            r = p.entries.iloc[0]
            print(f"    time zone normalised: '{r['raw'].split('[')[1].split(']')[0]}' -> {r['timestamp']} "
                  f"(UTC); referrer/User-Agent are empty in CLF")
            check(1, s["formats"] == {"common": s["parsed"]} and r["timestamp"].hour == 9 and "-0500" in r["raw"], "CLF parsed, -0500 -> UTC")
        if name == "access.log":
            check(1, s["malformed"] == 5 and s["parsed"] == 882, "882 entries parsed, 5 malformed kept for review")
            print("    example entry:", {k: (int(v) if k in ("status", "size") else v)
                                      for k, v in p.entries.iloc[5][["ip", "method", "path", "status", "size"]].items()})
        if name == "access_sample.csv":
            check(1, s["malformed"] == 0 and s["parsed"] > 200, "CSV with standard columns parsed")


def demo2():
    banner(2, "Normal traffic analysis (demo_normal.log)")
    res = run_analysis(SAMPLE_DIR / "demo_normal.log")
    s = res.stats
    print(f"  {s['parsed']} requests from {s['unique_ips']} IPs, {fmt_ts(s['first_ts'])} -> {fmt_ts(s['last_ts'])}")
    print(f"  methods: {s['methods']}")
    print(f"  status codes: {s['status_counts']}")
    top = res.df["path"].map(lambda p: p.split("?")[0]).value_counts().head(6)
    print("  most requested URLs: " + ", ".join(f"{k} ({v})" for k, v in top.items()))
    traps = ["/search?q=union+station", "/search?q=how+to+select+a+drop+table+lamp", "/search?q=O%27Brien+jacket",
             "/blog/select-the-right-database"]
    print("  benign requests containing SQL words or quotes (must NOT be flagged): " + ", ".join(traps))
    check(2, s["incidents"] == 0, "no incidents on normal traffic (one mistyped password and a 408 are normal)")


def demo3():
    banner(3, "SQL injection detection (demo_sqli.log)")
    res = run_analysis(SAMPLE_DIR / "demo_sqli.log")
    show_requests(res, "sql_injection")
    inc = res.incidents[0]
    print(f"  -> {inc.ip}: {inc.level} {inc.score} = {inc.explanation}")
    check(3, len(res.by_category("sql_injection")) == 14 and inc.ip == "198.51.100.23",
          "14 of 16 sqlmap requests flagged ('id=1' and the lone quote 'id=1%27' are not)")


def demo4():
    banner(4, "XSS detection (demo_xss.log)")
    res = run_analysis(SAMPLE_DIR / "demo_xss.log")
    show_requests(res, "xss")
    print("  Note: a 200 response means the request was accepted - not that the page is vulnerable.")
    check(4, len(res.by_category("xss")) == 10 and res.incidents[0].level == "Medium", "10 XSS requests, Medium risk")


def demo5():
    banner(5, "Directory traversal detection (demo_traversal.log)")
    res = run_analysis(SAMPLE_DIR / "demo_traversal.log")
    show_requests(res, "traversal")
    ok200 = [f for f in res.by_category("traversal") if f.status == 200]
    for f in ok200:
        print(f"  !! answered 200 OK: {f.request} - check what was served (size in the log)")
    ids = {r for f in res.by_category("traversal") for r in f.rule_ids}
    check(5, len(res.by_category("traversal")) == 12 and {"TRV-02", "TRV-03"} <= ids,
          "12 traversal requests incl. encoded (TRV-02) and double/overlong-encoded (TRV-03)")


def demo6():
    banner(6, "Brute-force detection (demo_bruteforce.log)")
    res = run_analysis(SAMPLE_DIR / "demo_bruteforce.log")
    for f in res.by_category("brute_force"):
        d = f.details
        print(f"  {f.ip}: {', '.join(f.rule_ids)} | peak {d['peak_in_window']} in window "
              f"{fmt_ts(d['window_start'])[11:19]} - {fmt_ts(d['window_end'])[11:19]} | intensity {d['intensity']}")
        print(f"     per minute: {d['per_minute']}")
        print(f"     {f.explanation}")
    print("  Sliding window: the two-pointer scan finds the busiest 5-minute stretch, wherever it starts.")
    cfg = DetectionConfig(bf_max_failed=30, bf_high_threshold=40, bf_critical_threshold=60)
    res2 = analyze_parsed(res.parsed, cfg)
    print(f"  With max failed=30, high=40, critical=60: "
          f"{[(i.ip, i.level, i.score) for i in res2.incidents if 'brute_force' in i.categories]}")
    lv = {i.ip: i.level for i in res.incidents}
    check(6, lv.get("203.0.113.10") == "High" and lv.get("198.51.100.77") == "Medium" and "192.0.2.15" not in lv,
          "203.0.113.10 High (incl. success after failures), 198.51.100.77 Medium, single typo not flagged")


def demo7():
    banner(7, "Reconnaissance detection (demo_recon.log)")
    res = run_analysis(SAMPLE_DIR / "demo_recon.log")
    for f in res.by_category("reconnaissance"):
        print(f"  {f.ip}: {', '.join(f.rule_ids)}\n     {f.explanation}")
        print("     sample probes: " + "; ".join(f.evidence[:8]))
    an = res.by_category("http_anomaly")
    for f in an:
        print(f"  {f.ip}: {f.explanation}")
    check(7, [i.ip for i in res.incidents] == ["203.0.113.99"], "only the scanner IP is reported (Googlebot's "
                                                                 "robots.txt is context, not an alert)")


def demo8(db_path):
    banner(8, "Incident investigation and persistence")
    res = run_analysis(SAMPLE_DIR / "access.log")
    db = DBManager(db_path)
    db.save_analysis(res)
    inc = next(i for i in res.incidents if i.level == "Critical")
    note = "Demo 8: Nikto scan with SQLi/XSS/traversal payloads; checking app logs for 200 responses"
    db.update_status(inc.incident_id, "Investigating", note, "student")
    print(f"  {inc.incident_id} ({inc.ip}, {inc.level} {inc.score}) set to Investigating; database closed "
          f"(simulated restart)")
    db.close()
    db = DBManager(db_path)
    db.save_analysis(run_analysis(SAMPLE_DIR / "access.log"))
    got = db.get_incident(inc.incident_id)
    print(f"  after restart + re-analysis: status={got['status']}, note='{got['analyst_notes'][:60]}...', "
          f"detected {got['times_detected']}x, history entries {len(got['notes'])}")
    check(8, got["status"] == "Investigating" and got["analyst_notes"] == note, "status and note persisted")
    db.close()


def demo9(db_path, out: Path):
    banner(9, "Report generation")
    res = run_analysis(SAMPLE_DIR / "access.log")
    db = DBManager(db_path)
    merged = db.merged(res)
    db.close()
    out.mkdir(parents=True, exist_ok=True)
    pdf = pdf_report(res, merged)
    (out / "security_investigation_report.pdf").write_bytes(pdf)
    (out / "suspicious_requests.csv").write_bytes(suspicious_requests_csv(res))
    (out / "suspicious_ips.csv").write_bytes(suspicious_ips_csv(res))
    (out / "incidents.csv").write_bytes(incidents_csv(merged))
    n_req = len(res.suspicious_requests())
    print(f"  {out / 'security_investigation_report.pdf'} ({len(pdf):,} bytes)")
    print(f"  suspicious_requests.csv ({n_req} rows), suspicious_ips.csv ({len(res.incidents)} rows), incidents.csv")
    print("  Findings summary:")
    for i in res.incidents[:8]:
        print(f"    [{i.level.upper():8s} {i.score:3d}] {i.ip:15s} {', '.join(i.categories)}")
    check(9, pdf[:4] == b"%PDF" and n_req > 0, "PDF and CSV files created from the analysis")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=None, help="SQLite file for Demos 8-9 (default: a temporary file)")
    ap.add_argument("--out", default=str(BASE_DIR / "sample_output"))
    a = ap.parse_args(argv)
    db_path = a.db or str(Path(tempfile.mkdtemp()) / "demo_incidents.db")
    print("All demonstrations use SYNTHETIC logs from sample_logs/ (generated text, no real traffic).")
    for fn in (demo1, demo2, demo3, demo4, demo5, demo6, demo7):
        fn()
    demo8(db_path)
    demo9(db_path, Path(a.out))
    print("\n" + "=" * 96)
    for n in sorted(RESULTS):
        print(f"  Demo {n}: {'PASS' if RESULTS[n] else 'FAIL'}")
    return 0 if all(RESULTS.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
