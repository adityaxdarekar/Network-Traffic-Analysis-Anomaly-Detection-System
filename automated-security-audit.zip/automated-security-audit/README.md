# Automated Security Audit Tool

**Bash · Linux (Kali Linux / Ubuntu) · systemctl · ss · find · grep · awk · stat · dpkg/apt · ufw · journalctl**

This is a menu-driven Bash tool that checks a Linux machine for common security misconfigurations in **9 audit modules**. It:

- rates every finding CRITICAL, HIGH, MEDIUM, LOW or INFO;
- marks each finding as **CONFIRMED** (observed directly) or **POTENTIAL** (a risk indicator that needs a human decision);
- gives a recommendation for every finding;
- calculates a documented **security score out of 100**;
- saves timestamped **TXT and HTML** reports.

> **Read-only by design.** The tool never changes configuration files, services, firewall rules, packages or permissions, and it never deletes system files. Every remediation is printed as a *recommendation* for a human to apply.
>
> The only things it writes are:
> - its own reports in `reports/`;
> - its own log in `logs/`;
> - a private temporary directory that it removes on exit.

---

## 1. Architecture

```
                    ┌──────────────────────────── main.sh ────────────────────────────┐
  user ── menu / ──►│ argument parsing · banner · root check · safe config loading      │
          options   │ run_module N · run_full · view previous reports · logging          │
                    └──────────────┬───────────────────────────────────┬───────────────┘
                                   │ sources                           │ sources
              ┌────────────────────▼───────────┐          ┌────────────▼──────────────┐
              │ lib/common.sh                  │          │ lib/report.sh              │
              │ colours, log_msg, have_cmd,    │          │ calc_score (documented),   │
              │ is_root, can_read, mktemp/trap,│          │ print_summary,             │
              │ add_finding (registry),        │          │ write_txt_report,          │
              │ skip_check, html_escape        │          │ write_html_report          │
              └────────────────────┬───────────┘          └────────────┬──────────────┘
                                   │ used by                           │ reads registry
   modules/  1 system_info  2 user_audit  3 permission_audit  4 network_audit  5 firewall_audit
             6 service_audit  7 ssh_audit  8 update_audit  9 login_audit
                                   │ read-only commands and files
   /etc/os-release /etc/passwd /etc/shadow* /etc/sudoers* · find · ss or /proc/net · ufw*/nft*/iptables*
   systemctl · sshd_config (+Include) or sshd -T* · apt list --upgradable · auth.log* / journalctl
                                                                        (* needs root)
```

**How a run works:**
1. Every module calls `add_finding SEVERITY TYPE title detail recommendation`, which stores the finding in shared arrays.
2. Plain output also goes to a per-module section file in a private temporary directory.
3. At the end, `lib/report.sh` computes the score and writes both reports from the same data, so the terminal, the TXT file and the HTML file always agree.

## 2. Folder structure

```
automated-security-audit/
├── main.sh                    entry point: menu, options, orchestration
├── install.sh                 dependency check, permissions, optional apt install
├── requirements.txt           system packages (no Python/pip needed)
├── README.md                  this file
├── PROJECT_STATUS.md          what was tested, and how
├── lib/
│   ├── common.sh              helpers + findings registry
│   └── report.sh              scoring + TXT/HTML reports
├── modules/
│   ├── system_info.sh         Module 1
│   ├── user_audit.sh          Module 2
│   ├── permission_audit.sh    Module 3
│   ├── network_audit.sh       Module 4
│   ├── firewall_audit.sh      Module 5
│   ├── service_audit.sh       Module 6
│   ├── ssh_audit.sh           Module 7
│   ├── update_audit.sh        Module 8
│   └── login_audit.sh         Module 9
├── config/audit.conf          optional settings (scan folders, thresholds, service lists)
├── demo/
│   ├── setup_demo.sh          creates SAFE, removable test cases (/srv/audit-demo)
│   ├── cleanup_demo.sh        removes exactly what setup created
│   └── insecure_sshd_config   deliberately weak SSH config, only READ via SSHD_CONFIG=
├── tests/
│   ├── run_tests.sh           170 automated tests with stub commands (no root needed)
│   └── fixtures/              fake passwd/shadow/sudoers, sshd_config, auth logs, /proc/net …
├── reports/                   saved reports (mode 600, created by the tool)
├── logs/                      audit_YYYY-MM-DD.log
├── assets/                    (reserved for report assets; the HTML report is self-contained)
├── docs/                      DEMO_GUIDE.md, PROJECT_REPORT.md, VIVA.md
├── sample_output/             real terminal output, TXT/HTML sample reports, test results
└── screenshots/               terminal and HTML report screenshots
```

## 3. Installation (Kali Linux / Ubuntu)

```bash
# 1. copy or unzip the project, then:
cd automated-security-audit
chmod +x install.sh
./install.sh                    # checks dependencies, sets permissions (no root needed)
./install.sh --install-deps     # optional: also installs missing packages with apt (asks for sudo)

# 2. optional: install recommended packages yourself
sudo apt update
sudo apt install -y iproute2 ufw procps login     # Kali / Debian 13: lastlog2 instead of login

# 3. run it
chmod +x main.sh
sudo ./main.sh                  # interactive menu
```

`install.sh` does the following:
- makes the scripts executable;
- creates `reports/` and `logs/` with mode 700, because reports contain sensitive system details;
- removes group and world write access from `config/audit.conf`.

`main.sh` refuses to load a config file that others could write to, because the config is sourced by a root process. Accepted owners are root, the current user, and the user who ran `sudo`.

Installing `ufw` with `--install-deps` **does not enable it**.

## 4. Running

| Command | What it does |
|---|---|
| `sudo ./main.sh` | Interactive menu (options 1–12) |
| `sudo ./main.sh --full` | All 9 modules, score, and TXT + HTML reports in `reports/` |
| `sudo ./main.sh --module 7` | One module (SSH) |
| `sudo ./main.sh -m 3,4 -r` | Modules 3 and 4, and save reports |
| `./main.sh --list-reports` | List saved reports with their scores |
| `sudo ./main.sh --full --min-score 70` | Exit status 3 if the score is below 70 (for scripts or cron) |
| `./main.sh --full --no-color -o /tmp/r` | Plain output, reports in another folder |
| `./main.sh --help` | All options |

**Menu:**

```
 1) System Information Audit          7) SSH Security Audit
 2) User Account Security Audit       8) System Update Audit
 3) File Permission Audit             9) Login & Authentication Audit
 4) Network Security Audit           10) Complete Security Audit (all + reports)
 5) Firewall Audit                   11) View Previous Reports
 6) Running Services Audit           12) Exit
```

After a single module, the menu asks whether to save a report. Option 10 always saves.

**Opening the HTML report.** When started with sudo, report files are handed back to your user, so open them **without** sudo:

```bash
xdg-open reports/security_audit_2026-11-08_220000.html      # or: firefox reports/...html
```

### What works without root

| Works as a normal user | Needs root (skipped and listed otherwise) |
|---|---|
| System information, logged-in users | `/etc/shadow`: empty passwords, password ageing |
| UID 0 and duplicate UIDs, login shells, sudo group members | sudoers rules (NOPASSWD, `!authenticate`) |
| World-writable and SUID files in readable folders | UFW status/rules, nftables/iptables |
| Listening ports (process names for your own processes only) | Process names of other users' sockets |
| SSH config parsing (`sshd_config` is world-readable) | `sshd -T` effective configuration |
| Pending updates from the apt cache | `auth.log` (root or the `adm` group) / the system journal |
| Running/enabled services | |

A non-root run shows `Score: 92/100 (Excellent - limited audit, 5 check(s) skipped)`. **Skipped checks are not counted**, so a limited score is not comparable with a full root audit.

## 5. How each module works

### Module 1: System Information
- Reads `/etc/os-release` (falling back to `lsb_release`), `uname -r` and `uname -m`, the hostname, `uptime -p` (or `/proc/uptime`), `who`, and `systemd-detect-virt`.
- **LOW confirmed:** `/var/run/reboot-required` exists (patched libraries or kernel are not yet in use).
- **INFO:** the distribution is not Ubuntu, Kali or Debian.

### Module 2: User Accounts

| Check | Result |
|---|---|
| A UID 0 account other than `root` | **CRITICAL** |
| Duplicate UIDs | **HIGH** |
| An empty password field in `/etc/shadow` | **CRITICAL** (root only) |
| System accounts (UID < `UID_MIN` from `/etc/login.defs`) with an interactive shell | LOW potential |
| Never-expiring passwords | LOW potential |
| No login for more than `INACTIVE_DAYS` (90), from `lastlog`; skipped when `lastlog` is not available rather than guessed | LOW potential |
| sudoers with `!authenticate` | **CRITICAL** |
| `NOPASSWD: ALL` | **HIGH** |
| NOPASSWD for specific commands | MEDIUM potential |
| A sudoers file writable by group or others | **HIGH** |
| More than 3 members of sudo/admin/wheel | LOW potential |

### Module 3: File Permissions

**World-writable files and directories.**
- `find -xdev` over *selected* folders (`/etc /usr /opt /srv /var/www /home /root /boot`), pruning `/proc /sys /dev /run /snap` and container storage.
- Only regular files and directories are checked; symlinks always show 777 and are ignored.
- Results:
  - in a system folder → **HIGH**;
  - elsewhere → MEDIUM;
  - a world-writable directory without the sticky bit → MEDIUM. `/tmp`-style folders with the sticky bit are fine.

**SUID/SGID programs.** These are **not reported just for being SUID**. Each is classified:

| Classification | Result |
|---|---|
| Standard programs (passwd, sudo, mount, ping …) | Counted, no finding |
| GTFOBins escalation programs (find, vim, bash, python, nmap …) | **HIGH potential** |
| SUID in `/home`, `/tmp`, `/var/tmp`, `/srv`, `/root` | **HIGH potential** |
| A world-writable SUID program | **CRITICAL** |
| Anything else | LOW potential: "check it belongs to a package (`dpkg -S`)" |

**Sensitive files.**
- Each file has a maximum allowed mode and an owner: `/etc/passwd` 644, `/etc/shadow` 640, `/etc/gshadow` 640, `/etc/sudoers` 440, `sshd_config` 644, `/etc/crontab`, `/root` 700, `grub.cfg`.
- Results:
  - any extra bit → MEDIUM;
  - group-writable → HIGH;
  - world-writable, or a secret file that is world-readable → **CRITICAL**;
  - wrong owner → HIGH.

**Home directories.** Writable by others → HIGH; readable by others → LOW potential.

### Module 4: Network

**Reading the sockets.**
- Uses `ss -tulnp`, or decodes `/proc/net/tcp`, `tcp6`, `udp` and `udp6` when `ss` is missing:
  - IPv4 addresses are hex and little-endian;
  - LISTEN is state 0A for TCP; UDP sockets are state 07.
- As root, process names are matched through socket inodes in `/proc/*/fd`.

**Scope.** Each socket is labelled ALL interfaces (0.0.0.0, ::, \*), localhost, or a specific address.

**Findings.** A listening port is not a vulnerability. Only well-known risky services that are reachable on **all** interfaces become POTENTIAL findings:

| Service | Result |
|---|---|
| Docker API 2375 | CRITICAL |
| Telnet, FTP, TFTP, r-services, Redis, Memcached, MongoDB, Elasticsearch | HIGH |
| SMB/NFS/RPC, databases, RDP/VNC, SNMP | MEDIUM |
| Development ports | LOW |

Also:
- more than 10 services on all interfaces → LOW;
- `ip_forward=1` → LOW;
- interfaces and IP addresses come from `ip -br addr`, or `/sys/class/net` plus `hostname -I`.

### Module 5: Firewall
- **UFW installed?** As root, `ufw status verbose` is read:
  - inactive → checks for other firewalls;
  - default incoming ALLOW → **HIGH**;
  - risky ports allowed from Anywhere → MEDIUM potential;
  - logging off → LOW.
- **Without UFW, or with UFW inactive,** nftables/iptables are checked so that another firewall isn't missed:
  - rules present → INFO;
  - none → one **HIGH** "No host firewall is active".
- **Without root,** `/etc/ufw/ufw.conf ENABLED=no` → HIGH; otherwise MEDIUM potential "could not be verified".

### Module 6: Services
- **Listing:** `systemctl list-units --state=running`, `list-unit-files --state=enabled` and `--state=failed`. Each service is marked "[enabled at boot]".
- **Lists:** configurable in `config/audit.conf`. Matching only produces *recommendations*; the audit never disables anything.

| Service type | Examples | Result |
|---|---|---|
| Legacy/insecure | telnet, inetd/xinetd, r-services, tftp | HIGH potential |
| FTP, VNC, snmpd | | MEDIUM potential |
| Often unnecessary | avahi, cups, bluetooth, rpcbind, smbd … | LOW potential |
| Server software | apache2, mysql … | INFO |
| Failed units | | LOW |

- **Without systemd** (containers), the check is skipped and the process list is shown.

### Module 7: SSH

**Installed and running?** Uses `sshd`, `dpkg -s openssh-server`, `systemctl is-active ssh|sshd` or `pgrep`.

**Effective settings.**
- As root, `sshd -T` gives the exact effective configuration.
- Otherwise `sshd_config` is parsed **the way sshd does it**:
  - `Include` files are read where they appear, so Ubuntu's `sshd_config.d/*.conf` comes first;
  - the **first** value of a keyword wins;
  - global parsing stops at the first `Match` block.
- Unset keywords get OpenSSH defaults, marked "(default)".

| Setting | Result |
|---|---|
| `PermitEmptyPasswords yes` | **CRITICAL** |
| `PermitRootLogin yes` together with password authentication | **CRITICAL** |
| `PermitRootLogin yes` with keys only | **HIGH** |
| `PasswordAuthentication yes` | MEDIUM potential |
| `PubkeyAuthentication no` | MEDIUM |
| `PermitUserEnvironment`, `HostbasedAuthentication`, `IgnoreRhosts no`, weak ciphers/MACs/KEX | MEDIUM |
| `X11Forwarding yes`, `MaxAuthTries > 4`, `LogLevel QUIET` | LOW |
| No AllowUsers/AllowGroups | INFO |

When sshd is **not running**, its findings are POTENTIAL: they apply once it starts. The configuration is never modified.

### Module 8: Updates
- **Pending upgrades:** `apt list --upgradable` reads the **existing** cache. The tool never runs `apt update` or `upgrade`.

| Check | Result |
|---|---|
| Package lists older than 7 days | LOW |
| Package lists older than 30 days | MEDIUM (results are stale) |
| Upgrades from `-security` (Ubuntu) | **HIGH** |
| Security-sensitive packages (kernel, OpenSSL, OpenSSH, sudo, libc, systemd, polkit …) upgradable | **HIGH** |
| Other upgrades | LOW (MEDIUM if more than 50) |
| `unattended-upgrades` missing (Ubuntu) | LOW potential |

- **Kali (rolling)** has no security pocket, so all upgrades are reported together.
- Also shows the last apt transaction. Uses `dnf check-update --cacheonly` as a fallback.

### Module 9: Login and Authentication

**Sources.**
- `/var/log/auth.log` (+ `.1`) on Ubuntu/Kali with rsyslog, `/var/log/secure`, or `journalctl -t sshd -t sudo -t su -t login …`. Kali 2023+ uses the journal only.
- Both `Nov  8 21:00:01` and ISO `2026-11-08T21:00:01.123+00:00` timestamps are understood.

**Events counted (without double counting).**
- **sshd:** only `Failed password …`; the matching PAM line is ignored. `Invalid user …` and `Accepted …` are also recorded.
- **sudo:** only `N incorrect password attempts`.
- **su and local logins:** `FAILED SU`, `FAILED LOGIN`, and display-manager PAM failures.

**Per source IP:** failures, distinct user names, and first/last timestamps.

| Pattern | Result |
|---|---|
| 20 or more failures from one IP | **HIGH** (brute force) |
| 5 or more failures from one IP | MEDIUM potential |
| 3 or more non-existent user names from one IP | MEDIUM potential (guessing) |
| **Successful login from an IP after 5 or more failures** | **CRITICAL potential**: verify immediately |
| Attempts against root | MEDIUM potential |
| Direct root logins | MEDIUM |
| 3 or more sudo or su failures | LOW |

## 6. Severity and finding types

| Severity | Meaning | Example |
|---|---|---|
| CRITICAL | Direct path to compromise | UID 0 backdoor, empty password, `PermitEmptyPasswords yes`, world-writable SUID |
| HIGH | Serious weakness | No firewall, `NOPASSWD: ALL`, pending security updates, brute force |
| MEDIUM | Should be fixed | Password SSH login, world-writable folders, weak ciphers |
| LOW | Hardening | X11 forwarding, readable home folders, stale package lists |
| INFORMATIONAL | Context; never scored | Server software running, no AllowGroups |

- **CONFIRMED:** the misconfiguration was observed.
- **POTENTIAL:** a risk indicator that may be intended, such as an exposed service or an unknown SUID program.

## 7. Security score: methodology

```
score = 100 − Σ cost(finding)          (minimum 0)

cost:   CRITICAL 20   HIGH 10   MEDIUM 5   LOW 2   INFO 0
        POTENTIAL findings cost half, rounded up (CRITICAL 10, HIGH 5, MEDIUM 3, LOW 1)
```

| Score | Rating |
|---|---|
| 90–100 | Excellent |
| 75–89 | Good |
| 50–74 | Fair |
| 25–49 | Poor |
| 0–24 | Critical |

- **Grouping:** each finding summarises one *check*. For example, "SUID files in unusual locations" is one finding listing all the files, so one noisy check cannot dominate the score.
- **Skipped checks** are listed separately and **not** scored. Non-root ratings carry "limited audit".
- **Example** (the real baseline audit of the build container): 3 HIGH confirmed (30) + 1 HIGH potential (5) + 1 LOW confirmed (2) + 3 LOW potential (3) = 40 points, so **60/100 (Fair)**.

## 8. Reports

Reports are saved as `reports/security_audit_YYYY-MM-DD_HHMMSS.txt` and `.html` (mode 600).

| Section | TXT | HTML |
|---|---|---|
| Audit date, host, OS, kernel, architecture, user/mode, modules | ✓ | ✓ |
| Score, rating, method | ✓ | ✓ (gauge) |
| Severity summary (counts and points) | ✓ | ✓ (cards) |
| Findings, most severe first: type, module, details, recommendation, score impact | ✓ | ✓ (table) |
| Skipped checks | ✓ | ✓ |
| Full output of every module | ✓ | ✓ (collapsible) |

The HTML report is a single self-contained file: inline CSS, no JavaScript, no external resources. It is responsive, and all log or config content is HTML-escaped (a user name such as `<script>…` taken from auth.log is shown as text). See `sample_output/` and `screenshots/08–11`.

## 9. Testing

```bash
bash tests/run_tests.sh          # expected last line: Result: 170 passed, 0 failed
```

The test runner:
- creates stand-in commands (`ss ufw iptables nft systemctl apt dpkg journalctl sshd pgrep who ip lastlog`) in a private temporary folder, each logging its arguments;
- runs every module against fixtures in `tests/fixtures/`.

Tests cover:
- syntax of all scripts;
- escaping and the score arithmetic;
- every finding rule above;
- the `/proc/net` decoding (IPv4/IPv6/UDP);
- sshd `Include`, first-value-wins and `Match` semantics;
- both log timestamp formats and the journal;
- non-root behaviour;
- end-to-end `main.sh` (reports, permissions, HTML validity, `--module`, `--min-score`, menu, `--list-reports`, unsafe-config refusal);
- **a read-only guarantee:** every external command the tool ran was a read-only one.

## 10. Practical demonstration (summary)

The full script is in `docs/DEMO_GUIDE.md`.

```bash
sudo ./main.sh --full                      # 1. baseline score
sudo ./demo/setup_demo.sh                  # 2. safe test cases in /srv/audit-demo + listener on :23
sudo ./main.sh --module 3,4                # 3. weak permissions + exposed port found
sudo SSH_USE_SSHD_T=0 SSHD_CONFIG=demo/insecure_sshd_config ./main.sh --module 7   # 4. SSH demo
sudo ./main.sh --module 5                  # 5. firewall status
sudo ./main.sh --module 9                  # 6. failed logins (setup_demo.sh --with-log-entries adds tagged ones)
sudo ./main.sh --full                      # 7. score drops (container: 60 -> 45)
xdg-open reports/security_audit_*.html     # 8. HTML report
sudo ./demo/cleanup_demo.sh                # 9. remove everything; score returns to baseline
```

## 11. Troubleshooting

| Problem | Fix |
|---|---|
| `Permission denied` running `./main.sh` | `chmod +x main.sh` (or run `./install.sh`) |
| `This tool needs Bash 4 or newer` | Use `bash`, not `sh`: `sudo bash main.sh` |
| Many `[SKIPPED]` lines | Run with `sudo` for a full audit |
| Network: `/proc/net (ss not installed)` | `sudo apt install iproute2` (the fallback already works) |
| Process column shows `-` | Run with sudo to see other users' processes |
| Firewall: "could not be verified (not root)" | Run with sudo |
| Services: "systemd is not running" | Expected in containers/WSL; run on a normal VM |
| Login: "no authentication log source found" | Kali uses the journal: run with sudo, or install rsyslog for `/var/log/auth.log` |
| Inactive-account check skipped | `lastlog` is missing (Kali/Debian 13: `sudo apt install lastlog2`) |
| Updates: "package lists are N days old" | `sudo apt update`, then re-run (the tool never updates for you) |
| Warning "ignoring config/audit.conf" | `chmod go-w config/audit.conf`; the owner must be root or you |
| Permission scan is slow | Narrow `WW_SCAN_DIRS` / `SUID_SCAN_DIRS` in `config/audit.conf` (each `find` has a 120 s limit) |
| HTML won't open as root | Open it as your normal user; files are handed back to the sudo user |
| Colours look wrong in a log file | `--no-color` (colours are off automatically when output is not a terminal) |

## 12. Future enhancements

- CIS Benchmark mapping per finding; JSON output for SIEM ingestion.
- A comparison mode: diff two reports and show what changed since the last audit.
- Additional checks: kernel sysctl hardening, AppArmor/SELinux status, cron jobs, `authorized_keys`, password policy (pam_pwquality), fail2ban, auditd, file integrity baseline.
- RPM-family support (`firewalld`, `/var/log/secure` patterns, `dnf updateinfo`).
- Scheduled audits through a systemd timer, with e-mail on a score drop.
- ShellCheck in CI.

See `docs/PROJECT_REPORT.md` for the college documentation and `PROJECT_STATUS.md` for the test evidence.
