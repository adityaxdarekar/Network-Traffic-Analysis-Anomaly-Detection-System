# Viva Questions and Answers (25)

**1. What does the tool do, and what does it not do?**
It audits a Linux machine in nine areas, rates and explains each finding, computes a score and saves TXT/HTML reports. It does **not** change anything: no configuration edits, no service changes, no firewall changes, no package installs and no deletions. Fixes are given as recommendations.

**2. Why Bash?**
Bash is available on every Linux system. The audit mostly orchestrates standard tools (`find`, `ss`, `systemctl`, `ufw`), and Bash makes each command visible and easy to explain. There is nothing to install for the core audit.

**3. What is the difference between a CONFIRMED and a POTENTIAL finding?**
- **Confirmed:** the misconfiguration was observed directly, e.g. an empty password field.
- **Potential:** a risk indicator that might be intended, such as Redis listening on all interfaces or an unknown SUID program.

Potential findings cost half the points.

**4. Explain the scoring method.**
Start at 100 and subtract 20, 10, 5 or 2 points for each CRITICAL, HIGH, MEDIUM or LOW finding (INFO costs 0). Potential findings cost half, rounded up, and the minimum score is 0.

| Score | Rating |
|---|---|
| 90–100 | Excellent |
| 75–89 | Good |
| 50–74 | Fair |
| 25–49 | Poor |
| 0–24 | Critical |

Checks that could not run are listed but not scored.

**5. Why is a non-root score labelled "limited audit"?**
Without root, `/etc/shadow`, the sudoers rules, the firewall state and the protected logs cannot be read, so serious problems may be invisible. A high non-root score is therefore not comparable with a full audit, and the label prevents false reassurance.

**6. Why is UID 0 important?**
The kernel grants root privileges based on UID 0, not on the name "root". A second account with UID 0, such as "toor", is a full root account and a classic backdoor, so the tool rates it CRITICAL.

**7. How are empty passwords detected, and why does that need root?**
The second field of `/etc/shadow` holds the password hash. If it is empty, the account has no password. `/etc/shadow` is readable only by root (and the shadow group), so the check is skipped for normal users.

**8. What is risky about sudo NOPASSWD?**
Anyone who gains that user's session (malware, an unlocked terminal, a stolen SSH key) becomes root without knowing a password. `NOPASSWD: ALL` is rated HIGH, and `!authenticate` (no password for any rule) CRITICAL. NOPASSWD for specific commands is MEDIUM potential, because commands such as `vim` or `find` can spawn shells.

**9. What are SUID and SGID, and why aren't all SUID files reported?**
- **SUID/SGID** make a program run with its file owner's or group's identity. `passwd` needs SUID root to update `/etc/shadow`.
- **Why not report them all:** standard SUID programs are normal. The tool flags only:
  - SUID on GTFOBins programs (find, vim, bash, python…) that give a root shell;
  - SUID files in user-writable places (/home, /tmp, /srv);
  - world-writable SUID files (CRITICAL);
  - unknown ones, as LOW, to verify with `dpkg -S`.

**10. Why does the permission scan use `-xdev` and prune paths?**
`/proc`, `/sys`, `/dev` and `/run` are virtual filesystems whose "files" are kernel interfaces. Scanning them is slow and meaningless. Network mounts and container storage could also be huge. Only selected folders are scanned, each `find` has a time limit, and symlinks are ignored because they always show 777.

**11. What is the sticky bit?**
On a directory, the sticky bit (`chmod +t`, shown as `t`) lets only a file's owner delete or rename it, even if everyone can write to the directory. `/tmp` is 1777 and safe. A 777 directory without the sticky bit lets any user delete or replace others' files, so it is reported as MEDIUM.

**12. How does the network module work when `ss` is not installed?**
It reads `/proc/net/tcp`, `tcp6`, `udp` and `udp6`:
- addresses and ports are hexadecimal, and IPv4 addresses are stored little-endian, so `0100007F:0CEA` is 127.0.0.1:3306;
- TCP state `0A` means LISTEN, and bound UDP sockets are state `07`;
- as root, the socket inode is matched to a process through `/proc/<pid>/fd`.

The default awk on Ubuntu/Kali (mawk) has no `strtonum`, so the hex conversion is written by hand.

**13. Why isn't every listening port a vulnerability?**
Servers must listen to provide services, and SSH on port 22 is normal. Risk depends on **what** the service is and **where** it listens:
- services bound to 127.0.0.1 are reachable only locally;
- the tool flags well-known risky services (Telnet, FTP, TFTP, Redis, databases, the Docker API) only when they listen on all interfaces, and only as potential risks.

**14. What does the firewall module check if UFW is not installed?**
It checks nftables (`nft list ruleset`) and iptables (`iptables -S`, including a DROP policy). If rules exist, the host is protected by another firewall (INFO). If none exist, one HIGH finding is raised: "No host firewall is active". The tool never enables or changes a firewall.

**15. What is the difference between an enabled and a running service?**
- **Running:** active now.
- **Enabled:** starts automatically at boot.

A service can be enabled but not running (it will start after a reboot), or running but not enabled (started by hand). Both matter for attack surface.

**16. Why is sshd_config parsing tricky, and how does the tool handle it?**
- **First value wins:** sshd uses the *first* value it reads for a keyword.
- **Include comes first:** Ubuntu's `Include /etc/ssh/sshd_config.d/*.conf` sits at the top, so a cloud-init file there can override lines below it.
- **Match blocks** apply only to matching connections.

As root, the tool uses `sshd -T` (the effective configuration). Otherwise it parses with the same rules and fills in OpenSSH defaults, marked "(default)".

**17. Why is `PermitRootLogin yes` with password authentication CRITICAL?**
Root exists on every system, so attackers only need to guess the password, and bots try this constantly. With keys only it is HIGH: still not recommended, because there is no accountability for who used root.

**18. Why does the update module not run `apt update`?**
The audit must be read-only, and `apt update` changes system state (the package lists). The tool reads the existing cache, reports its age, and warns that the results may be stale.

**19. Why are security-sensitive packages reported separately?**
Outdated kernel, OpenSSL, OpenSSH, sudo, libc, systemd or polkit packages have a history of critical vulnerabilities, such as CVE-2021-3156 in sudo and CVE-2021-4034 (PwnKit) in polkit. They should be patched first, whatever the total number of pending updates.

**20. Where are login logs on Ubuntu and Kali?**
- **Ubuntu:** rsyslog writes `/var/log/auth.log`, rotated to `auth.log.1`.
- **Kali 2023+:** logs to the systemd journal only.

The tool reads the files, or falls back to `journalctl -t sshd -t sudo -t su -t login`. Reading them needs root or the `adm` group.

**21. How do you avoid counting one failed login twice?**
One failed SSH password produces a PAM line (`authentication failure`) and an sshd line (`Failed password`). For sshd, only `Failed password` is counted. For sudo, only `N incorrect password attempts` is counted, not the PAM line. Tests check that 31 failures are counted, not 41.

**22. Why is a successful login after many failures CRITICAL (potential)?**
It may mean the attacker guessed the password, which is the moment a brute force becomes a compromise. It needs immediate verification with the account owner. It is "potential" because it can also be a user who finally typed the right password.

**23. How is the tool made safe against shell injection and unsafe files?**
- **Quoting:** every variable is quoted, and `--` is used before file arguments.
- **Config:** the config file is sourced only if it is owned by root or the user and is not writable by others.
- **Temporary files:** created with `mktemp -d` under `umask 077`, and the cleanup trap only removes that directory.
- **HTML:** report output is HTML-escaped, which was tested with a `<script>` user name from auth.log.
- **Reports:** mode 600.

**24. How did you test a security tool without changing the system?**
- **Stand-ins:** stub versions of `ss`, `ufw`, `systemctl`, `apt`, `journalctl` and others print fixture data and log every call.
- **Fixtures:** fake passwd/shadow/sudoers files, sshd configs, auth logs and `/proc/net` tables simulate the vulnerable conditions.
- **Read-only proof:** the final test checks that the tool only ever invoked read-only commands.

170 tests pass without root.

**25. What would you improve next?**
- CIS control mapping and JSON output.
- Drift comparison between reports.
- More checks: sysctl, AppArmor, cron, PAM policy, authorized_keys, auditd.
- RPM-family support.
- ShellCheck in CI.
- Real-VM test runs on Kali and Ubuntu as part of the test suite.
