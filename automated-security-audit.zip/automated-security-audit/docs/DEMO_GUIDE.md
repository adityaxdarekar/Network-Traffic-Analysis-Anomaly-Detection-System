# Practical Demonstration Guide (Kali Linux)

**Use a lab virtual machine (VirtualBox/VMware, host-only or NAT network), never a production server or someone else's machine.** The audit itself is read-only. The demo test cases are created inside one marked folder and are removed by `cleanup_demo.sh`.

The outputs below are the **real outputs** captured in the build environment, an Ubuntu 24.04 container (see `sample_output/`). On your Kali VM, the host details, services, firewall and login sections will differ.

---

## 1. Install on Kali Linux

```bash
sudo apt update
sudo apt install -y iproute2 procps lastlog2 ufw    # ufw is optional; it is NOT enabled by installing it
unzip automated-security-audit.zip && cd automated-security-audit
chmod +x install.sh && ./install.sh                 # shows found/missing tools, sets permissions
bash tests/run_tests.sh                             # optional: "Result: 170 passed, 0 failed"
```

Explain to the faculty member:
- Only standard Linux tools are used, and each one is optional: there is a fallback, or the check is skipped with a reason.
- `reports/` and `logs/` are mode 700 because audit reports reveal weaknesses.

## 2. Execute the security audit

```bash
sudo ./main.sh               # menu → 10 (Complete Security Audit)
# or
sudo ./main.sh --full
```

Real baseline output (container, as root):

```
== Security Score and Risk Assessment ==
  Score: 60/100 (Fair)
  CRITICAL    0 finding(s)   -0 points
  HIGH        4 finding(s)   -35 points
  MEDIUM      0 finding(s)   -0 points
  LOW         4 finding(s)   -5 points
  INFO        2 finding(s)   -0 points
  Confirmed issues: 4   Potential risks: 4   Skipped checks: 2
```

Write down your baseline score. Also run it once **without sudo** (`./main.sh --full`) to show the `[SKIPPED]` lines and the rating `… - limited audit, N check(s) skipped`: least privilege limits what an auditor can see.

## 3. Identify weak file permissions

```bash
sudo ./demo/setup_demo.sh          # creates /srv/audit-demo: world_writable.txt (666), shared_upload/ (777), suid_demo (4755)
ls -l /srv/audit-demo              # show the permission strings: -rw-rw-rw-, drwxrwxrwx, -rwsr-xr-x
sudo ./main.sh --module 3
```

Real output:

```
  [MEDIUM] World-writable files outside system directories (1)
      e.g. /srv/audit-demo/world_writable.txt
      -> chmod o-w <file> unless sharing is intended (prefer group permissions).
  [MEDIUM] World-writable directories without the sticky bit (1)
      Any user can delete or replace other users' files in: /srv/audit-demo/shared_upload
  [HIGH] (potential) SUID/SGID files in user-writable or unusual locations
      /srv/audit-demo/suid_demo ...
```

Explain:
- **Not every SUID file is a problem.** `passwd` and `sudo` are counted as standard and not reported. Programs are flagged only in odd places, when they are GTFOBins escalation programs, or when they are unknown.
- `suid_demo` is a shell script. Linux ignores SUID on scripts, so the test file is harmless.
- `/tmp` is world-writable but has the sticky bit, so it is not reported.

## 4. Identify exposed network ports

`setup_demo.sh` also started a harmless Python listener on `0.0.0.0:23`. It accepts and immediately closes connections, and stops by itself after 60 minutes.

```bash
sudo ss -tulnp | grep ':23 '       # show it with the standard tool
sudo ./main.sh --module 4
```

```
    PROTO ADDRESS     PORT    SCOPE        PROCESS
    tcp   0.0.0.0     23      ALL          python3/946
  [HIGH] (potential) Telnet (cleartext logins) listening on all interfaces (tcp/23, python3/946)
```

Explain:
- A listening port by itself is not a vulnerability. An SSH port on all interfaces produces no finding.
- Well-known risky services on **all interfaces** are flagged as POTENTIAL, because only the administrator knows whether they are needed.
- Services on 127.0.0.1 are local only.

## 5. Check the firewall status

```bash
sudo ufw status verbose            # standard tool
sudo ./main.sh --module 5
```

**Without UFW,** or with UFW inactive and no nftables/iptables rules:

```
  [HIGH] No host firewall is active (UFW not installed, no nftables/iptables rules found)
      -> Install and enable UFW: sudo apt install ufw && sudo ufw default deny incoming && sudo ufw allow OpenSSH && sudo ufw enable
```

**Optional "after" step,** done by **you**, never by the tool, and on the lab VM only:

```bash
sudo ufw default deny incoming && sudo ufw allow OpenSSH && sudo ufw enable
sudo ./main.sh --module 5          # finding gone; rules are displayed
sudo ufw disable                   # put the VM back if you want
```

## 6. Detect failed login attempts

Kali stores logins in the systemd journal; Ubuntu uses `/var/log/auth.log`. Two ways to produce data:

1. **Real attempts against your own VM** (requires the openssh-server package): from another terminal, `ssh wronguser@localhost` three times with wrong passwords.
2. **Tagged sample lines:** `sudo ./demo/setup_demo.sh --with-log-entries` writes 8 lines with `logger -t sshd`, from the documentation address 203.0.113.99, each marked `[audit-demo]`.

```bash
sudo ./main.sh --module 9
```

Expected (from the test fixtures; the container has no auth log):

```
    IP                  FAILS  INVALID  FIRST                      LAST                       USERNAMES
    203.0.113.50           25        5  Nov 8 09:10:04             Nov 8 09:11:40             admin,oracle,test,ubuntu,pi,root
  [HIGH] SSH brute-force attempts from 203.0.113.50 (25 failed passwords)
  [MEDIUM] (potential) Username guessing from 203.0.113.50 (5 non-existent user names)
  [CRITICAL] (potential) Successful login from 203.0.113.50 after 25 failed attempts
```

Explain:
- Each attempt is counted once: the PAM duplicate line is ignored.
- A success after many failures from the same IP is the most important line to verify.

## 7. Calculate the security score

Show the summary and the "Score impact" lines in the TXT report:

```
score = 100 − Σ cost      CRITICAL 20 · HIGH 10 · MEDIUM 5 · LOW 2 · INFO 0   (POTENTIAL = half, rounded up)
```

**With the demo lab** (real container run): **60 → 45/100 (Poor)**.
- New: world-writable file (MEDIUM, 5), world-writable directory (MEDIUM, 5) and the exposed port-23 listener (HIGH potential, 5): **15 points**.
- `suid_demo` joined the existing "unusual SUID locations" finding, which is one finding per check, so it adds no extra points.

For the SSH demo, the real `/etc/ssh/sshd_config` is never touched:

```bash
sudo SSH_USE_SSHD_T=0 SSHD_CONFIG=demo/insecure_sshd_config ./main.sh --module 7
```

```
  [CRITICAL] (potential) PermitEmptyPasswords yes
  [CRITICAL] (potential) Root can log in over SSH with a password
  [MEDIUM] (potential) SSH password authentication is enabled
  ...
  Score: 69/100 (Fair)
```

The findings are "potential" because sshd is not running in this environment; they would apply once it starts.

## 8. Generate and open the HTML report

```bash
sudo ./main.sh --full                                    # saves TXT + HTML
ls -l reports/                                           # -rw------- owned by YOUR user (handed back after sudo)
xdg-open reports/security_audit_*.html                   # run as your normal user, not with sudo
less reports/security_audit_*.txt
```

Menu option **11** lists previous reports with their scores. The HTML report contains:
- a score gauge and severity cards;
- system information;
- a table of findings with recommendations;
- skipped checks;
- collapsible module output.

See `screenshots/08_html_report_dashboard.png`.

## 9. Demonstrate findings safely and clean up

```bash
sudo ./demo/cleanup_demo.sh       # stops the listener, removes /srv/audit-demo (only if the marker file exists)
sudo ./main.sh --full             # score is back to the baseline
```

Safety rules:
- The demo only creates files in one marked folder and one temporary listener.
- The tool never changes a configuration.
- Tagged log lines (option 2 in section 6) stay in the journal/auth.log: logs are never edited.

## 10. Explaining the results to a faculty member

1. **Purpose:** a repeatable, read-only health check covering the main local attack surfaces: accounts, permissions, network, firewall, services, SSH, patches and logins.
2. **Confirmed vs potential:** confirmed findings are observed misconfigurations. Potential findings need a decision; the tool does not guess intent.
3. **False-positive control:**
   - standard SUID programs are ignored;
   - ports are judged by scope and service;
   - sshd semantics (Include, first value wins, Match) are respected;
   - log events are de-duplicated;
   - checks that need root are skipped and listed instead of guessed.
4. **The score:** a transparent prioritisation aid, not a certification. 100/100 means "nothing found by these checks".
5. **Remediation stays human:** every finding includes the command an administrator *could* run, after review.
6. **Evidence of quality:** 170 automated tests with stub commands, including a test proving that only read-only commands are executed.
