# Automated Security Audit Tool for Linux Using Bash
### College Project Report

---

## 1. Abstract

Linux systems are often compromised through ordinary misconfigurations rather than advanced exploits: an extra UID 0 account, passwordless sudo, world-writable files, exposed legacy services, a disabled firewall, root SSH logins, missing patches, or unnoticed password guessing.

This project implements a modular, read-only Bash tool that audits a Kali Linux or Ubuntu machine in nine modules: system information, user accounts, file permissions, network, firewall, services, SSH, updates, and login/authentication logs.

**Findings.** Each finding is rated CRITICAL, HIGH, MEDIUM, LOW or INFORMATIONAL, and marked as either a *confirmed* misconfiguration or a *potential* risk that needs human judgement. Every finding comes with a remediation recommendation.

**Score.** A documented scoring method turns the findings into a score out of 100. Results are shown in a menu-driven terminal interface and saved as timestamped TXT and HTML reports.

**Testing.** The tool was tested with 170 automated tests using stub commands and fixtures, including a test that proves only read-only commands are executed. It was also run on a real Ubuntu 24.04 system, both as root and as a normal user, and with a safe demonstration lab:

| Run | Score |
|---|---|
| Baseline | 60/100 |
| With the lab | 45/100 |
| After cleanup | Back to baseline |

## 2. Problem Statement

Administrators and students rarely have time to check dozens of security settings by hand after every change. The commands involved (`find`, `ss`, `ufw`, `systemctl`, `sshd -T`, `journalctl`) each give partial, differently formatted answers. They need privileges, and their output is easy to misinterpret:
- not every SUID file or open port is a vulnerability;
- an `sshd_config` line can be overridden by an earlier `Include`.

Commercial or large open-source auditors can be heavy, opaque, or unsuitable for teaching.

The problem is to build a lightweight, transparent, safe tool that:
- collects these checks into one repeatable audit;
- separates real problems from context;
- explains each result;
- produces a report suitable for a manager or examiner;
- never changes the system it audits.

## 3. Objectives

1. Implement nine audit modules covering accounts, permissions, network exposure, firewall, services, SSH, patches and authentication logs on Kali and Ubuntu.
2. Classify every finding by severity and as confirmed or potential, and attach a remediation recommendation.
3. Compute a transparent security score out of 100.
4. Provide a menu-driven interface, single-module and full audits, and TXT/HTML reports with timestamps.
5. Work safely: read-only, graceful handling of missing commands and privileges, safe temporary files, quoting, and logging.
6. Verify the tool with automated tests and a reproducible, safe classroom demonstration.

## 4. Existing Systems

| Tool | Strength | Limitation for this purpose |
|---|---|---|
| Lynis | Very broad, mature | Hundreds of tests and complex output; harder to explain in a student project |
| OpenSCAP / CIS-CAT | Formal compliance profiles | Heavy, XML-based, distribution-specific content |
| Tiger, chkrootkit, rkhunter | Specific areas | Older, or focused on rootkits |
| Manual commands | Flexible | Not repeatable; no scoring or reporting; error-prone interpretation |

## 5. Proposed System

**Design.** A single Bash entry point (`main.sh`) loads two libraries and nine module files:
- each module is a function that inspects one area and records findings in a shared registry;
- a reporting library scores the findings and writes the reports.

**Key design decisions:**
- **Read-only.** Only query commands are used (`status`, `list`, `-S`, `-T`, `--upgradable`). Recommendations are text.
- **Confirmed vs potential.** The tool reports what it can prove and labels judgement calls.
- **Graceful degradation.** Missing tools trigger fallbacks (`/proc/net` instead of `ss`; nftables/iptables instead of UFW). Missing privileges produce *skipped* checks that are listed and not scored.
- **Correct semantics.** SSH config parsing follows sshd rules; log events are de-duplicated.
- **Testability.** Every path and external command can be redirected through variables to fixtures and stubs.

## 6. Hardware and Software Requirements

| Hardware | Minimum |
|---|---|
| CPU / RAM | Any machine that runs Kali/Ubuntu; 1 GB RAM |
| Disk | Less than 5 MB for the tool, plus reports |

| Software | |
|---|---|
| OS | Kali Linux 2023+ or Ubuntu 20.04+ (tested: Ubuntu 24.04) |
| Shell | Bash 4+ (tested: 5.2) |
| Required | coreutils, findutils, grep, sed, awk (mawk or gawk), hostname |
| Recommended | iproute2 (ss, ip), ufw, systemd (systemctl, journalctl), login/lastlog2, procps, dpkg/apt |

## 7. System Architecture

| Layer | Components |
|---|---|
| Interface | `main.sh`: options parser, menu, banner, root check, config loader (ownership/permission check), report viewer |
| Core library | `lib/common.sh`: colours, logging, `have_cmd`, `is_root`, `can_read`, `init_runtime` (`mktemp -d` + trap), `add_finding`, `skip_check`, `html_escape` |
| Audit modules | `modules/*.sh`: nine functions, each with its own configurable inputs |
| Scoring and reporting | `lib/report.sh`: `calc_score`, `print_summary`, `write_txt_report`, `write_html_report`, `save_reports` |
| Data | The findings registry (parallel arrays), per-module section files in the private temporary directory, `reports/`, `logs/` |

## 8. Data Flow Diagram

**Level 0:**

```
 Administrator ──(menu choice / options)──► [ Automated Security Audit Tool ] ──► terminal, TXT, HTML reports
                                                 ▲                  │
             system files, command output ───────┘                  └──► logs/audit_DATE.log
```

**Level 1:**

```
 options ─► 1 Initialise (colours, mktemp, log, safe config) ─► 2 Run module(s) ─┬─► findings registry
                                                                                  ├─► section text files
          /etc/*, /proc/net, find, ss, ufw, systemctl, sshd_config, apt, auth.log ┘     │
                                                                                         ▼
                                      3 Score (100 − Σ cost) ─► 4 Summary ─► 5 Write TXT + HTML (mode 600)
```

## 9. Module Flow (per module)

```
START module
 → check prerequisites (file readable? command present? root?)
     missing → skip_check(reason) → END
 → collect data (read file / run read-only command / fallback)
 → print data (out/kv), keep a copy for the report
 → for each rule: condition true? → add_finding(severity, CONFIRMED|POTENTIAL, title, detail, recommendation)
 → print [OK] lines for passed checks
END module
```

## 10. Module Descriptions

1. **System information:** distribution, version, kernel, hostname, architecture, uptime, logged-in users, virtualisation, pending reboot.
2. **User accounts:** UID 0 and duplicate UIDs, empty passwords (shadow), login shells of system accounts, password ageing, inactive and never-used accounts (lastlog), sudo group size, sudoers NOPASSWD and `!authenticate`, sudoers permissions.
3. **File permissions:**
   - world-writable files and directories in selected folders, with virtual filesystems pruned and `-xdev`;
   - SUID/SGID files classified as standard, GTFOBins-risky, unusual location, world-writable or unknown;
   - sensitive files checked against a maximum mode and owner;
   - home directories.
4. **Network:** listening TCP/UDP sockets (ss, or decoded `/proc/net`), scope (all interfaces / localhost / specific), processes, risky services exposed on all interfaces, IP forwarding, interfaces and addresses.
5. **Firewall:** UFW installed, active, default policy, risky allow rules, logging. Fallback detection of nftables/iptables.
6. **Services:** running, enabled at boot and failed systemd units; legacy, optional and server services (configurable lists); recommendations only.
7. **SSH:** installed and running state; effective configuration (`sshd -T`, or a parser with Include, first-value-wins and Match semantics, plus defaults); root login, password and key authentication, empty passwords, X11, MaxAuthTries, user environment, host-based authentication, rhosts, weak algorithms, LogLevel, AllowUsers/Groups.
8. **Updates:** cache age, last transaction, upgradable packages (from the cache), security-pocket and security-sensitive packages, unattended-upgrades; dnf fallback.
9. **Login and authentication:** auth.log, secure, or the journal; failed passwords, invalid users, root attempts, success after failures, sudo/su/local failures; per-IP table with first/last timestamps and user names.

## 11. Security Scoring Methodology

```
score = max(0, 100 − Σ cost)
cost(CRITICAL)=20  cost(HIGH)=10  cost(MEDIUM)=5  cost(LOW)=2  cost(INFO)=0
cost(POTENTIAL finding) = ceil(cost/2)
```

| Score | Rating |
|---|---|
| 90–100 | Excellent |
| 75–89 | Good |
| 50–74 | Fair |
| 25–49 | Poor |
| 0–24 | Critical |

**Rationale.**
- Severities reflect how directly an issue leads to compromise.
- Potential risks weigh half, because they may be intended.
- One finding summarises one check (e.g. all unusual SUID files together), so noisy checks cannot dominate.
- Skipped checks are excluded, and a non-root rating is labelled "limited audit".

**Worked example** (the real baseline): HIGH confirmed ×3 (30) + HIGH potential ×1 (5) + LOW confirmed ×1 (2) + LOW potential ×3 (3) = 40, so the score is **60 (Fair)**.

## 12. Security and Reliability Measures

- **Read-only:**
  - only query sub-commands are used;
  - the test suite logs every external call and fails on anything else;
  - demo cleanup removes only a folder that contains its marker file.
- **Privileges:**
  - `is_root` and `can_read` are checked before restricted files are read;
  - limited mode is clearly reported.
- **Safe temporary files:**
  - `umask 077`;
  - `mktemp -d` under `$TMPDIR`;
  - a `trap` on EXIT removes only that directory, after checking its name pattern.
- **Injection safety:**
  - all variables are quoted, and `--` is used before file arguments;
  - the config file is sourced only if it is owned by root or the user and is not group/world-writable;
  - HTML output is escaped, so hostile user names from logs are shown as text. This was tested, and it uncovered a Bash 5.2 behaviour change where `&` in a replacement means "the matched text"; the replacements are now quoted.
- **Robustness:**
  - `timeout` limits slow commands (`find`, firewall, apt, journal);
  - missing commands lead to fallbacks or skipped checks;
  - errors are logged to `logs/audit_DATE.log`.
- **Report protection:** mode 600, handed to `$SUDO_USER` so it can be opened without root.

## 13. Testing Methodology

`tests/run_tests.sh` runs **170 tests** without root and without touching the system:

| Group | Content |
|---|---|
| Syntax | `bash -n` on every script |
| Library | HTML escaping, trimming, score arithmetic incl. floor and half-cost |
| Modules 1–9 | Fixtures and stubs for each rule: positive and negative cases, non-root behaviour |
| Parsing | `/proc/net` IPv4/IPv6/UDP decoding; sshd Include/first-value/Match; syslog and ISO timestamps; journal source; de-duplication of PAM and sudo lines |
| End to end | `main.sh --full`: all modules ran, reports created with timestamped names and mode 600, TXT score equals terminal score, HTML parses and contains no injected script; `--module`, `--min-score`, invalid options, `--list-reports`, menu session, non-root run, unsafe config refused |
| Read-only guarantee | Every stubbed command call is checked against an allowlist of read-only invocations |

**Real-system runs.** In the build container (Ubuntu 24.04, as root and as user `ubuntu`), the demo lab was set up, audited and cleaned up. All outputs are in `sample_output/`.

## 14. Results

| Run (real, Ubuntu 24.04 container) | Score | Notes |
|---|---|---|
| Full audit as root (baseline) | 60/100 Fair | NOPASSWD sudo rule, no firewall, world-writable lock files under /root, SUID files under /tmp |
| Modules 3 and 4 with the demo lab | 69/100 | World-writable file and directory, SUID test file, port-23 listener |
| SSH module with `demo/insecure_sshd_config` | 69/100 | 2 CRITICAL potential (empty passwords, root password login) + 5 MEDIUM/LOW |
| Full audit with the demo lab | 45/100 Poor | 13 findings |
| Full audit as non-root | 92/100 "Excellent – limited audit, 5 check(s) skipped" | Shows why root is required for a meaningful score |
| Simulated full audit (all fixtures, stubs) | 0/100 Critical | Exercises every rule; see `sample_output/simulated_full_audit.html` |

## 15. Advantages and Limitations

**Advantages**

- Transparent and explainable: every rule, threshold and score contribution is documented.
- Safe: read-only, which is verified by tests.
- Low dependencies: Bash plus standard tools, with fallbacks.
- Separates confirmed problems from potential risks, reducing false alarms.
- Professional reports, useful for teaching and documentation.

**Limitations**

- **Coverage:** a heuristic, partial audit. It is not a full CIS benchmark or a vulnerability scanner (no CVE matching beyond pending package updates).
- **Root needed:** non-root results are incomplete (they are labelled as such).
- **Configurable lists:** service and SUID lists may need tuning for specialised systems.
- **Update freshness:** update results depend on the age of the local package cache, because the tool never runs `apt update`.
- **Log coverage:** analysis covers the current and previous auth.log, or 7 days of the journal. Compressed rotated logs are not read.
- **Not verified in the build environment:** UFW, `ss`, `ip` and a running systemd/sshd/journal were not available in the build container, so those paths were tested with stub commands and fixtures. The `/proc/net`, iptables, apt, permission and user paths were also run for real. ShellCheck was not available.

## 16. Future Enhancements

- CIS control IDs per finding; JSON output for SIEM.
- A comparison of two reports (drift detection); a scheduled systemd timer with alerts.
- More checks: sysctl hardening, AppArmor/SELinux, cron, authorized_keys, PAM password policy, auditd, fail2ban, kernel module blacklists.
- RPM-family support (firewalld, dnf updateinfo).
- ShellCheck and Kali/Ubuntu VM runs in CI.

## 17. Conclusion

The project shows that a small, well-structured Bash tool can perform a meaningful, safe and repeatable security audit of a Linux machine.

By combining read-only checks, correct interpretation (sshd semantics, de-duplicated log events, context-aware port and SUID rules) and a transparent score, it gives administrators a prioritised to-do list without the risk of automatic changes. The demonstration lab shows the effect of typical misconfigurations on the score in a controlled, reversible way, and the automated tests provide evidence that the tool behaves as documented.

## 18. References

1. CIS Benchmarks: Ubuntu Linux and Debian Linux (Center for Internet Security).
2. NIST SP 800-123, *Guide to General Server Security*; NIST SP 800-53 Rev. 5 (CM, AC, AU, SI families).
3. OpenSSH manual pages: `sshd(8)`, `sshd_config(5)` (Include, Match, first-obtained-value rule).
4. Ubuntu Server Guide: UFW, unattended-upgrades; Kali Linux documentation (journald logging).
5. Linux manual pages: `find(1)`, `ss(8)`, `proc(5)` (`/proc/net/tcp`), `shadow(5)`, `sudoers(5)`, `login.defs(5)`, `journalctl(1)`, `lastlog(8)`.
6. GTFOBins (gtfobins.github.io): Unix binaries that can be abused when SUID.
7. GNU Bash Reference Manual (parameter expansion; the `patsub_replacement` option in Bash 5.2).
8. MITRE ATT&CK: T1110 Brute Force, T1548.001 Setuid and Setgid, T1021.004 Remote Services: SSH.
