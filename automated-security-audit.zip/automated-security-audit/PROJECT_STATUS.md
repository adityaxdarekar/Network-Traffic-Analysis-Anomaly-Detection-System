# Project Status: what was verified, and how

**Build environment:** Ubuntu 24.04.5 container, Bash 5.2.21, mawk 1.3.4, running as root, plus a normal user `ubuntu`.

| Present | Absent |
|---|---|
| systemctl (systemd *not* running), journalctl (no journal), dpkg, apt, lastlog, iptables (no rules) | `ss`, `ip`, `ufw`, `nft`, `sshd`, ShellCheck, a syslog daemon |

## Verified

| Item | Evidence |
|---|---|
| 170 automated tests pass, both as root and as a normal user | `bash tests/run_tests.sh` → `sample_output/09_test_results.txt`, `screenshots/07_*` |
| All scripts parse (`bash -n`) | Test group 1 |
| Every finding rule of the 9 modules | Fixtures + stub commands (test groups 3–11) |
| Read-only behaviour: every external command call is a query | Test group 13 (stub call log checked against an allowlist) |
| Real full audit as root | `sample_output/01_baseline_full_audit_root.txt` (60/100) and `sample_report_baseline_container.*` |
| Real `/proc/net` fallback, process lookup, iptables check, apt cache check, user/sudoers/permission checks | Same run |
| Demo lab: setup, detection, cleanup | `sample_output/02–06_*` (scores 60 → 45 → back), `sample_report_with_demo_lab.*` |
| Real non-root run (user `ubuntu`) | `sample_output/07_full_audit_non_root.txt` (5 skipped checks, "limited audit" rating) |
| Menu session | `sample_output/08_menu_session.txt` |
| HTML report renders (desktop and phone width), parses, escapes hostile log content | `screenshots/08–11`, test group 12 |
| `install.sh` | `sample_output/00_install.txt` |

## Not verified on a real system (tested with stubs/fixtures only)

| Item | Why |
|---|---|
| `ss -tulnp` parsing | `ss` not installed in the build container (fixture output in `tests/fixtures/ss_tulnp.txt`) |
| UFW status parsing | `ufw` not installed (fixtures for active/inactive/default-allow) |
| systemd service listing | systemd is not PID 1 in a container (real run: check skipped with a reason) |
| sshd detection and `sshd -T` | OpenSSH server not installed. Config parsing *was* run for real with `demo/insecure_sshd_config` |
| auth.log / journal analysis | The container has no auth log or journal (real run: skipped with a reason). The parser was tested with synthetic logs in both timestamp formats |
| Kali-specific paths (journal-only logging, rolling updates, lastlog2) | No Kali VM available. Covered by fixtures (`os-release-kali`, journal stub) |
| ShellCheck | Not installed. Quoting was reviewed manually, and all scripts pass `bash -n` |

**Recommendation:** run `bash tests/run_tests.sh` and `sudo ./main.sh --full` on your Kali VM before the demonstration. Results will differ from the container samples, as expected.

## Bugs found and fixed by the tests

`html_escape` produced `<lt;` instead of `&lt;`. Since Bash 5.2, an unquoted `&` in a `${var//pattern/replacement}` replacement means "the matched text" (the `patsub_replacement` option). The replacements are now quoted variables.

The first test run as a normal user failed for checks that need root. The test suite now sets `AUDIT_ASSUME_ROOT=1`, a test hook that only selects code paths and grants no privileges, so the root-only logic is tested against fixtures by any user.

## Data honesty

- Sample reports from the container show real findings of that container. Some paths, such as `/tmp/claude-0/...` SUID test files and `/root/.cache/uv/.lock`, come from the build sandbox itself.
- `simulated_full_audit.*` is generated from the deliberately insecure **test fixtures** (score 0/100) to show every rule. It is not a real machine.
- Auth-log fixtures use documentation IP ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24) and are synthetic.
