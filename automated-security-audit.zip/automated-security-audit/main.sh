#!/usr/bin/env bash
# =============================================================================
#  Automated Security Audit Tool - main.sh
#
#  Read-only security audit for Linux (Kali Linux / Ubuntu).
#
#    sudo ./main.sh                 interactive menu (recommended: run as root)
#    sudo ./main.sh --full          complete audit + TXT and HTML reports
#    ./main.sh --module 3,4         selected modules, as a normal user (limited)
#    ./main.sh --list-reports       show saved reports
#    ./main.sh --help
#
#  The tool NEVER changes configuration, services, firewall rules or files.
# =============================================================================
set -o pipefail

if [[ -z "${BASH_VERSINFO:-}" || "${BASH_VERSINFO[0]}" -lt 4 ]]; then
    echo "This tool needs Bash 4 or newer." >&2; exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
REPORT_DIR="${AUDIT_REPORT_DIR:-$SCRIPT_DIR/reports}"
LOG_DIR="${AUDIT_LOG_DIR:-$SCRIPT_DIR/logs}"
CONFIG_FILE="${AUDIT_CONFIG:-$SCRIPT_DIR/config/audit.conf}"

# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh" || { echo "missing lib/common.sh" >&2; exit 1; }
# shellcheck source=lib/report.sh
source "$SCRIPT_DIR/lib/report.sh" || { echo "missing lib/report.sh" >&2; exit 1; }

MODULE_FILES=(system_info user_audit permission_audit network_audit firewall_audit service_audit ssh_audit update_audit login_audit)
MODULE_FUNCS=(audit_system_info audit_users audit_permissions audit_network audit_firewall audit_services audit_ssh audit_updates audit_login)
MODULE_NAMES=("System Information Audit" "User Account Security Audit" "File Permission Audit" "Network Security Audit"
              "Firewall Audit" "Running Services Audit" "SSH Security Audit" "System Update Audit" "Login & Authentication Audit")

load_config() {
    [[ -f "$CONFIG_FILE" ]] || return 0
    local owner mode
    owner=$(stat -c '%u' "$CONFIG_FILE" 2>/dev/null); mode=$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)
    # trusted owners: root, the current user, or the user who invoked sudo (who owns main.sh itself anyway)
    if [[ "$owner" != "0" && "$owner" != "$(id -u)" && "$owner" != "${SUDO_UID:-x}" ]] || (( (8#${mode:-777} & 8#022) != 0 )); then
        printf '%sWarning:%s ignoring %s (owner uid %s, mode %s): it must be owned by root or you and not be writable by group/others\n' \
            "$C_YELLOW" "$C_RESET" "$CONFIG_FILE" "$owner" "$mode" >&2
        log_msg WARN "config ignored: unsafe ownership/permissions ($owner, $mode)"
        return 0
    fi
    # shellcheck source=config/audit.conf
    source "$CONFIG_FILE"
}

load_modules() {
    local m
    for m in "${MODULE_FILES[@]}"; do
        # shellcheck source=/dev/null
        source "$SCRIPT_DIR/modules/$m.sh" || die "cannot load modules/$m.sh"
    done
}

setup_logging() {
    if mkdir -p -- "$LOG_DIR" 2>/dev/null && [[ -w "$LOG_DIR" ]]; then
        AUDIT_LOG_FILE="$LOG_DIR/audit_$(date +%Y-%m-%d).log"
    else
        AUDIT_LOG_FILE="$AUDIT_TMP/audit.log"
    fi
    touch "$AUDIT_LOG_FILE" 2>/dev/null && chmod 600 "$AUDIT_LOG_FILE" 2>/dev/null
}

banner() {
    printf '%s%s' "$C_BOLD" "$C_CYAN"
    cat <<'EOF'
     _         _                        _           _
    / \  _   _| |_ ___  _ __ ___   __ _| |_ ___  __| |
   / _ \| | | | __/ _ \| '_ ` _ \ / _` | __/ _ \/ _` |
  / ___ \ |_| | || (_) | | | | | | (_| | ||  __/ (_| |
 /_/   \_\__,_|\__\___/|_| |_| |_|\__,_|\__\___|\__,_|
      ____                       _ _            _             _ _ _
     / ___|  ___  ___ _   _ _ __(_) |_ _   _   / \  _   _  __| (_) |_
     \___ \ / _ \/ __| | | | '__| | __| | | | / _ \| | | |/ _` | | __|
      ___) |  __/ (__| |_| | |  | | |_| |_| |/ ___ \ |_| | (_| | | |_
     |____/ \___|\___|\__,_|_|  |_|\__|\__, /_/   \_\__,_|\__,_|_|\__|
                                       |___/
EOF
    printf '%s' "$C_RESET"
    printf '  %sAutomated Security Audit Tool v%s%s  -  read-only Linux security audit (Kali / Ubuntu)\n' "$C_BOLD" "$AUDIT_VERSION" "$C_RESET"
    printf '  Host: %s   User: %s   Date: %s\n' "$(hostname 2>/dev/null)" "$(id -un)" "$(date '+%Y-%m-%d %H:%M')"
    if is_root; then
        printf '  %sRunning as root: all checks available.%s\n' "$C_GREEN" "$C_RESET"
    else
        printf '  %sNot running as root:%s checks that need /etc/shadow, sudoers, firewall state, other users'"'"' processes\n' "$C_YELLOW" "$C_RESET"
        printf '  or protected logs are skipped and listed. For a complete audit: sudo %s\n' "$0"
    fi
}

usage() {
    cat <<EOF
Usage: $(basename "$0") [options]

  (no options)          interactive menu
  -f, --full            run all 9 modules, show the score and save TXT + HTML reports
  -m, --module LIST     run selected modules, e.g. -m 3 or -m 2,4,7 (numbers 1-9)
  -r, --report          save reports after --module (always done for --full)
      --no-report       do not save reports after --full
  -o, --output DIR      report directory (default: $REPORT_DIR)
  -l, --list-reports    list saved reports
      --min-score N     exit with status 3 when the score is below N (for scripts/CI)
      --no-color        plain output
      --menu            force the interactive menu
  -V, --version         show the version
  -h, --help            this help

Modules: 1 System Info  2 Users  3 File Permissions  4 Network  5 Firewall
         6 Services  7 SSH  8 Updates  9 Login & Authentication

Works without root (limited): system info, login shells/UID 0, world-writable files
and SUID programs in readable directories, listening ports, SSH config parsing,
pending updates. Needs root: /etc/shadow (empty passwords), sudoers rules,
UFW/nftables state, process names of other users, auth logs (or 'adm' group).
The audit never modifies the system.
EOF
}

reset_findings() {
    F_SEV=(); F_TYPE=(); F_MODULE=(); F_TITLE=(); F_DETAIL=(); F_REC=(); SKIPPED=(); MODULES_RUN=()
    rm -f -- "$AUDIT_TMP"/section_*.txt "$AUDIT_TMP"/auth_*.txt "$AUDIT_TMP"/auth_raw.log 2>/dev/null
}

run_module() {   # run_module N
    local n="$1"
    if ! [[ "$n" =~ ^[1-9]$ ]]; then printf 'Unknown module: %s (use 1-9)\n' "$n" >&2; return 1; fi
    local fn="${MODULE_FUNCS[$((n-1))]}"
    if ! declare -F "$fn" >/dev/null; then log_msg ERROR "function $fn missing"; printf 'Module %s is not available\n' "$n" >&2; return 1; fi
    "$fn" || { log_msg ERROR "module $n returned an error"; printf '  %s[ERROR]%s module %s ended with an error (see %s)\n' "$C_RED" "$C_RESET" "$n" "$AUDIT_LOG_FILE"; }
    return 0
}

finish_run() {   # finish_run save(0/1)
    print_summary
    if [[ "$1" == "1" ]]; then
        local paths
        if paths=$(save_reports "$REPORT_DIR"); then
            printf '\n  %sReports saved:%s\n' "$C_GREEN" "$C_RESET"
            printf '%s\n' "$paths" | sed 's/^/    /'
            printf '  Open the HTML report as your normal user: xdg-open "%s"\n' "$(printf '%s\n' "$paths" | tail -1)"
        else
            printf '  %sCould not save reports to %s (see log)%s\n' "$C_RED" "$REPORT_DIR" "$C_RESET"
        fi
    fi
    log_msg INFO "run finished: score $SCORE, findings ${#F_SEV[@]}, skipped ${#SKIPPED[@]}"
}

run_full() {   # run_full save(0/1)
    reset_findings
    local n
    for n in 1 2 3 4 5 6 7 8 9; do run_module "$n"; done
    finish_run "$1"
}

list_reports() {
    local files
    mapfile -t files < <(ls -1t "$REPORT_DIR"/security_audit_*.txt 2>/dev/null)
    if (( ${#files[@]} == 0 )); then echo "  No saved reports in $REPORT_DIR"; return 1; fi
    local i score
    for i in "${!files[@]}"; do
        score=$(sed -n 's/^ SECURITY SCORE: \([0-9]*\/100.*\)/\1/p' "${files[$i]}" | head -1)
        printf '  %2d) %s   %s\n' "$((i+1))" "$(basename "${files[$i]}")" "${score:-}"
    done
    REPORT_LIST=("${files[@]}")
}

view_reports() {
    printf '\n%sPrevious reports%s (%s)\n' "$C_BOLD" "$C_RESET" "$REPORT_DIR"
    list_reports || return 0
    local choice
    read -r -p "  Number to view (Enter = back): " choice || return 0
    [[ -z "$choice" ]] && return 0
    if ! [[ "$choice" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > ${#REPORT_LIST[@]} )); then echo "  Invalid choice."; return 0; fi
    local f="${REPORT_LIST[$((choice-1))]}"
    if [[ -t 1 ]] && have_cmd less; then less -R -- "$f"; else cat -- "$f"; fi
    printf '  HTML version: %s\n' "${f%.txt}.html"
}

menu() {
    banner
    local choice
    while true; do
        cat <<EOF

  ${C_BOLD}Main menu${C_RESET}
   1) System Information Audit          7) SSH Security Audit
   2) User Account Security Audit       8) System Update Audit
   3) File Permission Audit             9) Login & Authentication Audit
   4) Network Security Audit           10) Complete Security Audit (all + reports)
   5) Firewall Audit                   11) View Previous Reports
   6) Running Services Audit           12) Exit
EOF
        if ! read -r -p "  Select an option [1-12]: " choice; then echo; break; fi
        case "$choice" in
            [1-9])
                reset_findings; run_module "$choice"; print_summary
                local yn=""; read -r -p "  Save TXT + HTML report for this module? [y/N]: " yn || true
                [[ "$yn" =~ ^[Yy] ]] && finish_run 1 >/dev/null && printf '  Saved: %s and %s\n' "$LAST_TXT" "$LAST_HTML"
                ;;
            10) run_full 1 ;;
            11) view_reports ;;
            12|q|Q|exit) break ;;
            *) echo "  Please enter a number from 1 to 12." ;;
        esac
    done
    echo "  Goodbye. Logs: $AUDIT_LOG_FILE"
}

main() {
    local mode="" modules="" save=0 nosave=0 min_score="" force_menu=0
    while (( $# )); do
        case "$1" in
            -f|--full) mode="full" ;;
            -m|--module) shift; modules="${1:-}"; mode="modules"; [[ -n "$modules" ]] || { echo "--module needs a list, e.g. -m 2,4" >&2; exit 2; } ;;
            -r|--report) save=1 ;;
            --no-report) nosave=1 ;;
            -o|--output) shift; REPORT_DIR="${1:?--output needs a directory}" ;;
            -l|--list-reports) mode="list" ;;
            --min-score) shift; min_score="${1:-}"; [[ "$min_score" =~ ^[0-9]+$ ]] || { echo "--min-score needs a number" >&2; exit 2; } ;;
            --no-color) AUDIT_NO_COLOR=1 ;;
            --menu) force_menu=1 ;;
            -V|--version) echo "Automated Security Audit Tool $AUDIT_VERSION"; exit 0 ;;
            -h|--help) setup_colors; usage; exit 0 ;;
            *) echo "Unknown option: $1 (see --help)" >&2; exit 2 ;;
        esac
        shift
    done
    setup_colors
    init_runtime
    setup_logging
    load_config
    load_modules
    log_msg INFO "started: $0 mode=${mode:-menu} user=$(id -un) root=$(is_root && echo yes || echo no)"

    case "$mode" in
        full)
            banner; run_full "$(( nosave ? 0 : 1 ))" ;;
        modules)
            banner; reset_findings
            local n; IFS=',' read -r -a list <<<"$modules"
            for n in "${list[@]}"; do run_module "$(trim "$n")" || exit 2; done
            finish_run "$save" ;;
        list) list_reports; exit 0 ;;
        *)
            if [[ -t 0 || "$force_menu" == "1" ]]; then menu; exit 0; fi
            usage; exit 2 ;;
    esac
    if [[ -n "$min_score" ]] && (( SCORE < min_score )); then
        printf '  Score %s is below the required minimum %s\n' "$SCORE" "$min_score"; exit 3
    fi
    exit 0
}

main "$@"
