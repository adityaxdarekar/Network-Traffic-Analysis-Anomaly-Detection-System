#!/usr/bin/env bash
# =============================================================================
#  demo/cleanup_demo.sh - remove the demo lab created by setup_demo.sh
#
#  Removes ONLY the demo folder (it must contain the .audit-demo-lab marker)
#  and stops the demo listener (only if its command line is the demo listener).
#  System log lines written with --with-log-entries stay in the logs (they are
#  tagged [audit-demo]); log files are never edited.
# =============================================================================
set -u
DEMO_DIR="${DEMO_DIR:-/srv/audit-demo}"
MARK=".audit-demo-lab"

[[ "${EUID:-$(id -u)}" -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
if [[ ! -f "$DEMO_DIR/$MARK" ]]; then echo "No demo lab found at $DEMO_DIR - nothing to do."; exit 0; fi

if [[ -f "$DEMO_DIR/listener.pid" ]]; then
    pid=$(cat "$DEMO_DIR/listener.pid")
    if [[ "$pid" =~ ^[0-9]+$ ]] && tr '\0' ' ' <"/proc/$pid/cmdline" 2>/dev/null | grep -q 'python3'; then
        kill "$pid" 2>/dev/null && echo "  stopped demo listener (PID $pid)"
    fi
fi
case "$DEMO_DIR" in
    /|/etc|/usr|/home|/root|/var|/srv|/tmp|"") echo "Refusing to remove $DEMO_DIR" >&2; exit 1 ;;
esac
rm -rf -- "$DEMO_DIR" && echo "  removed $DEMO_DIR"
echo "Demo lab cleaned up. Re-run 'sudo ./main.sh --full' to see the score return to your baseline."
