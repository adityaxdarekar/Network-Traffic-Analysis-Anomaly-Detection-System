#!/usr/bin/env bash
# =============================================================================
#  demo/setup_demo.sh - create SAFE, removable test cases for the classroom demo
#
#    sudo ./demo/setup_demo.sh                     files + harmless listener
#    sudo ./demo/setup_demo.sh --with-log-entries  also write 8 tagged fake failed-login lines
#    sudo ./demo/cleanup_demo.sh                   remove everything again
#
#  Use a lab virtual machine (Kali or Ubuntu), never a production server.
#  Everything is created inside ONE folder (default /srv/audit-demo) marked with a
#  .audit-demo-lab file, so cleanup_demo.sh can remove exactly what was created.
#
#  Test cases                                             expected finding
#   1 world-writable file      /srv/audit-demo/world_writable.txt (666)   MEDIUM confirmed (Module 3)
#   2 world-writable directory /srv/audit-demo/shared_upload (777)        MEDIUM confirmed (Module 3)
#   3 SUID file in /srv        /srv/audit-demo/suid_demo (4755 script;    HIGH potential   (Module 3)
#                              Linux ignores SUID on scripts -> harmless)
#   4 listener on 0.0.0.0:23   python3 socket that accepts nothing and    HIGH potential   (Module 4)
#                              exits by itself after 60 minutes
#   5 (optional) failed logins 8 lines via `logger -t sshd`, tagged       MEDIUM           (Module 9)
#                              [audit-demo], from 203.0.113.99 (documentation IP)
#  The SSH demo uses demo/insecure_sshd_config through SSHD_CONFIG - the real
#  /etc/ssh/sshd_config is never touched.
# =============================================================================
set -u
DEMO_DIR="${DEMO_DIR:-/srv/audit-demo}"
DEMO_PORT="${DEMO_PORT:-23}"
DEMO_MINUTES="${DEMO_MINUTES:-60}"
MARK=".audit-demo-lab"

[[ "${EUID:-$(id -u)}" -eq 0 ]] || { echo "Run with sudo (creating a SUID test file and binding port $DEMO_PORT need root)." >&2; exit 1; }
if [[ -e "$DEMO_DIR" && ! -f "$DEMO_DIR/$MARK" ]]; then
    echo "$DEMO_DIR exists and is not a demo lab - choose another DEMO_DIR. Nothing was changed." >&2; exit 1
fi

mkdir -p -- "$DEMO_DIR"
echo "Created by demo/setup_demo.sh on $(date) - remove with demo/cleanup_demo.sh" >"$DEMO_DIR/$MARK"

echo "demo data - anyone can write to this file" >"$DEMO_DIR/world_writable.txt"
chmod 666 "$DEMO_DIR/world_writable.txt"
mkdir -p "$DEMO_DIR/shared_upload" && chmod 777 "$DEMO_DIR/shared_upload"
printf '#!/bin/sh\necho "audit demo: SUID bit is ignored for scripts, this file is harmless"\n' >"$DEMO_DIR/suid_demo"
chmod 4755 "$DEMO_DIR/suid_demo"
echo "  [1-3] files created in $DEMO_DIR"

if command -v python3 >/dev/null 2>&1; then
    if (exec 3<>"/dev/tcp/127.0.0.1/$DEMO_PORT") 2>/dev/null; then
        echo "  [4] port $DEMO_PORT is already in use - listener not started"
    else
        nohup python3 - "$DEMO_PORT" "$DEMO_MINUTES" >/dev/null 2>&1 <<'PY' &
import socket, sys, time
# audit-demo-listener: binds a port and immediately closes every connection - no service, no data
port, minutes = int(sys.argv[1]), int(sys.argv[2])
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", port)); s.listen(1); s.settimeout(5)
end = time.time() + minutes * 60
while time.time() < end:
    try:
        c, _ = s.accept(); c.close()
    except socket.timeout:
        pass
PY
        echo $! >"$DEMO_DIR/listener.pid"
        sleep 1
        echo "  [4] harmless listener on 0.0.0.0:$DEMO_PORT (PID $(cat "$DEMO_DIR/listener.pid"), stops after $DEMO_MINUTES min)"
    fi
else
    echo "  [4] python3 not found - listener skipped"
fi

if [[ "${1:-}" == "--with-log-entries" ]]; then
    if command -v logger >/dev/null 2>&1; then
        for u in admin oracle test pi admin root root root; do
            logger -p auth.notice -t sshd "Failed password for invalid user $u from 203.0.113.99 port 4242 ssh2 [audit-demo]"
        done
        echo "  [5] 8 fake failed SSH logins written to the system log (tagged [audit-demo]; logs are not edited by cleanup)"
    else
        echo "  [5] logger not found - log entries skipped"
    fi
fi

cat <<EOF

Lab ready. Now run:
  sudo ./main.sh --module 3,4          (or the menu) - see the new findings
  sudo SSH_USE_SSHD_T=0 SSHD_CONFIG=demo/insecure_sshd_config ./main.sh --module 7
  sudo ./main.sh --full                compare the score with your baseline
Clean up afterwards:
  sudo ./demo/cleanup_demo.sh
EOF
