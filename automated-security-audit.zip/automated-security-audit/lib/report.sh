#!/usr/bin/env bash
# shellcheck shell=bash
# =============================================================================
# lib/report.sh - security score and TXT / HTML report generation
#
# SCORING (documented in README section 7 and docs/PROJECT_REPORT.md)
#   Start at 100 and subtract, for every finding:
#       CRITICAL 20   HIGH 10   MEDIUM 5   LOW 2   INFO 0
#   POTENTIAL findings (risk indicators that need a human decision) cost half,
#   rounded up. The score never goes below 0. Checks that could not run
#   (e.g. without root) are listed as "skipped" - they do not raise the score,
#   so a limited (non-root) audit is clearly marked as incomplete.
#
#   Rating: 90-100 Excellent · 75-89 Good · 50-74 Fair · 25-49 Poor · 0-24 Critical
# =============================================================================

declare -A DEDUCT=([CRITICAL]=20 [HIGH]=10 [MEDIUM]=5 [LOW]=2 [INFO]=0)

finding_cost() {   # finding_cost SEVERITY TYPE -> points
    local full="${DEDUCT[$1]:-0}"
    if [[ "$2" == "POTENTIAL" ]]; then printf '%s' $(( (full + 1) / 2 )); else printf '%s' "$full"; fi
}

calc_score() {
    local i cost total=0
    declare -gA SEV_POINTS=([CRITICAL]=0 [HIGH]=0 [MEDIUM]=0 [LOW]=0 [INFO]=0)
    for i in "${!F_SEV[@]}"; do
        cost=$(finding_cost "${F_SEV[$i]}" "${F_TYPE[$i]}")
        total=$((total + cost))
        SEV_POINTS[${F_SEV[$i]}]=$(( ${SEV_POINTS[${F_SEV[$i]}]} + cost ))
    done
    DEDUCTION_TOTAL=$total
    SCORE=$(( 100 - total )); (( SCORE < 0 )) && SCORE=0
    if   (( SCORE >= 90 )); then RATING="Excellent"
    elif (( SCORE >= 75 )); then RATING="Good"
    elif (( SCORE >= 50 )); then RATING="Fair"
    elif (( SCORE >= 25 )); then RATING="Poor"
    else RATING="Critical"; fi
    # a non-root audit cannot see everything: say so in the rating itself
    is_root || RATING="$RATING - limited audit, ${#SKIPPED[@]} check(s) skipped"
}

score_color() {
    if (( SCORE >= 75 )); then printf '%s' "$C_GREEN"; elif (( SCORE >= 50 )); then printf '%s' "$C_YELLOW"; else printf '%s' "$C_RED"; fi
}

print_summary() {
    calc_score
    local s
    printf '\n%s%s== Security Score and Risk Assessment ==%s\n' "$C_BOLD" "$C_CYAN" "$C_RESET"
    printf '  Score: %s%s%s/100 (%s)%s\n' "$(score_color)" "$C_BOLD" "$SCORE" "$RATING" "$C_RESET"
    for s in "${SEVERITIES[@]}"; do
        printf '  %s%-9s%s %3s finding(s)   -%s points\n' "$(sev_color "$s")" "$s" "$C_RESET" "$(count_findings "$s")" "${SEV_POINTS[$s]}"
    done
    printf '  Confirmed issues: %s   Potential risks: %s   Skipped checks: %s\n' \
        "$(type_count CONFIRMED)" "$(type_count POTENTIAL)" "${#SKIPPED[@]}"
    if ! is_root; then
        printf '  %sNote:%s not run as root - %s check(s) skipped; the score covers only what could be read.\n' \
            "$C_YELLOW" "$C_RESET" "${#SKIPPED[@]}"
    fi
}

join_modules() {   # "1 System Information Audit, 2 User Account ..." for the report header
    local t out=""
    for t in "${MODULES_RUN[@]}"; do t=${t#Module }; out+="${out:+, }${t/:/}"; done
    printf '%s' "$out"
}

type_count() { local t="$1" n=0 i; for i in "${!F_TYPE[@]}"; do [[ "${F_TYPE[$i]}" == "$t" ]] && n=$((n+1)); done; printf '%s' "$n"; }

# indexes of findings sorted by severity (CRITICAL first), keeping module order inside a severity
sorted_indexes() {
    local s i
    for s in "${SEVERITIES[@]}"; do
        for i in "${!F_SEV[@]}"; do [[ "${F_SEV[$i]}" == "$s" ]] && printf '%s\n' "$i"; done
    done
}

report_meta() {
    R_HOST=$(hostname 2>/dev/null || cat /proc/sys/kernel/hostname 2>/dev/null || echo unknown)
    R_OS=$( . /etc/os-release 2>/dev/null && printf '%s' "${PRETTY_NAME:-unknown}" ) ; R_OS=${R_OS:-unknown}
    R_KERNEL=$(uname -r 2>/dev/null || echo unknown)
    R_ARCH=$(uname -m 2>/dev/null || echo unknown)
    R_USER=$(id -un 2>/dev/null || echo unknown)
    R_MODE=$(is_root && echo "root (full audit)" || echo "non-root (limited audit)")
    R_DATE=$(date '+%Y-%m-%d %H:%M:%S %Z')
}

# ---------------------------------------------------------------- TXT report
write_txt_report() {   # write_txt_report path
    local f="$1" i s m id
    calc_score; report_meta
    {
        echo "==============================================================================="
        echo " AUTOMATED SECURITY AUDIT REPORT   (tool version $AUDIT_VERSION)"
        echo "==============================================================================="
        printf ' %-14s %s\n' "Date:" "$R_DATE" "Hostname:" "$R_HOST" "OS:" "$R_OS" "Kernel:" "$R_KERNEL" \
            "Architecture:" "$R_ARCH" "Audited as:" "$R_USER - $R_MODE" "Modules:" "${#MODULES_RUN[@]} ($(join_modules))"
        echo
        echo " SECURITY SCORE: $SCORE/100  ($RATING)"
        echo " Method: 100 minus CRITICAL 20 / HIGH 10 / MEDIUM 5 / LOW 2 per finding;"
        echo "         potential risks cost half (rounded up); minimum 0."
        echo
        echo " SEVERITY SUMMARY"
        for s in "${SEVERITIES[@]}"; do printf '   %-9s %3s finding(s)   -%s points\n' "$s" "$(count_findings "$s")" "${SEV_POINTS[$s]}"; done
        echo "   Confirmed issues: $(type_count CONFIRMED)   Potential risks: $(type_count POTENTIAL)   Skipped checks: ${#SKIPPED[@]}"
        is_root || echo "   NOTE: limited (non-root) audit - skipped checks are NOT counted; run with sudo for a full audit."
        echo
        echo "==============================================================================="
        echo " FINDINGS AND RECOMMENDATIONS (most severe first)"
        echo "==============================================================================="
        if (( ${#F_SEV[@]} == 0 )); then echo " No findings."; fi
        local n=0
        while IFS= read -r i; do
            [[ -z "$i" ]] && continue
            n=$((n+1))
            printf '\n %d. [%s] [%s] %s\n' "$n" "${F_SEV[$i]}" "${F_TYPE[$i]}" "${F_TITLE[$i]}"
            printf '    Module:         %s\n' "${F_MODULE[$i]}"
            [[ -n "${F_DETAIL[$i]}" ]] && printf '    Details:        %s\n' "${F_DETAIL[$i]}"
            [[ -n "${F_REC[$i]}" ]] && printf '    Recommendation: %s\n' "${F_REC[$i]}"
            printf '    Score impact:   -%s\n' "$(finding_cost "${F_SEV[$i]}" "${F_TYPE[$i]}")"
        done < <(sorted_indexes)
        if (( ${#SKIPPED[@]} )); then
            echo; echo " SKIPPED CHECKS (not scored)"
            for m in "${SKIPPED[@]}"; do printf '   - [%s] %s\n' "${m%%|*}" "${m#*|}"; done
        fi
        echo
        echo "==============================================================================="
        echo " MODULE OUTPUT"
        echo "==============================================================================="
        for id in $(ls -1 "$AUDIT_TMP" 2>/dev/null | sed -n 's/^section_\(.*\)\.txt$/\1/p' | sort -n); do
            echo; echo "---- $(module_title_for "$id") ----"; cat "$AUDIT_TMP/section_${id}.txt"
        done
        echo
        echo " This audit is read-only: no configuration, service, firewall rule or file was changed."
        echo " CONFIRMED = observed misconfiguration; POTENTIAL = risk indicator needing a human decision."
    } >"$f"
}

module_title_for() {   # section ids are "NN_name"; titles were recorded in MODULES_RUN order
    local id="$1" t
    for t in "${MODULES_RUN[@]}"; do
        [[ "$t" == "Module ${id%%_*}:"* || "$t" == "Module $((10#${id%%_*})):"* ]] && { printf '%s' "$t"; return; }
    done
    printf '%s' "$id"
}

# ---------------------------------------------------------------- HTML report
write_html_report() {   # write_html_report path
    local f="$1" i s m id cls
    calc_score; report_meta
    local scol="#22c55e"; (( SCORE < 75 )) && scol="#eab308"; (( SCORE < 50 )) && scol="#ef4444"
    {
        cat <<EOF
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Security Audit - $(html_escape "$R_HOST") - $(html_escape "$R_DATE")</title>
<style>
:root{--bg:#0b1120;--panel:#111a2e;--line:#22304d;--text:#e2e8f0;--muted:#94a3b8;--crit:#d946ef;--high:#ef4444;--med:#eab308;--low:#38bdf8;--info:#64748b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:1180px;margin:0 auto;padding:28px 18px 60px}
h1{margin:0 0 4px;font-size:26px}h2{font-size:18px;margin:30px 0 10px;border-bottom:1px solid var(--line);padding-bottom:6px}
.muted{color:var(--muted)}.grid{display:grid;gap:14px}.top{grid-template-columns:260px 1fr}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px}
.gauge{width:170px;height:170px;border-radius:50%;margin:6px auto;display:grid;place-items:center;
 background:conic-gradient(${scol} calc(${SCORE}*1%),#1e293b 0)}
.gauge div{width:136px;height:136px;border-radius:50%;background:var(--panel);display:grid;place-items:center;text-align:center}
.gauge b{font-size:40px;line-height:1}.cards{grid-template-columns:repeat(5,1fr)}
.card{border-left:0;text-align:center}.card b{display:block;font-size:28px}
.c-CRITICAL b{color:var(--crit)}.c-HIGH b{color:var(--high)}.c-MEDIUM b{color:var(--med)}.c-LOW b{color:var(--low)}.c-INFO b{color:var(--info)}
table{width:100%;border-collapse:collapse}td,th{padding:7px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase}
.sev{display:inline-block;padding:1px 8px;border-radius:999px;font-weight:700;font-size:12px;color:#0b1120}
.s-CRITICAL{background:var(--crit)}.s-HIGH{background:var(--high)}.s-MEDIUM{background:var(--med)}.s-LOW{background:var(--low)}.s-INFO{background:var(--info);color:#e2e8f0}
.type{font-size:12px;color:var(--muted)}.rec{color:#86efac}
details{background:var(--panel);border:1px solid var(--line);border-radius:10px;margin:8px 0;padding:8px 14px}
summary{cursor:pointer;font-weight:600}pre{white-space:pre-wrap;word-break:break-word;font:12.5px/1.45 ui-monospace,Consolas,monospace;color:#cbd5e1}
.note{background:#1c1a0b;border:1px solid #a16207;color:#fde68a;border-radius:8px;padding:8px 12px;margin-top:10px}
@media (max-width:760px){.top{grid-template-columns:1fr}.cards{grid-template-columns:repeat(2,1fr)}td,th{font-size:12.5px}}
</style></head><body><main>
<h1>Automated Security Audit Report</h1>
<div class="muted">$(html_escape "$R_DATE") &middot; tool version $(html_escape "$AUDIT_VERSION") &middot; read-only audit</div>
<div class="grid top" style="margin-top:18px">
 <div class="panel"><div class="gauge"><div><span><b>${SCORE}</b><br><span class="muted">/ 100</span></span></div></div>
  <div style="text-align:center;font-weight:700;color:${scol}">$(html_escape "$RATING")</div></div>
 <div class="panel"><table>
  <tr><th>Hostname</th><td>$(html_escape "$R_HOST")</td></tr>
  <tr><th>Operating system</th><td>$(html_escape "$R_OS")</td></tr>
  <tr><th>Kernel / architecture</th><td>$(html_escape "$R_KERNEL") / $(html_escape "$R_ARCH")</td></tr>
  <tr><th>Audited as</th><td>$(html_escape "$R_USER") &middot; $(html_escape "$R_MODE")</td></tr>
  <tr><th>Modules run</th><td>$(html_escape "$(join_modules)")</td></tr>
  <tr><th>Scoring</th><td>100 minus CRITICAL 20 / HIGH 10 / MEDIUM 5 / LOW 2 per finding; potential risks cost half (rounded up). Total deducted: ${DEDUCTION_TOTAL}.</td></tr>
 </table></div>
</div>
<h2>Severity summary</h2>
<div class="grid cards">
EOF
        for s in "${SEVERITIES[@]}"; do
            printf ' <div class="panel card c-%s"><b>%s</b>%s<div class="muted">-%s points</div></div>\n' \
                "$s" "$(count_findings "$s")" "$s" "${SEV_POINTS[$s]}"
        done
        echo '</div>'
        printf '<p class="muted">Confirmed issues: %s &middot; Potential risks: %s &middot; Skipped checks: %s</p>\n' \
            "$(type_count CONFIRMED)" "$(type_count POTENTIAL)" "${#SKIPPED[@]}"
        is_root || echo '<div class="note">Limited (non-root) audit: some checks were skipped and are not included in the score. Run with sudo for a complete audit.</div>'
        echo '<h2>Detected issues and recommended remediation</h2>'
        if (( ${#F_SEV[@]} == 0 )); then echo '<p>No findings.</p>'; else
            echo '<div class="panel" style="overflow-x:auto"><table><tr><th>Severity</th><th>Module</th><th>Finding</th><th>Recommendation</th><th>Impact</th></tr>'
            while IFS= read -r i; do
                [[ -z "$i" ]] && continue
                printf '<tr><td><span class="sev s-%s">%s</span><div class="type">%s</div></td><td>%s</td><td><b>%s</b><div class="muted">%s</div></td><td class="rec">%s</td><td>-%s</td></tr>\n' \
                    "${F_SEV[$i]}" "${F_SEV[$i]}" "${F_TYPE[$i]}" "$(html_escape "${F_MODULE[$i]}")" \
                    "$(html_escape "${F_TITLE[$i]}")" "$(html_escape "${F_DETAIL[$i]}")" "$(html_escape "${F_REC[$i]}")" \
                    "$(finding_cost "${F_SEV[$i]}" "${F_TYPE[$i]}")"
            done < <(sorted_indexes)
            echo '</table></div>'
        fi
        if (( ${#SKIPPED[@]} )); then
            echo '<h2>Skipped checks (not scored)</h2><div class="panel"><ul>'
            for m in "${SKIPPED[@]}"; do printf '<li><b>%s</b>: %s</li>\n' "$(html_escape "${m%%|*}")" "$(html_escape "${m#*|}")"; done
            echo '</ul></div>'
        fi
        echo '<h2>Individual audit results</h2>'
        for id in $(ls -1 "$AUDIT_TMP" 2>/dev/null | sed -n 's/^section_\(.*\)\.txt$/\1/p' | sort -n); do
            printf '<details><summary>%s</summary><pre>%s</pre></details>\n' \
                "$(html_escape "$(module_title_for "$id")")" "$(html_escape <"$AUDIT_TMP/section_${id}.txt")"
        done
        cat <<'EOF'
<p class="muted" style="margin-top:28px">CONFIRMED = a misconfiguration observed directly. POTENTIAL = a risk indicator that needs a human decision (for example, a listening port may be required). INFO = context only.
No configuration, service, firewall rule or file was changed by this audit.</p>
</main></body></html>
EOF
    } >"$f"
}

save_reports() {   # save_reports dir -> prints the two paths
    local dir="$1" stamp base
    mkdir -p -- "$dir" || { log_msg ERROR "cannot create $dir"; return 1; }
    stamp=$(date '+%Y-%m-%d_%H%M%S')
    base="$dir/security_audit_${stamp}"
    write_txt_report "${base}.txt" && write_html_report "${base}.html" || { log_msg ERROR "report write failed"; return 1; }
    chmod 600 -- "${base}.txt" "${base}.html" 2>/dev/null
    # when started with sudo, hand the reports to the invoking user so they can open them without root
    if [[ -n "${SUDO_UID:-}" && -n "${SUDO_GID:-}" ]] && is_root; then
        chown "$SUDO_UID:$SUDO_GID" -- "${base}.txt" "${base}.html" 2>/dev/null || true
    fi
    log_msg INFO "reports saved: ${base}.txt ${base}.html (score $SCORE)"
    LAST_TXT="${base}.txt"; LAST_HTML="${base}.html"
    printf '%s\n%s\n' "${base}.txt" "${base}.html"
}
