#!/usr/bin/env bash
# shellcheck shell=bash
# =============================================================================
# lib/common.sh - shared helpers for the Automated Security Audit Tool
#
#   * colours (disabled automatically when output is not a terminal)
#   * logging to logs/audit_<date>.log
#   * the findings registry used by every module
#   * privilege checks, command detection, safe temporary directory
#
# Every module records problems with:
#   add_finding SEVERITY TYPE "Title" "Detail" "Recommendation"
#     SEVERITY : CRITICAL | HIGH | MEDIUM | LOW | INFO
#     TYPE     : CONFIRMED  - the misconfiguration was observed directly
#                POTENTIAL  - a risk indicator that needs a human decision
#                INFO       - context only, never affects the score
# The audit is READ-ONLY: nothing in this file changes the system.
# =============================================================================

AUDIT_VERSION="1.0.0"
SEVERITIES=(CRITICAL HIGH MEDIUM LOW INFO)

# ---------------------------------------------------------------- state
F_SEV=() ; F_TYPE=() ; F_MODULE=() ; F_TITLE=() ; F_DETAIL=() ; F_REC=()
SKIPPED=()                 # "Module|reason" for checks that could not run
MODULES_RUN=()             # module titles in execution order
CURRENT_MODULE="General"
CURRENT_MODULE_ID="general"
AUDIT_TMP=""

# ---------------------------------------------------------------- colours
setup_colors() {
    if [[ -t 1 && -z "${NO_COLOR:-}" && "${AUDIT_NO_COLOR:-0}" != "1" ]]; then
        C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
        C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'
        C_BLUE=$'\033[34m'; C_MAGENTA=$'\033[35m'; C_CYAN=$'\033[36m'
    else
        C_RESET=""; C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""
        C_BLUE=""; C_MAGENTA=""; C_CYAN=""
    fi
}

sev_color() {
    case "$1" in
        CRITICAL) printf '%s' "${C_BOLD}${C_MAGENTA}" ;;
        HIGH)     printf '%s' "${C_BOLD}${C_RED}" ;;
        MEDIUM)   printf '%s' "${C_YELLOW}" ;;
        LOW)      printf '%s' "${C_BLUE}" ;;
        *)        printf '%s' "${C_DIM}" ;;
    esac
}

# ---------------------------------------------------------------- logging
log_msg() {   # log_msg LEVEL message...
    local level="$1"; shift
    [[ -n "${AUDIT_LOG_FILE:-}" ]] || return 0
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" >>"$AUDIT_LOG_FILE" 2>/dev/null || true
}

die() {
    printf '%sError:%s %s\n' "${C_RED}" "${C_RESET}" "$*" >&2
    log_msg ERROR "$*"
    exit 1
}

# ---------------------------------------------------------------- environment
have_cmd() { command -v "$1" >/dev/null 2>&1; }

# Test hooks (they grant no privileges, they only select code paths):
#   AUDIT_ASSUME_NONROOT=1  show the limited, non-root behaviour while running as root
#   AUDIT_ASSUME_ROOT=1     let the test-suite exercise root-only logic against fixtures as a normal user
is_root() {
    [[ "${AUDIT_ASSUME_NONROOT:-0}" == "1" ]] && return 1
    [[ "${AUDIT_ASSUME_ROOT:-0}" == "1" ]] && return 0
    [[ "${EUID:-$(id -u)}" -eq 0 ]]
}

can_read() {  # readable by us, honouring AUDIT_ASSUME_NONROOT for root-only files
    local f="$1"
    [[ -r "$f" ]] || return 1
    if [[ "${AUDIT_ASSUME_NONROOT:-0}" == "1" ]]; then
        local mode; mode=$(stat -c '%a' "$f" 2>/dev/null) || return 1
        (( (8#$mode & 8#004) != 0 )) || return 1      # only world-readable files count as readable
    fi
    return 0
}

systemd_running() { [[ -d "${SYSTEMD_RUN_DIR:-/run/systemd/system}" ]] && have_cmd systemctl; }

init_runtime() {
    umask 077
    AUDIT_TMP=$(mktemp -d "${TMPDIR:-/tmp}/secaudit.XXXXXXXX") || die "cannot create a temporary directory"
    trap cleanup_runtime EXIT
    trap 'printf "\nInterrupted.\n" >&2; exit 130' INT TERM
}

cleanup_runtime() {
    # only ever removes the private temporary directory this run created
    if [[ -n "$AUDIT_TMP" && -d "$AUDIT_TMP" && "$AUDIT_TMP" == "${TMPDIR:-/tmp}"/secaudit.* ]]; then
        rm -rf -- "$AUDIT_TMP"
    fi
}

# ---------------------------------------------------------------- output
section_header() {   # section_header id "Title"
    CURRENT_MODULE_ID="$1"; CURRENT_MODULE="$2"
    MODULES_RUN+=("$2")
    : >"$AUDIT_TMP/section_${CURRENT_MODULE_ID}.txt"
    printf '\n%s%s== %s ==%s\n' "${C_BOLD}" "${C_CYAN}" "$2" "${C_RESET}"
    log_msg INFO "module started: $2"
}

out() {   # plain line, shown and kept for the report
    printf '%s\n' "$*"
    [[ -n "$AUDIT_TMP" ]] && printf '%s\n' "$*" >>"$AUDIT_TMP/section_${CURRENT_MODULE_ID}.txt"
}

kv() { out "$(printf '  %-26s %s' "$1:" "$2")"; }

sub() { printf '\n  %s%s%s\n' "${C_BOLD}" "$*" "${C_RESET}"; [[ -n "$AUDIT_TMP" ]] && printf '\n  %s\n' "$*" >>"$AUDIT_TMP/section_${CURRENT_MODULE_ID}.txt"; }

ok() { printf '  %s[OK]%s %s\n' "${C_GREEN}" "${C_RESET}" "$*"; [[ -n "$AUDIT_TMP" ]] && printf '  [OK] %s\n' "$*" >>"$AUDIT_TMP/section_${CURRENT_MODULE_ID}.txt"; }

# list_block "header" < lines  - prints at most LIST_LIMIT lines, then "... and N more"
list_block() {
    local limit="${LIST_LIMIT:-15}" n=0 line
    while IFS= read -r line; do
        n=$((n + 1))
        (( n <= limit )) && out "    $line"
    done
    (( n > limit )) && out "    ... and $((n - limit)) more"
    return 0
}

add_finding() {   # add_finding SEVERITY TYPE title detail recommendation
    local sev="$1" type="$2" title="$3" detail="$4" rec="$5"
    case "$sev" in CRITICAL|HIGH|MEDIUM|LOW|INFO) ;; *) sev="INFO" ;; esac
    case "$type" in CONFIRMED|POTENTIAL|INFO) ;; *) type="POTENTIAL" ;; esac
    [[ "$sev" == "INFO" ]] && type="INFO"
    F_SEV+=("$sev"); F_TYPE+=("$type"); F_MODULE+=("$CURRENT_MODULE")
    F_TITLE+=("$title"); F_DETAIL+=("$detail"); F_REC+=("$rec")
    printf '  %s[%s]%s %s%s%s\n' "$(sev_color "$sev")" "$sev" "${C_RESET}" \
        "$( [[ "$type" == "POTENTIAL" ]] && printf '(potential) ' )" "$title" ""
    [[ -n "$detail" ]] && printf '      %s%s%s\n' "${C_DIM}" "$detail" "${C_RESET}"
    [[ -n "$rec" ]] && printf '      %s-> %s%s\n' "${C_GREEN}" "$rec" "${C_RESET}"
    log_msg FINDING "$sev/$type [$CURRENT_MODULE] $title"
}

skip_check() {   # skip_check "reason"  (a check that could not run - shown, not scored)
    SKIPPED+=("$CURRENT_MODULE|$1")
    printf '  %s[SKIPPED]%s %s\n' "${C_YELLOW}" "${C_RESET}" "$1"
    [[ -n "$AUDIT_TMP" ]] && printf '  [SKIPPED] %s\n' "$1" >>"$AUDIT_TMP/section_${CURRENT_MODULE_ID}.txt"
    log_msg SKIP "[$CURRENT_MODULE] $1"
}

# ---------------------------------------------------------------- small utilities
trim() { local s="$1"; s="${s#"${s%%[![:space:]]*}"}"; printf '%s' "${s%"${s##*[![:space:]]}"}"; }

html_escape() {   # stdin or argument -> HTML-safe text
    local s
    if (( $# )); then s="$1"; else s=$(cat); fi
    # replacements are quoted: since Bash 5.2 an unquoted "&" in a replacement means "the matched text"
    local amp='&amp;' lt='&lt;' gt='&gt;' quot='&quot;' apos='&#39;'
    s=${s//&/"$amp"}; s=${s//</"$lt"}; s=${s//>/"$gt"}; s=${s//\"/"$quot"}; s=${s//\'/"$apos"}
    printf '%s' "$s"
}

# run a command with a time limit when `timeout` exists (keeps slow tools from hanging the audit)
run_limited() {
    local secs="$1"; shift
    if have_cmd timeout; then timeout "$secs" "$@"; else "$@"; fi
}

file_age_days() {   # whole days since the file was last modified
    local f="$1" now mt
    mt=$(stat -c '%Y' "$f" 2>/dev/null) || return 1
    now=$(date +%s)
    printf '%s' $(( (now - mt) / 86400 ))
}

count_findings() {   # count_findings SEVERITY -> number
    local s="$1" n=0 i
    for i in "${!F_SEV[@]}"; do [[ "${F_SEV[$i]}" == "$s" ]] && n=$((n + 1)); done
    printf '%s' "$n"
}
