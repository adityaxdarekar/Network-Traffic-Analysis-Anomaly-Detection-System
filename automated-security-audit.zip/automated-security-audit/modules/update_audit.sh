#!/usr/bin/env bash
# shellcheck shell=bash
# Module 8: System Update Audit
#   pending upgrades from the package manager's EXISTING cache, pending security
#   upgrades, security-sensitive packages (kernel, OpenSSL, OpenSSH, sudo, libc ...),
#   age of the package lists, last upgrade, unattended-upgrades, reboot required.
#
# The audit never runs `apt update`, `apt upgrade` or installs anything; it reads the
# cache that is already on disk. If the cache is old, the result is stale and the
# report says so.

APT_STAMP_FILES="${APT_STAMP_FILES:-/var/lib/apt/periodic/update-success-stamp /var/cache/apt/pkgcache.bin /var/lib/apt/lists}"
APT_HISTORY="${APT_HISTORY:-/var/log/apt/history.log}"
STALE_DAYS="${STALE_DAYS:-7}"
SENSITIVE_PKG_RE="${SENSITIVE_PKG_RE:-^(linux-image|linux-generic|linux-headers|openssl|libssl|openssh|sudo|libc6|bash|systemd|polkit|libpolkit|gnupg|curl|libcurl|ca-certificates|apt|dpkg|xz-utils|liblzma|glibc|libpam|login|passwd|firefox|chromium)}"

audit_updates() {
    section_header "08_updates" "Module 8: System Update Audit"
    if have_cmd apt; then audit_apt
    elif have_cmd dnf; then audit_dnf
    else skip_check "no supported package manager (apt or dnf) found"; fi
    if [[ -f "${REBOOT_REQUIRED_FILE:-/var/run/reboot-required}" ]]; then out "  A reboot is required to finish earlier updates (see Module 1)."; fi
    return 0
}

audit_apt() {
    kv "Package manager" "apt / dpkg"
    # --- cache age
    local newest="" f age
    for f in $APT_STAMP_FILES; do
        [[ -e "$f" ]] || continue
        local t; t=$(stat -c '%Y' "$f" 2>/dev/null) || continue
        [[ -z "$newest" || "$t" -gt "$newest" ]] && newest=$t
    done
    if [[ -n "$newest" ]]; then
        age=$(( ( $(date +%s) - newest ) / 86400 ))
        kv "Package lists last refreshed" "$(date -d "@$newest" '+%Y-%m-%d %H:%M' 2>/dev/null) ($age day(s) ago)"
        if (( age > 30 )); then
            add_finding MEDIUM CONFIRMED "Package lists have not been refreshed for $age days" "Update information (and this audit's results) are out of date." \
                "Run: sudo apt update  (then re-run this audit)."
        elif (( age > STALE_DAYS )); then
            add_finding LOW CONFIRMED "Package lists are $age days old" "Newer security updates may exist than reported here." "Run: sudo apt update"
        fi
    else
        skip_check "cannot determine when the package lists were last refreshed"
    fi
    if [[ -r "$APT_HISTORY" ]]; then
        local last; last=$(grep '^Start-Date:' "$APT_HISTORY" | tail -1 | sed 's/^Start-Date: *//')
        kv "Last apt transaction" "${last:-none recorded}"
    fi

    # --- pending upgrades (reads the cache; does not refresh it)
    local up; up=$(run_limited 60 apt list --upgradable 2>/dev/null | grep -v '^Listing' | grep .)
    local total sec sens
    total=$(printf '%s\n' "$up" | grep -c .)
    sec=$(printf '%s\n' "$up" | grep -E -- '-security|/kali-rolling' | grep -c .)
    # Kali has no separate security pocket: every upgrade comes from kali-rolling
    local is_kali=0; grep -qi '^ID=kali' "${OS_RELEASE_FILE:-/etc/os-release}" 2>/dev/null && is_kali=1
    (( is_kali )) || sec=$(printf '%s\n' "$up" | grep -c -- '-security')
    sens=$(printf '%s\n' "$up" | awk -F/ '{print $1}' | grep -E "$SENSITIVE_PKG_RE" | sort -u | tr '\n' ' ')
    kv "Upgradable packages" "$total"
    (( is_kali )) || kv "From the security pocket" "$sec"
    if (( total > 0 )); then
        sub "Upgradable packages"
        printf '%s\n' "$up" | sed 's/ \[upgradable from: / (installed: /; s/\]$/)/' | list_block
    fi
    if (( is_kali == 0 && sec > 0 )); then
        add_finding HIGH CONFIRMED "$sec pending SECURITY update(s)" "From the -security repository: $(printf '%s\n' "$up" | grep -- '-security' | cut -d/ -f1 | head -8 | tr '\n' ' ')" \
            "Install them: sudo apt update && sudo apt upgrade (the audit does not install anything)."
    fi
    if [[ -n "$sens" ]]; then
        add_finding HIGH CONFIRMED "Outdated security-sensitive packages" "$(trim "$sens")" \
            "Upgrade these first; kernel/libc/openssl updates need a restart of services or a reboot."
    fi
    if (( total > 0 )) && [[ -z "$sens" ]] && (( is_kali == 1 || sec == 0 )); then
        local sev=LOW; (( total > 50 )) && sev=MEDIUM
        add_finding "$sev" CONFIRMED "$total package upgrade(s) pending" "No security-sensitive package among them." "Apply regularly: sudo apt update && sudo apt upgrade"
    fi
    (( total == 0 )) && ok "No pending upgrades in the local package cache"

    # --- automatic updates
    if dpkg -s unattended-upgrades >/dev/null 2>&1; then
        kv "unattended-upgrades" "installed"
    elif (( is_kali == 0 )); then
        add_finding LOW POTENTIAL "Automatic security updates (unattended-upgrades) not installed" "" \
            "sudo apt install unattended-upgrades && sudo dpkg-reconfigure -plow unattended-upgrades"
    else
        out "  Kali is a rolling distribution: update manually and often (sudo apt update && sudo apt full-upgrade)."
    fi
}

audit_dnf() {
    kv "Package manager" "dnf"
    local out_up rc
    out_up=$(run_limited 120 dnf -q --cacheonly check-update 2>/dev/null); rc=$?
    local total; total=$(printf '%s\n' "$out_up" | grep -cE '^[[:alnum:]]')
    kv "Upgradable packages" "$total"
    if (( rc == 100 )); then
        add_finding MEDIUM CONFIRMED "$total package upgrade(s) pending" "" "sudo dnf upgrade --security (then a full upgrade)."
    elif (( rc == 0 )); then ok "No pending upgrades in the dnf cache"
    else skip_check "dnf could not read its cache (run 'sudo dnf makecache' and re-run)"; fi
}
