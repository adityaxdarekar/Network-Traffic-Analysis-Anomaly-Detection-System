#!/usr/bin/env bash
# shellcheck shell=bash
# Module 4: Network Security Audit
#   listening TCP/UDP ports (ss, or /proc/net when ss is missing), services bound to
#   ALL interfaces, owning processes (root needed for other users' processes),
#   commonly risky exposed services, interfaces and IP addresses, IP forwarding.
#
# A listening port is NOT a vulnerability by itself. Only well-known risky
# services reachable on all interfaces are flagged, as POTENTIAL risks.

PROC_NET_DIR="${PROC_NET_DIR:-/proc/net}"
IP_FORWARD_FILE="${IP_FORWARD_FILE:-/proc/sys/net/ipv4/ip_forward}"
ALL_IF_THRESHOLD="${ALL_IF_THRESHOLD:-10}"

# port:severity:description - flagged only when reachable on all interfaces
RISKY_PORTS="21:HIGH:FTP_(cleartext_logins) 23:HIGH:Telnet_(cleartext_logins) 69:HIGH:TFTP_(no_authentication) \
512:HIGH:rexec 513:HIGH:rlogin 514:HIGH:rsh/syslog 111:MEDIUM:rpcbind_(NFS_RPC) 135:MEDIUM:MS-RPC \
139:MEDIUM:NetBIOS/SMB 445:MEDIUM:SMB_file_sharing 2049:MEDIUM:NFS 161:MEDIUM:SNMP 1433:MEDIUM:MS_SQL_Server \
3306:MEDIUM:MySQL/MariaDB 5432:MEDIUM:PostgreSQL 3389:MEDIUM:RDP 5900:MEDIUM:VNC 5901:MEDIUM:VNC \
6379:HIGH:Redis_(often_no_authentication) 11211:HIGH:Memcached_(no_authentication) 27017:HIGH:MongoDB \
9200:HIGH:Elasticsearch 2375:CRITICAL:Docker_API_without_TLS 5000:LOW:development_web_server \
8000:LOW:development_web_server 8080:LOW:HTTP_alternate/proxy 8888:LOW:Jupyter/dev_server"

# ---------------------------------------------------------------- collection
# Output records: proto|local_address|port|process
collect_ss() {
    ss -tulnp 2>/dev/null | awk 'NR>1 {
        proto=$1; local=$5; proc="";
        for(i=7;i<=NF;i++) proc=proc $i " ";
        n=split(local, a, ":"); port=a[n]; addr=substr(local, 1, length(local)-length(port)-1);
        gsub(/[\[\]]/, "", addr); sub(/%.*/, "", addr);
        if (match(proc, /users:\(\("[^"]+",pid=[0-9]+/)) { p=substr(proc, RSTART+9, RLENGTH-9); gsub(/",pid=/, "/", p); proc=p } else proc="";
        print proto "|" addr "|" port "|" proc }'
}

collect_proc() {
    local f proto
    declare -A inode_proc=()
    if is_root; then
        local line ino pid
        while IFS= read -r line; do
            ino=${line%% *}; pid=${line#* }; pid=${pid#/proc/}; pid=${pid%%/*}
            ino=${ino#socket:[}; ino=${ino%]}
            [[ -z "${inode_proc[$ino]:-}" ]] && inode_proc[$ino]="$(cat "/proc/$pid/comm" 2>/dev/null)/$pid"
        done < <(find /proc/[0-9]*/fd -lname 'socket:*' -printf '%l %p\n' 2>/dev/null)
    fi
    for f in tcp tcp6 udp udp6; do
        [[ -r "$PROC_NET_DIR/$f" ]] || continue
        proto=${f%6}
        awk -v proto="$proto" -v v6="$([[ $f == *6 ]] && echo 1 || echo 0)" '
        function hex(s,   i, n) { n = 0; s = tolower(s); for (i = 1; i <= length(s); i++) n = n * 16 + index("0123456789abcdef", substr(s, i, 1)) - 1; return n }
        NR>1 {
            st=$4; if (proto=="tcp" && st!="0A") next; if (proto=="udp" && st!="07") next;
            split($2, la, ":"); h=la[1]; port=hex(la[2]);
            if (v6=="0") { addr=hex(substr(h,7,2)) "." hex(substr(h,5,2)) "." hex(substr(h,3,2)) "." hex(substr(h,1,2)) }
            else {
                if (h ~ /^0+$/) addr="::";
                else if (h=="00000000000000000000000001000000") addr="::1";
                else if (substr(h,1,24)=="0000000000000000FFFF0000") { w=substr(h,25,8); addr="::ffff:" hex(substr(w,7,2)) "." hex(substr(w,5,2)) "." hex(substr(w,3,2)) "." hex(substr(w,1,2)) }
                else { addr=""; for(i=0;i<4;i++){ w=substr(h,i*8+1,8); g=substr(w,7,2) substr(w,5,2) substr(w,3,2) substr(w,1,2); addr=addr (i?":":"") tolower(substr(g,1,4)) ":" tolower(substr(g,5,4)) } }
            }
            print proto "|" addr "|" port "|" $10 }' "$PROC_NET_DIR/$f"
    done | while IFS='|' read -r p a o ino; do
        printf '%s|%s|%s|%s\n' "$p" "$a" "$o" "${inode_proc[$ino]:-}"
    done
}

is_all_if() { [[ "$1" == "0.0.0.0" || "$1" == "::" || "$1" == "*" || "$1" == "" ]]; }
is_loopback() { [[ "$1" == 127.* || "$1" == "::1" || "$1" == "::ffff:127."* ]]; }

audit_network() {
    section_header "04_network" "Module 4: Network Security Audit"
    local records src
    if have_cmd ss && [[ "${FORCE_PROC_NET:-0}" != "1" ]]; then records=$(collect_ss); src="ss -tulnp"
    elif [[ -r "$PROC_NET_DIR/tcp" ]]; then records=$(collect_proc); src="/proc/net (ss not installed)"
    else skip_check "neither 'ss' nor $PROC_NET_DIR is available - listening ports not checked"; audit_interfaces; return 0; fi
    records=$(printf '%s\n' "$records" | grep . | sort -t'|' -k1,1 -k3,3n -u)
    kv "Source" "$src"
    is_root || out "  Note: without root, process names are shown only for your own processes."

    local total all=0 local_only=0 line proto addr port proc scope
    total=$(printf '%s\n' "$records" | grep -c .)
    kv "Listening sockets" "$total"
    sub "Listening ports"
    out "$(printf '    %-5s %-40s %-7s %-12s %s' PROTO ADDRESS PORT SCOPE PROCESS)"
    local exposed=()
    while IFS='|' read -r proto addr port proc; do
        [[ -z "$proto" ]] && continue
        if is_all_if "$addr"; then scope="ALL"; all=$((all+1)); exposed+=("$proto/$port|$proc")
        elif is_loopback "$addr"; then scope="localhost"; local_only=$((local_only+1))
        else scope="specific"; fi
        out "$(printf '    %-5s %-40s %-7s %-12s %s' "$proto" "${addr:-*}" "$port" "$scope" "${proc:--}")"
    done <<<"$records"
    kv "On all interfaces" "$all"
    kv "Localhost only" "$local_only"

    local e p pr spec rp rsev rdesc flagged=0
    for e in "${exposed[@]}"; do
        p=${e%%|*}; pr=${e#*|}
        for spec in $RISKY_PORTS; do
            IFS=: read -r rp rsev rdesc <<<"$spec"
            if [[ "${p#*/}" == "$rp" ]]; then
                rdesc=${rdesc//_/ }
                add_finding "$rsev" POTENTIAL "$rdesc listening on all interfaces ($p${pr:+, $pr})" \
                    "Reachable from any network the host is connected to, unless a firewall blocks it." \
                    "If it is not needed, stop it; otherwise bind it to localhost/a private interface and restrict it with firewall rules."
                flagged=$((flagged+1))
            fi
        done
    done
    if (( all > ALL_IF_THRESHOLD )); then
        add_finding LOW POTENTIAL "$all services listen on all interfaces" "A large attack surface; each service should have a reason to be reachable." \
            "Review the list above and close or restrict services that are not required."
    fi
    (( flagged == 0 )) && ok "No commonly risky service is exposed on all interfaces"

    local fw; fw=$(cat "$IP_FORWARD_FILE" 2>/dev/null)
    kv "IPv4 forwarding" "${fw:-unknown}"
    if [[ "$fw" == "1" ]]; then
        add_finding LOW POTENTIAL "IP forwarding is enabled" "The host can route packets between networks (normal for routers, Docker or VPN hosts)." \
            "If this machine is not meant to route traffic: set net.ipv4.ip_forward=0 in /etc/sysctl.conf."
    fi
    audit_interfaces
}

audit_interfaces() {
    sub "Network interfaces and IP addresses"
    if have_cmd ip; then
        ip -br addr show 2>/dev/null | list_block
    else
        local i
        for i in /sys/class/net/*; do
            [[ -e "$i" ]] || continue
            out "$(printf '    %-12s %s' "$(basename "$i")" "$(cat "$i/operstate" 2>/dev/null)")"
        done
        have_cmd hostname && out "    addresses: $(hostname -I 2>/dev/null || echo unknown)"
        out "    ('ip' not installed - install iproute2 for full details)"
    fi
}
