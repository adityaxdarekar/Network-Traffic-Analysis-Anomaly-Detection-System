#!/usr/bin/env bash
# shellcheck shell=bash
# Module 3: File Permission Audit
#   * world-writable files and directories (without sticky bit) in SELECTED locations
#   * SUID/SGID programs, compared with a list of programs that are normally SUID
#   * permissions and ownership of sensitive files (/etc/passwd, /etc/shadow, sudoers ...)
#   * home directories readable/writable by others
#
# Scans stay on one file system (-xdev) and prune virtual/pseudo file systems
# (/proc /sys /dev /run /snap ...). A SUID program is NOT reported as a problem
# just because it is SUID - only unusual locations, unknown programs and
# programs known to allow privilege escalation are flagged.

WW_SCAN_DIRS="${WW_SCAN_DIRS:-/etc /usr /opt /srv /var/www /home /root /boot}"
SUID_SCAN_DIRS="${SUID_SCAN_DIRS:-/usr /bin /sbin /opt /home /srv /var /tmp /root}"
HOME_BASE="${HOME_BASE:-/home}"
SUID_ODD_RE="${SUID_ODD_RE:-^/(home|tmp|var/tmp|dev/shm|srv|root)/}"   # unusual places for SUID programs
SYSTEM_DIR_RE="${SYSTEM_DIR_RE:-^/(etc|usr|bin|sbin|boot|root)/}"      # world-writable here = HIGH
PRUNE_PATHS="${PRUNE_PATHS:-/proc /sys /dev /run /snap /var/lib/docker /var/lib/containers /var/lib/lxcfs}"

# path:max_mode:owner   (any permission bit outside max_mode is a finding)
SENSITIVE_FILE_SPECS="${SENSITIVE_FILE_SPECS:-/etc/passwd:644:root /etc/group:644:root /etc/shadow:640:root /etc/gshadow:640:root /etc/sudoers:440:root /etc/ssh/sshd_config:644:root /etc/crontab:644:root /etc/hosts:644:root /etc/login.defs:644:root /root:700:root /boot/grub/grub.cfg:644:root}"

# programs that are SUID/SGID on a standard Ubuntu/Kali installation
KNOWN_SUID="passwd chsh chfn gpasswd newgrp su sudo sudoedit mount umount ping ping6 pkexec ssh-keysign \
dbus-daemon-launch-helper polkit-agent-helper-1 unix_chkpwd pam_extrausers_chkpwd chage expiry crontab ssh-agent \
fusermount fusermount3 ntfs-3g Xorg.wrap at wall write bsd-write mount.nfs mount.cifs pppd traceroute6.iputils \
snap-confine kismet_cap_linux_bluetooth kismet_cap_linux_wifi kismet_cap_nrf_51822 kismet_cap_nrf_mousejack \
kismet_cap_nxp_kw41z kismet_cap_rz_killerbee kismet_cap_ti_cc_2531 kismet_cap_ti_cc_2540 kismet_cap_ubertooth_one \
kismet_cap_hak5_wifi_coconut kismet_cap_nrf_52840 vmware-user-suid-wrapper chrome-sandbox Xorg dmcrypt-get-device \
utempter pt_chown mail-lock mail-unlock mail-touchlock dotlockfile lockfile procmail exim4 ssh-agent vboxdrv \
VBoxHeadless VBoxNetAdpCtl VBoxNetDHCP VBoxNetNAT VBoxSDL VBoxVolInfo VirtualBoxVM authbind lppasswd \
usernetctl userhelper staprun nvidia-modprobe fping fping6 arping mtr-packet slock xscreensaver dumpcap"

# programs that give a root shell or file access when SUID (GTFOBins)
RISKY_SUID="bash sh dash zsh ksh csh tcsh fish find vim vi vim.basic nano less more awk gawk mawk python python2 python3 \
perl ruby lua php node nmap cp mv tar zip unzip rsync tee dd env xargs timeout nice taskset strace gdb docker \
busybox socat nc ncat netcat wget curl openssl base64 sed ed git ftp ash expect"

prune_expr() {   # builds:  ( -path P1 -o -path P2 ... ) -prune -o
    local p first=1
    PRUNE_ARGS=( "(" )
    for p in $PRUNE_PATHS; do
        (( first )) || PRUNE_ARGS+=( -o ); first=0
        PRUNE_ARGS+=( -path "$p" )
    done
    PRUNE_ARGS+=( ")" -prune -o )
}

in_list() { local w="$1" x; for x in $2; do [[ "$x" == "$w" ]] && return 0; done; return 1; }

audit_permissions() {
    section_header "03_permissions" "Module 3: File Permission Audit"
    is_root || out "  Note: without root, directories you cannot read are skipped silently by find."
    prune_expr
    audit_world_writable
    audit_suid
    audit_sensitive_files
    audit_homes
}

audit_world_writable() {
    sub "World-writable files and directories (locations: $WW_SCAN_DIRS)"
    local dirs=() d
    for d in $WW_SCAN_DIRS; do [[ -d "$d" ]] && dirs+=("$d"); done
    (( ${#dirs[@]} )) || { out "    no scan locations exist"; return 0; }
    local wwf wwd
    wwf=$(run_limited "${SCAN_TIMEOUT:-120}" find "${dirs[@]}" -xdev "${PRUNE_ARGS[@]}" -type f -perm -0002 -print 2>/dev/null | sort)
    wwd=$(run_limited "${SCAN_TIMEOUT:-120}" find "${dirs[@]}" -xdev "${PRUNE_ARGS[@]}" -type d -perm -0002 ! -perm -1000 -print 2>/dev/null | sort)
    local nf nd; nf=$(printf '%s\n' "$wwf" | grep -c .); nd=$(printf '%s\n' "$wwd" | grep -c .)
    kv "World-writable files" "$nf"
    kv "World-writable dirs (no sticky bit)" "$nd"
    if (( nf > 0 )); then
        printf '%s\n' "$wwf" | grep . | while IFS= read -r p; do printf '%s  %s\n' "$(stat -c '%A %U:%G' "$p" 2>/dev/null)" "$p"; done | list_block
        local sys; sys=$(printf '%s\n' "$wwf" | grep -E "$SYSTEM_DIR_RE" | head -5 | tr '\n' ' ')
        if [[ -n "$sys" ]]; then
            add_finding HIGH CONFIRMED "World-writable files in system locations ($(printf '%s\n' "$wwf" | grep -cE "$SYSTEM_DIR_RE"))" \
                "Any local user can modify: $(trim "$sys")" "Remove write access for others: sudo chmod o-w <file> (check why it was changed first)."
        fi
        local other; other=$(printf '%s\n' "$wwf" | grep -vE "$SYSTEM_DIR_RE" | grep .)
        if [[ -n "$other" ]]; then
            add_finding MEDIUM CONFIRMED "World-writable files outside system directories ($(printf '%s\n' "$other" | grep -c .))" \
                "e.g. $(printf '%s\n' "$other" | head -3 | tr '\n' ' ')" "chmod o-w <file> unless sharing is intended (prefer group permissions)."
        fi
    else ok "No world-writable files in the scanned locations"; fi
    if (( nd > 0 )); then
        printf '%s\n' "$wwd" | grep . | list_block
        add_finding MEDIUM CONFIRMED "World-writable directories without the sticky bit ($nd)" \
            "Any user can delete or replace other users' files in: $(printf '%s\n' "$wwd" | head -3 | tr '\n' ' ')" \
            "Remove o+w, or set the sticky bit like /tmp: sudo chmod +t <dir>."
    fi
}

audit_suid() {
    sub "SUID / SGID programs (locations: $SUID_SCAN_DIRS)"
    local dirs=() d
    for d in $SUID_SCAN_DIRS; do [[ -d "$d" ]] && dirs+=("$d"); done
    (( ${#dirs[@]} )) || return 0
    local list; list=$(run_limited "${SCAN_TIMEOUT:-120}" find "${dirs[@]}" -xdev "${PRUNE_ARGS[@]}" -type f \( -perm -4000 -o -perm -2000 \) -print 2>/dev/null | sort -u)
    local total known=0 unknown=() risky=() oddloc=() wwsuid=() p b
    total=$(printf '%s\n' "$list" | grep -c .)
    while IFS= read -r p; do
        [[ -z "$p" ]] && continue
        b=$(basename "$p")
        local mode; mode=$(stat -c '%a' "$p" 2>/dev/null)
        if [[ -n "$mode" ]] && (( (8#$mode & 8#002) != 0 )); then wwsuid+=("$p"); fi
        if [[ "$p" =~ $SUID_ODD_RE ]]; then oddloc+=("$p")
        elif in_list "$b" "$RISKY_SUID"; then risky+=("$p")
        elif in_list "$b" "$KNOWN_SUID"; then known=$((known+1))
        else unknown+=("$p"); fi
    done <<<"$list"
    kv "SUID/SGID files found" "$total (standard: $known)"
    printf '%s\n' "$list" | grep . | while IFS= read -r p; do printf '%s  %s\n' "$(stat -c '%A %U' "$p" 2>/dev/null)" "$p"; done | list_block
    if (( ${#wwsuid[@]} )); then
        add_finding CRITICAL CONFIRMED "SUID/SGID program that is world-writable" "${wwsuid[*]}" \
            "Anyone can replace it with code that runs with its owner's rights: sudo chmod o-w,u-s,g-s <file> after investigating."
    fi
    if (( ${#risky[@]} )); then
        add_finding HIGH POTENTIAL "SUID/SGID set on programs that allow privilege escalation" "${risky[*]}" \
            "These programs (see GTFOBins) can spawn a root shell when SUID. Remove the bit unless documented: sudo chmod u-s <file>."
    fi
    if (( ${#oddloc[@]} )); then
        add_finding HIGH POTENTIAL "SUID/SGID files in user-writable or unusual locations" "${oddloc[*]}" \
            "SUID programs in home, /tmp or /srv are unusual - verify their origin, then remove the bit (chmod u-s,g-s)."
    fi
    if (( ${#unknown[@]} )); then
        add_finding LOW POTENTIAL "SUID/SGID programs not in the standard list (${#unknown[@]})" "${unknown[*]:0:8}" \
            "Not automatically vulnerable - check each belongs to an installed package (dpkg -S <file>) and is needed."
    fi
    (( ${#unknown[@]} + ${#risky[@]} + ${#oddloc[@]} + ${#wwsuid[@]} == 0 )) && ok "All SUID/SGID programs are standard system programs"
    return 0
}

audit_sensitive_files() {
    sub "Sensitive files"
    local spec path max owner mode own extra
    for spec in $SENSITIVE_FILE_SPECS; do
        IFS=: read -r path max owner <<<"$spec"
        [[ -e "$path" ]] || continue
        mode=$(stat -c '%a' "$path" 2>/dev/null) || continue
        own=$(stat -c '%U:%G' "$path" 2>/dev/null)
        out "$(printf '    %-28s %4s  %s' "$path" "$mode" "$own")"
        extra=$(( 8#$mode & ~8#$max & 8#7777 ))
        if (( extra != 0 )); then
            local sev=MEDIUM
            # writable by others, or secret files readable by others = critical
            if (( (8#$mode & 8#002) != 0 )); then sev=CRITICAL
            elif [[ "$path" =~ (shadow|gshadow|sudoers)$ ]] && (( (8#$mode & 8#004) != 0 )); then sev=CRITICAL
            elif (( (8#$mode & 8#020) != 0 )); then sev=HIGH; fi
            add_finding "$sev" CONFIRMED "Insecure permissions on $path ($mode, expected $max or stricter)" \
                "Extra permission bits: $(printf '%o' "$extra"); owner $own" "sudo chmod $max $path"
        fi
        if [[ "${own%%:*}" != "$owner" ]]; then
            add_finding HIGH CONFIRMED "$path is owned by ${own%%:*} instead of $owner" "Owner/group: $own" "sudo chown $owner $path (after checking why it changed)"
        fi
    done
}

audit_homes() {
    sub "Home directories ($HOME_BASE)"
    [[ -d "$HOME_BASE" ]] || return 0
    local d mode bad_w="" bad_r=""
    for d in "$HOME_BASE"/*/; do
        [[ -d "$d" ]] || continue
        d=${d%/}; mode=$(stat -c '%a' "$d" 2>/dev/null) || continue
        out "$(printf '    %-28s %4s  %s' "$d" "$mode" "$(stat -c '%U' "$d")")"
        if (( (8#$mode & 8#002) != 0 )); then bad_w+="$d ($mode) "
        elif (( (8#$mode & 8#005) != 0 )); then bad_r+="$d ($mode) "; fi
    done
    [[ -n "$bad_w" ]] && add_finding HIGH CONFIRMED "Home directories writable by all users" "$(trim "$bad_w")" "sudo chmod 750 <home> (or 700)."
    [[ -n "$bad_r" ]] && add_finding LOW POTENTIAL "Home directories readable by all users" "$(trim "$bad_r")" \
        "Consider chmod 750 so other users cannot browse personal files (Ubuntu < 21.04 created homes as 755)."
    return 0
}
