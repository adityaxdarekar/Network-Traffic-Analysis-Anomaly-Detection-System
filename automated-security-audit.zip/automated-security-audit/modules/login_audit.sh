#!/usr/bin/env bash
# shellcheck shell=bash
# Module 9: Login and Authentication Audit
#   Sources (first that is readable):
#     /var/log/auth.log (+ auth.log.1)   Ubuntu, Debian, Kali with rsyslog
#     /var/log/secure                     RHEL family
#     journalctl                          Kali 2023+ and other journald-only systems
#   Both "Nov  8 21:00:01 host ..." and ISO "2026-11-08T21:00:01.123+00:00 host ..."
#   timestamps are understood.
#
#   Detects: failed SSH passwords (per IP / per user), invalid-user guessing,
#   attempts against root, successful logins after many failures from the same IP,
#   sudo and su failures, local console failures. Counting avoids duplicates:
#   for sshd only "Failed password" lines are counted (the PAM line for the same
#   attempt is ignored); for sudo only "incorrect password attempts" lines.

AUTH_LOG_FILES="${AUTH_LOG_FILES:-/var/log/auth.log.1 /var/log/auth.log /var/log/secure}"
LOGIN_SOURCE="${LOGIN_SOURCE:-auto}"          # auto | files | journal
LOGIN_DAYS="${LOGIN_DAYS:-7}"                 # journal look-back
FAIL_THRESHOLD="${FAIL_THRESHOLD:-5}"         # failures from one IP -> MEDIUM
BRUTE_THRESHOLD="${BRUTE_THRESHOLD:-20}"      # failures from one IP -> HIGH
GUESS_USERS="${GUESS_USERS:-3}"               # distinct invalid user names from one IP

# normalise log lines to events:  TYPE|timestamp|user|ip   (TYPE: FAIL SUCCESS INVALID SUDOFAIL SUFAIL LOCALFAIL MAXTRIES)
login_events() {
    awk '
    {
        if ($1 ~ /^[0-9][0-9][0-9][0-9]-/) { ts=$1; prog=$3; m=4 } else { ts=$1" "$2" "$3; prog=$5; m=6 }
        msg=""; for (i=m; i<=NF; i++) msg = msg (i>m?" ":"") $i
        sub(/\[[0-9]+\]:$/, "", prog); sub(/:$/, "", prog)
        if (msg ~ /^Failed password for invalid user /) { split(msg, w, " "); print "FAIL|" ts "|" w[6] "|" w[8] "|invalid"; next }
        if (msg ~ /^Failed password for /)              { split(msg, w, " "); print "FAIL|" ts "|" w[4] "|" w[6] "|"; next }
        if (msg ~ /^Invalid user /)                     { split(msg, w, " "); u=w[3]; ip=w[5]; if (w[4]!="from") { u=""; ip=w[4] } print "INVALID|" ts "|" u "|" ip "|"; next }
        if (msg ~ /^Accepted (password|publickey|keyboard-interactive)/) { split(msg, w, " "); print "SUCCESS|" ts "|" w[4] "|" w[6] "|" w[2]; next }
        if (msg ~ /maximum authentication attempts exceeded for/) {
            n=split(msg, w, " "); for (i=1;i<=n;i++) if (w[i]=="from") { print "MAXTRIES|" ts "|" w[i-1] "|" w[i+1] "|"; break }; next }
        if (prog ~ /^sudo/ && msg ~ /incorrect password attempt/) {
            split(msg, w, " "); c=w[3]+0; if (c<1) c=1; for (k=0;k<c;k++) print "SUDOFAIL|" ts "|" w[1] "||"; next }
        if (msg ~ /^FAILED SU/)   { n=split(msg, w, " "); print "SUFAIL|" ts "|" w[5] "||" w[3]; next }
        if (msg ~ /^FAILED LOGIN/) { u=msg; sub(/.*FOR .?/, "", u); sub(/.?, .*/, "", u); print "LOCALFAIL|" ts "|" u "||"; next }
        if (prog ~ /^(login|gdm-password|lightdm|sddm)/ && msg ~ /authentication failure/) {
            u=""; if (match(msg, /user=[^ ]+/)) u=substr(msg, RSTART+5, RLENGTH-5); print "LOCALFAIL|" ts "|" u "||"; next }
    }'
}

login_read_source() {   # prints raw log lines; sets LOGIN_SRC
    local f used=() unreadable=()
    if [[ "$LOGIN_SOURCE" != "journal" ]]; then
        for f in $AUTH_LOG_FILES; do
            [[ -e "$f" ]] || continue
            if can_read "$f"; then used+=("$f"); else unreadable+=("$f"); fi
        done
        if (( ${#used[@]} )); then LOGIN_SRC="${used[*]}"; cat -- "${used[@]}" 2>/dev/null; return 0; fi
        if (( ${#unreadable[@]} )); then LOGIN_UNREADABLE="${unreadable[*]}"; fi
    fi
    if [[ "$LOGIN_SOURCE" != "files" ]] && have_cmd journalctl; then
        # -t selects by syslog identifier (repeatable = OR): sshd, sudo, su, login, display managers
        local j; j=$(run_limited 60 journalctl --no-pager -q -o short-iso --since "-${LOGIN_DAYS} days" \
            -t sshd -t sshd-session -t sudo -t su -t login -t gdm-password -t lightdm 2>/dev/null)
        if [[ -n "$j" ]]; then LOGIN_SRC="journalctl (last $LOGIN_DAYS days)"; printf '%s\n' "$j"; return 0; fi
    fi
    return 1
}

audit_login() {
    section_header "09_login" "Module 9: Login & Authentication Audit"
    local raw="$AUDIT_TMP/auth_raw.log" ev="$AUDIT_TMP/auth_events.txt"
    LOGIN_SRC=""; LOGIN_UNREADABLE=""
    if ! login_read_source >"$raw"; then
        if [[ -n "$LOGIN_UNREADABLE" ]]; then
            skip_check "authentication logs exist but need root or the 'adm' group: $LOGIN_UNREADABLE"
        else
            skip_check "no authentication log source found (no auth.log/secure file and no readable journal)"
        fi
        return 0
    fi
    login_events <"$raw" >"$ev"
    kv "Source" "$LOGIN_SRC"
    kv "Log lines analysed" "$(wc -l <"$raw" | tr -d ' ')"
    local nf ns ni nsudo nsu nloc
    nf=$(grep -c '^FAIL|' "$ev"); ns=$(grep -c '^SUCCESS|' "$ev"); ni=$(grep -c '^INVALID|' "$ev")
    nsudo=$(grep -c '^SUDOFAIL|' "$ev"); nsu=$(grep -c '^SUFAIL|' "$ev"); nloc=$(grep -c '^LOCALFAIL|' "$ev")
    kv "Failed SSH passwords" "$nf"
    kv "Invalid-user attempts" "$ni"
    kv "Successful SSH logins" "$ns"
    kv "sudo / su failures" "$nsudo / $nsu"
    kv "Local login failures" "$nloc"
    if (( nf + ni + nsudo + nsu + nloc == 0 )); then ok "No failed authentication attempts recorded"; fi

    # ---- per-IP aggregation: failures, distinct users, invalid names, first/last, success after failures
    local agg="$AUDIT_TMP/auth_ip.txt"
    awk -F'|' '
        $1=="FAIL" || $1=="INVALID" { ip=$4; if (ip=="") next
            all[ip]=1; if (!(ip in first)) first[ip]=$2; last[ip]=$2
            key=ip SUBSEP $3; if ($3!="" && !(key in seen)) { seen[key]=1; users[ip]=users[ip] (users[ip]?",":"") $3 }
            if ($1=="FAIL") { f[ip]++; if (!(ip in firstn)) firstn[ip]=NR }
            if ($1=="INVALID" || $5=="invalid") { if (!(key in inv)) { inv[key]=1; ninv[ip]++ } } }
        $1=="SUCCESS" { if (($4 in firstn) && NR>firstn[$4]) { succ[$4]=$2 " (" $3 ")" } }
        END { for (ip in all) printf "%s|%d|%d|%s|%s|%s|%s\n", ip, f[ip]+0, ninv[ip]+0, users[ip], first[ip], last[ip], succ[ip] }
    ' "$ev" | sort -t'|' -k2,2nr >"$agg"
    if [[ -s "$agg" ]]; then
        sub "Failed SSH logins / invalid users by source IP"
        out "$(printf '    %-18s %6s %8s  %-26s %-26s %s' IP FAILS INVALID FIRST LAST USERNAMES)"
        local ip c ninv users first last succ shown=0
        while IFS='|' read -r ip c ninv users first last succ; do
            shown=$((shown+1)); (( shown > ${LIST_LIMIT:-15} )) && { out "    ... more IPs omitted"; break; }
            out "$(printf '    %-18s %6s %8s  %-26s %-26s %s' "$ip" "$c" "$ninv" "${first:0:26}" "${last:0:26}" "${users:0:60}")"
        done <"$agg"
        while IFS='|' read -r ip c ninv users first last succ; do
            if (( c >= BRUTE_THRESHOLD )); then
                add_finding HIGH CONFIRMED "SSH brute-force attempts from $ip ($c failed passwords)" \
                    "Users tried: ${users:0:120}; first $first, last $last" \
                    "Block the source at the firewall after review (e.g. sudo ufw deny from $ip), use keys only, consider fail2ban."
            elif (( c >= FAIL_THRESHOLD )); then
                add_finding MEDIUM POTENTIAL "Repeated failed SSH logins from $ip ($c)" "Users: ${users:0:120}; $first .. $last" \
                    "Check whether this is a user who forgot a password or an attack; rate-limit SSH (sudo ufw limit OpenSSH)."
            fi
            if (( ninv >= GUESS_USERS )); then
                add_finding MEDIUM POTENTIAL "Username guessing from $ip ($ninv non-existent user names)" "Names: ${users:0:120}" \
                    "Typical of automated scanners; disable password authentication and restrict SSH access."
            fi
            if [[ -n "$succ" ]] && (( c >= FAIL_THRESHOLD )); then
                add_finding CRITICAL POTENTIAL "Successful login from $ip after $c failed attempts" "Accepted login: $succ" \
                    "Verify with the account owner immediately; if not legitimate: lock the account, rotate credentials, investigate the host."
            fi
        done <"$agg"
    fi

    # ---- root attempts and root logins
    local rootfail rootok
    rootfail=$(awk -F'|' '$1=="FAIL" && $3=="root"' "$ev" | wc -l | tr -d ' ')
    rootok=$(awk -F'|' '$1=="SUCCESS" && $3=="root" {print $2 " from " $4 " (" $5 ")"}' "$ev" | tail -3 | tr '\n' ';')
    if (( rootfail > 0 )); then
        add_finding MEDIUM POTENTIAL "$rootfail failed SSH password attempts against root" "" \
            "Set 'PermitRootLogin no' (Module 7) so root passwords cannot be guessed over SSH."
    fi
    if [[ -n "$rootok" ]]; then
        add_finding MEDIUM CONFIRMED "Direct root logins over SSH occurred" "$rootok" "Log in as a named user and use sudo, for accountability."
    fi

    # ---- per-user failures (top 10)
    if (( nf + nsudo + nsu + nloc > 0 )); then
        sub "Failed attempts by user name"
        awk -F'|' '$1 ~ /FAIL$/ && $3!="" {c[$3]++; t[$3]=$1} END {for (u in c) printf "%6d  %-20s (%s)\n", c[u], u, t[u]}' "$ev" | sort -nr | head -10 | list_block
        sub "Most recent failures"
        grep -E '^(FAIL|SUDOFAIL|SUFAIL|LOCALFAIL)\|' "$ev" | tail -8 | awk -F'|' '{printf "%-28s %-9s user=%-14s %s\n", $2, $1, $3, ($4!=""?"from " $4:"")}' | list_block
    fi
    local u n
    while read -r n u; do
        [[ -z "$u" ]] && continue
        (( n >= 3 )) && add_finding LOW POTENTIAL "$n failed sudo password attempts by $u" "" "Confirm with $u; repeated sudo failures can mean a stolen session trying to escalate."
    done < <(awk -F'|' '$1=="SUDOFAIL" {c[$3]++} END {for (u in c) print c[u], u}' "$ev")
    if (( nsu >= 3 )); then add_finding LOW POTENTIAL "$nsu failed 'su' attempts" "" "Review who is trying to switch user (journalctl -t su)."; fi
    if (( nloc >= FAIL_THRESHOLD )); then add_finding LOW POTENTIAL "$nloc failed local/console logins" "" "Check physical/console access to the machine."; fi
    return 0
}
