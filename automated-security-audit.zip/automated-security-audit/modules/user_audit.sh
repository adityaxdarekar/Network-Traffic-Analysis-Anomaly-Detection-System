#!/usr/bin/env bash
# shellcheck shell=bash
# Module 2: User Account Security Audit
#   UID 0 accounts, duplicate UIDs, empty passwords (needs root to read /etc/shadow),
#   accounts with login shells, inactive accounts (lastlog), password ageing,
#   risky sudo rules (NOPASSWD, !authenticate, broad ALL rules) and sudoers permissions.

PASSWD_FILE="${PASSWD_FILE:-/etc/passwd}"
SHADOW_FILE="${SHADOW_FILE:-/etc/shadow}"
GROUP_FILE="${GROUP_FILE:-/etc/group}"
SUDOERS_FILE="${SUDOERS_FILE:-/etc/sudoers}"
SUDOERS_DIR="${SUDOERS_DIR:-/etc/sudoers.d}"
LOGIN_DEFS="${LOGIN_DEFS:-/etc/login.defs}"
INACTIVE_DAYS="${INACTIVE_DAYS:-90}"
NOLOGIN_RE='(/nologin|/false|/sync|/shutdown|/halt)$'

uid_min() {
    local v=""
    [[ -r "$LOGIN_DEFS" ]] && v=$(awk '$1=="UID_MIN"{print $2; exit}' "$LOGIN_DEFS")
    printf '%s' "${v:-1000}"
}

audit_users() {
    section_header "02_users" "Module 2: User Account Security Audit"
    [[ -r "$PASSWD_FILE" ]] || { skip_check "cannot read $PASSWD_FILE"; return 0; }
    local umin; umin=$(uid_min)

    # ---- UID 0 and duplicate UIDs
    local uid0; uid0=$(awk -F: '$3==0 {print $1}' "$PASSWD_FILE" | tr '\n' ' ')
    kv "Accounts with UID 0" "$(trim "${uid0:-none}")"
    local extra; extra=$(awk -F: '$3==0 && $1!="root" {print $1}' "$PASSWD_FILE" | tr '\n' ' ')
    if [[ -n "$extra" ]]; then
        add_finding CRITICAL CONFIRMED "Account(s) other than root have UID 0: $(trim "$extra")" \
            "UID 0 gives full root privileges regardless of the user name." \
            "Investigate immediately; give the account a unique non-zero UID or remove it after confirming it is not legitimate."
    else ok "Only root has UID 0"; fi
    local dup; dup=$(awk -F: '{c[$3]++; n[$3]=n[$3]" "$1} END{for(u in c) if(c[u]>1) print u":"n[u]}' "$PASSWD_FILE")
    if [[ -n "$dup" ]]; then
        add_finding HIGH CONFIRMED "Duplicate UIDs shared by several accounts" "$(printf '%s' "$dup" | tr '\n' ';')" \
            "Give every account a unique UID so file ownership and audit trails stay unambiguous."
    fi

    # ---- login shells
    local shells; shells=$(awk -F: -v re="$NOLOGIN_RE" '$7!="" && $7 !~ re {print $1" (uid "$3", "$7")"}' "$PASSWD_FILE")
    sub "Accounts with a login shell ($(printf '%s\n' "$shells" | grep -c . ))"
    printf '%s\n' "$shells" | grep . | list_block
    local sysshell; sysshell=$(awk -F: -v re="$NOLOGIN_RE" -v m="$umin" '$3>0 && $3<m && $7!="" && $7 !~ re {print $1}' "$PASSWD_FILE" | tr '\n' ' ')
    if [[ -n "$sysshell" ]]; then
        add_finding LOW POTENTIAL "System accounts with interactive login shells: $(trim "$sysshell")" \
            "Service accounts (UID < $umin) normally use /usr/sbin/nologin." \
            "If an account does not need interactive logins: sudo usermod -s /usr/sbin/nologin <user>"
    fi

    # ---- shadow: empty passwords and password ageing
    if can_read "$SHADOW_FILE"; then
        local empty; empty=$(awk -F: '$2=="" {print $1}' "$SHADOW_FILE" | tr '\n' ' ')
        if [[ -n "$empty" ]]; then
            add_finding CRITICAL CONFIRMED "Accounts with an EMPTY password: $(trim "$empty")" \
                "These accounts can log in without any password (where the service allows empty passwords)." \
                "Set a password (sudo passwd <user>) or lock the account (sudo passwd -l <user>)."
        else ok "No accounts with empty passwords"; fi
        local human noexp=""
        for human in $(awk -F: -v re="$NOLOGIN_RE" -v m="$umin" '$3>=m && $3<60000 && $7 !~ re {print $1}' "$PASSWD_FILE"); do
            awk -F: -v u="$human" '$1==u && $2 !~ /^[!*]/ && ($5=="" || $5>=99999) {f=1} END{exit !f}' "$SHADOW_FILE" && noexp+="$human "
        done
        if [[ -n "$noexp" ]]; then
            add_finding LOW POTENTIAL "Passwords that never expire: $(trim "$noexp")" \
                "Maximum password age is unset or 99999 days." \
                "Consider a password policy (sudo chage -M 365 <user>) or key-based logins; follow your organisation's policy."
        fi
        local locked; locked=$(awk -F: '$2 ~ /^[!*]/ {n++} END{print n+0}' "$SHADOW_FILE")
        kv "Locked / no-password accounts" "$locked"
    else
        skip_check "empty-password and password-ageing checks need root (cannot read $SHADOW_FILE)"
    fi

    # ---- inactive accounts (only when lastlog gives reliable data)
    if have_cmd lastlog && [[ "${SKIP_LASTLOG:-0}" != "1" ]]; then
        local never="" old="" u
        for u in $(awk -F: -v re="$NOLOGIN_RE" -v m="$umin" '$3>=m && $3<60000 && $7 !~ re {print $1}' "$PASSWD_FILE"); do
            local rec; rec=$(lastlog -u "$u" 2>/dev/null | tail -n +2)
            [[ -z "$rec" ]] && continue
            if [[ "$rec" == *"Never logged in"* ]]; then never+="$u "
            elif [[ -n "$(lastlog -b "$INACTIVE_DAYS" -u "$u" 2>/dev/null | tail -n +2)" ]]; then old+="$u "; fi
        done
        kv "Never logged in" "$(trim "${never:-none}")"
        if [[ -n "$old" ]]; then
            add_finding LOW POTENTIAL "Accounts inactive for more than $INACTIVE_DAYS days: $(trim "$old")" \
                "Last login older than $INACTIVE_DAYS days (from lastlog)." \
                "Disable accounts that are no longer needed: sudo usermod -L -e 1 <user> (after confirming with the owner)."
        fi
        if [[ -n "$never" ]]; then
            add_finding INFO INFO "Login-capable accounts that never logged in: $(trim "$never")" "" \
                "Remove or lock accounts that are not used."
        fi
    else
        skip_check "inactive-account check: lastlog not available (login records cannot be read reliably)"
    fi

    audit_sudo
}

audit_sudo() {
    sub "Sudo privileges"
    local groups_line g members
    for g in sudo admin wheel; do
        members=$(awk -F: -v g="$g" '$1==g {print $4}' "$GROUP_FILE" 2>/dev/null)
        [[ -n "$members" ]] && kv "Members of group '$g'" "$members"
        groups_line+="$members,"
    done
    local nadm; nadm=$(printf '%s' "$groups_line" | tr ',' '\n' | grep -c .)
    if (( nadm > ${MAX_ADMINS:-3} )); then
        add_finding LOW POTENTIAL "$nadm users have full administrator (sudo) rights" "Group members: $(printf '%s' "$groups_line" | tr -s ',' ' ')" \
            "Keep administrative access to the smallest group that needs it."
    fi

    local files=()
    [[ -e "$SUDOERS_FILE" ]] && files+=("$SUDOERS_FILE")
    if [[ -d "$SUDOERS_DIR" ]]; then
        local f; for f in "$SUDOERS_DIR"/*; do [[ -f "$f" ]] && files+=("$f"); done
    fi
    if (( ${#files[@]} == 0 )); then out "    no sudoers files found"; return 0; fi

    local f mode perm_bad="" unreadable=0
    for f in "${files[@]}"; do
        mode=$(stat -c '%a' "$f" 2>/dev/null)
        [[ -n "$mode" ]] && (( (8#$mode & 8#022) != 0 )) && perm_bad+="$f ($mode) "
    done
    if [[ -n "$perm_bad" ]]; then
        add_finding HIGH CONFIRMED "Sudoers file writable by group or others: $(trim "$perm_bad")" \
            "Anyone able to write a sudoers file can grant themselves root." "sudo chmod 0440 <file> (and keep owner root:root)."
    fi
    local rules="" nopass="" noauth="" allall=""
    for f in "${files[@]}"; do
        if ! can_read "$f"; then unreadable=$((unreadable+1)); continue; fi
        # strip comments (but keep #include lines out of rules), join continuation lines
        local content; content=$(sed -e 's/\\$//' "$f" | grep -vE '^[[:space:]]*(#|$)|^[[:space:]]*Defaults|^[[:space:]]*@include|^[[:space:]]*#include')
        rules+="$content"$'\n'
        nopass+=$(printf '%s\n' "$content" | grep -E 'NOPASSWD' | sed "s|^|$(basename "$f"): |")$'\n'
        noauth+=$(grep -E '^[[:space:]]*Defaults.*!authenticate' "$f" 2>/dev/null | sed "s|^|$(basename "$f"): |")$'\n'
        allall+=$(printf '%s\n' "$content" | grep -E '^[[:space:]]*[^%[:space:]][^[:space:]]*[[:space:]]+ALL[[:space:]]*=[[:space:]]*(\([^)]*\))?[[:space:]]*(NOPASSWD:[[:space:]]*)?ALL[[:space:]]*$' \
            | grep -vE '^[[:space:]]*root[[:space:]]' | sed "s|^|$(basename "$f"): |")$'\n'
    done
    if (( unreadable )); then skip_check "$unreadable sudoers file(s) unreadable without root - NOPASSWD rules not checked"; fi
    if [[ -n "$(trim "$rules")" ]]; then out "    active rules:"; printf '%s' "$rules" | grep . | list_block; fi
    nopass=$(printf '%s' "$nopass" | grep .)
    noauth=$(printf '%s' "$noauth" | grep .)
    allall=$(printf '%s' "$allall" | grep .)
    if [[ -n "$noauth" ]]; then
        add_finding CRITICAL CONFIRMED "sudo authentication disabled (Defaults !authenticate)" "$(printf '%s' "$noauth" | tr '\n' ';')" \
            "Remove '!authenticate' so sudo always asks for a password (edit with sudo visudo)."
    fi
    if [[ -n "$nopass" ]]; then
        if printf '%s' "$nopass" | grep -qE 'NOPASSWD:[[:space:]]*ALL'; then
            add_finding HIGH CONFIRMED "Passwordless sudo for ALL commands (NOPASSWD: ALL)" "$(printf '%s' "$nopass" | tr '\n' ';')" \
                "Require a password (remove NOPASSWD) or restrict the rule to specific commands via sudo visudo."
        else
            add_finding MEDIUM POTENTIAL "Passwordless sudo rules for specific commands" "$(printf '%s' "$nopass" | tr '\n' ';')" \
                "Check each command cannot be abused to get a shell (e.g. editors, find, less)."
        fi
    else
        (( unreadable )) || ok "No NOPASSWD sudo rules"
    fi
    if [[ -n "$allall" ]]; then
        add_finding INFO INFO "Individual users with full sudo rights (ALL)" "$(printf '%s' "$allall" | tr '\n' ';')" \
            "Prefer granting rights through the sudo group so they are easy to review."
    fi
}
