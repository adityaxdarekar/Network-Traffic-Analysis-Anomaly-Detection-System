#!/usr/bin/env bash
# shellcheck shell=bash
# Module 6: Running Services Audit
#   running and enabled systemd services, failed units, and services that are
#   often unnecessary or insecure. Only RECOMMENDATIONS are given: the audit never
#   stops, disables or masks a service. The lists below are configurable in
#   config/audit.conf - a service in them may be perfectly legitimate on your host.

# name:severity:reason
LEGACY_SERVICES="${LEGACY_SERVICES:-telnet:HIGH:cleartext_remote_login telnetd:HIGH:cleartext_remote_login \
inetd:HIGH:legacy_super-server xinetd:HIGH:legacy_super-server rsh:HIGH:cleartext_r-services rlogin:HIGH:cleartext_r-services \
rexec:HIGH:cleartext_r-services tftpd-hpa:HIGH:TFTP_has_no_authentication tftp:HIGH:TFTP_has_no_authentication \
vsftpd:MEDIUM:FTP_sends_credentials_in_cleartext proftpd:MEDIUM:FTP_sends_credentials_in_cleartext \
pure-ftpd:MEDIUM:FTP_sends_credentials_in_cleartext x11vnc:MEDIUM:remote_desktop_exposure \
vncserver:MEDIUM:remote_desktop_exposure snmpd:MEDIUM:SNMP_often_uses_default_communities}"
OPTIONAL_SERVICES="${OPTIONAL_SERVICES:-avahi-daemon cups cups-browsed bluetooth rpcbind nfs-server smbd nmbd \
ModemManager whoopsie kerneloops apport postfix exim4 sendmail openvpn xrdp}"
SERVER_SERVICES="${SERVER_SERVICES:-apache2 nginx lighttpd mysql mariadb postgresql redis-server mongod docker \
containerd elasticsearch memcached tomcat9 jenkins}"

audit_services() {
    section_header "06_services" "Module 6: Running Services Audit"
    if ! systemd_running; then
        skip_check "systemd is not running (container or non-systemd init) - service checks use the process list only"
        if have_cmd ps; then
            sub "Running processes (top 15 by memory)"
            ps -eo user=,pid=,comm= --sort=-rss 2>/dev/null | head -15 | list_block
        fi
        return 0
    fi
    local running enabled failed
    running=$(systemctl list-units --type=service --state=running --no-legend --no-pager --plain 2>/dev/null | awk '{print $1}' | sed 's/\.service$//' | sort)
    enabled=$(systemctl list-unit-files --type=service --state=enabled --no-legend --no-pager 2>/dev/null | awk '{print $1}' | sed 's/\.service$//' | sort)
    failed=$(systemctl list-units --type=service --state=failed --no-legend --no-pager --plain 2>/dev/null | awk '{print $1}' | sed 's/\.service$//')
    kv "Running services" "$(printf '%s\n' "$running" | grep -c .)"
    kv "Enabled at startup" "$(printf '%s\n' "$enabled" | grep -c .)"
    sub "Running services"
    printf '%s\n' "$running" | grep . | while IFS= read -r s; do
        printf '%s%s\n' "$s" "$(printf '%s\n' "$enabled" | grep -qx "$s" && printf '   [enabled at boot]')"
    done | LIST_LIMIT=40 list_block

    if [[ -n "$(trim "$failed")" ]]; then
        add_finding LOW CONFIRMED "Failed services: $(printf '%s' "$failed" | tr '\n' ' ')" "Failed units may indicate misconfiguration or tampering." \
            "Inspect with: systemctl status <service> and journalctl -u <service>"
    fi

    local spec name sev reason active_or_enabled flagged=0
    for spec in $LEGACY_SERVICES; do
        IFS=: read -r name sev reason <<<"$spec"
        if printf '%s\n%s\n' "$running" "$enabled" | grep -qxE "${name}(@)?"; then
            add_finding "$sev" POTENTIAL "Insecure/legacy service active: $name" "${reason//_/ }; $(svc_state "$name" "$running" "$enabled")" \
                "If not required: sudo systemctl disable --now $name (the audit does not do this for you)."
            flagged=$((flagged+1))
        fi
    done
    local opt="" srv=""
    for name in $OPTIONAL_SERVICES; do
        printf '%s\n%s\n' "$running" "$enabled" | grep -qx "$name" && opt+="$name ($(svc_state "$name" "$running" "$enabled")) "
    done
    for name in $SERVER_SERVICES; do
        printf '%s\n' "$running" | grep -qx "$name" && srv+="$name "
    done
    if [[ -n "$opt" ]]; then
        add_finding LOW POTENTIAL "Services that are often unnecessary on servers/lab machines" "$(trim "$opt")" \
            "Keep them only if used (printing, mDNS, Bluetooth, NFS/SMB sharing...): sudo systemctl disable --now <service>."
        flagged=$((flagged+1))
    fi
    if [[ -n "$srv" ]]; then
        add_finding INFO INFO "Server software running: $(trim "$srv")" "Check each is intended, patched and not exposed more than needed (see Module 4)." \
            "Confirm ownership and purpose of each server process."
    fi
    (( flagged == 0 )) && ok "No legacy or commonly unnecessary services found"
    return 0
}

svc_state() {   # svc_state name running enabled -> "running, enabled at boot"
    local s=()
    printf '%s\n' "$2" | grep -qx "$1" && s+=("running")
    printf '%s\n' "$3" | grep -qx "$1" && s+=("enabled at boot")
    if (( ${#s[@]} == 0 )); then printf 'inactive'; elif (( ${#s[@]} == 1 )); then printf '%s' "${s[0]}"; else printf '%s, %s' "${s[0]}" "${s[1]}"; fi
}
