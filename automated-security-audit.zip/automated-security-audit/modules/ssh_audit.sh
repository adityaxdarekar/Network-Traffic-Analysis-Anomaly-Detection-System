#!/usr/bin/env bash
# shellcheck shell=bash
# Module 7: SSH Security Audit
#   Is the OpenSSH server installed and running? Which settings are in effect?
#   PermitRootLogin, PasswordAuthentication, PubkeyAuthentication,
#   PermitEmptyPasswords and other insecure values.
#
# Effective configuration:
#   * as root, `sshd -T` prints exactly what sshd will use (most reliable)
#   * otherwise sshd_config is parsed like sshd does: Include files are read
#     where they appear, the FIRST value of a keyword wins, and parsing of
#     global settings stops at the first "Match" block
#   * keywords that are not set get the OpenSSH default (marked "(default)")
# The configuration is only read - never modified.

SSHD_CONFIG="${SSHD_CONFIG:-/etc/ssh/sshd_config}"
SSH_USE_SSHD_T="${SSH_USE_SSHD_T:-1}"
SSHD_CMD="${SSHD_CMD:-sshd}"
SSHD_BIN_PATH="${SSHD_BIN_PATH:-/usr/sbin/sshd}"

declare -A SSH_DEFAULTS=(
    [permitrootlogin]="prohibit-password" [passwordauthentication]="yes" [pubkeyauthentication]="yes"
    [permitemptypasswords]="no" [x11forwarding]="no" [maxauthtries]="6" [permituserenvironment]="no"
    [hostbasedauthentication]="no" [ignorerhosts]="yes" [port]="22" [loglevel]="INFO"
    [kbdinteractiveauthentication]="yes" [usepam]="no" [logingracetime]="120" [clientaliveinterval]="0"
)

ssh_parse_file() {   # ssh_parse_file path  -> "key value" lines (global section only)
    local file="$1" line key val inc
    [[ -r "$file" ]] || return 0
    while IFS= read -r line || [[ -n "$line" ]]; do
        line=$(trim "${line%%#*}")
        [[ -z "$line" ]] && continue
        key=${line%%[[:space:]=]*}; val=$(trim "${line#"$key"}"); val=$(trim "${val#=}")
        key=${key,,}
        if [[ "$key" == "match" ]]; then SSH_IN_MATCH=1; return 0; fi
        if [[ "$key" == "include" ]]; then
            local pattern
            for pattern in $val; do
                [[ "$pattern" != /* ]] && pattern="$(dirname "$SSHD_CONFIG")/$pattern"
                for inc in $pattern; do
                    [[ -f "$inc" ]] && ssh_parse_file "$inc"
                    (( SSH_IN_MATCH )) && return 0
                done
            done
            continue
        fi
        printf '%s %s\n' "$key" "$val"
    done <"$file"
}

ssh_load_config() {
    declare -gA SSHCFG=() SSHSRC=()
    local k v
    SSH_CFG_SOURCE="parsed $SSHD_CONFIG"
    if [[ "$SSH_USE_SSHD_T" == "1" ]] && is_root && have_cmd "$SSHD_CMD"; then
        local t; t=$(run_limited 15 "$SSHD_CMD" -T 2>/dev/null)
        if [[ -n "$t" ]]; then
            while read -r k v; do [[ -n "$k" && -z "${SSHCFG[$k]:-}" ]] && { SSHCFG[$k]="$v"; SSHSRC[$k]="effective"; }; done <<<"$t"
            SSH_CFG_SOURCE="sshd -T (effective configuration)"
            return 0
        fi
    fi
    SSH_IN_MATCH=0
    while read -r k v; do
        [[ -n "$k" && -z "${SSHCFG[$k]:-}" ]] && { SSHCFG[$k]="$v"; SSHSRC[$k]="set"; }
    done < <(ssh_parse_file "$SSHD_CONFIG")
    for k in "${!SSH_DEFAULTS[@]}"; do
        [[ -z "${SSHCFG[$k]:-}" ]] && { SSHCFG[$k]="${SSH_DEFAULTS[$k]}"; SSHSRC[$k]="default"; }
    done
}

sshv() { printf '%s' "${SSHCFG[$1]:-}" | tr 'A-Z' 'a-z'; }
shown() { printf '%s%s' "${SSHCFG[$1]:-?}" "$( [[ "${SSHSRC[$1]:-}" == "default" ]] && printf ' (default)')"; }

audit_ssh() {
    section_header "07_ssh" "Module 7: SSH Security Audit"
    local installed="no" running="no"
    if have_cmd "$SSHD_CMD" || [[ -x "$SSHD_BIN_PATH" ]] || dpkg -s openssh-server >/dev/null 2>&1; then installed="yes"; fi
    if systemd_running && { systemctl is-active --quiet ssh 2>/dev/null || systemctl is-active --quiet sshd 2>/dev/null; }; then running="yes"
    elif have_cmd pgrep && pgrep -x sshd >/dev/null 2>&1; then running="yes"; fi
    kv "OpenSSH server installed" "$installed"
    kv "SSH server running" "$running"
    if [[ "$installed" == "no" && ! -f "$SSHD_CONFIG" ]]; then
        ok "No SSH server installed - nothing to audit (remote shell access is not offered)"
        return 0
    fi
    if [[ ! -r "$SSHD_CONFIG" ]]; then skip_check "cannot read $SSHD_CONFIG"; return 0; fi
    ssh_load_config
    kv "Configuration source" "$SSH_CFG_SOURCE"
    local k
    for k in port permitrootlogin passwordauthentication pubkeyauthentication permitemptypasswords kbdinteractiveauthentication \
             x11forwarding maxauthtries permituserenvironment hostbasedauthentication ignorerhosts loglevel logingracetime; do
        kv "$k" "$(shown "$k")"
    done
    [[ -n "${SSHCFG[allowusers]:-}" ]] && kv "allowusers" "${SSHCFG[allowusers]}"
    [[ -n "${SSHCFG[allowgroups]:-}" ]] && kv "allowgroups" "${SSHCFG[allowgroups]}"

    # when sshd is not running, the settings only matter once it is started -> potential
    local T="CONFIRMED"; [[ "$running" == "yes" ]] || T="POTENTIAL"
    local note=""; [[ "$running" == "yes" ]] || note=" (sshd is not running now; applies when it starts)"
    local prl pa pk pe; prl=$(sshv permitrootlogin); pa=$(sshv passwordauthentication); pk=$(sshv pubkeyauthentication); pe=$(sshv permitemptypasswords)

    if [[ "$pe" == "yes" ]]; then
        add_finding CRITICAL "$T" "PermitEmptyPasswords yes" "Accounts without a password can log in over SSH$note." \
            "Set 'PermitEmptyPasswords no' in $SSHD_CONFIG, then: sudo sshd -t && sudo systemctl reload ssh"
    fi
    if [[ "$prl" == "yes" ]]; then
        if [[ "$pa" == "yes" ]]; then
            add_finding CRITICAL "$T" "Root can log in over SSH with a password" "PermitRootLogin yes + PasswordAuthentication $(shown passwordauthentication)$note." \
                "Set 'PermitRootLogin no' (log in as a normal user and use sudo), then reload sshd."
        else
            add_finding HIGH "$T" "PermitRootLogin yes" "Direct root logins are allowed$note." "Set 'PermitRootLogin no' (or prohibit-password if root key logins are required)."
        fi
    elif [[ "$prl" == "no" ]]; then ok "PermitRootLogin no"
    else ok "PermitRootLogin $(shown permitrootlogin) - root cannot log in with a password"; fi

    if [[ "$pa" == "yes" ]]; then
        add_finding MEDIUM POTENTIAL "SSH password authentication is enabled" "PasswordAuthentication $(shown passwordauthentication) - passwords can be brute-forced$note." \
            "Use SSH keys and set 'PasswordAuthentication no' (test key login in a second session first)."
    else ok "PasswordAuthentication no"; fi
    if [[ "$pk" == "no" ]]; then
        add_finding MEDIUM "$T" "PubkeyAuthentication is disabled" "Key-based logins (the safer method) are not allowed$note." "Set 'PubkeyAuthentication yes'."
    else ok "PubkeyAuthentication $(shown pubkeyauthentication)"; fi

    [[ "$(sshv x11forwarding)" == "yes" ]] && add_finding LOW "$T" "X11Forwarding yes" "Forwarded X11 sessions widen the attack surface$note." "Set 'X11Forwarding no' unless graphical forwarding is needed."
    local mat; mat=$(sshv maxauthtries)
    if [[ "$mat" =~ ^[0-9]+$ ]] && (( mat > 4 )); then
        add_finding LOW POTENTIAL "MaxAuthTries is $(shown maxauthtries)" "More password guesses per connection than recommended (CIS: 4 or fewer)." "Set 'MaxAuthTries 4'."
    fi
    [[ "$(sshv permituserenvironment)" == "yes" ]] && add_finding MEDIUM "$T" "PermitUserEnvironment yes" "Users can set environment variables (e.g. LD_PRELOAD) for sshd sessions$note." "Set 'PermitUserEnvironment no'."
    [[ "$(sshv hostbasedauthentication)" == "yes" ]] && add_finding MEDIUM "$T" "HostbasedAuthentication yes" "Trust is based on the client host, not the user$note." "Set 'HostbasedAuthentication no'."
    [[ "$(sshv ignorerhosts)" == "no" ]] && add_finding MEDIUM "$T" "IgnoreRhosts no" ".rhosts/.shosts files are honoured$note." "Set 'IgnoreRhosts yes'."
    [[ -n "${SSHCFG[protocol]:-}" && "${SSHCFG[protocol]}" == *1* ]] && add_finding MEDIUM CONFIRMED "Obsolete 'Protocol ${SSHCFG[protocol]}' line" "SSH protocol 1 is broken; modern OpenSSH ignores this keyword." "Remove the Protocol line."
    local weak; weak=$(printf '%s %s %s' "${SSHCFG[ciphers]:-}" "${SSHCFG[macs]:-}" "${SSHCFG[kexalgorithms]:-}" | tr ',' '\n' | grep -iE 'cbc|arcfour|3des|md5|-96|diffie-hellman-group1-' | tr '\n' ' ')
    if [[ -n "$weak" ]]; then
        if [[ "${SSHSRC[ciphers]:-}" == "effective" ]]; then
            add_finding LOW POTENTIAL "Weak algorithms enabled in the effective SSH configuration" "$(trim "$weak")" "Remove them from Ciphers/MACs/KexAlgorithms."
        else
            add_finding MEDIUM "$T" "Weak SSH algorithms configured" "$(trim "$weak")" "Remove CBC/arcfour/3DES ciphers, MD5/96-bit MACs and group1 key exchange."
        fi
    fi
    [[ "$(sshv loglevel)" == "quiet" ]] && add_finding LOW CONFIRMED "SSH LogLevel QUIET" "Logins are not logged." "Set 'LogLevel INFO' (or VERBOSE)."
    if [[ -z "${SSHCFG[allowusers]:-}${SSHCFG[allowgroups]:-}" ]]; then
        add_finding INFO INFO "No AllowUsers/AllowGroups restriction" "Every account with a valid credential may log in over SSH." "Optionally restrict SSH to a group: AllowGroups sshusers"
    fi
    [[ "$(sshv port)" == "22" ]] && out "  Port 22 is standard; changing it only reduces log noise, it is not a security control."
    return 0
}
