#!/usr/bin/env bash
# shellcheck shell=bash
# Module 1: System Information Audit
#   distribution and version, kernel, hostname, architecture, uptime,
#   logged-in users, virtualisation, pending reboot. Mostly informational.

OS_RELEASE_FILE="${OS_RELEASE_FILE:-/etc/os-release}"

audit_system_info() {
    section_header "01_system" "Module 1: System Information Audit"
    local name="unknown" version="" id="unknown" like=""
    if [[ -r "$OS_RELEASE_FILE" ]]; then
        name=$(sed -n 's/^PRETTY_NAME=//p' "$OS_RELEASE_FILE" | tr -d '"')
        version=$(sed -n 's/^VERSION_ID=//p' "$OS_RELEASE_FILE" | tr -d '"')
        id=$(sed -n 's/^ID=//p' "$OS_RELEASE_FILE" | tr -d '"')
        like=$(sed -n 's/^ID_LIKE=//p' "$OS_RELEASE_FILE" | tr -d '"')
    elif have_cmd lsb_release; then
        name=$(lsb_release -ds 2>/dev/null); id=$(lsb_release -is 2>/dev/null | tr 'A-Z' 'a-z')
    fi
    kv "Distribution" "${name:-unknown}"
    kv "Version" "${version:-n/a}"
    kv "Kernel" "$(uname -r 2>/dev/null || echo unknown)"
    kv "Hostname" "$(hostname 2>/dev/null || cat /proc/sys/kernel/hostname 2>/dev/null)"
    kv "Architecture" "$(uname -m 2>/dev/null)"
    local up=""
    up=$(uptime -p 2>/dev/null) || up=""
    if [[ -z "$up" && -r /proc/uptime ]]; then
        local s; s=$(cut -d. -f1 /proc/uptime); up="up $((s/86400)) days, $(((s%86400)/3600)) hours, $(((s%3600)/60)) minutes"
    fi
    kv "Uptime" "${up:-unknown}"
    if have_cmd systemd-detect-virt; then kv "Virtualisation" "$(systemd-detect-virt 2>/dev/null || echo none)"; fi
    kv "Audit mode" "$(is_root && echo 'root - full audit' || echo 'non-root - limited audit (some checks skipped)')"

    sub "Logged-in users"
    local users=""
    have_cmd who && users=$(who 2>/dev/null)
    if [[ -n "$users" ]]; then printf '%s\n' "$users" | list_block; else out "    (no interactive sessions reported by 'who')"; fi

    case "$id $like" in
        *ubuntu*|*kali*|*debian*) ok "Supported distribution family (${id})" ;;
        *) add_finding INFO INFO "Distribution not tested with this tool (${id})" \
               "The tool targets Ubuntu and Kali Linux; some checks may not apply." "Review module output manually." ;;
    esac
    if [[ -f "${REBOOT_REQUIRED_FILE:-/var/run/reboot-required}" ]]; then
        local pk=""; [[ -r /var/run/reboot-required.pkgs ]] && pk=$(tr '\n' ' ' </var/run/reboot-required.pkgs)
        add_finding LOW CONFIRMED "System restart required to finish applying updates" \
            "reboot-required flag present${pk:+ (packages: $pk)}" "Schedule a reboot so patched kernels/libraries are actually in use."
    fi
}
