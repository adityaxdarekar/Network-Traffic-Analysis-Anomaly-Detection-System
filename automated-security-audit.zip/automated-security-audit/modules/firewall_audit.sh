#!/usr/bin/env bash
# shellcheck shell=bash
# Module 5: Firewall Security Audit
#   UFW installed? active? default policies, configured rules, logging.
#   When UFW is absent, nftables / iptables rules are checked so a host
#   protected by another firewall is not reported as unprotected.
#   Reading firewall state needs root. The audit NEVER changes firewall rules.

UFW_CONF="${UFW_CONF:-/etc/ufw/ufw.conf}"
UFW_CMD="${UFW_CMD:-ufw}"            # command names can be overridden (used by the test-suite)
NFT_CMD="${NFT_CMD:-nft}"
IPTABLES_CMD="${IPTABLES_CMD:-iptables}"

audit_firewall() {
    section_header "05_firewall" "Module 5: Firewall Audit"
    if have_cmd "$UFW_CMD"; then
        kv "UFW installed" "yes ($("$UFW_CMD" version 2>/dev/null | head -1))"
        if ! is_root; then
            local en=""; [[ -r "$UFW_CONF" ]] && en=$(sed -n 's/^ENABLED=//p' "$UFW_CONF")
            kv "ufw.conf ENABLED" "${en:-unknown}"
            skip_check "UFW status and rules need root (sudo ufw status verbose)"
            if [[ "$en" == "no" ]]; then
                add_finding HIGH CONFIRMED "UFW firewall is disabled (ENABLED=no in $UFW_CONF)" "" \
                    "Allow the services you need, then enable it: sudo ufw allow OpenSSH && sudo ufw enable"
            fi
            return 0
        fi
        local st; st=$(run_limited 20 "$UFW_CMD" status verbose 2>&1)
        printf '%s\n' "$st" | sed 's/^/    /' | while IFS= read -r l; do out "$l"; done
        if printf '%s\n' "$st" | grep -qi '^Status: active'; then
            ok "UFW is active"
            local incoming; incoming=$(printf '%s\n' "$st" | sed -n 's/^Default: *\([a-z]*\) (incoming).*/\1/p')
            kv "Default incoming policy" "${incoming:-unknown}"
            if [[ "$incoming" == "allow" ]]; then
                add_finding HIGH CONFIRMED "UFW default incoming policy is ALLOW" "Every port not explicitly denied is reachable." \
                    "sudo ufw default deny incoming (allow required services first)."
            fi
            local anyall; anyall=$(printf '%s\n' "$st" | grep -E 'ALLOW IN +Anywhere' | grep -E '^(21|23|69|111|139|445|2049|3306|5432|5900|6379|11211|27017)[/ ]')
            if [[ -n "$anyall" ]]; then
                add_finding MEDIUM POTENTIAL "Firewall allows risky services from anywhere" "$(printf '%s' "$anyall" | tr -s ' ' | tr '\n' ';')" \
                    "Restrict these rules to trusted source networks: sudo ufw allow from <net> to any port <port>."
            fi
            local nrules; nrules=$(printf '%s\n' "$st" | grep -cE 'ALLOW|DENY|REJECT|LIMIT')
            kv "Rules" "$nrules"
            if printf '%s\n' "$st" | grep -qi '^Logging: off'; then
                add_finding LOW CONFIRMED "UFW logging is off" "Blocked connection attempts are not recorded." "sudo ufw logging low"
            fi
        else
            kv "UFW status" "inactive"
            check_other_firewalls "installed but inactive"
        fi
    else
        kv "UFW installed" "no"
        check_other_firewalls "not installed"
    fi
}

check_other_firewalls() {   # $1 = why UFW does not protect the host
    if ! is_root; then
        skip_check "nftables/iptables rules need root - could not confirm whether another firewall is active"
        add_finding MEDIUM POTENTIAL "UFW is $1 and no other firewall could be verified (not root)" "" \
            "Run the audit with sudo, or install and enable UFW: sudo apt install ufw && sudo ufw enable"
        return 0
    fi
    local n=0 src=""
    if have_cmd "$NFT_CMD"; then
        n=$(run_limited 20 "$NFT_CMD" list ruleset 2>/dev/null | grep -cE '^\s+(ip|tcp|udp|ct|iif|oif|meta|counter|accept|drop|reject)')
        src="nftables"
    fi
    if (( n == 0 )) && have_cmd "$IPTABLES_CMD"; then
        n=$(run_limited 20 "$IPTABLES_CMD" -S 2>/dev/null | grep -c '^-A')
        src="iptables"
        local pol; pol=$(run_limited 20 "$IPTABLES_CMD" -S INPUT 2>/dev/null | sed -n 's/^-P INPUT //p')
        [[ -n "$pol" ]] && kv "iptables INPUT policy" "$pol"
        [[ "$pol" == "DROP" || "$pol" == "REJECT" ]] && n=$((n + 1))
    fi
    if (( n > 0 )); then
        kv "Other firewall" "$src with $n rule line(s)"
        add_finding INFO INFO "UFW is $1, but $src rules are present" "Filtering is configured outside UFW." \
            "Review those rules (sudo nft list ruleset / sudo iptables -S) - they were not evaluated in detail."
    else
        local rec="Install and enable UFW: sudo apt install ufw && sudo ufw default deny incoming && sudo ufw allow OpenSSH && sudo ufw enable"
        [[ "$1" == *inactive* ]] && rec="Allow the services you need, then enable UFW: sudo ufw default deny incoming && sudo ufw allow OpenSSH && sudo ufw enable"
        add_finding HIGH CONFIRMED "No host firewall is active (UFW $1, no nftables/iptables rules found)" \
            "All listening services are reachable from connected networks." "$rec"
    fi
}
