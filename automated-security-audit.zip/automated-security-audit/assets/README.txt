Reserved for report assets. The HTML report is self-contained (inline CSS, no external files).
