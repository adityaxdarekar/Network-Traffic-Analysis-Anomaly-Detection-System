#!/usr/bin/env bash
# =============================================================================
# tests/run_tests.sh - automated tests for the Automated Security Audit Tool
#
#   bash tests/run_tests.sh            (no root needed; nothing on the system is changed)
#
# Every module is run against FIXTURES (fake passwd/shadow/sudoers, sshd_config,
# auth logs, /proc/net tables) and STUB commands (ss, ufw, systemctl, apt, dpkg,
# journalctl, lastlog, iptables, nft, sshd, pgrep, ip, who) created in a private
# temporary directory. Each stub records how it was called, so the suite can also
# prove that the tool only ever runs read-only commands.
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)"
FIX="$ROOT/tests/fixtures"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/audit-tests.XXXXXX")"
trap 'rm -rf -- "$WORK"' EXIT
BIN="$WORK/bin"; mkdir -p "$BIN"
export STUB_LOG="$WORK/stub_calls.log"; : >"$STUB_LOG"
export FIX
PASS=0; FAIL=0; FAILED=()

# ---------------------------------------------------------------- tiny assertion helpers
ok_()   { PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
bad_()  { FAIL=$((FAIL+1)); FAILED+=("$1"); printf '  \033[31mFAIL\033[0m %s\n' "$1"; [[ -n "${2:-}" ]] && printf '       %s\n' "$2"; }
has()   { grep -qF -- "$2" <<<"$1"; }
check() { # check "name" "haystack" "needle"   (needle must be present)
    if has "$2" "$3"; then ok_ "$1"; else bad_ "$1" "expected to find: $3"; fi; }
lacks() { # lacks "name" "haystack" "needle"   (needle must be absent)
    if has "$2" "$3"; then bad_ "$1" "did not expect: $3"; else ok_ "$1"; fi; }
equals() { if [[ "$2" == "$3" ]]; then ok_ "$1"; else bad_ "$1" "expected '$3', got '$2'"; fi; }

stub() {  # stub NAME 'body'
    printf '#!/usr/bin/env bash\nprintf "%%s %%s\\n" "%s" "$*" >>"$STUB_LOG"\n%s\n' "$1" "$2" >"$BIN/$1"
    chmod +x "$BIN/$1"
}

# ---------------------------------------------------------------- stub commands (read-only behaviour only)
stub ss         'case "${STUB_SS:-fixture}" in fixture) cat "$FIX/ss_tulnp.txt";; *) exit 1;; esac'
stub ufw        'case "$1" in version) echo "ufw 0.36.2";; status) case "${STUB_UFW:-inactive}" in inactive) echo "Status: inactive";; allow) cat "$FIX/ufw_active_allow.txt";; good) cat "$FIX/ufw_active_good.txt";; esac;; *) echo "stub refuses: $*" >&2; exit 9;; esac'
stub iptables   'case "${STUB_IPTABLES:-empty}" in empty) [[ "$*" == "-S INPUT" ]] && echo "-P INPUT ACCEPT" || printf -- "-P INPUT ACCEPT\n-P FORWARD ACCEPT\n-P OUTPUT ACCEPT\n";; rules) [[ "$*" == "-S INPUT" ]] && echo "-P INPUT DROP" || printf -- "-P INPUT DROP\n-A INPUT -i lo -j ACCEPT\n-A INPUT -p tcp --dport 22 -j ACCEPT\n";; esac'
stub nft        'exit 0'
stub systemctl  'case "$*" in
  *--state=running*) cat "$FIX/systemctl_running.txt";;
  *list-unit-files*) cat "$FIX/systemctl_enabled.txt";;
  *--state=failed*)  cat "$FIX/systemctl_failed.txt";;
  is-active*)        [[ "${STUB_SSH_RUNNING:-0}" == 1 ]];;
  *) echo "stub refuses: $*" >&2; exit 9;; esac'
stub apt        '[[ "$*" == "list --upgradable" ]] && cat "${STUB_APT_FILE:-$FIX/apt_upgradable.txt}" || { echo "stub refuses: $*" >&2; exit 9; }'
stub dpkg       '[[ "$1" == "-s" ]] && [[ " ${STUB_DPKG:-} " == *" $2 "* ]]'
stub journalctl '[[ -n "${STUB_JOURNAL:-}" ]] && cat "$STUB_JOURNAL"; exit 0'
stub sshd       'exit 1'
stub pgrep      '[[ "${STUB_SSH_RUNNING:-0}" == 1 ]]'
stub who        'echo "alice    pts/0        2026-11-08 09:00 (192.0.2.10)"'
stub ip         'echo "lo               UNKNOWN        127.0.0.1/8 ::1/128"; echo "eth0             UP             10.0.2.15/24"'
stub lastlog    'u="${@: -1}"; line=$(grep "^$u|" "$FIX/users/lastlog.txt") || exit 0; IFS="|" read -r _ rec old <<<"$line"
                 echo "Username Port From Latest"; if [[ "$1" == "-b" ]]; then [[ "$old" == 1 ]] && echo "$rec"; else echo "$rec"; fi'

# ---------------------------------------------------------------- working copies of fixtures with exact permissions
U="$WORK/users"; mkdir -p "$U/sudoers.d"
cp "$FIX"/users/{passwd,shadow,group,login.defs,sudoers} "$U/"; cp "$FIX/sudoers.d/90-deploy" "$U/sudoers.d/"
chmod 644 "$U/passwd" "$U/group" "$U/login.defs"; chmod 640 "$U/shadow"; chmod 440 "$U/sudoers" "$U/sudoers.d/90-deploy"
mkdir -p "$WORK/systemd"          # makes the service module believe systemd is running

# environment shared by every module run
base_env() {   # defaults only - a variable already set by the test (VAR=... run_mod) wins
    export PATH="$BIN:$PATH" AUDIT_NO_COLOR=1 LIST_LIMIT="${LIST_LIMIT:-50}"
    [[ "${AUDIT_ASSUME_NONROOT:-0}" == "1" ]] || export AUDIT_ASSUME_ROOT=1   # root-mode logic, even when tests run as a normal user
    local kv k v
    for kv in "PASSWD_FILE=$U/passwd" "SHADOW_FILE=$U/shadow" "GROUP_FILE=$U/group" "LOGIN_DEFS=$U/login.defs" \
              "SUDOERS_FILE=$U/sudoers" "SUDOERS_DIR=$U/sudoers.d" "SYSTEMD_RUN_DIR=$WORK/systemd" \
              "OS_RELEASE_FILE=$FIX/os-release-ubuntu" "REBOOT_REQUIRED_FILE=$WORK/none" "UFW_CMD=ufw" "NFT_CMD=nft" \
              "IPTABLES_CMD=iptables" "UFW_CONF=$WORK/none" "SSH_USE_SSHD_T=0" "AUTH_LOG_FILES=$FIX/auth.log" \
              "LOGIN_SOURCE=files" "APT_STAMP_FILES=$WORK/stamp" "APT_HISTORY=$WORK/none" "PROC_NET_DIR=$FIX/proc_net" \
              "IP_FORWARD_FILE=$FIX/proc_net/ip_forward" "SSHD_CONFIG=$FIX/ssh/sshd_config" "WW_SCAN_DIRS=$WORK/none" \
              "SUID_SCAN_DIRS=$WORK/none" "HOME_BASE=$WORK/none" "SENSITIVE_FILE_SPECS=$WORK/none:644:root"; do
        k=${kv%%=*}; v=${kv#*=}
        [[ -n "${!k:-}" ]] || export "$k=$v"
    done
}
touch "$WORK/stamp"

# run_mod FILE FUNCTION -> prints "F|SEV|TYPE|TITLE" for findings, "S|..." for skipped checks, "O|line" for output
run_mod() {
    (
        base_env
        cd "$ROOT" || exit 1
        source lib/common.sh; source lib/report.sh; source "modules/$1.sh"
        setup_colors
        AUDIT_TMP="$(mktemp -d "$WORK/run.XXXXXX")"
        "$2" >"$AUDIT_TMP/stdout" 2>&1
        local i s
        for i in "${!F_SEV[@]}"; do printf 'F|%s|%s|%s\n' "${F_SEV[$i]}" "${F_TYPE[$i]}" "${F_TITLE[$i]}"; done
        for s in "${SKIPPED[@]}"; do printf 'S|%s\n' "$s"; done
        sed 's/^/O|/' "$AUDIT_TMP/stdout"
    )
}

echo "== 1. Syntax =="
for f in "$ROOT"/main.sh "$ROOT"/install.sh "$ROOT"/lib/*.sh "$ROOT"/modules/*.sh "$ROOT"/demo/*.sh; do
    [[ -f "$f" ]] || continue
    if bash -n "$f" 2>"$WORK/err"; then ok_ "bash -n ${f#"$ROOT"/}"; else bad_ "bash -n ${f#"$ROOT"/}" "$(cat "$WORK/err")"; fi
done

echo "== 2. Library: escaping, trimming, scoring =="
r=$( cd "$ROOT"; source lib/common.sh; html_escape '<a href="x">Tom & Jerry'"'"'s</a>' )
equals "html_escape" "$r" '&lt;a href=&quot;x&quot;&gt;Tom &amp; Jerry&#39;s&lt;/a&gt;'
r=$( cd "$ROOT"; source lib/common.sh; trim "   padded text  " )
equals "trim" "$r" "padded text"
r=$( cd "$ROOT"; AUDIT_NO_COLOR=1; AUDIT_ASSUME_ROOT=1; source lib/common.sh; source lib/report.sh; setup_colors
     add_finding CRITICAL CONFIRMED a "" "" >/dev/null; add_finding HIGH POTENTIAL b "" "" >/dev/null
     add_finding MEDIUM CONFIRMED c "" "" >/dev/null; add_finding LOW POTENTIAL d "" "" >/dev/null
     add_finding INFO CONFIRMED e "" "" >/dev/null; calc_score; echo "$SCORE $RATING $DEDUCTION_TOTAL ${F_TYPE[4]}" )
equals "score: 100-(20+5+5+1+0) = 69 Fair; INFO forced to type INFO" "$r" "69 Fair 31 INFO"
r=$( cd "$ROOT"; AUDIT_NO_COLOR=1; AUDIT_ASSUME_ROOT=1; source lib/common.sh; source lib/report.sh; setup_colors
     for k in 1 2 3 4 5 6; do add_finding CRITICAL CONFIRMED "c$k" "" "" >/dev/null; done; calc_score; echo "$SCORE $RATING" )
equals "score never below 0" "$r" "0 Critical"
r=$( cd "$ROOT"; source lib/common.sh; source lib/report.sh; echo "$(finding_cost HIGH POTENTIAL) $(finding_cost MEDIUM POTENTIAL) $(finding_cost LOW POTENTIAL) $(finding_cost CRITICAL CONFIRMED)" )
equals "potential findings cost half, rounded up" "$r" "5 3 1 20"

echo "== 3. Module 1: system information =="
o=$(run_mod system_info audit_system_info)
check "distribution read from os-release" "$o" "Ubuntu 24.04.1 LTS"
check "logged-in users listed" "$o" "alice    pts/0"
check "supported distribution recognised" "$o" "Supported distribution family (ubuntu)"
o=$(OS_RELEASE_FILE_OVERRIDE=1 run_mod system_info audit_system_info | head -0; ( base_env; export OS_RELEASE_FILE="$FIX/os-release-arch"; cd "$ROOT"; source lib/common.sh; source modules/system_info.sh; setup_colors; AUDIT_TMP=$(mktemp -d "$WORK/x.XXXX"); audit_system_info; printf 'F|%s\n' "${F_TITLE[@]}" ))
check "untested distribution -> INFO" "$o" "Distribution not tested with this tool (arch)"
touch "$WORK/reboot-required"
o=$( ( base_env; export REBOOT_REQUIRED_FILE="$WORK/reboot-required"; cd "$ROOT"; source lib/common.sh; source modules/system_info.sh; setup_colors; AUDIT_TMP=$(mktemp -d "$WORK/x.XXXX"); audit_system_info >/dev/null; printf 'F|%s|%s\n' "${F_SEV[@]}" "${F_TITLE[@]}" ) )
check "pending reboot -> LOW" "$o" "System restart required"

echo "== 4. Module 2: user accounts =="
o=$(run_mod user_audit audit_users)
check "extra UID 0 account -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|Account(s) other than root have UID 0: toor"
check "duplicate UID -> HIGH" "$o" "F|HIGH|CONFIRMED|Duplicate UIDs"
check "empty password -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|Accounts with an EMPTY password: guest"
check "system account with shell -> LOW potential" "$o" "F|LOW|POTENTIAL|System accounts with interactive login shells: www-data"
check "never-expiring passwords (locked accounts excluded)" "$o" "Passwords that never expire: alice guest"
lacks "carol is locked, not listed as never-expiring" "$o" "alice guest carol"
check "inactive account from lastlog" "$o" "Accounts inactive for more than 90 days: alice"
check "never logged in" "$o" "Login-capable accounts that never logged in: guest carol"
check "!authenticate -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|sudo authentication disabled"
check "NOPASSWD: ALL -> HIGH" "$o" "F|HIGH|CONFIRMED|Passwordless sudo for ALL commands"
check "many admins -> LOW" "$o" "4 users have full administrator (sudo) rights"
lacks "sudoers with mode 440 not reported as writable" "$o" "Sudoers file writable"
chmod 666 "$U/sudoers.d/90-deploy"
o=$(run_mod user_audit audit_users); chmod 440 "$U/sudoers.d/90-deploy"
check "writable sudoers file -> HIGH" "$o" "F|HIGH|CONFIRMED|Sudoers file writable by group or others"
o=$(AUDIT_ASSUME_NONROOT=1 run_mod user_audit audit_users)
check "non-root: shadow check skipped" "$o" "S|Module 2: User Account Security Audit|empty-password and password-ageing checks need root"
check "non-root: sudoers rules skipped" "$o" "sudoers file(s) unreadable without root"
lacks "non-root: no empty-password claim" "$o" "EMPTY password"
check "non-root: UID 0 check still works" "$o" "other than root have UID 0"

echo "== 5. Module 3: file permissions =="
P="$WORK/perm"; mkdir -p "$P/etc" "$P/data/share" "$P/bin" "$P/odd" "$P/homes/alice" "$P/homes/bob" "$P/homes/carol" "$P/data/tmp"
echo x >"$P/etc/app.conf"; chmod 666 "$P/etc/app.conf"
echo x >"$P/data/notes.txt"; chmod 666 "$P/data/notes.txt"
chmod 777 "$P/data/share"; chmod 1777 "$P/data/tmp"
ln -s /etc/passwd "$P/data/link-to-passwd"
for b in passwd find mystery; do printf '#!/bin/sh\necho demo\n' >"$P/bin/$b"; chmod 4755 "$P/bin/$b"; done
printf '#!/bin/sh\n' >"$P/odd/helper"; chmod 4755 "$P/odd/helper"
printf '#!/bin/sh\n' >"$P/bin/wwsuid"; chmod 4777 "$P/bin/wwsuid"
chmod 777 "$P/homes/alice"; chmod 755 "$P/homes/bob"; chmod 700 "$P/homes/carol"
cp "$U/passwd" "$P/passwd"; chmod 666 "$P/passwd"; cp "$U/shadow" "$P/shadow"; chmod 644 "$P/shadow"
cp "$U/group" "$P/group"; chmod 664 "$P/group"; cp "$U/sudoers" "$P/sudoers"; chmod 440 "$P/sudoers"
me=$(id -un)
o=$( export WW_SCAN_DIRS="$P" SUID_SCAN_DIRS="$P" HOME_BASE="$P/homes" SUID_ODD_RE="^$P/odd/" SYSTEM_DIR_RE="^$P/etc/" \
     SENSITIVE_FILE_SPECS="$P/passwd:644:$me $P/shadow:640:$me $P/group:644:$me $P/sudoers:440:$me $P/missing:600:$me $P/sudoers:440:nobody"
     run_mod_env() { ( base_env; export WW_SCAN_DIRS SUID_SCAN_DIRS HOME_BASE SUID_ODD_RE SYSTEM_DIR_RE SENSITIVE_FILE_SPECS
        cd "$ROOT"; source lib/common.sh; source lib/report.sh; source modules/permission_audit.sh; setup_colors
        AUDIT_TMP=$(mktemp -d "$WORK/p.XXXX"); audit_permissions >"$AUDIT_TMP/o" 2>&1
        for i in "${!F_SEV[@]}"; do printf 'F|%s|%s|%s|%s\n' "${F_SEV[$i]}" "${F_TYPE[$i]}" "${F_TITLE[$i]}" "${F_DETAIL[$i]}"; done; sed 's/^/O|/' "$AUDIT_TMP/o" ); }
     run_mod_env )
check "world-writable file in system dir -> HIGH" "$o" "F|HIGH|CONFIRMED|World-writable files in system locations (1)"
check "world-writable file elsewhere -> MEDIUM" "$o" "F|MEDIUM|CONFIRMED|World-writable files outside system directories (3)"
check "dir without sticky bit -> MEDIUM" "$o" "F|MEDIUM|CONFIRMED|World-writable directories without the sticky bit (2)"
lacks "sticky /tmp-like dir not reported" "$o" "$P/data/tmp"
lacks "symlinks ignored" "$o" "link-to-passwd"
check "world-writable SUID -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|SUID/SGID program that is world-writable"
check "GTFOBins program with SUID -> HIGH potential" "$o" "F|HIGH|POTENTIAL|SUID/SGID set on programs that allow privilege escalation|$P/bin/find"
check "SUID in unusual location -> HIGH potential" "$o" "unusual locations|$P/odd/helper"
check "unknown SUID -> LOW potential" "$o" "F|LOW|POTENTIAL|SUID/SGID programs not in the standard list"
check "standard SUID name counted as standard" "$o" "(standard: 1)"
check "passwd writable by others -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|Insecure permissions on $P/passwd (666"
check "shadow readable by others -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|Insecure permissions on $P/shadow (644"
check "group writable by group -> HIGH" "$o" "F|HIGH|CONFIRMED|Insecure permissions on $P/group (664"
check "wrong owner -> HIGH" "$o" "$P/sudoers is owned by $me instead of nobody"
lacks "missing sensitive file skipped quietly" "$o" "$P/missing"
check "home writable by all -> HIGH" "$o" "F|HIGH|CONFIRMED|Home directories writable by all users|$P/homes/alice (777)"
check "home readable by all -> LOW" "$o" "F|LOW|POTENTIAL|Home directories readable by all users|$P/homes/bob (755)"

echo "== 6. Module 4: network =="
o=$(run_mod network_audit audit_network)
check "ss: telnet on all interfaces -> HIGH potential" "$o" "F|HIGH|POTENTIAL|Telnet (cleartext logins) listening on all interfaces (tcp/23, inetd/777)"
check "ss: TFTP over UDP -> HIGH potential" "$o" "TFTP (no authentication) listening on all interfaces (udp/69"
check "ss: redis on * -> HIGH" "$o" "F|HIGH|POTENTIAL|Redis (often no authentication)"
check "ss: Docker API -> CRITICAL potential" "$o" "F|CRITICAL|POTENTIAL|Docker API without TLS"
lacks "ss: MariaDB on localhost not flagged" "$o" "MySQL/MariaDB"
lacks "ss: SSH on all interfaces is not a finding" "$o" "F|HIGH|POTENTIAL|SSH"
check "ss: localhost scope shown" "$o" "127.0.0.1                                3306    localhost    mariadbd/950"
check "ss: specific-address scope" "$o" "10.0.2.15                                80      specific"
check "ss: ip forwarding -> LOW" "$o" "F|LOW|POTENTIAL|IP forwarding is enabled"
check "interfaces via ip" "$o" "eth0             UP             10.0.2.15/24"
o=$(FORCE_PROC_NET=1 run_mod network_audit audit_network)
check "/proc/net fallback used" "$o" "/proc/net (ss not installed)"
check "/proc/net: 127.0.0.1:3306 decoded" "$o" "tcp   127.0.0.1                                3306    localhost"
check "/proc/net: telnet 0.0.0.0:23 -> HIGH" "$o" "Telnet (cleartext logins) listening on all interfaces (tcp/23"
check "/proc/net: IPv6 :: port 22" "$o" "tcp   ::                                       22      ALL"
check "/proc/net: IPv6 ::1 port 631" "$o" "tcp   ::1                                      631     localhost"
check "/proc/net: UDP 69 (state 07)" "$o" "udp   0.0.0.0                                  69      ALL"
lacks "/proc/net: established connection ignored" "$o" "10.0.2.15                                22"

echo "== 7. Module 5: firewall =="
o=$(STUB_UFW=inactive run_mod firewall_audit audit_firewall)
check "UFW inactive + no other rules -> one HIGH" "$o" "F|HIGH|CONFIRMED|No host firewall is active (UFW installed but inactive"
equals "only one firewall finding when inactive" "$(grep -c '^F|' <<<"$o")" "1"
o=$(STUB_UFW=inactive STUB_IPTABLES=rules run_mod firewall_audit audit_firewall)
check "UFW inactive but iptables rules -> INFO" "$o" "F|INFO|INFO|UFW is installed but inactive, but iptables rules are present"
o=$(STUB_UFW=allow run_mod firewall_audit audit_firewall)
check "default allow -> HIGH" "$o" "F|HIGH|CONFIRMED|UFW default incoming policy is ALLOW"
check "risky port allowed from anywhere -> MEDIUM" "$o" "F|MEDIUM|POTENTIAL|Firewall allows risky services from anywhere"
check "logging off -> LOW" "$o" "F|LOW|CONFIRMED|UFW logging is off"
o=$(STUB_UFW=good run_mod firewall_audit audit_firewall)
equals "well-configured UFW -> no findings" "$(grep -c '^F|' <<<"$o")" "0"
check "rules displayed" "$o" "22/tcp                     LIMIT IN    Anywhere"
o=$(UFW_CMD=ufw-not-installed run_mod firewall_audit audit_firewall)
check "UFW missing + no rules -> HIGH" "$o" "No host firewall is active (UFW not installed"
printf 'ENABLED=no\n' >"$WORK/ufw.conf"
o=$(AUDIT_ASSUME_NONROOT=1 UFW_CONF_X=1 bash -c 'true'; ( base_env; export AUDIT_ASSUME_NONROOT=1 UFW_CONF="$WORK/ufw.conf"; cd "$ROOT"; source lib/common.sh; source modules/firewall_audit.sh; setup_colors; AUDIT_TMP=$(mktemp -d "$WORK/x.XXXX"); audit_firewall >/dev/null; printf 'F|%s|%s\n' "${F_SEV[@]}" "${F_TITLE[@]}"; printf 'S|%s\n' "${SKIPPED[@]}" ) )
check "non-root: ufw.conf ENABLED=no -> HIGH" "$o" "UFW firewall is disabled (ENABLED=no"
check "non-root: status skipped" "$o" "UFW status and rules need root"

echo "== 8. Module 6: services =="
o=$(run_mod service_audit audit_services)
check "xinetd running -> HIGH potential" "$o" "F|HIGH|POTENTIAL|Insecure/legacy service active: xinetd"
check "optional services -> LOW potential, with state" "$o" "avahi-daemon (running, enabled at boot) cups (running, enabled at boot) bluetooth (enabled at boot)"
check "server software -> INFO" "$o" "F|INFO|INFO|Server software running: apache2"
check "failed unit -> LOW" "$o" "F|LOW|CONFIRMED|Failed services: backup-sync"
check "enabled-at-boot marker" "$o" "cups   [enabled at boot]"
o=$(SYSTEMD_RUN_DIR_X=1 bash -c true; ( base_env; export SYSTEMD_RUN_DIR="$WORK/no-systemd"; cd "$ROOT"; source lib/common.sh; source modules/service_audit.sh; setup_colors; AUDIT_TMP=$(mktemp -d "$WORK/x.XXXX"); audit_services >/dev/null; printf 'S|%s\n' "${SKIPPED[@]}" ) )
check "no systemd -> skipped, not failed" "$o" "systemd is not running"

echo "== 9. Module 7: SSH =="
o=$(STUB_DPKG="openssh-server" STUB_SSH_RUNNING=1 run_mod ssh_audit audit_ssh)
check "Include read first: PasswordAuthentication no wins" "$o" "passwordauthentication:    no"
check "PermitRootLogin yes (keys only) -> HIGH confirmed" "$o" "F|HIGH|CONFIRMED|PermitRootLogin yes"
lacks "not CRITICAL because passwords are off" "$o" "Root can log in over SSH with a password"
check "PermitEmptyPasswords yes -> CRITICAL" "$o" "F|CRITICAL|CONFIRMED|PermitEmptyPasswords yes"
check "X11Forwarding -> LOW" "$o" "F|LOW|CONFIRMED|X11Forwarding yes"
check "MaxAuthTries 10 -> LOW" "$o" "F|LOW|POTENTIAL|MaxAuthTries is 10"
check "CBC cipher -> MEDIUM" "$o" "F|MEDIUM|CONFIRMED|Weak SSH algorithms configured"
lacks "settings after Match are not global" "$o" "PermitUserEnvironment yes"
check "defaults marked" "$o" "pubkeyauthentication:      yes (default)"
o=$(STUB_DPKG="openssh-server" STUB_SSH_RUNNING=0 SSHD_CONFIG="$FIX/ssh_secure/sshd_config" run_mod ssh_audit audit_ssh)
equals "hardened config -> only the INFO hint" "$(grep '^F|' <<<"$o" | grep -vc '^F|INFO')" "0"
check "AllowGroups shown" "$o" "allowgroups:"
printf 'PermitRootLogin yes\nPasswordAuthentication yes\n' >"$WORK/sshd_bad"
o=$(STUB_DPKG="openssh-server" STUB_SSH_RUNNING=0 SSHD_CONFIG="$WORK/sshd_bad" run_mod ssh_audit audit_ssh)
check "root + password -> CRITICAL; POTENTIAL while sshd is stopped" "$o" "F|CRITICAL|POTENTIAL|Root can log in over SSH with a password"
o=$(STUB_DPKG="" SSHD_CMD=sshd-not-installed SSHD_BIN_PATH="$WORK/none" SSHD_CONFIG="$WORK/nonexistent" run_mod ssh_audit audit_ssh)
check "no SSH server -> nothing to audit" "$o" "No SSH server installed"

echo "== 10. Module 8: updates =="
touch -d '40 days ago' "$WORK/stamp"
o=$(STUB_DPKG="" run_mod update_audit audit_updates)
check "stale package lists (>30 days) -> MEDIUM" "$o" "F|MEDIUM|CONFIRMED|Package lists have not been refreshed for 40 days"
check "security pocket updates -> HIGH" "$o" "F|HIGH|CONFIRMED|2 pending SECURITY update(s)"
check "sensitive packages -> HIGH" "$o" "F|HIGH|CONFIRMED|Outdated security-sensitive packages"
check "openssl listed" "$o" "openssl"
check "unattended-upgrades missing -> LOW potential" "$o" "F|LOW|POTENTIAL|Automatic security updates"
touch "$WORK/stamp"
o=$(STUB_DPKG="unattended-upgrades" OS_RELEASE_FILE="$FIX/os-release-kali" STUB_APT_FILE="$FIX/apt_upgradable_plain.txt" run_mod update_audit audit_updates)
check "Kali: rolling upgrades -> LOW" "$o" "F|LOW|CONFIRMED|2 package upgrade(s) pending"
lacks "Kali: no security-pocket claim" "$o" "SECURITY update"
lacks "fresh lists not reported" "$o" "F|LOW|CONFIRMED|Package lists"
equals "apt only called read-only" "$(grep '^apt ' "$STUB_LOG" | sort -u)" "apt list --upgradable"

echo "== 11. Module 9: login and authentication =="
o=$(run_mod login_audit audit_login)
check "syslog format parsed" "$o" "Failed SSH passwords:      31"
check "brute force from one IP -> HIGH" "$o" "F|HIGH|CONFIRMED|SSH brute-force attempts from 203.0.113.50 (25 failed passwords)"
check "username guessing -> MEDIUM" "$o" "F|MEDIUM|POTENTIAL|Username guessing from 203.0.113.50 (5 non-existent user names)"
check "success after failures -> CRITICAL potential" "$o" "F|CRITICAL|POTENTIAL|Successful login from 203.0.113.50 after 25 failed attempts"
check "repeated failures -> MEDIUM" "$o" "F|MEDIUM|POTENTIAL|Repeated failed SSH logins from 198.51.100.7 (6)"
check "attempts against root -> MEDIUM" "$o" "F|MEDIUM|POTENTIAL|15 failed SSH password attempts against root"
check "root login occurred -> MEDIUM confirmed" "$o" "F|MEDIUM|CONFIRMED|Direct root logins over SSH occurred"
check "sudo failures counted once (3, PAM line ignored)" "$o" "F|LOW|POTENTIAL|3 failed sudo password attempts by alice"
check "su failures" "$o" "F|LOW|POTENTIAL|3 failed 'su' attempts"
check "timestamps and users shown" "$o" "Nov 8 09:10:04"
check "local login failure parsed" "$o" "LOCALFAIL user=guest"
lacks "PAM sshd lines not double-counted" "$o" "Failed SSH passwords:      41"
o=$(AUTH_LOG_FILES="$FIX/auth_iso.log" run_mod login_audit audit_login)
check "ISO timestamps parsed" "$o" "2026-11-08T13:00:00.123456+00:00"
check "ISO: 7 failures -> MEDIUM" "$o" "Repeated failed SSH logins from 198.51.100.99 (7)"
lacks "ISO: success from a different IP is not 'after failures'" "$o" "Successful login from"
o=$(LOGIN_SOURCE=journal STUB_JOURNAL="$FIX/auth_iso.log" run_mod login_audit audit_login)
check "journalctl source (Kali default)" "$o" "journalctl (last 7 days)"
o=$( ( base_env; export AUDIT_ASSUME_NONROOT=1 AUTH_LOG_FILES="$U/shadow" STUB_JOURNAL=""; cd "$ROOT"; source lib/common.sh; source modules/login_audit.sh; setup_colors; AUDIT_TMP=$(mktemp -d "$WORK/x.XXXX"); audit_login >/dev/null; printf 'S|%s\n' "${SKIPPED[@]}" ) )
check "unreadable logs -> skipped with hint about adm group" "$o" "need root or the 'adm' group"

echo "== 12. main.sh end to end (all stubs) =="
RD="$WORK/reports"
run_main() { ( base_env; export STUB_DPKG="openssh-server" STUB_SSH_RUNNING=1 AUDIT_LOG_DIR="$WORK/logs" AUDIT_CONFIG="$WORK/none"
               export WW_SCAN_DIRS="$P" SUID_SCAN_DIRS="$P" HOME_BASE="$P/homes"; "$ROOT/main.sh" "$@" ) 2>&1; }
o=$(run_main --full --no-color -o "$RD"); rc=$?
equals "full audit exit code" "$rc" "0"
for m in 1 2 3 4 5 6 7 8 9; do check "module $m ran" "$o" "== Module $m:"; done
txt=$(ls "$RD"/security_audit_*.txt 2>/dev/null | head -1); html=$(ls "$RD"/security_audit_*.html 2>/dev/null | head -1)
[[ -f "$txt" && -f "$html" ]] && ok_ "TXT and HTML reports created" || bad_ "TXT and HTML reports created"
[[ "$(basename "$txt")" =~ ^security_audit_[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{6}\.txt$ ]] && ok_ "timestamped file name" || bad_ "timestamped file name" "$txt"
equals "report permissions 600" "$(stat -c '%a' "$txt")" "600"
T=$(cat "$txt"); H=$(cat "$html")
score=$(sed -n 's/^  Score: \([0-9]*\)\/100.*/\1/p' <<<"$o")
check "TXT has the same score as the terminal" "$T" "SECURITY SCORE: $score/100"
check "TXT severity summary" "$T" "SEVERITY SUMMARY"
check "TXT recommendations" "$T" "Recommendation: "
check "TXT module output" "$T" "---- Module 9: Login & Authentication Audit ----"
check "HTML score" "$H" "<b>${score}</b>"
check "HTML severity cards" "$H" 'class="panel card c-CRITICAL"'
check "HTML escapes hostile log content (user name from auth.log)" "$H" "&lt;script&gt;alert(1)&lt;/script&gt;"
lacks "HTML contains no injected script tag" "$H" "<script>alert(1)</script>"
if command -v python3 >/dev/null; then
    if python3 -c 'import sys,html.parser; p=html.parser.HTMLParser(); p.feed(open(sys.argv[1]).read()); p.close()' "$html" 2>/dev/null; then ok_ "HTML parses"; else bad_ "HTML parses"; fi
fi
check "log file written" "$(cat "$WORK"/logs/audit_*.log)" "run finished: score $score"
[[ -n "${KEEP_REPORT_DIR:-}" ]] && { mkdir -p "$KEEP_REPORT_DIR"; cp "$txt" "$KEEP_REPORT_DIR/simulated_full_audit.txt"; cp "$html" "$KEEP_REPORT_DIR/simulated_full_audit.html"; }
o=$(run_main --module 7 --no-color -o "$RD");
check "--module 7 runs only SSH" "$o" "== Module 7: SSH Security Audit =="
lacks "--module 7 does not run module 1" "$o" "== Module 1:"
o=$(run_main --module 7 --no-color --min-score 99 -o "$RD"); rc=$?
equals "--min-score below threshold exits 3" "$rc" "3"
o=$(run_main --module 12 --no-color); rc=$?
equals "invalid module number exits 2" "$rc" "2"
o=$(run_main -o "$RD" --list-reports)
check "--list-reports shows score" "$o" "/100"
o=$(printf '1\nn\n11\n\n12\n' | run_main --menu --no-color -o "$RD")
check "menu: module 1 ran" "$o" "== Module 1: System Information Audit =="
check "menu: previous reports listed" "$o" "security_audit_"
check "menu: exit" "$o" "Goodbye"
o=$(run_main --bogus); rc=$?
equals "unknown option exits 2" "$rc" "2"
o=$( ( base_env; export AUDIT_ASSUME_NONROOT=1 AUDIT_LOG_DIR="$WORK/logs" AUDIT_CONFIG="$WORK/none"; "$ROOT/main.sh" --full --no-color -o "$WORK/r2" ) 2>&1)
check "non-root run states it is limited" "$o" "not run as root"
check "non-root report notes skipped checks" "$(cat "$WORK"/r2/*.txt)" "limited (non-root) audit"
check "non-root rating is labelled limited" "$o" "limited audit,"
printf 'LIST_LIMIT=3\n' >"$WORK/unsafe.conf"; chmod 666 "$WORK/unsafe.conf"
o=$( ( base_env; export AUDIT_LOG_DIR="$WORK/logs" AUDIT_CONFIG="$WORK/unsafe.conf"; "$ROOT/main.sh" --module 1 --no-color ) 2>&1)
check "world-writable config file is refused" "$o" "ignoring $WORK/unsafe.conf"

echo "== 13. Read-only guarantee =="
bad=$(grep -E '^(ufw|systemctl|apt|dpkg|iptables|nft|sshd) ' "$STUB_LOG" \
      | grep -vE '^(ufw (version|status verbose)|systemctl (list-units|list-unit-files|is-active)|apt list --upgradable|dpkg -s |iptables -S|nft list ruleset|sshd -T)' || true)
if [[ -z "$bad" ]]; then ok_ "only read-only commands were executed ($(wc -l <"$STUB_LOG") stub calls)"; else bad_ "only read-only commands were executed" "$bad"; fi
lacks "no service-changing call (systemctl ... --now)" "$(cat "$STUB_LOG")" " --now"

echo
echo "Result: $PASS passed, $FAIL failed"
(( FAIL == 0 )) || { printf '  failed: %s\n' "${FAILED[@]}"; exit 1; }
