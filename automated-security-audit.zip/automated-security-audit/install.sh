#!/usr/bin/env bash
# =============================================================================
#  install.sh - prepare the Automated Security Audit Tool
#
#    chmod +x install.sh && ./install.sh              check dependencies, set permissions
#    ./install.sh --install-deps                       also install missing packages with apt (asks sudo)
#
#  What it does:
#    * checks Bash and the required / recommended commands
#    * makes the scripts executable, creates reports/ and logs/ (mode 700)
#    * makes config/audit.conf not writable by group/others (main.sh refuses unsafe configs)
#  It changes nothing outside the project folder unless --install-deps is given,
#  and even then it only installs packages - it never enables UFW or changes services.
# =============================================================================
set -u
DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
INSTALL=0
[[ "${1:-}" == "--install-deps" ]] && INSTALL=1
[[ "${1:-}" == "-h" || "${1:-}" == "--help" ]] && { sed -n '3,14p' "$0"; exit 0; }

g=$'\033[32m'; y=$'\033[33m'; r=$'\033[31m'; b=$'\033[1m'; n=$'\033[0m'
[[ -t 1 ]] || { g=""; y=""; r=""; b=""; n=""; }

echo "${b}Automated Security Audit Tool - installer${n}"
if [[ -r /etc/os-release ]]; then . /etc/os-release; echo "  System: ${PRETTY_NAME:-unknown}"; fi
case "${ID:-}" in ubuntu|kali|debian) ;; *) echo "  ${y}Note:${n} tested on Ubuntu and Kali Linux; other distributions may need adjustments." ;; esac

if (( BASH_VERSINFO[0] < 4 )); then echo "  ${r}Bash 4+ is required (found $BASH_VERSION)${n}"; exit 1; fi
echo "  Bash $BASH_VERSION ${g}OK${n}"

# command -> package (Debian/Ubuntu/Kali)
REQUIRED="awk:mawk sed:sed grep:grep find:findutils stat:coreutils date:coreutils mktemp:coreutils id:coreutils uname:coreutils hostname:hostname"
RECOMMENDED="ss:iproute2 ip:iproute2 ufw:ufw systemctl:systemd journalctl:systemd lastlog:login dpkg:dpkg apt:apt timeout:coreutils ps:procps who:coreutils less:less"
missing_req=(); missing_pkgs=()
for pair in $REQUIRED; do
    c=${pair%%:*}; p=${pair#*:}
    if command -v "$c" >/dev/null 2>&1; then printf '  %-11s %sfound%s\n' "$c" "$g" "$n"; else printf '  %-11s %sMISSING (required, package %s)%s\n' "$c" "$r" "$p" "$n"; missing_req+=("$c"); missing_pkgs+=("$p"); fi
done
for pair in $RECOMMENDED; do
    c=${pair%%:*}; p=${pair#*:}
    if command -v "$c" >/dev/null 2>&1; then printf '  %-11s %sfound%s\n' "$c" "$g" "$n"
    else
        hint=""
        case "$c" in
            ss|ip) hint="network module falls back to /proc/net" ;;
            ufw) hint="firewall module then checks nftables/iptables" ;;
            lastlog) hint="inactive-account check is skipped (Kali/Debian 13: package lastlog2)" ;;
            systemctl|journalctl) hint="service/journal checks are skipped" ;;
        esac
        printf '  %-11s %snot found%s (optional, package %s%s)\n' "$c" "$y" "$n" "$p" "${hint:+ - $hint}"
        missing_pkgs+=("$p")
    fi
done

if (( ${#missing_pkgs[@]} )); then
    mapfile -t uniq < <(printf '%s\n' "${missing_pkgs[@]}" | sort -u)
    if (( INSTALL )) && command -v apt-get >/dev/null 2>&1; then
        echo "  Installing: ${uniq[*]}  (UFW is installed but NOT enabled)"
        sudo apt-get update && sudo apt-get install -y "${uniq[@]}" || echo "  ${y}Some packages could not be installed - the audit still runs with fallbacks.${n}"
    else
        echo "  To install missing packages:  sudo apt update && sudo apt install -y ${uniq[*]}"
        echo "  (or run: ./install.sh --install-deps)"
    fi
fi
(( ${#missing_req[@]} )) && { echo "  ${r}Required commands are missing - install them first.${n}"; exit 1; }

chmod +x "$DIR/main.sh" "$DIR"/modules/*.sh "$DIR"/lib/*.sh "$DIR/tests/run_tests.sh" "$DIR"/demo/*.sh 2>/dev/null
mkdir -p "$DIR/reports" "$DIR/logs" && chmod 700 "$DIR/reports" "$DIR/logs"
[[ -f "$DIR/config/audit.conf" ]] && chmod go-w "$DIR/config/audit.conf"
echo "  Permissions set: scripts executable, reports/ and logs/ private (700), config not group/world-writable."
cat <<EOF

${b}Ready.${n} Run:
  sudo ./main.sh                 interactive menu (full audit as root)
  sudo ./main.sh --full          complete audit + TXT/HTML reports in reports/
  ./main.sh --module 3,4         selected modules without root (limited)
  bash tests/run_tests.sh        automated tests (no root needed)
EOF
