# Demo Guide, Expected Outputs and Beginner Explanation

## A. Start the application
```bash
cd phishing-email-detector
./setup.sh          # once  (Windows: setup.bat)
./run.sh            # (Windows: run.bat)   → http://localhost:8501
```
Before presenting, you can clear old history: **Scan History → Delete all history**.

## B. Step-by-step demonstration (about 10 minutes)
| # | Do this | Say this |
|---|---|---|
| 1 | Open **About Project** | "It's rule-based, everything runs locally, and it never opens links or attachments. The score is a heuristic, not a probability." |
| 2 | **Analyze Email → Load a sample → L2 · Online shop order confirmation → Load sample → Analyze** | Result **LOW 0/100**. "The email says *we will never ask for your password*; the detector understands the negation, so it is not flagged." |
| 3 | Load **P1 · Fake bank verification → Analyze** | Result **HIGH 100/100**. Go through the Findings tab: IP-address link, lookalike sender `examplebank-secure.com`, "account has been suspended", password and card request, "within 24 hours". |
| 4 | Open the **Sender analysis** tab | "The name says Example Bank, but the domain is not examplebank.com: it's a lookalike." |
| 5 | Open the **URLs** tab | "`http://192.0.2.45/...` is a raw IP address. Real banks link to their own domain. We never visited it." |
| 6 | Load **U1 · Link text hides a different destination → Analyze** | **HIGH 65**. "The visible link says `www.exampleshop.com`, but it really goes to `exampleshop.account-verify.top`. You can't see that in a normal mail client." |
| 7 | Load **S1 · Fake job offer → Analyze** | **MEDIUM 40**. "There's no link, but there's a registration fee, 'you have been selected' and pressure. That's suspicious, not certain." |
| 8 | **Upload .eml file →** `samples/eml/bank_phishing_html.eml` | **HIGH 100**. Show "Email authentication failed (SPF=fail, DMARC=fail)" and "Reply-To goes elsewhere". The `<script>` in the HTML was removed, not executed. |
| 9 | **Upload .eml file →** `samples/eml/delivery_scam_attachment.eml` | **HIGH 60**. "The attachment `Delivery_Label.pdf.exe` is a program disguised as a PDF. It was listed, never opened." |
| 10 | **URL Analysis** → type `https://examplebank.com@198.51.100.7/login` | "Everything before `@` is ignored; the real host is 198.51.100.7." |
| 11 | **Home Dashboard** | KPI cards and risk-distribution chart from the scans you just ran. |
| 12 | **Scan History** → pick a scan → **Export CSV**; **Reports → Download PDF report** | Open the PDF: score, sender analysis, keywords, URL table, findings, recommendations. |
| 13 | Terminal: `python -m pytest -v` | "144 automated tests, all passing." |

## C. Expected output
**Legitimate (L2 order confirmation):**
```
Email Risk: SAFE / LOW RISK            Score: 0/100
Findings: none
Recommendation: No strong phishing indicators were found. Still check unexpected requests before acting.
```

**Suspicious (S1 fake job offer):**
```
Email Risk: SUSPICIOUS / MEDIUM RISK   Score: 40/100
1. +15 Suspicious phrase: "congratulations, you have been selected"
2. +10 Suspicious phrase: "registration fee"
3. +10 Urgent or threatening language  (as soon as possible)
4.  +5 Suspicious phrase: "no experience needed"
Recommendation: Treat this email with caution - do not click links until you have verified the sender.
                Contact the organisation using contact details from its official website, not from this email.
```

**Phishing (P1 fake bank verification):**
```
Email Risk: HIGH RISK / LIKELY PHISHING   Score: 100/100   (13 indicators; raw points exceed 100, total capped)
 1. +20 URL: IP address instead of domain          http://192.0.2.45/examplebank/login.php
 2. +20 Sender: Lookalike domain                   alerts@examplebank-secure.com
 3. +15 Suspicious phrase: "account has been suspended"
 4. +15 Suspicious phrase: "account will be closed"
 5. +15 Suspicious phrase: "bank verification required"
 6. +15 Requests sensitive information             password / PIN, payment card details
 7. +10 Suspicious phrase: "unusual login"
 8. +10 Suspicious phrase: "click here immediately"
 9. +10 Suspicious phrase: "confirm your identity"
10. +10 Suspicious phrase: "verify your account"
11. +10 Urgent or threatening language             failure to verify, urgent, within 24 hours
12.  +5 URL: Uses HTTP, not HTTPS
13.  +5 URL: Suspicious keywords in URL            login
Score breakdown: Keywords 85 → capped 35 · Language 25 · URLs 30 · Sender 20  = 110 → 100
Recommendation: Do not click any links, open attachments or reply to this email. Do not provide passwords,
codes, card or bank details. Report it … If you already clicked, change the password from the official site
and enable multi-factor authentication.
```
(Scan IDs and dates will differ on your computer.)

## D. The project explained for a beginner
Think of the program as a **checklist that a careful security analyst would follow**, turned into code.

1. **`email_parser.py` – reading the email.** It takes whatever you give it (typed fields, a `.txt`, or a real
   `.eml` file exported from Gmail/Outlook) and pulls out the sender, subject, text, links and attachment names.
   HTML emails are turned into plain text, and any `<script>` is thrown away. Attachments are only *listed*.
2. **`keyword_detector.py` – reading the words.** It looks for phrases scammers love ("verify your account",
   "your account will be closed"), pressure ("within 24 hours"), requests for secrets ("enter your password") and
   dangerous attachments ("invoice.pdf.exe"). It is careful not to flag "we will **never** ask for your password".
3. **`url_analyzer.py` – reading the links without clicking them.** It looks at each address as text: is it an IP
   number? a shortener? does it contain `@`? does it imitate a brand (`paypa1.com`)? does the visible text differ
   from the real destination?
4. **`sender_analyzer.py` – checking who sent it.** Is the address valid? Does "Example Bank" really come from
   `examplebank.com`, or from `examplebank-secure.com` or a Gmail account? Do replies go somewhere else? Did the
   mail server record an SPF/DMARC failure?
5. **`risk_scorer.py` – adding up the evidence.** Each warning sign is worth points (e.g. IP link = 20). Each sign
   counts once, each category has a maximum, and the total stops at 100. 0–29 = low, 30–59 = medium,
   60–100 = high.
6. **`phishing_engine.py` – putting it together.** It runs steps 1–5 and writes the advice.
7. **`db_manager.py`, `pdf_generator.py`, `app.py`** – saving results (without the email text, unless you allow
   it), making the PDF, and showing everything in the dashboard.

## E. Viva questions and answers
**Q1. Is this machine learning?** No. It is a rule-based expert system: hand-written rules with weights. That makes
every decision explainable, but it was not trained on data and the score is not a probability.

**Q2. Why not just check if the link uses HTTPS?** Because phishing sites also use HTTPS; free certificates are
easy to obtain. HTTPS means the connection is encrypted, not that the site is honest.

**Q3. Why don't you visit the URL to check it?** Visiting a phishing link can trigger downloads or exploits and tells
the attacker the address is active. Static checks are safe, and the project brief required them.

**Q4. How do you detect a lookalike domain?** By comparing the domain with the real domains of trusted brands:
small spelling differences (edit distance), swapped characters (0↔o, rn↔m), extra words (`examplebank-secure`)
and the real domain used as a subdomain (`examplebank.com.evil.xyz`).

**Q5. Why does the `@` symbol matter in a URL?** In `https://bank.com@198.51.100.7/` everything before `@` is a
username; the browser actually goes to 198.51.100.7.

**Q6. How do you prevent the score from being inflated?** Each indicator counts once, each category has a cap, and
the total is limited to 100.

**Q7. How do you avoid false positives?** Word boundaries, negation handling, no double counting of overlapping
phrases, length-dependent spelling thresholds, and not flagging free-mail or unfamiliar domains on their own.

**Q8. What are SPF, DKIM and DMARC?** Email authentication standards. SPF lists the servers allowed to send for a
domain, DKIM is a digital signature, and DMARC is the domain's policy for failures. The tool reads the receiving
server's results from the `Authentication-Results` header.

**Q9. How is the application secured?** Uploads are limited to .txt/.eml up to 5 MB; HTML is converted to text, not
rendered; email text is escaped before display; attachments and links are never opened; SQL is parameterised;
users don't see stack traces; nothing leaves the computer; bodies are not stored by default.

**Q10. What are the main limitations?** New wording, other languages and image-only emails can be missed; there are no
reputation lookups; and accuracy wasn't measured on a large real dataset.

**Q11. How would you improve it?** Evaluate it on a public dataset, add an interpretable ML model, add opt-in
reputation checks, DKIM verification and OCR for images/QR codes.
