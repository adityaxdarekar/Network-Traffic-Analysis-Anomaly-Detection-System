"""
Generate the sample .eml / .txt files in samples/eml/ (fictional senders, no live links).

    python samples/make_eml_samples.py

The "attachment" in delivery_scam.eml is a few bytes of harmless placeholder text named like a
disguised executable - it cannot run and the application never opens it anyway.
"""

from __future__ import annotations

from email.message import EmailMessage
from pathlib import Path

OUT = Path(__file__).resolve().parent / "eml"


def legit_order() -> EmailMessage:
    m = EmailMessage()
    m["From"] = "ExampleShop <orders@exampleshop.com>"
    m["To"] = "priya@example.net"
    m["Subject"] = "Your ExampleShop order #48213 has shipped"
    m["Date"] = "Thu, 05 Nov 2026 10:15:00 +0000"
    m["Message-ID"] = "<48213.shipped@exampleshop.com>"
    m["Authentication-Results"] = "mx.example.net; spf=pass smtp.mailfrom=exampleshop.com; dkim=pass; dmarc=pass"
    m.set_content("Hi Priya,\n\nGood news - order #48213 has shipped and should arrive on 12 November.\n"
                  "Track it at https://www.exampleshop.com/orders/48213\n\nThe ExampleShop Team")
    m.add_alternative("<html><body><p>Hi Priya,</p><p>Good news - order <b>#48213</b> has shipped and should "
                      "arrive on 12 November.</p><p><a href=\"https://www.exampleshop.com/orders/48213\">Track your "
                      "order</a></p><p>The ExampleShop Team</p></body></html>", subtype="html")
    return m


def bank_phish() -> EmailMessage:
    m = EmailMessage()
    m["From"] = "Example Bank <security@examplebank-alerts.com>"
    m["Reply-To"] = "examplebank.verify@gmail.com"
    m["To"] = "customer@example.net"
    m["Subject"] = "Unusual sign-in detected - verify your account"
    m["Date"] = "Thu, 05 Nov 2026 02:41:00 +0000"
    m["Message-ID"] = "<a81f@examplebank-alerts.com>"
    m["Authentication-Results"] = "mx.example.net; spf=fail smtp.mailfrom=examplebank-alerts.com; dkim=none; dmarc=fail"
    m.set_content("Dear customer, we detected an unusual sign-in. Verify your account within 24 hours.")
    m.add_alternative(
        "<html><head><script>alert('never executed')</script></head><body>"
        "<p>Dear customer,</p><p>We detected an <b>unusual sign-in attempt</b>. Your account will be suspended "
        "unless you verify your account within 24 hours.</p>"
        "<p><a href=\"http://198.51.100.23/examplebank/verify\">https://www.examplebank.com/secure</a></p>"
        "<p>Please have your card number and one-time password ready.</p></body></html>", subtype="html")
    return m


def delivery_scam() -> EmailMessage:
    m = EmailMessage()
    m["From"] = "ExampleParcel <tracking@exampleparcel-delivery.click>"
    m["To"] = "you@example.net"
    m["Subject"] = "Delivery failed - action required"
    m["Date"] = "Wed, 04 Nov 2026 18:03:00 +0000"
    m["Message-ID"] = "<x77@exampleparcel-delivery.click>"
    m.set_content("Your parcel could not be delivered. Open the attached label and pay the redelivery fee at "
                  "https://bit.ly/ep-redeliver within 48 hours.")
    m.add_attachment(b"Harmless placeholder text - not a program.", maintype="application",
                     subtype="octet-stream", filename="Delivery_Label.pdf.exe")
    return m


def main() -> None:
    OUT.mkdir(exist_ok=True)
    for name, msg in [("legit_order_shipped.eml", legit_order()), ("bank_phishing_html.eml", bank_phish()),
                      ("delivery_scam_attachment.eml", delivery_scam())]:
        (OUT / name).write_bytes(bytes(msg))
    (OUT / "job_offer.txt").write_text(
        "From: Recruitment Team <hr.offers.2026@gmail.com>\nSubject: Job offer: remote data entry, $450 per day\n\n"
        "Congratulations, you have been selected for a remote data entry position. No experience needed.\n"
        "A registration fee of $50 is required. Please respond as soon as possible.\n", encoding="utf-8")
    print(f"Samples written to {OUT}")


if __name__ == "__main__":
    main()
