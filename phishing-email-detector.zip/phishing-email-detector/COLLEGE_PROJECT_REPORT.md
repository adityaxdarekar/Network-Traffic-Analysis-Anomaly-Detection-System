# Phishing Email Detection and Analysis System Using Python

*College project report*

---

## Abstract
Phishing emails remain one of the most common ways of stealing credentials and spreading malware. They imitate
trusted organisations and pressure the reader into clicking a link, entering a password or opening an
attachment. This project designs and implements a rule-based phishing email detection and analysis system in
Python. The system accepts an email as manually entered text, a plain-text file or a standard `.eml` file. It
parses the sender, subject, plain-text and HTML body, links and attachments, and applies four groups of
detectors: suspicious keywords and language, static URL analysis, sender and domain analysis, and attachment
analysis. Each triggered rule becomes a weighted indicator. A scoring engine combines the indicators into a
0–100 risk score, using per-category caps and de-duplication, and classifies the email as low, medium or high
risk. Every indicator is explained to the user together with recommended actions. The application provides a
Streamlit dashboard, a local SQLite scan history, and PDF and CSV reports. It processes all data locally, never
opens links or attachments, and does not store email bodies by default. The implementation was verified with
144 automated tests and with an end-to-end evaluation on a purpose-built dataset of ten fictional emails and
four sample files, all of which were classified as intended. The system is a transparent heuristic tool. Its
scores are not statistically validated probabilities.

## 1. Introduction
Email is the primary communication channel of universities, businesses and service providers, and it is
therefore also a primary attack channel. In a phishing attack the sender pretends to be a trusted organisation,
such as a bank, an online shop, a parcel service, an employer or the university IT desk. The email persuades the
recipient to perform a harmful action: logging in on a fake page, sending a one-time code, paying a fee or
opening a malicious file.

Phishing emails share recognisable features. These include urgent or threatening language, requests for
confidential information, links that hide their real destination, sender addresses that imitate a known domain,
and attachments with dangerous file types. Experienced users check these features manually. This project
automates the checks, combines them into a score and explains the result, so that the system can support users
and also teach them what to look for.

## 2. Problem statement
Users receive many emails and cannot reliably tell genuine messages from phishing ones. The warning signs are
spread across the header, the text, the HTML markup and the attachments, and some are invisible in a normal mail
client (for example a link whose visible text differs from its real target). Conventional spam filters return a
verdict without explanation and may not be available for emails received through other channels. Opening a
suspicious link or attachment just to check it is itself dangerous. The problem addressed by this project is to
build a tool that:
- examines all relevant parts of an email without opening any link or attachment,
- detects common phishing indicators,
- combines them into a transparent risk assessment, and
- explains each finding and the recommended action in plain language.

## 3. Existing system
The common existing approaches are:
1. **Manual inspection by the user.** This depends on the user's knowledge and attention, and hidden link targets
   and spoofed headers are easily missed.
2. **Mail-provider spam and phishing filters.** These are effective at scale but act as a black box: messages are
   moved to a spam folder without an explanation the user can learn from, and the user cannot analyse a message
   received elsewhere.
3. **Online URL/file scanning services.** These require uploading the email or link to a third party, which may
   be undesirable for private messages.
4. **Machine-learning classifiers in research.** These can achieve high accuracy on their training data but need
   large labelled datasets, can be hard to explain, and may not generalise to new campaigns.

Limitations of the existing approaches: little or no explanation, privacy concerns when content is sent to
external services, and dependence on large datasets.

## 4. Proposed system
The proposed system is a local, explainable, rule-based analyser:
- Three input methods (manual, `.txt`, `.eml`), with support for plain-text and HTML bodies.
- Independent detectors for language, URLs, sender and attachments, each with configurable patterns.
- A weighted scoring engine with de-duplication, category caps and a 0–100 range.
- A three-level classification with an explanation and evidence for each indicator, and recommendations.
- A dashboard with history, statistics and reports.
- Security by design: links are never visited, attachments are never opened, HTML is never rendered, content is
  never transmitted, and email bodies are stored only if the user opts in.

## 5. Objectives
1. Parse emails from manual input, `.txt` and `.eml` files safely, including HTML bodies and attachment metadata.
2. Detect suspicious keywords, urgency, sensitive-information requests and risky attachments while avoiding
   harmless matches.
3. Extract URLs and analyse them statically for at least eleven risk characteristics.
4. Detect sender anomalies: invalid format, lookalike domains, brand impersonation, display-name and Reply-To
   mismatches and authentication failures.
5. Compute an explainable weighted risk score and classify emails into three risk levels.
6. Store scan results locally and generate PDF and CSV reports.
7. Verify the implementation with automated tests and an end-to-end evaluation on sample emails.

## 6. Scope
**In scope:** analysis of individual emails supplied by the user, in English, in plain text, HTML or `.eml`
format; static analysis of URLs and attachment names; reading existing authentication-result headers; a local
dashboard for one user; reports for individual scans and the scan history.

**Out of scope:** connecting to mailboxes (IMAP/POP/Exchange), scanning attachment contents for malware,
visiting URLs or querying reputation services, verifying DKIM signatures cryptographically, machine-learning
classification, multi-user deployment, and non-English emails.

## 7. Hardware requirements
| Component | Minimum | Recommended |
|---|---|---|
| Processor | any 64-bit dual-core CPU | quad-core |
| RAM | 2 GB | 4 GB |
| Storage | 300 MB (Python packages + project) | 1 GB |
| Display | 1280 × 720 | 1920 × 1080 |
| Network | needed only once, to install packages | – |

## 8. Software requirements
| Software | Version |
|---|---|
| Operating system | Windows 10/11, Ubuntu 22.04+/Kali Linux, or macOS |
| Python | 3.11 or newer |
| Streamlit | ≥ 1.50 |
| Plotly | ≥ 5.18 |
| pandas | ≥ 2.0 |
| BeautifulSoup4 | ≥ 4.12 |
| ReportLab | ≥ 4.0 |
| SQLite | bundled with Python |
| pytest, pypdf | for testing |
| Web browser | any current browser |

## 9. System architecture
The system follows a pipeline architecture with independent detector modules:

```
 User input (manual / .txt / .eml)
            │
            ▼
 ┌──────────────────────┐
 │ Email Parser          │  validation (type, size, empty, binary) · header extraction ·
 │                       │  HTML→text (scripts removed) · links + visible text · attachment metadata
 └──────────┬───────────┘
            │ ParsedEmail
   ┌────────┼──────────────┬────────────────┐
   ▼        ▼              ▼                ▼
 Keyword  Language /     URL Analyzer     Sender Analyzer
 Detector Attachment     (static checks)  (format, spoofing,
          detectors                        auth results)
   └────────┴──────┬───────┴────────────────┘
                   ▼
            Risk Scorer  (weights · once per indicator · category caps · ≤100 · thresholds)
                   ▼
            Phishing Engine → AnalysisResult (score, level, indicators, URL table, sender, recommendations)
          ┌────────┼─────────────┐
          ▼        ▼             ▼
   Streamlit UI  SQLite DB   PDF / CSV / JSON reports
```

## 10. Module descriptions
| Module | Description |
|---|---|
| `config.py` | Central configuration: scoring weights, category caps, thresholds, keyword dictionary with explanations, urgency and sensitive-data patterns, risky attachment types, URL shorteners, suspicious TLDs, free-mail providers, trusted brands and their domains, input limits, privacy defaults. |
| `detector/email_parser.py` | Builds a `ParsedEmail` from manual fields, `.txt` (optional header lines) or `.eml` (Python `email` package with the modern policy). Converts HTML to text with BeautifulSoup after removing scripts, styles and frames; extracts `<a href>` links with their visible text; lists attachments without opening them; validates file type, size, emptiness and binary content; handles malformed files and unknown character sets. |
| `detector/keyword_detector.py` | Finds dictionary phrases (case-insensitive, word boundaries), urgent language, sensitive-information requests and attachment risks. Ignores negated phrases and overlapping weaker phrases, and counts each phrase once. |
| `detector/url_analyzer.py` | Extracts URLs with a regular expression and from HTML, and performs static checks: IP host (including decimal/hex), `@`, punycode, shortener, misleading/lookalike domain, link-text mismatch, subdomain depth, length, encoding, suspicious characters and words, uncommon TLD, `javascript:` links. Includes registered-domain approximation, Levenshtein distance and homoglyph normalisation. Performs no network access. |
| `detector/sender_analyzer.py` | Validates the address format and detects lookalike domains, brand impersonation via free-mail or unrelated domains, addresses hidden in display names, unusual local parts, Reply-To mismatches and failed SPF/DKIM/DMARC results. Adds neutral notes rather than findings for free-mail and unfamiliar domains. |
| `detector/risk_scorer.py` | Defines `Indicator`, removes duplicates, sums points per category, applies caps, limits the total to 100 and classifies. |
| `detector/phishing_engine.py` | Orchestrates all detectors, builds indicators, scores them and generates recommendations and the disclaimer; serialises the result. |
| `database/db_manager.py` | SQLite storage using parameterised queries: save, list with filters, details, delete, clear, statistics, CSV export. Bodies are stored only on request. |
| `reports/pdf_generator.py` | ReportLab PDF with scan metadata, score box, score breakdown, sender analysis, keywords, URL analysis, detailed findings and recommendations; all email text is escaped. |
| `app.py`, `dashboard/*` | Streamlit interface: Home Dashboard, Analyze Email, URL Analysis, Scan History, Reports, About Project, plus privacy settings. Email-derived text is HTML-escaped before display, and errors are shown as friendly messages without stack traces. |

## 11. Algorithms
**Algorithm 1 – Keyword detection with negation and overlap handling**
```
input: text, dictionary of (pattern, level, explanation)
sort dictionary by level (high→low), then phrase length (long→short)
taken ← ∅
for each entry in dictionary:
    for each regex match m of \b pattern \b (case-insensitive) in text:
        if a negation word (never, not, do not …) occurs within 45 characters before m in the same sentence: skip
        if m lies inside a span in taken: skip
        record m; add span(m) to taken
    if any match recorded: output one hit for this entry (counted once)
```

**Algorithm 2 – Static URL analysis**
```
for each URL u (from regex over text and from <a href> with visible text t):
    parse u with urllib.parse (no network)
    host ← hostname; reg ← registered domain (last 2 labels, or 3 for known two-level suffixes)
    apply checks: IP host, '@' in netloc, punycode/non-ASCII, shortener list,
                  brand lookalike(host), brand in path, subdomain depth > 3, uncommon TLD,
                  t shows a domain whose registered domain ≠ reg, length > 100, %-encoding,
                  suspicious characters, suspicious words, javascript: scheme
    risk(u) ← highest risk among its findings (None if no findings)
```

**Algorithm 3 – Lookalike domain detection**
```
input: domain d, trusted brands B (brand → legitimate domains)
reg ← registered_domain(d); label ← first label of reg
if reg is a legitimate domain of any brand: return none
for each brand b with legitimate domain r (label r₁):
    if d contains r as a subdomain (r.attacker.tld): return lookalike
    if label = r₁ but TLD differs: return lookalike
    if len(r₁) ≥ 6 and Levenshtein(label, r₁) ≤ (2 if len(r₁) ≥ 8 else 1): return lookalike
    if homoglyph_normalise(label) = homoglyph_normalise(r₁): return lookalike      (0→o, 1→l, rn→m …)
    if b is a subdomain label of d, a hyphen token of label, or a prefix of label: return lookalike
return none
```

**Algorithm 4 – Risk scoring**
```
indicators ← keyword hits, urgency, sensitive request, attachment risk,
             one indicator per URL check type, one per sender finding (each with its weight)
remove duplicate indicator ids
for each category c: points(c) ← min(Σ points of indicators in c, cap(c))
score ← min(100, Σ points(c))
level ← HIGH if score ≥ 60, MEDIUM if score ≥ 30, else LOW
```

## 12. Implementation
The system was implemented in Python 3 (about 2,300 lines of application code and 720 lines of tests). Important
implementation decisions:

- **Safety of untrusted input.** Emails are treated as hostile. HTML is parsed with BeautifulSoup's `html.parser`
  and only text is extracted; `<script>`, `<style>`, `<iframe>`, `<object>` and `<embed>` content is discarded.
  Attachments are enumerated from the MIME structure, and only their name, type and size are recorded. URLs are
  analysed with `urllib.parse` and `ipaddress` only, and a test patches the socket functions to prove that no
  connection is attempted. In the dashboard all email-derived text is passed through `html.escape` before it is
  shown, and the analysed body is displayed with `st.text`, never as HTML. PDF text is escaped as well.
- **Input validation.** Only `.txt` and `.eml` files up to 5 MB are accepted, binary content in `.txt` files is
  rejected, malformed `.eml` files and unknown character sets produce clear error messages, and bodies longer
  than 200,000 characters are truncated.
- **Analysing both MIME parts.** During development, a test `.eml` file showed that analysing only the plain-text
  part missed requests that appeared only in the HTML part. The parser now analyses both parts when they differ,
  because attackers can make the two parts say different things.
- **Reducing false positives.** Negation handling (a legitimate shop writes "we will never ask for your
  password"), overlap handling, word boundaries, length-dependent edit-distance thresholds (so that `amazing.com`
  is not treated as `amazon.com`), token/prefix matching for brand names (so that `pineapple.com` is not treated
  as `apple.com`), and allow-listed brand domains (`amazonaws.com`, `googleapis.com`).
- **Gap found during testing.** The first version did not recognise a brand used as a subdomain of an unrelated
  domain (`exampleshop.account-verify.top`). The sample email U1 exposed this, and the check was added to the
  detector instead of changing the sample.
- **Privacy.** The database stores sender, subject, score, classification, indicator count, summary and the
  structured findings. The email body is stored only if the user enables this in the sidebar. The Streamlit
  server is bound to 127.0.0.1, error details are hidden from users, and usage statistics are disabled.
- **Dashboard.** Six pages share helpers for KPI cards, charts and tables. A Plotly gauge shows the score, and tabs
  separate findings, sender analysis, keywords, URLs and recommendations. Reports can be produced for the current
  scan or for any stored scan, because the stored findings contain everything the PDF generator needs.

## 13. Testing
**Automated testing.** 144 pytest tests in seven files were executed in the development environment (Ubuntu 24.04,
Python 3.13): **144 passed, 0 failed**. The source code also compiles on Python 3.11 and 3.12.

| Area | Tests | Examples |
|---|---|---|
| Email parsing | 20 | header lines in .txt; HTML and plain parts; scripts removed; attachments listed; invalid type, empty, oversized, binary, malformed `.eml`, unknown charset |
| Keyword detection | 18 | ten phrases in mixed case; repeated phrase counted once; negation; overlap; harmless text; word boundaries |
| URL analysis | 35 | extraction from text and HTML; IP-based URLs (IPv4, IPv6, decimal, hex); shorteners; `@`; punycode; subdomains; six misleading and seven legitimate domains; HTTPS not treated as safe; no network access |
| Sender analysis | 20 | invalid formats; official domain; lookalike; brand on free mail; free mail alone not flagged; display-name, Reply-To and authentication checks |
| Risk scoring | 26 | thresholds 29/30/59/60; de-duplication; category caps; maximum 100; every sample classified as intended |
| Database and reports | 10 | privacy default; optional body storage; filtering and deletion; SQL-injection-safe search; CSV; PDF contents and escaping |
| Dashboard | 15 | all pages; sample-to-history workflow; `.eml` upload; friendly error for malformed upload; empty input; settings; HTML escaping |

The dashboard tests use a stand-in module that executes the real page code without a browser, because Streamlit
could not be installed in the development environment. The visual appearance of the pages must therefore be
checked in a browser on the target computer.

**Manual end-to-end testing.** Each of the ten sample emails and four sample files was analysed through the same
pipeline used by the dashboard (see Results).

## 14. Results
| ID | Sample | Intended | Classified | Score | Main indicators |
|---|---|---|---|---|---|
| L1 | University timetable announcement | Low | Low | 0 | none |
| L2 | Order confirmation ("we will never ask for your password") | Low | Low | 0 | none (negation handled) |
| L3 | Colleague's meeting reminder | Low | Low | 0 | none |
| P1 | Fake bank verification | High | High | 100 | IP link, lookalike sender, account threats, password + card request, urgency |
| P2 | Fake IT password reset | High | High | 95 | brand on Gmail, password expired, shortener, password request |
| P3 | Package delivery scam | High | High | 90 | brand-as-subdomain URL, lookalike sender `examp1eparcel.com`, `.pdf.exe` |
| S1 | Fake job offer | Medium | Medium | 40 | "selected", registration fee, urgency, "no experience needed" |
| S2 | Gift card survey | Medium | Medium | 35 | "claim your reward", gift card, "expires today" |
| U1 | HTML link text ≠ destination | High | High | 65 | link-text mismatch, brand-as-subdomain URL, lookalike sender |
| U2 | Obfuscated document link | Medium | Medium | 45 | `@` in URL, IP host, shortener |
| – | `legit_order_shipped.eml` | – | Low | 0 | SPF/DKIM/DMARC pass |
| – | `bank_phishing_html.eml` | – | High | 100 | SPF/DMARC fail, Reply-To to Gmail, IP link behind official-looking text |
| – | `delivery_scam_attachment.eml` | – | High | 60 | attachment `Delivery_Label.pdf.exe`, shortener, lookalike sender |
| – | `job_offer.txt` | – | Medium | 40 | as S1 |

All ten samples were classified as intended. The three legitimate emails scored 0, and every non-legitimate
email produced at least three explained indicators. These results demonstrate that the rules work as designed on
examples written for this project. They are **not** an estimate of accuracy on real-world email, which would
require evaluation on a large, independent, labelled dataset.

## 15. Advantages
- **Explainable:** every point of the score is linked to a named rule, an explanation and evidence.
- **Private and safe:** fully local; no link or attachment is opened; HTML is not rendered; bodies are not stored by default.
- **Configurable:** weights, thresholds, phrases and trusted brands are kept in one file.
- **Fair scoring:** de-duplication and category caps prevent a single repeated signal from dominating.
- **Educational:** explanations and recommendations teach users what to look for.
- **Practical:** handles real `.eml` files including HTML parts, authentication headers and attachments; offers history and reports.
- **Lightweight:** no training data or GPU required.

## 16. Limitations
- Rule-based detection can miss new wording, other languages, image-only emails and targeted spear-phishing, and
  can occasionally rate unusual legitimate emails as suspicious.
- No domain-reputation, blocklist or WHOIS information is used, by design.
- Lookalike detection is limited to the configured brands; registered-domain detection is approximate.
- Authentication results are read from headers, not verified.
- Attachment contents are not scanned.
- Weights are expert-chosen, not statistically calibrated; accuracy on real-world data was not measured.

## 17. Future scope
- Quantitative evaluation (precision, recall, false-positive rate) on public phishing and legitimate email corpora.
- A hybrid approach combining the rules with an interpretable machine-learning model.
- Opt-in reputation services and full Public Suffix List support.
- DKIM signature verification and header-path analysis.
- OCR for image-based emails and QR codes ("quishing").
- Integration as a mail-client add-in, and multilingual dictionaries.

## 18. Conclusion
The Phishing Email Detection and Analysis System meets its objectives. It accepts emails in three formats, applies
language, URL, sender and attachment analysis, and produces a transparent 0–100 risk score with a three-level
classification. Every finding is explained. Strict safety rules ensure that suspicious content is never executed,
opened or sent elsewhere. The dashboard, local history and PDF/CSV reports make the system easy to use and
demonstrate. The automated test suite and the end-to-end evaluation confirm that the implementation behaves as
designed, and the documented limitations show where the system should be extended before any real-world
deployment.

## 19. References
1. Anti-Phishing Working Group (APWG). *Phishing Activity Trends Reports*. https://apwg.org/trendsreports/
2. Cybersecurity and Infrastructure Security Agency (CISA). *Avoiding Social Engineering and Phishing Attacks*. https://www.cisa.gov/
3. National Cyber Security Centre (UK). *Phishing attacks: defending your organisation*. https://www.ncsc.gov.uk/guidance/phishing
4. MITRE ATT&CK. *T1566 Phishing* (and sub-techniques T1566.001 Spearphishing Attachment, T1566.002 Spearphishing Link). https://attack.mitre.org/techniques/T1566/
5. Resnick, P. (Ed.). *RFC 5322: Internet Message Format*. IETF, 2008.
6. Kitterman, S. *RFC 7208: Sender Policy Framework (SPF)*. IETF, 2014; Kucherawy, M. & Zwicky, E. *RFC 7489: DMARC*. IETF, 2015.
7. Costello, A. *RFC 3492: Punycode*. IETF, 2003.
8. Python Software Foundation. `email`, `re`, `urllib.parse`, `ipaddress`, `sqlite3` documentation. https://docs.python.org/3/
9. BeautifulSoup documentation. https://www.crummy.com/software/BeautifulSoup/bs4/doc/
10. Streamlit documentation. https://docs.streamlit.io/ · ReportLab User Guide. https://docs.reportlab.com/
