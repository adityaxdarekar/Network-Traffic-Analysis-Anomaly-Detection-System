#!/usr/bin/env bash
# One-time setup (Linux / macOS): virtual environment + dependencies.
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv venv || { echo "Install python3-venv first:  sudo apt install -y python3-venv python3-pip"; exit 1; }
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
echo; echo "Done.  Run the app: ./run.sh    Run the tests: ./venv/bin/python -m pytest -v"
