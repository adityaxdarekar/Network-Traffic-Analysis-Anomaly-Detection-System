"""
Central configuration for the Phishing Email Detection and Analysis System.

Everything that decides *how suspicious* something is lives here, so it can be
reviewed and tuned without touching the detection code:
  * scoring weights and per-category caps
  * risk thresholds
  * phishing keyword dictionary (with an explanation for every phrase)
  * trusted brands and their legitimate domains
  * URL shorteners, free e-mail providers, risky attachment extensions
"""

from __future__ import annotations

import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SAMPLES_DIR = BASE_DIR / "samples"
OUTPUT_DIR = BASE_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
DB_PATH = OUTPUT_DIR / "scan_history.db"
SETTINGS_FILE = BASE_DIR / "user_settings.json"
STYLE_FILE = BASE_DIR / "assets" / "style.css"

APP_TITLE = "Phishing Email Detection and Analysis System"
APP_SHORT = "Phishing Email Detector"
APP_VERSION = "1.0.0"

# --------------------------------------------------------------------------- input limits
MAX_UPLOAD_BYTES = 5 * 1024 * 1024          # 5 MB per uploaded file
ALLOWED_UPLOAD_EXTENSIONS = {".txt", ".eml"}
MAX_BODY_CHARS = 200_000                    # longer bodies are truncated before analysis
MAX_URLS = 200                              # analyse at most this many URLs per e-mail

# --------------------------------------------------------------------------- scoring
RISK_THRESHOLDS = {"MEDIUM": 30, "HIGH": 60}   # 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH
RISK_LABELS = {
    "LOW": "SAFE / LOW RISK",
    "MEDIUM": "SUSPICIOUS / MEDIUM RISK",
    "HIGH": "HIGH RISK / LIKELY PHISHING",
}
RISK_COLORS = {"LOW": "#22c55e", "MEDIUM": "#f59e0b", "HIGH": "#ef4444"}

# Points per indicator. Each indicator is counted ONCE per e-mail, however often it appears.
WEIGHTS = {
    # keywords / language
    "keyword_low": 5,              # mildly suspicious phrase ("click here")
    "keyword_medium": 10,          # typical phishing phrase ("verify your account")
    "keyword_high": 15,            # strong phishing phrase ("your account has been suspended")
    "urgency": 10,                 # urgent or threatening language
    "sensitive_request": 15,       # asks for password / card / OTP / SSN
    "attachment_reference": 10,    # mentions or carries a risky attachment
    # URLs
    "url_ip": 20,
    "url_shortener": 10,
    "url_http": 5,
    "url_at_symbol": 15,
    "url_punycode": 15,
    "url_brand_mismatch": 25,      # brand name in a URL whose domain is not the brand's
    "url_text_mismatch": 20,       # link text shows one domain, link goes to another
    "url_many_subdomains": 10,
    "url_long": 5,
    "url_encoded": 5,
    "url_suspicious_chars": 5,
    "url_keywords": 5,
    "url_suspicious_tld": 5,
    # sender
    "sender_invalid": 15,
    "sender_lookalike": 20,
    "sender_brand_freemail": 20,
    "sender_display_mismatch": 15,
    "sender_reply_to_mismatch": 10,
    "sender_digits": 5,
    "sender_punycode": 15,
    "sender_auth_fail": 15,
}

# Category caps stop one kind of evidence from dominating the score.
CATEGORY_CAPS = {"Keywords": 35, "Language": 25, "URLs": 45, "Sender": 40, "Attachments": 15}

# --------------------------------------------------------------------------- keyword dictionary
# level: low / medium / high  -> keyword_low / keyword_medium / keyword_high weights
# Patterns are regular expressions matched case-insensitively on word boundaries.
KEYWORDS = [
    # account threats
    {"phrase": "your account has been suspended", "pattern": r"account (has been|was|is) (suspended|locked|disabled|restricted|compromised)",
     "category": "Account threat", "level": "high",
     "why": "Claims your account is blocked to frighten you into acting before thinking."},
    {"phrase": "your account will be closed", "pattern": r"account will be (closed|suspended|terminated|deleted|deactivated|locked)",
     "category": "Account threat", "level": "high",
     "why": "Threatens loss of the account to create pressure."},
    {"phrase": "unusual login detected", "pattern": r"(unusual|suspicious|unauthori[sz]ed) (login|sign[- ]?in|activity|access)( attempt)?",
     "category": "Account threat", "level": "medium",
     "why": "Fake security alerts are a common lure; real alerts can be checked in the official app or website."},
    {"phrase": "password expired", "pattern": r"password (has )?(expired|expires|will expire)",
     "category": "Credential lure", "level": "medium",
     "why": "Password-expiry notices are used to send people to fake login pages."},
    # verification
    {"phrase": "verify your account", "pattern": r"verify (your )?(account|identity|details|information|email)",
     "category": "Verification request", "level": "medium",
     "why": "Requests to 'verify' an account through a link are the classic credential-phishing pattern."},
    {"phrase": "confirm your identity", "pattern": r"confirm (your )?(identity|account|password|details|credentials)",
     "category": "Verification request", "level": "medium",
     "why": "Legitimate services rarely ask you to confirm your identity through an e-mail link."},
    {"phrase": "bank verification required", "pattern": r"bank (account )?verification (is )?required",
     "category": "Verification request", "level": "high",
     "why": "Banks do not ask customers to verify accounts through e-mail links."},
    {"phrase": "update payment details", "pattern": r"update (your )?(payment|billing|card|bank) (details|information|method|info)",
     "category": "Financial lure", "level": "medium",
     "why": "Payment-update requests aim to steal card or bank details."},
    # calls to action
    {"phrase": "click here immediately", "pattern": r"click (here|the link|below) (immediately|now|right away|urgently)",
     "category": "Call to action", "level": "medium",
     "why": "Pushes you to click before checking where the link goes."},
    {"phrase": "click here", "pattern": r"click here",
     "category": "Call to action", "level": "low",
     "why": "Generic link text hides the destination; legitimate e-mails usually name the page."},
    {"phrase": "log in to avoid", "pattern": r"(log ?in|sign ?in) (now )?to (avoid|prevent|restore|reactivate|unlock)",
     "category": "Call to action", "level": "medium",
     "why": "Combines a login request with a threat."},
    # prizes / money
    {"phrase": "congratulations, you won", "pattern": r"congratulations,? you('ve| have)? (won|been selected)",
     "category": "Prize scam", "level": "high",
     "why": "Unexpected winnings are a classic advance-fee and data-harvesting scam."},
    {"phrase": "claim your prize", "pattern": r"claim (your )?(prize|reward|gift|winnings|refund)",
     "category": "Prize scam", "level": "high",
     "why": "Asking you to 'claim' something you did not enter for is a common lure."},
    {"phrase": "processing fee", "pattern": r"(processing|release|registration|clearance|delivery|customs) fee",
     "category": "Advance fee", "level": "medium",
     "why": "Asking for a small fee to release a parcel, prize or job is typical of scams."},
    {"phrase": "no experience needed", "pattern": r"no (prior )?experience (is )?(needed|required)",
     "category": "Job scam", "level": "low",
     "why": "Very easy, very well-paid job offers are a frequent recruitment scam."},
    {"phrase": "package could not be delivered", "pattern": r"(package|parcel|shipment|delivery) (could not|couldn't|cannot|was unable to) be delivered|failed delivery attempt",
     "category": "Delivery scam", "level": "medium",
     "why": "Fake delivery-failure notices lead to payment or credential pages."},
    {"phrase": "gift card", "pattern": r"gift ?cards?",
     "category": "Financial lure", "level": "medium",
     "why": "Requests to buy or send gift cards are almost always fraud."},
    {"phrase": "wire transfer", "pattern": r"wire transfer|bitcoin|crypto(currency)? wallet",
     "category": "Financial lure", "level": "medium",
     "why": "Untraceable payment methods are preferred by fraudsters."},
]

URGENCY_PATTERNS = [
    r"urgent(ly)?( action)?( required)?", r"immediate(ly)? (action|response|attention)( required)?",
    r"act now", r"within (24|48|72) hours", r"within \d+ (minutes|hours)", r"expires? (today|tonight|soon)",
    r"final (notice|warning|reminder)", r"last (chance|warning)", r"(legal action|penalty|fine|arrest)",
    r"respond (immediately|now|asap|urgently)", r"failure to (respond|comply|verify)",
    r"as soon as possible", r"time[- ]sensitive", r"don'?t delay",
]

SENSITIVE_PATTERNS = [
    (r"(your|enter|provide|send|confirm|share|reply with)( your)? (current )?(password|passcode|pin)\b", "password / PIN"),
    (r"(credit|debit) card (number|details)|card number|\bcvv\b|\bcvc\b|security code", "payment card details"),
    (r"(social security|ssn|national insurance|aadhaar|pan) (number)?", "national ID number"),
    (r"(one[- ]time password|\botp\b|verification code|2fa code|authenticat(ion|or) code)", "one-time / 2FA code"),
    (r"(bank|account) (login|credentials|username and password)|login credentials|username and password", "login credentials"),
    (r"(date of birth|mother'?s maiden name)", "personal security answers"),
    (r"(routing|sort) (number|code)|\biban\b|account number", "bank account number"),
]
# A sensitive phrase preceded by one of these (within ~45 characters) is a reassurance, not a request:
# "We will NEVER ask for your password".
NEGATION_PATTERN = r"\b(never|not|n't|no one|nobody|don't|do not|will not|won't)\b"

RISKY_ATTACHMENT_EXT = {
    ".exe", ".scr", ".js", ".jse", ".vbs", ".vbe", ".bat", ".cmd", ".com", ".pif", ".msi", ".ps1", ".hta",
    ".jar", ".lnk", ".iso", ".img", ".zip", ".rar", ".7z", ".docm", ".xlsm", ".pptm", ".html", ".htm",
}
ATTACHMENT_PATTERNS = [
    r"(open|download|see|view|run|enable) (the )?(attached|attachment|enclosed)",
    r"enable (macros|content|editing)",
    r"\b[\w-]+\.(exe|scr|js|vbs|bat|cmd|zip|rar|7z|docm|xlsm|iso|img|html?|lnk|hta|msi)\b",
]

# --------------------------------------------------------------------------- URLs
URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly",
    "shorturl.at", "tiny.cc", "rb.gy", "s.id", "t.ly", "bl.ink", "short.io", "lnkd.in", "v.gd", "qr.ae",
}
URL_SUSPICIOUS_WORDS = [
    "login", "log-in", "signin", "sign-in", "verify", "verification", "account", "update", "secure",
    "security", "confirm", "banking", "password", "unlock", "suspend", "wallet", "billing", "webscr",
]
SUSPICIOUS_TLDS = {".zip", ".mov", ".xyz", ".top", ".click", ".country", ".gq", ".tk", ".ml", ".cf", ".ga",
                   ".work", ".rest", ".fit", ".loan"}
LONG_URL_LENGTH = 100
MAX_SUBDOMAINS = 3          # more labels than this before the registered domain is suspicious

# Common two-level public suffixes so "bank.co.uk" is treated as the registered domain.
TWO_LEVEL_SUFFIXES = {
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.in", "ac.in", "gov.in", "org.in",
    "co.jp", "co.nz", "com.br", "com.mx", "co.za", "com.sg", "com.my", "edu.au", "edu.in",
}

# --------------------------------------------------------------------------- sender
FREE_EMAIL_PROVIDERS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.in", "outlook.com", "hotmail.com", "live.com",
    "aol.com", "icloud.com", "me.com", "proton.me", "protonmail.com", "gmx.com", "mail.com", "yandex.com",
    "zoho.com", "rediffmail.com",
}

# Trusted brands -> legitimate domains. Used to spot impersonation and lookalike domains.
# The fictional "Example" brands are used by the sample dataset; real brands are included only as
# names and their official domains, so that impersonation of them can be recognised.
TRUSTED_BRANDS = {
    "examplebank": ["examplebank.com"],
    "exampleshop": ["exampleshop.com"],
    "exampleparcel": ["exampleparcel.com"],
    "exampleuniversity": ["exampleuniversity.edu"],
    "paypal": ["paypal.com"],
    "amazon": ["amazon.com", "amazon.in", "amazon.co.uk", "amazonaws.com"],
    "microsoft": ["microsoft.com", "office.com", "outlook.com", "live.com"],
    "google": ["google.com", "gmail.com", "googleapis.com", "googleusercontent.com", "googlemail.com"],
    "apple": ["apple.com", "icloud.com"],
    "netflix": ["netflix.com"],
    "dhl": ["dhl.com"],
    "fedex": ["fedex.com"],
    "linkedin": ["linkedin.com"],
}
# Brand words inside a domain that are too short/common to match on their own are skipped here.
MIN_BRAND_LENGTH = 4

# --------------------------------------------------------------------------- privacy / settings
DEFAULT_SETTINGS = {
    "store_email_body": False,      # privacy: bodies are NOT stored in scan history by default
    "save_scans": True,
}


def default_settings() -> dict:
    return json.loads(json.dumps(DEFAULT_SETTINGS))


def load_settings(path: Path | None = None) -> dict:
    path = path or SETTINGS_FILE
    settings = default_settings()
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            settings.update({k: v for k, v in data.items() if k in settings})
    except (OSError, ValueError):
        pass
    return settings


def save_settings(settings: dict, path: Path | None = None) -> None:
    path = path or SETTINGS_FILE
    Path(path).write_text(json.dumps(settings, indent=2), encoding="utf-8")
