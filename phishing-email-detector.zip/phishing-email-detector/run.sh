#!/usr/bin/env bash
# Start the dashboard on http://localhost:8501 (listens on this computer only).
set -euo pipefail
cd "$(dirname "$0")"
[ -x ./venv/bin/python ] || { echo "Run ./setup.sh first."; exit 1; }
exec ./venv/bin/python -m streamlit run app.py
