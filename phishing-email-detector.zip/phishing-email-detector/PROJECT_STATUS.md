# Project Status

**Code status: complete.** All features in the brief are implemented. One verification step must be done on
your own computer.

## Verified in the development environment (Ubuntu 24.04, Python 3.13)
- [x] All detector modules, scoring engine, database, PDF/CSV reports
- [x] `pytest`: **144 passed, 0 failed**; syntax checked on Python 3.11, 3.12 and 3.13
- [x] End-to-end: all 10 sample emails classified as intended, plus 4 sample files (results in README §12)
- [x] PDF reports rendered and visually checked; real samples in `sample_output/`
- [x] All 6 dashboard pages executed headlessly with a Streamlit stand-in, including load sample → analyze →
      history, .eml upload, malformed upload, settings, delete, report saving and HTML escaping
- [x] No network access during URL analysis (enforced by a test)

## To do on your computer
- [ ] **Open the dashboard in a browser.** Streamlit and Plotly could not be installed in the development
      environment (no internet access), so the page code was executed but the visual layout was not seen.
      Run `./setup.sh` then `./run.sh` (Windows: `setup.bat`, `run.bat`) and click through the 6 pages.
- [ ] **Take dashboard screenshots**: see `screenshots/README.md`.
- [ ] Optional: `python -m pytest -v` on your computer (expected: 144 passed).
