# Phishing Email Detection and Analysis System Using Python

A rule-based phishing email analyser with a Streamlit dashboard. Paste an email or upload a `.txt` / `.eml`
file. The system checks the **sender**, **subject**, **body**, **links** and **attachments**, gives a
**0–100 risk score**, classifies the email as **SAFE / LOW**, **SUSPICIOUS / MEDIUM** or **HIGH RISK / LIKELY
PHISHING**, and explains every finding.

> **Important:** this is a rule-based detection system. The score is a heuristic, not a statistically
> validated probability. Findings are indicators, not proof that an email is malicious, and a low score
> does not guarantee that an email is safe.
>
> All analysis runs locally. Links are never opened, attachments are never opened, and no email content
> is ever sent to an external service.

---

## 1. Project introduction
Phishing emails trick people into revealing passwords, card numbers or one-time codes, or into opening
malware, by imitating banks, shops, delivery companies, universities and employers. This project
recognises the typical warning signs of phishing automatically and explains them in plain language. It is
useful both as a practical checking tool and as a way to teach how to spot phishing.

## 2. Problem statement
Ordinary users cannot easily judge whether an email is genuine. The signs are spread across several
places: a lookalike sender domain, an urgent tone, a request for a password, a link whose real destination
differs from its text, a disguised attachment. Spam filters give a yes/no answer without explanation. Users
need a tool that examines all of these parts, weighs the evidence transparently and explains *why* an email
is suspicious, without the risk of opening the email's links or files.

## 3. Objectives
1. Accept emails as manual input, `.txt` files or `.eml` files (plain text and HTML).
2. Detect phishing keywords, urgent or threatening language, sensitive-information requests and risky attachments.
3. Extract URLs (regex + HTML parsing) and analyse them statically, with 11+ checks.
4. Analyse the sender: format, lookalike domains, brand impersonation, display-name and Reply-To mismatch, SPF/DKIM/DMARC results.
5. Compute a weighted, capped, explainable score (0–100) and a three-level classification.
6. Provide a dashboard, local SQLite scan history, and PDF/CSV reports.
7. Handle invalid, empty, malformed and malicious input safely.

## 4. Technologies used
| Technology | Purpose |
|---|---|
| Python 3.11+ | application language |
| Streamlit | web dashboard (6 pages) |
| Plotly | gauge, donut and bar charts |
| pandas | tables, history, CSV |
| `re` (regular expressions) | keyword, URL and pattern detection |
| BeautifulSoup4 | HTML email → text and link extraction (scripts removed) |
| `email` (standard library) | `.eml` parsing, attachments listed only |
| `urllib.parse`, `ipaddress` | static URL analysis (no network access) |
| SQLite (`sqlite3`) | local scan history |
| ReportLab | PDF reports |
| pytest (+ pypdf) | automated tests |

## 5. System architecture
```
           ┌──────────────────────────────────────────────┐
 input ──► │ email_parser   manual / .txt / .eml           │  sender, subject, text, HTML→text,
           │                validation · size limits       │  links (+ visible text), attachments (listed)
           └───────────────┬──────────────────────────────┘
                           │ ParsedEmail
       ┌───────────────────┼───────────────────────┐
       ▼                   ▼                       ▼
 keyword_detector     url_analyzer            sender_analyzer
 phrases · urgency    extraction + 11 checks  format · lookalike · brand
 sensitive · attach.  (string analysis only)  Reply-To · SPF/DKIM/DMARC
       └───────────────────┼───────────────────────┘
                           ▼
                      risk_scorer   weighted indicators, once each, category caps, ≤ 100
                           ▼
                    phishing_engine  AnalysisResult + recommendations
            ┌──────────────┼───────────────┐
            ▼              ▼               ▼
     Streamlit dashboard  SQLite history  PDF / CSV / JSON
```

## 6. Project folder structure
```
phishing-email-detector/
├── app.py                         Streamlit entry point (6 pages + privacy settings)
├── config.py                      weights, thresholds, keyword dictionary, trusted brands, limits
├── requirements.txt  pytest.ini   setup.sh / run.sh (Linux, macOS)   setup.bat / run.bat (Windows)
├── detector/
│   ├── email_parser.py            manual / .txt / .eml parsing, HTML → text, upload validation
│   ├── keyword_detector.py        phrases, urgency, sensitive requests, attachments (with negation handling)
│   ├── url_analyzer.py            URL extraction and static checks, lookalike-domain logic
│   ├── sender_analyzer.py         sender format, spoofing and impersonation checks
│   ├── risk_scorer.py             Indicator, weighting, caps, classification
│   └── phishing_engine.py         runs everything → AnalysisResult + recommendations
├── database/db_manager.py         SQLite history: save, list, filter, delete, clear, stats, CSV
├── reports/pdf_generator.py       ReportLab PDF report
├── dashboard/                     home, analyze_page, url_page, history_page, reports_page, about_page,
│                                  result_view, common, samples, theme
├── assets/style.css               dashboard theme
├── samples/                       legitimate / phishing / suspicious _emails.json (10 emails)
│   ├── eml/                       3 .eml files + 1 .txt file for upload testing
│   └── make_eml_samples.py        regenerates the files in eml/
├── sample_output/                 real PDF reports and CSV produced from the samples
├── tests/                         144 pytest tests (+ Streamlit stand-in for headless page tests)
├── documentation/DEMO_GUIDE.md    demonstration script, expected outputs, viva questions
├── COLLEGE_PROJECT_REPORT.md      academic project report
├── screenshots/                   report page images; add your dashboard screenshots here
└── output/                        scan_history.db and saved PDFs (created at runtime)
```

## 7. Installation instructions
**Linux / macOS (Ubuntu, Kali, …)**
```bash
sudo apt install -y python3 python3-venv python3-pip      # Debian/Ubuntu/Kali only, if missing
cd phishing-email-detector
chmod +x setup.sh run.sh
./setup.sh
```
**Windows** (Python 3.11+ from python.org, with "Add to PATH" ticked)
```bat
cd phishing-email-detector
setup.bat
```
**Manual (any OS)**
```bash
python3 -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 8. How to run the application
```bash
./run.sh                            # Windows: run.bat
# or, with the venv activated:
streamlit run app.py
```
Open **http://localhost:8501**. The server listens on 127.0.0.1 only.

**Quick demo:** Analyze Email → *Load a sample email* → choose **P1 · phishing · Fake bank verification** →
Load sample → **🔍 Analyze email**.

Run the tests: `./venv/bin/python -m pytest -v` (Windows: `venv\Scripts\python -m pytest -v`).

## 9. How phishing detection works
**Parsing.** Manual fields are used directly. A `.txt` file may start with `From:`, `Subject:` and `Reply-To:`
lines. A `.eml` file is parsed with Python's `email` package: headers (From, Reply-To, Return-Path,
Authentication-Results …), text and HTML parts (both are analysed), and attachments, which are listed by name,
type and size but never opened. HTML is converted to text with BeautifulSoup after `<script>`, `<style>` and
`<iframe>` are removed. Uploads must be `.txt`/`.eml` and at most 5 MB.

**Keywords and language** (`config.KEYWORDS`, 18 phrase patterns in 9 categories). Examples: "verify your
account", "your account has been suspended", "password expired", "unusual login", "click here immediately",
"update payment details", "claim your prize", "package could not be delivered", "gift card". Each phrase has a
level (low/medium/high) and an explanation. To avoid flagging harmless text:
- matching is case-insensitive on word boundaries ("reclaim" does not match "claim");
- a phrase preceded by a negation in the same sentence is ignored ("we will **never** ask for your password");
- a short phrase inside a longer matched one is not counted twice ("click here" inside "click here immediately");
- each phrase counts once, however often it is repeated.

Separate detectors find **urgent / threatening language** (deadlines, "final notice", legal threats), **requests
for sensitive information** (passwords, PINs, card numbers, CVV, one-time codes, ID numbers, bank details) and
**attachment risks** (dangerous file types, double extensions like `Label.pdf.exe`, "enable macros").

**URL analysis.** URLs are extracted from text (regular expression) and from HTML `<a href>` tags together
with their visible text. Each URL is checked **as a string only** (it is never requested):

| Check | Risk |
|---|---|
| IP address instead of a domain (incl. decimal/hex forms) | High |
| `@` in the address (the real host comes after it) | High |
| Punycode / non-ASCII domain (homograph) | High |
| Misleading domain: brand lookalike (`paypa1.com`), brand + words (`examplebank-secure.com`), brand used as subdomain (`examplebank.com.verify.xyz`) | High |
| Link text shows a different domain than the real destination | High |
| `javascript:` link | High |
| URL shortener (bit.ly, tinyurl …) | Medium |
| More than 3 subdomain levels | Medium |
| Brand name in the path of an unrelated site | Medium |
| HTTP instead of HTTPS | Low |
| Unusually long URL (> 100 characters) | Low |
| Percent-encoded characters | Low / Medium |
| Suspicious characters (`//` redirect, many hyphens, redirect parameters) | Low |
| Suspicious words (login, verify, secure, account …) on non-brand domains | Low |
| Uncommon top-level domain (.xyz, .top, .click …) | Low |

HTTPS is not treated as a sign of safety. Phishing sites routinely use valid certificates.

**Sender analysis.** Invalid address format, lookalike domain of a trusted brand, a brand named in the display
name or address but sent from a free provider (`examplebank.help@gmail.com`) or an unrelated domain, a different
address inside the display name, many digits or unusual characters, Reply-To to another domain, and failed
SPF/DKIM/DMARC (when an `.eml` includes `Authentication-Results`). Trusted brands and their legitimate domains
are configurable in `config.TRUSTED_BRANDS`. An unfamiliar domain is **not** reported as malicious, and neither is a
free-mail address on its own.

## 10. Risk scoring methodology
Every triggered rule becomes an *indicator* with points from `config.WEIGHTS`:

| Indicator | Points |
|---|---|
| Suspicious keyword: low / medium / high | 5 / 10 / 15 |
| Urgent or threatening language | 10 |
| Sensitive information request | 15 |
| Suspicious attachment | 10 |
| IP-based URL | 20 |
| Misleading domain / brand in URL | 25 |
| Link text mismatch | 20 |
| `@` in URL, punycode URL | 15 each |
| URL shortener, excessive subdomains | 10 each |
| HTTP, long URL, encoded chars, odd chars, URL keywords, uncommon TLD | 5 each |
| Lookalike sender domain, brand on free email | 20 each |
| Display-name mismatch, punycode sender, authentication failed, invalid address | 15 each |
| Reply-To mismatch | 10 |
| Unusual sender address | 5 |

Rules that keep the score fair:
1. **Once per indicator.** Ten repetitions of a phrase, or the same URL problem in five links, count once.
2. **Category caps.** Keywords ≤ 35, Language ≤ 25, URLs ≤ 45, Sender ≤ 40, Attachments ≤ 15, so one kind of
   evidence cannot decide alone.
3. **Total capped at 100.**
4. **Classification:** 0–29 LOW (safe / low risk) · 30–59 MEDIUM (suspicious) · 60–100 HIGH (likely phishing).

The dashboard and PDF show every indicator with its points, explanation and evidence, plus the points per
category before and after the cap. The weights were chosen by reasoning about how strongly each sign indicates
phishing. They were **not** fitted to a labelled dataset, so the score is not a probability.

## 11. Screenshots
`screenshots/` contains the first pages of two real PDF reports generated from the samples. Take dashboard
screenshots on your computer (see `screenshots/README.md`):

| | |
|---|---|
| Home Dashboard | `screenshots/01_home.png` |
| Analyze Email – HIGH result | `screenshots/02_analyze_high.png` |
| Analyze Email – LOW result | `screenshots/03_analyze_low.png` |
| URL Analysis | `screenshots/04_url_analysis.png` |
| Scan History | `screenshots/05_history.png` |
| Reports | `screenshots/06_reports.png` |

## 12. Test results
Command: `python -m pytest -v`. Result in the development environment (Ubuntu 24.04, Python 3.13):
**144 passed, 0 failed** (about 1 s). The syntax was also checked on Python 3.11 and 3.12.

| Test file | Tests | Covers |
|---|---|---|
| test_email_parser.py | 20 | manual/.txt/.eml parsing, HTML parts, scripts removed, attachments listed, invalid type, empty, oversized, binary, malformed .eml, bad charset, truncation |
| test_keyword_detector.py | 18 | 10 phrases case-insensitive, counted once, negation, overlap, harmless text, word boundaries, urgency, sensitive requests, attachments |
| test_url_analyzer.py | 35 | extraction (text, HTML, de-duplication, link text), IP (v4, v6, decimal, hex), shorteners, HTTP, @, punycode, subdomains, long/encoded, 6 misleading + 7 legitimate domains, text mismatch, HTTPS-is-not-safe, javascript:, **no network access** |
| test_sender_analyzer.py | 20 | 6 invalid formats, valid senders, official domain, lookalike, brand on free mail, free mail alone not flagged, display mismatch, digits, Reply-To, SPF/DKIM/DMARC, unfamiliar ≠ malicious |
| test_risk_scorer.py | 26 | thresholds, sum, de-duplication, caps, ≤ 100, explanations, recommendations, **all 10 samples classified as intended**, legitimate samples score 0 |
| test_reports_database.py | 10 | save/list, body not stored by default, optional body storage, stats/filter/delete/clear, SQL-injection-safe search, CSV, PDF contents, PDF escaping |
| test_dashboard.py | 15 | all 6 pages, sample → analyze → history, .eml upload, malformed upload shows a friendly error, empty input, settings, delete, PDF save, single-URL checker, HTML escaping of email content |

**Manual end-to-end test with the sample emails** (same results in the dashboard flow):

| ID | Sample | Intended | Result | Score |
|---|---|---|---|---|
| L1 | University exam timetable | LOW | LOW | 0 |
| L2 | Order confirmation | LOW | LOW | 0 |
| L3 | Colleague's meeting reminder | LOW | LOW | 0 |
| P1 | Fake bank verification | HIGH | HIGH | 100 |
| P2 | Password reset scam | HIGH | HIGH | 95 |
| P3 | Package delivery scam | HIGH | HIGH | 90 |
| S1 | Fake job offer | MEDIUM | MEDIUM | 40 |
| S2 | Gift card survey | MEDIUM | MEDIUM | 35 |
| U1 | HTML link text ≠ destination | HIGH | HIGH | 65 |
| U2 | Obfuscated document link (@, IP, shortener) | MEDIUM | MEDIUM | 45 |
| file | legit_order_shipped.eml | – | LOW | 0 |
| file | bank_phishing_html.eml (SPF/DMARC fail, Reply-To, IP link) | – | HIGH | 100 |
| file | delivery_scam_attachment.eml (`Delivery_Label.pdf.exe`) | – | HIGH | 60 |
| file | job_offer.txt | – | MEDIUM | 40 |

These samples were written for this project, so matching them shows the rules work as designed. It is **not** a
measurement of real-world accuracy (see Limitations).

## 13. Limitations
- Rule-based: new wording, other languages, image-only emails and well-crafted spear-phishing can score low;
  unusual legitimate emails (e.g. a real security alert) can score medium.
- No reputation, blocklist or WHOIS lookups, because nothing is sent to external services. A brand-new malicious
  domain with no lookalike pattern is not recognised as bad.
- Lookalike detection only covers brands in `config.TRUSTED_BRANDS`; the registered-domain logic is an
  approximation (a short list of two-level suffixes, not the full Public Suffix List).
- SPF/DKIM/DMARC are only *read* from existing `Authentication-Results` headers, not verified.
- Attachments are judged by name and type only; their content is never scanned.
- Weights were not statistically calibrated, and accuracy was not measured on a large labelled corpus.
- The `From` header can be forged, so an "official domain" is not proof of authenticity.

## 14. Future enhancements
- Evaluate on a public labelled phishing/ham corpus; report precision and recall
- Optional machine-learning model (e.g. TF-IDF + logistic regression) alongside the rules, with explanations
- Optional, opt-in reputation lookups (Safe Browsing / PhishTank) with clear consent
- Full Public Suffix List and a larger, user-editable brand list in the UI
- DKIM signature verification; QR-code and image text extraction (OCR)
- Browser or mail-client plug-in; multilingual keyword dictionaries

## 15. Conclusion
The project delivers a working, explainable phishing detector that combines language, URL, sender and
attachment analysis into a transparent score. It handles manual input, text files and real `.eml` files
safely: no links or attachments are ever opened, HTML is never rendered, and nothing leaves the computer. A suite
of 144 automated tests and an end-to-end run over the sample dataset confirm that the rules behave as designed.
Because it explains *why* an email is suspicious, it is useful both as a checking tool and for security awareness.
