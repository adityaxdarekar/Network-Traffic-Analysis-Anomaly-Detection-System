"""
Phishing Email Detection and Analysis System - Streamlit entry point.

    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config as C  # noqa: E402
from dashboard import about_page, analyze_page, history_page, home, reports_page, url_page  # noqa: E402
from dashboard.common import get_settings  # noqa: E402
from dashboard.theme import css  # noqa: E402

PAGES = {
    "Home Dashboard": ("🏠", home.render),
    "Analyze Email": ("🔍", analyze_page.render),
    "URL Analysis": ("🔗", url_page.render),
    "Scan History": ("🕘", history_page.render),
    "Reports": ("📄", reports_page.render),
    "About Project": ("ℹ️", about_page.render),
}


def sidebar_settings() -> None:
    s = get_settings()
    with st.expander("⚙️ Privacy settings"):
        save = st.checkbox("Save scans to history", value=bool(s.get("save_scans", True)), key="set_save")
        body = st.checkbox("Also store the email body", value=bool(s.get("store_email_body", False)),
                           key="set_body", help="Off by default: only sender, subject, score and findings are stored.")
        if save != s.get("save_scans") or body != s.get("store_email_body"):
            s.update(save_scans=save, store_email_body=body)
            try:
                C.save_settings(s)
            except OSError:
                st.caption("Settings apply to this session only (could not write user_settings.json).")


def main() -> None:
    st.set_page_config(page_title="Phishing Email Detector", page_icon="🛡️", layout="wide",
                       initial_sidebar_state="expanded")
    st.markdown(css(), unsafe_allow_html=True)
    if "nav_target" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("nav_target")
    if "nav" not in st.session_state:
        st.session_state["nav"] = "Home Dashboard"
    with st.sidebar:
        st.markdown("## 🛡️ Phishing Detector")
        st.caption(f"{C.APP_TITLE} · v{C.APP_VERSION}")
        page = st.radio("Navigation", list(PAGES), key="nav", format_func=lambda p: f"{PAGES[p][0]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        sidebar_settings()
        st.caption("🔒 Local analysis only · links are never opened")
    try:
        PAGES[page][1]()
    except Exception as exc:  # noqa: BLE001
        if any(c.__name__ in ("StopException", "RerunException", "ScriptControlException") for c in type(exc).__mro__):
            raise
        # ordinary users see a friendly message, not a stack trace
        st.error("Something went wrong on this page. Please check your input and try again.")
        if "--debug" in sys.argv:
            st.exception(exc)


if __name__ == "__main__":   # "streamlit run app.py" executes the script as __main__
    main()
