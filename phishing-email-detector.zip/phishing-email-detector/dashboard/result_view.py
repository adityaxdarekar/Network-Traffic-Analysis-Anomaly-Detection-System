"""Renders one analysis result (used by Analyze Email and Scan History)."""

from __future__ import annotations

import pandas as pd
import streamlit as st

import config as C
from dashboard.common import badge, download, e, gauge, show_table
from reports.pdf_generator import generate_pdf_bytes, safe_filename

URL_RISK_ORDER = {"High": 0, "Medium": 1, "Low": 2, "None": 3}


def risk_banner(level: str, label: str, score: int) -> None:
    st.markdown(f"<div class='risk-banner risk-{e(level)}'><div><div class='muted'>Email risk</div>"
                f"<div class='lvl'>{e(label)}</div></div><div class='score'>{int(score)}/100</div></div>",
                unsafe_allow_html=True)


def findings_list(indicators: list[dict]) -> None:
    if not indicators:
        st.success("No phishing indicators were triggered.")
        return
    for n, i in enumerate(indicators, 1):
        st.markdown(f"<div class='finding'><span class='pts'>+{int(i['points'])}</span><b>{n}. {e(i['title'])}</b>"
                    f" <span class='muted'>({e(i['category'])})</span><br>{e(i['explanation'])}"
                    + (f"<div class='ev'>Evidence: {e(i['evidence'])}</div>" if i.get("evidence") else "")
                    + "</div>", unsafe_allow_html=True)


def url_table(rows: list[dict]) -> None:
    if not rows:
        st.caption("No URLs were found in this email.")
        return
    df = pd.DataFrame(rows)
    df = df.sort_values("Risk", key=lambda s: s.map(URL_RISK_ORDER))
    show_table(df)
    st.caption("URLs are analysed as text only - none was opened, resolved or downloaded. "
               "HTTPS alone does not prove a site is safe.")


def render(d: dict, body: str | None = None, key: str = "res") -> None:
    """d = AnalysisResult.to_dict() or a stored scan's details."""
    risk_banner(d["level"], d["classification"], d["score"])
    st.markdown(f"<div class='disclaimer'>{e(d.get('disclaimer', ''))}</div>", unsafe_allow_html=True)

    c1, c2 = st.columns([1, 1.4])
    with c1:
        gauge(d["score"], d["level"])
    with c2:
        st.markdown("**Email**")
        st.markdown(f"<div class='panel'><b>From:</b> {e(d.get('sender') or '(not provided)')}<br>"
                    f"<b>Subject:</b> {e(d.get('subject') or '(no subject)')}<br>"
                    f"<b>Scan ID:</b> {e(d.get('scan_id'))} · {e(d.get('analyzed_at'))} · input: {e(d.get('source'))}"
                    f"<br><b>Summary:</b> {e(d.get('summary'))}</div>", unsafe_allow_html=True)
        cats = d.get("by_category", {})
        if cats:
            show_table(pd.DataFrame([{"Category": c, "Points": v["raw"], "Counted (after cap)": v["capped"],
                                      "Cap": C.CATEGORY_CAPS.get(c, 100)} for c, v in cats.items()]))

    t1, t2, t3, t4, t5 = st.tabs(["Findings", "Sender analysis", "Keywords & language", "URLs", "Recommendations"])
    with t1:
        findings_list(d.get("indicators", []))
    with t2:
        sa = d.get("sender_analysis", {})
        show_table(pd.DataFrame(sa.get("rows", [])), empty_msg="No sender information.")
        for f in sa.get("findings", []):
            st.markdown(f"{badge('HIGH', 'Finding')} **{e(f['check'])}** - {e(f['reason'])}", unsafe_allow_html=True)
        for n in sa.get("notes", []):
            st.caption(n)
    with t3:
        kws = d.get("keywords", [])
        show_table(pd.DataFrame([{"Phrase": k["phrase"], "Found": ", ".join(k["matches"]), "Category": k["category"],
                                  "Level": k["level"].title(), "Why it is suspicious": k["why"]} for k in kws]),
                   empty_msg="No phishing keywords found.")
        if d.get("urgency"):
            st.markdown("**Urgent / threatening language:** " + e(", ".join(d["urgency"])))
        if d.get("sensitive_requests"):
            st.markdown("**Sensitive information requested:** "
                        + e(", ".join(s["item"] for s in d["sensitive_requests"])))
        if d.get("attachments"):
            st.markdown("**Attachment risks:**")
            show_table(pd.DataFrame(d["attachments"]))
        if d.get("attachments_listed"):
            st.caption("Attachments in the file (listed only - never opened): "
                       + ", ".join(f"{a['filename']} ({a['content_type']}, {a['size']} bytes)"
                                   for a in d["attachments_listed"]))
    with t4:
        url_table(d.get("urls", []))
    with t5:
        for r in d.get("recommendations", []):
            st.markdown(f"- {e(r)}")

    if body is not None:
        with st.expander("Email text that was analysed (shown as plain text - HTML is never rendered)"):
            st.text(body[:20000])

    c1, c2 = st.columns(2)
    with c1:
        download("⬇ PDF report", generate_pdf_bytes(d), safe_filename(d.get("scan_id", "")), "application/pdf",
                 f"{key}_pdf", primary=True)
    with c2:
        import json
        download("⬇ JSON", json.dumps(d, indent=2).encode(), f"{d.get('scan_id', 'scan')}.json", "application/json",
                 f"{key}_json")
