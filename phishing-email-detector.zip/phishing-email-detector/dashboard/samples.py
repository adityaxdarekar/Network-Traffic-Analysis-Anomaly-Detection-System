"""Loads the fictional sample emails from samples/*.json."""

from __future__ import annotations

import json

import config as C

FILES = ["legitimate_emails.json", "phishing_emails.json", "suspicious_emails.json"]


def load_samples() -> list[dict]:
    out = []
    for name in FILES:
        try:
            data = json.loads((C.SAMPLES_DIR / name).read_text(encoding="utf-8"))
            out += data.get("emails", [])
        except (OSError, ValueError):
            continue
    return out


def label(s: dict) -> str:
    return f"{s['id']} · {s['category'].replace('_', ' ')} · {s['title']}"
