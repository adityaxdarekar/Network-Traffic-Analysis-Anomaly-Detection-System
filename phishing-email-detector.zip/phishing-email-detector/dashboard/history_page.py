"""Scan History page: list, filter, view, delete, clear, CSV export."""

from __future__ import annotations

import streamlit as st

from dashboard import result_view
from dashboard.common import db_or_warn, download, page_header, show_table


def render() -> None:
    page_header("Scan History", "Stored locally in SQLite - email bodies are not stored unless you enable it")
    db = db_or_warn()
    if db is None:
        return
    c1, c2 = st.columns([1, 2])
    level = c1.selectbox("Risk level", ["All", "LOW", "MEDIUM", "HIGH"], key="hist_level")
    search = c2.text_input("Search sender or subject", key="hist_search")
    scans = db.list_scans(None if level == "All" else level, search.strip())
    st.markdown(f"**{len(scans)}** scan(s)")
    show_table(scans.drop(columns=["summary"]), height=320, empty_msg="No scans match.")
    if scans.empty:
        return
    download("⬇ Export history as CSV", db.export_csv().encode(), "phishing_scan_history.csv", "text/csv", "hist_csv")

    st.subheader("Scan details")
    labels = {r.scan_id: f"{r.scanned_at} · {r.risk_level} {r.risk_score} · {r.subject or '(no subject)'}"
              for r in scans.itertuples()}
    pick = st.selectbox("Choose a scan", list(labels), format_func=labels.get, key="hist_pick")
    rec = db.get_scan(pick)
    if rec:
        result_view.render(rec["details"], body=rec.get("body"), key="hist")
        if rec.get("body") is None:
            st.caption("The email body was not stored (privacy default).")
        if st.button("🗑 Delete this scan", key="hist_delete"):
            db.delete_scan(pick)
            st.success("Scan deleted.")
            st.rerun()

    with st.expander("Delete all history"):
        sure = st.checkbox("Yes, permanently delete every stored scan", key="hist_sure")
        if st.button("Delete all scans", key="hist_clear", disabled=not sure):
            n = db.clear()
            st.success(f"{n} scan(s) deleted.")
            st.rerun()
