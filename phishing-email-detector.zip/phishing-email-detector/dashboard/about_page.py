"""About Project page: how detection works, scoring weights, privacy."""

from __future__ import annotations

import pandas as pd
import streamlit as st

import config as C
from dashboard.common import page_header

ARCH = """
 Email input (paste / .txt / .eml)
        │
        ▼
 email_parser ── sender, subject, text body, HTML → text, links, attachments (listed only)
        │
        ├─► keyword_detector  phishing phrases · urgency · sensitive requests · attachments
        ├─► url_analyzer      extraction + 11 static URL checks (no URL is ever opened)
        └─► sender_analyzer   format · lookalike · brand impersonation · Reply-To · SPF/DKIM
        │
        ▼
 risk_scorer ── weighted indicators, once each, category caps, total ≤ 100 → LOW / MEDIUM / HIGH
        │
        ▼
 phishing_engine ── result + recommendations ──► Streamlit dashboard · SQLite history · PDF / CSV
"""


def render() -> None:
    page_header("About Project", f"{C.APP_TITLE} · v{C.APP_VERSION}")
    st.markdown("A rule-based tool that inspects an email's **sender**, **subject**, **body**, **links** and "
                "**attachments** for common phishing indicators, explains every finding and gives a 0-100 risk "
                "score.")
    st.warning("The score is a heuristic built from expert rules, **not** a statistically validated probability. "
               "Findings are indicators, not proof. A LOW score does not guarantee an email is safe.")
    st.code(ARCH, language=None)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Classification**")
        st.dataframe(pd.DataFrame([{"Score": "0-29", "Class": C.RISK_LABELS["LOW"]},
                                   {"Score": "30-59", "Class": C.RISK_LABELS["MEDIUM"]},
                                   {"Score": "60-100", "Class": C.RISK_LABELS["HIGH"]}]),
                     hide_index=True, width="stretch")
        st.markdown("**Category caps**")
        st.dataframe(pd.DataFrame(list(C.CATEGORY_CAPS.items()), columns=["Category", "Max points"]),
                     hide_index=True, width="stretch")
    with c2:
        st.markdown("**Indicator weights** (config.py → WEIGHTS)")
        st.dataframe(pd.DataFrame(sorted(C.WEIGHTS.items(), key=lambda x: -x[1]), columns=["Indicator", "Points"]),
                     hide_index=True, width="stretch", height=330)
    st.markdown("""
**Security and privacy**
- Everything runs on this computer; email content is never sent to any service
- Links are never opened, resolved or downloaded; attachments are listed, never opened
- HTML is converted to text - scripts and remote content are never executed or loaded
- Email bodies are not stored in history unless you enable it in the sidebar
- Uploads are limited to .txt / .eml files up to 5 MB

**Technology:** Python · Streamlit · Plotly · pandas · regular expressions · BeautifulSoup4 · email library ·
SQLite · ReportLab · pytest
""")
