"""Shared dashboard helpers. All email-derived text is HTML-escaped before it is shown with unsafe_allow_html."""

from __future__ import annotations

import html
import json

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config as C
from dashboard.theme import plotly_layout
from database.db_manager import DatabaseError, DatabaseManager

LEVEL_ORDER = ["LOW", "MEDIUM", "HIGH"]


def e(text) -> str:
    """Escape untrusted text for HTML output."""
    return html.escape("" if text is None else str(text))


def get_settings() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = C.load_settings()
    return st.session_state["settings"]


@st.cache_resource
def get_db() -> DatabaseManager | None:
    try:
        return DatabaseManager()
    except DatabaseError:
        return None


def db_or_warn() -> DatabaseManager | None:
    db = get_db()
    if db is None:
        st.error("The scan history database could not be opened. Check that the 'output' folder is writable.")
    return db


def go_to(page: str) -> None:
    st.session_state["nav_target"] = page
    st.rerun()


def page_header(title: str, subtitle: str = "") -> None:
    st.markdown(f"<div class='soc-header'><div><div class='title'>{e(title)}</div>"
                f"<div class='subtitle'>{e(subtitle)}</div></div>"
                f"<span class='soc-pill'>local analysis · no links opened</span></div>", unsafe_allow_html=True)


def kpi_row(items: list[tuple]) -> None:
    cols = st.columns(len(items))
    for col, item in zip(cols, items):
        label, value = item[0], item[1]
        sub = item[2] if len(item) > 2 else ""
        style = item[3] if len(item) > 3 else "accent"
        col.markdown(f"<div class='kpi {style}'><div class='label'>{e(label)}</div><div class='value'>{e(value)}</div>"
                     f"<div class='sub'>{e(sub)}</div></div>", unsafe_allow_html=True)


def badge(level: str, text: str | None = None) -> str:
    return f"<span class='sev sev-{e(level)}'>{e(text or level)}</span>"


def show_table(df: pd.DataFrame, height: int | None = None, empty_msg: str = "Nothing to show.") -> None:
    if df is None or df.empty:
        st.caption(empty_msg)
        return
    kw = {"hide_index": True, "width": "stretch"}
    if height:
        kw["height"] = height
    st.dataframe(df, **kw)


def risk_donut(counts: dict, title: str = "Risk distribution"):
    labels = [C.RISK_LABELS[k] for k in LEVEL_ORDER]
    values = [counts.get(k, 0) for k in LEVEL_ORDER]
    if not sum(values):
        st.markdown(f"<div class='panel'><b>{e(title)}</b><br><span class='muted'>No scans yet.</span></div>",
                    unsafe_allow_html=True)
        return
    fig = px.pie(names=labels, values=values, hole=0.55, color=labels,
                 color_discrete_map={C.RISK_LABELS[k]: C.RISK_COLORS[k] for k in LEVEL_ORDER})
    st.plotly_chart(plotly_layout(fig, title), width="stretch")


def bar(df: pd.DataFrame, x: str, y: str, title: str, color: str = "#3b82f6", horizontal: bool = False):
    if df is None or df.empty:
        return
    fig = px.bar(df, x=y if horizontal else x, y=x if horizontal else y, orientation="h" if horizontal else "v")
    fig.update_traces(marker_color=color)
    st.plotly_chart(plotly_layout(fig, title), width="stretch")


def gauge(score: int, level: str):
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score, number={"suffix": "/100"},
        gauge={"axis": {"range": [0, 100]}, "bar": {"color": C.RISK_COLORS[level]},
               "steps": [{"range": [0, 30], "color": "rgba(34,197,94,.18)"},
                         {"range": [30, 60], "color": "rgba(245,158,11,.18)"},
                         {"range": [60, 100], "color": "rgba(239,68,68,.18)"}]}))
    st.plotly_chart(plotly_layout(fig, "Phishing risk score", height=250), width="stretch")


def download(label: str, data, filename: str, mime: str, key: str, primary: bool = False) -> None:
    st.download_button(label, data=data, file_name=filename, mime=mime, key=key,
                       type="primary" if primary else "secondary", width="stretch")


def result_json(result) -> bytes:
    return json.dumps(result.to_dict(), indent=2).encode()
