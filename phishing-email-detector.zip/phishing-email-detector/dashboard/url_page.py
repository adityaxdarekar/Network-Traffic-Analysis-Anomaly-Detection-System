"""URL Analysis page: URLs from the current email plus a single-URL checker (string analysis only)."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from dashboard.common import e, kpi_row, page_header
from dashboard.result_view import url_table
from detector.url_analyzer import analyze_url

CHECKS = [
    ("HTTP instead of HTTPS", "Unencrypted. HTTPS alone does not make a site safe - phishing sites use it too."),
    ("IP address instead of domain", "Real organisations link to their named domain, not to 192.0.2.45."),
    ("URL shortener", "bit.ly, tinyurl … hide where the link really goes."),
    ("Excessive subdomains", "login.secure.account.example.com.attacker.net looks official but belongs to attacker.net."),
    ("Misleading domain / lookalike", "paypa1.com, examplebank-secure.com, brand.com.evil.xyz imitate a trusted brand."),
    ("@ symbol in URL", "https://trusted.com@198.51.100.7 really goes to 198.51.100.7."),
    ("Punycode", "xn-- domains can contain look-alike international characters."),
    ("Unusually long URL", "Long URLs push the real domain out of view."),
    ("Encoded characters", "%2F, %40 … can hide words, redirects or the real host."),
    ("Suspicious characters / keywords", "'//' redirects, many hyphens, words like login, verify, secure."),
    ("Link text mismatch", "The visible text shows one address, the link goes to another (HTML emails)."),
]


def render() -> None:
    page_header("URL Analysis", "Links are analysed as text - they are never opened, resolved or downloaded")
    result = st.session_state.get("result")
    if result is None:
        st.info("No email analysed yet in this session. Analyse an email first, or check a single URL below.")
    else:
        urls = result.urls
        kpi_row([("URLs found", len(urls)),
                 ("High risk", sum(u.risk == "High" for u in urls), "", "alert" if any(u.risk == "High" for u in urls)
                  else "accent"),
                 ("Medium risk", sum(u.risk == "Medium" for u in urls)),
                 ("No issue found", sum(u.risk == "None" for u in urls))])
        st.markdown(f"**Email:** {e(result.email.subject or '(no subject)')}")
        url_table(result.url_rows)
        html_links = [u for u in urls if u.link_text]
        if html_links:
            st.markdown("**HTML links (visible text → real destination)**")
            st.dataframe(pd.DataFrame([{"Visible text": u.link_text, "Real destination": u.url, "Risk": u.risk}
                                       for u in html_links]), hide_index=True, width="stretch")

    st.subheader("Check a single URL")
    url = st.text_input("Paste a URL (it will NOT be visited)", key="single_url",
                        placeholder="http://examplebank.com.secure-login.xyz/verify")
    text = st.text_input("Visible link text (optional, for HTML links)", key="single_text")
    if url.strip():
        a = analyze_url(url.strip(), text.strip())
        st.markdown(f"Domain: `{e(a.host or '-')}` · registered domain: `{e(a.registered_domain or '-')}` · "
                    f"overall risk: **{e(a.risk)}**")
        url_table(a.rows())

    with st.expander("What does each URL check mean?"):
        st.dataframe(pd.DataFrame(CHECKS, columns=["Check", "Why it matters"]), hide_index=True, width="stretch")
