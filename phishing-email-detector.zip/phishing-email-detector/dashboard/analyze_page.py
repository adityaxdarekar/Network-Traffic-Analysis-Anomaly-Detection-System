"""Analyze Email page: manual input, .txt upload or .eml upload, plus sample loader."""

from __future__ import annotations

import logging

import streamlit as st

from dashboard import result_view
from dashboard import common
from dashboard.common import get_settings, page_header
from dashboard.samples import label, load_samples
from detector.email_parser import EmailParseError, parse_manual, parse_upload
from detector.phishing_engine import analyze

log = logging.getLogger(__name__)
METHODS = ["Paste email", "Upload .txt file", "Upload .eml file"]


def _load_sample(sample: dict) -> None:
    st.session_state["in_sender"] = sample["sender"]
    st.session_state["in_subject"] = sample["subject"]
    st.session_state["in_body"] = sample["body"]
    st.session_state["in_method"] = METHODS[0]


def run_analysis(make_parsed) -> None:
    """Parse + analyse + save. Users see friendly messages, never a stack trace."""
    try:
        parsed = make_parsed()
        result = analyze(parsed)
    except EmailParseError as exc:
        st.error(str(exc))
        return
    except Exception:  # noqa: BLE001
        log.exception("analysis failed")
        st.error("The email could not be analysed. Check that the input is a valid email and try again.")
        return
    st.session_state["result"] = result
    settings = get_settings()
    if settings.get("save_scans", True):
        db = common.get_db()
        if db is not None:
            try:
                db.save_scan(result, store_body=bool(settings.get("store_email_body")))
            except Exception:  # noqa: BLE001
                st.warning("The result could not be saved to scan history.")


def render() -> None:
    page_header("Analyze Email", "Paste an email or upload a .txt / .eml file - nothing is sent anywhere")
    samples = load_samples()
    with st.expander("🧪 Load a sample email (fictional, safe to use)", expanded=False):
        c1, c2 = st.columns([3, 1])
        idx = c1.selectbox("Sample", list(range(len(samples))), format_func=lambda i: label(samples[i]),
                           key="sample_pick", label_visibility="collapsed")
        if c2.button("Load sample", key="load_sample", width="stretch") and samples:
            _load_sample(samples[idx])
            st.rerun()

    method = st.radio("Input method", METHODS, horizontal=True, key="in_method")
    if method == METHODS[0]:
        sender = st.text_input("Sender address", key="in_sender",
                               placeholder="Example Bank <alerts@examplebank.com>")
        subject = st.text_input("Subject", key="in_subject")
        body = st.text_area("Email body (plain text or HTML)", key="in_body", height=260)
        if st.button("🔍 Analyze email", type="primary", key="analyze_manual"):
            run_analysis(lambda: parse_manual(sender, subject, body))
    else:
        ext = "txt" if method == METHODS[1] else "eml"
        up = st.file_uploader(f"Upload a .{ext} file (max 5 MB)", type=[ext], key=f"upload_{ext}",
                              help="Attachments inside .eml files are listed but never opened.")
        if ext == "txt":
            st.caption("Optional header lines at the top are recognised: `From:`, `Subject:`, `Reply-To:` "
                       "followed by a blank line and the body.")
        if st.button("🔍 Analyze file", type="primary", key="analyze_file", disabled=up is None):
            run_analysis(lambda: parse_upload(up.name, up.getvalue()))

    result = st.session_state.get("result")
    if result is not None:
        st.divider()
        result_view.render(result.to_dict(), body=result.email.body_text, key="current")
