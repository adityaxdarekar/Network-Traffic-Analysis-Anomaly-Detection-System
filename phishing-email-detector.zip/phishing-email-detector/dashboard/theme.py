"""Dark cybersecurity theme: CSS (assets/style.css) and a matching Plotly layout."""

from __future__ import annotations

import config as C

BG = "#0a1628"
PANEL = "#0f2038"
BORDER = "#1e3a5f"
TEXT = "#e2e8f0"
MUTED = "#8ba3c7"
CYAN = "#22d3ee"
CHART_COLORS = ["#3b82f6", "#22d3ee", "#818cf8", "#2dd4bf", "#38bdf8", "#a78bfa", "#facc15", "#94a3b8"]


def css() -> str:
    try:
        return "<style>" + C.STYLE_FILE.read_text(encoding="utf-8") + "</style>"
    except OSError:
        return ""


def plotly_layout(fig, title: str | None = None, height: int = 330):
    fig.update_layout(
        template="plotly_dark", paper_bgcolor=PANEL, plot_bgcolor=PANEL, height=height,
        font=dict(color=TEXT, size=12), colorway=CHART_COLORS,
        margin=dict(l=10, r=10, t=45 if title else 15, b=10),
        title=dict(text=title, font=dict(size=14, color=TEXT), x=0.01) if title else None,
        legend=dict(bgcolor="rgba(0,0,0,0)"),
    )
    fig.update_xaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    fig.update_yaxes(gridcolor=BORDER, zerolinecolor=BORDER)
    return fig
