"""Home Dashboard page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

import config as C
from dashboard.common import bar, db_or_warn, go_to, kpi_row, page_header, risk_donut, show_table


def render() -> None:
    page_header("Home Dashboard", C.APP_TITLE)
    db = db_or_warn()
    stats = db.stats() if db else {"total": 0, "LOW": 0, "MEDIUM": 0, "HIGH": 0, "average_score": 0}
    kpi_row([("Emails analyzed", stats["total"]),
             ("Low risk", stats["LOW"], "safe / low"),
             ("Suspicious", stats["MEDIUM"], "medium risk", "alert" if stats["MEDIUM"] else "accent"),
             ("High risk", stats["HIGH"], "likely phishing", "alert" if stats["HIGH"] else "accent"),
             ("Average score", stats["average_score"], "out of 100")])
    st.write("")
    scans = db.list_scans() if db else pd.DataFrame()
    c1, c2 = st.columns(2)
    with c1:
        risk_donut(stats)
    with c2:
        if scans.empty:
            st.markdown("<div class='panel'><b>Risk scores</b><br><span class='muted'>Analyse an email to see "
                        "statistics here.</span></div>", unsafe_allow_html=True)
        else:
            bins = pd.cut(scans["risk_score"], bins=[-1, 9, 19, 29, 39, 49, 59, 69, 79, 89, 100],
                          labels=["0-9", "10-19", "20-29", "30-39", "40-49", "50-59", "60-69", "70-79", "80-89",
                                  "90-100"])
            dist = bins.value_counts().sort_index()
            bar(pd.DataFrame({"score range": dist.index.astype(str), "emails": dist.values}), "score range", "emails",
                "Risk score distribution", color="#22d3ee")
    st.subheader("Recent scans")
    show_table(scans.head(10)[["scanned_at", "sender", "subject", "risk_score", "classification",
                               "indicator_count"]] if not scans.empty else scans,
               empty_msg="No scans yet - open Analyze Email and load a sample to start.")
    if st.button("🔍 Analyze an email", type="primary", key="home_analyze"):
        go_to("Analyze Email")
    st.markdown("<div class='disclaimer'>Rule-based detection: scores are heuristics and findings are indicators, "
                "not proof. All analysis runs locally; links are never opened.</div>", unsafe_allow_html=True)
