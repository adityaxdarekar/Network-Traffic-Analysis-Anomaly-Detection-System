"""Reports page: PDF report for the current or a stored scan, CSV export of history."""

from __future__ import annotations

import streamlit as st

from dashboard.common import db_or_warn, download, page_header, show_table
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report, safe_filename


def render() -> None:
    page_header("Reports", "PDF reports per email and CSV export of the scan history")
    db = db_or_warn()
    result = st.session_state.get("result")

    st.subheader("📄 PDF report")
    sources = []
    if result is not None:
        sources.append(("current", f"Current email · {result.level} {result.score} · {result.email.subject[:60]}"))
    scans = db.list_scans() if db else None
    if scans is not None and not scans.empty:
        sources += [(r.scan_id, f"{r.scanned_at} · {r.risk_level} {r.risk_score} · {(r.subject or '')[:60]}")
                    for r in scans.itertuples() if result is None or r.scan_id != result.scan_id]
    if not sources:
        st.info("Analyse an email first - its report will be available here.")
    else:
        names = dict(sources)
        pick = st.selectbox("Report for", list(names), format_func=names.get, key="rep_pick")
        details = result.to_dict() if pick == "current" else db.get_scan(pick)["details"]
        c1, c2 = st.columns(2)
        with c1:
            download("⬇ Download PDF report", generate_pdf_bytes(details), safe_filename(details["scan_id"]),
                     "application/pdf", "rep_pdf", primary=True)
        with c2:
            if st.button("💾 Save PDF to output/reports", key="rep_save", width="stretch"):
                path = generate_pdf_report(details)
                st.success(f"Saved to {path}")
        st.caption("Each report contains: scan ID, date, sender, subject, score and classification, score breakdown, "
                   "sender analysis, suspicious keywords, extracted URLs and URL analysis, detailed findings and "
                   "recommendations.")

    st.subheader("📊 CSV export")
    if db:
        if scans is not None and not scans.empty:
            show_table(scans.head(5).drop(columns=["summary"]))
            download("⬇ Download scan history (CSV)", db.export_csv().encode(), "phishing_scan_history.csv",
                     "text/csv", "rep_csv")
        else:
            st.caption("No scans stored yet.")
