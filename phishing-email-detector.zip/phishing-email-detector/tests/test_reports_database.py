"""SQLite history (privacy default), CSV export and PDF report."""

from __future__ import annotations

import csv
import io

import pytest

from conftest import run, sample
from reports.pdf_generator import generate_pdf_bytes, generate_pdf_report, safe_filename


def test_save_and_list(db, phishing_result):
    db.save_scan(phishing_result)
    df = db.list_scans()
    assert len(df) == 1
    row = df.iloc[0]
    assert row["scan_id"] == phishing_result.scan_id and row["risk_score"] == phishing_result.score
    assert row["risk_level"] == "HIGH" and row["indicator_count"] == len(phishing_result.indicators)


def test_body_not_stored_by_default(db, phishing_result):
    db.save_scan(phishing_result)
    rec = db.get_scan(phishing_result.scan_id)
    assert rec["body"] is None
    assert "body" not in rec["details"]


def test_body_stored_when_enabled(db, phishing_result):
    db.save_scan(phishing_result, store_body=True)
    assert "verify your account" in db.get_scan(phishing_result.scan_id)["body"]


def test_stats_filter_delete_clear(db):
    for sid in ("L1", "S1", "P1", "P2"):
        s = sample(sid)
        db.save_scan(run(s["sender"], s["subject"], s["body"]))
    assert db.stats() | {} == {"total": 4, "LOW": 1, "MEDIUM": 1, "HIGH": 2, "average_score": db.stats()["average_score"]}
    assert len(db.list_scans("HIGH")) == 2 and len(db.list_scans(search="Job offer")) == 1
    first = db.list_scans().iloc[0]["scan_id"]
    assert db.delete_scan(first) and len(db.list_scans()) == 3
    assert db.clear() == 3 and db.stats()["total"] == 0


def test_sql_injection_in_search_is_harmless(db, phishing_result):
    db.save_scan(phishing_result)
    assert db.list_scans(search="' OR 1=1; DROP TABLE scans; --").empty
    assert len(db.list_scans()) == 1


def test_csv_export(db, phishing_result):
    db.save_scan(phishing_result)
    rows = list(csv.DictReader(io.StringIO(db.export_csv())))
    assert rows[0]["scan_id"] == phishing_result.scan_id and rows[0]["classification"] == phishing_result.label
    assert "body" not in rows[0]


def test_pdf_report_contents(tmp_path, phishing_result):
    pypdf = pytest.importorskip("pypdf")
    path = generate_pdf_report(phishing_result.to_dict(), tmp_path / "r.pdf")
    text = "\n".join(p.extract_text() for p in pypdf.PdfReader(str(path)).pages)
    for needed in ("Phishing Email Analysis Report", phishing_result.scan_id, "examplebank-secure.com",
                   "URGENT: Your account has been suspended", "HIGH RISK", "Sender analysis",
                   "Suspicious keywords", "Extracted URLs", "192.0.2.45", "Detailed findings", "Recommendations"):
        assert needed in text, needed


def test_pdf_for_clean_email_and_from_stored_scan(db):
    s = sample("L3")
    r = run(s["sender"], s["subject"], s["body"])
    db.save_scan(r)
    data = generate_pdf_bytes(db.get_scan(r.scan_id)["details"])
    assert data.startswith(b"%PDF") and len(data) > 2000


def test_pdf_escapes_markup():
    r = run("x@example.com", "<b>bold</b> & <script>", "<para>verify your account</para> </b>")
    assert generate_pdf_bytes(r.to_dict()).startswith(b"%PDF")


def test_safe_filename():
    assert safe_filename("../../etc/passwd") == "phishing_report_______etc_passwd.pdf"
