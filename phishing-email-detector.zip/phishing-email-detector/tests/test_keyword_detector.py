"""Keyword, urgency, sensitive-request and attachment detection."""

from __future__ import annotations

import pytest

from detector.keyword_detector import find_attachment_risks, find_keywords, find_sensitive_requests, find_urgency


def phrases(text):
    return {h.phrase for h in find_keywords(text)}


@pytest.mark.parametrize("text,phrase", [
    ("URGENT action: VERIFY YOUR ACCOUNT now", "verify your account"),
    ("Your account has been suspended.", "your account has been suspended"),
    ("We noticed an unusual login detected on your profile", "unusual login detected"),
    ("Your password has expired", "password expired"),
    ("Please update your payment details", "update payment details"),
    ("Congratulations, you won a phone!", "congratulations, you won"),
    ("Claim your prize today", "claim your prize"),
    ("Bank verification required for all customers", "bank verification required"),
    ("Your account will be closed tomorrow", "your account will be closed"),
    ("Please confirm your identity", "confirm your identity"),
])
def test_keywords_detected_case_insensitive(text, phrase):
    assert phrase in phrases(text)


def test_phrase_counted_once():
    hits = find_keywords("verify your account. verify your account! VERIFY YOUR ACCOUNT")
    hit = next(h for h in hits if h.phrase == "verify your account")
    assert hit.count == 3 and hit.matches == ["verify your account"]
    assert len([h for h in hits if h.phrase == "verify your account"]) == 1


def test_negated_phrase_not_flagged():
    text = "ExampleShop will never ask you to verify your account or for your password by email."
    assert "verify your account" not in phrases(text)
    assert find_sensitive_requests(text) == []


def test_overlapping_phrase_not_double_counted():
    assert phrases("Click here immediately") == {"click here immediately"}


def test_harmless_text_no_keywords():
    text = ("Hi team, the project meeting is on Thursday. Please review the attached agenda document and "
            "click the calendar invite if you can attend.")
    assert phrases(text) == set()


def test_word_boundaries():
    assert phrases("reclaim your prizes") == set()           # 'claim' inside 'reclaim'


def test_urgency():
    assert "within 24 hours" in find_urgency("Respond within 24 hours or face legal action")
    assert find_urgency("Have a nice weekend") == []


def test_sensitive_requests():
    found = {s["item"] for s in find_sensitive_requests("Please enter your password and your card number and CVV")}
    assert {"password / PIN", "payment card details"} <= found


def test_attachment_risks():
    att = find_attachment_risks("Please see attached", [{"filename": "invoice.pdf.exe"}])
    assert att[0]["detail"] == "invoice.pdf.exe" and "double extension" in att[0]["reason"]
    assert find_attachment_risks("Enable macros to view the document")
    assert find_attachment_risks("Here is the report.pdf you asked for", [{"filename": "report.pdf"}]) == []
