"""Sender validation and spoofing indicators."""

from __future__ import annotations

import pytest

from detector.sender_analyzer import analyze_sender


def checks(sender, **kw):
    return {f.check for f in analyze_sender(sender, **kw).findings}


@pytest.mark.parametrize("sender", ["not-an-email", "user@", "@example.com", "user@@example.com", "user@example",
                                    "John <john at example.com>"])
def test_invalid_formats(sender):
    s = analyze_sender(sender)
    assert not s.valid_format and "Invalid sender address" in {f.check for f in s.findings}


@pytest.mark.parametrize("sender", ["alice@example.com", "Bob Smith <bob.smith@example.org>",
                                    "registrar@exampleuniversity.edu"])
def test_valid_senders_no_findings(sender):
    s = analyze_sender(sender)
    assert s.valid_format and s.findings == []


def test_official_brand_domain():
    s = analyze_sender("Example Bank <alerts@examplebank.com>")
    assert s.official_domain and s.findings == []


def test_lookalike_domain():
    assert "Lookalike domain" in checks("Example Bank <alerts@examplebank-secure.com>")
    assert "Lookalike domain" in checks("Support <help@examp1ebank.com>")


def test_brand_on_free_email():
    assert "Brand name on a free email account" in checks("ExampleBank Support <examplebank.help@gmail.com>")


def test_free_email_alone_is_not_flagged():
    s = analyze_sender("Priya Shah <priya.shah@gmail.com>")
    assert s.findings == [] and s.is_freemail and s.notes


def test_display_name_brand_mismatch():
    assert "Display name does not match domain" in checks("PayPal Service <service@mail-notices.net>")


def test_display_name_contains_other_address():
    assert "Different address in display name" in checks('"alerts@examplebank.com" <x@mailer.example.net>')


def test_excessive_digits():
    assert "Unusual sender address" in checks("user8812934@example.net")


def test_reply_to_mismatch():
    assert "Reply-To goes elsewhere" in checks("a@example.com", reply_to="collect@other.example.org")
    assert "Reply-To goes elsewhere" not in checks("a@example.com", reply_to="b@example.com")


def test_authentication_failure():
    assert "Email authentication failed" in checks("a@example.com", auth_results="spf=fail; dkim=pass; dmarc=fail")
    assert "Email authentication failed" not in checks("a@example.com", auth_results="spf=pass dkim=pass dmarc=pass")


def test_unfamiliar_domain_is_not_malicious():
    s = analyze_sender("Info <info@some-small-business.example>")
    assert s.findings == [] and any("Unfamiliar does not mean malicious" in n for n in s.notes)


def test_missing_sender():
    s = analyze_sender("")
    assert s.findings == [] and s.notes
