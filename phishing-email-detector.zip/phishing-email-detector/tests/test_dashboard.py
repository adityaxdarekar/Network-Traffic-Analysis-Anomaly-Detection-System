"""Headless test of the six dashboard pages with the Streamlit stand-in (tests/streamlit_stub.py)."""

from __future__ import annotations

import pytest

from tests import streamlit_stub as S

S.install()
import streamlit as st  # noqa: E402

import app  # noqa: E402
import config as C  # noqa: E402
from dashboard import common  # noqa: E402
from conftest import ROOT  # noqa: E402


class Upload:
    def __init__(self, path):
        self.name, self._data = path.name, path.read_bytes()

    def getvalue(self):
        return self._data


@pytest.fixture
def env(tmp_path, monkeypatch, db):
    monkeypatch.setattr(common, "get_db", lambda: db)
    monkeypatch.setattr(C, "SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr(C, "REPORT_DIR", tmp_path / "reports")
    st.session_state.clear()
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(), {}
    return db


def page(name, press=(), **inputs):
    st.session_state["nav"] = name
    S.StubState.calls.clear()
    S.StubState.press, S.StubState.inputs = set(press), inputs
    try:
        app.main()
    except S.StopException:
        pass
    except S.RerunException:
        return "rerun"
    errors = [c for c in S.StubState.calls if c[0] in ("error", "exception")]
    return errors


def test_six_pages():
    assert list(app.PAGES) == ["Home Dashboard", "Analyze Email", "URL Analysis", "Scan History", "Reports",
                               "About Project"]


@pytest.mark.parametrize("name", list(app.PAGES))
def test_pages_render_empty(env, name):
    assert page(name) == []


def test_sample_load_and_analyze_workflow(env):
    assert page("Analyze Email", press={"Load sample"}, sample_pick=3) == "rerun"      # P1 fake bank
    assert st.session_state["in_subject"].startswith("URGENT")
    assert page("Analyze Email", press={"🔍 Analyze email"}) == []
    r = st.session_state["result"]
    assert r.level == "HIGH" and env.stats()["HIGH"] == 1
    assert env.get_scan(r.scan_id)["body"] is None            # privacy default
    for name in app.PAGES:
        assert page(name) == [], name


def test_eml_upload_workflow(env):
    up = Upload(ROOT / "samples" / "eml" / "bank_phishing_html.eml")
    assert page("Analyze Email", press={"🔍 Analyze file"}, in_method="Upload .eml file", upload_eml=up) == []
    assert st.session_state["result"].email.source == "eml"


def test_invalid_upload_shows_friendly_error(env, tmp_path):
    bad = tmp_path / "broken.eml"
    bad.write_text("not an email")
    errors = page("Analyze Email", press={"🔍 Analyze file"}, in_method="Upload .eml file", upload_eml=Upload(bad))
    assert len(errors) == 1 and "Traceback" not in str(errors) and "result" not in st.session_state


def test_empty_manual_input_error(env):
    errors = page("Analyze Email", press={"🔍 Analyze email"})
    assert errors and "empty" in str(errors[0])


def test_store_body_setting(env):
    st.session_state["settings"] = {"save_scans": True, "store_email_body": True}
    st.session_state.update(in_sender="a@example.com", in_subject="Hi", in_body="verify your account please")
    page("Analyze Email", press={"🔍 Analyze email"})
    assert env.get_scan(st.session_state["result"].scan_id)["body"] == "verify your account please"


def test_history_delete_and_reports(env):
    st.session_state.update(in_sender="a@example.com", in_subject="Hi", in_body="Click here immediately")
    page("Analyze Email", press={"🔍 Analyze email"})
    assert page("Reports", press={"💾 Save PDF to output/reports"}) == []
    assert list((C.REPORT_DIR).glob("*.pdf"))
    assert page("Scan History", press={"🗑 Delete this scan"}) == "rerun"
    assert env.stats()["total"] == 0


def test_single_url_checker(env):
    assert page("URL Analysis", single_url="http://192.0.2.9/login") == []
    assert any(c[0] == "dataframe" for c in S.StubState.calls)


def test_email_content_is_escaped(env):
    st.session_state.update(in_sender="x@example.com", in_subject="<img src=x onerror=alert(1)>",
                            in_body="<script>alert(1)</script> verify your account")
    page("Analyze Email", press={"🔍 Analyze email"})
    html_out = " ".join(str(c[1]) for c in S.StubState.calls if c[0] == "markdown")
    assert "<img src=x" not in html_out and "&lt;img src=x" in html_out
