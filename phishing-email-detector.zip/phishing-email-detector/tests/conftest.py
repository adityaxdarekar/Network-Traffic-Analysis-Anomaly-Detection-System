"""Shared fixtures. Tests only use the fictional samples and temporary files."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from database.db_manager import DatabaseManager  # noqa: E402
from detector.email_parser import parse_manual  # noqa: E402
from detector.phishing_engine import analyze  # noqa: E402

SAMPLE_FILES = ["legitimate_emails.json", "phishing_emails.json", "suspicious_emails.json"]


def all_samples() -> list[dict]:
    out = []
    for name in SAMPLE_FILES:
        out += json.loads((ROOT / "samples" / name).read_text())["emails"]
    return out


def sample(sid: str) -> dict:
    return next(s for s in all_samples() if s["id"] == sid)


def run(sender="", subject="", body=""):
    return analyze(parse_manual(sender, subject, body))


@pytest.fixture
def db(tmp_path):
    return DatabaseManager(tmp_path / "history.db")


@pytest.fixture
def phishing_result():
    s = sample("P1")
    return run(s["sender"], s["subject"], s["body"])
