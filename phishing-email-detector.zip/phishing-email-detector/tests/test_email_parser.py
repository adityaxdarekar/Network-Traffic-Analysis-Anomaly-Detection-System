"""Email parsing: manual input, .txt, .eml, HTML, attachments, invalid files, empty input."""

from __future__ import annotations

from email.message import EmailMessage

import pytest

import config as C
from conftest import ROOT
from detector.email_parser import (EmailParseError, html_to_text, parse_eml, parse_manual, parse_text, parse_upload,
                                   split_sender, validate_upload)


def make_eml(html: str | None = None, text: str = "Hello", attach: str | None = None, **headers) -> bytes:
    m = EmailMessage()
    m["From"] = headers.get("From", "Example Bank <alerts@examplebank.com>")
    m["To"] = "me@example.net"
    m["Subject"] = headers.get("Subject", "Statement ready")
    if "Reply_To" in headers:
        m["Reply-To"] = headers["Reply_To"]
    m.set_content(text)
    if html:
        m.add_alternative(html, subtype="html")
    if attach:
        m.add_attachment(b"placeholder", maintype="application", subtype="octet-stream", filename=attach)
    return bytes(m)


def test_manual_input_fields():
    p = parse_manual("Example Bank <alerts@examplebank.com>", "Hi", "Body text")
    assert p.display_name == "Example Bank" and p.address == "alerts@examplebank.com"
    assert p.subject == "Hi" and p.body_text == "Body text" and p.source == "manual"


def test_manual_html_body_converted_to_text():
    p = parse_manual("a@example.com", "s", "<html><body><p>Hello <b>there</b></p>"
                                         "<a href='http://x.example.com'>link</a></body></html>")
    assert "Hello" in p.body_text and "<b>" not in p.body_text
    assert p.html_links[0].url == "http://x.example.com" and p.html_links[0].text == "link"


@pytest.mark.parametrize("sender,subject,body", [("", "", ""), ("a@example.com", "  ", "   \n ")])
def test_empty_email_rejected(sender, subject, body):
    with pytest.raises(EmailParseError, match="empty"):
        parse_manual(sender, subject, body)


def test_text_file_with_headers():
    p = parse_text("From: HR <hr@example.com>\nSubject: Offer\nReply-To: x@other.example.org\n\nDear user,\nbody")
    assert p.address == "hr@example.com" and p.subject == "Offer" and p.reply_to == "x@other.example.org"
    assert p.body_text.startswith("Dear user")


def test_text_file_without_headers_is_all_body():
    p = parse_text("Just a plain message\nwith two lines")
    assert p.sender == "" and "two lines" in p.body_text


def test_eml_plain_and_html_parts():
    p = parse_eml(make_eml(html="<p>Visit <a href='http://198.51.100.1/x'>https://examplebank.com</a></p>",
                           text="Plain part", Reply_To="other@example.org"))
    assert p.source == "eml" and p.subject == "Statement ready" and p.reply_to == "other@example.org"
    assert "Plain part" in p.body_text and "Visit" in p.body_text      # both parts analysed
    assert p.html_links[0].url == "http://198.51.100.1/x"
    assert p.headers["Subject"] == "Statement ready"


def test_eml_attachment_listed_not_opened():
    p = parse_eml(make_eml(attach="Invoice.pdf.exe"))
    assert p.attachments == [{"filename": "Invoice.pdf.exe", "content_type": "application/octet-stream", "size": 11}]
    assert "placeholder" not in p.body_text


def test_html_scripts_removed():
    text, _ = html_to_text("<html><head><script>alert('x')</script><style>p{}</style></head>"
                           "<body><p>Safe text</p><script>steal()</script></body></html>")
    assert "Safe text" in text and "alert" not in text and "steal" not in text


def test_split_sender():
    assert split_sender('"Support" <help@example.com>') == ("Support", "help@example.com")
    assert split_sender("plain@example.com") == ("", "plain@example.com")


@pytest.mark.parametrize("name", ["mail.pdf", "mail.exe", "mail", "mail.html"])
def test_invalid_file_type(name):
    with pytest.raises(EmailParseError, match="Unsupported file type"):
        validate_upload(name, b"data")


def test_empty_and_oversized_upload():
    with pytest.raises(EmailParseError, match="empty"):
        parse_upload("a.txt", b"")
    with pytest.raises(EmailParseError, match="larger than"):
        parse_upload("a.eml", b"x" * (C.MAX_UPLOAD_BYTES + 1))


def test_binary_txt_rejected():
    with pytest.raises(EmailParseError, match="binary"):
        parse_upload("a.txt", b"\x00\x01\x02binary")


def test_malformed_eml_rejected():
    with pytest.raises(EmailParseError):
        parse_upload("broken.eml", b"this is not an email at all, just words")


def test_eml_with_bad_charset_does_not_crash():
    raw = (b"From: a@example.com\r\nSubject: test\r\nContent-Type: text/plain; charset=unknown-8bit\r\n\r\n"
           b"Caf\xe9 verify your account")
    p = parse_upload("x.eml", raw)
    assert "verify your account" in p.body_text


def test_sample_eml_files_parse():
    for f in (ROOT / "samples" / "eml").iterdir():
        p = parse_upload(f.name, f.read_bytes())
        assert p.subject


def test_long_body_truncated():
    p = parse_manual("a@example.com", "s", "word " * (C.MAX_BODY_CHARS // 4))
    assert p.truncated and len(p.body_text) == C.MAX_BODY_CHARS
