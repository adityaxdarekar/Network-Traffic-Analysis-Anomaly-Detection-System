"""Scoring engine, classification, end-to-end sample classification."""

from __future__ import annotations

import pytest

import config as C
from conftest import all_samples, run
from detector.risk_scorer import Indicator, classify, score_indicators


@pytest.mark.parametrize("score,level", [(0, "LOW"), (29, "LOW"), (30, "MEDIUM"), (59, "MEDIUM"), (60, "HIGH"),
                                         (100, "HIGH")])
def test_classification_thresholds(score, level):
    assert classify(score) == level


def test_score_is_sum_of_indicators():
    r = score_indicators([Indicator("a", "URLs", "t", "e", 20), Indicator("b", "Sender", "t", "e", 15)])
    assert r["score"] == 35 and r["level"] == "MEDIUM" and r["label"] == C.RISK_LABELS["MEDIUM"]


def test_duplicate_indicator_counted_once():
    r = score_indicators([Indicator("same", "URLs", "t", "e", 20)] * 4)
    assert r["score"] == 20 and len(r["indicators"]) == 1


def test_category_cap():
    inds = [Indicator(f"k{i}", "Keywords", "t", "e", 15) for i in range(6)]       # 90 raw
    r = score_indicators(inds)
    assert r["by_category"]["Keywords"] == {"raw": 90, "capped": C.CATEGORY_CAPS["Keywords"]}
    assert r["score"] == C.CATEGORY_CAPS["Keywords"]


def test_score_never_exceeds_100():
    inds = [Indicator(f"{c}{i}", c, "t", "e", 25) for c in C.CATEGORY_CAPS for i in range(10)]
    assert score_indicators(inds)["score"] == 100


def test_zero_point_indicators_ignored():
    assert score_indicators([Indicator("z", "URLs", "t", "e", 0)])["indicators"] == []


def test_empty_is_low():
    assert score_indicators([]) ["score"] == 0


def test_url_check_counted_once_for_many_links():
    body = "http://192.0.2.1/a http://192.0.2.2/b http://192.0.2.3/c"
    r = run("a@example.com", "links", body)
    ip = [i for i in r.indicators if i.id == "url:url_ip"]
    assert len(ip) == 1 and ip[0].points == C.WEIGHTS["url_ip"] and "3 links" in ip[0].title


def test_every_indicator_explained(phishing_result):
    assert phishing_result.indicators
    for i in phishing_result.indicators:
        assert i.title and i.explanation and i.points > 0


def test_recommendations_and_disclaimer(phishing_result):
    assert any("Do not click" in r for r in phishing_result.recommendations)
    assert "not proof" in phishing_result.disclaimer


@pytest.mark.parametrize("s", all_samples(), ids=lambda s: s["id"])
def test_samples_classified_as_intended(s):
    """End-to-end: every sample email receives the classification it was written to demonstrate."""
    r = run(s["sender"], s["subject"], s["body"])
    assert r.level == s["expected"], (s["id"], r.score, [i.title for i in r.indicators])


def test_legitimate_samples_have_zero_score():
    for s in all_samples():
        if s["category"] == "legitimate":
            assert run(s["sender"], s["subject"], s["body"]).score == 0
