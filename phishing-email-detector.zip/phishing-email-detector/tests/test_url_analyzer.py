"""URL extraction and the static URL checks. No URL is ever requested."""

from __future__ import annotations

import socket

import pytest

from detector.email_parser import Link, parse_manual
from detector.url_analyzer import (analyze_url, brand_lookalike, extract_urls, is_ip, levenshtein,
                                   registered_domain, subdomain_count)


def checks(url, text=""):
    return {f.check for f in analyze_url(url, text).findings}


def test_extraction_from_text():
    text = ("Visit https://www.example.com/page, or http://192.0.2.5/login. Also www.example.org/x "
            "and (https://example.net/a).")
    urls = [l.url for l in extract_urls(text)]
    assert urls == ["https://www.example.com/page", "http://192.0.2.5/login", "www.example.org/x",
                    "https://example.net/a"]


def test_extraction_deduplicates_and_keeps_html_text():
    links = [Link(url="http://198.51.100.1/x", text="https://examplebank.com", source="html")]
    urls = extract_urls("again http://198.51.100.1/x", links)
    assert len(urls) == 1 and urls[0].text == "https://examplebank.com"


def test_extraction_from_html_email():
    p = parse_manual("a@example.com", "s", '<p><a href="https://bit.ly/abc">Click</a></p>')
    assert [l.url for l in extract_urls(p.body_text, p.html_links)] == ["https://bit.ly/abc"]


@pytest.mark.parametrize("url", ["http://192.0.2.45/login", "https://[2001:db8::1]/x", "http://3232235777/",
                                 "http://0xC0A80001/"])
def test_ip_based_url(url):
    assert "IP address instead of domain" in checks(url)


@pytest.mark.parametrize("url", ["https://bit.ly/3xYz", "http://tinyurl.com/abc", "https://t.co/x1"])
def test_url_shortener(url):
    assert "URL shortener" in checks(url)


def test_http_flagged_https_not():
    assert "Uses HTTP, not HTTPS" in checks("http://example.com")
    assert "Uses HTTP, not HTTPS" not in checks("https://example.com")


def test_at_symbol():
    a = analyze_url("https://examplebank.com@198.51.100.7/login")
    assert "@ symbol in URL" in {f.check for f in a.findings} and a.host == "198.51.100.7"


def test_punycode():
    assert "Punycode / non-ASCII domain" in checks("https://xn--pypal-4ve.com/")


def test_excessive_subdomains():
    url = "https://login.secure.account.verify.example-host.net/"
    assert subdomain_count("login.secure.account.verify.example-host.net") == 4
    assert "Excessive subdomains" in checks(url)


def test_long_and_encoded():
    url = "https://example.net/" + "a" * 120 + "?r=%2F%2F%40%2E"
    assert {"Unusually long URL", "Encoded characters"} <= checks(url)


@pytest.mark.parametrize("domain", ["examplebank-secure.com", "examp1ebank.com", "examplebank.com.verify-now.xyz",
                                    "paypa1.com", "rnicrosoft.com", "exampleshop.account-verify.top"])
def test_misleading_domains(domain):
    assert brand_lookalike(domain) is not None
    assert "Misleading domain" in checks(f"https://{domain}/")


@pytest.mark.parametrize("domain", ["examplebank.com", "www.examplebank.com", "pineapple.com", "amazing.com",
                                    "docs.example.com", "s3.amazonaws.com", "mail.google.com"])
def test_legitimate_or_unrelated_domains_not_misleading(domain):
    assert brand_lookalike(domain) is None


def test_link_text_mismatch():
    assert "Link text does not match destination" in checks("http://198.51.100.1/x", "https://www.examplebank.com")
    assert "Link text does not match destination" not in checks("https://www.examplebank.com/a",
                                                                 "www.examplebank.com")


def test_clean_url_has_no_findings():
    a = analyze_url("https://www.exampleuniversity.edu/exams/timetable")
    assert a.findings == [] and a.risk == "None"


def test_https_alone_is_not_safe():
    """A phishing URL with HTTPS still gets findings - HTTPS is not treated as proof of safety."""
    a = analyze_url("https://examplebank.com.secure-login.xyz/verify")
    assert a.risk == "High"


def test_javascript_link():
    assert analyze_url("javascript:alert(1)").risk == "High"


def test_helpers():
    assert is_ip("192.0.2.1") and not is_ip("example.com")
    assert registered_domain("a.b.example.co.uk") == "example.co.uk"
    assert registered_domain("www.example.com") == "example.com"
    assert levenshtein("paypal", "paypa1") == 1


def test_no_network_access(monkeypatch):
    """Analysing URLs must never open a connection or resolve a host name."""
    def boom(*a, **k):
        raise AssertionError("network access attempted")
    monkeypatch.setattr(socket, "create_connection", boom)
    monkeypatch.setattr(socket, "getaddrinfo", boom)
    monkeypatch.setattr(socket.socket, "connect", boom)
    for url in ["http://192.0.2.45/login", "https://bit.ly/x", "https://examplebank.com.evil.xyz/"]:
        analyze_url(url)


def test_visible_link_text_is_not_a_second_url():
    p = parse_manual("a@example.com", "s", '<a href="http://198.51.100.1/x">https://www.examplebank.com/login</a>')
    assert [l.url for l in extract_urls(p.body_text, p.html_links)] == ["http://198.51.100.1/x"]
