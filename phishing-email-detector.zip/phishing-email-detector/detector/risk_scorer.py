"""
Weighted, explainable risk scoring.

Every triggered rule becomes an Indicator with its points. Rules:
  * each indicator id counts once per e-mail (repeating a phrase ten times is not ten times worse)
  * each category is capped (config.CATEGORY_CAPS) so one kind of evidence cannot dominate
  * the total is capped at 100
  * 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH (config.RISK_THRESHOLDS)

The score is a heuristic built from expert rules - NOT a statistically validated probability.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import config as C


@dataclass
class Indicator:
    id: str                 # unique key used for de-duplication
    category: str           # Keywords / Language / URLs / Sender / Attachments
    title: str
    explanation: str
    points: int
    evidence: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def classify(score: int) -> str:
    if score >= C.RISK_THRESHOLDS["HIGH"]:
        return "HIGH"
    if score >= C.RISK_THRESHOLDS["MEDIUM"]:
        return "MEDIUM"
    return "LOW"


def weight(key: str, weights: dict | None = None) -> int:
    return int((weights or C.WEIGHTS).get(key, 0))


def dedupe(indicators: list[Indicator]) -> list[Indicator]:
    seen, out = set(), []
    for ind in indicators:
        if ind.id not in seen:
            seen.add(ind.id)
            out.append(ind)
    return out


def score_indicators(indicators: list[Indicator], caps: dict | None = None) -> dict:
    """{"score", "level", "label", "by_category": {cat: {"raw", "capped"}}, "indicators": [...]}"""
    caps = caps or C.CATEGORY_CAPS
    inds = dedupe([i for i in indicators if i.points > 0])
    by_cat: dict[str, dict] = {}
    for i in inds:
        by_cat.setdefault(i.category, {"raw": 0, "capped": 0})
        by_cat[i.category]["raw"] += i.points
    for cat, v in by_cat.items():
        v["capped"] = min(v["raw"], caps.get(cat, 100))
    score = max(0, min(100, sum(v["capped"] for v in by_cat.values())))
    level = classify(score)
    return {"score": score, "level": level, "label": C.RISK_LABELS[level], "by_category": by_cat,
            "indicators": sorted(inds, key=lambda i: -i.points)}
