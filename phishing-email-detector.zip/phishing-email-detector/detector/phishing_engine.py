"""
Phishing engine: runs every detector on a ParsedEmail and produces one AnalysisResult
(score, classification, indicators, URL table, sender analysis, recommendations).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime

import config as C
from detector.email_parser import ParsedEmail
from detector.keyword_detector import (KeywordHit, find_attachment_risks, find_keywords, find_sensitive_requests,
                                       find_urgency)
from detector.risk_scorer import Indicator, score_indicators, weight
from detector.sender_analyzer import SenderAnalysis, analyze_parsed_sender
from detector.url_analyzer import UrlAnalysis, analyze_links, extract_urls

DISCLAIMER = ("This is a rule-based detector. Its score is a heuristic and its findings are indicators, not proof "
              "that an email is malicious or safe. When in doubt, verify through the organisation's official "
              "website or phone number.")


@dataclass
class AnalysisResult:
    scan_id: str
    analyzed_at: str
    email: ParsedEmail
    score: int
    level: str
    label: str
    indicators: list
    by_category: dict
    keywords: list = field(default_factory=list)          # [KeywordHit]
    urgency: list = field(default_factory=list)           # [str]
    sensitive: list = field(default_factory=list)         # [{"item", "match"}]
    attachments: list = field(default_factory=list)       # [{"source", "detail", "reason"}]
    urls: list = field(default_factory=list)              # [UrlAnalysis]
    sender: SenderAnalysis | None = None
    recommendations: list = field(default_factory=list)
    disclaimer: str = DISCLAIMER

    @property
    def url_rows(self) -> list[dict]:
        return [row for u in self.urls for row in u.rows()]

    @property
    def summary(self) -> str:
        if not self.indicators:
            return "No phishing indicators were found."
        top = "; ".join(i.title for i in self.indicators[:4])
        return f"{len(self.indicators)} indicator(s): {top}" + ("…" if len(self.indicators) > 4 else "")

    def to_dict(self, include_body: bool = False) -> dict:
        d = {
            "scan_id": self.scan_id, "analyzed_at": self.analyzed_at, "sender": self.email.sender,
            "subject": self.email.subject, "source": self.email.source, "score": self.score, "level": self.level,
            "classification": self.label, "summary": self.summary,
            "indicators": [i.to_dict() for i in self.indicators],
            "keywords": [{"phrase": k.phrase, "category": k.category, "level": k.level, "matches": k.matches,
                          "why": k.why} for k in self.keywords],
            "urgency": self.urgency, "sensitive_requests": self.sensitive, "attachments": self.attachments,
            "urls": self.url_rows, "attachments_listed": self.email.attachments,
            "sender_analysis": {"address": self.sender.address, "display_name": self.sender.display_name,
                                "domain": self.sender.domain, "findings": [f.__dict__ for f in self.sender.findings],
                                "notes": self.sender.notes, "rows": self.sender.as_rows()} if self.sender else {},
            "by_category": self.by_category, "url_count": len(self.urls),
            "recommendations": self.recommendations, "disclaimer": self.disclaimer,
        }
        if include_body:
            d["body"] = self.email.body_text
        return d


LEVEL_TO_KEY = {"low": "keyword_low", "medium": "keyword_medium", "high": "keyword_high"}


def build_indicators(keywords: list[KeywordHit], urgency, sensitive, attachments, urls: list[UrlAnalysis],
                     sender: SenderAnalysis) -> list[Indicator]:
    inds = []
    for k in keywords:
        inds.append(Indicator(f"kw:{k.phrase}", "Keywords", f"Suspicious phrase: \"{k.matches[0]}\"",
                              f"{k.category}. {k.why}", weight(LEVEL_TO_KEY[k.level]), ", ".join(k.matches)))
    if urgency:
        inds.append(Indicator("urgency", "Language", "Urgent or threatening language",
                              "Pressure and deadlines are used to stop you from checking the message carefully.",
                              weight("urgency"), ", ".join(urgency[:6])))
    if sensitive:
        inds.append(Indicator("sensitive", "Language", "Requests sensitive information",
                              "Legitimate organisations do not ask for passwords, codes or card numbers by email.",
                              weight("sensitive_request"), ", ".join(s["item"] for s in sensitive)))
    if attachments:
        inds.append(Indicator("attachment", "Attachments", "Suspicious attachment",
                              "; ".join(sorted({a["reason"] for a in attachments})).capitalize() + ".",
                              weight("attachment_reference"), ", ".join(a["detail"] for a in attachments[:5])))
    # URL checks: one indicator per check type, listing the URLs it applies to
    per_check: dict[str, list] = {}
    for u in urls:
        for f in u.findings:
            per_check.setdefault(f.weight_key, []).append((u, f))
    for key, items in per_check.items():
        u0, f0 = items[0]
        inds.append(Indicator(f"url:{key}", "URLs", f"URL: {f0.check}" + (f" ({len(items)} links)" if len(items) > 1
                                                                          else ""),
                              f0.reason, weight(key), ", ".join(sorted({u.url for u, _ in items}))[:400]))
    if sender:
        for f in sender.findings:
            inds.append(Indicator(f"sender:{f.weight_key}", "Sender", f"Sender: {f.check}", f.reason,
                                  weight(f.weight_key), sender.address))
    return inds


def recommendations(level: str, res_flags: dict) -> list[str]:
    recs = []
    if level == "HIGH":
        recs.append("Do not click any links, open attachments or reply to this email.")
        recs.append("Do not provide passwords, codes, card or bank details.")
        recs.append("Report it to your IT/security team or the organisation's official abuse address, then delete it.")
    elif level == "MEDIUM":
        recs.append("Treat this email with caution - do not click links until you have verified the sender.")
        recs.append("Contact the organisation using contact details from its official website, not from this email.")
    else:
        recs.append("No strong phishing indicators were found. Still check unexpected requests before acting.")
    if res_flags.get("urls"):
        recs.append("Hover over links to see the real address; type known addresses into the browser yourself.")
    if res_flags.get("sensitive"):
        recs.append("Never send passwords, one-time codes or card numbers by email - no legitimate service needs them.")
    if res_flags.get("attachments"):
        recs.append("Do not open the attachment or enable macros; ask the sender through another channel.")
    if res_flags.get("sender"):
        recs.append("The sender details look spoofed - verify through the organisation's official phone or website.")
    if level != "LOW":
        recs.append("If you already clicked or entered details, change the password from the official site and "
                    "enable multi-factor authentication.")
    return recs


def analyze(parsed: ParsedEmail) -> AnalysisResult:
    text = f"{parsed.subject}\n{parsed.body_text}"
    keywords = find_keywords(text)
    urgency = find_urgency(text)
    sensitive = find_sensitive_requests(text)
    attachments = find_attachment_risks(text, parsed.attachments)
    links = extract_urls(parsed.body_text + "\n" + parsed.subject, parsed.html_links)
    urls = analyze_links(links)
    sender = analyze_parsed_sender(parsed)
    scored = score_indicators(build_indicators(keywords, urgency, sensitive, attachments, urls, sender))
    flags = {"urls": any(u.findings for u in urls), "sensitive": bool(sensitive), "attachments": bool(attachments),
             "sender": bool(sender.findings)}
    return AnalysisResult(
        scan_id="SCAN-" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4].upper(),
        analyzed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), email=parsed,
        score=scored["score"], level=scored["level"], label=scored["label"], indicators=scored["indicators"],
        by_category=scored["by_category"], keywords=keywords, urgency=urgency, sensitive=sensitive,
        attachments=attachments, urls=urls, sender=sender,
        recommendations=recommendations(scored["level"], flags))
