"""
Sender analysis: address format, domain, display-name spoofing, lookalike domains,
free-mail brand impersonation, Reply-To mismatch and (for .eml) authentication results.

An unfamiliar domain is NOT reported as malicious - only specific, explainable anomalies are.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import config as C
from detector.email_parser import ParsedEmail, split_sender
from detector.url_analyzer import brand_lookalike, registered_domain

EMAIL_RE = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+"
                      r"(?:[A-Za-z]{2,63}|xn--[A-Za-z0-9-]{2,59})$")
ADDRESS_IN_TEXT = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")


@dataclass
class SenderFinding:
    check: str
    reason: str
    weight_key: str


@dataclass
class SenderAnalysis:
    raw: str = ""
    display_name: str = ""
    address: str = ""
    domain: str = ""
    registered_domain: str = ""
    valid_format: bool = False
    is_freemail: bool = False
    claimed_brand: str = ""
    official_domain: bool = False
    findings: list = field(default_factory=list)
    notes: list = field(default_factory=list)

    def as_rows(self) -> list[dict]:
        rows = [{"Field": "From (as shown)", "Value": self.raw or "(not provided)"},
                {"Field": "Display name", "Value": self.display_name or "-"},
                {"Field": "Address", "Value": self.address or "-"},
                {"Field": "Domain", "Value": self.domain or "-"},
                {"Field": "Valid format", "Value": "Yes" if self.valid_format else "No"},
                {"Field": "Free email provider", "Value": "Yes" if self.is_freemail else "No"},
                {"Field": "Brand named by sender", "Value": self.claimed_brand or "-"},
                {"Field": "Official brand domain", "Value": "Yes" if self.official_domain else "-"}]
        return rows


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def brand_in(text: str) -> str:
    """Trusted brand named in a display name or local part ('Example Bank Security' -> examplebank)."""
    n = _norm(text)
    for brand in sorted(C.TRUSTED_BRANDS, key=len, reverse=True):
        if len(brand) >= C.MIN_BRAND_LENGTH and brand in n:
            return brand
    return ""


def analyze_sender(sender: str, reply_to: str = "", auth_results: str = "") -> SenderAnalysis:
    s = SenderAnalysis(raw=(sender or "").strip())
    s.display_name, s.address = split_sender(s.raw)
    if not s.address and s.raw and "@" in s.raw:
        s.address = s.raw.strip("<> ")
    if not s.raw:
        s.notes.append("No sender was provided, so sender checks were skipped.")
        return s

    s.valid_format = bool(EMAIL_RE.match(s.address))
    if not s.valid_format:
        s.findings.append(SenderFinding("Invalid sender address",
                                        f"'{s.address or s.raw}' is not a valid email address format",
                                        "sender_invalid"))
        return s
    local, s.domain = s.address.rsplit("@", 1)
    s.domain = s.domain.lower()
    s.registered_domain = registered_domain(s.domain)
    s.is_freemail = s.registered_domain in C.FREE_EMAIL_PROVIDERS or s.domain in C.FREE_EMAIL_PROVIDERS
    legit = {d for ds in C.TRUSTED_BRANDS.values() for d in ds}

    claimed = brand_in(s.display_name) or brand_in(local)
    s.claimed_brand = claimed
    if claimed and s.registered_domain in C.TRUSTED_BRANDS[claimed]:
        s.official_domain = True

    if "xn--" in s.domain:
        s.findings.append(SenderFinding("Punycode sender domain", f"'{s.domain}' uses international characters that "
                                        "can imitate a familiar domain", "sender_punycode"))
    look = brand_lookalike(s.domain)
    if look and not s.is_freemail:
        s.findings.append(SenderFinding("Lookalike domain", f"Sender domain {look[1]}", "sender_lookalike"))
    if claimed and not s.official_domain:
        official = ", ".join(C.TRUSTED_BRANDS[claimed])
        if s.is_freemail:
            s.findings.append(SenderFinding("Brand name on a free email account",
                                            f"Claims to be '{claimed}' but sends from a free {s.registered_domain} "
                                            f"account (official: {official})", "sender_brand_freemail"))
        elif not look:
            s.findings.append(SenderFinding("Display name does not match domain",
                                            f"Name says '{claimed}' but the address is @{s.domain} "
                                            f"(official: {official})", "sender_display_mismatch"))
    shown = ADDRESS_IN_TEXT.search(s.display_name)
    if shown and shown.group(0).lower() != s.address.lower():
        s.findings.append(SenderFinding("Different address in display name",
                                        f"Display name shows {shown.group(0)} but the real address is {s.address}",
                                        "sender_display_mismatch"))
    digits = sum(c.isdigit() for c in local)
    if digits >= 5 or (len(local) >= 6 and digits / len(local) > 0.4) or re.search(r"[^\w.+-]", local) \
            or sum(c.isdigit() for c in s.registered_domain.split(".")[0]) >= 4:
        s.findings.append(SenderFinding("Unusual sender address", f"'{s.address}' contains many numbers or unusual "
                                        "characters, typical of throw-away accounts", "sender_digits"))
    if reply_to:
        _, rt = split_sender(reply_to)
        if rt and "@" in rt and registered_domain(rt.rsplit("@", 1)[1]) != s.registered_domain:
            s.findings.append(SenderFinding("Reply-To goes elsewhere", f"Replies would go to {rt}, not to "
                                            f"{s.address}", "sender_reply_to_mismatch"))
    if auth_results:
        failed = sorted(set(re.findall(r"\b(spf|dkim|dmarc)=(fail|softfail|none|permerror)", auth_results, re.I)))
        bad = [f"{a.upper()}={b}" for a, b in failed if b.lower() in ("fail", "softfail", "permerror")]
        if bad:
            s.findings.append(SenderFinding("Email authentication failed", "The receiving server recorded "
                                            + ", ".join(bad) + " - the sender may be forged", "sender_auth_fail"))

    if s.is_freemail and not claimed:
        s.notes.append(f"Sent from a free provider ({s.registered_domain}). That is normal for individuals but "
                       "unusual for banks, shops or universities.")
    if s.official_domain:
        s.notes.append(f"The domain matches the official domain of '{claimed}'. Note: the From header can be forged; "
                       "check authentication results when available.")
    if not s.findings and not s.official_domain and not s.is_freemail and s.registered_domain not in legit:
        s.notes.append(f"'{s.registered_domain}' is not in the trusted-brand list. Unfamiliar does not mean "
                       "malicious - no anomaly was found.")
    return s


def analyze_parsed_sender(p: ParsedEmail) -> SenderAnalysis:
    auth = " ".join(v for k, v in p.headers.items() if k in ("Authentication-Results", "Received-SPF"))
    return analyze_sender(p.sender, p.reply_to, auth)
