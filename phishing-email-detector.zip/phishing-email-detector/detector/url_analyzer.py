"""
URL extraction and static analysis.

URLs are treated as untrusted text. This module NEVER visits, resolves, downloads or
renders a URL - every check is done on the string itself (urllib.parse + ipaddress).
HTTPS alone does not make a link safe: phishing sites routinely use valid certificates.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlsplit

import config as C
from detector.email_parser import Link

URL_RE = re.compile(r"""(?:\b(?:https?|hxxps?|ftp)://|\bwww\.)[^\s<>"'`\[\]{}|\\^]+""", re.I)
TRAILING = ".,;:!?)]}'\">"
RISK_ORDER = {"None": 0, "Low": 1, "Medium": 2, "High": 3}
DOMAIN_IN_TEXT = re.compile(r"\b((?:[a-z0-9-]+\.)+[a-z]{2,})\b", re.I)


@dataclass
class UrlFinding:
    check: str
    reason: str
    risk: str               # Low / Medium / High
    weight_key: str


@dataclass
class UrlAnalysis:
    url: str
    link_text: str = ""
    scheme: str = ""
    host: str = ""
    registered_domain: str = ""
    findings: list = field(default_factory=list)

    @property
    def risk(self) -> str:
        if not self.findings:
            return "None"
        return max((f.risk for f in self.findings), key=RISK_ORDER.get)

    def rows(self) -> list[dict]:
        if not self.findings:
            return [{"URL": self.url, "Finding": "No suspicious characteristics found",
                     "Reason": "Static check only - still verify before clicking", "Risk": "None"}]
        return [{"URL": self.url, "Finding": f.check, "Reason": f.reason, "Risk": f.risk} for f in self.findings]


# --------------------------------------------------------------------------- extraction
def clean_url(url: str) -> str:
    url = url.strip()
    while url and url[-1] in TRAILING:
        # keep a closing bracket that belongs to the URL, e.g. wiki/Foo_(bar)
        if url[-1] == ")" and url.count("(") >= url.count(")"):
            break
        url = url[:-1]
    return url


def extract_urls(text: str, html_links: list | None = None) -> list[Link]:
    """URLs from plain text (regex) and from HTML <a href> (with their visible text). De-duplicated."""
    found: dict[str, Link] = {}
    for link in html_links or []:
        url = clean_url(link.url)
        if url and url not in found:
            found[url] = Link(url=url, text=link.text, source="html")
    # the visible text of an HTML link is display text, not a second destination
    shown = {clean_url(link.text) for link in html_links or [] if link.text}
    for m in URL_RE.finditer(text or ""):
        url = clean_url(m.group(0))
        if len(url) > 4 and url not in found and url not in shown:
            found[url] = Link(url=url, source="text")
    return list(found.values())[: C.MAX_URLS]


# --------------------------------------------------------------------------- domain helpers
def is_ip(host: str) -> bool:
    host = host.strip("[]")
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        pass
    # decimal (http://3232235777) or hex (http://0xC0A80001) encoded IPv4
    return bool(re.fullmatch(r"\d{8,10}|0x[0-9a-f]{8}", host, re.I))


def registered_domain(host: str) -> str:
    """Approximate registrable domain: last two labels, or three for known two-level suffixes."""
    host = (host or "").lower().strip(".")
    if not host or is_ip(host):
        return host
    labels = host.split(".")
    if len(labels) >= 3 and ".".join(labels[-2:]) in C.TWO_LEVEL_SUFFIXES:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def subdomain_count(host: str) -> int:
    reg = registered_domain(host)
    if not reg or reg == host:
        return 0
    return host[: -len(reg)].strip(".").count(".") + 1


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


HOMOGLYPHS = [("rn", "m"), ("vv", "w"), ("0", "o"), ("1", "l"), ("3", "e"), ("5", "s"), ("4", "a"), ("7", "t"),
              ("8", "b"), ("@", "a"), ("$", "s"), ("|", "l"), ("i", "l")]


def deconfuse(label: str) -> str:
    s = label.lower().replace("-", "").replace("_", "")
    for a, b in HOMOGLYPHS:
        s = s.replace(a, b)
    return s


def brand_lookalike(domain: str, brands: dict | None = None) -> tuple[str, str] | None:
    """
    (brand, reason) if `domain` imitates a trusted brand's domain without being one of its real domains.
    Detects: typos (examp1ebank.com), homoglyphs (rn->m, 0->o), brand + extra words (paypal-secure.com),
    and the brand's domain used as a subdomain (paypal.com.account-check.net).
    """
    brands = brands or C.TRUSTED_BRANDS
    domain = (domain or "").lower().strip(".")
    if not domain or is_ip(domain):
        return None
    reg = registered_domain(domain)
    all_legit = {d for ds in brands.values() for d in ds}
    if reg in all_legit:
        return None
    label = reg.split(".")[0]
    sub_labels = domain[: -len(reg)].strip(".").split(".") if domain != reg else []
    for brand, legit in brands.items():
        if len(brand) < C.MIN_BRAND_LENGTH:
            continue
        for real in legit:
            real_label = real.split(".")[0]
            if domain.startswith(real + ".") or f".{real}." in f".{domain}.":
                return brand, f"contains the real domain '{real}' as a subdomain of '{reg}'"
            if label == real_label:
                return brand, f"uses the name '{real_label}' with a different ending ('{reg}' instead of '{real}')"
            limit = 2 if len(real_label) >= 8 else 1
            if len(real_label) >= 6 and levenshtein(label, real_label) <= limit:
                return brand, f"'{reg}' is a near-spelling of '{real}'"
            if deconfuse(label) == deconfuse(real_label):
                return brand, f"'{reg}' uses look-alike characters to imitate '{real}'"
        if len(brand) >= C.MIN_BRAND_LENGTH and any(sl == brand or sl.split("-")[0] == brand for sl in sub_labels):
            return brand, f"puts the brand name '{brand}' in front of an unrelated domain '{reg}'"
        tokens = label.split("-")
        if brand in tokens or label.startswith(brand) or deconfuse(label).startswith(deconfuse(brand)) \
                or any(t.startswith(brand) for t in tokens):
            return brand, f"includes the brand name '{brand}' but is not an official {brand} domain"
    return None


# --------------------------------------------------------------------------- analysis
def analyze_url(url: str, link_text: str = "") -> UrlAnalysis:
    raw = url
    norm = url if re.match(r"^[a-z][a-z0-9+.-]*:", url, re.I) else "http://" + url
    norm = re.sub(r"^hxxp", "http", norm, flags=re.I)
    a = UrlAnalysis(url=raw, link_text=link_text)
    f = a.findings

    if norm.lower().startswith("javascript:"):
        a.scheme = "javascript"
        f.append(UrlFinding("JavaScript link", "The link runs script code instead of opening a page", "High",
                            "url_suspicious_chars"))
        return a
    try:
        parts = urlsplit(norm)
        host = (parts.hostname or "").lower()
    except ValueError:
        f.append(UrlFinding("Malformed URL", "The URL cannot be parsed - often a sign of obfuscation", "Medium",
                            "url_suspicious_chars"))
        return a
    a.scheme, a.host = parts.scheme.lower(), host
    a.registered_domain = registered_domain(host)
    netloc = parts.netloc

    if a.scheme == "http":
        f.append(UrlFinding("Uses HTTP, not HTTPS", "The connection is not encrypted. (HTTPS alone would not prove "
                            "the site is safe either.)", "Low", "url_http"))
    if is_ip(host):
        f.append(UrlFinding("IP address instead of domain", f"Links to the raw address {host} - legitimate "
                            "organisations link to their named domain", "High", "url_ip"))
    if "@" in netloc:
        f.append(UrlFinding("@ symbol in URL", "Everything before '@' is ignored by the browser, so the real "
                            f"destination is '{host}'", "High", "url_at_symbol"))
    if "xn--" in host or any(ord(c) > 127 for c in host):
        f.append(UrlFinding("Punycode / non-ASCII domain", "International characters can imitate a familiar "
                            "domain (homograph attack)", "High", "url_punycode"))
    if a.registered_domain in C.URL_SHORTENERS or host in C.URL_SHORTENERS:
        f.append(UrlFinding("URL shortener", f"{host} hides the real destination", "Medium", "url_shortener"))
    if not is_ip(host):
        look = brand_lookalike(host)
        if look:
            f.append(UrlFinding("Misleading domain", f"Domain {look[1]}", "High", "url_brand_mismatch"))
        else:
            path_brand = _brand_in_path(parts.path + "?" + parts.query, a.registered_domain)
            if path_brand:
                f.append(UrlFinding("Brand name in path", f"Mentions '{path_brand}' in the path, but the site is "
                                    f"'{a.registered_domain}'", "Medium", "url_brand_mismatch"))
        if subdomain_count(host) > C.MAX_SUBDOMAINS:
            f.append(UrlFinding("Excessive subdomains", f"{subdomain_count(host)} subdomain levels before "
                                f"'{a.registered_domain}' - used to make a long, official-looking address",
                                "Medium", "url_many_subdomains"))
        tld = "." + host.rsplit(".", 1)[-1] if "." in host else ""
        if tld in C.SUSPICIOUS_TLDS:
            f.append(UrlFinding("Uncommon top-level domain", f"'{tld}' domains are cheap and often abused",
                                "Low", "url_suspicious_tld"))
    if link_text:
        shown = DOMAIN_IN_TEXT.search(link_text)
        if shown and "." in shown.group(1):
            shown_reg = registered_domain(shown.group(1))
            if shown_reg and a.registered_domain and shown_reg != a.registered_domain and not is_ip(shown_reg):
                f.append(UrlFinding("Link text does not match destination", f"Shows '{shown.group(1)}' but "
                                    f"goes to '{host}'", "High", "url_text_mismatch"))
    if len(raw) > C.LONG_URL_LENGTH:
        f.append(UrlFinding("Unusually long URL", f"{len(raw)} characters - long URLs hide the real domain",
                            "Low", "url_long"))
    encoded = re.findall(r"%[0-9a-f]{2}", raw, re.I)
    if "%" in netloc or len(encoded) >= 3:
        f.append(UrlFinding("Encoded characters", f"{len(encoded)} percent-encoded characters can hide words or "
                            f"redirects (decoded: {unquote(raw)[:80]})", "Medium" if "%" in netloc else "Low",
                            "url_encoded"))
    odd = []
    if "//" in parts.path:
        odd.append("'//' inside the path (possible redirect)")
    if host.count("-") >= 3:
        odd.append(f"{host.count('-')} hyphens in the domain")
    if re.search(r"(redirect|url|next|goto|dest)=https?", parts.query, re.I):
        odd.append("redirect parameter pointing to another site")
    if "~" in host or "_" in host:
        odd.append("unusual characters in the host")
    if odd:
        f.append(UrlFinding("Suspicious characters", "; ".join(odd), "Low", "url_suspicious_chars"))
    words = sorted({w for w in C.URL_SUSPICIOUS_WORDS if w in (host + parts.path).lower()})
    if words and (a.registered_domain not in {d for ds in C.TRUSTED_BRANDS.values() for d in ds}):
        f.append(UrlFinding("Suspicious keywords in URL", "Contains " + ", ".join(words[:5]), "Low", "url_keywords"))
    return a


def _brand_in_path(path: str, reg: str) -> str | None:
    p = path.lower()
    for brand, legit in C.TRUSTED_BRANDS.items():
        if len(brand) >= C.MIN_BRAND_LENGTH and brand in p.replace("-", "") and reg not in legit:
            return brand
    return None


def analyze_links(links: list[Link]) -> list[UrlAnalysis]:
    return [analyze_url(link.url, link.text) for link in links]
