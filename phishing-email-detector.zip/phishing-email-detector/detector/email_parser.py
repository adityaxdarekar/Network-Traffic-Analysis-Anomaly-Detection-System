"""
Email parsing: manual input, .txt files and .eml files -> one ParsedEmail object.

Safety:
  * attachments are only *listed* (file name, type, size) - never saved, opened or executed
  * HTML is converted to text with BeautifulSoup; <script>/<style> content is discarded
  * nothing is fetched from the network (remote images, links) - only text is read
  * malformed input raises EmailParseError with a friendly message instead of crashing
"""

from __future__ import annotations

import email
import re
from dataclasses import dataclass, field
from email import policy
from email.utils import getaddresses, parseaddr
from pathlib import Path

from bs4 import BeautifulSoup

import config as C


class EmailParseError(ValueError):
    """Raised for empty, oversized, unsupported or unreadable input."""


@dataclass
class Link:
    url: str
    text: str = ""          # visible link text (HTML <a>), empty for plain-text URLs
    source: str = "text"    # "text" or "html"


@dataclass
class ParsedEmail:
    sender: str = ""                    # full From value, e.g. "Example Bank <alerts@examplebank.com>"
    display_name: str = ""
    address: str = ""
    subject: str = ""
    body_text: str = ""                 # plain text used for analysis
    body_html: str = ""                 # original HTML (never rendered)
    reply_to: str = ""
    return_path: str = ""
    to: str = ""
    date: str = ""
    headers: dict = field(default_factory=dict)
    attachments: list = field(default_factory=list)     # [{"filename", "content_type", "size"}]
    html_links: list = field(default_factory=list)      # [Link] from <a href>
    source: str = "manual"              # manual / txt / eml
    truncated: bool = False

    @property
    def is_empty(self) -> bool:
        return not (self.subject.strip() or self.body_text.strip() or self.body_html.strip())


# --------------------------------------------------------------------------- helpers
def split_sender(value: str) -> tuple[str, str]:
    """'Name <a@b.com>' -> ('Name', 'a@b.com'). Works for bare addresses too."""
    name, addr = parseaddr(value or "")
    return name.strip().strip('"'), addr.strip()


def html_to_text(html: str) -> tuple[str, list[Link]]:
    """Visible text + links from HTML. Scripts, styles and comments are removed, nothing is executed."""
    soup = BeautifulSoup(html or "", "html.parser")
    links = []
    for a in soup.find_all("a"):
        href = (a.get("href") or "").strip()
        if href and not href.lower().startswith(("mailto:", "tel:", "#", "javascript:")):
            links.append(Link(url=href, text=a.get_text(" ", strip=True), source="html"))
        elif href.lower().startswith("javascript:"):
            links.append(Link(url=href, text=a.get_text(" ", strip=True), source="html"))
    for tag in soup(["script", "style", "head", "noscript", "iframe", "object", "embed"]):
        tag.decompose()
    for br in soup.find_all(["br", "p", "div", "tr", "li", "h1", "h2", "h3"]):
        br.append("\n")
    text = soup.get_text(" ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    return text.strip(), links


def looks_like_html(text: str) -> bool:
    return bool(re.search(r"<(html|body|a\s|div|p>|p\s|table|br|span)", text or "", re.I))


def _limit(text: str) -> tuple[str, bool]:
    if len(text) > C.MAX_BODY_CHARS:
        return text[: C.MAX_BODY_CHARS], True
    return text, False


def _finish(p: ParsedEmail) -> ParsedEmail:
    p.display_name, p.address = split_sender(p.sender)
    if p.body_html:
        html_text, p.html_links = html_to_text(p.body_html)
        if not p.body_text:
            p.body_text = html_text
        elif re.sub(r"\W+", " ", html_text).strip().lower() not in re.sub(r"\W+", " ", p.body_text).lower():
            # the HTML part says something the plain-text part does not -> analyse both
            p.body_text = p.body_text.rstrip() + "\n\n" + html_text
    p.body_text, p.truncated = _limit(p.body_text)
    if p.is_empty:
        raise EmailParseError("The email is empty - enter at least a subject or a body.")
    return p


# --------------------------------------------------------------------------- manual input
def parse_manual(sender: str, subject: str, body: str) -> ParsedEmail:
    """Fields typed into the form. An HTML body is detected and converted to text."""
    p = ParsedEmail(sender=(sender or "").strip(), subject=(subject or "").strip(), source="manual")
    body = body or ""
    if looks_like_html(body):
        p.body_html = body
    else:
        p.body_text = body
    return _finish(p)


# --------------------------------------------------------------------------- .txt
HEADER_LINE = re.compile(r"^(From|Sender|Subject|To|Reply-To|Date)\s*:\s*(.*)$", re.I)


def parse_text(raw: str, source: str = "txt") -> ParsedEmail:
    """
    Plain text e-mail. Optional header lines at the top are recognised:
        From: Example Bank <alerts@examplebank.com>
        Subject: Your statement
        (blank line)
        body ...
    Without headers the whole text is the body.
    """
    if raw is None or not raw.strip():
        raise EmailParseError("The file is empty.")
    lines = raw.replace("\r\n", "\n").split("\n")
    p = ParsedEmail(source=source)
    i = 0
    while i < len(lines) and i < 20:
        m = HEADER_LINE.match(lines[i].strip())
        if not m:
            break
        key, val = m.group(1).lower(), m.group(2).strip()
        if key in ("from", "sender"):
            p.sender = val
        elif key == "subject":
            p.subject = val
        elif key == "reply-to":
            p.reply_to = val
        elif key == "to":
            p.to = val
        elif key == "date":
            p.date = val
        p.headers[m.group(1).title()] = val
        i += 1
    body = "\n".join(lines[i:]).strip("\n")
    if looks_like_html(body):
        p.body_html = body
    else:
        p.body_text = body
    return _finish(p)


# --------------------------------------------------------------------------- .eml
SAFE_HEADERS = ["From", "To", "Reply-To", "Return-Path", "Subject", "Date", "Message-ID",
                "Authentication-Results", "Received-SPF", "DKIM-Signature", "X-Mailer"]


def parse_eml(data: bytes) -> ParsedEmail:
    """Parse an RFC 5322 .eml file. Attachments are listed, never extracted to disk or run."""
    if not data or not data.strip():
        raise EmailParseError("The .eml file is empty.")
    try:
        msg = email.message_from_bytes(data, policy=policy.default)
    except Exception as exc:  # noqa: BLE001 - the email package can raise many types on bad input
        raise EmailParseError("This file could not be read as an email (.eml).") from exc
    if not any(msg.get(h) for h in ("From", "Subject", "To", "Date", "Message-ID")) and not msg.is_multipart():
        raise EmailParseError("No email headers were found - is this really an .eml file? "
                              "For plain text use a .txt file or paste the text.")

    def header(name: str) -> str:
        try:
            return str(msg.get(name, "") or "").strip()
        except Exception:  # noqa: BLE001 - malformed encoded header
            return ""

    p = ParsedEmail(source="eml", sender=header("From"), subject=header("Subject"), reply_to=header("Reply-To"),
                    return_path=header("Return-Path"), to=header("To"), date=header("Date"))
    p.headers = {h: header(h)[:500] for h in SAFE_HEADERS if header(h)}
    p.headers["Received (hops)"] = str(len(msg.get_all("Received", []) or []))

    texts, htmls = [], []
    for part in msg.walk():
        if part.is_multipart():
            continue
        disposition = (part.get_content_disposition() or "").lower()
        filename = part.get_filename()
        ctype = part.get_content_type()
        if disposition == "attachment" or (filename and disposition != "inline") or (
                filename and not ctype.startswith("text/")):
            try:
                size = len(part.get_payload(decode=True) or b"")
            except Exception:  # noqa: BLE001
                size = 0
            p.attachments.append({"filename": filename or "(unnamed)", "content_type": ctype, "size": size})
            continue
        if ctype not in ("text/plain", "text/html"):
            continue
        try:
            content = part.get_content()
        except Exception:  # noqa: BLE001 - unknown charset or broken encoding
            raw = part.get_payload(decode=True) or b""
            content = raw.decode("utf-8", errors="replace")
        (texts if ctype == "text/plain" else htmls).append(str(content))

    p.body_text = "\n".join(texts).strip()
    p.body_html = "\n".join(htmls).strip()
    return _finish(p)


# --------------------------------------------------------------------------- uploads
def validate_upload(filename: str, data: bytes) -> str:
    """Check extension and size. Returns the lower-case extension."""
    ext = Path(filename or "").suffix.lower()
    if ext not in C.ALLOWED_UPLOAD_EXTENSIONS:
        raise EmailParseError(f"Unsupported file type '{ext or 'none'}'. Upload a .txt or .eml file.")
    if data is None or len(data) == 0:
        raise EmailParseError("The uploaded file is empty.")
    if len(data) > C.MAX_UPLOAD_BYTES:
        raise EmailParseError(f"The file is larger than {C.MAX_UPLOAD_BYTES // (1024 * 1024)} MB.")
    return ext


def parse_upload(filename: str, data: bytes) -> ParsedEmail:
    ext = validate_upload(filename, data)
    if ext == ".eml":
        return parse_eml(data)
    if b"\x00" in data[:4096]:
        raise EmailParseError("The file looks like a binary file, not text.")
    return parse_text(data.decode("utf-8", errors="replace"), source="txt")


def all_recipients(p: ParsedEmail) -> list[str]:
    return [a for _, a in getaddresses([p.to]) if a]
