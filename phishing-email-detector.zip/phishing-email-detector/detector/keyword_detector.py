"""
Suspicious language detection: phishing keywords, urgent/threatening language,
requests for sensitive information and risky attachment references.

Matching is case-insensitive and on word boundaries. To avoid flagging harmless text:
  * a phrase preceded by a negation ("we will NEVER ask for your password") is ignored
  * a short phrase inside a longer matched phrase is not counted twice
    ("click here" inside "click here immediately")
  * every phrase counts once per e-mail, however often it appears
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import config as C


@dataclass
class KeywordHit:
    phrase: str
    category: str
    level: str          # low / medium / high
    why: str
    matches: list = field(default_factory=list)    # the actual text found
    count: int = 0


def normalise(text: str) -> str:
    text = (text or "").replace("’", "'").replace(" ", " ")
    return re.sub(r"\s+", " ", text)


def _compile(pattern: str) -> re.Pattern:
    return re.compile(rf"(?<![\w]){pattern}(?![\w])", re.I)


_NEG = re.compile(C.NEGATION_PATTERN, re.I)


def is_negated(text: str, start: int, window: int = 45) -> bool:
    """True if a negation word appears shortly before the match, in the same sentence."""
    before = text[max(0, start - window):start]
    before = re.split(r"[.!?\n]", before)[-1]
    return bool(_NEG.search(before))


def find_keywords(text: str, keywords: list | None = None) -> list[KeywordHit]:
    text = normalise(text)
    keywords = keywords if keywords is not None else C.KEYWORDS
    order = {"high": 0, "medium": 1, "low": 2}
    # strongest and longest phrases first, so their spans can block weaker overlapping ones
    ranked = sorted(keywords, key=lambda k: (order.get(k["level"], 3), -len(k["phrase"])))
    taken: list[tuple[int, int]] = []
    hits = []
    for kw in ranked:
        hit = KeywordHit(kw["phrase"], kw["category"], kw["level"], kw["why"])
        for m in _compile(kw["pattern"]).finditer(text):
            if is_negated(text, m.start()):
                continue
            if any(s <= m.start() and m.end() <= e for s, e in taken):
                continue
            hit.matches.append(m.group(0))
            hit.count += 1
            taken.append((m.start(), m.end()))
        if hit.count:
            hit.matches = sorted(set(x.lower() for x in hit.matches))
            hits.append(hit)
    return hits


def find_urgency(text: str) -> list[str]:
    text = normalise(text)
    found = []
    for pat in C.URGENCY_PATTERNS:
        for m in _compile(pat).finditer(text):
            if not is_negated(text, m.start()):
                found.append(m.group(0).lower())
    return sorted(set(found))


def find_sensitive_requests(text: str) -> list[dict]:
    """[{"item": "password / PIN", "match": "enter your password"}] - negated mentions are skipped."""
    text = normalise(text)
    out, seen = [], set()
    for pat, label in C.SENSITIVE_PATTERNS:
        for m in _compile(pat).finditer(text):
            if is_negated(text, m.start()) or label in seen:
                continue
            seen.add(label)
            out.append({"item": label, "match": m.group(0)})
    return out


def find_attachment_risks(text: str, attachments: list | None = None) -> list[dict]:
    """Risky attachments actually present in an .eml, plus attachment references in the text."""
    out = []
    for a in attachments or []:
        name = a.get("filename", "")
        suffixes = [s.lower() for s in Path(name).suffixes]
        risky = [s for s in suffixes if s in C.RISKY_ATTACHMENT_EXT]
        double_ext = len(suffixes) >= 2 and suffixes[-1] in C.RISKY_ATTACHMENT_EXT
        if risky:
            out.append({"source": "attachment", "detail": name,
                        "reason": "double extension disguising the real type" if double_ext and len(suffixes) > 1
                        and suffixes[-2] in {".pdf", ".doc", ".docx", ".jpg", ".png", ".txt", ".xlsx"}
                        else f"file type {risky[-1]} can run code or hide other files"})
    text = normalise(text)
    for pat in C.ATTACHMENT_PATTERNS:
        for m in _compile(pat).finditer(text):
            if not is_negated(text, m.start()):
                out.append({"source": "text", "detail": m.group(0), "reason": "asks you to open or enable an attachment"
                            if not re.search(r"\.\w+$", m.group(0)) else "mentions a file type that can run code"})
    uniq, seen = [], set()
    for o in out:
        key = (o["source"], o["detail"].lower())
        if key not in seen:
            seen.add(key)
            uniq.append(o)
    return uniq
