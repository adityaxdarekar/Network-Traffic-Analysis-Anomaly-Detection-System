"""
PDF scan report (ReportLab).

Works from the analysis dictionary (AnalysisResult.to_dict() or a stored scan's details), so a report
can be produced right after a scan or later from Scan History. All text from the email is escaped
before it is placed in the PDF.

Contents: project title · scan ID/date · sender · subject · score and classification · score breakdown ·
sender analysis · suspicious keywords · extracted URLs and URL analysis · detailed findings ·
recommendations · disclaimer.
"""

from __future__ import annotations

import io
import re
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

import config as C

NAVY = colors.HexColor("#0b1f3a")
BLUE = colors.HexColor("#2563eb")
LIGHT = colors.HexColor("#f1f5f9")
BORDER = colors.HexColor("#cbd5e1")
TEXT = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#64748b")
LEVEL_COLORS = {k: colors.HexColor(v) for k, v in C.RISK_COLORS.items()}
RISK_CELL = {"High": colors.HexColor("#fee2e2"), "Medium": colors.HexColor("#fef3c7"),
             "Low": colors.HexColor("#e0f2fe"), "None": colors.HexColor("#dcfce7")}
PAGE_W, PAGE_H = A4
MARGIN = 1.8 * cm
WIDTH = PAGE_W - 2 * MARGIN

ST = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=NAVY),
    "sub": ParagraphStyle("sub", fontName="Helvetica", fontSize=9.5, leading=13, textColor=MUTED, spaceAfter=8),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=11.5, leading=15, textColor=BLUE, spaceBefore=12,
                         spaceAfter=5),
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.3, leading=13, textColor=TEXT, spaceAfter=4),
    "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8, leading=10.5, textColor=MUTED),
    "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=8, leading=10.2, textColor=TEXT),
    "url": ParagraphStyle("url", fontName="Helvetica", fontSize=8, leading=10.2, textColor=TEXT, wordWrap="CJK"),
    "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=8, leading=10.2, textColor=colors.white),
    "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=9.3, leading=13, textColor=TEXT, leftIndent=12,
                             bulletIndent=2, spaceAfter=3),
    "score": ParagraphStyle("score", fontName="Helvetica-Bold", fontSize=30, leading=34, textColor=colors.white,
                            alignment=1),
    "level": ParagraphStyle("level", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=colors.white,
                            alignment=1),
}


def esc(value, limit: int = 600) -> str:
    text = "" if value is None else str(value)
    text = text if len(text) <= limit else text[:limit] + "…"
    return escape(text)


def P(text, style="cell", limit=600) -> Paragraph:
    return Paragraph(esc(text, limit) or "-", ST[style])


def table(header: list, rows: list, widths: list, risk_col: int | None = None, url_cols: tuple = ()) -> Table:
    """url_cols: columns holding URLs/addresses, wrapped at any character so long links fit."""
    data = [[Paragraph(escape(h), ST["cellb"]) for h in header]] + \
           [[P(c, "url" if j in url_cols else "cell") for j, c in enumerate(r)] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 3),
             ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT])]
    if risk_col is not None:
        for i, r in enumerate(rows, start=1):
            if r[risk_col] in RISK_CELL:
                style.append(("BACKGROUND", (risk_col, i), (risk_col, i), RISK_CELL[r[risk_col]]))
    t.setStyle(TableStyle(style))
    return t


def kv(rows: list[tuple]) -> Table:
    t = Table([[Paragraph(f"<b>{escape(k)}</b>", ST["cell"]), P(v)] for k, v in rows],
              colWidths=[4.2 * cm, WIDTH - 4.2 * cm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t


def _page(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, PAGE_H - 1.2 * cm, PAGE_W, 1.2 * cm, stroke=0, fill=1)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 9)
    canvas.drawString(MARGIN, PAGE_H - 0.78 * cm, C.APP_TITLE)
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 0.78 * cm, doc.scan_id)
    canvas.setFillColor(MUTED)
    canvas.drawString(MARGIN, 1.0 * cm, "Rule-based indicators only - not proof of malicious intent. Analysed locally.")
    canvas.drawRightString(PAGE_W - MARGIN, 1.0 * cm, f"Page {doc.page}")
    canvas.restoreState()


def safe_filename(scan_id: str) -> str:
    return "phishing_report_" + re.sub(r"[^A-Za-z0-9_-]", "_", scan_id or "scan") + ".pdf"


def build_story(d: dict) -> list:
    level = d.get("level", "LOW")
    story = [Paragraph("Phishing Email Analysis Report", ST["title"]),
             Paragraph(f"{escape(C.APP_TITLE)} · v{C.APP_VERSION}", ST["sub"])]

    score_box = Table([[Paragraph(str(d.get("score", 0)), ST["score"])], [Paragraph("/ 100", ST["level"])],
                       [Paragraph(escape(d.get("classification", "")), ST["level"])]],
                      colWidths=[5.2 * cm], rowHeights=[1.3 * cm, 0.55 * cm, 1.1 * cm])
    score_box.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LEVEL_COLORS.get(level, NAVY)),
                                   ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    meta = Table([[Paragraph(f"<b>{escape(k)}</b>", ST["cell"]), P(v)] for k, v in [
        ("Scan ID", d.get("scan_id")), ("Scan date and time", d.get("analyzed_at")), ("Sender", d.get("sender")),
        ("Subject", d.get("subject")), ("Input type", d.get("source")),
        ("Indicators triggered", len(d.get("indicators", []))), ("URLs extracted", d.get("url_count", 0))]],
        colWidths=[3.6 * cm, WIDTH - 5.6 * cm - 3.6 * cm])
    meta.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, BORDER), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                              ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    top = Table([[meta, score_box]], colWidths=[WIDTH - 5.6 * cm, 5.6 * cm])
    top.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                             ("ALIGN", (1, 0), (1, 0), "RIGHT")]))
    story += [top, Spacer(1, 6), Paragraph(escape(d.get("summary", "")), ST["body"]),
              Paragraph(escape(d.get("disclaimer", "")), ST["small"])]

    story.append(Paragraph("1. Score breakdown", ST["h2"]))
    cats = d.get("by_category", {})
    if cats:
        rows = [[c, v["raw"], v["capped"], C.CATEGORY_CAPS.get(c, 100)] for c, v in cats.items()]
        story.append(table(["Category", "Points triggered", "Points counted", "Category cap"], rows,
                           [5 * cm, 4 * cm, 4 * cm, WIDTH - 13 * cm]))
        story.append(Paragraph("Each indicator counts once; categories are capped and the total is limited to 100. "
                               "Thresholds: 0-29 low, 30-59 medium, 60-100 high. The score is a heuristic, not a "
                               "probability.", ST["small"]))
    else:
        story.append(Paragraph("No indicator contributed points.", ST["body"]))

    story.append(Paragraph("2. Sender analysis", ST["h2"]))
    sa = d.get("sender_analysis", {})
    story.append(kv([(r["Field"], r["Value"]) for r in sa.get("rows", [])] or [("Sender", "(not provided)")]))
    for f in sa.get("findings", []):
        story.append(Paragraph(f"<b>{escape(f['check'])}:</b> {esc(f['reason'])}", ST["bullet"], bulletText="•"))
    for n in sa.get("notes", []):
        story.append(Paragraph(esc(n), ST["small"]))

    story.append(Paragraph("3. Suspicious keywords and language", ST["h2"]))
    kws = d.get("keywords", [])
    if kws:
        story.append(table(["Phrase", "Found in email", "Category", "Level", "Why it is suspicious"],
                           [[k["phrase"], ", ".join(k["matches"]), k["category"], k["level"].title(), k["why"]]
                            for k in kws], [3.3 * cm, 3.2 * cm, 2.6 * cm, 1.7 * cm, WIDTH - 10.8 * cm]))
    else:
        story.append(Paragraph("No phishing keywords from the dictionary were found.", ST["body"]))
    extra = []
    if d.get("urgency"):
        extra.append(("Urgent / threatening language", ", ".join(d["urgency"])))
    if d.get("sensitive_requests"):
        extra.append(("Sensitive information requested", ", ".join(s["item"] for s in d["sensitive_requests"])))
    if d.get("attachments"):
        extra.append(("Attachment risks", "; ".join(f"{a['detail']} ({a['reason']})" for a in d["attachments"])))
    if extra:
        story += [Spacer(1, 5), kv(extra)]

    story.append(Paragraph("4. Extracted URLs and URL analysis", ST["h2"]))
    urls = d.get("urls", [])
    if urls:
        story.append(table(["URL", "Finding", "Reason", "Risk"], [[u["URL"], u["Finding"], u["Reason"], u["Risk"]]
                                                                  for u in urls],
                           [5.4 * cm, 3.4 * cm, WIDTH - 10.6 * cm, 1.8 * cm], risk_col=3, url_cols=(0,)))
        story.append(Paragraph("URLs were analysed as text only - none was opened, resolved or downloaded. HTTPS "
                               "alone does not mean a site is safe.", ST["small"]))
    else:
        story.append(Paragraph("No URLs were found in the email.", ST["body"]))

    story.append(Paragraph("5. Detailed findings", ST["h2"]))
    inds = d.get("indicators", [])
    if inds:
        story.append(table(["#", "Indicator", "Category", "Points", "Explanation", "Evidence"],
                           [[n, i["title"], i["category"], i["points"], i["explanation"], i["evidence"]]
                            for n, i in enumerate(inds, 1)],
                           [0.8 * cm, 3.5 * cm, 2.0 * cm, 1.4 * cm, WIDTH - 11.7 * cm, 4.0 * cm], url_cols=(5,)))
    else:
        story.append(Paragraph("No rule was triggered.", ST["body"]))

    recs = [Paragraph("6. Recommendations", ST["h2"])]
    recs += [Paragraph(esc(r), ST["bullet"], bulletText="•") for r in d.get("recommendations", [])]
    story.append(KeepTogether(recs))
    return story


def generate_pdf_bytes(details: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=1.9 * cm,
                            bottomMargin=1.7 * cm, title="Phishing Email Analysis Report", author=C.APP_TITLE)
    doc.scan_id = details.get("scan_id", "")
    doc.build(build_story(details), onFirstPage=_page, onLaterPages=_page)
    return buf.getvalue()


def generate_pdf_report(details: dict, output_path: Path | str | None = None) -> Path:
    path = Path(output_path) if output_path else C.REPORT_DIR / safe_filename(details.get("scan_id", ""))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(generate_pdf_bytes(details))
    return path
