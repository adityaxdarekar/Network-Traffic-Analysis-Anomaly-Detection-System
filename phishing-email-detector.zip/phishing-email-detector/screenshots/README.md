# Screenshots

## Included (real output)
- `report_P1_high_page1.png`: first page of the PDF report for sample P1 (fake bank verification, HIGH 100)
- `report_U1_high_page1.png`: first page of the PDF report for sample U1 (link-text mismatch, HIGH 65)

## Take these on your computer
Dashboard screenshots could not be taken in the development environment, because Streamlit could not be installed
there. After `./run.sh`:

| File | What to capture |
|---|---|
| 01_home.png | Home Dashboard after analysing several samples (KPIs + charts) |
| 02_analyze_high.png | Analyze Email with sample P1: banner, gauge, findings |
| 03_analyze_low.png | Analyze Email with sample L2 |
| 04_url_analysis.png | URL Analysis for sample U1 (link-text mismatch) |
| 05_history.png | Scan History table |
| 06_reports.png | Reports page |
| 07_eml_upload.png | Analyze Email after uploading `samples/eml/bank_phishing_html.eml` |

Windows: Win + Shift + S · Ubuntu/Kali: PrtSc or `gnome-screenshot -w` · macOS: Cmd + Shift + 4.
