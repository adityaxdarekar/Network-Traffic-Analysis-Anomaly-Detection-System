"""
SQLite scan history (stored locally in output/scan_history.db).

Privacy: the email BODY is not stored unless the user turns on "store email body" in Settings.
Only sender, subject, score, classification, indicator count and a short summary are kept, plus the
analysis details (indicators, URL table) needed to regenerate a report.
"""

from __future__ import annotations

import csv
import io
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

import config as C

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    scan_id          TEXT PRIMARY KEY,
    scanned_at       TEXT NOT NULL,
    sender           TEXT,
    subject          TEXT,
    risk_score       INTEGER NOT NULL,
    risk_level       TEXT NOT NULL,
    classification   TEXT NOT NULL,
    indicator_count  INTEGER NOT NULL,
    url_count        INTEGER NOT NULL DEFAULT 0,
    source           TEXT,
    summary          TEXT,
    details_json     TEXT,
    body             TEXT
);
CREATE INDEX IF NOT EXISTS idx_scans_time ON scans(scanned_at);
"""

EXPORT_COLUMNS = ["scan_id", "scanned_at", "sender", "subject", "risk_score", "risk_level", "classification",
                  "indicator_count", "url_count", "source", "summary"]


class DatabaseError(RuntimeError):
    pass


class DatabaseManager:
    def __init__(self, path: Path | str | None = None):
        self.path = Path(path or C.DB_PATH)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._conn() as con:
                con.executescript(SCHEMA)
        except (OSError, sqlite3.Error) as exc:
            raise DatabaseError(f"Cannot open the scan history database at {self.path}: {exc}") from exc

    @contextmanager
    def _conn(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        finally:
            con.close()

    # ------------------------------------------------------------------ write
    def save_scan(self, result, store_body: bool = False) -> str:
        """Store an AnalysisResult. Parameterised SQL only."""
        details = result.to_dict(include_body=False)
        with self._conn() as con:
            con.execute(
                "INSERT OR REPLACE INTO scans (scan_id, scanned_at, sender, subject, risk_score, risk_level, "
                "classification, indicator_count, url_count, source, summary, details_json, body) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (result.scan_id, result.analyzed_at, result.email.sender[:300], result.email.subject[:500],
                 result.score, result.level, result.label, len(result.indicators), len(result.urls),
                 result.email.source, result.summary[:1000], json.dumps(details),
                 result.email.body_text if store_body else None))
        return result.scan_id

    def delete_scan(self, scan_id: str) -> bool:
        with self._conn() as con:
            return con.execute("DELETE FROM scans WHERE scan_id = ?", (scan_id,)).rowcount > 0

    def clear(self) -> int:
        with self._conn() as con:
            return con.execute("DELETE FROM scans").rowcount

    # ------------------------------------------------------------------ read
    def list_scans(self, level: str | None = None, search: str = "") -> pd.DataFrame:
        sql = f"SELECT {', '.join(EXPORT_COLUMNS)}, body IS NOT NULL AS body_stored FROM scans"
        cond, args = [], []
        if level:
            cond.append("risk_level = ?")
            args.append(level)
        if search:
            cond.append("(sender LIKE ? OR subject LIKE ?)")
            args += [f"%{search}%", f"%{search}%"]
        if cond:
            sql += " WHERE " + " AND ".join(cond)
        sql += " ORDER BY scanned_at DESC, rowid DESC"
        with self._conn() as con:
            rows = [dict(r) for r in con.execute(sql, args)]
        return pd.DataFrame(rows, columns=EXPORT_COLUMNS + ["body_stored"])

    def get_scan(self, scan_id: str) -> dict | None:
        with self._conn() as con:
            row = con.execute("SELECT * FROM scans WHERE scan_id = ?", (scan_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["details"] = json.loads(d.pop("details_json") or "{}")
        return d

    def stats(self) -> dict:
        with self._conn() as con:
            total = con.execute("SELECT COUNT(*) FROM scans").fetchone()[0]
            by = dict(con.execute("SELECT risk_level, COUNT(*) FROM scans GROUP BY risk_level").fetchall())
            avg = con.execute("SELECT AVG(risk_score) FROM scans").fetchone()[0]
        return {"total": total, "LOW": by.get("LOW", 0), "MEDIUM": by.get("MEDIUM", 0), "HIGH": by.get("HIGH", 0),
                "average_score": round(avg or 0, 1)}

    def export_csv(self) -> str:
        df = self.list_scans()[EXPORT_COLUMNS]
        buf = io.StringIO()
        df.to_csv(buf, index=False, quoting=csv.QUOTE_MINIMAL)
        return buf.getvalue()
